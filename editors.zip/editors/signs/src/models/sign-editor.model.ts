/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { EditorData } from '@oksygen-sim-train-libraries/components-services/editors';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';

export const SIGNS_CARD_DATA = new EditorData(
  t('Signs'),
  '/editors/signs',
  OksygenIcon.SIGN,
  'signs'
);
