/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Sign } from '@oksygen-sim-train-libraries/components-services/signs';

export interface SignEditorState {
  selectedSign: Sign;
  searchValue: string;
  editing: boolean;

  templateSearchValue: string;
  elementSearchValue: string;
  textSearchValue: string;
}

export const initialSignEditorState: SignEditorState = {
  selectedSign: null,
  searchValue: '',
  editing: false,
  templateSearchValue: '',
  elementSearchValue: '',
  textSearchValue: ''
};
