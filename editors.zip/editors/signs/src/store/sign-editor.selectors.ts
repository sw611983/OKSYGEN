/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createFeatureSelector, createSelector } from '@ngrx/store';

import { SignEditorState } from './sign-editor.state';

export const selectSignEditorState = createFeatureSelector<SignEditorState>(
  'signEditor'
);
export const getSelectedSign = createSelector(
  selectSignEditorState,
  (state: SignEditorState) => state.selectedSign
);
export const getSignSearchValue = createSelector(
  selectSignEditorState,
  (state: SignEditorState) => state.searchValue
);
export const getSignEditing = createSelector(
  selectSignEditorState,
  (state: SignEditorState) => state.editing
);
export const getSignTemplateSearchValue = createSelector(
  selectSignEditorState,
  (state: SignEditorState) => state.templateSearchValue
);
export const getSignElementSearchValue = createSelector(
  selectSignEditorState,
  (state: SignEditorState) => state.elementSearchValue
);
export const getSignTextSearchValue = createSelector(
  selectSignEditorState,
  (state: SignEditorState) => state.textSearchValue
);
