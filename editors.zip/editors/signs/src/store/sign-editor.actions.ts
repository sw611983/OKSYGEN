/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createAction, props } from '@ngrx/store';

import { Sign } from '@oksygen-sim-train-libraries/components-services/signs';

export enum SignEditorActionEnum {
  UPDATE_SELECTED_SIGN = '[SignEditorActionEnum] UPDATE_SELECTED_SIGN',
  UPDATE_SEARCH_VALUE = '[SignEditorActionEnum] UPDATE_SEARCH_VALUE',
  UPDATE_EDITING = '[SignEditorActionEnum] UPDATE_EDITING',
  UPDATE_TEMPLATE_SEARCH_VALUE = '[SignEditorActionEnum] UPDATE_TEMPLATE_SEARCH_VALUE',
  UPDATE_ELEMENT_SEARCH_VALUE = '[SignEditorActionEnum] UPDATE_ELEMENT_SEARCH_VALUE',
  UPDATE_TEXT_SEARCH_VALUE = '[SignEditorActionEnum] UPDATE_TEXT_SEARCH_VALUE',
  RESET = '[SignEditorActionEnum] RESET'
}

export const updateSelectedSignAction = createAction(SignEditorActionEnum.UPDATE_SELECTED_SIGN, props<{ value: Sign }>());
export const updateSignSearchValueAction = createAction(SignEditorActionEnum.UPDATE_SEARCH_VALUE, props<{ value: string }>());
export const updateEditingSignAction = createAction(SignEditorActionEnum.UPDATE_EDITING, props<{ value: boolean }>());
export const updateTemplateSearchValueAction = createAction(SignEditorActionEnum.UPDATE_TEMPLATE_SEARCH_VALUE, props<{ value: string }>());
export const updateElementSearchValueAction = createAction(SignEditorActionEnum.UPDATE_ELEMENT_SEARCH_VALUE, props<{ value: string }>());
export const updateTextSearchValueAction = createAction(SignEditorActionEnum.UPDATE_TEXT_SEARCH_VALUE, props<{ value: string }>());
export const resetSignAction = createAction(SignEditorActionEnum.RESET);

