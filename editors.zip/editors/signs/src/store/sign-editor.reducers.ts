/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createReducer, on } from '@ngrx/store';

import * as EditorActions from './sign-editor.actions';
import {
  initialSignEditorState,
  SignEditorState
} from './sign-editor.state';

export const signEditorReducer = createReducer(
  initialSignEditorState,
  on(EditorActions.resetSignAction, (state: SignEditorState, action: any) => ({
    ...initialSignEditorState
  })),
  on(
    EditorActions.updateEditingSignAction,
    (state: SignEditorState, action: any) => ({
      ...state,
      editing: action.props.value
    })
  ),
  on(
    EditorActions.updateElementSearchValueAction,
    (state: SignEditorState, action: any) => ({
      ...state,
      elementSearchValue: action.props.value
    })
  ),
  on(
    EditorActions.updateSignSearchValueAction,
    (state: SignEditorState, action: any) => ({
      ...state,
      searchValue: action.props.value
    })
  ),
  on(
    EditorActions.updateSelectedSignAction,
    (state: SignEditorState, action: any) => ({
      ...state,
      selectedSign: action.props.value
    })
  ),
  on(
    EditorActions.updateTemplateSearchValueAction,
    (state: SignEditorState, action: any) => ({
      ...state,
      templateSearchValue: action.props.value
    })
  ),
  on(
    EditorActions.updateTextSearchValueAction,
    (state: SignEditorState, action: any) => ({
      ...state,
      textSearchValue: action.props.value
    })
  )
);
