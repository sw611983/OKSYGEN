/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AbstractBrowserService } from '@oksygen-sim-train-libraries/components-services/editors';

import { SignEditorActionEnum } from '../store/sign-editor.actions';
import { SignEditorState } from '../store/sign-editor.state';

@Injectable()
export class SignsEditorService extends AbstractBrowserService {
  constructor(private store: Store<SignEditorState>) {
    super('SignsEditorService');
  }

  /**
   * This is called when the page is first opened
   */
  public override initialiseEditing(): void {
    super.initialiseEditing();
    // TODO: Any local initialisation for this
  }

  /**
   * This is called when the page is being closed fully
   */
  public override resetEditing(): void {
    super.resetEditing();
    this.store.dispatch({
      type: SignEditorActionEnum.RESET
    });
  }
}
