/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

// TODO Perhaps we should use Spectator for writing tests...
// import { createServiceFactory, mockProvider, SpectatorService } from '@ngneat/spectator';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { provideMockStore } from '@ngrx/store/testing';

import { SignsEditorService } from './signs-editor.service';

describe('SignsEditorService', () => {
  // TODO Perhaps we should use Spectator for writing tests...
  // let spectator: SpectatorService<SignsEditorService>;
  // const createService = createServiceFactory({
  //   service: SignsEditorService,
  //   providers: [
  //     mockProvider(TranslateService),
  //     provideMockStore({})
  //   ]
  // });

  // beforeEach(() => spectator = createService());

  // it('should be created', () => {
  //   expect(spectator.service).toBeTruthy();
  // });

  let service: SignsEditorService;

  beforeEach(() => {
    // waitForAsync(() => {
    //   configureSimTrainTestingModule({
    //     imports: [ OksygenSimTrainEditorsModule ],
    //     providers: [provideMockStore({})]
    //   });
    //   service = TestBed.inject(SignsEditorService);
    // })
    waitForAsync(() => {
      const tb = TestBed.configureTestingModule({providers: [provideMockStore({})]});
      service = tb.inject(SignsEditorService);
    });
    service = new SignsEditorService(null);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
