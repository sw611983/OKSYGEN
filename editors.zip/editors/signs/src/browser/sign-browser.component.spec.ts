/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { BehaviorSubject, Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { SignBrowserComponent } from './sign-browser.component';
import { SignService } from '@oksygen-sim-train-libraries/components-services/signs';
import { getSelectedSign, getSignSearchValue, getSignEditing } from '../store/sign-editor.selectors';

describe('SignsComponent', () => {
  let component: SignBrowserComponent;
  let fixture: ComponentFixture<SignBrowserComponent>;
  const signServiceData = new BehaviorSubject(null);

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [ OksygenSimTrainEditorsModule ],
        providers: [
          {
            provide: SignService,
            useValue: {
              data: (): Observable<any> => signServiceData.asObservable()
            }
          },
          provideMockStore({
            selectors: [
              { selector: getSelectedSign, value: null },
              { selector: getSignSearchValue, value: '' },
              { selector: getSignEditing, value: false }
            ]
          })
        ],
        declarations: [ SignBrowserComponent ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(SignBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // FIXME Having some problems with the File Manager which I'm not sure how to solve...
  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
