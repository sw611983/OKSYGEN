/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, of, Subscription } from 'rxjs';

import { BasicTabNavItem, BasicTabNavItemComponent, TabGroupChild, TabService } from '@oksygen-common-libraries/material/components';
import { SignService } from '@oksygen-sim-train-libraries/components-services/signs';

import { SIGNS_CARD_DATA } from '../models/sign-editor.model';
import { SignsEditorService } from '../services/signs-editor.service';
import { SignEditorActionEnum } from '../store/sign-editor.actions';
import { getSignElementSearchValue, getSignTemplateSearchValue, getSignTextSearchValue } from '../store/sign-editor.selectors';
import { SignEditorState } from '../store/sign-editor.state';

@Component({
  selector: 'oksygen-sign-editor',
  templateUrl: './sign-editor.component.html',
  styleUrls: ['./sign-editor.component.scss']
})
export class SignEditorComponent implements OnInit, OnDestroy {
  readonly PANEL_HEADER_HEIGHT = '67px';

  templateSearchValue = '';
  elementSearchValue = '';
  textSearchValue = '';

  private tsvSubscription: Subscription;
  private esvSubscription: Subscription;
  private txtSvSubscription: Subscription;

  constructor(
    private signsEditorService: SignsEditorService,
    private translateService: TranslateService,
    private signService: SignService,
    private store: Store<SignEditorState>,
    private tabService: TabService
  ) {}

  ngOnInit(): void {
    this.tsvSubscription = this.store.select(getSignTemplateSearchValue).subscribe(value => {
      this.templateSearchValue = value;
    });

    this.esvSubscription = this.store.select(getSignElementSearchValue).subscribe(value => {
      this.elementSearchValue = value;
    });

    this.txtSvSubscription = this.store.select(getSignTextSearchValue).subscribe(value => {
      this.templateSearchValue = value;
    });

    const signsTab: TabGroupChild<BasicTabNavItem> = {
      data: {
        id: SIGNS_CARD_DATA.id,
        groupId: SIGNS_CARD_DATA.id,
        icon: 'list_alt',
        routerLink: SIGNS_CARD_DATA.routerLink,
        name: SIGNS_CARD_DATA.name,
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => of(true)
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: SIGNS_CARD_DATA.id,
        groupName: SIGNS_CARD_DATA.name,
        route: SIGNS_CARD_DATA.routerLink,
        // groupIcon: SIGNS_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [signsTab]
    });
  }

  ngOnDestroy(): void {
    this.tsvSubscription.unsubscribe();
    this.esvSubscription.unsubscribe();
    this.txtSvSubscription.unsubscribe();
  }

  setTemplateSearchValue(searchValue: string): void {
    this.store.dispatch({ type: SignEditorActionEnum.UPDATE_TEMPLATE_SEARCH_VALUE, props: { value: searchValue }});
  }

  setElementSearchValue(searchValue: string): void {
    this.store.dispatch({ type: SignEditorActionEnum.UPDATE_ELEMENT_SEARCH_VALUE, props: { value: searchValue }});
  }

  setTextSearchValue(searchValue: string): void {
    this.store.dispatch({ type: SignEditorActionEnum.UPDATE_TEXT_SEARCH_VALUE, props: { value: searchValue }});
  }
}
