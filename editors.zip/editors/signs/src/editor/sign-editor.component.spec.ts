/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { SignService } from '@oksygen-sim-train-libraries/components-services/signs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { SignsEditorService } from '../services/signs-editor.service';
import { getSignTemplateSearchValue, getSignElementSearchValue, getSignTextSearchValue } from '../store/sign-editor.selectors';
import { SignEditorComponent } from './sign-editor.component';

describe('SignEditorComponent', () => {
  let component: SignEditorComponent;
  let fixture: ComponentFixture<SignEditorComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        providers: [
          { provide: SignService, useValue: {} },
          {
            provide: SignsEditorService,
            useValue: {
              initialiseEditing(): void {},
              pageOpening(): void {}
            }
          },
          provideMockStore({
            selectors: [
              { selector: getSignTemplateSearchValue, value: { templateSearchValue: null } },
              { selector: getSignElementSearchValue, value: { elementSearchValue: null } },
              { selector: getSignTextSearchValue, value: { textSearchValue: null } }
            ]
          })
        ],
        declarations: [SignEditorComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(SignEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
