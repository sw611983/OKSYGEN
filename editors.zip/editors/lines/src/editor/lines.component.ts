/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

import { RouteConfig, RoutingPage, SideNavService, TabService } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { Logging } from '@oksygen-common-libraries/pio';
import { AbstractEditorTabPage, EditorData, LinesEditorService } from '@oksygen-sim-train-libraries/components-services/editors';

export const LINES_CARD_DATA = new EditorData(
  t('Worlds'),
  '/editors/lines',
  OksygenIcon.LINE_EDITOR,
  'lines'
);

@Component({
  templateUrl: './lines.component.html',
  styleUrls: ['./lines.component.scss']
})
export class LinesEditorComponent extends AbstractEditorTabPage implements OnInit, OnDestroy {
  constructor(
    editorService: LinesEditorService,
    sideNavService: SideNavService,
    router: Router,
    tabService: TabService,
    logger: Logging,
    translateService: TranslateService
  ) {
    super(editorService, sideNavService, router, LINES_CARD_DATA, tabService, logger, translateService);
  }

  ngOnInit(): void {
    this.pageOpening();
  }

  ngOnDestroy(): void {
    this.pageClosing();
  }
}

// move this once we start implementation.
export const linesEditorPage: RoutingPage = {
  path: 'lines',
  component: LinesEditorComponent
};

export function linesEditorRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  return { path: linesEditorPage.path, component: linesEditorPage.component, canActivate: auth };
}
