/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable } from 'rxjs';

import { SignallingProject } from '../models/signalling-project.model';

export interface WorldProjectService {
  data$(): Observable<SignallingProject[]>;

  getValue(id: string): SignallingProject | undefined;

  refreshData(): void;
}
