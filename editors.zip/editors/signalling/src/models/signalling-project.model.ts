/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { CommonData } from '@oksygen-common-libraries/common';

export type SignallingProject = CommonData;
