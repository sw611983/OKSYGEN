/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { CommonModule, DecimalPipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { Route, RouterModule } from '@angular/router';

import { DataAccessWebService } from '@oksygen-common-libraries/data-access/web';
import { OksygenMaterialComponentsModule, RouteConfig, RoutingPage } from '@oksygen-common-libraries/material/components';
import { registrySchemaProvider } from '@oksygen-common-libraries/pio/registry';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';

import { TrainDetailsPanelComponent } from './browser/train-details-panel/train-details-panel.component';
import { TrainsBrowserComponent } from './browser/trains-browser.component';
import { TrainsDeleteDialogComponent } from './browser/trains-delete-dialog/trains-delete-dialog.component';
import { trainEditorSchema } from './models/train-editor-config.model';
import { TrainEditDataService } from './services/rest/train-edit-data.service';
import { TrainEditService } from './services/train-edit/train-edit.service';
import { TrainEditorContextManager } from './services/train-editor-context.manager';
import { TrainsBrowserService } from './services/trains-browser.service';
import { TrainEditorConsistDataService } from './services/trains/consist-data.service';
import { TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN, TRAIN_EDITOR_DATA_ACCESS_SERVICE_TOKEN } from './tokens/train-editor.token';
// eslint-disable-next-line max-len
import { TrainEditorConfigurationItemSetComponent } from './train-editor/train-editor-configuration/train-editor-configuration-item-set/train-editor-configuration-item-set.component';
import {
  TrainEditorConfigurationItemComponent
  // eslint-disable-next-line max-len
} from './train-editor/train-editor-configuration/train-editor-configuration-item-set/train-editor-configuration-item/train-editor-configuration-item.component';
import { TrainEditorConfigurationComponent } from './train-editor/train-editor-configuration/train-editor-configuration.component';
import { TrainEditorDetailPanelComponent } from './train-editor/train-editor-detail-panel/train-editor-detail-panel.component';
import { TrainEditorListPanelItemComponent } from './train-editor/train-editor-list-panel/train-editor-list-panel-item/train-editor-list-panel-item.component';
import { TrainEditorListPanelComponent } from './train-editor/train-editor-list-panel/train-editor-list-panel.component';
import { TrainEditorTopToolbarComponent } from './train-editor/train-editor-top-toolbar/train-editor-top-toolbar.component';
import { TrainEditorComponent } from './train-editor/train-editor.component';

import { LoadingGraphComponent } from './train-editor/loading-graph/loading-graph.component';
import { BaseBarGraphComponent } from './common/graphs/base-bar-graph/base-bar-graph.component';
import { VehicleConfigurationComponent } from './train-editor/train-editor-detail-panel/vehicle-configuration/vehicle-configuration.component';
// eslint-disable-next-line max-len
import { LodingConfigurationComponent } from './train-editor/train-editor-detail-panel/vehicle-configuration/loding-configuration/loding-configuration.component';
import { OksygenSimCoreUnitsModule, UnitsToPipe, UnitsUnitPipe } from '@oksygen-sim-core-libraries/components-services/measurement-units';

export const trainsBrowserPage: RoutingPage = {
  path: 'trains',
  component: TrainsBrowserComponent
};

export function trainsBrowserRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  return { path: trainsBrowserPage.path, component: trainsBrowserPage.component, canActivate: auth };
}

export const trainEditorPage: RoutingPage = {
  path: 'trains/:id',
  component: TrainEditorComponent
};

export function trainEditorRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  return { path: trainEditorPage.path, component: trainEditorPage.component, canActivate: auth };
}

const components = [
  TrainsBrowserComponent,
  TrainDetailsPanelComponent,
  TrainEditorComponent,
  TrainEditorTopToolbarComponent,
  TrainEditorDetailPanelComponent,
  TrainEditorListPanelComponent,
  TrainEditorListPanelItemComponent,
  TrainEditorConfigurationComponent,
  TrainEditorConfigurationItemSetComponent,
  TrainEditorConfigurationItemComponent,
  TrainsDeleteDialogComponent,
  VehicleConfigurationComponent,
  LoadingGraphComponent,
  BaseBarGraphComponent,
  LodingConfigurationComponent
];

@NgModule({
  declarations: components,
  exports: components,
  providers: [
    UnitsToPipe,
    UnitsUnitPipe,
    DecimalPipe,
    DataAccessWebService, // This is NOT how we would normally do this, but the two data services below don't use the current default BaseX Data Access service
    {
      provide: TRAIN_EDITOR_DATA_ACCESS_SERVICE_TOKEN,
      useExisting: DataAccessWebService
    },
    TrainEditorConsistDataService,
    {
      provide: TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN,
      useExisting: TrainEditorConsistDataService
    },
    TrainEditDataService,
    TrainEditService,
    TrainsBrowserService,
    TrainEditorContextManager,
    registrySchemaProvider(trainEditorSchema)
  ],
  imports: [RouterModule, CommonModule, OksygenMaterialComponentsModule, OksygenSimTrainCommonModule, OksygenSimTrainEditorsModule, OksygenSimCoreUnitsModule]
})
export class OksygenSimTrainTrainEditModule {}
