/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { InjectionToken } from '@angular/core';

import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';

export const TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN = new InjectionToken<ConsistDataService>('Train Editor Consist Data Service');
export const TRAIN_EDITOR_DATA_ACCESS_SERVICE_TOKEN = new InjectionToken<ConsistDataService>('Train Editor Data Access Service');
