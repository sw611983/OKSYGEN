import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseBarGraphComponent } from './base-bar-graph.component';

describe('BaseBarGraphComponent', () => {
  let component: BaseBarGraphComponent;
  let fixture: ComponentFixture<BaseBarGraphComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BaseBarGraphComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BaseBarGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
