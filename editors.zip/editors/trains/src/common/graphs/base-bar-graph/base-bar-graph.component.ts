/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, OnInit, ViewChild, Input, ElementRef, AfterViewInit, OnDestroy, EventEmitter, Output } from '@angular/core';
import * as d3 from 'd3';
import { BehaviorSubject, Subscription } from 'rxjs';
import { BarData, ChartConfiguration, Configs } from '../../../models/histogram.model';
import { BaseGraphComponent, Margin } from '../base-graph/base-graph.component';
import { UnitsToPipe, UnitsUnitPipe } from '@oksygen-sim-core-libraries/components-services/measurement-units';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'oksygen-base-bar-graph',
  templateUrl: './base-bar-graph.component.html',
  styleUrl: './base-bar-graph.component.scss'
})
export class BaseBarGraphComponent extends BaseGraphComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly unitFormatAccessor = ['load', 'long'];
  @ViewChild('chart', { static: true }) private chartContainer: ElementRef;
  @Input() public data: BarData[];
  @Input() public path$!: BehaviorSubject<BarData[]>;
  @Input() public chartId: string;
  @Input() public chartConfiguration: ChartConfiguration;
  @Input() public configs: Configs;
  @Input() public override margin: Margin;
  @Output('zoom') readonly zoomEvent = new EventEmitter<d3.D3ZoomEvent<SVGSVGElement, unknown>>();
  private subscription: Subscription;

  private chart: d3.Selection<SVGGElement, unknown, null, unknown>;
  private xScale: d3.ScaleBand<string>;
  private yScale: d3.ScaleLinear<number, number, never>;
  private xAxis: d3.Selection<SVGGElement, unknown, null, unknown>;
  private yAxis: d3.Selection<SVGGElement, unknown, null, unknown>;
  private gradBars: d3.Selection<SVGClipPathElement, unknown, null, unknown>;
  private yDomain: [number, any];
  private yUnit = '';
  private yUnitLabel: d3.Selection<SVGTextElement, unknown, null, any>;
  private tooltip: d3.Selection<HTMLDivElement, unknown, HTMLElement, any>;

  constructor(private unitsTo: UnitsToPipe, private unitsUnit: UnitsUnitPipe, private decimal: DecimalPipe) {
    super();
  }

  ngOnInit(): void {
    this.subscription = this.path$.subscribe(data => {
      if (data !== undefined) {
        this.yUnit = this.configs?.unit;
        this.data = data;
        if (this.chart && this.data?.length > 0) {
          this.updateChart();
        }
      }
    });
    this.zoomDomain = this.chartConfiguration.zoomDomain;
  }

  ngAfterViewInit(): void {
    this.createChart();
    if (this.data.length > 0) {
      this.updateChart();
    }
  }

  override ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private createChart(): void {
    this.createBaseGraphElements(this.chartContainer);

    // define X & Y domains
    const xDomain = this.data.map(d => d.name);
    this.yDomain = [this.configs.min, this.configs.max];

    // create scales
    this.xScale = d3
      .scaleBand<string>()
      .domain(xDomain)
      .range([0, this.contentWidth])
      .round(false)
      .paddingInner(this.chartConfiguration.barsPadding)
      .paddingOuter(0.1);

    this.yScale = d3.scaleLinear().domain(this.yDomain).range([this.contentHeight, 0]);

    // chart plot area
    this.chart = this.svg
      .append('g')
      .attr('class', 'bars' + this.chartId)
      .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`);

    // bar color gradient
    const bgGradient = this.chart
      .append('linearGradient')
      .attr('id', 'bg-gradient' + this.chartId)
      .attr('gradientTransform', 'rotate(90)');

    bgGradient.append('stop').attr('stop-color', this.chartConfiguration.gradientColorLower).attr('offset', '0%');

    bgGradient.append('stop').attr('stop-color', this.chartConfiguration.gradientColorUpper).attr('offset', '100%');

    this.gradBars = this.chart
      .append('clipPath')
      .attr('class', 'clipped' + this.chartId)
      .attr('id', 'clip-bar-rects' + this.chartId);

    //Add gradient color on bars
    const clipPath = this.chart.append('g').attr('clip-path', 'url(#clip-bar-rects' + this.chartId + ')');

    clipPath
      .append('rect')
      .attr('x', 0)
      .attr('y', 0)
      .attr('width', this.contentWidth)
      .attr('height', this.contentHeight)
      .style('fill', 'url(#bg-gradient' + this.chartId + ')');

    // x & y axis
    if (this.chartConfiguration.displayXAxis) {
      this.xAxis = this.svg
        .append('g')
        .attr('class', 'axis axis-x' + this.chartId)
        .attr('transform', `translate(${this.margin.left}, ${this.margin.top + this.yScale(0)})`)
        .call(d3.axisBottom(this.xScale).tickValues([]).tickSize(0))
        .style('pointer-events', 'none');
    }

    if (this.chartConfiguration.displayYAxis) {
      this.yAxis = this.svg
        .append('g')
        .attr('class', 'axis axis-y' + this.chartId)
        .attr('transform', `translate(${this.contentWidth + this.margin.left}, ${this.margin.top})`)
        .call(d3.axisRight(this.yScale))
        .style('pointer-events', 'none');
    }

    // text label for the y-axis
    if (this.chartConfiguration.displayYUnitLabel) {
      this.yUnitLabel = this.svg
        .append('text')
        .attr('transform', 'rotate(-90)')
        .attr('y', this.contentWidth + 40)
        .attr('x', 0 - this.contentHeight / 2)
        .attr('dy', '1em')
        .style('text-anchor', 'middle')
        .text(this.yUnit)
        .style('pointer-events', 'none');
    }

    // To hide elements beyond chart area
    this.chart
      .append('clipPath')
      .attr('id', 'clip' + this.chartId)
      .append('rect')
      .attr('width', this.contentWidth)
      .attr('height', this.contentHeight);

    this.gradBars.attr('clip-path', 'url(#clip' + this.chartId + ')');
    if (this.chartConfiguration.displayXAxis) {
      this.xAxis.attr('clip-path', 'url(#clip' + this.chartId + ')');
    }
    if (this.chartConfiguration.isZoomable) {
      this.initialiseZoom();
    }

    // Add tooltip
    this.tooltip = d3
      .select('.' + this.chartConfiguration.tooltipClassName)
      .append('div')
      .style('position', 'absolute')
      .style('z-index', '1')
      .style('width', 'auto')
      .style('height', 'auto')
      .style('padding', '5px 10px 5px 10px')
      .style('margin-right', '55px')
      .style('border-radius', '5px')
      .style('background-color', '#424242')
      .style('fill-opacity', '0.5')
      .style('color', 'white')
      .style('pointer-events', 'none')
      .style('opacity', 0);
  }

  /**
   * Method to add zoom fnctionality
   */
  override initialiseZoom(): void {
    this.zoom = d3
      .zoom()
      .scaleExtent(this.zoomDomain)
      .translateExtent([
        [this.margin.left, -Infinity],
        [this.contentWidth, Infinity]
      ])
      .extent([
        [this.margin.left, 0],
        [this.contentWidth, this.contentHeight]
      ])
      .on('zoom', this.onZoom.bind(this));

    this.zoomRect = this.svg
      .append('rect')
      .attr('id', 'zoomRect' + this.chartId)
      .attr('x', this.margin.left)
      .attr('y', this.margin.top)
      .attr('width', this.contentWidth)
      .attr('height', this.contentHeight)
      .style('pointer-events', 'none');
    this.svg.call(this.zoom);
  }

  /**
   * Method to resize elements on zoom
   */
  onZoom(event: d3.D3ZoomEvent<SVGSVGElement, unknown>): void {
    this.xScale.range([this.margin.left, this.contentWidth].map(d => event.transform.applyX(d)));

    this.svg
      .selectAll<SVGRectElement, BarData>('.clipped' + this.chartId + ' rect')
      .attr('x', (d: BarData) => this.xScale(d.name))
      .attr('width', this.xScale.bandwidth());

    this.svg
      .selectAll<SVGRectElement, BarData>('.hiddenBar' + this.chartId)
      .attr('x', (d: BarData) => this.xScale(d.name))
      .attr('width', this.xScale.bandwidth());

    this.zoomEvent.emit(event);
  }

  /**
   * Method to update bar values when data changes
   */
  private updateChart(): void {
    this.yDomain = [this.configs.min, this.configs.max];
    // update scales & axis
    this.xScale.domain(this.data.map(d => d.name));
    this.yScale.domain(this.yDomain);
    if (this.chartConfiguration.displayXAxis) {
      this.xAxis
        .transition()
        .call(d3.axisBottom(this.xScale).tickValues([]).tickSize(0))
        .attr('transform', `translate(${this.margin.left}, ${this.margin.top + this.yScale(0)})`);
    }
    if (this.chartConfiguration.displayYAxis) {
      this.yAxis.transition().call(d3.axisRight(this.yScale));
    }
    if (this.chartConfiguration.displayYUnitLabel) {
      this.yUnitLabel.text(this.yUnit);
    }
    // Select all visible bars
    const bars = this.gradBars.selectAll<SVGRectElement, BarData>('.bar' + this.chartId).data(this.data);
    // Select all invisible bars
    const hiddenBars = this.chart.selectAll('.hiddenBar' + this.chartId).data(this.data);

    // remove exiting bars
    bars.exit().remove();
    hiddenBars.exit().remove();

    // update exisitng visible bars
    this.gradBars
      .selectAll<SVGRectElement, BarData>('.bar' + this.chartId)
      .attr('x', (d: BarData) => this.xScale(d.name))
      .attr('y', (d: BarData) => this.yScale(Math.max(0, d.value)))
      .attr('width', d => this.xScale.bandwidth())
      .attr('height', (d: BarData) => Math.abs(this.yScale(d.value) - this.yScale(0)));

    // update exisitng invisible bars
    this.chart
      .selectAll<SVGRectElement, BarData>('.hiddenBar' + this.chartId)
      .attr('x', (d: BarData) => this.xScale(d.name))
      .attr('y', (d: BarData) => this.yScale(Math.max(0, d.value)))
      .attr('width', d => this.xScale.bandwidth())
      .attr('height', (d: BarData) => Math.abs(this.yScale(d.value) - this.yScale(0)))
      .style('fill-opacity', '0')
      .on('mouseenter', (event, d: BarData) => this.displayTooltip(event, d))
      .on('mouseleave', () => this.tooltip.style('opacity', 0));

    // Add new visible bars
    bars
      .enter()
      .append('rect')
      .attr('class', 'bar' + this.chartId)
      .attr('x', d => this.xScale(d.name))
      .attr('y', d => this.yScale(Math.max(0, d.value)))
      .attr('width', this.xScale.bandwidth())
      .attr('height', d => Math.abs(this.yScale(d.value) - this.yScale(0)));

    // Add new invisible bars
    hiddenBars
      .enter()
      .append('rect')
      .attr('class', 'hiddenBar' + this.chartId)
      .attr('x', d => this.xScale(d.name))
      .attr('y', d => this.yScale(Math.max(0, d.value)))
      .attr('width', this.xScale.bandwidth())
      .attr('height', d => Math.abs(this.yScale(d.value) - this.yScale(0)))
      .style('fill-opacity', '0')
      .on('mouseenter', (event, d) => this.displayTooltip(event, d))
      .on('mouseleave', () => this.tooltip.style('opacity', 0));
  }

  /**
   * Method to display tooltip on mouse event
   *
   * @param event mouse event data
   * @param d bar datum
   */
  private displayTooltip(event: any, d: any): void {
    const vehicleNumber = d?.name;
    const vehicleDisplay = Math.floor(Number(vehicleNumber) + 1);
    const convertedValue = this.unitsTo.transform(d.value, 'weight', 'kg', 't');
    const formattedValue = this.decimal.transform(convertedValue, '1.0-2');
    const unit = this.unitsUnit.transform(convertedValue, 'weight', this.unitFormatAccessor)?.displayShort;
    this.tooltip
      .style('opacity', 0.9)
      .style('left', event.x + 'px')
      .style('top', event.y - 50 + 'px');

    // Tooltip data
    this.tooltip.html(`${vehicleDisplay} | ${formattedValue} ${unit}`);
  }

  rerender(transitionDuration: number): void {
    // Not required
    this.g.selectAll('.bar').remove();

    // Create X and Y scales based on data
    const xScale = d3
      .scaleBand()
      .domain(this.data.map(d => d.name))
      .range([0, this.contentWidth])
      .padding(0.1);

    const yScale = d3
      .scaleLinear()
      .domain([0, d3.max(this.data, d => d.value)])
      .range([this.contentHeight, 0]);

    // Add bars
    this.g
      .selectAll<SVGRectElement, BarData>('.bar')
      .data(this.data)
      .enter()
      .append('rect')
      .attr('class', 'bar')
      .attr('x', d => xScale(d.name))
      .attr('y', this.contentHeight)
      .attr('width', xScale.bandwidth())
      .attr('height', 0)
      .transition()
      .duration(transitionDuration)
      .attr('y', d => yScale(d.value))
      .attr('height', d => this.contentHeight - yScale(d.value));
  }

  protected setMargin(): Margin {
    return {
      top: this.margin.top,
      right: this.margin.right,
      bottom: this.margin.bottom,
      left: this.margin.left
    };
  }
}
