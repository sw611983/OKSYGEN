/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import * as d3 from 'd3';
import { Component, ElementRef, Input, OnDestroy } from '@angular/core';
import { Subscription, fromEvent } from 'rxjs';
import { throttleTime } from 'rxjs/operators';

/**
 * A data point in the context of a graph has an x and y value (optionally z, if you're doing some fancy stuff)
 */
export interface DataPoint {
  x: number;
  y: number;
  z?: number;
}

/**
 * Essentially like a CSS margin - space around the edges.
 */
export interface Margin {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

@Component({
  template: '<strong>Do not use BaseGraphComponent directly!</strong>'
})
export abstract class BaseGraphComponent implements OnDestroy {

  @Input() zoomDomain: [number, number];
  /** the root for the d3 graphing instantiation */
  protected svg: d3.Selection<any, unknown, any, unknown>;
  /** this holds our path and both axis */
  protected g: d3.Selection<any, unknown, any, unknown>;

  /** this is NOT the margin around this component - it's the margin around the content area of the graph. */
  protected margin: Margin;
  protected contentWidth: number;
  protected contentHeight: number;
  protected width: number;
  protected height: number;
  /** this is effectively the d3 way of saying "overflow: auto" so cropped path doesn't render over the axis */
  protected clip: d3.Selection<d3.BaseType, unknown, any, unknown>;
  /** this rect handles touch events, so we can interact with the graph (mostly for zoom and pan) */
  zoomRect: d3.Selection<any, unknown, any, unknown>;
  /** this is our zoom transform */
  zoom: d3.ZoomBehavior<Element, unknown>;
  resizeSubscription: Subscription;

  ngOnDestroy(): void {
    this.resizeSubscription?.unsubscribe();
  }

  /**
   * This selects our base SVG container and creates a child "g" to use as our graph container, as well as setting up zoom.
   */
  createBaseGraphElements(baseSvg: ElementRef): void {
    const element = baseSvg.nativeElement;
    this.svg = d3.select(element)
      .attr('viewBox', `0 0 ${this.width} ${this.height}`)
      .attr('preserveAspectRatio', 'xMinYMid');
    this.margin = this.setMargin();

    this.width = parseInt(this.svg.style('width'), 10) || 800;
    this.height = parseInt(this.svg.style('height'), 10) || 400;

    this.contentWidth = this.width - this.margin.left - this.margin.right;
    this.contentHeight = this.height - this.margin.top - this.margin.bottom;

    this.g = this.svg.append('g')
      .attr('transform', `translate(${this.margin.left},${this.margin.top})`)
      .attr('viewBox', `0 0 ${this.contentWidth} ${this.contentHeight}`)
      .attr('preserveAspectRatio', 'xMinYMid');
  }

  /**
   * Initialises the zooming & panning features for this graph.
   */
  initialiseZoom(): void {
    this.zoom = d3.zoom()
      .scaleExtent([this.zoomDomain[0], this.zoomDomain[1]]) // this allows zooming into 500m ticks (default is about 10km)
      .extent([[this.margin.left, 0], [this.contentWidth, this.contentHeight]]) // viewport for zoom behavior (top left to bot right)
      .translateExtent([[this.margin.left, -Infinity], [this.contentWidth, Infinity]]) // only set x as no vertical panning
      .on('zoom', this.onZoom.bind(this)); // using bind as need to maintain "this" context
    this.zoomRect = this.svg.append('rect')
      .attr('id', 'zoomRect')
      .attr('x', this.margin.left)
      .attr('y', this.margin.top)
      .attr('width', this.contentWidth)
      .attr('height', this.contentHeight);
    this.zoomRect.call(
      this.zoom
    );
  }

  /**
   * Initialise our resizing for this component. Calls onResize().
   * @param every in ms, how often to fire the resize event.
   */
  initialiseResize(every = 500): void {
    this.resizeSubscription = fromEvent(window, 'resize')
    .pipe(
      throttleTime(every, undefined, {leading: true, trailing: true})
    )
    .subscribe(event => {
      this.onResize();
    });
  }

  /**
   * By default, on resize we simply call rerender(100).
   */
  protected onResize(): void {
    this.rerender(100);
  }

  /**
   * implement this to rerender your data. For example, when the data is updated you need to recalculate your axis & redraw the path
   * @param transitionDuration how long (in ms) to animate this redraw over
   * */
  abstract rerender(transitionDuration: number): void;
  /** implmement this to handle zoom & pan events */
  protected abstract onZoom(event: d3.D3ZoomEvent<any, any>): void;
  /** implement this to set the margin's of the base graph element on initialisation */
  protected abstract setMargin(): Margin;
}
