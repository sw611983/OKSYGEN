/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainEditorComponent } from './train-editor.component';

describe('TrainEditorComponent', () => {
  let component: TrainEditorComponent;
  let fixture: ComponentFixture<TrainEditorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainEditorComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
