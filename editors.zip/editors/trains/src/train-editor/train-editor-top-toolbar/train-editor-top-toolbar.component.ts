/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'oksygen-train-editor-top-toolbar',
  templateUrl: './train-editor-top-toolbar.component.html',
  styleUrls: ['./train-editor-top-toolbar.component.scss']
})
export class TrainEditorTopToolbarComponent {

  @Input() version: number;
  @Input() disableSave: boolean;
  @Input() canUndo$: Observable<boolean>;
  @Input() canRedo$: Observable<boolean>;

  @Output() readonly save = new EventEmitter();
  @Output() readonly undo = new EventEmitter();
  @Output() readonly redo = new EventEmitter();

  constructor() { }

}
