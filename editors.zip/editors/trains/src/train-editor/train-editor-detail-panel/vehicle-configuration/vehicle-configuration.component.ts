/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, input, output } from '@angular/core';
import { every, groupBy, map } from 'lodash';
import { EditorCarClass, EditorConsistVehicle } from '../../../models/train-editor.model';

@Component({
  selector: 'oksygen-vehicle-configuration',
  templateUrl: './vehicle-configuration.component.html',
  styleUrl: './vehicle-configuration.component.scss'
})
export class VehicleConfigurationComponent {
  selectedVehicles = input.required<Array<EditorConsistVehicle>>();
  readonly updatedVehicles = output<Array<EditorConsistVehicle>>();

  selectedCarClasses: EditorCarClass[] = [];

  constructor() {
    effect(() => {
      const selectedVehicles = this.selectedVehicles();
      this.selectedCarClasses = map(
        groupBy(selectedVehicles, item => item.carClass.carClassId),
        (group, groupId) => {
          const firstValue = group[0].loading;
          const allSame = every(group, item => item.loading === firstValue);

          return {
            ...group[0].carClass,
            loading: allSame ? firstValue : 0
          };
        }
      );
    });
  }

  updateLoding(carClass: EditorCarClass): void {
    const updated = this.selectedVehicles().map(v => {
      if (v.carClass.carClassId === carClass.carClassId) {
        return { ...v, loading: carClass.loading };
      }
      return { ...v };
    });
    this.updatedVehicles.emit(updated);
  }
}
