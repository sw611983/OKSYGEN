/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, effect, input, OnDestroy, OnInit, output } from '@angular/core';
import { newOptionalNumericFormControl, quietUpdateOptions, UpdateOn } from '@oksygen-common-libraries/material/components';
import { Registry } from '@oksygen-common-libraries/pio';
// import { EditorCarClass } from '@oksygen-sim-train-libraries/components-services/editors/trains';
import { CarClassType, RailType } from '@oksygen-sim-train-libraries/components-services/trains';
import { isNil } from 'lodash';
import { debounceTime, Subscription } from 'rxjs';
import { EditorCarClass } from '../../../../models/train-editor.model';

@Component({
  selector: 'oksygen-loding-configuration',
  templateUrl: './loding-configuration.component.html',
  styleUrl: './loding-configuration.component.scss'
})
export class LodingConfigurationComponent implements OnInit, OnDestroy {
  readonly unitFormatAccessor = ['load', 'long'];
  readonly unitForPassenger = ['passengerLoad', 'long'];
  private readonly formDebounceTime = 750;

  carClass = input.required<EditorCarClass>();
  readonly modifiedCarClass = output<EditorCarClass>();

  resetValue: number;
  disableReset = true;

  loadingControl = newOptionalNumericFormControl(2, UpdateOn.CHANGE);
  percentageControl = newOptionalNumericFormControl(2, UpdateOn.CHANGE);

  private masterSubscription = new Subscription();

  icon: string;
  isPassengerType: boolean;
  isFreightType: boolean;
  isTramType: boolean;
  constructor(private registry: Registry) {
    effect(() => {
      const carClass = this.carClass();
      this.loadingControl.setValue(carClass.loading);
      this.updatePercentageValue(carClass.loading);
      if (this.isPassengerType) {
        this.icon = carClass.carType === CarClassType.MOTOR ? 'train' : 'railcar';
      } else if (this.isFreightType) {
        this.icon = carClass.carType === CarClassType.MOTOR ? 'locomotive' : 'wagon';
      } else if (this.isTramType) {
        this.icon = carClass.carType === CarClassType.MOTOR ? 'tram' : 'railcar';
      }
      this.disableReset = this.resetValue === carClass.loading;
    });
    const railType = this.registry.getString(['editor', 'train', 'railType'], 'Passenger');
    this.isPassengerType = railType === RailType.PASSENGER_TYPE;
    this.isFreightType = railType === RailType.FREIGHT_TYPE;
    this.isTramType = railType === RailType.TRAM_TYPE;
  }

  ngOnInit(): void {
    this.resetValue = this.carClass().loading;
    this.masterSubscription.add(
      this.loadingControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(value => {
        value = Number(value);
        if (!isNil(value) && this.carClass().loading !== value) {
          if (value > this.carClass().maxLoading) {
            value = this.carClass().maxLoading;
          }
          this.carClass().loading = value;
          this.modifiedCarClass.emit(this.carClass());
        }
      })
    );

    this.masterSubscription.add(
      this.percentageControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(value => {
        value = Number(value);
        let loading = parseFloat(((value / 100) * this.carClass().maxLoading).toFixed(2));
        if (!isNil(value) && !isNaN(value) && this.carClass().loading !== loading) {
          if (loading > this.carClass().maxLoading) {
            loading = this.carClass().maxLoading;
          }
          this.carClass().loading = loading;
          this.modifiedCarClass.emit(this.carClass());
        }
      })
    );
  }

  private updatePercentageValue(loading: number): void {
    const percentage = (loading / this.carClass().maxLoading) * 100;
    this.percentageControl.setValue(percentage, quietUpdateOptions);
  }

  reset(): void {
    this.loadingControl.setValue(this.resetValue);
  }

  ngOnDestroy(): void {
    this.masterSubscription.unsubscribe();
  }
}
