/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LodingConfigurationComponent } from './loding-configuration.component';

describe('LodingConfigurationComponent', () => {
  let component: LodingConfigurationComponent;
  let fixture: ComponentFixture<LodingConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LodingConfigurationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LodingConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
