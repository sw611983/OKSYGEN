/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, UntypedFormControl, ValidationErrors } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { BehaviorSubject, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { filterTruthy, SelfCompletingObservable } from '@oksygen-common-libraries/common';
import {
  AutocompleteInputType,
  DynamicComponent,
  errorStateMatcher,
  illegalNameCharacterExists,
  InputError,
  newFormControl,
  UpdateOn,
  validateMandatoryString,
  validateUniqueString
} from '@oksygen-common-libraries/material/components';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { ConfirmResult, yesNoDialog } from '@oksygen-sim-train-libraries/components-services/common';

import { EditorConsistVehicle, EditorTrain, TrainEditorConfigurationData, TrainEditorDetailPanelData } from '../../models/train-editor.model';

// verbose way of providing strongly typed forms, could be made generic
// source: https://indepth.dev/posts/1198/angular-forms-story-strong-types
interface TrainForm {
  name: string;
  trainType: string;
}
type TrainControls = { [key in keyof TrainForm]: FormControl };
type TrainFormGroup = FormGroup & { value: TrainForm; controls: TrainControls };

@Component({
  selector: 'oksygen-train-editor-detail-panel',
  templateUrl: './train-editor-detail-panel.component.html',
  styleUrls: ['./train-editor-detail-panel.component.scss']
})
export class TrainEditorDetailPanelComponent extends DynamicComponent<TrainEditorDetailPanelData, any> implements OnInit, OnDestroy {
  trainFormGroup: TrainFormGroup;
  selectedVehicles: EditorConsistVehicle[] = [];
  /** stored reference for the HTML, only train type needed as it's an autocomplete */
  trainTypeControl: FormControl;

  trainTypeInputControl: UntypedFormControl; // for value validation

  // properties for the train selection
  autocompleteInputType = AutocompleteInputType.FORM_FIELD;
  trainTypeControlErrors: InputError[] = [{ type: 'missing', text: t('A train type is required.') }];
  public TrainEditorConfigurationData: TrainEditorConfigurationData;
  private subscription = new Subscription();
  private trainVehicles$ = new BehaviorSubject<EditorConsistVehicle[]>(null);
  private train: EditorTrain;

  matcher = errorStateMatcher;

  existingTrainNames: string[] = [];

  originalName: string;

  constructor(private dialog: MatDialog, private translateService: TranslateService) {
    super();
  }

  ngOnInit(): void {
    this.trainFormGroup = this.createTrainForm();
    this.listenToTrainUpdates();
    const trainFormGroupSub = this.trainFormGroup.statusChanges.pipe(map(status => status === 'INVALID')).subscribe(this.data.disableSave);
    this.subscription.add(trainFormGroupSub);
    this.trainTypeInputControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => validateMandatoryString(control.value));
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  echo(o: any): any {
    return o; // used to render trains by autocomplete in HTML
  }

  selectTrainType(trainType: string): void {
    this.trainTypeControl.setValue(trainType);
  }

  // pre-clear check for train auto complete
  // arrow function allows it to retain context
  onTrainClear = (consistName: string): SelfCompletingObservable<boolean> =>
    yesNoDialog(
      t('Train type in use'),
      t('This train type has vehicles in use against it - clearing it will clear them as well. Do you wish to proceed?'),
      this.translateService,
      this.dialog,
      t('Clear')
    ).pipe(map(result => (result === ConfirmResult.SAVE ? true : false)));

  private createTrainForm(): TrainFormGroup {
    const nameControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => this.validateTrainName(control.value));
    const trainTypeControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;
      if (!control.value || control.value?.length === 0) {
        result = { missing: true };
      }
      return result;
    });
    const trainFormGroup = new FormGroup({
      name: nameControl,
      trainType: trainTypeControl
    } as TrainControls) as TrainFormGroup;
    this.trainTypeControl = trainTypeControl; // needs it's own reference as it's an autocomplete
    if (this.data?.nameUpdate) {
      const nameSub = nameControl.valueChanges.subscribe(this.data.nameUpdate);
      this.subscription.add(nameSub);
    }
    if (this.data?.trainTypeUpdate) {
      const trainTypeSub = trainTypeControl.valueChanges.subscribe(this.data.trainTypeUpdate);
      this.subscription.add(trainTypeSub);
    }
    if (this.data?.trainConfigurationUpdated) {
      const trainConfigurationUpdatedSub = this.trainVehicles$.subscribe(this.data.trainConfigurationUpdated);
      this.subscription.add(trainConfigurationUpdatedSub);
    }
    return trainFormGroup;
  }

  private listenToTrainUpdates(): void {
    const trainSub = this.data?.train$.pipe(filterTruthy()).subscribe(train => {
      this.train = train;
      this.processTrainUpdate(train);
      this.selectedVehicles = train.vehicles.filter(vehicle => vehicle.selected);
    });
    this.subscription.add(trainSub);
    const existingTrainNamesSub = this.data?.otherTrainNames$.pipe(filterTruthy()).subscribe(existingTrainNames => {
      this.existingTrainNames = existingTrainNames;
    });
    this.subscription.add(existingTrainNamesSub);
    const savedTrainNameSub = this.data?.savedTrainName$.pipe(filterTruthy()).subscribe(savedTrainName => {
      this.originalName = savedTrainName;
    });
    this.subscription.add(savedTrainNameSub);
  }

  private processTrainUpdate(train: EditorTrain): void {
    const opts = { emitEvent: false, onlySelf: true };
    this.trainFormGroup.get('name').setValue(train.name, opts);
    if (train?.trainType?.name) {
      this.trainFormGroup.get('trainType').setValue(train.trainType?.name, opts);
    }
  }

  private validateTrainName(name: string): ValidationErrors {
    let result: ValidationErrors = null;
    if (name) {
      const nameInUse = validateUniqueString(name, this.existingTrainNames, this.originalName);
      if (nameInUse) {
        result = nameInUse;
      } else if (name?.trim() !== name) {
        result = { spacesError: true };
      } else if (illegalNameCharacterExists(name)) {
        result = { specialCharacterError: true };
      }
    } else {
      result = { missing: true };
    }

    return result;
  }

  updateLoading(updatedVehicles: EditorConsistVehicle[]): void {
    const trainVehicles = this.train?.vehicles?.map(vehicle => {
      const updated = updatedVehicles.find(v => v.position === vehicle.position);
      return updated ? { ...vehicle, loading: updated.loading } : vehicle;
    });
    this.trainVehicles$.next(trainVehicles);
  }
}
