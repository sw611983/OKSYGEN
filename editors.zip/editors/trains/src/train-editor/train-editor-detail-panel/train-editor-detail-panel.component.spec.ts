/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainEditorDetailPanelComponent } from './train-editor-detail-panel.component';

describe('TrainEditorDetailPanelComponent', () => {
  let component: TrainEditorDetailPanelComponent;
  let fixture: ComponentFixture<TrainEditorDetailPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainEditorDetailPanelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainEditorDetailPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
