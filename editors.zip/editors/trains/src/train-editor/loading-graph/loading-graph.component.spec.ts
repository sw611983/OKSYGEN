import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadingGraphComponent } from './loading-graph.component';

describe('LoadingGraphComponent', () => {
  let component: LoadingGraphComponent;
  let fixture: ComponentFixture<LoadingGraphComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LoadingGraphComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoadingGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
