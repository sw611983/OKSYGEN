/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Input } from '@angular/core';
import { Margin } from '../../common/graphs/base-graph/base-graph.component';
import { BehaviorSubject } from 'rxjs';
import { BarData, ChartConfiguration, Configs } from '../../models/histogram.model';

@Component({
  selector: 'oksygen-loading-graph',
  templateUrl: './loading-graph.component.html',
  styleUrl: './loading-graph.component.scss'
})
export class LoadingGraphComponent {
  @Input() public data: BarData[];
  @Input() public configs: Configs;
  @Input() public loadingGraphData$: BehaviorSubject<BarData[]>;
  public chartConfiguration: ChartConfiguration = {
    barsPadding: 0,
    gradientColorLower: '#FF833C',
    gradientColorUpper: '#FF833C',
    isZoomable: false,
    //Name of parent class to append tooltip
    tooltipClassName: 'train-configuration-panel',
    displayXAxis: true,
    displayYAxis: false,
    displayYUnitLabel: false
  };
  public margin: Margin = { top: 0, right: 0, bottom: 0, left: 0 };

  constructor() {}
}
