/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { enableDragHandling } from '@oksygen-common-libraries/common';
import { TrainVehicleData } from '../../../models/train-editor.model';

@Component({
  selector: 'oksygen-train-editor-list-panel-item',
  templateUrl: './train-editor-list-panel-item.component.html',
  styleUrls: ['./train-editor-list-panel-item.component.scss']
})
export class TrainEditorListPanelItemComponent implements OnInit {
  @Input() trainVehicleData: TrainVehicleData;
  constructor(private host: ElementRef) {}

  ngOnInit(): void {
    if(this.trainVehicleData.isDraggable){
      enableDragHandling(this.host, () => ({
        type: this.trainVehicleData.type,
        data: this.trainVehicleData
      }));
    }
  }
}
