/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserConfigurationModule } from '@oksygen-sim-train-libraries/components-services/user-configuration';

import { TrainEditorListPanelItemComponent } from './train-editor-list-panel-item.component';
import { OksygenSimTrainTrainEditModule } from '../../../trains-edit.module';

describe('TrainEditorListPanelItemComponent', () => {
  let component: TrainEditorListPanelItemComponent;
  let fixture: ComponentFixture<TrainEditorListPanelItemComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainTrainsModule, OksygenSimTrainTrainEditModule, OksygenSimTrainUserConfigurationModule],
      declarations: [TrainEditorListPanelItemComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainEditorListPanelItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
