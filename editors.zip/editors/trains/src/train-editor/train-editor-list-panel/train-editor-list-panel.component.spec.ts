/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainEditorListPanelComponent } from './train-editor-list-panel.component';

describe('TrainEditorListPanelComponent', () => {
  let component: TrainEditorListPanelComponent;
  let fixture: ComponentFixture<TrainEditorListPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainEditorListPanelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainEditorListPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
