/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  allFilterTypesMatch,
  DynamicComponent,
  Filter,
  filterMatches,
  SelectedFilterArray,
  Sorter,
  SorterPipe
} from '@oksygen-common-libraries/material/components';
import {
  TrainEditorFilterType, TrainEditorListPanelData, TrainEditorUiState, TrainVehicleData, TrainVehicleListDataType
} from '../../models/train-editor.model';
import { CarClassType, Consist, RailType, TrainType } from '@oksygen-sim-train-libraries/components-services/trains';
import { combineLatest, Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Registry } from '@oksygen-common-libraries/pio';

@Component({
  selector: 'oksygen-train-editor-list-panel',
  templateUrl: './train-editor-list-panel.component.html',
  styleUrls: ['./train-editor-list-panel.component.scss']
})
export class TrainEditorListPanelComponent extends DynamicComponent<TrainEditorListPanelData, any> implements OnInit, OnDestroy {
  noTrainType = true;

  sorter = new Sorter<TrainVehicleData>();
  state: TrainEditorUiState;
  filterGroups: { name: string; displayName: string }[] = [];
  motorCars: TrainVehicleData[] = [];
  trailerCars: TrainVehicleData[] = [];
  trains: TrainVehicleData[] = [];
  filteredMotorCars: TrainVehicleData[] = [];
  filteredTrailerCars: TrainVehicleData[] = [];
  filteredTrains: TrainVehicleData[] = [];
  trainType: TrainType;
  isPassengerType: boolean;
  isFreightType: boolean;
  isTramType: boolean;

  private sorterPipe = new SorterPipe();
  private subscription = new Subscription();

  constructor(private registry: Registry) {
    super();
    this.sorter.sortFunction = (c, a, b): number => a?.name?.localeCompare(b?.name);
    const railType = this.registry.getString(['editor', 'train', 'railType'], 'Passenger');
    this.isPassengerType = railType === RailType.PASSENGER_TYPE;
    this.isFreightType = railType === RailType.FREIGHT_TYPE;
    this.isTramType = railType === RailType.TRAM_TYPE;
  }

  textToFilter = (text: string): Filter<string> => new Filter(TrainEditorFilterType.CAR_CLASS, text);

  ngOnInit(): void {
    if (!this.data) {
      return;
    }
    const stateSub = this.data.uiState$
      .pipe(
        tap(uiState => {
          this.state = uiState;
        })
      )
      .subscribe();
    this.subscription.add(stateSub);

    const sub = combineLatest([this.data.trainType$, this.data.trains$])
      .pipe(
        tap(([trainType, trains]) => {
          if (!trainType) {
            this.noTrainType = true;
            return;
          }
          this.noTrainType = false;
          this.trainType = trainType;
          this.processUpdates(trainType, trains);
        })
      )
      .subscribe();
    this.subscription.add(sub);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onCurrentValueUpdate(search: string): void {
    this.state.filters.search = search;

    // Note that when the user hits enter in the text box there is a moment where
    // there is no text in the box but the chip hasn't been created yet.
    // Filtering at this time may result in a glitchy looking update.
    // The following delays the refiltering to avoid this.
    // FIXME The common component should suppress the string updates in this situation
    // (at least until its internal state has become consistant).
    this.updateFiltersLater();
  }

  updateFiltersLater(): void {
    // wait for the selectedFilters to hopefully update before applying the filters
    setTimeout(() => this.applyFilters(), 250);
  }

  applyFilters(): void {
    this.filteredMotorCars = this.applyFilterTo(this.motorCars);
    this.filteredTrailerCars = this.applyFilterTo(this.trailerCars);
    this.filteredTrains = this.applyFilterTo(this.trains);
  }

  clearFilters(): void {
    this.state.filters.groups = [];
    this.state.filters.search = '';
    this.state.filters.selectedFilters = new SelectedFilterArray<TrainEditorFilterType>();
    this.applyFilters();
  }

  sortToggled(): void {
    this.applyFilters();
  }

  /**
   * Adds the given filter to the selected filters, removing any other filters of the same type.
   */
  setUniqueFilterType(filter: Filter<TrainEditorFilterType>): void {
    if (filter) {
      this.state.filters.selectedFilters.replace(filter.type, filter);
      this.applyFilters();
    }
  }

  filterByTypeGroup(typeGroup: { name: string; displayName: string }): void {
    if (!!typeGroup?.name && typeGroup?.name?.length > 0) {
      this.setUniqueFilterType(new Filter(TrainEditorFilterType.GROUP, typeGroup.name));
    }
  }

  /**
   * Helper method for applyFilters() as it needs to execute this logic on train & vehicle properties.
   *
   * @param list list of sim properties to filter on.
   */
  private applyFilterTo(list: TrainVehicleData[]): TrainVehicleData[] {
    if (!list) {
      return [];
    }

    let filteredList = list.filter(prop => {
      const names = [prop.name];

      if (!allFilterTypesMatch([{ t: TrainEditorFilterType.CAR_CLASS, v: names }], this.state.filters.selectedFilters)) {
        return false;
      }

      if (!filterMatches(names, this.state.filters.search)) {
        return false;
      }
      return true;
    });

    filteredList = this.sorterPipe.transform(filteredList, this.sorter, this.sorter.refresh);
    return filteredList;
  }

  private processUpdates(trainType: TrainType, trains: Consist[]): void {
    this.motorCars = [];
    this.trailerCars = [];
    trainType.carClasses.forEach(cc => {
      if (cc.carType === CarClassType.MOTOR) {
        this.motorCars.push({ name: cc.description, type: TrainVehicleListDataType.CarClass, carClass: cc, isDraggable: trainType.editable });
      } else {
        this.trailerCars.push({ name: cc.description, type: TrainVehicleListDataType.CarClass, carClass: cc, isDraggable: trainType.editable });
      }
    });
    this.trains = [];
    trains.forEach(train => {
      this.trains.push({ name: train.name, type: TrainVehicleListDataType.Train, train, isDraggable: true });
    });
    this.applyFilters();
  }
}
