/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  HostListener,
  isSignal,
  OnDestroy,
  ViewChild,
  ViewContainerRef
} from '@angular/core';
import { ActivatedRoute, Data } from '@angular/router';
import { combineLatest, Observable, of } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { TabService } from '@oksygen-common-libraries/material/components';
import { ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';
import { BaseEditorComponent } from '@oksygen-sim-train-libraries/components-services/editors';
import { CarClass } from '@oksygen-sim-train-libraries/components-services/trains';

import {
  EditorConsistVehicle,
  EditorTrain,
  isTrainEditorConfig,
  TrainEditorConfig,
  TrainEditorConfigurationData,
  TrainEditorDetailPanelData,
  TrainEditorListPanelData,
  TrainEditorUiState,
  TRAINS_CARD_DATA
} from '../models/train-editor.model';
import { TrainEditManager } from '../services/train-edit/train-edit.manager';
import { TrainEditService } from '../services/train-edit/train-edit.service';
import { TrainEditorContext } from '../services/train-editor-context';
import { TrainEditorContextPublisher } from '../services/train-editor-context.publisher';
import { TrainEditorConfigurationComponent } from './train-editor-configuration/train-editor-configuration.component';
import { TrainEditorDetailPanelComponent } from './train-editor-detail-panel/train-editor-detail-panel.component';
import { TrainEditorListPanelComponent } from './train-editor-list-panel/train-editor-list-panel.component';
import { isNil } from 'lodash';

function defaultConfig(): TrainEditorConfig {
  return {
    listPanel: {
      component: TrainEditorListPanelComponent
    },
    trainConfigurationPanel: {
      component: TrainEditorConfigurationComponent
    },
    detailsPanel: {
      component: TrainEditorDetailPanelComponent
    }
  };
}

@Component({
  selector: 'oksygen-train-editor',
  templateUrl: './train-editor.component.html',
  styleUrls: ['./train-editor.component.scss'],
  providers: [TrainEditorContextPublisher, { provide: ContextSupplier, useExisting: TrainEditorContextPublisher }]
})
export class TrainEditorComponent
  extends BaseEditorComponent<EditorTrain, TrainEditorContext, TrainEditManager, TrainEditService>
  implements AfterViewInit, OnDestroy
{
  @ViewChild('listView', { read: ViewContainerRef, static: false }) listView: ViewContainerRef;
  @ViewChild('mainView', { read: ViewContainerRef, static: false }) mainView: ViewContainerRef;
  @ViewChild('detailsView', { read: ViewContainerRef, static: false }) detailsView: ViewContainerRef;

  version: number;
  formError = false;
  vehicleConfigError = false;
  train$: Observable<EditorTrain>;
  saveDisabled = false;

  constructor(
    activatedRoute: ActivatedRoute,
    contextSupplier: TrainEditorContextPublisher,
    trainEditService: TrainEditService,
    private cdr: ChangeDetectorRef,
    private tabService: TabService
  ) {
    super(activatedRoute, contextSupplier, trainEditService);
  }
  ngAfterViewInit(): void {
    this.initialiseDataManagers();
  }
  override processConfig(context: TrainEditorContext, config: Data): void {
    this.subscription.add(
      context.train$.subscribe(train => {
        this.version = train?.version;
        this.vehicleConfigError = train?.vehicles?.length === 0;
        this.updateSaveDisabled();
      })
    );

    if (isTrainEditorConfig(config)) {
      this.config = config;
    } else {
      throw new Error(`[TrainEditorComponent] supplied component config invalid!`);
    }
    this.renderViews();
    this.cdr.detectChanges(); // rerun change detection as attaching views in ngAfterViewInit will trigger an ExpressionChangedAfterItHasBeenCheckedError
  }

  private renderViews(): void {
    this.renderListView();
    this.renderMainView();
    this.renderDetailsView();
  }

  private renderListView(): void {
    const context$ = this.contextSupplier.currentContext$();
    this.train$ = context$.pipe(switchMap(context => context.train$));
    const trainType$ = context$.pipe(
      switchMap(context => combineLatest([of(context), context.train$])),
      switchMap(([context, train]) => context.trainTypes$.pipe(map(trainTypes => trainTypes.find(tt => tt.name === train?.trainType?.name))))
    );
    const trains$ = context$.pipe(
      switchMap(context => combineLatest([of(context), trainType$, context.train$])),
      switchMap(([context, trainType, train]) =>
        context.trains$.pipe(map(trains => trains.filter(t => t.trainType.name === trainType?.name && t.name !== train.name)))
      )
    );
    const uiState$ = context$.pipe(
      map(context =>
        context.uiState.getStateModel<TrainEditorUiState>('list', () => {
          throw new Error(`[TrainEditor] ui state manager not initialised!`);
        })
      )
    );
    const data: TrainEditorListPanelData = {
      train$: this.train$,
      uiState$,
      trainType$,
      trains$
    };
    this.renderChild(this.listView, this.getConfig().listPanel.component, data);
  }

  private renderMainView(): void {
    const trainData = this.constructTrainConfigViewData();
    const children = [];
    children.push({ component: this.getConfig().trainConfigurationPanel.component, data: trainData });
    this.renderChildren(this.mainView, children);
  }

  private constructTrainConfigViewData(): TrainEditorConfigurationData {
    const context$ = this.contextSupplier.currentContext$();
    const train$ = context$.pipe(switchMap(context => context.train$));
    const trainType$ = context$.pipe(
      switchMap(context => combineLatest([of(context), context.train$])),
      switchMap(([context, train]) => context.trainTypes$.pipe(map(trainTypes => trainTypes.find(c => c.name === train?.trainType?.name))))
    );
    const data: TrainEditorConfigurationData = {
      train$,
      trainType$,
      carClassAdded: {
        next: (carClass: CarClass) => this.addCar(carClass),
        error: () => {},
        complete: () => {}
      },
      trainConfigurationUpdated: {
        next: (vehicles: EditorConsistVehicle[]) => this.trainConfigUpdated(vehicles),
        error: () => {},
        complete: () => {}
      }
    };
    return data;
  }

  private renderDetailsView(): void {
    const context$ = this.contextSupplier.currentContext$();
    const train$ = context$.pipe(switchMap(context => context.train$));
    const trainTypes$ = context$.pipe(
      switchMap(context => context.trainTypes$),
      map(trainTypes => trainTypes.filter(trainType => trainType.editable).map(trainType => trainType.name))
    );
    const savedTrainName$ = this.manager$.getValue().savedTrainName$();
    const trainNames$ = context$.pipe(switchMap(context => context.trains$.pipe(map(trains => trains.map(t => t.name)))));
    const data: TrainEditorDetailPanelData = {
      train$,
      trainTypes$,
      otherTrainNames$: trainNames$,
      savedTrainName$,
      nameUpdate: {
        next: name => this.nameUpdate(name),
        error: () => {},
        complete: () => {}
      },
      disableSave: {
        next: status => this.saveDisable(status),
        error: () => {},
        complete: () => {}
      },
      trainTypeUpdate: {
        next: trainTypeName => this.trainTypeUpdate(trainTypeName),
        error: () => {},
        complete: () => {}
      },
      trainConfigurationUpdated: {
        next: updated => this.trainConfigUpdated(updated),
        error: () => {},
        complete: () => {}
      }
    };
    this.renderChild(this.detailsView, this.getConfig().detailsPanel.component, data);
  }
  private nameUpdate(name: string): void {
    this.manager$.getValue().setTrainName(name);
    this.cdr.detectChanges();
  }

  private saveDisable(status: boolean): void {
    this.formError = status;
    this.updateSaveDisabled();
  }

  private addCar(carClass: CarClass): void {
    this.manager$.getValue().addVehicle(carClass);
  }

  private trainConfigUpdated(vehicles: EditorConsistVehicle[]): void {
    if(!isNil(vehicles)){
      this.manager$.getValue().updateTrainConfig(vehicles);
    }
  }

  private trainTypeUpdate(trainTypeName: string): void {
    this.subscription.add(
      this.contextSupplier
        .currentContext$()
        .pipe(
          switchMap(context => context.trainTypes$),
          map(trainTypes => trainTypes.find(trainType => trainType.name === trainTypeName))
        )
        .subscribe(tt => {
          this.manager$.getValue().setTrainType(tt);
        })
    );
  }

  getDefaultConfig(): TrainEditorConfig {
    return defaultConfig();
  }

  getEditorDataFromContext(context: TrainEditorContext): Observable<EditorTrain> {
    return context?.train$ || of(null);
  }

  override ngOnDestroy(): SuperCalled {
    return super.ngOnDestroy();
  }

  @HostListener('window:keydown.control.s', ['$event'])
  saveTrain(event?: KeyboardEvent): void {
    event?.preventDefault();
    this.manager$.getValue().save().subscribe();
  }

  private getConfig(): Data {
    let config = this.config;

    if (isSignal(config)) {
      config = config();
    }

    return config;
  }

  override onEditorDataUpdate(data: EditorTrain): void {
    if (!data) {
      return;
    }
    const tab = this.tabService.getTabGroupItem(TRAINS_CARD_DATA.id, data.id);
    if (!!tab && tab.data.name !== data.name) {
      tab.data.name = data.name;
    }
  }

  updateSaveDisabled(): void {
    this.saveDisabled = this.formError || this.vehicleConfigError;
    this.manager$.value.updateSaveDisabled(this.saveDisabled);
  }
}
