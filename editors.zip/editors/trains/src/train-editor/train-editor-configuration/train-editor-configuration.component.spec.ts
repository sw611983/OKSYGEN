/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserConfigurationModule } from '@oksygen-sim-train-libraries/components-services/user-configuration';

import { TrainEditorConfigurationComponent } from './train-editor-configuration.component';
import { OksygenSimTrainTrainEditModule } from '../../trains-edit.module';

describe('TrainEditorConfigurationComponent', () => {
  let component: TrainEditorConfigurationComponent;
  let fixture: ComponentFixture<TrainEditorConfigurationComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainTrainsModule, OksygenSimTrainTrainEditModule, OksygenSimTrainUserConfigurationModule],
      declarations: [TrainEditorConfigurationComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainEditorConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
