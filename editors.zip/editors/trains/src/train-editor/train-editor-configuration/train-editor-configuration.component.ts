/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { extractJSONData } from '@oksygen-common-libraries/common';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ConfirmResult, yesNoDialog } from '@oksygen-sim-train-libraries/components-services/common';
import { CarClassType, Consist, ConsistVehicleOrientation, RailType, TrainType } from '@oksygen-sim-train-libraries/components-services/trains';
import _ from 'lodash';
import { BehaviorSubject, combineLatest, Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';
import { EditorConsistVehicle, EditorTrain, TrainEditorConfigurationData, TrainVehicleData, TrainVehicleListDataType } from '../../models/train-editor.model';
import { BarData, Configs } from '../../models/histogram.model';

@Component({
  selector: 'oksygen-train-editor-configuration',
  templateUrl: './train-editor-configuration.component.html',
  styleUrls: ['./train-editor-configuration.component.scss']
})
export class TrainEditorConfigurationComponent implements OnInit, OnDestroy {
  @Input() data: TrainEditorConfigurationData;
  readonly unitFormatAccessor = ['load', 'long'];
  readonly unitForPassenger = ['passengerLoad', 'long'];
  isPassengerType: boolean;
  isFreightType: boolean;
  isTramType: boolean;
  maxMotorVehicles: number;
  maxVehicles: number;

  readonly decimalPlaces: number = 2;
  trainType: TrainType;
  train: EditorTrain;

  trainConfiguration: EditorConsistVehicle[][] = [];

  protected subscription = new Subscription();

  public loadingPanelState = true;
  public loadingGraphConfig: Configs = { min: 0, max: 0 };
  public loadingData: BarData[] = [];
  public loadingGraphData$: BehaviorSubject<BarData[]> = new BehaviorSubject<BarData[]>(null);
  public totalTareWeight = 0;
  public totalLoadingWeight = 0;
  public totalMaxLoadingWeight = 0;
  public totalGrossWeight = 0;
  public totalMaxGrossWeight = 0;
  public totalLength = 0;
  public loco = 0;
  public trailer = 0;

  wholeSelectedGroups: number[] = [];
  indeterminateEnabled = false;
  duplicateEnabled = false;
  multiplyEnabled = false;
  moveUpEnabled = false;
  moveDownEnabled = false;
  moveFirstEnabled = false;
  moveLastEnabled = false;
  deleteEnabled = false;

  indeterminateValue = false;

  checkedValue = false;
  motorCarsCount: number;
  totalVehicleCount: number;

  multiplySelectedQuantity: number;
  minMultiplyValue = 1;
  maxMultiplyValue: number;
  // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
  multiplyForm = new FormControl(null, [Validators.required, Validators.min(1), (control: AbstractControl) => Validators.max(this.maxMultiplyValue)(control)]);

  expandedPosition: string;

  constructor(private logger: Logging, private dialog: MatDialog, private translateService: TranslateService, private registry: Registry) {
    const railType = this.registry.getObject(['editor', 'train'], { railType: 'Passenger', maxMotorVehicles: 1, maxVehicles: 300 });
    this.isPassengerType = railType.railType === RailType.PASSENGER_TYPE;
    this.isFreightType = railType.railType === RailType.FREIGHT_TYPE;
    this.isTramType = railType.railType === RailType.TRAM_TYPE;
    this.maxMotorVehicles = railType.maxMotorVehicles;
    this.maxVehicles = railType.maxVehicles;
  }

  ngOnInit(): void {
    this.initialiseData();
    this.updateLoadingGraphData();
  }

  protected initialiseData(): void {
    if (!this.data) {
      return;
    }
    const sub = combineLatest([this.data.trainType$, this.data.train$])
      .pipe(
        tap(([trainType, train]) => {
          if (!trainType) {
            this.trainConfiguration = []; // all vehicles rely on a train type, so no train type no vehicles!
            return;
          }
          this.trainType = trainType;
          this.trainConfiguration = [];
          this.train = train;
          if (train?.vehicles?.length > 0) {
            const vehicles = this.updateOrientationSupportedStatus(train.vehicles);
            this.trainConfiguration = this.insertAndGroup(vehicles);
            this.updateLoadingGraphData();
          }
          this.refreshPageStatus();
        })
      )
      .subscribe();
    this.subscription.add(sub);
  }

  updateOrientationSupportedStatus(vehicles: EditorConsistVehicle[]): EditorConsistVehicle[] {
    return vehicles.map(v => {
      const carClass = Array.from(this.trainType.carClasses.values()).find(cc => cc.classCode === v.carClass.classCode);
      return { ...v, isOrientationChangeSupported: !!carClass?.carOrientation12 && !!carClass?.carOrientation21 };
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  // Handle drag over
  onDrag(ev: DragEvent): void {
    ev.preventDefault();
    ev.dataTransfer.dropEffect = 'move';
  }

  // Handle drop from external source
  onDrop(ev: DragEvent): void {
    ev.preventDefault();
    const droppedData = extractJSONData<{ type: string; data: TrainVehicleData }>(ev.dataTransfer);
    if (droppedData.type === TrainVehicleListDataType.CarClass || TrainVehicleListDataType.Train) {
      if (droppedData.type === TrainVehicleListDataType.CarClass) {
        this.data.carClassAdded.next(droppedData.data.carClass);
        this.refreshTrainConfiguration();
      } else {
        if (this.trainConfiguration.length > 0) {
          const trainDropSub = yesNoDialog(
            t('Train Dropped'),
            t('Adding a train will clear the existing train configuration. Do you wish to proceed?'),
            this.translateService,
            this.dialog,
            t('Clear')
          ).subscribe(result => {
            if (result === ConfirmResult.SAVE) {
              this.onTrainDrop(droppedData.data.train);
            }
          });
          this.subscription.add(trainDropSub);
        } else {
          this.onTrainDrop(droppedData.data.train);
        }
      }
    } else {
      // Handle invalid data
      this.logger.error('Invalid drag data');
    }
  }

  onTrainDrop(train: Consist): void {
    this.trainConfiguration = this.insertAndGroup(train.vehicles);
    this.refreshTrainConfiguration();
  }

  // Handle internal drag and drop
  dropList(event: CdkDragDrop<any[]>): void {
    if (event.previousContainer === event.container) {
      // Move item within the same list
      moveItemInArray(this.trainConfiguration, event.previousIndex, event.currentIndex);
    } else {
      // Move item between different containers
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
    }
    this.refreshTrainConfiguration();
  }

  // Group items by car class and set the group header
  insertAndGroup(vehicleDisplayInfo: EditorConsistVehicle[]): EditorConsistVehicle[][] {
    const groupedVehicles: EditorConsistVehicle[][] = [];
    let currentGroup: EditorConsistVehicle[] = [];
    let prevVehicleName = vehicleDisplayInfo[0]?.carClass?.description;

    vehicleDisplayInfo.forEach((vehicle, index) => {
      const currentVehicleName = vehicle?.carClass?.description;
      const sNum = index + 1;
      if (currentVehicleName === prevVehicleName) {
        currentGroup.push({ ...vehicle, position: index, displayPosition: sNum.toString() }); // Add to current group
      } else {
        groupedVehicles.push([...currentGroup]); // Push previous group
        currentGroup = [{ ...vehicle, position: index, displayPosition: sNum.toString() }]; // Start new group
        prevVehicleName = currentVehicleName;
      }
    });

    groupedVehicles.push([...currentGroup]); // Push the last group
    return groupedVehicles;
  }

  /**
   * This method refreshes vehicle positions and check/indeterminate status.
   */
  private updateVehiclePositions(): void {
    let position = 1;
    this.trainConfiguration?.forEach(vehicleGroup => {
      const startIndex = vehicleGroup[0].header ? 1 : 0;
      for (let i = startIndex; i < vehicleGroup.length; i++) {
        vehicleGroup[i].displayPosition = this.formatNumber(position);
        ++position;
      }
      if (vehicleGroup.length > 1) {
        // It has only header and a vehicle. Remove the header.
        if (vehicleGroup.length === 2 && vehicleGroup[0].header) {
          vehicleGroup.splice(0, 1);
        } else {
          // No header, add one
          if (!vehicleGroup[0].header) {
            vehicleGroup.unshift(_.cloneDeep(vehicleGroup[0]));
          }
          // Update header position, loading and max loading
          vehicleGroup[0].header = true;
          vehicleGroup[0].displayPosition = this.findHeaderPosition(vehicleGroup[1].displayPosition, vehicleGroup[vehicleGroup.length - 1].displayPosition);
          const vehicles = vehicleGroup.slice(1);
          vehicleGroup[0].loading = this.findTotalLoading(vehicles);
          vehicleGroup[0].carClass.maxLoading = this.findTotalMaxLoading(vehicles);
        }
      }
    });
    // The positions are updated so update selected configurations as well
    this.updateWholeSelectedGroups();
    // Need to update check/indeterminate of the header entry
    this.updateAllHeaderStatus();
  }

  /**
   * Finds total max loading to display on the header entry of a vehicle group.
   * @param vehicleGroup
   */
  private findTotalMaxLoading(vehicleGroup: EditorConsistVehicle[]): number {
    const totalMaxLoading = vehicleGroup.map(v => +v.carClass.maxLoading).reduce((sum, current) => sum + current);
    return totalMaxLoading;
  }

  /**
   * Finds total loading to display on the header entry of a vehicle group.
   * @param vehicleGroup
   */
  private findTotalLoading(vehicleGroup: EditorConsistVehicle[]): number {
    const totalLoading = vehicleGroup.map(v => v.loading).reduce((sum, current) => sum + current);
    return totalLoading;
  }

  /**
   * Finds header position from the start position and end position of this group.
   * @param start
   * @param end
   */
  private findHeaderPosition(start: string, end: string): string {
    return start + ' - ' + end;
  }

  /**
   * Format the number to have a minium of 2 digits.
   */
  private formatNumber(no: number): string {
    return String(no).padStart(2, '0');
  }

  /**
   * Handles selection of a single vehicle.
   * @param position
   */
  selectVehicleClicked(position: string): void {
    for (const vehicleGroup of this.trainConfiguration) {
      for (let i = 0; i < vehicleGroup.length; i++) {
        const vehicle = vehicleGroup[i];
        if (position === vehicle.displayPosition) {
          // This is an entry with just one element which has only check (no indeterminate)
          if (vehicleGroup.length === 1) {
            vehicle.selected = !vehicle.selected;
          } else {
            // This is the first entry(i.e; the summary) of a group which has check and indeterminate
            if (i === 0) {
              vehicle.selected = this.findCheckValue(vehicle.selected, vehicle.indeterminate);
              vehicle.indeterminate = false;
              // Iterate through all the vehicles and check/uncheck
              vehicleGroup?.forEach((v, index) => {
                if (index > 0) {
                  // First entry is the header
                  v.selected = vehicle.selected;
                }
              });
            }
            // This is the vehicle entry of a group which has only check (no indeterminate)
            else {
              vehicle.selected = !vehicle.selected;
            }
          }
          this.refreshTrainConfiguration();
          return;
        }
      }
    }
  }

  /**
   * If all the sub entries are selected, mark the status as checked. If none of the
   * elements selected, uncheck it. If some of the elements selected, mark as indeterminate.
   * This is worked out based on total number of elememts and the number of selected elements.
   */
  private updateSelectAllStatus(): void {
    const selectedCount = this.getSelectedVehiclesCount();
    if (selectedCount === 0) {
      this.updateCheckedValue(false);
      this.updateIndeterminateValue(false);
    } else {
      let totalCount = 0;
      this.trainConfiguration?.forEach(vehicleGroup => {
        const vehiclesThisGroupCount = vehicleGroup.length === 1 ? vehicleGroup.length : vehicleGroup.length - 1;
        totalCount = totalCount + vehiclesThisGroupCount;
      });
      if (selectedCount === totalCount) {
        this.updateCheckedValue(true);
        this.updateIndeterminateValue(false);
      } else {
        this.updateCheckedValue(false);
        this.updateIndeterminateValue(true);
      }
    }
  }

  private getSelectedVehiclesCount(): number {
    return this.trainConfiguration.flat().filter(vehicle => !vehicle.header && vehicle.selected)?.length;
  }

  /**
   * Updates indeterminate value.
   * @param value
   */
  private updateIndeterminateValue(value: boolean): void {
    this.indeterminateValue = value;
  }

  /**
   * Updates checked value.
   * @param value
   */
  private updateCheckedValue(value: boolean): void {
    this.checkedValue = value;
  }

  /**
   * Executes necessary methods to refresh the page status.
   */
  private refreshPageStatus(): void {
    this.updateVehiclePositions();
    this.updateVehicleCount();
    this.updateToolbarStatus();
    this.updateWholeSelectedGroups();
  }

  /**
   * Updates toolbar status.
   */
  private updateToolbarStatus(): void {
    this.updateSelectAllStatus();

    // If there is any entry in train configuration indeterminate is enabled
    this.indeterminateEnabled = this.trainConfiguration.length > 0;

    // If no selected entries, all the entries except indeterminate is disabled
    if (this.getSelectedVehiclesCount() === 0) {
      this.duplicateEnabled = false;
      this.multiplyEnabled = false;
      this.moveUpEnabled = false;
      this.moveDownEnabled = false;
      this.moveFirstEnabled = false;
      this.moveLastEnabled = false;
      this.deleteEnabled = false;
    } else {
      // If selected entries exist, delete enabled
      this.deleteEnabled = this.trainType?.editable;

      // Duplicate is enabled if groups are fully selected and if the maximum motorCars/vehicle count can be satisfied after duplication
      this.duplicateEnabled = false;
      if (this.wholeSelectedGroups.length !== 0) {
        const selectedMotors = this.trainConfiguration
          .flat()
          .filter(vehicle => !vehicle.header && vehicle.selected && vehicle.carClass.carType === CarClassType.MOTOR).length;
        const selectedVehicles = this.getSelectedVehiclesCount();
        this.duplicateEnabled =
          this.motorCarsCount + selectedMotors <= this.maxMotorVehicles &&
          this.totalVehicleCount + selectedVehicles <= this.maxVehicles &&
          this.trainType?.editable;
      }
      this.updateMultiplyAttributes();

      let moveUpEnabled = false;
      let moveDownEnabled = false;
      const totalVehicleCount = this.trainConfiguration.length;
      if (this.wholeSelectedGroups.length === 1) {
        moveUpEnabled = totalVehicleCount > 1 && !this.isSelectedGroupAtDesiredLocation(0) && this.trainType?.editable;
        moveDownEnabled = totalVehicleCount > 1 && !this.isSelectedGroupAtDesiredLocation(totalVehicleCount - 1) && this.trainType?.editable;
      }
      this.moveUpEnabled = moveUpEnabled;
      this.moveFirstEnabled = moveUpEnabled;
      this.moveDownEnabled = moveDownEnabled;
      this.moveLastEnabled = moveDownEnabled;
    }
  }

  /**
   * This method checks if selected vehicle group is at a desired location.
   */
  isSelectedGroupAtDesiredLocation(desiredLocation: number): boolean {
    return this.wholeSelectedGroups[0] === desiredLocation;
  }

  /**
   * Updates attributes of multiply functionality.
   */
  private updateMultiplyAttributes(): void {
    this.multiplyEnabled = false;
    if (this.wholeSelectedGroups.length === 1) {
      this.multiplyEnabled = this.trainType?.editable;
      let maximumAllowedValue;
      const numberOfCars = this.getSelectedVehiclesCount();
      if (this.trainConfiguration.flat().filter(vehicle => !vehicle?.header && vehicle?.selected)[0]?.carClass.carType === CarClassType.MOTOR) {
        // Maximum allowed value depends on total locomotives and total vehicles already used
        maximumAllowedValue = numberOfCars + Math.min(this.maxMotorVehicles - this.motorCarsCount, this.maxVehicles - this.totalVehicleCount);
      } else {
        maximumAllowedValue = numberOfCars + (this.maxVehicles - this.totalVehicleCount);
      }
      this.maxMultiplyValue = maximumAllowedValue;
      this.updateMultiplyQuantity(numberOfCars);
    }
  }

  updateMultiplyQuantity(value: number): void {
    this.multiplySelectedQuantity = value;
    this.multiplyForm.setValue(value);
  }

  /**
   * If it is already checked, uncheck it. If already unchecked
   * or indeterminate, check it.
   * @param currentCheckValue
   * @param currentIndeterminateValue
   */
  private findCheckValue(currentCheckValue: boolean, currentIndeterminateValue: boolean): boolean {
    if (currentCheckValue) {
      return false;
    } else if ((!currentCheckValue && !currentIndeterminateValue) || currentIndeterminateValue) {
      return true;
    } else {
      return false;
    }
  }

  updateAllHeaderStatus(): void {
    this.trainConfiguration
      .filter(vehicleGroup => vehicleGroup.length > 1)
      .forEach(vehicleGroup => {
        this.updateHeaderCheckStatus(vehicleGroup);
      });
  }

  /**
   * Update head check/inderterminate status. Work out the state depending on the total
   * number of vehicles and the number of selected entries in this group.
   * @param vehicleGroup
   */
  private updateHeaderCheckStatus(vehicleGroup: EditorConsistVehicle[]): void {
    const selectedVehiclesCount = vehicleGroup.slice(1).filter(v => v.selected).length; // Ignore header entry
    const header: EditorConsistVehicle = vehicleGroup[0];

    if (selectedVehiclesCount === 0) {
      header.selected = false;
      header.indeterminate = false;
    } else {
      const totalVehiclesCount = vehicleGroup.length - 1; // Ignore header entry
      if (selectedVehiclesCount === totalVehiclesCount) {
        header.selected = true;
        header.indeterminate = false;
      } else {
        header.selected = false;
        header.indeterminate = true;
      }
    }
  }

  /**
   * Updates the groups which are fully selected.
   */
  private updateWholeSelectedGroups(): void {
    this.wholeSelectedGroups.splice(0, this.wholeSelectedGroups.length); // Clear first
    for (let index = 0; index < this.trainConfiguration.length; index++) {
      const vehicleGroup = this.trainConfiguration[index];
      // If there is a group partially selected, clear whole selected groups and return
      if (vehicleGroup[0].indeterminate) {
        this.wholeSelectedGroups.splice(0, this.wholeSelectedGroups.length);
        break;
      } else if (vehicleGroup[0].selected) {
        this.wholeSelectedGroups.push(index);
      }
    }
  }

  expandClicked(position: string): void {
    this.expandedPosition = this.expandedPosition === position ? null : position;
  }

  /**
   * When checkbox is clicked, if it is already checked, uncheck it. If already unchecked
   * or indeterminate, check it. Whatever is the case it will not be indeterminate.
   */
  selectAllClicked(): void {
    this.updateIndeterminateValue(false);
    this.updateCheckedValue(this.findCheckValue(this.checkedValue, this.indeterminateValue));

    // Iterate through all the values and check/uncheck
    this.trainConfiguration?.forEach(vehicleGroup => {
      vehicleGroup?.forEach(vehicle => {
        vehicle.selected = this.checkedValue;
      });
    });

    // Update selected train configurations.
    this.refreshVehicleSelection();
  }

  /**
   * Executes necessary methods to refresh vehicle selection.
   */
  refreshVehicleSelection(): void {
    this.updateVehicleGroupCheckStatus();
    this.updateWholeSelectedGroups();
    this.updateToolbarStatus();
  }

  /**
   * Updates checkstatus of vehicle group.
   */
  updateVehicleGroupCheckStatus(): void {
    this.trainConfiguration?.forEach(vehicleGroup => {
      const vehicleGroupLength = vehicleGroup.length;
      const startIndex = vehicleGroupLength === 1 ? 0 : 1;
      let selectedVehiclesCount = 0;
      for (let i = startIndex; i < vehicleGroupLength; i++) {
        selectedVehiclesCount = vehicleGroup[i].selected ? ++selectedVehiclesCount : selectedVehiclesCount;
      }
      if (vehicleGroupLength > 1) {
        const headerVehicle = vehicleGroup[0];
        // Update indeterminate/checked of header
        const vehiclesCount = vehicleGroupLength - 1;
        headerVehicle.indeterminate = selectedVehiclesCount > vehiclesCount && selectedVehiclesCount !== vehiclesCount;
        headerVehicle.selected = selectedVehiclesCount === vehiclesCount;
      }
    });
  }

  /**
   * Duplicates selected vehicle groups next to the last selected entry.
   */
  duplicateClicked(): void {
    let positionToInsert = this.wholeSelectedGroups[this.wholeSelectedGroups.length - 1];
    this.wholeSelectedGroups?.forEach(selectedIndex => {
      const vehicleGroup = this.trainConfiguration[selectedIndex];
      this.trainConfiguration.splice(++positionToInsert, 0, _.cloneDeep(vehicleGroup));
    });
    this.refreshTrainConfiguration();
    this.refreshVehicleSelection();
  }

  /**
   * Executes necessary methods to update train configuration.
   */
  refreshTrainConfiguration(): void {
    this.data.trainConfigurationUpdated.next(this.trainConfiguration.flat().filter(vehicle => !vehicle.header));
    this.updateVehicleCount();
    this.updateToolbarStatus();
  }

  /**
   * Updates vehicle count which will be displayed at top right of the screen.
   */
  updateVehicleCount(): void {
    this.totalVehicleCount = this.trainConfiguration.length;
    let noOfTotalVehicles = 0;
    let noOfMotorVehicles = 0;
    this.trainConfiguration?.forEach(vehicleGroup => {
      vehicleGroup?.forEach(v => {
        if (!v.header) {
          ++noOfTotalVehicles;
          if (v.carClass.carType === CarClassType.MOTOR) {
            ++noOfMotorVehicles;
          }
        }
      });
    });
    this.totalVehicleCount = noOfTotalVehicles;
    this.motorCarsCount = noOfMotorVehicles;
  }

  /**
   * Cancels currently selected multiply value.
   */
  cancelMultiply(): void {
    this.updateMultiplyQuantity(this.getSelectedVehiclesCount());
  }

  /**
   * Moves up the selected entry(it is enabled only if a single group is selected).
   */
  moveUpClicked(): void {
    const position = this.wholeSelectedGroups[0];
    this.move(position - 1);
  }

  /**
   * Moves the currently selected vehicle group to the desired position.
   */
  private move(toPosition: number): void {
    const position = this.wholeSelectedGroups[0];
    const vehicleGroupToMove = this.trainConfiguration[position];
    this.trainConfiguration.splice(position, 1);
    this.trainConfiguration.splice(toPosition, 0, _.cloneDeep(vehicleGroupToMove));
    this.refreshTrainConfiguration();
    this.refreshVehicleSelection();
  }

  /**
   * Moves down the selected entry(it is enabled only if a single group is selected).
   */
  moveDownClicked(): void {
    const position = this.wholeSelectedGroups[0];
    this.move(position + 1);
  }

  /**
   * Moves up the selected entry(it is enabled only if a single group is selected) to the first position.
   */
  moveFirstClicked(): void {
    this.move(0);
  }

  /**
   * Moves down the selected entry(it is enabled only if a single group is selected) to the last position.
   */
  moveLastClicked(): void {
    this.move(this.trainConfiguration.length - 1);
  }

  /**
   * Delete button is clicked. Remove all the selected entries. Need to iterate
   * backwards as the entries get removed on iteration.
   */
  deleteClicked(): void {
    let outerIndex = this.trainConfiguration.length;
    while (outerIndex--) {
      const vehicleGroup = this.trainConfiguration[outerIndex];
      let innerIndex = vehicleGroup.length;
      while (innerIndex--) {
        const vehicle = vehicleGroup[innerIndex];
        if (vehicle.header) {
          // It is a header
          // All the other entries are removed, remove header as well
          if (vehicleGroup.length === 1) {
            this.trainConfiguration.splice(outerIndex, 1);
          }
        } else {
          // Its a vehicle entry
          if (vehicle.selected) {
            vehicleGroup.splice(innerIndex, 1);
          }
          // All the entries in this group got removed. Remove the entire group.
          if (vehicleGroup.length === 0) {
            this.trainConfiguration.splice(outerIndex, 1);
          }
        }
      }
    }
    this.refreshTrainConfiguration();
    this.refreshVehicleSelection();
  }

  /**
   * Sets quantity entered from multiple pop up.
   */
  setQuantity(value: number | string): void {
    this.updateMultiplyQuantity(+value);
    this.multiplyForm.markAsTouched();
  }

  /**
   * Applies the currently selected multiply value.
   */
  applyMultiply(): void {
    if (this.multiplySelectedQuantity >= this.minMultiplyValue && this.multiplySelectedQuantity <= this.maxMultiplyValue) {
      const selectedIndex = this.wholeSelectedGroups[0];
      const selectedVehicleGroup = this.trainConfiguration[selectedIndex];
      const startIndex = selectedVehicleGroup[0].header ? 1 : 0;
      const noOfElements = selectedVehicleGroup.length - startIndex;
      // Add more entries
      if (this.multiplySelectedQuantity > noOfElements) {
        let noOfElementsToAdd = this.multiplySelectedQuantity - noOfElements;
        const elementToAdd = selectedVehicleGroup[startIndex];
        while (noOfElementsToAdd--) {
          selectedVehicleGroup.splice(selectedVehicleGroup.length, 0, _.cloneDeep(elementToAdd));
        }
      } else {
        // Remove some entries
        selectedVehicleGroup.splice(startIndex + this.multiplySelectedQuantity, noOfElements - this.multiplySelectedQuantity);
      }

      this.refreshTrainConfiguration();
      this.refreshVehicleSelection();
    }
  }

  orientationUpdated(position: string): void {
    const vehicle = this.trainConfiguration.flat().find(v => !v.header && v.displayPosition === position);
    if (vehicle) {
      // eslint-disable-next-line no-underscore-dangle
      vehicle.orientation = vehicle.orientation === ConsistVehicleOrientation._1_2 ? ConsistVehicleOrientation._2_1 : ConsistVehicleOrientation._1_2;
    }
    this.refreshTrainConfiguration();
  }

  public updateLoadingGraphData(): void {
    this.loadingGraphConfig.max = Math.max(0, ...(this.train?.vehicles?.map(d => (d.loading ?? 0) + (d.carClass?.tareWeight ?? 0)) || []));
    this.totalTareWeight = this.train?.vehicles?.reduce((acc, d) => acc + (d.carClass?.tareWeight ?? 0), 0) ?? 0;
    this.totalLoadingWeight = this.train?.vehicles?.reduce((acc, d) => acc + (d.loading ?? 0), 0) ?? 0;
    this.totalMaxLoadingWeight = this.train?.vehicles?.reduce((acc, d) => acc + (d.carClass?.maxLoading ?? 0), 0) ?? 0;
    this.totalGrossWeight = this.train?.vehicles?.reduce((acc, d) => acc + ((d.carClass?.tareWeight ?? 0) + (d.loading ?? 0)), 0) ?? 0;
    this.totalMaxGrossWeight = this.train?.vehicles?.reduce((acc, d) => acc + (d.carClass?.grossWeight ?? 0), 0) ?? 0;
    this.totalLength = this.train?.vehicles?.reduce((acc, d) => acc + (d.carClass?.length ?? 0), 0) ?? 0;
    this.loco = this.train?.vehicles?.reduce((acc, d) => acc + (d.carClass?.carType === 'MCA' ? 1 : 0), 0) ?? 0;
    this.trailer = this.train?.vehicles?.reduce((acc, d) => acc + (d.carClass?.carType === 'TCA' ? 1 : 0), 0) ?? 0;
    this.updateLoadingData();
  }

  private updateLoadingData(): void {
    this.loadingData = [];
    this.train.vehicles?.forEach(v => {
      this.loadingData.push({ name: v.position.toFixed(2).toString(), value: Number((v.loading + v.carClass.tareWeight).toFixed(this.decimalPlaces)) });
    });
    this.loadingData.reverse();
    this.loadingGraphData$.next(this.loadingData);
  }
}
