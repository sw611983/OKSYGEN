/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import { EditorConsistVehicle } from '../../../models/train-editor.model';
import { MatExpansionPanel } from '@angular/material/expansion';

@Component({
  selector: 'oksygen-train-editor-configuration-item-set',
  templateUrl: './train-editor-configuration-item-set.component.html',
  styleUrls: ['./train-editor-configuration-item-set.component.scss']
})
export class TrainEditorConfigurationItemSetComponent implements AfterViewInit, OnChanges {
  @Input() trainConfigItem: EditorConsistVehicle[];

  @Input() expanded = false;

  @Output() readonly expandClick = new EventEmitter<string>();

  @Output() readonly selectVehicleClick = new EventEmitter<string>();

  @Output() readonly orientationChanged = new EventEmitter<string>();

  @ViewChild('expansionPanel') expansionPanel: MatExpansionPanel;

  constructor(private cdr: ChangeDetectorRef) {}

  synchroniseExpansion(): void {
    if (this.expanded) {
      this.expansionPanel?.open();
    } else {
      this.expansionPanel?.close();
    }
    this.cdr.detectChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.expanded) {
      this.synchroniseExpansion();
    }
  }

  ngAfterViewInit(): void {
    this.synchroniseExpansion();
  }

  toggleExpansion(): void {
    this.expandClick.emit(this.trainConfigItem[0].displayPosition);
  }

  selectVehicleClicked(position: string): void {
    this.selectVehicleClick.emit(position);
  }

  orientationUpdated(position: string): void {
    this.orientationChanged.emit(position);
  }
}
