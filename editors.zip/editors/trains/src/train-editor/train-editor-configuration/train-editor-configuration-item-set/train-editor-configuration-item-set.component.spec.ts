/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainEditorConfigurationItemSetComponent } from './train-editor-configuration-item-set.component';

describe('TrainEditorConfigurationItemSetComponent', () => {
  let component: TrainEditorConfigurationItemSetComponent;
  let fixture: ComponentFixture<TrainEditorConfigurationItemSetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainEditorConfigurationItemSetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainEditorConfigurationItemSetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
