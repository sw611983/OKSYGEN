/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CarClassType, ConsistVehicleOrientation, RailType } from '@oksygen-sim-train-libraries/components-services/trains';
import { EditorConsistVehicle } from '../../../../models/train-editor.model';
import { Registry } from '@oksygen-common-libraries/pio';

type MaterialColors = 'primary'|'accent'|'warn';

@Component({
  selector: 'oksygen-train-editor-configuration-item',
  templateUrl: './train-editor-configuration-item.component.html',
  styleUrls: ['./train-editor-configuration-item.component.scss']
})
export class TrainEditorConfigurationItemComponent implements OnInit {
  isPassengerType: boolean;
  isFreightType: boolean;
  isTramType: boolean;
  readonly carTypeMCA = CarClassType.MOTOR;
  // eslint-disable-next-line no-underscore-dangle
  readonly orientation12 = ConsistVehicleOrientation._1_2;

  /** The vehicles associated with this component. */
  @Input() vehicle!: EditorConsistVehicle;

  @Input() isHeader = false;

  @Output() readonly selectVehicleClick = new EventEmitter<string>();

  @Output() readonly orientationChanged = new EventEmitter<string>();

  checkboxColor: MaterialColors;

  constructor(private registry: Registry) {
    const railType = this.registry.getString(['editor', 'train', 'railType'], 'Passenger');
        this.isPassengerType = railType === RailType.PASSENGER_TYPE;
        this.isFreightType = railType === RailType.FREIGHT_TYPE;
        this.isTramType = railType === RailType.TRAM_TYPE;
  }

  ngOnInit(): void {
    this.checkboxColor = this.isHeader ? 'primary' : 'accent';
  }

  selectVehicleClicked(): void {
    this.selectVehicleClick.emit(this.vehicle.displayPosition);
  }

  orientationUpdated(): void {
    this.orientationChanged.emit(this.vehicle.displayPosition);
  }

}
