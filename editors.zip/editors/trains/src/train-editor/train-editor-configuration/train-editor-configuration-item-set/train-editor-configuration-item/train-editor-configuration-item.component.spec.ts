/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserConfigurationModule } from '@oksygen-sim-train-libraries/components-services/user-configuration';

import { TrainEditorConfigurationItemComponent } from './train-editor-configuration-item.component';
import { OksygenSimTrainTrainEditModule } from '@oksygen-sim-train-libraries/components-services/editors/trains';

describe('TrainEditorConfigurationItemComponent', () => {
  let component: TrainEditorConfigurationItemComponent;
  let fixture: ComponentFixture<TrainEditorConfigurationItemComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainTrainsModule, OksygenSimTrainTrainEditModule, OksygenSimTrainUserConfigurationModule],
      declarations: [TrainEditorConfigurationItemComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainEditorConfigurationItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
