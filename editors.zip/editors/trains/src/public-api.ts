/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export * from './browser/trains-browser.component';
export * from './common/graphs/base-bar-graph/base-bar-graph.component';
export * from './browser/train-details-panel/train-details-panel.component';
export * from './train-editor/train-editor.component';
export * from './train-editor/train-editor-detail-panel/train-editor-detail-panel.component';
export * from './train-editor/train-editor-detail-panel/vehicle-configuration/vehicle-configuration.component';
export * from './train-editor/train-editor-detail-panel/vehicle-configuration/loding-configuration/loding-configuration.component';
export * from './train-editor/loading-graph/loading-graph.component';
export * from './train-editor/train-editor-list-panel/train-editor-list-panel.component';
export * from './train-editor/train-editor-list-panel/train-editor-list-panel-item/train-editor-list-panel-item.component';
export * from './train-editor/train-editor-configuration/train-editor-configuration.component';
// eslint-disable-next-line max-len
export * from './train-editor/train-editor-configuration/train-editor-configuration-item-set/train-editor-configuration-item-set.component';
// eslint-disable-next-line max-len
export * from './train-editor/train-editor-configuration/train-editor-configuration-item-set/train-editor-configuration-item/train-editor-configuration-item.component';
export * from './train-editor/train-editor-top-toolbar/train-editor-top-toolbar.component';
export * from './browser/trains-delete-dialog/trains-delete-dialog.component';

export * from './services/trains-browser.service';
export * from './services/train-editor-context.publisher';
export * from './services/train-editor-context.manager';

export * from './services/rest/train-edit-data.service';

export * from './models/train-editor.model';

export * from './trains-edit.module';

export * from './store/train-editor.actions';
export * from './store/train-editor.reducers';
export * from './store/train-editor.selectors';
export * from './store/train-editor.state';
