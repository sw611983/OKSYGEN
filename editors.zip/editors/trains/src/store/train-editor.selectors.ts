/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/explicit-function-return-type */

import { EntityState } from '@ngrx/entity';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { canRedo, canUndo, getEditorItem, getSavedName, getUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { TrainEditorStoreData, trainEditorDataAdapter as trainEditorDataAdapter } from './train-editor.state';

const trainEditorSelectors = trainEditorDataAdapter.getSelectors();

export const selectTrainEditorState = createFeatureSelector<EntityState<TrainEditorStoreData>>('trainEditor');

export const selectTrainEditorEntities = createSelector(selectTrainEditorState, trainEditorSelectors.selectEntities);

export const getAllTrainEditorData = createSelector(selectTrainEditorState, trainEditorSelectors.selectAll);

/**
 * Selector for observing the saved train name.
 * This will change when the train is saved.
 */
export const getSavedTrainName = (id: string) => createSelector(getAllTrainEditorData, storeData => getSavedName(id, storeData));

/**
 * Selector for observing the unsaved changes state
 * This will change when the train is saved.
 */
export const getTrainUnsavedChanges = (id: string) => createSelector(getAllTrainEditorData, storeData => getUnsavedChanges(id, storeData));

/**
 * Selector for observing the train under edit.
 * This will change during an editing session to reflect the user's input.
 */
export const getTrain = (id: string) => createSelector(getAllTrainEditorData, storeData => getEditorItem(id, storeData));

/**
 * Selector for observing the undo changes state
 * This will change when train data is changed.
 */
export const canUndoTrain = (id: string) => createSelector(getAllTrainEditorData, storeData => canUndo(id, storeData));

/**
 * Selector for observing the redo changes state
 * This will change when train data is changed.
 */
export const canRedoTrain = (id: string) => createSelector(getAllTrainEditorData, storeData => canRedo(id, storeData));
