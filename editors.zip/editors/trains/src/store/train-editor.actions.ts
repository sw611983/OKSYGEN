/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/explicit-function-return-type */

import { createActionGroup, props } from '@ngrx/store';
import { EditorTrain, EditorConsistVehicle } from '../models/train-editor.model';
import { CarClass, TrainType } from '@oksygen-sim-train-libraries/components-services/trains';

/** Our list of possible actions one can take in the train Editor. */
export const trainEditorActions = createActionGroup({
  source: 'TrainEditorActionEnum',
  events: {
    'new Train': props<{ id: string; name: string }>(),
    'load Train': props<{ id: string; original: EditorTrain }>(),
    'train Closed': props<{ id: string }>(),
    'train Undo': props<{ id: string }>(),
    'train Redo': props<{ id: string }>(),
    'save Train': props<{ id: string; save: EditorTrain; trainId: number }>(),
    'set Train Type': props<{ id: string; trainType: TrainType }>(),
    'add Vehicle': props<{ id: string; carClass: CarClass }>(),
    'update Train Config': props<{ id: string; vehicles: EditorConsistVehicle[] }>(),
    'set Train Name': props<{ id: string; name: string }>()
  }
});
