/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { BaseEditorStoreData } from '@oksygen-sim-train-libraries/components-services/editors';
import { EditorTrain } from '../models/train-editor.model';

export type TrainEditorStoreData = BaseEditorStoreData<EditorTrain>;
export type TrainEditorState = EntityState<TrainEditorStoreData>;
export const trainEditorDataAdapter: EntityAdapter<TrainEditorStoreData> = createEntityAdapter<TrainEditorStoreData>();
export const initialTrainEditorState: TrainEditorState = trainEditorDataAdapter.getInitialState();
