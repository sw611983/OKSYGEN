/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createReducer, on } from '@ngrx/store';
import { cloneDeep, isNil } from 'lodash';

import { trainEditorActions } from './train-editor.actions';
import { updateForUnsavedChanges, updateSimpleProperty } from '@oksygen-sim-train-libraries/components-services/editors';
import { initialTrainEditorState, trainEditorDataAdapter, TrainEditorState, TrainEditorStoreData } from './train-editor.state';
import { EditorTrain, EditorConsistVehicle } from '../models/train-editor.model';
import { CarClass, ConsistVehicleOrientation, TrainType } from '@oksygen-sim-train-libraries/components-services/trains';

function trainUpdateForUnsavedChanges(state: TrainEditorState, original: TrainEditorStoreData, train: EditorTrain): TrainEditorState {
  return updateForUnsavedChanges(trainEditorDataAdapter, state, original, train);
}

function generateNewTrain(id?: string, name?: string): EditorTrain {
  const newTrain: EditorTrain = {
    id,
    name,
    history: {
      historyLog: []
    },
    version: 1,
    trainType: undefined,
    vehicles: [],
    editable: true
  };
  return newTrain;
}

export const trainEditorReducer = createReducer(
  initialTrainEditorState,
  on(trainEditorActions.newTrain, (state: TrainEditorState, action: { id: string; name: string }) => {
    const value: TrainEditorStoreData = {
      id: action.id,
      savedName: undefined,
      unsavedChanges: false,
      editorItem: generateNewTrain(action.id, action.name),
      canRedo: false,
      canUndo: false
    };
    return trainEditorDataAdapter.setOne(value, state);
  }),
  on(trainEditorActions.loadTrain, (state: TrainEditorState, action: { id: string; original: EditorTrain }) => {
    const value: TrainEditorStoreData = {
      id: action.id,
      savedName: action.original.name,
      unsavedChanges: false,
      editorItem: action.original,
      canRedo: false,
      canUndo: false
    };

    return trainEditorDataAdapter.setOne(value, state);
  }),
  on(trainEditorActions.trainClosed, (state: TrainEditorState, action: { id: string }) => trainEditorDataAdapter.removeOne(action.id, state)),
  on(trainEditorActions.saveTrain, (state: TrainEditorState, action: { id: string; save: EditorTrain; trainId: number }) => {
    const value = cloneDeep(state.entities[action.id]);
    return trainEditorDataAdapter.setOne(
      {
        ...value,
        unsavedChanges: false,
        savedName: action.save.name,
        editorItem: {
          ...value.editorItem,
          version: action.save.version,
          history: action.save.history,
          trainId: action.trainId
        }
      },
      state
    );
  }),
  on(trainEditorActions.setTrainType, (state: TrainEditorState, action: { id: string; trainType: TrainType }) => {
    const value = cloneDeep(state.entities[action.id]);

    if (value.editorItem.trainType === action.trainType) {
      return state;
    }

    let vehicles = value?.editorItem?.vehicles;

    if (isNil(action.trainType)) {
      vehicles = [];
    }

    return trainUpdateForUnsavedChanges(state, value, {
      ...value.editorItem,
      trainType: action.trainType,
      vehicles
    });
  }),
  on(trainEditorActions.addVehicle, (state: TrainEditorState, action: { id: string; carClass: CarClass }) => {
    const value = cloneDeep(state.entities[action.id]);
    const vehicles = value?.editorItem?.vehicles;
    // eslint-disable-next-line no-underscore-dangle
    vehicles.push({ carClass: action.carClass, loading: 0, orientation: ConsistVehicleOrientation._1_2, serialNumber: 0, position: 0 });

    return trainUpdateForUnsavedChanges(state, value, {
      ...value.editorItem,
      vehicles: [...vehicles]
    });
  }),
  on(trainEditorActions.updateTrainConfig, (state: TrainEditorState, action: { id: string; vehicles: EditorConsistVehicle[] }) => {
    const value = cloneDeep(state.entities[action.id]);
    return trainUpdateForUnsavedChanges(state, value, {
      ...value.editorItem,
      vehicles: [...action.vehicles]
    });
  }),
  on(trainEditorActions.setTrainName, (state: TrainEditorState, action: { id: string; name: string }) =>
    updateSimpleProperty(state, trainEditorDataAdapter, {
      id: action.id,
      name: action.name
    })
  )
);
