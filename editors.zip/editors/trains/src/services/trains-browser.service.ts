/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { AbstractBrowserService } from '@oksygen-sim-train-libraries/components-services/editors';

@Injectable({
  providedIn: 'root'
})
export class TrainsBrowserService extends AbstractBrowserService {

  constructor() {
    super('TrainsBrowserService');
   }
}
