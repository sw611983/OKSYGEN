/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, Injectable } from '@angular/core';
import { isNil } from 'lodash';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { asArray, EditHistory, SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import {
  Consist,
  ConsistDataService,
  ConsistVehicle,
  ConsistVehicleOrientation,
  TrainType,
  TrainTypeService,
  VehicleOrientation
} from '@oksygen-sim-train-libraries/components-services/trains';

import { TRAIN_EDITOR_DATA_ACCESS_SERVICE_TOKEN } from '../../tokens/train-editor.token';

/* eslint-disable no-underscore-dangle */

/**
 * Don't use these interfaces - prefer TrainType in train-vehicle.model!
 */
interface TrainRestResponseData {
  message: TrainRestData;
}

interface TrainRestData {
  trains: Array<TrainRest>;
}

interface TrainHistory extends EditHistory {
  trainName: string;
  trainVersion: number;
}

interface TrainRest {
  uuid?: string;
  id?: number;
  name: string;
  version: number;
  editable: boolean;
  history: Array<TrainHistory>;
  trainTypeName: string;
  cars: Array<CarRest>;
}

interface CarRest {
  carClass: string;
  orientation: string;
  loading: number;
  position: number;
  serialNumber: number;
}

@Injectable()
export class TrainEditorConsistDataService extends ConsistDataService {
  private url: string;

  constructor(
    logging: Logging,
    registry: Registry,
    @Inject(TRAIN_EDITOR_DATA_ACCESS_SERVICE_TOKEN) dataAccessService: DataAccessService,
    trainTypeService: TrainTypeService
  ) {
    super(logging, registry, dataAccessService, trainTypeService);

    this.url = this.registry.getString(['trainEditorData', 'allTrainsUrl']);
    this.initialise();
  }

  protected override getTrainsData(): SelfCompletingObservable<TrainRestData> {
    return this.dataAccessService
      .callQueryJson<TrainRestResponseData>({
        query: this.url,
        operation: 'getTrains',
        debugMsg: 'fetched all Trains'
      })
      .pipe(map(response => response.message));
  }

  /**
   * This exists because the XML format for trains is kinda sucky to work with.
   *
   * @param train the converted XML train type data
   */
  protected override transformData(train: TrainRestData, types: Map<number, TrainType>): Array<Consist> {
    if (isNil(train?.trains)) {
      return undefined;
    }

    const trainTypes = new Map<string, TrainType>();
    Array.from(types.values()).forEach(t => trainTypes.set(t.name, t));

    const consists: Array<Consist> = [];

    for (const t of asArray(train.trains)) {
      const trainType = trainTypes.get(t.trainTypeName);
      if (!trainType) {
        this.logging.warn(`Train ${t.name} has train type ${t.trainTypeName} that does not exist! Trains of this type may not work as expected.`);
      }

      const consist: Consist = {
        uuid: t.uuid,
        id: t.id,
        name: t.name,
        version: t.version,
        trainType,
        editable: t.editable,
        vehicles: [],
        history: { historyLog: asArray(t.history) }
      };

      asArray(t.cars).forEach(c => {
        const carClass = Array.from(trainType?.carClasses?.values() ?? []).find(cc => cc.classCode === c.carClass);

        const vehicle: ConsistVehicle = {
          carClass,
          orientation: c.orientation === VehicleOrientation.ORIENTATION_1_2 ? ConsistVehicleOrientation._1_2 : ConsistVehicleOrientation._2_1,
          loading: c.loading,
          serialNumber: c.serialNumber,
          position: c.position
        };
        consist.vehicles.push(vehicle);
      });

      consists.push(consist);
    }

    return consists;
  }

  public getTrain(id: string): Observable<Consist> {
    return this.data().pipe(map(consist => consist?.find(c => c.uuid === id)));
  }
}
