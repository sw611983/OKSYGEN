/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Observable } from 'rxjs';
import { Consist, TrainType } from '@oksygen-sim-train-libraries/components-services/trains';
import { Context } from '@oksygen-sim-train-libraries/components-services/common';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { EditorTrain } from '../models/train-editor.model';


export class TrainEditorContext implements Context {

  uiState: UiStateModelManager;
  train$: Observable<EditorTrain>;
  trainTypes$: Observable<TrainType[]>;
  trains$: Observable<Consist[]>;
  unsavedChanges$: Observable<boolean>;

  destroy(): void {
  }
}
