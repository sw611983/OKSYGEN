/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { cloneDeep, isEqual } from 'lodash';
import { BehaviorSubject, Observable, of, zip } from 'rxjs';
import { catchError, first, switchMap, tap } from 'rxjs/operators';

import {
  filterTruthy,
  HISTORY_TYPE_COPIED,
  HISTORY_TYPE_CREATED,
  HISTORY_TYPE_MODIFIED,
  HistoryType,
  selfCompletingObservable,
  SelfCompletingObservable,
  shareReplayOne,
  SuperCalled,
  takeOneTruthy
} from '@oksygen-common-libraries/common';
import { OK_BUTTON, PromptDialogComponent, PromptDialogData } from '@oksygen-common-libraries/material/components';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Logging } from '@oksygen-common-libraries/pio';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { ConfirmResult, unsavedChangesDialog } from '@oksygen-sim-train-libraries/components-services/common';
import { BaseDataEditorManager } from '@oksygen-sim-train-libraries/components-services/editors';
import { CarClass, ConsistDataService, TrainType } from '@oksygen-sim-train-libraries/components-services/trains';

import { EditorConsistVehicle, EditorTrain } from '../../models/train-editor.model';
import { trainEditorActions } from '../../store/train-editor.actions';
import { canRedoTrain, canUndoTrain, getSavedTrainName, getTrain, getTrainUnsavedChanges } from '../../store/train-editor.selectors';
import { TrainEditorState } from '../../store/train-editor.state';
import { TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN } from '../../tokens/train-editor.token';
import { TrainEditDataService } from '../rest/train-edit-data.service';
import { TrainEditorContext } from '../train-editor-context';

interface SuccessFailedDialogData {
  title: string;
  id: string;
  successMessage: string;
  failedMessage?: string;
}

export class TrainEditManager extends BaseDataEditorManager<EditorTrain, TrainEditorContext> {
  private train: BehaviorSubject<EditorTrain> = new BehaviorSubject(null);

  public canUndo$: Observable<boolean>;
  public canRedo$: Observable<boolean>;
  private saveDisabled = false;

  constructor(
    public id: string,
    protected store: Store<TrainEditorState>,
    private authService: AuthService,
    dialog: MatDialog,
    translateService: TranslateService,
    private snackbar: MatSnackBar,
    private readonly zone: NgZone,
    protected logging: Logging,
    private trainEditDataService: TrainEditDataService,
    @Inject(TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN) private consistDataService: ConsistDataService
  ) {
    super(translateService, dialog);
    const sub = this.store.select(getTrainUnsavedChanges(this.id)).subscribe(unsavedChanges => (this.unsavedChanges = unsavedChanges));
    this.subscription.add(sub);
    this.canUndo$ = this.store.select(canUndoTrain(this.id));
    this.canRedo$ = this.store.select(canRedoTrain(this.id));
  }

  override confirmCloseEditor(): Observable<boolean> {
    if (!this.unsavedChanges) {
      return of(true);
    } else {
      return unsavedChangesDialog(this.getItemName(), this.translateService, this.dialog).pipe(
        switchMap(dialogResult => {
          switch (dialogResult) {
            case ConfirmResult.SAVE:
              return this.verifyAndSaveTrain();
            case ConfirmResult.NO_SAVE:
              return of(true);
            default:
              return of(false);
          }
        })
      );
    }
  }

  private verifyAndSaveTrain(): SelfCompletingObservable<boolean> {
    if (!this.saveDisabled) {
      return this.saveTrain();
    } else {
      this.zone.run(() => {
        // snackbar needs to run in zone
        this.snackbar.open(this.translateService.instant(t('Unable to save the train due to incorrect configurations.')), '', { duration: 3000 });
      });
      return selfCompletingObservable(false);
    }
  }

  setEditingContext(dm: TrainEditorContext): void {
    this.context = dm;
    this.subscription.add(
      this.store
        .select(getTrain(this.id))
        .pipe(filterTruthy())
        .subscribe(train => {
          this.train.next(train);
        })
    );
    // feels like a bit of a code smell setting context properties here rather than the provider
    dm.train$ = this.train.asObservable();
    dm.unsavedChanges$ = this.store.select(getTrainUnsavedChanges(this.id));
  }

  newItem(name: string): void {
    this.store.dispatch(trainEditorActions.newTrain({ id: this.id, name }));
  }

  loadItem(item: EditorTrain): void {
    this.store.dispatch(trainEditorActions.loadTrain({ id: this.id, original: item }));
  }

  saveItem(): SelfCompletingObservable<boolean> {
    return this.saveTrain();
  }

  override saveItemDirect(item: EditorTrain): SelfCompletingObservable<any> {
    throw new Error('Method not implemented.');
  }

  getItemName(): string {
    return this.train?.value?.name || '';
  }

  duplicateItem(item: EditorTrain, newName?: string): SelfCompletingObservable<any> {
    const train = cloneDeep(item);
    if (train.id !== this.id) {
      train.id = this.id;
    }
    train.trainId = undefined;
    train.name = newName;
    train.version = 1;
    const dialogData: SuccessFailedDialogData = {
      title: 'Could not duplicate Train',
      id: 'DUPLICATE_FAILED',
      successMessage: 'Train Duplicated'
    };
    return this.trainEditDataService.saveTrain(train, this.authService.getLoggedInUser(), HISTORY_TYPE_COPIED).pipe(
      tap(result => {
        if (result) {
          this.consistDataService.reloadData();
        }
      }),
      tap(_ => this.displayResult(true, dialogData)),
      catchError(_ => this.displayResult(false, dialogData))
    );
  }

  deleteItem(item: EditorTrain, reload = false): SelfCompletingObservable<any> {
    const dialogData: SuccessFailedDialogData = {
      title: 'Could not delete Train',
      id: 'DELETE_FAILED',
      successMessage: 'Train Deleted'
    };
    return this.trainEditDataService.deleteTrain(item.trainId).pipe(
      tap(destroyed => {
        if (destroyed && reload) {
          this.consistDataService.reloadData();
        }
      }),
      tap(result => this.displayResult(result, dialogData)),
      catchError(_ => this.displayResult(false, dialogData))
    );
  }

  override data(): Observable<EditorTrain> {
    return this.train.pipe(shareReplayOne());
  }

  override get data$(): Observable<EditorTrain> {
    return this.train.pipe(shareReplayOne());
  }

  override destroy(): SuperCalled {
    this.train.complete();
    this.store.dispatch(trainEditorActions.trainClosed({ id: this.id }));
    return super.destroy();
  }

  /**
   * Saving a train will automatically reload the data and show success / failure snackbars.
   */
  public save(): SelfCompletingObservable<boolean> {
    return this.saveTrain();
  }

  public undo(): void {
    this.store.dispatch(trainEditorActions.trainUndo({ id: this.id }));
  }

  public redo(): void {
    this.store.dispatch(trainEditorActions.trainRedo({ id: this.id }));
  }

  private saveTrain(): SelfCompletingObservable<boolean> {
    const dialogData: SuccessFailedDialogData = {
      title: 'Could not save Train',
      id: 'SAVE_FAILED',
      successMessage: 'Train Saved'
    };
    const train$ = this.train.asObservable();
    const oldTrain$ = this.consistDataService.getTrain(this.id);
    return zip(oldTrain$.pipe(first()), train$.pipe(takeOneTruthy())).pipe(
      switchMap(([oldTrain, train]) => {
        const updatedTrain = cloneDeep(train);
        let historyType: HistoryType = HISTORY_TYPE_CREATED;
        if (oldTrain) {
          updatedTrain.version = oldTrain.version + 1;
          historyType = HISTORY_TYPE_MODIFIED;
        }
        return this.trainEditDataService.saveTrain(updatedTrain, this.authService.getLoggedInUser(), historyType).pipe(
          tap(result => {
            if (result) {
              const trainId = Number(result);
              if (!isNaN(trainId)) {
                this.store.dispatch(trainEditorActions.saveTrain({ id: updatedTrain.id, save: updatedTrain, trainId }));
                this.consistDataService.reloadData();
              }
            }
          }),
          tap(_ => this.displayResult(true, dialogData)),
          catchError(error => this.handleError(error, dialogData))
        );
      })
    );
  }

  private handleError(error: any, dialogData: SuccessFailedDialogData): SelfCompletingObservable<any> {
    dialogData.failedMessage = error?.error;
    return this.displayResult(false, dialogData);
  }

  private displayResult(result: any, dialogData: SuccessFailedDialogData): SelfCompletingObservable<any> {
    if (result) {
      this.zone.run(() => {
        // snackbar needs to run in zone
        this.snackbar.open(this.translateService.instant(t(dialogData.successMessage)), '', { duration: 3000 });
      });
    } else {
      const promptData = new PromptDialogData();
      promptData.title = t(dialogData.title);
      // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
      promptData.content = dialogData?.failedMessage ? t(dialogData.failedMessage) : t('Please contact an administrator.');
      promptData.buttons = OK_BUTTON;
      PromptDialogComponent.open(this.dialog, { id: dialogData.id, data: promptData });
    }
    return selfCompletingObservable(result);
  }

  /**
   * WARNING: setting a new train type will WIPE your vehicles!
   *
   * @param trainType the new train type
   */
  public setTrainType(trainType: TrainType): void {
    trainType = trainType ?? null;

    const prevTrainType = this.train.getValue()?.trainType;

    if (!(prevTrainType === undefined && trainType === null) && !isEqual(prevTrainType, trainType)) {
      this.store.dispatch(trainEditorActions.setTrainType({ id: this.id, trainType }));
    }
  }

  public addVehicle(carClass: CarClass): void {
    this.store.dispatch(trainEditorActions.addVehicle({ id: this.id, carClass }));
  }

  public updateTrainConfig(vehicles: EditorConsistVehicle[]): void {
    this.store.dispatch(trainEditorActions.updateTrainConfig({ id: this.id, vehicles }));
  }

  public setTrainName(name: string): void {
    this.store.dispatch(trainEditorActions.setTrainName({ id: this.id, name }));
  }

  public savedTrainName$(): Observable<string> {
    return this.store.select(getSavedTrainName(this.id));
  }

  updateSaveDisabled(saveDisabled: boolean): void {
    this.saveDisabled = saveDisabled;
  }
}
