/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, Injectable, NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Store } from '@ngrx/store';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LmsService } from '@oksygen-sim-core-libraries/components-services/lms';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { EditorManagementService } from '@oksygen-sim-train-libraries/components-services/editors';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { EditorTrain } from '../../models/train-editor.model';
import { TrainEditorState } from '../../store/train-editor.state';
import { TrainEditDataService } from '../rest/train-edit-data.service';
import { TrainEditorContext } from '../train-editor-context';
import { TrainEditManager } from './train-edit.manager';
import { TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN } from '../../tokens/train-editor.token';

@Injectable()
export class TrainEditService extends EditorManagementService<TrainEditorState, EditorTrain, TrainEditorContext, TrainEditManager> {
  constructor(
    dataAccessService: DataAccessService,
    authService: AuthService,
    store: Store<TrainEditorState>,
    registry: Registry,
    logger: Logging,
    lmsService: LmsService,
    dialog: MatDialog,
    translateService: TranslateService,
    snackbar: MatSnackBar,
    zone: NgZone,
    private trainEditDataService: TrainEditDataService,
    @Inject(TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN) private consistDataService: ConsistDataService
  ) {
    super(dataAccessService, authService, store, registry, logger, lmsService, dialog, translateService, snackbar, zone, trainEditDataService);
  }
  newManager(id: string | number): TrainEditManager {
    return new TrainEditManager(
      `${id}`,
      this.store,
      this.authService,
      this.dialog,
      this.translateService,
      this.snackbar,
      this.zone,
      this.logger,
      this.trainEditDataService,
      this.consistDataService
    );
  }
}
