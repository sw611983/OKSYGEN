/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TestBed } from '@angular/core/testing';
import { MatSnackBar } from '@angular/material/snack-bar';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainTrainEditModule } from '../../trains-edit.module';
import { TrainEditDataService } from '../rest/train-edit-data.service';
import { TrainEditService } from './train-edit.service';
import { TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN } from '../../tokens/train-editor.token';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';

describe('TrainEditService', () => {
  let service: TrainEditService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainTrainEditModule],
      providers: [TrainEditDataService, TrainEditService, MatSnackBar, {
        provide: TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN,
        useExisting: ConsistDataService
      }]
    });
    service = TestBed.inject(TrainEditService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
