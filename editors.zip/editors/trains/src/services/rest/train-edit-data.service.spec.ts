/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TestBed } from '@angular/core/testing';

import { TrainEditDataService } from './train-edit-data.service';

describe('TrainEditDataService', () => {
  let service: TrainEditDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [TrainEditDataService] });
    service = TestBed.inject(TrainEditDataService);
  });

  xit('should be created', () => {
    expect(service).toBeTruthy();
  });
});
