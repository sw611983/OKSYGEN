/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, Injectable } from '@angular/core';
import { HistoryType, momentToString, SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { AbstractDataService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { User } from '@oksygen-sim-core-libraries/components-services/users';
import { ConsistDataService, ConsistVehicleOrientation, VehicleOrientation } from '@oksygen-sim-train-libraries/components-services/trains';
import moment from 'moment';
import { EditorTrain } from '../../models/train-editor.model';
import { TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN, TRAIN_EDITOR_DATA_ACCESS_SERVICE_TOKEN } from '../../tokens/train-editor.token';

export enum TrainEditorMessageId {
  CREATE_TRAIN = 1,
  DELETE_TRAIN = 2,
  EDIT_TRAIN = 3
}

interface TrainDefinition {
  uuid: string;
  trainId: number;
  trainDescription: string;
  trainType: string;
  version: number;
  authorFirstName: string;
  authorLastName: string;
  timeStamp: string;
  historyType: string;
  trainElements: TrainElements[];
}

interface TrainElements {
  carId: number;
  loading: number;
  position: number;
  serialNumber: number;
  orientation: string;
}

@Injectable()
export class TrainEditDataService extends AbstractDataService<EditorTrain[]> {
  private url: string;

  constructor(
    logging: Logging,
    registry: Registry,
    @Inject(TRAIN_EDITOR_DATA_ACCESS_SERVICE_TOKEN) dataAccessService: DataAccessService,
    @Inject(TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN) private consistDataService: ConsistDataService
  ) {
    super(logging, registry, dataAccessService);
    this.url = this.registry.getString(['trainEditorData', 'trainEditorUrl']);
    this.initialise();
  }

  override reloadData(): void {
    this.consistDataService.reloadData();
  }

  /**
   * Populate message for train creation/updation and invokes create/update train API.
   * @returns train id in the Observable
   */
  public saveTrain(train: EditorTrain, loggedInUser: User, historyType: HistoryType): SelfCompletingObservable<any> {
    const trainElementsDefinition = this.getTrainDefinition(train, loggedInUser, historyType);
    const createTrainDefinition = {
      messageId: train?.trainId ? TrainEditorMessageId.EDIT_TRAIN : TrainEditorMessageId.CREATE_TRAIN,
      message: trainElementsDefinition
    };
    return this.dataAccessService.saveData({
      path: this.url,
      data: createTrainDefinition,
      type: 'POST',
      debugMsg: 'Creating/updating train in DB'
    });
  }

  public deleteTrain(trainId: number): SelfCompletingObservable<any> {
    const deleteTrainDefinition = {
      messageId: TrainEditorMessageId.DELETE_TRAIN,
      message: { trainId }
    };
    return this.dataAccessService.saveData({
      path: this.url,
      data: deleteTrainDefinition,
      type: 'POST',
      debugMsg: 'Deleting train in DB'
    });
  }

  /**
   * Populates train element definition.
   */
  private getTrainDefinition(train: EditorTrain, loggedInUser: User, historyType: HistoryType): TrainDefinition {
    const trainDefinition: TrainDefinition = {
      uuid: train.id,
      trainId: train.trainId,
      trainDescription: train.name,
      trainType: train.trainType.name,
      version: train.version,
      timeStamp: momentToString(moment()),
      authorFirstName: loggedInUser.firstName,
      authorLastName: loggedInUser.lastName,
      historyType,
      trainElements: train.vehicles.map((v, i) => ({
        carId: v.carClass.carClassId,
        loading: v.loading,
        position: i,
        serialNumber: v.serialNumber,
        // eslint-disable-next-line no-underscore-dangle
        orientation: v.orientation === ConsistVehicleOrientation._1_2 ? VehicleOrientation.ORIENTATION_1_2 : VehicleOrientation.ORIENTATION_2_1
      }))
    };
    return trainDefinition;
  }
}
