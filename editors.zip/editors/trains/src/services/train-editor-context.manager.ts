/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, Injectable } from '@angular/core';

import { SelectedFilterArray } from '@oksygen-common-libraries/material/components';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { ContextManager } from '@oksygen-sim-train-libraries/components-services/common';
import { ConsistDataService, TrainTypeService } from '@oksygen-sim-train-libraries/components-services/trains';

import { map } from 'rxjs/operators';
import { TrainEditorFilterType, TrainEditorUiState } from '../models/train-editor.model';
import { TrainEditorContext } from './train-editor-context';
import { TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN } from '../tokens/train-editor.token';

/**
 * A ContextManager for the Train Editor.
 */
@Injectable()
export class TrainEditorContextManager extends ContextManager<string, TrainEditorContext> {
  constructor(@Inject(TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN) private consistDataService: ConsistDataService, private trainTypeService: TrainTypeService) {
    super();
  }

  protected createContext(id: string): TrainEditorContext {
    const context = new TrainEditorContext();
    context.uiState = new UiStateModelManager();
    context.uiState.getStateModel<TrainEditorUiState>('list', () => ({
      filters: {
        groups: [],
        search: '',
        selectedFilters: new SelectedFilterArray<TrainEditorFilterType>()
      }
    }));
    context.trainTypes$ = this.trainTypeService.data().pipe(map(tt => Array.from(tt.values())));
    context.trains$ = this.consistDataService.data().pipe(map(t => Array.from(t.values())));
    return context;
  }
}
