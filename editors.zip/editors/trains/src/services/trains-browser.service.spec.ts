/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TestBed } from '@angular/core/testing';

import { TrainsBrowserService } from './trains-browser.service';

describe('TrainsBrowserServiceService', () => {
  let service: TrainsBrowserService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [TrainsBrowserService] });
    service = TestBed.inject(TrainsBrowserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
