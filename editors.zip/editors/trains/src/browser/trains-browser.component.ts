/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { BehaviorSubject, combineLatest, Observable, of, Subscription } from 'rxjs';
import { first } from 'rxjs/operators';

import { SelfCompletingObservable, SuperCalled } from '@oksygen-common-libraries/common';
import {
  allFilterTypesMatch,
  BasicSingleInputDialogComponent,
  BasicSingleInputDialogData,
  BasicSingleInputDialogInput,
  BasicTabNavItem,
  BasicTabNavItemComponent,
  Breadcrumb,
  ButtonInfo,
  CANCEL_BUTTON,
  FileManagerTableComponent,
  FileManagerTableData,
  Filter,
  filterMatches,
  illegalNameCharacterExists,
  newFormControl,
  PromptDialogComponent,
  PromptDialogData,
  SelectedFilterArray,
  SideNavService,
  TabGroupChild,
  TabService,
  UpdateOn
} from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { User, UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import {
  BrowserFilterText,
  BrowserState,
  EditorBrowserFilterIOConfig,
  EditorBrowserTableStatus,
  newName
} from '@oksygen-sim-train-libraries/components-services/common';
import { BaseLockableBrowserTabPage, EditorLock, LockDatabaseService } from '@oksygen-sim-train-libraries/components-services/editors';
import { Consist, ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';

import { Scenario, ScenarioService } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { EditorTrain, TrainEditorTabType, TRAINS_CARD_DATA, trainStatus, TrainTableData, trainToTable } from '../models/train-editor.model';
import { TrainEditService } from '../services/train-edit/train-edit.service';
import { TrainEditorContextManager } from '../services/train-editor-context.manager';
import { TrainsBrowserService } from '../services/trains-browser.service';
import { TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN } from '../tokens/train-editor.token';
import { DeletableTrainDetails, TrainsDeleteDialogComponent } from './trains-delete-dialog/trains-delete-dialog.component';

interface TrainFilterFields extends BrowserFilterText {
  authorText: string;
  trainText: string;
  trainTypeText: string;
}

enum TrainFilterIcons {
  // names of the icons in the filtering of trains
  TRAIN = 'train',
  AUTHOR = 'author'
}

enum TrainInUseDialogResult {
  DUPLICATE = 1
}

function warnTrainInUsePromptDialogData(scenarioNames: string[], isEdit: boolean): PromptDialogData {
  const promptData = new PromptDialogData();

  const actionWord = isEdit ? 'edited' : 'deleted';

  promptData.title =
    scenarioNames.length > 1
      ? t(`This train is currently in use by the following scenarios, so it cannot be ${actionWord}.`)
      : t(`This train is currently in use by the following scenario, so it cannot be ${actionWord}.`);

  promptData.content = scenarioNames.length > 1 ? scenarioNames : `<b>${scenarioNames}</b>`;

  // Configure buttons based on the operation type
  promptData.buttons = isEdit
    ? [
        {
          color: MaterialThemePalette.PRIMARY,
          text: t('Duplicate'),
          data: TrainInUseDialogResult.DUPLICATE
        },
        CANCEL_BUTTON
      ]
    : [CANCEL_BUTTON];

  return promptData;
}

@Component({
  templateUrl: './trains-browser.component.html',
  styleUrls: ['./trains-browser.component.scss']
})
export class TrainsBrowserComponent extends BaseLockableBrowserTabPage<EditorTrain, TrainTableData, TrainFilterFields, string> implements OnInit, OnDestroy {
  readonly DEFAULT_TRAIN_TEMPLATE_NAME: string = t('New train');
  readonly DUPLICATE_TRAIN_NAME_ERROR: string = t('A train with this name already exists.');
  readonly MISSING_TRAIN_NAME_ERROR: string = t('A train name is required.');
  readonly SPACES_TRAIN_NAME_ERROR: string = t('A train name cannot have leading or trailing spaces.');
  readonly SPECIAL_CHARACTER_TRAIN_NAME_ERROR: string = t('A train name cannot have the special characters " < % > * | ? :');
  readonly BREADCRUMB: Breadcrumb = {
    text: t('Trains'),
    icon: 'train'
  };
  @ViewChild(FileManagerTableComponent) fileManagerTable: FileManagerTableComponent<TrainTableData>;

  private masterSubscription = new Subscription();

  private scenarioList: Scenario[];

  constructor(
    public trainsBrowserService: TrainsBrowserService,
    sideNavService: SideNavService,
    router: Router,
    tabService: TabService,
    logger: Logging,
    translateService: TranslateService,
    private dialog: MatDialog,
    lockService: LockDatabaseService,
    authService: AuthService,
    private uiStateModelManager: UiStateModelManager,
    private registry: Registry,
    private userService: UserService,
    @Inject(TRAIN_EDITOR_CONSIST_DATA_SERVICE_TOKEN) private consistDataService: ConsistDataService,
    private trainEditService: TrainEditService,
    private dataService: TrainEditorContextManager,
    private cd: ChangeDetectorRef,
    private scenarioService: ScenarioService
  ) {
    super(
      {
        create: { visible: true, enabled: true },
        delete: { visible: true, enabled: true },
        duplicate: { visible: true, enabled: true },
        edit: { visible: false, enabled: false },
        open: { visible: true, enabled: true },
        search: { visible: true, enabled: true },
        refresh: { visible: true, enabled: true }
      },
      trainsBrowserService,
      sideNavService,
      router,
      TRAINS_CARD_DATA,
      tabService,
      logger,
      translateService,
      lockService,
      authService,
      dialog
    );
    this.refreshDisabled.set(false);
  }

  override ngOnInit(): SuperCalled {
    const superCalled = super.ngOnInit();
    this.pageOpening();
    this.loadLocks(this.registry);
    this.state = this.uiStateModelManager.getStateModel<any>('TrainsBrowserComponent', () => ({
      filters: {
        authorText: '',
        faultText: '',
        selectedFilters: new SelectedFilterArray<string>()
      }
    }));
    const dataSub = combineLatest([this.consistDataService.data(), this.lockService.getEditorLocks(this.editorName()), this.scenarioService.data()]).subscribe(
      ([consist, locks, scenarios]) => {
        this.data.set(
          consist?.map((item: Consist) => ({
            id: item.uuid,
            trainId: item.id,
            name: item.name,
            trainType: item.trainType,
            vehicles: item.vehicles,
            history: item.history,
            version: item.version,
            editable: item.editable
          })) ?? []
        );
        this.scenarioList = scenarios;
        this.locks.set(locks ?? []);
        this.cd.detectChanges(); // updating the file manager double triggers CD which gives the changed after checked err
        this.fileManagerTable?.applyFilter();
      }
    );
    this.masterSubscription.add(dataSub);
    const trainsTab: TabGroupChild<BasicTabNavItem> = {
      data: {
        id: TRAINS_CARD_DATA.id,
        groupId: TRAINS_CARD_DATA.id,
        icon: OksygenIcon.FILE_MANAGER,
        routerLink: TRAINS_CARD_DATA.routerLink,
        name: t('Manager'),
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => of(true),
        onClose: () => {
          this.tabClosing();
          this.clearFilters();
        }
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: TRAINS_CARD_DATA.id,
        groupName: TRAINS_CARD_DATA.name,
        route: TRAINS_CARD_DATA.routerLink,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [trainsTab],
      childrenIndex: 0
    });
    return superCalled;
  }

  override onUnlock(): void {
    this.lockService.deleteDatabaseLock(this.selectedLock.id, this.selectedLock.editor).subscribe(() => this.loadLocks(this.registry));
  }

  override editorName(): string {
    return 'train';
  }

  protected override toTableData(data: EditorTrain[], locks?: EditorLock[]): TrainTableData[] {
    const tableData: TrainTableData[] =
      data?.map(train => {
        const locked = !!locks?.find(lock => lock.editor === this.editorName() && lock.id === train.id);
        const status: EditorBrowserTableStatus = trainStatus(train, this.scenarioList);
        const tablified = trainToTable(this.userService, train, locked, status);
        const selectedData = this.editorService.getSelectedTableData()?.find(selected => selected?.name === train.name);
        tablified.fmtChecked = !!selectedData?.fmtChecked;
        tablified.fmtSelected = !!selectedData?.fmtSelected;
        return tablified;
      }) ?? [];
    return tableData;
  }

  override sorterFunction(trainKey: string, a: TrainTableData, b: TrainTableData): number {
    switch (trainKey) {
      case 'name': {
        return a.name.localeCompare(b.name, this.getCurrentLocale());
      }
      case 'train': {
        return a.name.localeCompare(b.name, this.getCurrentLocale());
      }
      case 'created': {
        return a.created.date.isBefore(b.created.date) ? 1 : -1;
      }
      case 'modified': {
        return a.modified.date.isBefore(b.modified.date) ? 1 : -1;
      }
      case 'status': {
        return a.status.localeCompare(b.status, this.getCurrentLocale());
      }
      default: {
        return 0;
      }
    }
  }

  override onImport(): void {
    throw new Error('Method not implemented.');
  }

  override onExport(): void {
    throw new Error('Method not implemented.');
  }

  override onEdit(item: EditorTrain): void {
    const startEditing = (): void => {
      this.trainEditService.loadItem(item);
      this.startEditing(item.id);
    };
    if (this.selectedTableData().status === 'In Use') {
      this.promptTrainInUse(item, true);
    } else {
      startEditing();
    }
  }

  private promptTrainInUse(item: EditorTrain, isEdit: boolean): void {
    const id = 'TRAIN_IN_USE_WARNING';
    const usedScenarios = this.scenarioList
      ?.filter(s => s.scenarioTrains?.scenarioTrain?.find(sTrain => sTrain.trainDescription === item.name))
      .map(s => s.name);
    const promptData = warnTrainInUsePromptDialogData(usedScenarios, isEdit);
    PromptDialogComponent.open(
      this.dialog,
      {
        id,
        data: promptData,
        width: '400px',
        panelClass: 'small-whitespace-dialog'
      },
      result => {
        if (result === TrainInUseDialogResult.DUPLICATE) {
          this.duplicateAndEdit();
        }
      }
    );
  }

  private duplicateAndEdit(): void {
    const existingNames = this.data().map(s => s.name);
    const name = newName(`${this.selectedItem().name} - ${this.COPY}`, this.translateService, existingNames);
    const duplicateNameError = 'duplicateName';
    const missingError = 'missing';
    const spacesError = 'spaces';
    const specialCharacterError = 'specialCharacter';
    const duplicateFormControl = newFormControl(UpdateOn.CHANGE, c => {
      if (c.value) {
        const match = this.data().find(s => s.name === c.value);
        const exists = !!match;
        if (exists) {
          return { [duplicateNameError]: true };
        } else if (c.value?.trim() !== c.value) {
          return { [spacesError]: true };
        } else if (illegalNameCharacterExists(c.value)) {
          return { [specialCharacterError]: true };
        }
      } else {
        return { [missingError]: true };
      }
      return null;
    });

    duplicateFormControl.setValue(name);
    const buttons: ButtonInfo[] = [
      CANCEL_BUTTON,
      {
        color: MaterialThemePalette.PRIMARY,
        text: t('Duplicate'),
        data: true,
        disableOnError: true
      }
    ];
    const input: BasicSingleInputDialogInput = {
      appearance: 'outline',
      floatLabel: 'always',
      label: t('Name'),
      inputFormControl: duplicateFormControl,
      formControlErrors: [
        // TODO: Possibly put these two messages in a shared place (they're copied from scenario-detail-panel)
        {
          type: duplicateNameError,
          text: this.DUPLICATE_TRAIN_NAME_ERROR
        },
        {
          type: missingError,
          text: this.MISSING_TRAIN_NAME_ERROR
        },
        {
          type: spacesError,
          text: this.SPACES_TRAIN_NAME_ERROR
        },
        {
          type: specialCharacterError,
          text: this.SPECIAL_CHARACTER_TRAIN_NAME_ERROR
        }
      ]
    };
    const data = new BasicSingleInputDialogData(t('Duplicate'), buttons, input);
    BasicSingleInputDialogComponent.open(this.dialog, data, result => {
      if (result.buttonData) {
        this.trainEditService.duplicateItem(this.selectedItem(), result.value).then(duplicatedItemId => {
          // once we duplicate the item, the manager automatically refreshes our list.
          // we need to wait for this refresh to occur before we can edit the template
          const subscription = this.consistDataService.data().subscribe(consists => {
            const newItem = consists.find(d => d.uuid === duplicatedItemId);
            const editorTrain = {
              id: newItem.uuid,
              trainId: newItem.id,
              name: newItem.name,
              trainType: newItem.trainType,
              vehicles: newItem.vehicles,
              history: newItem.history,
              version: newItem.version,
              editable: newItem.editable
            };
            if (editorTrain) {
              this.trainEditService.loadItem(editorTrain);
              this.startEditing(editorTrain.id);
              subscription?.unsubscribe();
            }
          });
        });
      }
    });
  }

  override onDelete(item: EditorTrain | EditorTrain[]): void {
    const selectedValues = this.fileManagerTable.getSelectedValues();
    if (Array.isArray(item) && selectedValues.length === 1 && selectedValues.some(train => train.status === 'In Use')) {
      this.promptTrainInUse(item[0], false);
    } else {
      if (Array.isArray(item)) {
        const inUseTrains = selectedValues.filter(train => train.status === 'In Use');
        const deletableTrains = this.getDeletableTrains(inUseTrains, item);
        this.deleteTrainsDialog(deletableTrains).subscribe(result => {
          // It returns a list of deletable trains name
          if (result?.length > 0) {
            const deletableItems = this.data().filter(tr => result.includes(tr.name));
            const sub = this.trainEditService.deleteItems(deletableItems, true);
            sub.subscribe(results => {
              // It returns a string if it succeeded, false if it failed
              if (results) {
                deletableItems.forEach(deletedItem => {
                  if (this.tabService.getTabGroupItem(TRAINS_CARD_DATA.id, deletedItem.id.toString())) {
                    this.tabService.removeItemFromTabGroup(TRAINS_CARD_DATA.id, { id: deletedItem.id.toString() }, true);
                    this.destroyManagers(deletedItem.id);
                  }
                });
              }
            });
          }
        });
      } else {
        const inUseTrains = selectedValues.filter(train => train.status === 'In Use');
        const deletableTrains = this.getDeletableTrains(inUseTrains, [item]);
        this.deleteTrainsDialog(deletableTrains).subscribe(result => {
          // It returns a list of deletable trains name
          if (result?.length > 0 && result.includes(item.name)) {
            const subs: SelfCompletingObservable<any>[] = [];
            const sub = this.trainEditService.deleteItem(item, true);
            sub.subscribe(results => {
              // It returns a string if it succeeded, false if it failed
              if (results) {
                if (this.tabService.getTabGroupItem(TRAINS_CARD_DATA.id, item.id.toString())) {
                  this.tabService.removeItemFromTabGroup(TRAINS_CARD_DATA.id, { id: item.id.toString() }, true);
                  this.destroyManagers(item.id);
                }
              }
            });
            subs.push(sub);
            combineLatest(subs).subscribe(results => {});
          }
        });
      }
    }
  }

  private deleteTrainsDialog(trains: DeletableTrainDetails[]): Observable<string[]> {
    const dialogRef = this.dialog.open<TrainsDeleteDialogComponent, any, string[]>(TrainsDeleteDialogComponent, {
      disableClose: true,
      minHeight: '200px',
      minWidth: '600px',
      data: { trains }
    });

    return dialogRef.afterClosed();
  }

  private getDeletableTrains(inUseTrains: TrainTableData[], editorTrains: EditorTrain[]): DeletableTrainDetails[] {
    const deletableTrains: DeletableTrainDetails[] = [];
    editorTrains.forEach(train => {
      if (!train.editable || inUseTrains.some(ut => ut.name === train.name)) {
        deletableTrains.push({ id: train.id, name: train.name, canDelete: false });
      } else {
        deletableTrains.push({ id: train.id, name: train.name, canDelete: true });
      }
    });
    return deletableTrains;
  }

  override onPrint(item: EditorTrain | EditorTrain[]): void {
    throw new Error('Method not implemented.');
  }

  override onDuplicate(item: EditorTrain): void {
    this.promptDuplicateName(item)
      .pipe(first())
      .subscribe(name => {
        this.trainEditService.duplicateItem(item, name);
      });
  }

  override onCreate(): void {
    const existingNames = this.tableData().map(td => td.name);
    const name = newName('New Train', this.translateService, existingNames);
    this.trainEditService.newItem(name).then(id => this.startEditing(id));
  }

  private startEditing(id: string): void {
    const url = TRAINS_CARD_DATA.routerLink + '/' + id;
    this.router.navigateByUrl(url);
    const trainTabData: TrainEditorTabType = {
      data: {
        groupId: TRAINS_CARD_DATA.id,
        icon: 'file_new',
        id: id.toString(),
        routerLink: url,
        name: id === this.selectedItem()?.id ? this.selectedItem()?.name : t('New Train'),
        destroyGroupOnAllCleared: true,
        // FIXME @@@ implement confirm/save dialog
        preCloseCheck: () => this.trainEditService.confirmCloseEditor(id),
        onClose: () => this.destroyManagers(id)
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: TRAINS_CARD_DATA.id,
        groupName: TRAINS_CARD_DATA.name,
        route: TRAINS_CARD_DATA.routerLink,
        groupIcon: TRAINS_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [trainTabData]
    });
    this.lockEditorItem(id);
  }

  private destroyManagers(id: string): void {
    this.trainEditService.destroyManagers(id);
    this.dataService.destroyContext(id);
    if (this.lockService.isEnabled(this.editorName())) {
      this.lockService.deleteDatabaseLock(id, this.editorName()).subscribe(() => this.loadLocks(this.registry));
    }
  }

  override onRefresh(): void {
    this.consistDataService.reloadData();
    this.loadLocks(this.registry);
  }

  protected override initialiseState(): BrowserState<TrainFilterFields, string> {
    return this.uiStateModelManager.getStateModel<any>('TrainsBrowserComponent', () => ({
      filters: {
        authorText: '',
        faultText: '',
        selectedFilters: new SelectedFilterArray<string>()
      }
    }));
  }

  protected override initialiseFilterConfig(): EditorBrowserFilterIOConfig<EditorTrain>[] {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;
    const trainFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: TrainFilterIcons.TRAIN,
        placeholder: 'Trains',
        value: this.state.filters.trainText
      },
      outputs: {
        currentValue: this.onTrainTextChange.bind(self),
        selectedValue: this.addTrainFilter.bind(self)
      }
    };
    const trainTypeFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: TrainFilterIcons.TRAIN,
        placeholder: 'Train Types',
        value: this.state.filters.trainTypeText
      },
      outputs: {
        currentValue: this.onTrainTypeTextChange.bind(self),
        selectedValue: this.addTrainTypeFilter.bind(self)
      }
    };
    const authorFilter: EditorBrowserFilterIOConfig<User> = {
      inputs: {
        icon: 'author',
        placeholder: 'Author',
        value: this.state.filters.authorText
      },
      outputs: {
        currentValue: this.onAuthorTextChange.bind(self),
        selectedValue: this.addAuthorFilter.bind(self)
      }
    };
    const filterConfig: EditorBrowserFilterIOConfig<any>[] = [trainFilter, trainTypeFilter, authorFilter];
    return filterConfig;
  }

  onTrainTextChange(text: string): void {
    this.state.filters.trainText = text;
    this.fileManagerTable.applyFilter();
  }

  onAuthorTextChange(text: User | string): void {
    this.state.filters.authorText = typeof text === 'object' ? `${text.firstName} ${text.lastName}` : text;
    this.fileManagerTable.applyFilter();
  }

  addAuthorFilter(value: User): void {
    const name = typeof value === 'object' ? `${value.firstName} ${value.lastName}` : value;
    this.state.filters.selectedFilters.push(new Filter(TrainFilterIcons.AUTHOR, name));
    this.fileManagerTable.applyFilter();
  }

  addTrainFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(TrainFilterIcons.TRAIN, value));
    this.fileManagerTable.applyFilter();
  }

  onTrainTypeTextChange(text: string): void {
    this.state.filters.trainTypeText = text;
    this.fileManagerTable.applyFilter();
  }

  addTrainTypeFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(TrainFilterIcons.TRAIN, value));
    this.fileManagerTable.applyFilter();
  }

  initialiseColumns(): FileManagerTableData[] {
    const columns: FileManagerTableData[] = [];
    return columns;
  }

  initialiseDisplayedColumns(): string[] {
    const columns: string[] = ['name', 'trainType', 'created', 'modified', 'status' /*, 'version'*/];
    return columns;
  }

  applyFilters(train: TrainTableData): boolean {
    const names = [train.name];
    const types = [train.trainTypeName];
    const authors = [train.created?.name, train.modified?.name];

    if (
      !allFilterTypesMatch(
        [
          { t: TrainFilterIcons.TRAIN, v: names },
          { t: TrainFilterIcons.TRAIN, v: types },
          { t: TrainFilterIcons.AUTHOR, v: authors }
        ],
        this.state.filters.selectedFilters
      )
    ) {
      return false;
    }

    if (!filterMatches(names, this.state.filters.trainText)) {
      return false;
    }

    if (!filterMatches(types, this.state.filters.trainTypeText)) {
      return false;
    }

    if (!filterMatches(authors, this.state.filters.authorText)) {
      return false;
    }

    return true;
  }

  protected override getItemFromTableItem(data: TrainTableData): EditorTrain {
    if (!data || !this.data) {
      return null;
    }
    // displayName must be unique!
    return this.data().find(train => train.name === data.name);
  }

  onFilterChange(): void {
    this.fileManagerTable.applyFilter();
  }

  ngOnDestroy(): void {
    this.pageClosing();
    this.setSelectedTableData();
    this.masterSubscription.unsubscribe();
  }

  private promptDuplicateName(train: EditorTrain): Observable<string> {
    const existingNames = this.data().map(s => s.name);
    const name = newName(`${train.name} - ${this.COPY}`, this.translateService, existingNames);
    const duplicateNameError = 'duplicateName';
    const missingError = 'missing';
    const spacesError = 'spaces';
    const specialCharacterError = 'specialCharacter';
    const duplicateFormControl = newFormControl(UpdateOn.CHANGE, c => {
      if (c.value) {
        const match = this.data().find(s => s.name === c.value);
        const exists = !!match;
        if (exists) {
          return { [duplicateNameError]: true };
        } else if (c.value?.trim() !== c.value) {
          return { [spacesError]: true };
        } else if (illegalNameCharacterExists(c.value)) {
          return { [specialCharacterError]: true };
        }
      } else {
        return { [missingError]: true };
      }
      return null;
    });

    duplicateFormControl.setValue(name);
    const buttons: ButtonInfo[] = [
      CANCEL_BUTTON,
      {
        color: MaterialThemePalette.PRIMARY,
        text: t('Duplicate'),
        data: true,
        disableOnError: true
      }
    ];
    const input: BasicSingleInputDialogInput = {
      appearance: 'outline',
      floatLabel: 'always',
      label: t('Name'),
      inputFormControl: duplicateFormControl,
      formControlErrors: [
        // TODO: Possibly put these two messages in a shared place
        // (they're copied from rule-browser.component which is itself copied from scenario-detail-panel)
        {
          type: duplicateNameError,
          text: this.DUPLICATE_TRAIN_NAME_ERROR
        },
        {
          type: missingError,
          text: this.MISSING_TRAIN_NAME_ERROR
        },
        {
          type: spacesError,
          text: this.SPACES_TRAIN_NAME_ERROR
        },
        {
          type: specialCharacterError,
          text: this.SPECIAL_CHARACTER_TRAIN_NAME_ERROR
        }
      ]
    };
    const data = new BasicSingleInputDialogData(t('Duplicate'), buttons, input);
    return new Observable(o => {
      BasicSingleInputDialogComponent.open(this.dialog, data, result => {
        if (result?.buttonData) {
          o.next(result.value);
          o.complete();
        }
      });
    });
  }

  override selectionChanged(): void {
    super.selectionChanged();
    // Prevent editing for non-editable trains
    const selectedValues = this.fileManagerTable.getSelectedValues();
    if (selectedValues.length === 1) {
      this.detailEditDisabled.set(!this.selectedItem()?.editable);
      this.editDisabled.set(!this.selectedItem()?.editable);
      this.deleteDisabled.set(!this.selectedItem()?.editable);
      this.detailDeleteDisabled.set(!this.selectedItem()?.editable);
    }
  }

  override onPublish(item: EditorTrain | EditorTrain[], isActive: boolean): void {
    throw new Error('Method not implemented.');
  }
}
