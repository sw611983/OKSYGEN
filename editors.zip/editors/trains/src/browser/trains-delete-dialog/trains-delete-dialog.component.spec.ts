/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainsDeleteDialogComponent } from './trains-delete-dialog.component';

describe('TrainsDeleteDialogComponent', () => {
  let component: TrainsDeleteDialogComponent;
  let fixture: ComponentFixture<TrainsDeleteDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TrainsDeleteDialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainsDeleteDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
