/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

export interface DeletableTrainDetails {
  id: string;
  name: string;
  canDelete: boolean;
}

@Component({
  selector: 'oksygen-trains-delete-dialog',
  templateUrl: './trains-delete-dialog.component.html',
  styleUrl: './trains-delete-dialog.component.scss'
})
export class TrainsDeleteDialogComponent {
  selectedCount: number;
  deletableCount: number;
  message = t(
    // eslint-disable-next-line max-len
    'You selected {selectedCount} trains. <b>Only {deletableCount} will be deleted</b>; trains that are <b><i>In Use</i></b> or <b><i>Locked</i></b> will remain.'
  );
  configurationIcon = 'exclamation_triangle';
  title: string;
  trainData: DeletableTrainDetails[];
  displayWarning = false;

  constructor(private dialogRef: MatDialogRef<TrainsDeleteDialogComponent, string[]>, @Inject(MAT_DIALOG_DATA) launchContext: any) {
    this.trainData = launchContext.trains as DeletableTrainDetails[];
    this.selectedCount = this.trainData.length;
    this.deletableCount = this.trainData.filter(train => train.canDelete).length;
    this.title = this.trainData.length > 1 ? t('Are you sure you want to delete these trains?') : t('Are you sure you want to delete this train?');
    this.displayWarning = this.selectedCount !== this.deletableCount;
  }

  onDeleteClick(): void {
    const deletableTrains = this.trainData.filter(train => train.canDelete).map(train => train.name);
    this.dialogRef.close(deletableTrains);
  }

  onCancelClick(): void {
    this.dialogRef.close();
  }
}
