/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainDetailsPanelComponent } from './train-details-panel.component';

describe('TrainDetailsPanelComponent', () => {
  let component: TrainDetailsPanelComponent;
  let fixture: ComponentFixture<TrainDetailsPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainDetailsPanelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainDetailsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
