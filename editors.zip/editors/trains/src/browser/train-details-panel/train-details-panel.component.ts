/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Input } from '@angular/core';
import { TrainTableData } from '../../models/train-editor.model';

@Component({
  selector: 'oksygen-train-details-panel',
  templateUrl: './train-details-panel.component.html',
  styleUrls: ['./train-details-panel.component.scss']
})
export class TrainDetailsPanelComponent {
  @Input() train: TrainTableData;

  displayedVehicleColumns: string[] = ['position', 'carType', 'classCode'];

}
