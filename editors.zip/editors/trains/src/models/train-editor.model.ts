/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Data } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { EditHistory, getLastModified, HISTORY_TYPE_COPIED, HISTORY_TYPE_CREATED, UNKNOWN } from '@oksygen-common-libraries/common';
import { BasicTabNavItem, DynamicComponent, SelectedFilterArray, TabGroupChild } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { ComponentConfig, EditorBrowserTableData, EditorBrowserTableStatus } from '@oksygen-sim-train-libraries/components-services/common';
import { BaseEditorStoreItem, EditorData } from '@oksygen-sim-train-libraries/components-services/editors';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { CarClass, Consist, ConsistVehicle, TrainType } from '@oksygen-sim-train-libraries/components-services/trains';
import moment from 'moment';
import { Observable, Observer } from 'rxjs';

export const TRAINS_CARD_DATA = new EditorData(t('Trains'), '/editors/trains', OksygenIcon.TRAIN, 'trains');

export type TrainsTabType = TabGroupChild<BasicTabNavItem>;

export interface EditorTrain extends BaseEditorStoreItem {
  version: number;
  name: string;
  trainId?: number;
  trainType: TrainType;
  editable: boolean;
  vehicles: EditorConsistVehicle[];
  history?: EditorTrainHistory;
}

export interface EditorTrainHistory {
  historyLog: EditorTrainHistoryLog[];
}

export interface EditorTrainHistoryLog extends EditHistory {
  trainName: string;
  trainVersion: number;
}

export interface TrainTableData extends EditorBrowserTableData {
  id: string;
  trainTypeName: string;
  vehicles: TrainVehicleTableData[];
  editable: boolean;
}

export interface TrainVehicleTableData {
  position: number;
  type: string;
  name: string;
}

export function trainToTable(userService: UserService, train: EditorTrain, locked = false, status: EditorBrowserTableStatus = 'Unknown'): TrainTableData {
  let created = train?.history?.historyLog?.find(history => history.type === HISTORY_TYPE_CREATED);
  if (!created) {
    created = train?.history?.historyLog?.find(history => history.type === HISTORY_TYPE_COPIED);
  }

  // In case there's missing data...
  if (!created) {
    created = {
      type: HISTORY_TYPE_CREATED,
      authorFirstName: UNKNOWN,
      authorLastName: UNKNOWN,
      trainName: UNKNOWN,
      trainVersion: train.version,
      timestamp: UNKNOWN
    };
  }

  const modified: EditHistory = getLastModified(train?.history?.historyLog);

  const creator = userService.users.find(u => u.firstName === created.authorFirstName && u.lastName === created.authorLastName);
  const modifier = userService.users.find(u => u.firstName === modified.authorFirstName && u.lastName === modified.authorLastName);
  const td: TrainTableData = {
    name: train.name,
    created: {
      name:
        created.authorFirstName === UNKNOWN && created.authorLastName === UNKNOWN ? UNKNOWN : (created.authorFirstName + ' ' + created.authorLastName).trim(),
      avatar: creator?.avatar,
      date: created.timestamp === UNKNOWN ? null : moment(created.timestamp)
    },
    modified: {
      name:
        modified.authorFirstName === UNKNOWN && modified.authorLastName === UNKNOWN
          ? UNKNOWN
          : (modified.authorFirstName + ' ' + modified.authorLastName).trim(),
      avatar: modifier?.avatar,
      date: modified.timestamp === UNKNOWN ? null : moment(modified.timestamp)
    },
    status,
    id: train.id,
    trainTypeName: train?.trainType?.name,
    vehicles: train.vehicles.map((vehicle: ConsistVehicle) => ({
      name: vehicle.carClass?.description,
      position: vehicle.position,
      type: vehicle.carClass.carType
    })),
    editable: train.editable
  };
  td.locked = locked;
  return td;
}

export interface TrainEditorUiState {
  filters: {
    groups: { name: string; displayName: string }[];
    search: string;
    selectedFilters: SelectedFilterArray<TrainEditorFilterType>;
  };
}

export enum TrainEditorFilterType {
  // ```no-mat-icon``` prefix prevents the chip list from displaying mat-icons
  CAR_CLASS = 'no-mat-icon-car_class',
  GROUP = 'no-mat-icon-group'
}

export interface TrainEditorData {
  train$: Observable<EditorTrain>;
}

export interface TrainEditorListPanelData extends TrainEditorData {
  uiState$: Observable<TrainEditorUiState>;
  trainType$: Observable<TrainType>;
  trains$: Observable<Consist[]>;
}

/**
 * Note you cannot currently configure the top toolbar.
 */
export interface TrainEditorConfig {
  listPanel: ComponentConfig<DynamicComponent<TrainEditorListPanelData, any>, TrainEditorListPanelData>;
  trainConfigurationPanel: ComponentConfig<DynamicComponent<TrainEditorConfigurationData, any>, TrainEditorConfigurationData>;
  detailsPanel: ComponentConfig<DynamicComponent<TrainEditorDetailPanelData, any>, TrainEditorDetailPanelData>;
}

export interface TrainEditorDetailPanelData extends TrainEditorData {
  trainTypes$: Observable<string[]>;
  otherTrainNames$: Observable<string[]>;
  savedTrainName$: Observable<string>;
  nameUpdate?: Observer<string>;
  trainTypeUpdate?: Observer<string>;
  disableSave?: Observer<boolean>;
  trainConfigurationUpdated: Observer<EditorConsistVehicle[]>;
}

/**
 * Returns whether the passed in data is train editor config. All fields are required!!
 *
 * @param config the config to check
 */
export function isTrainEditorConfig(config: TrainEditorConfig | Data): config is TrainEditorConfig {
  return !!config && !!config.listPanel && !!config.detailsPanel;
}

export type TrainEditorTabType = TabGroupChild<BasicTabNavItem>;

export interface TrainEditorConfigurationData extends TrainEditorData {
  trainType$: Observable<TrainType>;
  carClassAdded: Observer<CarClass>;
  trainConfigurationUpdated: Observer<EditorConsistVehicle[]>;
  triggerFormValidation$?: Observable<void>;
}

export interface EditorConsistVehicle extends ConsistVehicle {
  selected?: boolean;
  indeterminate?: boolean;
  header?: boolean;
  displayPosition?: string;
  // Sometimes we don't have all orientation info (normally at least one is supplied)
  isOrientationChangeSupported?: boolean;
}

export interface TrainVehicleData {
  name: string;
  type: TrainVehicleListDataType;
  train?: Consist;
  carClass?: CarClass;
  isDraggable: boolean;
}

export enum TrainVehicleListDataType {
  // eslint-disable-next-line @typescript-eslint/naming-convention
  Train = 'train',
  // eslint-disable-next-line @typescript-eslint/naming-convention, @typescript-eslint/no-shadow
  CarClass = 'vehicle'
}

export interface EditorCarClass extends CarClass {
  loading: number;
}


/**
 * Get the status of a train. Checks if it's in use by a scenario, then determines if the train is in use or a not in use.
 *
 * @param train the train to fetch the status of
 * @param scenarios a list of scenarios to check against (if the train is in use by them)
 */
export function trainStatus(train: EditorTrain, scenarios: Scenario[]): EditorBrowserTableStatus {
  if (scenarios?.length) {
    const scenario = scenarios?.find(s => s.scenarioTrains?.scenarioTrain?.find(sTrain => sTrain.trainDescription === train.name));
    if (scenario) {
      return 'In Use';
    }
  }
  return 'Not In Use';
}
