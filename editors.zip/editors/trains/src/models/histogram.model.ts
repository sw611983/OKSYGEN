/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export interface HistogramData {
  index: string;
  value: number;
  throttlePosition?: number;
  name: string;
}

export interface HistogramConfig {
  min?: number;
  max?: number;
  yUnit?: string;
  xUnit?: string;
}

export interface ThrottleData {
  position: number;
  name: string;
}

export enum BarDataTenthsPlace {
  COUNT = 3
}

export interface ChartConfiguration {
  barsPadding: number;
  gradientColorLower: string;
  gradientColorUpper: string;
  isZoomable: boolean;
  zoomDomain?: [number, number];
  tooltipClassName: string;
  displayXAxis: boolean;
  displayYAxis: boolean;
  displayYUnitLabel: boolean;
}

export interface BarData {
  name: string;
  value: number;
}

export interface Configs {
  min: number;
  max: number;
  unit?: string;
}
