/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { HTTP_SCHEMA_KEYWORD } from '@oksygen-sim-core-libraries/components-services/data-services';

export const trainEditorSchema: Record<string, any> = {
  $id: 'oksygen-train-editor',
  type: 'object',
  properties: {
    trainEditorData: {
      type: 'object',
      properties: {
        allTrainsUrl: { type: 'string', [HTTP_SCHEMA_KEYWORD]: HTTP_SCHEMA_KEYWORD },
        trainEditorUrl: { type: 'string', [HTTP_SCHEMA_KEYWORD]: HTTP_SCHEMA_KEYWORD }
      }
    }
  }
};
