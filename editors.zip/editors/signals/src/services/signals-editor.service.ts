/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AbstractBrowserService } from '@oksygen-sim-train-libraries/components-services/editors';
import { Observable } from 'rxjs';

import { SignalModels } from '../models/signal-editor.model';
import { SignalEditorActionEnum } from '../store/signal-editor.actions';
import { SignalEditorState } from '../store/signal-editor.state';

@Injectable()
export class SignalsEditorService extends AbstractBrowserService {
  constructor(
    private store: Store<SignalEditorState>,
    private httpClient: HttpClient
  ) {
    super('SignalalsEditorService');
  }

  /**
   * This is called when the page is first opened
   */
  public override initialiseEditing(): void {
    super.initialiseEditing();
    // TODO: Any local initialisation for this
  }

  /**
   * This is called when the page is being closed fully
   */
  public override resetEditing(): void {
    super.resetEditing();
    this.store.dispatch({
      type: SignalEditorActionEnum.RESET
    });
  }

  public loadModels(): Observable<SignalModels> {
    return this.httpClient.get<SignalModels>('./assets/models/models.json');
  }
}
