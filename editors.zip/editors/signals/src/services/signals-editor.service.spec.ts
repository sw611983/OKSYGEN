/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
// import { TestBed, waitForAsync } from '@angular/core/testing';
// import { provideMockStore } from '@ngrx/store/testing';

// import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
// import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { SignalsEditorService } from './signals-editor.service';

describe('SignalsEditorService', () => {
  let service: SignalsEditorService;

  beforeEach(() => {
    // waitForAsync(() => {
    //   configureSimTrainTestingModule({
    //     imports: [OksygenSimTrainEditorsModule, OksygenSimTrainEditorsModule],
    //     providers: [provideMockStore({})]
    //   });
    //   service = TestBed.inject(SignalsEditorService);
    // })
    service = new SignalsEditorService(null, null);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
