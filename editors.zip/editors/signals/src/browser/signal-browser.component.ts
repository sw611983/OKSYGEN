/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { BehaviorSubject, of, Subscription } from 'rxjs';

import {
  BasicTabNavItem,
  BasicTabNavItemComponent,
  FileManagerTableComponent,
  FileManagerTableData,
  SideNavService,
  Sorter,
  TabGroupChild,
  TabService
} from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { Logging } from '@oksygen-common-libraries/pio';
import { AbstractEditorTabPage, EditorData } from '@oksygen-sim-train-libraries/components-services/editors';
import { Signal, signalSearchableText, SignalService } from '@oksygen-sim-train-libraries/components-services/signals';

import { SignalsEditorService } from '../services/signals-editor.service';
import { SignalEditorActionEnum } from '../store/signal-editor.actions';
import { getSelectedSignal, getSignalEditing } from '../store/signal-editor.selectors';
import { SignalEditorState } from '../store/signal-editor.state';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

interface SignalTableData {
  id: number;
  name: string;
  type: string;
  preview: string;
}

export const SIGNALS_CARD_DATA = new EditorData(
  t('Signals'),
  '/editors/signals',
  OksygenIcon.SIGNAL_EDITOR,
  'signals'
);

@Component({
  templateUrl: './signal-browser.component.html',
  styleUrls: ['./signal-browser.component.scss']
})
export class SignalBrowserComponent extends AbstractEditorTabPage implements OnInit, OnDestroy {
  selectedSignal: Signal;
  selectedCount: number;
  filteredSignals: SignalTableData[];
  sorter = new Sorter<SignalTableData>();
  editing = false;

  editDisabled = true;
  duplicateDisabled = true;
  deleteDisabled = true;

  rowsChecked = false;

  @ViewChild(FileManagerTableComponent) fileManagerTable: FileManagerTableComponent<SignalTableData>;

  columns: FileManagerTableData[] = [
    { name: 'name', title: t('Signal Name'), icon: OksygenIcon.SIGNAL_EDITOR },
    { name: 'preview', title: t('Preview'), icon: OksygenIcon.PICTURE },
    { name: 'type', title: t('Type'), icon: OksygenIcon.TYPE }
  ];

  private signalsSubscription: Subscription;
  private slctdSgnSubscription: Subscription;
  private svSubscription: Subscription;
  private editingSubscription: Subscription;

  private signals: SignalTableData[];

  constructor(
    private signalsEditorService: SignalsEditorService,
    sideNavService: SideNavService,
    router: Router,
    private signalService: SignalService,
    private store: Store<SignalEditorState>,
    tabService: TabService,
    logger: Logging,
    translateService: TranslateService
  ) {
    super(signalsEditorService, sideNavService, router, SIGNALS_CARD_DATA, tabService, logger, translateService);

    this.sorter.sortFunction = this.sorterFunction.bind(this);
  }

  ngOnInit(): void {
    this.pageOpening();
    this.slctdSgnSubscription = this.store.select(getSelectedSignal).subscribe(value => {
      this.selectedSignal = value;
    });

    this.editingSubscription = this.store.select(getSignalEditing).subscribe(value => {
      this.editing = value;
    });

    this.signalsSubscription = this.signalService.data().subscribe(data => {
      this.updateSignals(data);
    });

    const signalsTab: TabGroupChild<BasicTabNavItem> = {
      data: {
        id: SIGNALS_CARD_DATA.id,
        groupId: SIGNALS_CARD_DATA.id,
        icon: OksygenIcon.FILE_MANAGER,
        routerLink: SIGNALS_CARD_DATA.routerLink,
        name: t('Manager'),
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => of(true),
        onClose: () => {
          this.tabClosing();
          // this.clearFilters(); // FIXME Use this from base class once implementation of this component is matched with other editors browser component
        }
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: SIGNALS_CARD_DATA.id,
        groupName: SIGNALS_CARD_DATA.name,
        route: SIGNALS_CARD_DATA.routerLink,
        // groupIcon: SIGNALS_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [signalsTab],
      childrenIndex: 0
    });
  }

  // FIXME Use this from base class once implementation of this component is matched with other editors browser component
  clearFilters(): void {
    // this.state.filters.selectedFilters.splice(0, this.state.filters.selectedFilters.length);
  }

  ngOnDestroy(): void {
    this.slctdSgnSubscription?.unsubscribe();
    this.svSubscription?.unsubscribe();
    this.editingSubscription?.unsubscribe();
    this.signalsSubscription?.unsubscribe();
    this.pageClosing();
  }

  toSearchableText(signal: Signal): string[] {
    return signalSearchableText(signal);
  }

  toFilterText(signal: Signal): string[] {
    return [signal.type.name.toString()];
  }

  sorterFunction(c: string, a: SignalTableData, b: SignalTableData): number {
    switch (c) {
      case 'name': {
        return a.name.localeCompare(b.name, this.getCurrentLocale());
      }
      case 'type': {
        return a.type.localeCompare(b.type, this.getCurrentLocale());
      }
      default: {
        return 0;
      }
    }
  }

  selectionChanged(): void {
    const selectedValues = this.fileManagerTable.getSelectedValues();

    if (selectedValues.length > 0) {
      const singleSelected = selectedValues.length === 1;

      this.editDisabled = !singleSelected;
      this.duplicateDisabled = !singleSelected;
      this.deleteDisabled = false;
    } else {
      this.editDisabled = true;
      this.duplicateDisabled = true;
      this.deleteDisabled = true;
    }
  }

  createNew(): void {
    this.store.dispatch({
      type: SignalEditorActionEnum.UPDATE_SELECTED_SIGNAL,
      props: {
        value: {
          id: -1,
          name: 'New Sign',
          type: null,
          version: null,
          data: []
        }
      }
    });

    this.store.dispatch({
      type: SignalEditorActionEnum.UPDATE_EDITING,
      props: { value: true }
    });
  }

  import(): void {
    this.logger.log('import');
    // TODO: Implement
  }

  export(): void {
    this.logger.log('export');
    // TODO: Implement
  }

  duplicateClick(): void {
    this.logger.log('duplicateClick', this.fileManagerTable.getSelectedValues());
    // TODO: Implement
  }

  editClick(): void {
    this.store.dispatch({
      type: SignalEditorActionEnum.UPDATE_EDITING,
      props: { value: true }
    });
  }

  deleteClick(): void {
    this.logger.log('deleteClick', this.fileManagerTable.getSelectedValues());
    // TODO: Implement
  }

  back(): void {
    this.logger.log('back');
    // TODO: Implement
  }

  private updateSignals(data: Signal[]): void {
    this.signals = [];
    this.filteredSignals = [];

    if (data) {
      data.forEach(signal => {
        this.signals.push({
          id: signal.id,
          name: signal.name,
          type: signal.type.name,
          preview: ''
        });
      });

      this.applyFilters();
    }
  }

  private applyFilters(): void {
    // TODO: Properly implement once filters are added
    this.filteredSignals = [...this.signals];
  }
}
