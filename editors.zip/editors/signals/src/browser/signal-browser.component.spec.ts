/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { BehaviorSubject, Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

// import { SignalService } from '../signal/services/signal.service';
import {
  getSelectedSignal,
  getSignalEditing,
  getSignalSearchValue,
  getSignalSupportSearchValue,
  getSignalTargetSearchValue
} from '../store/signal-editor.selectors';
import { SignalEditorComponent } from '../editor/signal-editor.component';
import { SignalModels } from '../models/signal-editor.model';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { SignalsEditorService } from '../services/signals-editor.service';
import { SignalBrowserComponent } from './signal-browser.component';
import { SignalService } from '@oksygen-sim-train-libraries/components-services/signals';

describe('SignalsEditorComponent', () => {
  let component: SignalBrowserComponent;
  let fixture: ComponentFixture<SignalBrowserComponent>;
  const signalModels = new BehaviorSubject<SignalModels>({
    supports: [],
    targets: []
  });

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [ OksygenSimTrainEditorsModule ],
        providers: [
          {
            provide: SignalService,
            useValue: {
              data: (): Observable<any> => new BehaviorSubject(null).asObservable()
            }
          },
          {
            provide: SignalsEditorService,
            useValue: {
              initialiseEditing(): void {},
              pageOpening(): void {},
              pageClosing(): void {},
              loadModels: (): Observable<any> => signalModels.asObservable()
            }
          },
          provideMockStore({
            selectors: [
              { selector: getSelectedSignal, value: { selectedSignal: null } },
              { selector: getSignalSearchValue, value: { searchValue: null } },
              { selector: getSignalEditing, value: { editing: false } },
              { selector: getSignalSupportSearchValue, value: null },
              { selector: getSignalTargetSearchValue, value: null },
              { selector: getSelectedSignal, value: null }
            ]
          })
        ],
        declarations: [SignalBrowserComponent, SignalEditorComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(SignalBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  //FIXME: Currently erroring with No provider for TranslateStore!
  // but is the only one doing so?
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
