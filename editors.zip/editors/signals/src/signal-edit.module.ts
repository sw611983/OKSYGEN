/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule, RouteConfig, RoutingPage } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';

import { SignalBrowserComponent } from './browser/signal-browser.component';
import { SignalEditorComponent } from './editor/signal-editor.component';
import { SignalsEditorService } from './services/signals-editor.service';

export const signalBrowserPage: RoutingPage = {
  path: 'signals',
  component: SignalBrowserComponent
};

export function signalBrowserRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  return { path: signalBrowserPage.path, component: signalBrowserPage.component, canActivate: auth };
}

const components = [
  SignalBrowserComponent,
  SignalEditorComponent
];

@NgModule({
  declarations: components,
  imports: [
    RouterModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DragDropModule,
    OksygenMaterialComponentsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenMaterialTranslateModule.forChild(),
    OksygenSimTrainCommonModule,
    OksygenSimTrainEditorsModule
    // OksygenSimTrainComponentsServicesModule,
    // OksygenSimTrainSignalModule
  ],
  exports: components,
  providers: [SignalsEditorService]
})
export class OksygenSimTrainSignalEditModule { }
