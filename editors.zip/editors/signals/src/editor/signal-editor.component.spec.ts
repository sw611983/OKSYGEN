/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

// TODO Perhaps we should use Spectator for writing tests...
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { BehaviorSubject, Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { SignalEditorComponent } from './signal-editor.component';
import { SignalModels } from '../models/signal-editor.model';
import { Signal, SignalService } from '@oksygen-sim-train-libraries/components-services/signals';
import { SignalsEditorService } from '../services/signals-editor.service';
import { getSignalSupportSearchValue, getSignalTargetSearchValue, getSelectedSignal } from '../store/signal-editor.selectors';

describe('SignalEditorComponent', () => {
  // TODO Perhaps we should use Spectator for writing tests...
  // const signalModels = new BehaviorSubject<SignalModels>({
  //   supports: [],
  //   targets: []
  // });

  // let spectator: Spectator<SignalEditorComponent>;
  // const createComponent = createComponentFactory({
  //   component: SignalEditorComponent,
  //   imports: [OksygenComponentsModule, OksygenMaterialModule, NoopAnimationsModule],
  //   providers: [
  //       { provide: SignalsEditorService, useValue: {
  //         loadModels() { return signalModels.asObservable(); },
  //         convertSignalToSignalState(s: Signal) {}
  //       } },
  //     mockProvider(SignService),
  //     mockProvider(TranslateService),
  //     provideMockStore({
  //       selectors: [
  //         {selector: getSupportSearchValue, value: null},
  //         {selector: getTargetSearchValue, value: null},
  //         {selector: getSelectedSignal, value: null}
  //       ]})
  //   ],
  //   declarations: [TranslatePipeStub],
  //   mocks: [SignalsEditorService]
  // });

  // beforeEach(() => spectator = createComponent());

  // it('should create', () => {
  //   expect(spectator.component).toBeTruthy();
  // });

  let component: SignalEditorComponent;
  let fixture: ComponentFixture<SignalEditorComponent>;
  const signalModels = new BehaviorSubject<SignalModels>({
    supports: [],
    targets: []
  });

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        providers: [
          { provide: SignalService, useValue: {} },
          {
            provide: SignalsEditorService,
            useValue: {
              loadModels: (): Observable<any> => signalModels.asObservable(),
              convertSignalToSignalState(s: Signal): void {}
            }
          },
          provideMockStore({
            selectors: [
              { selector: getSignalSupportSearchValue, value: null },
              { selector: getSignalTargetSearchValue, value: null },
              { selector: getSelectedSignal, value: null }
            ]
          })
        ],
        declarations: [SignalEditorComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(SignalEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
