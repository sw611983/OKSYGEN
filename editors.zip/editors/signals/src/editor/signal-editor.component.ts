/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild
} from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Subscription } from 'rxjs';
import { Logging } from '@oksygen-common-libraries/pio';
import { Signal, SignalElement, signalElementSearchableText, SignalService, SignalSupport } from '@oksygen-sim-train-libraries/components-services/signals';
import { SignalsEditorService } from '../services/signals-editor.service';
import { SignalEditorState } from '../store/signal-editor.state';
import { Engine3d, Engine3dThreeJs, Vector3d } from '@oksygen-sim-train-libraries/components-services/engine3d';
import { getSelectedSignal, getSignalSupportSearchValue, getSignalTargetSearchValue } from '../store/signal-editor.selectors';
import { SignalEditorActionEnum } from '../store/signal-editor.actions';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
declare let window: Window;

@Component({
  selector: 'oksygen-signal-editor',
  templateUrl: './signal-editor.component.html',
  styleUrls: ['./signal-editor.component.scss']
})
export class SignalEditorComponent implements OnInit, OnDestroy, AfterViewInit {
  readonly PANEL_HEADER_HEIGHT = '67px';
  readonly NULL_SIGNAL: Signal = {
    id: null,
    name: null,
    type: {
      id: null,
      name: null
    },
    version: null,
    support: null,
    targets: []
  };

  supports: SignalSupport[];
  targets: SignalElement[];

  move: Vector3d = { x: 0, y: 0, z: 0 };
  rotate: Vector3d = { x: 0, y: 0, z: 0 };

  engine3d: Engine3d;
  supportObject: any;
  selectedObject: any;

  supportSearchValue = '';
  targetSearchValue = '';

  signal: Signal = this.NULL_SIGNAL;

  private sigSubscription: Subscription;
  private supSubscription: Subscription;
  private tgtSubscription: Subscription;

  @ViewChild('editorContainer', { static: true })
  public editorContainer: ElementRef<HTMLDivElement>;

  constructor(
    private signalsEditorService: SignalsEditorService,
    private translateService: TranslateService,
    private signalService: SignalService,
    private store: Store<SignalEditorState>,
    private logger: Logging
  ) {
    this.engine3d = new Engine3dThreeJs();
  }

  ngOnInit(): void {
    this.selectedObject = null;

    this.sigSubscription = this.store
      .select(getSelectedSignal)
      .subscribe(value => {
        if (value) {
          this.signal = value;
        } else {
          this.signal = this.NULL_SIGNAL;
        }
      });

    this.supSubscription = this.store
      .select(getSignalSupportSearchValue)
      .subscribe(value => {
        this.supportSearchValue = value;
      });

    this.tgtSubscription = this.store
      .select(getSignalTargetSearchValue)
      .subscribe(value => {
        this.targetSearchValue = value;
      });

    this.signalsEditorService.loadModels().subscribe(models => {
      this.supports = models.supports;
      this.targets = models.targets;
    });
  }

  ngOnDestroy(): void {
    this.sigSubscription.unsubscribe();
    this.supSubscription.unsubscribe();
    this.tgtSubscription.unsubscribe();

    this.store.dispatch({
      type: SignalEditorActionEnum.UPDATE_SELECTED_SIGNAL,
      props: {
        value: this.signal
      }
    });
  }

  ngAfterViewInit(): void {
    this.engine3d.createScene(
      this.editorContainer.nativeElement,
      0xe0e0e0,
      750,
      750
    );
    // FIXME memory leak - should use Renderer2 (deals with it automatically) or removeEventListener()
    this.engine3d.getCanvas().addEventListener('mouseup', event => {
      const object = this.engine3d.selectObject(event);

      if (object) {
        this.selectedObject = object;
        this.move = this.engine3d.getPosition(object);
        const rotation = this.engine3d.getRotation(object);
        this.rotate = {
          x: this.fromRads(rotation.x),
          y: this.fromRads(rotation.y),
          z: this.fromRads(rotation.z)
        };
      }
    });
  }

  setSupportSearchValue(searchValue: string): void {
    this.store.dispatch({
      type: SignalEditorActionEnum.UPDATE_SUPPORT_SEARCH_VALUE,
      props: { value: searchValue }
    });
  }

  setTargetSearchValue(searchValue: string): void {
    this.store.dispatch({
      type: SignalEditorActionEnum.UPDATE_TARGET_SEARCH_VALUE,
      props: { value: searchValue }
    });
  }

  toSupportSearchableText(signalSupport: SignalSupport): string[] {
    return signalElementSearchableText(signalSupport);
  }

  toTargetSearchableText(signalElement: SignalElement): string[] {
    return signalElementSearchableText(signalElement);
  }

  setSupport(support: SignalSupport): void {
    this.signal.support = support;
    this.engine3d.addModel(
      support.model,
      null,
      this.supportObject,
      object => {
        this.supportObject = object;
        this.selectedObject = this.supportObject;
      }
    );
  }

  addTarget(target: SignalElement): void {
    this.signal.targets.push(target);
    this.engine3d.addModel(target.model, null, null, object => {
      this.selectedObject = object;
    });
  }

  resetCamera(): void {
    this.engine3d.resetCamera();
  }

  moveX(value: number): void {
    this.move.x = value;
    this.engine3d.updatePosition(this.selectedObject, {
      x: value,
      y: null,
      z: null
    });
  }

  moveY(value: number): void {
    this.move.y = value;
    this.engine3d.updatePosition(this.selectedObject, {
      x: null,
      y: value,
      z: null
    });
  }

  moveZ(value: number): void {
    this.move.z = value;
    this.engine3d.updatePosition(this.selectedObject, {
      x: null,
      y: null,
      z: value
    });
  }

  rotateX(value: number): void {
    this.rotate.x = value;
    this.engine3d.updateRotation(this.selectedObject, {
      x: this.toRads(value),
      y: null,
      z: null
    });
  }

  rotateY(value: number): void {
    this.rotate.y = value;
    this.engine3d.updateRotation(this.selectedObject, {
      x: null,
      y: this.toRads(value),
      z: null
    });
  }

  rotateZ(value: number): void {
    this.rotate.z = value;
    this.engine3d.updateRotation(this.selectedObject, {
      x: null,
      y: null,
      z: this.toRads(value)
    });
  }

  private toRads(degrees: number): number {
    return (degrees * Math.PI) / 180;
  }

  private fromRads(radians: number): number {
    return (radians * 180) / Math.PI;
  }

  cancel(): void {
    this.logger.log('cancel');
  }

  save(): void {
    this.logger.log('save');
  }
}
