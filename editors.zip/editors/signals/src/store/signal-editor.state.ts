/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Signal } from '@oksygen-sim-train-libraries/components-services/signals';

export interface SignalEditorState {
  selectedSignal: Signal;
  searchValue: string;
  editing: boolean;

  supportSearchValue: string;
  targetSearchValue: string;
}

export const initialSignalEditorState: SignalEditorState = {
  selectedSignal: null,
  searchValue: '',
  editing: false,
  supportSearchValue: '',
  targetSearchValue: ''
};
