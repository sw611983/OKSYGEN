/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createAction, props } from '@ngrx/store';

import { Signal } from '@oksygen-sim-train-libraries/components-services/signals';

export enum SignalEditorActionEnum {
  UPDATE_SELECTED_SIGNAL = '[SignalEditorActionEnum] UPDATE_SELECTED_SIGNAL',
  UPDATE_SEARCH_VALUE = '[SignalEditorActionEnum] UPDATE_SEARCH_VALUE',
  UPDATE_EDITING = '[SignalEditorActionEnum] UPDATE_EDITING',
  UPDATE_SUPPORT_SEARCH_VALUE = '[SignalEditorActionEnum] UPDATE_SUPPORT_SEARCH_VALUE',
  UPDATE_TARGET_SEARCH_VALUE = '[SignalEditorActionEnum] UPDATE_TARGET_SEARCH_VALUE',
  RESET = '[SignalEditorActionEnum] RESET',
}

export const updateSelectedSignalAction = createAction(
  SignalEditorActionEnum.UPDATE_SELECTED_SIGNAL,
  props<{ value: Signal }>()
);
export const updateSignalSearchValueAction = createAction(
  SignalEditorActionEnum.UPDATE_SEARCH_VALUE,
  props<{ value: string }>()
);
export const updateEditingSignalAction = createAction(
  SignalEditorActionEnum.UPDATE_EDITING,
  props<{ value: boolean }>()
);
export const updateSupportSearchValueAction = createAction(
  SignalEditorActionEnum.UPDATE_SUPPORT_SEARCH_VALUE,
  props<{ value: string }>()
);
export const updateTargetSearchValueAction = createAction(
  SignalEditorActionEnum.UPDATE_TARGET_SEARCH_VALUE,
  props<{ value: string }>()
);
export const resetSignalAction = createAction(SignalEditorActionEnum.RESET);
