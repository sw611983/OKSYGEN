/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createReducer, on } from '@ngrx/store';

import * as EditorActions from './signal-editor.actions';
import {
  initialSignalEditorState,
  SignalEditorState
} from './signal-editor.state';

export const signalEditorReducer = createReducer(
  initialSignalEditorState,
  on(EditorActions.resetSignalAction, (state: SignalEditorState, action: any) => ({
    ...initialSignalEditorState
  })),
  on(
    EditorActions.updateEditingSignalAction,
    (state: SignalEditorState, action: any) => ({
      ...state,
      editing: action.props.value
    })
  ),
  on(
    EditorActions.updateSignalSearchValueAction,
    (state: SignalEditorState, action: any) => ({
      ...state,
      searchValue: action.props.value
    })
  ),
  on(
    EditorActions.updateSelectedSignalAction,
    (state: SignalEditorState, action: any) => ({
      ...state,
      selectedSignal: action.props.value
    })
  ),
  on(
    EditorActions.updateSupportSearchValueAction,
    (state: SignalEditorState, action: any) => ({
      ...state,
      supportSearchValue: action.props.value
    })
  ),
  on(
    EditorActions.updateTargetSearchValueAction,
    (state: SignalEditorState, action: any) => ({
      ...state,
      targetSearchValue: action.props.value
    })
  )
);
