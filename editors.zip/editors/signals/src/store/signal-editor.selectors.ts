/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createFeatureSelector, createSelector } from '@ngrx/store';

import { SignalEditorState } from './signal-editor.state';

export const selectSignalEditorState = createFeatureSelector<SignalEditorState>(
  'signalEditor'
);
export const getSelectedSignal = createSelector(
  selectSignalEditorState,
  (state: SignalEditorState) => state.selectedSignal
);
export const getSignalSearchValue = createSelector(
  selectSignalEditorState,
  (state: SignalEditorState) => state.searchValue
);
export const getSignalEditing = createSelector(
  selectSignalEditorState,
  (state: SignalEditorState) => state.editing
);
export const getSignalSupportSearchValue = createSelector(
  selectSignalEditorState,
  (state: SignalEditorState) => state.supportSearchValue
);
export const getSignalTargetSearchValue = createSelector(
  selectSignalEditorState,
  (state: SignalEditorState) => state.targetSearchValue
);
