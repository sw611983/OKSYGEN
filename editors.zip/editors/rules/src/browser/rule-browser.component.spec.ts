/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainRuleEditModule } from '../rule-edit.module';
import { RuleBrowserComponent } from './rule-browser.component';

describe('RuleBrowserComponent', () => {
  let component: RuleBrowserComponent;
  let fixture: ComponentFixture<RuleBrowserComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [ OksygenSimTrainEditorsModule, OksygenSimTrainRuleEditModule ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
