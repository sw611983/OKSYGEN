/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';

import { AbstractBrowserService } from '@oksygen-sim-train-libraries/components-services/editors';

@Injectable()
export class RuleBrowserService extends AbstractBrowserService {
  private selectedRuleTemplate = new BehaviorSubject<RuleTemplate>(null);
  private searchText = new BehaviorSubject<string>('');

  constructor() {
    super('RuleBrowserService');
  }

  /**
   * This is called when the page is first opened
   */
  public override initialiseEditing(): void {
    super.initialiseEditing();
    // TODO: Any local initialisation for this
  }

  public setSelectedRuleTemplate(scenario: RuleTemplate): void {
    this.selectedRuleTemplate.next(scenario);
  }

  public getSelectedRuleTemplate$(): Observable<RuleTemplate> {
    return this.selectedRuleTemplate.asObservable();
  }

  public setSearchText(text: string): void {
    this.searchText.next(text);
  }

  public getSearchText$(): Observable<string> {
    return this.searchText.asObservable();
  }
}
