/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectorRef, Component, NgZone, OnDestroy, OnInit, Optional, signal, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, combineLatest, from, Observable, of, Subscription, zip } from 'rxjs';
import { first, map, startWith, switchMap, withLatestFrom } from 'rxjs/operators';

import { Author, SuperCalled, takeOneTruthy } from '@oksygen-common-libraries/common';
import { XmlJsonUtil } from '@oksygen-common-libraries/data-access';
import {
  allFilterTypesMatch,
  AutocompleteInputType,
  BasicSingleInputDialogComponent,
  BasicSingleInputDialogData,
  BasicSingleInputDialogInput,
  BasicTabNavItem,
  BasicTabNavItemComponent,
  Breadcrumb,
  ButtonInfo,
  CANCEL_BUTTON,
  FileManagerTableComponent,
  FileManagerTableData,
  Filter,
  filterMatches,
  illegalNameCharacterExists,
  newFormControl,
  PromptDialogComponent,
  PromptDialogData,
  SelectedFilterArray,
  SideNavService,
  TabGroupChild,
  TabService,
  UpdateOn
} from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { Backup, USER_CANCELLED_BACKUP } from '@oksygen-common-libraries/pio/backup';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { User, UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import {
  BrowserFilterText,
  BrowserState,
  deleteDialog,
  EditorBrowserFilterIOConfig,
  EditorBrowserTableStatus,
  newName
} from '@oksygen-sim-train-libraries/components-services/common';
import {
  BaseLockableBrowserTabPage,
  EditorData,
  EditorLock,
  LockDatabaseService
} from '@oksygen-sim-train-libraries/components-services/editors';
import {
  FromRuleTemplate,
  isRuleTemplateData,
  RuleBlockService,
  RuleTemplate,
  RuleTemplateService,
  transformFromRuleTemplate
} from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario, ScenarioService } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { filterOldVersions } from '../helpers/rules-filter';
import { ruleTemplateStatus, RuleTemplateSummaryData, ruleTemplateToRuleTemplateSummaryData } from '../models/rule-summary-data.model';
import { toRuleTemplateXml } from '../models/rule-template-xml.model';
import { RuleImportDialogComponent, RuleImportDialogInput } from '../rule-import-dialog/rule-import-dialog.component';
import { RuleEditManager } from '../services/rule-edit.manager';
import { RuleEditService } from '../services/rule-edit.service';
import { RuleEditorContextPublisher } from '../services/rule-editor-context.publisher';
import { RuleBrowserService } from './rule-browser.service';

export const RULES_CARD_DATA = new EditorData(t('Rules'), '/editors/rules', OksygenIcon.RULE_EDITOR, 'rules');

export function deleteRuleTemplatePromptDialogData(ruleTemplateName: string[]): PromptDialogData {
  const promptData = new PromptDialogData();
  // FIXME More meaningful message please
  promptData.title =
    ruleTemplateName.length > 1 ? t('Are you sure you want to delete these rule templates?') : t('Are you sure you want to delete this rule template?');
  promptData.content = ruleTemplateName.length > 1 ? ruleTemplateName : `<b>${ruleTemplateName}</b>`;
  promptData.buttons = promptData.buttons = [
    {
      color: MaterialThemePalette.WARN,
      text: t('Delete'),
      data: true
    },
    CANCEL_BUTTON
  ];
  return promptData;
}

enum RuleTemplateInUseDialogResult {
  EDIT = 1,
  DUPLICATE = 2
}

function warnRuleTemplateInUsePromptDialogData(ruleTemplateName: string): PromptDialogData {
  const promptData = new PromptDialogData();
  // FIXME More meaningful message please
  promptData.title = t('This rule template is in use by a scenario, are you sure you want to edit it?');
  promptData.content = `<b>${ruleTemplateName}</b>`;
  promptData.buttons = promptData.buttons = [
    {
      color: MaterialThemePalette.WARN,
      text: t('Edit'),
      data: RuleTemplateInUseDialogResult.EDIT
    },
    {
      color: MaterialThemePalette.PRIMARY,
      text: t('Duplicate'),
      data: RuleTemplateInUseDialogResult.DUPLICATE
    },
    CANCEL_BUTTON
  ];
  return promptData;
}

export type RuleTabType = TabGroupChild<BasicTabNavItem>;

enum FilterType {
  // These names are used to select the icon on chips of that type
  RULE = 'rule_editor',
  AUTHOR = 'author'
}

// interface RuleBrowserState {
//   filters: {
//     ruleText: string;
//     selectedFilters: SelectedFilterArray<FilterType>;
//   };
// }

interface RuleTemplateFilterFields extends BrowserFilterText {
  authorText: string;
  ruleText: string;
}

// this is a rip of the scenario browser - could look to making a lot (more!) of this generic

@Component({
  templateUrl: './rule-browser.component.html',
  styleUrls: ['./rule-browser.component.scss']
})
export class RuleBrowserComponent
  extends BaseLockableBrowserTabPage<RuleTemplate, RuleTemplateSummaryData, RuleTemplateFilterFields, string>
  implements OnInit, OnDestroy
{
  readonly DEFAULT_RULE_TEMPLATE_NAME: string = t('New Rule Template');
  readonly DUPLICATE_RULE_NAME_ERROR: string = t('A rule template with this name already exists.');
  readonly MISSING_RULE_NAME_ERROR: string = t('A rule template name is required.');
  readonly SPACES_RULE_NAME_ERROR: string = t('A rule template name cannot have leading or trailing spaces.');
  readonly SPECIAL_CHARACTER_RULE_NAME_ERROR: string = t('A rule template name cannot have the special characters " < % > * | ? :');
  readonly BREADCRUMB: Breadcrumb = {
    text: t('Rule Editor'),
    icon: 'rule_editor'
  };

  editing = false;

  // state: RuleBrowserState;

  @ViewChild(FileManagerTableComponent) fileManagerTable: FileManagerTableComponent<RuleTemplateSummaryData>;

  autoCompleteType = AutocompleteInputType.FORM_FIELD;

  override readonly selectedItem = signal<RuleTemplate | undefined>(undefined);

  // private ruleTemplates: RuleTemplate[];
  private subscriptions = new Subscription();

  constructor(
    private ruleEditService: RuleEditService,
    private ruleBrowserSerivce: RuleBrowserService,
    sideNavService: SideNavService,
    router: Router,
    tabService: TabService,
    logger: Logging,
    private registry: Registry,
    private dialog: MatDialog,
    private userService: UserService,
    private ruleTemplateService: RuleTemplateService,
    private ruleBlockService: RuleBlockService,
    private snackbar: MatSnackBar,
    private uiStateModelManager: UiStateModelManager,
    translateService: TranslateService,
    @Optional() private scenarioService: ScenarioService,
    private cd: ChangeDetectorRef,
    private contextSupplier: RuleEditorContextPublisher,
    private backup: Backup,
    lockService: LockDatabaseService,
    authService: AuthService,
    private zone: NgZone
  ) {
    super(
      {
        create: { visible: true, enabled: true },
        delete: { visible: true, enabled: true },
        duplicate: { visible: true, enabled: true },
        edit: { visible: false, enabled: false },
        open: { visible: true, enabled: true },
        search: { visible: true, enabled: true },
        refresh: { visible: true, enabled: true },
        import: { visible: true, enabled: true },
        export: { visible: true, enabled: true }
      },
      ruleBrowserSerivce,
      sideNavService,
      router,
      RULES_CARD_DATA,
      tabService,
      logger,
      translateService,
      lockService,
      authService,
      dialog
    );

    this.editDisabled.set(true);
    this.duplicateDisabled.set(true);
    this.deleteDisabled.set(true);
    this.printDisabled.set(true);

    this.detailEditDisabled.set(false);
    this.detailDuplicateDisabled.set(true);
    this.detailDeleteDisabled.set(false);
    this.detailPrintDisabled.set(true);

    this.columns = [];

    // this.displayedColumns = ['name', 'created', 'modified', 'status'];

    this.tableFilter = this.applyFilters.bind(this);

    // super(ruleBrowserSerivce, sideNavService, router, RULES_CARD_DATA, tabService, logger);
    this.refreshDisabled.set(false);
    this.sorter.sortFunction = this.sorterFunction.bind(this);
  }

  override ngOnInit(): SuperCalled {
    const superCalled = super.ngOnInit();
    this.pageOpening();
    this.loadLocks(this.registry);
    const canImportExport = this.registry.getBoolean(['backup', 'enabled'], true);
    this.fmhConfiguration.importConfig.visible = canImportExport;
    this.fmhConfiguration.exportConfig.visible = canImportExport;
    const selectedSub = this.ruleBrowserSerivce.getSelectedRuleTemplate$().subscribe(s => {
      // FIXME This doesn't update what the table shows (and right now  it's not clear to me how to make it do so).
      // On creation the table fires the selection callback with null, killing our attempt to persist the selection :(
      this.selectedItem.set(s);
      if (this.selectedItem()) {
        this.ruleTemplateService.getRuleTemplateById(this.selectedItem().id).subscribe();
      }
    });

    const searchSub = this.ruleBrowserSerivce.getSearchText$().subscribe(s => {
      // FIXME @@@ need the correct data type here
    });

    this.ruleTemplateService.reloadData();
    const dataSub = combineLatest(
      this.ruleTemplateService.data(),
      this.lockService.getEditorLocks(this.editorName()),
      this.translateService.onLangChange.pipe(startWith(null))
    ).subscribe(([ruleTemplates, locks, langChange]) => {
      // const dataSub = this.ruleTemplateService.data().subscribe(ruleTemplates => {
      const templates = ruleTemplates?.filter(rt => !rt.phantom);
      this.data.set(templates);
      this.locks.set(locks ?? []);
      this.cd.detectChanges(); // updating the file manager double triggers CD which gives the changed after checked err
      this.fileManagerTable?.applyFilter();
    });
    this.subscriptions.add(selectedSub);
    this.subscriptions.add(searchSub);
    this.subscriptions.add(dataSub);

    const rulesTab: TabGroupChild<BasicTabNavItem> = {
      data: {
        id: RULES_CARD_DATA.id,
        groupId: RULES_CARD_DATA.id,
        icon: OksygenIcon.FILE_MANAGER,
        routerLink: RULES_CARD_DATA.routerLink,
        name: t('Manager'),
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => of(true),
        onClose: () => {
          this.tabClosing();
          this.clearFilters();
        }
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: RULES_CARD_DATA.id,
        groupName: RULES_CARD_DATA.name,
        route: RULES_CARD_DATA.routerLink,
        // groupIcon: RULES_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [rulesTab],
      childrenIndex: 0
    });
    return superCalled;
  }

  ngOnDestroy(): void {
    this.pageClosing();
    this.setSelectedTableData();
    this.subscriptions.unsubscribe();
  }

  override editorName(): string {
    return 'rule';
  }

  onImport(): void {
    this.backup
      .getBackupLocation(true)
      .pipe(
        switchMap(location => this.backup.getBackupDirectoryFileList(location)),
        switchMap((files): Observable<{ fileName: string; ruleTemplate: RuleTemplate }[]> => {
          if (!(files && 'result' in files)) {
            return of([]);
          }
          const ruleTemplates$: Observable<{ fileName: string; ruleTemplate: RuleTemplate }>[] = [];
          files.result.children.forEach(ruleTemplateFile => {
            if (ruleTemplateFile.isDirectory) {
              return;
            }
            const absoluteFilePath = `${files.result.name}\\${ruleTemplateFile.name}`;
            const template$: Observable<{ fileName: string; ruleTemplate: RuleTemplate }> = this.backup.getBackupFile(absoluteFilePath).pipe(
              map(fileReadResult => {
                if (!(fileReadResult && 'result' in fileReadResult)) {
                  return null;
                }
                const ruleTemplateRaw: FromRuleTemplate = XmlJsonUtil.parseXML(fileReadResult.result);
                const isValid = isRuleTemplateData(ruleTemplateRaw);
                if (isValid) {
                  const ruleTemplate = transformFromRuleTemplate(ruleTemplateRaw);
                  return { fileName: ruleTemplateFile.name, ruleTemplate };
                }
                return null;
              })
            );
            ruleTemplates$.push(template$);
          });
          return zip(...ruleTemplates$);
        }),
        map(ruleTemplates => ruleTemplates.filter(r => !!r))
      )
      .subscribe(ruleTemplates => {
        this.zone.run(() => {
          const config: RuleImportDialogInput = {
            importRules: ruleTemplates,
            existingRules: this.data()
          };
          const dialogRef = RuleImportDialogComponent.openDialog(this.dialog, config);
          dialogRef.afterClosed().subscribe(dialogResult => {
          //return illegalNameCharacterExists(dialogResult);
          if (dialogResult?.rules?.length) {

            const results$ = dialogResult.rules.map(r => this.ruleEditService.saveItem(r));
            zip(...results$).subscribe(results => {
              this.snackbar.open(t('Rule template(s) imported'), '', { duration: 3000 });
            }, err => {
              this.snackbar.open(t('Rule template import failed'), '', { duration: 10000 });
              this.logger.error(`Error importing rule template(s): ${JSON.stringify(err)}`);
            });
          }
        });
      });
    });
    // this.backup.getBackupDirectoryFileList('rules').subscribe(backupResult => {
    //   if (backupResult && 'result' in backupResult) {
    //     const rules: RuleImportDialogRule[] = backupResult.result.children.map((r, i) => ({name: r.name, import: true, alreadyExists: i % 2 === 0}));
    //     const config: RuleImportDialogInput = {
    //       rules
    //     };
    //     const dialogRef = RuleImportDialogComponent.openDialog(this.dialog, config);
    //     dialogRef.afterClosed().subscribe(dialogResult => {
    //       this.logger.log(JSON.stringify(dialogResult));
    //     });
    //   }
    // });
    // this.backup.getBackupFile('', true).subscribe(b => {
    //   console.log(`[RuleBrowserComponent] backup is ${JSON.stringify(b)}`);
    //   if (b && 'result' in b) {
    //     const ruleTemplateRaw: FromRuleTemplate = XmlJsonUtil.parseXML(b.result);
    //     const isValid = isRuleTemplateData(ruleTemplateRaw);
    //     if (isValid) {
    //       const ruleTemplate = transformFromRuleTemplate(ruleTemplateRaw);
    //       this.ruleEditService.loadItem(ruleTemplate);
    //       this.startEditing(ruleTemplate.id, ruleTemplate.displayName);
    //     }
    //   }
    // });
  }

  onExport(): void {
    const selectedValues = this.fileManagerTable?.getSelectedValues();
    from(selectedValues)
      .pipe(
        map(ruleTemplateSummary => this.getItemFromTableItem(ruleTemplateSummary)),
        withLatestFrom(this.ruleBlockService.data()),
        switchMap(([ruleTemplate, ruleBlocks]) => {
          const xml = XmlJsonUtil.convertObjectToXml(toRuleTemplateXml(ruleTemplate, ruleBlocks, ruleTemplate), 'rule_template');
          const fileName = RuleEditManager.getRuleTemplateFileNameOnly(ruleTemplate);
          return this.backup.postBackup(fileName, xml, true);
        })
      )
      .subscribe(
        result => {
          if (result && 'result' in result) {
            this.snackbar.open(t('Rule template backed up'), '', { duration: 3000 });
          } else if (!result || ('error' in result && result.error.message !== USER_CANCELLED_BACKUP)) {
            this.snackbar.open(t('Rule template backup failed'), '', { duration: 10000 });
          }
        },
        err => {
          this.snackbar.open(t('An error occurred saving this rule template'), '', { duration: 10000 });
          this.logger.error(`Error saving rule template: ${JSON.stringify(err)}`);
        }
      );
  }

  onRefresh(): void {
    this.ruleTemplateService.reloadData();
    this.loadLocks(this.registry);
  }

  override onUnlock(): void {
    this.lockService.deleteDatabaseLock(this.selectedLock.id, this.selectedLock.editor).subscribe(() => this.loadLocks(this.registry));
  }

  onEdit(item: RuleTemplate): void {
    const startEditing = (): void => {
      this.ruleEditService.loadItem(item);
      this.startEditing(item.id, item.displayName);
    };
    if (this.selectedTableData().status === 'In Use') {
      const id = 'RULE_TEMPLATE_IN_USE_WARNING';
      const promptData = warnRuleTemplateInUsePromptDialogData(item.displayName);
      PromptDialogComponent.open(
        this.dialog,
        {
          id,
          data: promptData,
          width: '400px',
          panelClass: 'small-whitespace-dialog'
        },
        result => {
          if (result === RuleTemplateInUseDialogResult.EDIT) {
            startEditing();
          } else if (result === RuleTemplateInUseDialogResult.DUPLICATE) {
            this.duplicateAndEdit();
          }
        }
      );
    } else {
      startEditing();
    }
  }

  onDelete(item: RuleTemplate | RuleTemplate[]): void {
    const selectedItem = this.selectedItem();
    const items = Array.isArray(item) ? item : [item];
    const title = items.length > 1 ? 'Are you sure you want to delete these rule templates?' : 'Are you sure you want to delete this rule template?';
    const content = items.length > 1 ? items.map(s => s.displayName).reduce((p, n) => `${p}<br />${n}`) : `<b>${selectedItem.displayName}</b>`;
    deleteDialog(title, content, this.dialog).subscribe(dialogResult => {
      if (dialogResult) {
        this.ruleEditService.deleteItems(items).subscribe(result => {
          // result is a string if it succeeded, false otherwise
          if (result) {
            items.forEach(ruleTemplate => {
              if (this.tabService.getTabGroupItem(RULES_CARD_DATA.id, ruleTemplate.id.toString())) {
                this.tabService.removeItemFromTabGroup(RULES_CARD_DATA.id, { id: ruleTemplate.id.toString() }, true);
              }
            });
          }
        });
      }
    });
  }

  onPrint(item: RuleTemplate | RuleTemplate[]): void {
    throw new Error('Method not implemented.');
  }

  onDuplicate(item: RuleTemplate): void {
    this.promptDuplicateName(item)
      .pipe(first())
      .subscribe(name => {
        this.ruleEditService.duplicateItem(item, name);
      });
  }

  onCreate(): void {
    // const existingNames = this.data.map(s => s.displayName);
    const existingRuleTemplateNames = filterOldVersions(this.data()).map(tmp => tmp.displayName) || [];
    const name = newName(this.DEFAULT_RULE_TEMPLATE_NAME, this.translateService, existingRuleTemplateNames);
    this.ruleEditService.newItem(name).then(id => this.startEditing(id, name));
  }

  protected initialiseFilterConfig(): EditorBrowserFilterIOConfig<RuleTemplate>[] {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;
    const ruleFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: OksygenIcon.RULE_EDITOR,
        placeholder: t('Rule templates'),
        value: this.state.filters.ruleText
      },
      outputs: {
        currentValue: this.onRuleTextChange.bind(self),
        selectedValue: this.addRuleFilter.bind(self)
      }
    };

    const authorFilter: EditorBrowserFilterIOConfig<User | string> = {
      inputs: {
        icon: OksygenIcon.AUTHOR,
        placeholder: t('Author'),
        value: this.state.filters.authorText
      },
      outputs: {
        currentValue: this.onAuthorTextChange.bind(self),
        selectedValue: this.addAuthorFilter.bind(self)
      }
    };
    const filterConfig: EditorBrowserFilterIOConfig<any>[] = [ruleFilter, authorFilter];
    return filterConfig;
  }
  protected initialiseColumns(): FileManagerTableData[] {
    const columns: FileManagerTableData[] = [];
    return columns;
  }
  protected initialiseDisplayedColumns(): string[] {
    const columns = ['name', 'created', 'modified', 'status'];
    return columns;
  }

  protected toTableData(data: RuleTemplate[], locks: EditorLock[]): RuleTemplateSummaryData[] {
    const consolidatedVersions = filterOldVersions(data);
    const summary =
      consolidatedVersions?.map(ruleTemplate => {
        const status: EditorBrowserTableStatus = this.ruleTemplateStatus(ruleTemplate);
        const locked = !!locks?.find(lock => lock.editor === this.editorName() && lock.id === ruleTemplate.id);
        const selectedData = this.editorService.getSelectedTableData()?.find(selected => selected?.name === ruleTemplate.displayName);
        const summaryData = ruleTemplateToRuleTemplateSummaryData(this.userService, ruleTemplate, this.translateService, status, locked);
        summaryData.fmtChecked = !!selectedData?.fmtChecked;
        summaryData.fmtSelected = !!selectedData?.fmtSelected;

        return summaryData;
      }) ?? [];
    return summary;
  }

  protected getItemFromTableItem(data: RuleTemplateSummaryData): RuleTemplate {
    if (!data || !this.data) {
      return null;
    }
    return this.data().find(ruleTemplate => ruleTemplate.id === data.id);
  }

  sorterFunction(c: string, a: RuleTemplateSummaryData, b: RuleTemplateSummaryData): number {
    switch (c) {
      case 'name': {
        return a.name.localeCompare(b.name, this.getCurrentLocale());
      }
      case 'created': {
        if (a.created.date !== null && b.created.date !== null) {
          return a.created.date.isBefore(b.created.date) ? 1 : -1;
        } else if (a.created.date !== null && b.created.date === null) {
          return 1;
        } else {
          return -1;
        }
      }
      case 'modified': {
        if (a.modified.date !== null && b.modified.date !== null) {
          return a.modified.date.isBefore(b.modified.date) ? 1 : -1;
        } else if (a.modified.date !== null && b.modified.date === null) {
          return 1;
        } else {
          return -1;
        }
      }
      case 'status': {
        return a.status.localeCompare(b.status, this.getCurrentLocale());
      }
      default: {
        return 0;
      }
    }
  }

  override updateSort(sort: Sort): void {
    this.fileManagerTable.updateSort(sort);
  }

  displayAuthor(value: Author): string {
    return value?.name;
  }

  addRuleFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(FilterType.RULE, value));
    this.fileManagerTable.applyFilter();
  }

  onRuleTextChange(text: string): void {
    this.state.filters.ruleText = text;
    this.fileManagerTable.applyFilter();
  }

  onAuthorTextChange(text: User | string): void {
    this.state.filters.authorText = typeof text === 'object' ? `${text.firstName} ${text.lastName}` : text;
    this.fileManagerTable.applyFilter();
  }

  addAuthorFilter(value: User | string): void {
    const name = typeof value === 'object' ? `${value.firstName} ${value.lastName}` : value;
    this.state.filters.selectedFilters.push(new Filter(FilterType.AUTHOR, name, null));
    this.fileManagerTable.applyFilter();
  }

  override selectionChanged(): void {
    // FIXME use the super class impl
    const selectedValues = this.fileManagerTable?.getSelectedValues();

    this.selectedCount.set(selectedValues ? selectedValues.length : 0);

    this.ruleBrowserSerivce.setSelectedRuleTemplate(null);
    this.selectedTableData.set(undefined);

    if (this.selectedCount() > 0) {
      const singleSelected = selectedValues.length === 1;

      if (singleSelected) {
        this.selectedTableData.set(selectedValues[0]);
        this.ruleTemplateService.getRuleTemplateById(this.selectedTableData().id).subscribe(rt => this.ruleBrowserSerivce.setSelectedRuleTemplate(rt));
        this.selectedLock = this.locks().find(lock => lock.id === this.selectedItem().id);
        this.lockDisplay = this.getLockDisplay(this.authService.getLoggedInUser(), this.lockService.getMachineId());
        const lockHolder = this.lockDisplay?.lockHolder;
        if (lockHolder === 'other') {
          this.editDisabled.set(true);
          this.deleteDisabled.set(true);
          this.detailEditDisabled.set(true);
          this.detailDeleteDisabled.set(true);
        }
      } else {
        this.selectedLock = null;
      }

      this.editDisabled.set(!singleSelected);
      this.duplicateDisabled.set(!singleSelected); // TODO !singleSelected;
      this.deleteDisabled.set(selectedValues.some(r => r.status === 'In Use'));
      this.detailDeleteDisabled.set(selectedValues.some(r => r.status === 'In Use'));
      this.printDisabled.set(true); // TODO false;
      this.exportDisabled.set(false);
    } else {
      this.editDisabled.set(true);
      this.duplicateDisabled.set(true);
      this.deleteDisabled.set(true);
      this.printDisabled.set(true);
      this.selectedLock = null;
      this.exportDisabled.set(true);
    }
  }

  cellClicked(value: RuleTemplateSummaryData): void {}

  startEditing(templateId: string, name: string): void {
    const url = `/editors/rules/${templateId}`;
    this.router.navigateByUrl(url);
    const ruleEditorTab: RuleTabType = {
      data: {
        groupId: RULES_CARD_DATA.id,
        icon: OksygenIcon.FILE_NEW,
        id: templateId.toString(),
        routerLink: url,
        name,
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => this.ruleEditService.confirmCloseEditor(templateId),
        onClose: () => {
          this.ruleEditService.destroyManagers(templateId);
          this.contextSupplier.destroyCurrentContext(templateId);
          if (this.lockService.isEnabled(this.editorName())) {
            this.lockService.deleteDatabaseLock(templateId, this.editorName()).subscribe(() => this.loadLocks(this.registry));
          }
        }
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: RULES_CARD_DATA.id,
        groupName: RULES_CARD_DATA.name,
        route: RULES_CARD_DATA.routerLink,
        groupIcon: RULES_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [ruleEditorTab]
    });
    this.lockEditorItem(templateId.toString());
  }

  applyFilters(ruleTemplate: RuleTemplateSummaryData): boolean {
    const names = [ruleTemplate.name, ruleTemplate.description];
    const authors = [ruleTemplate.created?.name, ruleTemplate.modified?.name];

    if (
      !allFilterTypesMatch(
        [
          { t: FilterType.RULE, v: names },
          { t: FilterType.AUTHOR, v: authors }
        ],
        this.state.filters.selectedFilters
      )
    ) {
      return false;
    }

    if (!filterMatches(names, this.state.filters.ruleText)) {
      return false;
    }

    if (!filterMatches(authors, this.state.filters.authorText)) {
      return false;
    }

    return true;
  }

  private ruleTemplateStatus(ruleTemplate: RuleTemplate): EditorBrowserTableStatus {
    let scenarioList: Scenario[];
    this.scenarioService?.data()?.pipe(
      takeOneTruthy()
    )?.subscribe(scenarios => {
      scenarioList = scenarios;
    });
    return ruleTemplateStatus(ruleTemplate, scenarioList);
  }

  private duplicateAndEdit(): void {
    const existingNames = this.data().map(s => s.displayName);
    const name = newName(`${this.selectedItem().displayName} - ${this.COPY}`, this.translateService, existingNames);
    const duplicateNameError = 'duplicateName';
    const missingError = 'missing';
    const spacesError = 'spaces';
    const specialCharacterError = 'specialCharacter';
    const duplicateFormControl = newFormControl(UpdateOn.CHANGE, c => {
      if (c.value) {
        const match = this.data().find(s => s.displayName === c.value);
        const exists = !!match;
        if (exists) {
          return { [duplicateNameError]: true };
        } else if (c.value?.trim() !== c.value) {
          return { [spacesError]: true };
        } else if (illegalNameCharacterExists(c.value)) {
          return { [specialCharacterError]: true };
        }
      } else {
        return { [missingError]: true };
      }
      return null;
    });

    duplicateFormControl.setValue(name);
    const buttons: ButtonInfo[] = [
      CANCEL_BUTTON,
      {
        color: MaterialThemePalette.PRIMARY,
        text: t('Duplicate'),
        data: true,
        disableOnError: true
      }
    ];
    const input: BasicSingleInputDialogInput = {
      appearance: 'outline',
      floatLabel: 'always',
      label: t('Name'),
      inputFormControl: duplicateFormControl,
      formControlErrors: [
        // TODO: Possibly put these two messages in a shared place (they're copied from scenario-detail-panel)
        {
          type: duplicateNameError,
          text: this.DUPLICATE_RULE_NAME_ERROR
        },
        {
          type: missingError,
          text: this.MISSING_RULE_NAME_ERROR
        },
        {
          type: spacesError,
          text: this.SPACES_RULE_NAME_ERROR
        },
        {
          type: specialCharacterError,
          text: this.SPECIAL_CHARACTER_RULE_NAME_ERROR
        }
      ]
    };
    const data = new BasicSingleInputDialogData(t('Duplicate'), buttons, input);
    BasicSingleInputDialogComponent.open(this.dialog, data, result => {
      if (result.buttonData) {
        this.ruleEditService.duplicateItem(this.selectedItem(), result.value).then(duplicatedItemId => {
          // once we duplicate the item, the manager automatically refreshes our list.
          // we need to wait for this refresh to occur before we can edit the template
          const subscription = this.ruleTemplateService.data().subscribe(ruleTemplates => {
            const newItem = ruleTemplates.find(d => d.id === duplicatedItemId);
            if (newItem) {
              this.ruleEditService.loadItem(newItem);
              this.startEditing(duplicatedItemId, result.value);
              subscription?.unsubscribe();
            }
          });
        });
      }
    });
  }

  private promptDuplicateName(ruleTemplate: RuleTemplate): Observable<string> {
    const existingNames = this.data().map(s => s.displayName);
    const name = newName(`${ruleTemplate.displayName} - ${this.COPY}`, this.translateService, existingNames);
    const duplicateNameError = 'duplicateName';
    const missingError = 'missing';
    const spacesError = 'spaces';
    const specialCharacterError = 'specialCharacter';
    const duplicateFormControl = newFormControl(UpdateOn.CHANGE, c => {
      if (c.value) {
        const match = this.data().find(s => s.displayName === c.value);
        const exists = !!match;
        if (exists) {
          return { [duplicateNameError]: true };
        } else if (c.value?.trim() !== c.value) {
          return { [spacesError]: true };
        } else if (illegalNameCharacterExists(c.value)) {
          return { [specialCharacterError]: true };
        }
      } else {
        return { [missingError]: true };
      }
      return null;
    });

    duplicateFormControl.setValue(name);
    const buttons: ButtonInfo[] = [
      CANCEL_BUTTON,
      {
        color: MaterialThemePalette.PRIMARY,
        text: t('Duplicate'),
        data: true,
        disableOnError: true
      }
    ];
    const input: BasicSingleInputDialogInput = {
      appearance: 'outline',
      floatLabel: 'always',
      label: t('Name'),
      inputFormControl: duplicateFormControl,
      formControlErrors: [
        // TODO: Possibly put these two messages in a shared place (they're copied from scenario-detail-panel)
        {
          type: duplicateNameError,
          text: this.DUPLICATE_RULE_NAME_ERROR
        },
        {
          type: missingError,
          text: this.MISSING_RULE_NAME_ERROR
        },
        {
          type: spacesError,
          text: this.SPACES_RULE_NAME_ERROR
        },
        {
          type: specialCharacterError,
          text: this.SPECIAL_CHARACTER_RULE_NAME_ERROR
        }
      ]
    };
    const data = new BasicSingleInputDialogData(t('Duplicate'), buttons, input);
    return new Observable(o => {
      BasicSingleInputDialogComponent.open(this.dialog, data, result => {
        if (result?.buttonData) {
          o.next(result.value);
          o.complete();
        }
      });
    });
  }

  protected initialiseState(): BrowserState<RuleTemplateFilterFields, FilterType> {
    return this.uiStateModelManager.getStateModel<any>('RuleBrowserComponent', () => ({
      filters: {
        ruleText: '',
        authorText: '',
        selectedFilters: new SelectedFilterArray<FilterType>()
      }
    }));
  }

  onPublish(item: RuleTemplate | RuleTemplate[], isActive: boolean): void {
    throw new Error('Method not implemented.');
  }
}
