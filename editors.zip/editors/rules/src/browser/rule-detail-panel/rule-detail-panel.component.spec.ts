/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { IconFieldComponent } from '@oksygen-sim-train-libraries/components-services/common';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainRuleEditModule } from '../../rule-edit.module';
import { RuleDetailPanelComponent } from './rule-detail-panel.component';

describe('RuleDetailPanelComponent', () => {
  let component: RuleDetailPanelComponent;
  let fixture: ComponentFixture<RuleDetailPanelComponent>;

  beforeEach(async () => {
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainRuleEditModule, IconFieldComponent],
        declarations: [RuleDetailPanelComponent]
      }).compileComponents();
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleDetailPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
