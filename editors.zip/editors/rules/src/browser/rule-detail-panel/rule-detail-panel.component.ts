/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { UNKNOWN } from '@oksygen-common-libraries/common';
import { RuleTemplateSummaryData } from '../../models/rule-summary-data.model';

@Component({
  selector: 'oksygen-rule-detail-panel',
  templateUrl: './rule-detail-panel.component.html',
  styleUrls: ['./rule-detail-panel.component.scss']
})
export class RuleDetailPanelComponent implements OnInit {
  readonly UNKNOWN = UNKNOWN;

  @Input() edit: false;
  @Input() toolbox = true;
  @Input() summaryData: RuleTemplateSummaryData;

  nameControl  = new UntypedFormControl('');

  constructor() { }

  ngOnInit(): void {
    this.nameControl.setValue(this.summaryData?.name ?? '');
  }

}
