/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component } from '@angular/core';
import { MatFormFieldControl } from '@angular/material/form-field';
import { OksygenMatFormFieldComponent } from '@oksygen-common-libraries/material/components';

@Component({
  selector: 'oksygen-rule-detail-block-list',
  templateUrl: './rule-detail-block-list.component.html',
  styleUrls: ['./rule-detail-block-list.component.scss'],
  providers: [{ provide: MatFormFieldControl, useExisting: RuleDetailBlockListComponent }]
})
export class RuleDetailBlockListComponent extends OksygenMatFormFieldComponent<{name: string; description: string}[]>
implements MatFormFieldControl<{name: string; description: string}[]> {}
