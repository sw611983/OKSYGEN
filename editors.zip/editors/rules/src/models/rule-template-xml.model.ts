/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import moment from 'moment';

import { HISTORY_TYPE_CREATED, HISTORY_TYPE_MODIFIED, momentToString } from '@oksygen-common-libraries/common';
import { User } from '@oksygen-sim-core-libraries/components-services/users';
import { handleUnknownXmlData } from '@oksygen-sim-train-libraries/components-services/common';
import {
  FromRuleTemplateConnection,
  FromRuleTemplateRuleBlock,
  RuleBlock,
  RuleTemplate,
  ToRuleTemplateBlockXml,
  ToRuleTemplateConnectionXml,
  ToRuleTemplateXml
} from '@oksygen-sim-train-libraries/components-services/rules';
import { toVersionString } from '@oksygen-sim-train-libraries/components-services/versioning';

const knownRuleTemplateKeys = [
  'baseInfo',
  'id',
  'displayName',
  'displayDescription',
  'history',
  'version',
  'ruleBlocks',
  'connections'
];

/**
 * @param rawRuleTemplate The initial object which will be updated with the new data from ruleBlocks and ruleTemplate
 * @param ruleBlocks TODO - Someone provide a real description, I'm not sure what this is
 * @param ruleTemplate The updated rule template
 * @param loggedInUser The user who did the changes
 * @returns A transfer object containing the rule template XML
 */
export function toRuleTemplateXml(rawRuleTemplate: any, ruleBlocks: RuleBlock[], ruleTemplate: RuleTemplate): ToRuleTemplateXml {
  const data: ToRuleTemplateXml = {
      $: {
        id: ruleTemplate.id
      },
      version: toVersionString(ruleTemplate.version),
      displayName: ruleTemplate.displayName,
      displayDescription: ruleTemplate.displayDescription,
      history: {
        historyLog: []
      }
  };

  ruleTemplate.history?.historyLog?.forEach(history => {
    data.history.historyLog.push({
      $: {
        type: history.type,
        authorFirstName: history.authorFirstName,
        authorLastName: history.authorLastName,
        id: history.id,
        version: history.version,
        timestamp: history.timestamp
      }
    });
  });

  if (ruleTemplate.ruleBlocks?.ruleBlock.length > 0) {
    data.ruleBlocks = {ruleBlock: ruleTemplate.ruleBlocks.ruleBlock.map(def =>  toRuleBlockXml(def, ruleBlocks?.find(b => def?.blockType === b?.name))) };
  }
  if (ruleTemplate?.connections?.connection?.length > 0) {
    data.connections = { connection: ruleTemplate.connections.connection.map(toConnectionXml) };
  }

  return handleUnknownXmlData(rawRuleTemplate, data, knownRuleTemplateKeys);
}

/**
 * This will modify the rule template you pass in and add a history entry.
 * The first entry will be a CREATE, all further entries will be MODIFIED.
 */
export function appendRuleTemplateHistory(ruleTemplate: ToRuleTemplateXml, loggedInUser: User): void {
  if (!ruleTemplate?.history?.historyLog || ruleTemplate?.history.historyLog?.length === 0) {
    ruleTemplate.history.historyLog.push({
      $: {
        type: HISTORY_TYPE_CREATED,
        authorFirstName: loggedInUser.firstName,
        authorLastName: loggedInUser.lastName,
        id: ruleTemplate.$.id,
        version: '1',
        timestamp: momentToString(moment())
      }
    });
  } else {
    // add new entries to the start of the array
    ruleTemplate.history.historyLog.unshift({
      $: {
        type: HISTORY_TYPE_MODIFIED,
        authorFirstName: loggedInUser.firstName,
        authorLastName: loggedInUser.lastName,
        id: ruleTemplate.$.id,
        version: toVersionString(ruleTemplate.version),
        timestamp: momentToString(moment())
      }
    });
  }
}

function toRuleBlockXml(def: FromRuleTemplateRuleBlock, ruleBlock: RuleBlock): ToRuleTemplateBlockXml {
  // If there is any property without any value or with defautl values filter out those.
  // This is because when saving a rule template, only the properties that have changed
  // from the default value should be included in the saved XML.
  const filteredProperties = def?.properties?.property?.filter(defProp => {
    const prop = ruleBlock?.properties?.property?.find(p => p.name === defProp.name);
    return defProp.value && defProp.value !== undefined && defProp.value !== prop.defaultValue;
  });
  const properties = filteredProperties?.map(p => ({
    name: p.name,
    value: p.value === true ? 'true' : p.value === false ? 'false' : p.value // hack to process booleans as booleans
  })) || [];
  const xml: ToRuleTemplateBlockXml = {
    $: {
      id: def.id
    },
    blockType: def.blockType,
    displayName: def.displayName,
    displayDescription: def.displayDescription,
    version: def.version
  };
  if(properties?.length > 0) {
    xml.properties = { property: properties };
  }
  if (def.metaData) {
    xml.metaData = def.metaData;
  }
  return xml;
}

function toConnectionXml(def: FromRuleTemplateConnection): ToRuleTemplateConnectionXml {
  return {
    source: {
      blockId: def?.source?.blockId,
      port: def?.source?.port
    },
    destination: {
      blockId: def?.destination?.blockId,
      port: def?.destination?.port
    }
  };
}
