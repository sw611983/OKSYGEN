/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TranslateService } from '@oksygen-common-libraries/material/translate';


import { getCreated, getLastModified, historyToCreatedModified } from '@oksygen-common-libraries/common';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import {
  EditorBrowserTableData,
  EditorBrowserTableStatus,
  isEditorBrowserTableStatus
} from '@oksygen-sim-train-libraries/components-services/common';
import { RuleTemplate, RuleTemplateHistory } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { toVersionString, Version } from '@oksygen-sim-train-libraries/components-services/versioning';

export interface RuleTemplateSummaryData extends EditorBrowserTableData {
  id: string;
  description: string;
  version: Version|string|number;
  blocks: {name: string; description: string}[];
}

/**
 * Get the status of a rule template. Checks if it's in use by a scenario, then determines if the template is published or a draft.
 *
 * @param ruleTemplate the rule template to fetch the status of
 * @param scenarios a list of scenarios to check against (if the rule template is in use by them)
 */
export function ruleTemplateStatus(ruleTemplate: RuleTemplate, scenarios: Scenario[]): EditorBrowserTableStatus {
  if (scenarios?.length) {
    const scenario = scenarios?.find(s => s.rule?.find(rule => rule.ruleTemplateReference.id === ruleTemplate.id));
    if (scenario) { return 'In Use'; }
  }
  return 'Not In Use';
  // return ruleTemplate.history?.historyLog?.length > 0 ? 'Published' : 'Draft';
}

type StatusType = (() => EditorBrowserTableStatus) | EditorBrowserTableStatus;
export function ruleTemplateToRuleTemplateSummaryData(
  userService: UserService,
  ruleTemplate: RuleTemplate,
  translateService: TranslateService,
  status: StatusType = 'Unknown',
  locked: boolean = false
): RuleTemplateSummaryData {
  const created: RuleTemplateHistory = {
    id: ruleTemplate.id,
    version: toVersionString(ruleTemplate.version),
    ...getCreated(ruleTemplate?.history?.historyLog)
  };
  const modified: RuleTemplateHistory = {
    id: ruleTemplate.id,
    version: toVersionString(ruleTemplate.version),
    ...getLastModified(ruleTemplate?.history?.historyLog)
  };
  const creator = userService.users.find(u => u.firstName === created.authorFirstName && u.lastName === created.authorLastName);
  const modifier = userService.users.find(u => u.firstName === modified.authorFirstName && u.lastName === modified.authorLastName);

  const evaluatedStatus = typeof status === 'function' ? status() : isEditorBrowserTableStatus(status) ? status : 'Unknown';
  const blocks = ruleTemplate.ruleBlocks.ruleBlock.map(rb => ({name: rb.displayName, description: rb.displayDescription}));
  const tableData: RuleTemplateSummaryData = {
    id: ruleTemplate.id,
    name: translateService.instant(ruleTemplate.displayName ?? ''),
    description: ruleTemplate.displayDescription ? translateService.instant(ruleTemplate.displayDescription) : '',
    created: historyToCreatedModified(created, creator?.avatar),
    modified: historyToCreatedModified(modified, modifier?.avatar),
    version: ruleTemplate.version,
    status: evaluatedStatus,
    blocks,
    locked
  };

  return tableData;
}
