/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { SelectedFilterArray } from '@oksygen-common-libraries/material/components';

export enum RuleEditorFilterType {
  // ```no-mat-icon``` prefix prevents the chip list from displaying mat-icons
  // Which is not very intuitive though...
  CATEGORY = 'no-mat-icon-category',
  NAME = 'no-mat-icon-displayName'
}

export interface RuleEditorUiState {
  filters: {
    search: string;
    selectedFilters: SelectedFilterArray<RuleEditorFilterType>;
  };
}

export interface ZoomAvailable {
  canZoomIn: boolean;
  canZoomOut: boolean;
}

export enum ZoomType {
  IN = 'in',
  OUT = 'out',
  FIT = 'fit'
}
