/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Store } from '@ngrx/store';
import { BehaviorSubject, combineLatest, Observable, of, zip, forkJoin } from 'rxjs';
import { catchError, switchMap, tap, map, first, mergeMap } from 'rxjs/operators';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import moment from 'moment';
import { NgZone } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

import {
  Dictionary, filterTruthy, momentToString, selfCompletingObservable, SelfCompletingObservable, SuperCalled, takeOneTruthy
} from '@oksygen-common-libraries/common';
import { camelCaseToSnakeCasePostProcessor, DataAccessService, dateToStringCustomiser, XmlJsonUtil } from '@oksygen-common-libraries/data-access';
import { Logging } from '@oksygen-common-libraries/pio';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import {
  PropertyUpdate,
  RuleBlock,
  RuleBlockService,
  RuleTemplate,
  RuleTemplateConnection,
  RuleTemplateRuleBlock,
  RuleTemplateRuleBlockMeta
} from '@oksygen-sim-train-libraries/components-services/rules';

import { RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';
import { ruleEditorActions } from '../store/rule-editor.actions';
import { getSavedRuleTemplateName, getRule, getRuleTempalteUnsavedChanges, canUndoRule, canRedoRule } from '../store/rule-editor.selectors';
import { RuleEditorState } from '../store/rule-editor.state';
import { appendRuleTemplateHistory, toRuleTemplateXml } from '../models/rule-template-xml.model';
import { RuleEditorContext } from './rule-editor-context';
import { BaseDataEditorManager, LockDatabaseService } from '@oksygen-sim-train-libraries/components-services/editors';
import { cloneDeep } from 'lodash';

import { OK_BUTTON, PromptDialogComponent, PromptDialogData } from '@oksygen-common-libraries/material/components';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { toVersionString, versionFactory, versionCompare, Version, incrementVersionBy } from '@oksygen-sim-train-libraries/components-services/versioning';
import { Backup } from '@oksygen-common-libraries/pio/backup';

export function RuleBlockToTemplateBlock(
  ruleBlock: RuleBlock, id: number, meta?: RuleTemplateRuleBlockMeta
): RuleTemplateRuleBlock {
  const block: RuleTemplateRuleBlock = {
    id,
    blockType: ruleBlock.name,
    displayName: ruleBlock.displayName,
    version: '1.0.0',
    displayDescription: ruleBlock?.displayDescription ?? '',
    properties: ruleBlock.properties,
    metaData: meta
  };
  return block;
}

export class RuleEditManager extends BaseDataEditorManager<RuleTemplate, RuleEditorContext> {

  ruleTemplate: RuleTemplate;
  ruleBlocks: RuleBlock[];

  public canUndo$: Observable<boolean>;
  public canRedo$: Observable<boolean>;

  constructor(
    private ruleTemplateId: string,
    private store: Store<RuleEditorState>,
    private dataAccessService: DataAccessService,
    private authService: AuthService,
    private ruleTemplateService: RuleTemplateService,
    private ruleBlockService: RuleBlockService,
    private logger: Logging,
    private zone: NgZone,
    dialog: MatDialog,
    private snackbar: MatSnackBar,
    translateService: TranslateService,
    private scenario$: Observable<Scenario[]>,
    private lockService: LockDatabaseService,
    private backup: Backup
  ) {
    super(translateService, dialog);
    const sub = this.store.select(getRuleTempalteUnsavedChanges(this.ruleTemplateId)).subscribe(unsavedChanges => (this.unsavedChanges = unsavedChanges));
    this.ruleBlockService.data().pipe(takeOneTruthy()).subscribe(blocks => this.ruleBlocks = blocks);
    this.subscription.add(sub);
    this.canUndo$ = this.store.select(canUndoRule(this.ruleTemplateId));
    this.canRedo$ = this.store.select(canRedoRule(this.ruleTemplateId));
  }

  override destroy(): SuperCalled {
    this.context?.destroy();
    return super.destroy();
  }

  setEditingContext(dm: RuleEditorContext): void {
    this.context = dm;

    this.subscription.add(
      this.store
        .select(getRule(this.ruleTemplateId))
        .pipe(filterTruthy())
        .subscribe(ruleTemplate => {
          this.ruleTemplate = ruleTemplate;

          (this.context?.ruleTemplate$ as BehaviorSubject<RuleTemplate>)?.next(ruleTemplate);
        })
    );
  }

  setVersion(version: Version): void {
    this.getAllVersions().pipe(
      map(templates => templates.find(template => versionCompare(template.version, version) === 0)),
      takeOneTruthy(undefined, 100)
    ).subscribe(template => {
      (this.context.ruleTemplate$ as BehaviorSubject<RuleTemplate>).next(template);
    });
  }

  /**
   * Create a new (blank!) rule template for this manager to... manage!
   * Uses the id that was specified when this manager was created
   * which is also it's key in the service's manager map.
   */
  newItem(name: string): void {
    this.store.dispatch(ruleEditorActions.newRule({ id: this.ruleTemplateId, name }));
  }

  /**
   * Set this manager to manage an existing rule template.
   *
   * @param ruleTemplate the rule template to use
   */
  loadItem(item: RuleTemplate): void {
    this.store.dispatch(ruleEditorActions.loadRuleTemplate({ id: item.id, original: item }));
  }

  override saveItem(): SelfCompletingObservable<boolean> {
    return this.saveRuleTemplate() as any;
  }
  override saveItemDirect(item: RuleTemplate): SelfCompletingObservable<any> {
    const xmlFormatRuleTemplate = toRuleTemplateXml(null, this.ruleBlocks, item);
    appendRuleTemplateHistory(xmlFormatRuleTemplate, this.authService.getLoggedInUser());
    const xml = XmlJsonUtil.convertObjectToXml(xmlFormatRuleTemplate, 'rule_template');
    return this.doSaveRuleTemplate(item, xml);
  }

  getItemName(): string {
    return this.ruleTemplate?.displayName || '';
  }

  deleteItem(item: RuleTemplate, reload?: boolean): SelfCompletingObservable<void> {
    // FIXME make atomic
    this.store.dispatch(ruleEditorActions.ruleTemplateClosed({id: item.id}));
    return this.getAllVersions(item).pipe(
      switchMap(ruleTemplates => {
        const deletions = ruleTemplates.map( rt => RuleEditManager.deleteRuleTemplate(this.dataAccessService, rt, this.logger, item.displayName));
        const deletionBundle = zip(...deletions).pipe(map(results => {}));
        return deletionBundle;
      }),
      tap(() => {
        this.zone.run(() => { // snackbar needs to run in zone
          this.snackbar.open(this.translateService.instant(t('Rule Template Deleted')), '', { duration: 3000 });
        });
        if (reload) {
          // setTimeout to prevent expression changed after it was checked error
          setTimeout(() => this.ruleTemplateService.reloadData());
        }
      })
    );
  }

  duplicateItem(item: RuleTemplate, newName?: string): SelfCompletingObservable<any> {
    const newRuleTemplate = cloneDeep(item);
    if (newRuleTemplate.id !== this.ruleTemplateId) {
      newRuleTemplate.id = this.ruleTemplateId;
    }
    newRuleTemplate.displayName = newName;
    const loggedInUser = this.authService.getLoggedInUser();
    newRuleTemplate.history.historyLog = [
      {
        type: 'Copied',
        authorFirstName: loggedInUser.firstName,
        authorLastName: loggedInUser.lastName,
        timestamp: momentToString(moment()),
        id: item.id,
        version: toVersionString(item.version)
      }
    ];
    newRuleTemplate.version = versionFactory(1, 0, 0);
    return this.duplicateRuleTemplate(newRuleTemplate).pipe(
      catchError(err => selfCompletingObservable(false)),
      tap(result => {
        if (result) {
          this.zone.run(() => { // snackbar needs to run in zone
            this.snackbar.open(this.translateService.instant(t('Rule Template Duplicated')), '', { duration: 3000 });
          });
        } else {
          const promptData = new PromptDialogData();
          // FIXME More meaningful message please
          promptData.title = t(`Could not duplicate rule Template`);
          // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
          promptData.content = t('Please contact an administrator.');
          promptData.buttons = OK_BUTTON;
          PromptDialogComponent.open(this.dialog, { id: 'DUPLICATE_FAILED', data: promptData });
        }
      })
    );
  }

  get data$(): Observable<RuleTemplate> {
    return of(this.ruleTemplate);
  }

  /**
   * Get the database version of the rule (no edits).
   */
  public getSavedRuleTemplateName(): Observable<string> {
    return this.store.select(getSavedRuleTemplateName(this.ruleTemplateId));
  }

  public getRuleTemplate(): RuleTemplate {
    return this.ruleTemplate;
  }

  public renameRuleTemplate(name: string): void {
    this.store.dispatch(ruleEditorActions.setRuleTemplateName({id: this.ruleTemplateId, name}));
  }

  public renameRuleTemplateDescription(description: string): void {
    this.store.dispatch(ruleEditorActions.setRuleTemplateDescription({id: this.ruleTemplateId, desc: description}));
  }

  public renameBlock(blockId: number, name: string): void {
    this.store.dispatch(ruleEditorActions.updateRuleBlockName({id: this.ruleTemplateId, blockId, name}));
  }

  public renameBlockDescription(blockId: number, description: string): void {
    this.store.dispatch(ruleEditorActions.updateRuleBlockDescription({id: this.ruleTemplateId, blockId, description}));
  }

  public updateBlockProperty(blockId: number, propertyName: string, value: string|number|boolean): void {
    this.store.dispatch(ruleEditorActions.updateRuleBlockProperty({id: this.ruleTemplateId, blockId, propertyName, propertyValue: value}));
  }

  public updateBlockProperties(blockId: number, updates: PropertyUpdate[]): void {
    this.store.dispatch(ruleEditorActions.updateRuleBlockProperties({id: this.ruleTemplateId, blockId, updates}));
  }

  public undo(): void {
    this.store.dispatch(ruleEditorActions.undoRuleEdit({ id: this.ruleTemplateId }));
  }

  public redo(): void {
    this.store.dispatch(ruleEditorActions.redoRuleEdit({ id: this.ruleTemplateId }));
  }

  public addRuleBlock(ruleBlock: RuleBlock, meta?: RuleTemplateRuleBlockMeta): void {
    const max = this.getMaxBlockId();
    const templateBlock = RuleBlockToTemplateBlock(ruleBlock, max + 1, meta);
    templateBlock.displayName = this.translateService.instant(templateBlock.displayName);
    templateBlock.displayDescription = this.translateService.instant(templateBlock.displayDescription);
    this.store.dispatch(ruleEditorActions.addRuleBlockToRuleTemplate({id: this.ruleTemplateId, block: templateBlock}));
  }

  public removeRuleBlock(templateBlock: RuleTemplateRuleBlock): void {
    const params = { id: this.ruleTemplateId, block: templateBlock };
    this.store.dispatch(ruleEditorActions.removeRuleBlockFromRuleTemplate(params));
  }

  public updateRuleBlockMeta(blockId: number, meta: RuleTemplateRuleBlockMeta): void {
    const params = { id: this.ruleTemplateId, blockId, meta };
    this.store.dispatch(ruleEditorActions.updateRuleBlockInRuleTemplateMeta(params));
  }

  public updateRuleBlockConnections(connections: RuleTemplateConnection[]): void {
    const params = { id: this.ruleTemplateId, connections };
    this.store.dispatch(ruleEditorActions.updateRuleTemplateConnections(params));
  }

  /**
   * Returns an observable containing the result.
   * True if the save succeeded, false if it failed for unknown reasons.
   */
  public saveRuleTemplate(): SelfCompletingObservable<boolean|string> {
    const dbTemplate$ = this.ruleTemplateService.getRuleTemplateById(this.ruleTemplateId).pipe(first());
    const updatedTemplate$ =  this.context.ruleTemplate$.pipe(first());
    // would prefer zip but it just disappears into the ether..
    return combineLatest([dbTemplate$, updatedTemplate$]).pipe(
      // map(([rawRuleTemplate, ruleTemplate, savedTemplateName]) => [rawRuleTemplate, cloneDeep(ruleTemplate), savedTemplateName]),
      switchMap(([dbRuleTemplate, ruleTemplate]) => {
        const error = RuleEditManager.validateRuleTemplateForSave(ruleTemplate);
        const updatedRuleTemplate = cloneDeep(ruleTemplate);
        if (error) {
          // FIXME bubble up reason.
          this.logger.warn(`Failed to save rule template: ${error}`);
          return selfCompletingObservable(false);
        }
        if (dbRuleTemplate) {
          // only increment the version if it has already been saved
          this.incrementRuleTemplateVersion(updatedRuleTemplate);
        } else {
          if (this.lockService.isEnabled('rule')) {
            const lock = this.lockService.createLockData(ruleTemplate.id, 'rule'); // FIXME magic string
            this.lockService.addDatabaseLock(lock);
          }
        }
        return this.processRuleTemplateSave(dbRuleTemplate, updatedRuleTemplate);
      })
    );
  }

  /**
   * Get all currently existing versions of this rule template.
   * This will get the database version!!
   * If no rule template is supplied use this data manager's rule template.
   */
  public getAllVersions(ruleTemplate?: RuleTemplate): Observable<RuleTemplate[]> {
    const id = ruleTemplate?.id ?? this.ruleTemplateId;
    return this.ruleTemplateService.data().pipe(
      map(ruleTemplates => {
        const templates = ruleTemplates?.filter(rt => rt.id === id) || [];
        return templates;
      }),
    );
  }

  exportRuleTemplate(): SelfCompletingObservable<boolean|string> {
    const dbTemplate$ = this.ruleTemplateService.getRuleTemplateById(this.ruleTemplateId).pipe(first());
    const updatedTemplate$ =  this.context.ruleTemplate$.pipe(first());
    // would prefer zip but it just disappears into the ether..
    return combineLatest([dbTemplate$, updatedTemplate$]).pipe(
      // map(([rawRuleTemplate, ruleTemplate, savedTemplateName]) => [rawRuleTemplate, cloneDeep(ruleTemplate), savedTemplateName]),
      switchMap(([dbRuleTemplate, ruleTemplate]) => {
        const error = RuleEditManager.validateRuleTemplateForSave(ruleTemplate);
        const updatedRuleTemplate = cloneDeep(ruleTemplate);
        if (error) {
          // FIXME bubble up reason.
          this.logger.warn(`Failed to backup rule template: ${error}`);
          return selfCompletingObservable(false);
        }
        const xmlFormatRuleTemplate = toRuleTemplateXml(dbRuleTemplate, this.ruleBlocks, updatedRuleTemplate);
        // appendRuleTemplateHistory(xmlFormatRuleTemplate, this.authService.getLoggedInUser());
        const xml = XmlJsonUtil.convertObjectToXml(
          xmlFormatRuleTemplate, 'rule_template'
        );
        const fileName = RuleEditManager.getRuleTemplateFileName(ruleTemplate);
        return this.backup.postBackup(fileName, xml, true).pipe(
          map(result => {
            if (result && 'result' in result) {
              return 'success';
            } else {
              return false;
            }
          })
        );
      })
    );
  }

  private duplicateRuleTemplate(ruleTemplate: RuleTemplate): SelfCompletingObservable<boolean> {
    const user = this.authService.getLoggedInUser();
    const ruleTemplateXml = toRuleTemplateXml(null, this.ruleBlocks, ruleTemplate);
    appendRuleTemplateHistory(ruleTemplateXml, user);
    const xml = XmlJsonUtil.convertObjectToXmlWith(
      ruleTemplateXml,
      'rule_template',
      {
        customisers: [dateToStringCustomiser],
        postProcessors: [camelCaseToSnakeCasePostProcessor]
    });
    // const successPreProcess = (): void => {};
    const successPostProcess = (): void => {
      this.ruleTemplateService.reloadData();
    };
    successPostProcess.bind(this);
    return this.doSaveRuleTemplate(ruleTemplate, xml);
  }

  private processRuleTemplateSave(dbRuleTemplate: RuleTemplate, updatedRuleTemplate: RuleTemplate): SelfCompletingObservable<any> {
    const xmlFormatRuleTemplate = toRuleTemplateXml(dbRuleTemplate, this.ruleBlocks, updatedRuleTemplate);
    appendRuleTemplateHistory(xmlFormatRuleTemplate, this.authService.getLoggedInUser());
    const xml = XmlJsonUtil.convertObjectToXml(xmlFormatRuleTemplate, 'rule_template');

    // This is not in use anymore. It was used to delete versions that were not in use anymore.
    //
    // this.getAllVersions(updatedRuleTemplate).pipe(
    //   switchMap(ruleTemplates => this.versionsInUse(ruleTemplates)),
    //   switchMap(ruleTemplates => {
    //     const deletes: Observable<boolean>[] = ruleTemplates.notInUse.map(
    //       rt => RuleEditManager.deleteRuleTemplate(this.dataAccessService, rt, this.logger).pipe(
    //         catchError(() => selfCompletingObservable(false)),
    //         map(success => !!success)
    //       )
    //     );
    //     return zip(...deletes);
    //   }),
    //   switchMap(
    //     deletes =>
    //       iif(
    //         () => deletes.reduce((prev, curr) => curr && prev, true),
    //         this.doSaveRuleTemplate(updatedRuleTemplate, xml),
    //         selfCompletingObservable(false)
    //       )
    //   ),
    // );

    return this.getAllVersions(updatedRuleTemplate).pipe(
      first(),
      mergeMap(ruleTemplates => this.processNameChanges(updatedRuleTemplate, ruleTemplates)),
      mergeMap(() => this.doSaveRuleTemplate(updatedRuleTemplate, xml)),
      tap(result => this.store.dispatch(ruleEditorActions.setRuleTemplateVersion({ id: updatedRuleTemplate.id, version: updatedRuleTemplate.version })))
    );
  }

  private doSaveRuleTemplate(ruleTemplate: RuleTemplate, xml: string): SelfCompletingObservable<any> {
    const user = this.authService.getLoggedInUser();
    const savePath = RuleEditManager.getRuleTemplateFileName(ruleTemplate);

    const dictionary: Dictionary<string> = {};
    dictionary.xmlContent = xml;
    dictionary.savePath = savePath;
    dictionary.id = ruleTemplate.id;
    dictionary.userId = user.id;

    return this.dataAccessService.callQueryJsonPost(
      {
        query: 'update_rule_template.xq',
        parameters: dictionary,
        operation: 'updateRuleTemplate.xq',
        debugMsg: `Updating Rule Template ${ruleTemplate.id}`
      }
    ).pipe(
      tap(result => {
        // FIXME: This really should happen on the publish of the rule template not the save
        if (result) {
          this.store.dispatch(ruleEditorActions.saveRuleTemplate({ id: ruleTemplate.id, save: ruleTemplate }));
          this.ruleTemplateService.reloadData();
        }
      })
    );
  }

  private processNameChanges(updatedRuleTemplate: RuleTemplate, ruleTemplates: RuleTemplate[]): Observable<any> {
    if (!ruleTemplates || ruleTemplates?.length === 0) return of(true);
    const lastVersion = ruleTemplates.reduce((prev, curr) => (versionCompare(prev.version, curr.version) > 0 ? prev : curr));
    if (lastVersion.displayName === updatedRuleTemplate.displayName) return of(true);
    // The name has changed, so we need to update the name of all the versions file in the db.

    const observables = ruleTemplates.map(rt => {
      /**
       * Since the previous version path has changed to be the new version, you have to use the last version displayed name.
       * Example:
       * Create A (a_v1.xml)
       * A --> AB   (a_v1.xml --> ab_v1.xml) + creation of ab_v2.xml )
       * AB --> ABC (ab_v1.xml --> abc_v1.xml) + (ab_v2.xml --> abc_v2.xml) + creation of abc_v3.xml )
       *
       * So we need to delete the previous version of the file (ab_v1.xml) and (ab_v2.xml) in this case.
       */
      const oldPath = RuleEditManager.getRuleTemplateFileName(rt, rt.version, lastVersion.displayName);
      const newPath = RuleEditManager.getRuleTemplateFileName(lastVersion, rt.version, updatedRuleTemplate.displayName);
      return this.dataAccessService.executeCommand({
        commandParameters: {
          command: 'rename',
          parameters: {
            oldPath,
            newPath
          }
        }
      });
    });

    return forkJoin(observables);
  }

  /**
   * Get the maximum block id. If there are none, will return 0.
   */
  private getMaxBlockId(): number {
    const max = this.ruleTemplate?.ruleBlocks?.ruleBlock?.reduce(
      (prev, curr) => curr.id > prev.id ? curr : prev, {id: 0}
    ) || {id: 1};
    return max.id;
  }

  /**
   * This will increment the major version number by 1.
   * Please note this will kill minor version numbers as they're not used at the moment.
   */
  private incrementRuleTemplateVersion(ruleTemplate: RuleTemplate): void {
    if (!ruleTemplate) { return; }
    const newVersion = incrementVersionBy(ruleTemplate, 1);
    ruleTemplate.version = newVersion;
  }

  /**
   * Takes in a list of rule templates and returns a list of the ones in use and a list of the ones that are not.
   */
  private versionsInUse(ruleTemplates: RuleTemplate[]): Observable<{inUse: RuleTemplate[]; notInUse: RuleTemplate[]}> {
    return this.scenario$.pipe(
      map(scenarios => {
        const versionsInUse: RuleTemplate[] = [];
        const versionsNotInUse: RuleTemplate[] = [];
        for (const rt of ruleTemplates) {
          const scenariosUsingVersion = scenarios.filter(scenario =>
            scenario.rule?.find(rule => rule.ruleTemplateReference.id === rt.id && versionCompare(rule.ruleTemplateReference.version, rt.version) === 0)
          );
          if (scenariosUsingVersion?.length) {
            versionsInUse.push(rt);
          } else {
            versionsNotInUse.push(rt);
          }
        }
        return { inUse: versionsInUse, notInUse: versionsNotInUse };
      })
    );
  }

  public static deleteRuleTemplate(
    dataAccessService: DataAccessService, ruleTemplate: RuleTemplate, logger: Logging, currentName?: string
  ): SelfCompletingObservable<any> {
    try {
      const savePath = RuleEditManager.getRuleTemplateFileName(ruleTemplate, undefined, currentName);
      return dataAccessService.callQueryJson({
        query: 'delete_rule_template',
        debugMsg: `Deleting ${savePath}`,
        parameters: { id: ruleTemplate.id, v: toVersionString(ruleTemplate.version) ?? '1.0.0' }
      });
    } catch {
      logger.log(`Failed to delete rule template`);
    }
    return of(null);
  }

  /**
   * Returns the full file path name (including file extension) of the rule template.
   * Spaces will be replaced with "_".
   * For example, "rule template" -> "/rules/new_template_v1.xml"
   *
   * @param ruleTemplate the rule template
   */
  public static getRuleTemplateFileName(ruleTemplate: RuleTemplate, version?: Version, fileName?: string): string {
    // note this naming convention is almost definitely going to change
    // displayName will probably be swapped and customer templates will probably
    // be moved to their own folder.
    // FIXME need to forbid _ characters!!
    if (!ruleTemplate) { throw new Error('null rule template!'); }
    if (!ruleTemplate?.displayName) { throw new Error('null rule template name!'); }
    const folderPath = 'rules';
    const name = (fileName || ruleTemplate.displayName).toLocaleLowerCase().replace(/ /g, '_');
    const fileVersion = version ? version.major : ruleTemplate.version.major;
    const filePath = `/${folderPath}/${name}_v${fileVersion}.xml`;
    return filePath;
  }

  /**
   * Returns the  file name of the rule template with its extension.
   * Spaces will be replaced with "_".
   *
   * @param ruleTemplate the rule template
   */
   public static getRuleTemplateFileNameOnly(ruleTemplate: RuleTemplate, version?: Version, fileName?: string): string {
    // note this naming convention is almost definitely going to change
    // displayName will probably be swapped and customer templates will probably
    // be moved to their own folder.
    // FIXME need to forbid _ characters!!
    if (!ruleTemplate) { throw new Error('null rule template!'); }
    if (!ruleTemplate?.displayName) { throw new Error('null rule template name!'); }
    const name = (fileName || ruleTemplate.displayName).toLocaleLowerCase().replace(/ /g, '_');
    const fileVersion = version ? version.major : ruleTemplate.version.major;
    const fileNameExtension = `/${name}_v${fileVersion}.xml`;
    return fileNameExtension;
  }

  /**
   * Returns a stringified error message if there are any errors in the rule template.
   *
   * @param ruleTemplate the rule template to validate
   */
  static validateRuleTemplateForSave(ruleTemplate: RuleTemplate): string {
    // FIXME more validation. Will need handlers based on property type for the blocks.
    if (!ruleTemplate) {
      return 'Rule template missing';
    }
    if (!ruleTemplate.displayName) {
      return 'Enter a rule template name.';
    }
    return null;
  }
}
