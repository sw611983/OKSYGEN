/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
// import { TestBed, waitForAsync } from '@angular/core/testing';
// import { provideMockStore } from '@ngrx/store/testing';
// import { DataAccessService } from '@oksygen-common-libraries/data-access';
// import { DataAccessServiceStub } from '@oksygen-common-libraries/data-access/testing';
// import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
// import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
// import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { RuleEditService } from './rule-edit.service';

describe('RuleEditService', () => {
  let service: RuleEditService;

  beforeEach(() => {
    // waitForAsync(() => {
    //   configureSimTrainTestingModule({
    //     imports: [OksygenSimTrainCommonModule, OksygenSimTrainEditorsModule, /*OksygenSimTrainRuleEditModule*/],
    //     providers: [provideMockStore({})]
    //   });
    //   TestBed.inject(DataAccessService) as DataAccessServiceStub;
    //   service = TestBed.inject(RuleEditService);
    // })
    service = new RuleEditService(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
