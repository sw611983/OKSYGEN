/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { ContextManager } from '@oksygen-sim-train-libraries/components-services/common';
import { RuleBlockService } from '@oksygen-sim-train-libraries/components-services/rules';
import { RuleEditorContext } from './rule-editor-context';

/**
 * A ContextManager for the Rule Editor.
 */
@Injectable()
export class RuleEditorContextManager extends ContextManager<string, RuleEditorContext> {

  constructor(
    private ruleBlockService: RuleBlockService
  ) {
    super();
  }

  protected createContext(id: string): RuleEditorContext {
    const ruleBlocks$ = this.ruleBlockService.data();
    const ruleDataMan = new RuleEditorContext();
    ruleDataMan.ruleBlocks$ = ruleBlocks$;
    return ruleDataMan;
  }

}
