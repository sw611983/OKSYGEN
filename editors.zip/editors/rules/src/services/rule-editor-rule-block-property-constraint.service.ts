/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Inject, Injectable } from '@angular/core';

import { Logging } from '@oksygen-common-libraries/pio';
import {
  PropertyUpdate, RuleBlock, RuleBlockPair, RuleBlockPropertyConstraintService,
  RuleBlockService, RuleEditorRuleBlockProperty, RuleTemplateRuleBlock, RuleTemplateService
} from '@oksygen-sim-train-libraries/components-services/rules';
import { EnvironmentConstraint } from './rule-block-property-constraints/environment.constraint';
import { Observable, of, zip } from 'rxjs';
import { filter, map, switchMap } from 'rxjs/operators';
import { SelfCompletingObservable, takeOneTruthy } from '@oksygen-common-libraries/common';
import { difference } from 'lodash';
import { UnknownConstraint } from './rule-block-property-constraints/unknown.constraint';
import { VehicleConstraint } from './rule-block-property-constraints/vehicle.constraint';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { TrainConstraint } from './rule-block-property-constraints/train.constraint';
import { TrainSpatialConstraint } from './rule-block-property-constraints/train-spatial.constraint';
import { MoodleScormActivityConstraint } from './rule-block-property-constraints/moodle-scorm-activity.constraint';
import { MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { MoodleScormActivityActionConstraint } from './rule-block-property-constraints/moodle-scorm-activity-action.constraint';
import { TemporalEventConstraint } from './rule-block-property-constraints/temporal-event.constraint';
import { FeatureConstraint } from './rule-block-property-constraints/feature.constraint';
import { FeatureStateConstraint } from './rule-block-property-constraints/feature-state.constraint';
import { TrainPropertyConstraint } from './rule-block-property-constraints/train-property-constraint';
import { OksygenPropertyConstraintConfig, RULE_EDITOR_MODULE_CONFIG_TOKEN, RuleEditModuleConfig } from '../tokens/module-config.token';
import { UserFaultConstraint } from './rule-block-property-constraints/user-fault-constraint';
import { InstructorPromptConstraint } from './rule-block-property-constraints/instructor-prompt.constraint';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { SetVariableConstraint } from './rule-block-property-constraints/set-variable.constraint';
import { GetVariableConstraint } from './rule-block-property-constraints/get-variable.constraint';
import { AssessmentConstraint } from './rule-block-property-constraints/assessment.constraint';

/**
 * Rule editor implementation of ```RuleBlockPropertyConstraintService```.
 */
@Injectable()
export class RuleEditorRuleBlockPropertyConstraintService extends RuleBlockPropertyConstraintService<RuleEditorRuleBlockProperty> {

  constructor(
    logging: Logging,
    simPropertyService: SimPropertiesService,
    private ruleBlockService: RuleBlockService,
    private ruleTemplateService: RuleTemplateService,
    private consistDataService: ConsistDataService,
    private multimediaDataService: MultimediaDataService,
    @Inject(RULE_EDITOR_MODULE_CONFIG_TOKEN) private config: RuleEditModuleConfig
  ) {
    super(logging, simPropertyService);
    this.initialiseConstraints(this.config.constraintConfig).subscribe();
  }

  /**
   * Initialises the default set of rule block property constraints.
   */
  initialiseConstraints(config: OksygenPropertyConstraintConfig): Observable<void> {
    const blocks$ = this.ruleBlockService.data().pipe( takeOneTruthy() );
    const templates$ = this.ruleTemplateService.data().pipe( takeOneTruthy() );
    return zip(blocks$, templates$).pipe(
      filter(([blocks, templates]) => !!blocks && !!templates),
      switchMap(([blocks, templates]) => {
        if (config.unknown) {
          const unknownConstraint = new UnknownConstraint(this.simPropertyService, this.logging, blocks);
          this.setUnknownConstraint(unknownConstraint);
        }
        if (config.environment) {
          const envConstraint = new EnvironmentConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(envConstraint);
        }
        if (config.instrutorPrompt) {
          const instructorConstraint = new InstructorPromptConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(instructorConstraint);
        }
        if (config.assessment) {
          const assessmentConstraint = new AssessmentConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(assessmentConstraint);
        }
        if (config.userFault) {
          const userFaultConstraint = new UserFaultConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(userFaultConstraint);
        }
        if (config.trainSpatial) {
          const trainConstraint = new TrainSpatialConstraint(this.simPropertyService, this.logging, this.consistDataService, blocks);
          this.addPropertyConstraint(trainConstraint);
        }
        if (config.vehicle) {
          const vehicleConstraint = new VehicleConstraint(this.simPropertyService, this.logging, blocks, this.consistDataService);
          this.addPropertyConstraint(vehicleConstraint);
        }
        if (config.trainProperty) {
          const trainPropertyConstraint = new TrainPropertyConstraint(this.simPropertyService, this.logging, blocks, this.consistDataService);
          this.addPropertyConstraint(trainPropertyConstraint);
        }
        if (config.train) {
          const trainConstraint = new TrainConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(trainConstraint);
        }
        if (config.moodleActivity) {
          const trainConstraint = new MoodleScormActivityConstraint(this.simPropertyService, this.multimediaDataService, this.logging, blocks);
          this.addPropertyConstraint(trainConstraint);
        }
        if (config.moodleActivityAction) {
          const trainConstraint = new MoodleScormActivityActionConstraint(this.simPropertyService, this.multimediaDataService, this.logging, blocks);
          this.addPropertyConstraint(trainConstraint);
        }
        if (config.temporalEvent) {
          const trainConstraint = new TemporalEventConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(trainConstraint);
        }
        if (config.featureState) {
          const trainConstraint = new FeatureStateConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(trainConstraint);
        }
        if (config.feature) {
          const trainConstraint = new FeatureConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(trainConstraint);
        }
        if (config.setVariable) {
          const setVariableConstraint = new SetVariableConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(setVariableConstraint);
        }
        if (config.getVariable) {
          const getVariableConstraint = new GetVariableConstraint(this.simPropertyService, this.logging, blocks);
          this.addPropertyConstraint(getVariableConstraint);
        }
        return of(null);
      })
    );
  }

  generatePropertyList(ruleTemplateRuleBlock: RuleTemplateRuleBlock): SelfCompletingObservable<RuleEditorRuleBlockProperty[]> {
    if (!ruleTemplateRuleBlock) { return of([]); }
    const blocks$ = this.ruleBlockService.data().pipe( takeOneTruthy() );
    return blocks$.pipe(
      map(blocks => this.ruleBlockPair(ruleTemplateRuleBlock, blocks)),
      map(block => this.propertyList(block)),
      takeOneTruthy()
    );
  }

  updateProperty(block: RuleBlockPair, propertyName: string, value: string|number|boolean): PropertyUpdate[] {
    const propertiesUpdated: PropertyUpdate[] = [];
    this.constraints.forEach(constraint => {
      const props = constraint.managedProperties();
      if (props.find(p => p === propertyName)) {
        const updates = constraint.updateProperty(block, propertyName, value);
        propertiesUpdated.push(...updates);
      }
    });
    if (this.unknownConstraint && !propertiesUpdated?.length) {
      const update = this.unknownConstraint.updateProperty(block, propertyName, value);
      propertiesUpdated.push(...update);
    }
    return propertiesUpdated;
  }

  /** Convenience method to group your rule template rule block and its corresponding rule block */
  private ruleBlockPair(ruleTemplateBlock: RuleTemplateRuleBlock, ruleBlocks: RuleBlock[]): RuleBlockPair {
    const block = ruleBlocks.find(b => b.name === ruleTemplateBlock?.blockType);
    return {
      ruleBlock: block,
      templateBlock: ruleTemplateBlock
    };
  }

  private propertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const list: RuleEditorRuleBlockProperty[] = [];
    // properties not handled by by any of a constraints
    let unknownProperties = block.ruleBlock.properties?.property?.map(p => p.name) ?? [];
    this.constraints.forEach(handler => {
      const props = handler.managedProperties();
      // FIXME this algorithm is flawed - if multiple constraints handle properties with the same names
      // they will conflict and the first one to execute will run while it may not be the correct one.
      // the work around is to make sure the "more specific" constraint is added first.
       // handler should only be called if all it's properties exist AND none of those properties have already been handled
      const allPropertiesUnhandled = props.every(p => unknownProperties.includes(p));
      unknownProperties = allPropertiesUnhandled ? difference(unknownProperties, props) : unknownProperties;
      if (allPropertiesUnhandled) {
        list.push( ...handler.generatePropertyList(block) );
      }
    });
    if (this.unknownConstraint) {
      for (const prop of unknownProperties) {
        const unknownProperty = this.unknownConstraint.generateProperty(block, prop);
        list.push(unknownProperty);
      }
    }
    return list;
  }
}
