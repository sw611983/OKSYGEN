/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint,
  PropertyUpdate,
  RuleBlockPair,
  RuleBlockPropertyNameEnum,
  RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';

export class AssessmentConstraint extends BasePropertyConstraint {
  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.ASSESSMENT_CATEGORY,
      RuleBlockPropertyNameEnum.REPORT_MESSAGE,
      RuleBlockPropertyNameEnum.ASSESSMENT_POINTS,
      RuleBlockPropertyNameEnum.TRIGGERED_ONCE
    ];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const boolType = this.booleanSimProperty();
    const assessmentCategory = this.generateProperty(block, RuleBlockPropertyNameEnum.ASSESSMENT_CATEGORY, this.assessmentCategories());

     //this code needs to be updated after the raw-string feature development is done (report-messge).
    const reportMessage = this.generateProperty(block, RuleBlockPropertyNameEnum.REPORT_MESSAGE, this.description());

    const triggeredOnce = this.generateProperty(block, RuleBlockPropertyNameEnum.TRIGGERED_ONCE, boolType);
    const assessmentPoints = this.generateProperty(block, RuleBlockPropertyNameEnum.ASSESSMENT_POINTS);
    return [assessmentCategory, reportMessage, triggeredOnce, assessmentPoints];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number | string | boolean): PropertyUpdate[] {
    return [{ name: propertyName, value }]; // no propagation for properties we don't recognise
  }

  private assessmentCategories(): AssessmentCategory[] {
    const braking = this.simPropertyService.translateService.instant('Braking');
    const doors = this.simPropertyService.translateService.instant('Doors');
    const horn = this.simPropertyService.translateService.instant('Horn');
    const speed = this.simPropertyService.translateService.instant('Speed');
    const value: AssessmentCategory[] = [
      { name: braking, displayName: braking, value: 'Braking' },
      { name: doors, displayName: doors, value: 'Doors' },
      { name: horn, displayName: horn, value: 'Horn' },
      { name: speed, displayName: speed, value: 'Speed' }
    ];
    return value;
  }

  private description(): AssessmentCategory[] {
    // this enum is because the rule editor does not support the raw-string properties till the time of this development.
    // so to avoid any errors, we are passing an enum which is supported.
    // need to remove this once the raw-string property is supported.
    const assessment_desc = this.simPropertyService.translateService.instant('Rule based assessment');
    const value: AssessmentCategory[] = [
      { name: assessment_desc, displayName: assessment_desc, value: 'Rule based assessment' }
    ];
    return value;
  }

}

export interface AssessmentCategory {
  /** this is unique id of this sim property state */
  name: string;
  /** this is what we display */
  displayName: string;
  /** value should be a primitive (string, number, boolean) */
  value: any;
}
