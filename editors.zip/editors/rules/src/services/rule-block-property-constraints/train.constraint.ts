/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint, PropertyUpdate, RuleBlockPair, RuleBlockPropertyNameEnum, RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';

export class TrainConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.UNIT_CONVERSION
    ];
  }

  generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const trainRuleProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID);
    trainRuleProperty.assignData({enabled: false});
    const unitConversion = this.generateProperty(block, RuleBlockPropertyNameEnum.UNIT_CONVERSION);
    unitConversion.assignData({enabled: false});
    return [ trainRuleProperty, unitConversion ];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number|string|boolean): PropertyUpdate[] {
    if(propertyName === RuleBlockPropertyNameEnum.TRAIN_ID){
      // if we're updating the environment name reset its value to default
      return [{name: RuleBlockPropertyNameEnum.TRAIN_ID, value }];
    }
    // all other fields have no dependants
    return [{name: propertyName, value}];
  }
}
