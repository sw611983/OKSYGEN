/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Logging } from '@oksygen-common-libraries/pio';
import {
  BasePropertyConstraint, PropertyUpdate, RuleBlock, RuleBlockPair, RuleBlockPropertyNameEnum, RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';
import { TrainPropertyConstraintHelper } from './constraint-helpers/train-property-constraint.helper';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class VehicleConstraint extends BasePropertyConstraint {
  private trainHelper: TrainPropertyConstraintHelper;

  constructor(
    simPropertyService: SimPropertiesService,
    logging: Logging,
    ruleBlocks: RuleBlock[],
    consistDataService: ConsistDataService
  ) {
    super(simPropertyService, logging, ruleBlocks);
    this.trainHelper = new TrainPropertyConstraintHelper(simPropertyService, consistDataService);
  }

  override managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.VEHICLE_INDEX,
      RuleBlockPropertyNameEnum.VEHICLE_PROPERTY,
      RuleBlockPropertyNameEnum.VALUE
    ];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID);
    const vehicleIndexProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX);
    const vehiclePropertyProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY);
    const valueProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.VALUE);
    trainIdProperty.assignData({ enabled: false });
    vehicleIndexProperty.assignData({ enabled: false });
    vehiclePropertyProperty.assignData({ enabled: false });
    valueProperty.assignData({ enabled: false });
    // const trains = this.trainHelper.getTrains();
    // const trainProperties = this.trainHelper.findValidTrains();
    // const trainId = this.trainHelper.getTrainIdFromBlock(block);
    // const consist = trains.find(t => t.id === trainId);
    // const prop = findRuleProperty(block.templateBlock, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY);
    // const propName = prop?.value as string;
    // const data = this.trainHelper.findValidVehiclesAndProperties(consist, propName);

    // const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID, trainProperties);
    // const vehicleIndex = this.generateProperty(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX, data.validVehicles);
    // const selectedStateProperty = this.generateKeyValueProperty(
    //   block,
    //   RuleBlockPropertyNameEnum.VEHICLE_PROPERTY,
    //   RuleBlockPropertyNameEnum.VALUE,
    //   {
    //     allowedKeyValues: data.selectedVehicleAllProperties,
    //     allowedValueValues: data.selectedVehiclePropertyState?.simPropertyStateAssoc ?? []
    //   }
    // );
    // // must select a train before you can set property / value
    // if (!trainIdProperty.isValid()) {
    //   const errorMessage = data.validVehicles?.length > 0 ? undefined : `${trainIdProperty.name} has no vehicles.`;
    //   vehicleIndex.assignData({enabled: false, errorMessage });
    //   selectedStateProperty.forEach(p => { p.assignData({enabled: false }); });
    // }
    // if (!vehicleIndex.isValid()) {
    //   const errorMessage = data.selectedVehicleAllProperties?.length > 0 ? undefined : `${vehicleIndex.name} has no settable properties.`;
    //   selectedStateProperty.forEach(p => { p.assignData({enabled: false }); });
    // }
    // if (!data.selectedVehicleAllProperties?.length) {
    //   const errorMessage = t(`Train not configured for rules.`);
    //   selectedStateProperty.forEach((p, i) => {
    //     if (i === 0) { // only property selection shows error
    //       p.assignData({ enabled: false, errorMessage });
    //     } else { // value doesn't need to show the error
    //       p.assignData({ enabled: false });
    //     }
    //   });
    // }
    // return [ trainIdProperty, vehicleIndex, ...selectedStateProperty ];
    return [ trainIdProperty, vehicleIndexProperty, vehiclePropertyProperty, valueProperty ];
  }

  updateProperty(block: RuleBlockPair, propertyName: string, value: number|string|boolean): PropertyUpdate[] {
    const defaultVehicleIndex = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX);
    const defaultVehicleProperty = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY);
    const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
    if(propertyName === RuleBlockPropertyNameEnum.TRAIN_ID) {
      // if we're updating the environment name reset its value to default
      return [
        {name: RuleBlockPropertyNameEnum.TRAIN_ID, value },
        {name: RuleBlockPropertyNameEnum.VEHICLE_INDEX, value: defaultVehicleIndex },
        {name: RuleBlockPropertyNameEnum.VEHICLE_PROPERTY, value: defaultVehicleProperty },
        {name: RuleBlockPropertyNameEnum.VALUE, value: defaultValue }
      ];
    } else if (propertyName === RuleBlockPropertyNameEnum.VEHICLE_INDEX) {
      return [
        {name: RuleBlockPropertyNameEnum.VEHICLE_INDEX, value },
        {name: RuleBlockPropertyNameEnum.VEHICLE_PROPERTY, value: defaultVehicleProperty },
        {name: RuleBlockPropertyNameEnum.VALUE, value: defaultValue }
      ];
    } else if (propertyName === RuleBlockPropertyNameEnum.VEHICLE_PROPERTY) {
      return [
        {name: RuleBlockPropertyNameEnum.VEHICLE_PROPERTY, value },
        {name: RuleBlockPropertyNameEnum.VALUE, value: defaultValue }
      ];
    } else if (propertyName === RuleBlockPropertyNameEnum.VALUE) {
      return [
        {name: RuleBlockPropertyNameEnum.VALUE, value }
      ];
    } else {
      this.logging.warn(`[RuleBlockVehicleConstraint] failed to update unknown property ${propertyName}!`);
      return [];
    }
  }
}
