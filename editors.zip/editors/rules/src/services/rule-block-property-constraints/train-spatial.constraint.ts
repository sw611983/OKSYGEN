/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint,
  PropertyUpdate,
  RuleBlock,
  RuleBlockPair,
  RuleBlockPropertyNameEnum,
  RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';
import { TrainPropertyConstraintHelper } from './constraint-helpers/train-property-constraint.helper';
import { Logging } from '@oksygen-common-libraries/pio';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class TrainSpatialConstraint extends BasePropertyConstraint {
  private trainHelper: TrainPropertyConstraintHelper;

  constructor(simPropertyService: SimPropertiesService, logging: Logging, consistDataService: ConsistDataService, ruleBlocks: RuleBlock[]) {
    super(simPropertyService, logging, ruleBlocks);
    this.trainHelper = new TrainPropertyConstraintHelper(simPropertyService, consistDataService);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.VEHICLE_INDEX,
      RuleBlockPropertyNameEnum.FEATURE_NAME,
      RuleBlockPropertyNameEnum.PROMPT_ENABLE,
      RuleBlockPropertyNameEnum.PROMPT_TIME
    ];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID);
    const vehicleIndex = this.generateProperty(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX);
    const featureProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.FEATURE_NAME);
    // must select a train before you can set property / value
    trainIdProperty.assignData({ enabled: false });
    vehicleIndex.assignData({ enabled: false });
    featureProperty.assignData({ enabled: false });
    // selectedStateProperty.forEach(p => { p.assignData({enabled: false}); });

    const boolType = this.booleanSimProperty();
    const promptEnable = this.generateProperty(block, RuleBlockPropertyNameEnum.PROMPT_ENABLE, boolType);
    const promptTime = this.generateProperty(block, RuleBlockPropertyNameEnum.PROMPT_TIME);
    return [trainIdProperty, vehicleIndex, featureProperty, promptEnable, promptTime];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number | string | boolean): PropertyUpdate[] {
    const defaultVehicleIndex = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX);
    if (propertyName === RuleBlockPropertyNameEnum.TRAIN_ID) {
      // if we're updating the environment name reset its value to default
      return [
        { name: RuleBlockPropertyNameEnum.TRAIN_ID, value },
        { name: RuleBlockPropertyNameEnum.VEHICLE_INDEX, value: defaultVehicleIndex }
      ];
    }
    // all other fields have no dependants
    return [{ name: propertyName, value }];
  }
}
