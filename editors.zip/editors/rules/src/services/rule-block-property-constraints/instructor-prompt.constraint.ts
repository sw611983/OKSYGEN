/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint, PropertyUpdate, RuleBlockPair, RuleBlockPropertyNameEnum, RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';

export class InstructorPromptConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.MESSAGE,
      RuleBlockPropertyNameEnum.MESSAGE_TYPE,
      RuleBlockPropertyNameEnum.AUTO_DISMISS,
      RuleBlockPropertyNameEnum.DISMISS_DURATION
    ];
  }

  generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const selectedMessage = this.generateProperty(block, RuleBlockPropertyNameEnum.MESSAGE);

    const messageType = this.instructorPromptMessage();
    const selectedMessageType = this.generateProperty(block, RuleBlockPropertyNameEnum.MESSAGE_TYPE, messageType);

    const boolType = this.booleanSimProperty();
    const AutoDismiss = this.generateProperty(block, RuleBlockPropertyNameEnum.AUTO_DISMISS, boolType);

    const selectedDismissDuration = this.generateProperty(block, RuleBlockPropertyNameEnum.DISMISS_DURATION);

    return [ selectedMessage, selectedMessageType, AutoDismiss, selectedDismissDuration ];
  }

  updateProperty(block: RuleBlockPair, propertyName: string, value: number|string|boolean): PropertyUpdate[] {
    return [{name: propertyName, value}]; // no propagation for properties we don't recognise
  }
}
