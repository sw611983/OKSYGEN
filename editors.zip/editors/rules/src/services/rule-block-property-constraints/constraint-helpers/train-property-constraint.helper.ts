/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { map, tap } from 'rxjs/operators';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import { Consist, ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import {
  RuleBlockPair,
  RuleBlockPropertyNameEnum,
  RuleBlockPropertyTypeEnum,
  findRuleBlockProperty,
  findRuleProperty
} from '@oksygen-sim-train-libraries/components-services/rules';
import { SimPropertiesService, SimProperty, SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class TrainPropertyConstraintHelper {

  constructor(
    private simPropertyService: SimPropertiesService,
    private consistDataService: ConsistDataService
  ) {}

  public findProperties(
    consist: Consist, isVehicle: boolean, selectedPropertyName: string
  ): { selectedProperty: SimProperty; allProperties: SimPropertyState[] } {
    const allProperties: SimPropertyState[] = [];
    let selectedProperty: SimProperty;
    const properties = isVehicle
      ? this.simPropertyService.getConsistAllVehicleSimProperties(consist.id)
      : this.simPropertyService.getConsistTrainSimProperties(consist.id);

      properties.forEach(group => {
      group.simProperty.forEach(property => {
        // only properties with state that are writable can be considered
        if (property?.states?.length > 0 && property?.isWritable) {
          // when driver, grab driver properties, when auto, grab auto properties
          const prop: SimPropertyState = { name: property.name, displayName: property.displayName, value: property.name };

          if (property.name === selectedPropertyName) {
            selectedProperty = property;
          }
          prop.displayName = this.simPropertyService.translateService.instant(t(prop.displayName));
          prop.name = this.simPropertyService.translateService.instant(t(prop.name));
          prop.value = this.simPropertyService.translateService.instant(t(prop.value));
          allProperties.push(prop);
        }
      });
    });

    return {selectedProperty, allProperties};
  }

  public findValidTrains(): SimPropertyState[] {
    let validTrains: SimPropertyState[] = [];

    const trains = this.getTrains();
    // FIXME The typeing is wrong here. This is a collection of available train IDs.
    if (trains) {
      validTrains = trains.map(train => ({ name: train.name, displayName: train.name, value: train.id }));
    }

    return validTrains;
  }

  public getTrainIdFromBlock(block: RuleBlockPair): number {
    const ruleTrain = findRuleBlockProperty(block.ruleBlock, RuleBlockPropertyTypeEnum.TRAIN_ID);
    const templateTrain = findRuleProperty(block.templateBlock, RuleBlockPropertyNameEnum.TRAIN_ID);
    if (templateTrain) {
      return templateTrain.value as any; // FIXME number validation
    }
    if (ruleTrain) {
      return ruleTrain.defaultValue;
    }
    return null;
  }

  // public getScenarioTrainConsist(scenarioTrain: ScenarioTrain): Consist {
  //   if (!scenarioTrain) { return undefined; }
  //   const consist = this.getConsistByName(scenarioTrain.trainDescription);
  //   return consist;
  // }

  getTrains(): Consist[] {
    let consists: Consist[] = [];
    const sub = this.consistDataService.data().pipe(takeOneTruthy(), tap(c => consists = c)).subscribe();
    sub?.unsubscribe();
    return consists;
  }

  private getConsistByName(name: string): Consist {
    if (!name) { return undefined; }
    let consist: Consist = null;
    const sub = this.consistDataService.data().pipe(
      takeOneTruthy(),
      map(trains => trains.find(train => train.name === name)),
      tap(c => consist = c)
    ).subscribe();
    sub?.unsubscribe();
    return consist;
  }

  // public getScenarioTrainById(trainId: number): ScenarioTrain {
  //   if (trainId === null || trainId === undefined) { return undefined; }
  //   const trains = this.getScenarioTrains();
  //   return trains?.find(train => train.id === trainId);
  // }

  public findValidVehiclesAndProperties(
    consist: Consist, selectedVehicle: string
  ): {validVehicles: SimPropertyState[]; selectedVehicleAllProperties: SimPropertyState[]; selectedVehiclePropertyState: SimProperty} {
    // FIXME not sure this is the correct type, the vehicle index isn't a Sim Property.
    let allVehicleProperties: SimPropertyState[] = [];
    let validVehicles: SimPropertyState[] = [];

    const props = this.findProperties(consist, true, selectedVehicle);
    allVehicleProperties = props.allProperties;
    const selectedVehiclePropertyState = props.selectedProperty;

    if (consist?.vehicles) {
      validVehicles = consist.vehicles.map((v, i) => {
        const displayName = this.simPropertyService.translateService.instant(
          t('Car {carIndex} ({carClass})'), { carIndex: i + 1, carClass: v.carClass.description }
        );

        return { name: displayName, displayName, value: i };
      });
    }

    return {validVehicles, selectedVehicleAllProperties: allVehicleProperties, selectedVehiclePropertyState};
  }
}
