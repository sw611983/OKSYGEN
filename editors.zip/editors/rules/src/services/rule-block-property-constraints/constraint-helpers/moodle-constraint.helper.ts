/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { MultimediaDataService, MultimediaLmsScormActivity } from '@oksygen-sim-core-libraries/components-services/multimedia';

export class MoodleConstraintHelper {
  constructor(private multimediaDataService: MultimediaDataService) {}

  getMultimediaLmsScormActivities(): MultimediaLmsScormActivity[] {
    let activities: MultimediaLmsScormActivity[] = [];
    const sub = this.multimediaDataService?.lmsScormActivity$()?.subscribe(items => {
      activities = items;
    });
    sub?.unsubscribe();
    return activities;
  }
}
