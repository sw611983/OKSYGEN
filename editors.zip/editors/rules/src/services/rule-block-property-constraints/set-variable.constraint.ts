/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint,
  PropertyUpdate,
  RuleBlockPair,
  RuleBlockPropertyNameEnum,
  RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';

export class SetVariableConstraint extends BasePropertyConstraint {
  managedProperties(): string[] {
    return [RuleBlockPropertyNameEnum.VARIABLE, RuleBlockPropertyNameEnum.VALUE];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const variableName = this.generateProperty(block, RuleBlockPropertyNameEnum.VARIABLE);
    variableName.assignData({ enabled: false });

    const value = this.generateProperty(block, RuleBlockPropertyNameEnum.VALUE);
    value.assignData({ enabled: false });

    return [variableName, value];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number | string | boolean): PropertyUpdate[] {
    return [{ name: propertyName, value }]; // no propagation for properties we don't recognise
  }
}
