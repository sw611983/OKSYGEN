/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint, PropertyUpdate, RuleBlockPair, RuleBlockPropertyNameEnum, RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';

export class FeatureConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.FEATURE_NAME
    ];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const featureProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.FEATURE_NAME);
    featureProperty.assignData({enabled: false});
    return [ featureProperty ];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number|string|boolean): PropertyUpdate[] {
    // this.updateTemplateBlockSimple(block, propertyName, value);
    return [{name: propertyName, value}]; // no propagation for properties we don't recognise
  }
}
