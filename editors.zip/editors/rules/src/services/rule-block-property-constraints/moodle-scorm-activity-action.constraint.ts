/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Logging } from '@oksygen-common-libraries/pio';
import { MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import {
  BasePropertyConstraint,
  PropertyUpdate,
  RuleBlock,
  RuleBlockPair,
  RuleBlockPropertyNameEnum,
  RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { MoodleConstraintHelper } from './constraint-helpers/moodle-constraint.helper';

export class MoodleScormActivityActionConstraint extends BasePropertyConstraint {
  helper: MoodleConstraintHelper;
  constructor(simPropertyService: SimPropertiesService, private multimediaDataService: MultimediaDataService, logging: Logging, ruleBlocks: RuleBlock[]) {
    super(simPropertyService, logging, ruleBlocks);
    this.helper = new MoodleConstraintHelper(this.multimediaDataService);
  }

  managedProperties(): string[] {
    return [RuleBlockPropertyNameEnum.MULTIMEDIA_NAME];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const allowedMoodles = this.helper.getMultimediaLmsScormActivities().map(val => ({ name: val.displayName, displayName: val.displayName, value: val.id }));
    const prop = this.generateProperty(block, RuleBlockPropertyNameEnum.MULTIMEDIA_NAME, allowedMoodles);
    return [prop];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number | string | boolean): PropertyUpdate[] {
    return [{ name: propertyName, value }]; // no propagation for properties we don't recognise
  }
}
