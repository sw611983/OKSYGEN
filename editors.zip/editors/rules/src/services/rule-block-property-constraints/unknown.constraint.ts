/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BasePropertyConstraint, PropertyUpdate, RuleBlockPair, RuleEditorRuleBlockProperty } from '@oksygen-sim-train-libraries/components-services/rules';

export class UnknownConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [];
  }

  override constraintApplies(block: RuleBlockPair): boolean {
    return true;
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const properties: RuleEditorRuleBlockProperty[] = [];
    block.ruleBlock.properties.property.forEach(p => {
      const property = this.generateProperty(block, p.name);
      properties.push(property);
    });
    return properties;
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number|string|boolean): PropertyUpdate[] {
    // this.updateTemplateBlockSimple(block, propertyName, value);
    return [{name: propertyName, value}]; // no propagation for properties we don't recognise
  }
}
