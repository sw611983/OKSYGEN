/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint, PropertyUpdate, RuleBlockPair, RuleBlockPropertyNameEnum, RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';

export class FeatureStateConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.FEATURE_NAME,
      RuleBlockPropertyNameEnum.STATE
    ];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const featureProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.FEATURE_NAME);
    const stateProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.STATE);
    featureProperty.assignData({enabled: false});
    stateProperty.assignData({enabled: false});

    return [ featureProperty, stateProperty ];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number|string|boolean): PropertyUpdate[] {
    return [{name: propertyName, value}]; // no propagation for properties we don't recognise
  }
}
