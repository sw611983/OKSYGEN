/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint, PropertyUpdate,
  RuleBlockPair, RuleBlockPropertyNameEnum, RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';

export class UserFaultConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.USER_FAULT,
      RuleBlockPropertyNameEnum.VALUE
    ];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID);
    const userFaultProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.USER_FAULT);
    const valueProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.VALUE);
    trainIdProperty.assignData({ enabled: false });
    userFaultProperty.assignData({ enabled: false });
    valueProperty.assignData({ enabled: false });
    return [ trainIdProperty, userFaultProperty, valueProperty ];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number|string|boolean): PropertyUpdate[] {
    const defaultTrainProperty = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.TRAIN_PROPERTY);
    const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
    if(propertyName === RuleBlockPropertyNameEnum.TRAIN_ID) {
      // if we're updating the train id reset other properties to default
      return [
        {name: RuleBlockPropertyNameEnum.TRAIN_ID, value },
        {name: RuleBlockPropertyNameEnum.TRAIN_PROPERTY, value: defaultTrainProperty },
        {name: RuleBlockPropertyNameEnum.VALUE, value: defaultValue }
      ];
    } else if (propertyName === RuleBlockPropertyNameEnum.TRAIN_PROPERTY) {
      return [
        {name: RuleBlockPropertyNameEnum.TRAIN_PROPERTY, value },
        {name: RuleBlockPropertyNameEnum.VALUE, value: defaultValue }
      ];
    } else if (propertyName === RuleBlockPropertyNameEnum.VALUE) {
      return [
        {name: RuleBlockPropertyNameEnum.VALUE, value }
      ];
    } else {
      this.logging.warn(`[RuleBlockTrainPropertyConstraint] failed to update unknown property ${propertyName}!`);
      return [];
    }
  }
}
