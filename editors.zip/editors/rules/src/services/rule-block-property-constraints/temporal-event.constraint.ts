/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint,
  PropertyUpdate,
  RuleBlockPair,
  RuleBlockPropertyNameEnum,
  RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';

export class TemporalEventConstraint extends BasePropertyConstraint {
  managedProperties(): string[] {
    return [RuleBlockPropertyNameEnum.ELAPSED_TIME, RuleBlockPropertyNameEnum.PROMPT_ENABLE, RuleBlockPropertyNameEnum.PROMPT_TIME];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const boolType = this.booleanSimProperty();
    const elapsedTime = this.generateProperty(block, RuleBlockPropertyNameEnum.ELAPSED_TIME);
    const promptEnable = this.generateProperty(block, RuleBlockPropertyNameEnum.PROMPT_ENABLE, boolType);
    const promptTime = this.generateProperty(block, RuleBlockPropertyNameEnum.PROMPT_TIME);
    return [elapsedTime, promptEnable, promptTime];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number | string | boolean): PropertyUpdate[] {
    return [{ name: propertyName, value }]; // no propagation for properties we don't recognise
  }
}
