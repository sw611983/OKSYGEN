/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import {
  BasePropertyConstraint,
  PropertyUpdate,
  RuleBlock,
  RuleBlockPair,
  RuleBlockPropertyNameEnum,
  RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';
import { TrainPropertyConstraintHelper } from './constraint-helpers/train-property-constraint.helper';
import { Logging } from '@oksygen-common-libraries/pio';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class TrainPropertyConstraint extends BasePropertyConstraint {
  private trainHelper: TrainPropertyConstraintHelper;

  constructor(simPropertyService: SimPropertiesService, logging: Logging, ruleBlocks: RuleBlock[], consistDataService: ConsistDataService) {
    super(simPropertyService, logging, ruleBlocks);
    this.trainHelper = new TrainPropertyConstraintHelper(simPropertyService, consistDataService);
  }

  managedProperties(): string[] {
    return [RuleBlockPropertyNameEnum.TRAIN_ID, RuleBlockPropertyNameEnum.TRAIN_PROPERTY, RuleBlockPropertyNameEnum.VALUE];
  }

  override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[] {
    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID);
    const trainPropertyProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_PROPERTY);
    const valueProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.VALUE);
    trainIdProperty.assignData({ enabled: false });
    trainPropertyProperty.assignData({ enabled: false });
    valueProperty.assignData({ enabled: false });
    return [trainIdProperty, trainPropertyProperty, valueProperty];
  }

  override updateProperty(block: RuleBlockPair, propertyName: string, value: number | string | boolean): PropertyUpdate[] {
    const defaultTrainProperty = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.TRAIN_PROPERTY);
    const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
    if (propertyName === RuleBlockPropertyNameEnum.TRAIN_ID) {
      // if we're updating the environment name reset its value to default
      return [
        { name: RuleBlockPropertyNameEnum.TRAIN_ID, value },
        { name: RuleBlockPropertyNameEnum.TRAIN_PROPERTY, value: defaultTrainProperty },
        { name: RuleBlockPropertyNameEnum.VALUE, value: defaultValue }
      ];
    } else if (propertyName === RuleBlockPropertyNameEnum.TRAIN_PROPERTY) {
      return [
        { name: RuleBlockPropertyNameEnum.TRAIN_PROPERTY, value },
        { name: RuleBlockPropertyNameEnum.VALUE, value: defaultValue }
      ];
    } else if (propertyName === RuleBlockPropertyNameEnum.VALUE) {
      return [{ name: RuleBlockPropertyNameEnum.VALUE, value }];
    } else {
      this.logging.warn(`[RuleBlockTrainPropertyConstraint] failed to update unknown property ${propertyName}!`);
      return [];
    }
  }
}
