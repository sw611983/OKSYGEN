/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BehaviorSubject, Observable } from 'rxjs';
import { RuleBlock, RuleTemplate, RuleTemplateRuleBlock } from '@oksygen-sim-train-libraries/components-services/rules';

import { Context } from '@oksygen-sim-train-libraries/components-services/common';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';

export interface RuleTemplateUi {
  ruleTemplate: RuleTemplate;
  blocks: TemplateBlockUi[];
}

export interface TemplateBlockUi {
  templateBlock: RuleTemplateRuleBlock;
  ruleBlock: RuleBlock;
}

export class RuleEditorContext implements Context {
  public uiState = new UiStateModelManager();

  ruleBlocks$: Observable<RuleBlock[]>;
  ruleTemplates$: Observable<RuleTemplate[]>;
  /** This is the original! Don't mess with it!!! Note this is set in the rule edit manager. */
  ruleTemplate$: BehaviorSubject<RuleTemplate> = new BehaviorSubject(null);

  selectedBlock$: BehaviorSubject<number> = new BehaviorSubject(null);
  editTemplate: RuleTemplateUi;

  destroy(): void {
    this.ruleTemplate$.complete();
    this.selectedBlock$.complete();
  }

  setRuleTemplate(ruleTemplate: RuleTemplateUi): void {
    this.editTemplate = ruleTemplate;
  }

  selectBlock(blockId: number): void {
    if (blockId === null || blockId === undefined) {
      this.selectedBlock$.next(null);
      return;
    }
    this.selectedBlock$.next(blockId);
  }
}
