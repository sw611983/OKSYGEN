/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable, NgZone } from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';

import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { RuleBlockService, RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';

import { RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';
import { RuleEditorState } from '../store/rule-editor.state';
import { RuleEditManager } from './rule-edit.manager';
import { EditorManagementService, LockDatabaseService } from '@oksygen-sim-train-libraries/components-services/editors';
import { RuleEditorContext } from './rule-editor-context';
import { LmsService } from '@oksygen-sim-core-libraries/components-services/lms';
import { ScenarioService } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { Backup } from '@oksygen-common-libraries/pio/backup';

@Injectable()
export class RuleEditService extends EditorManagementService<
RuleEditorState, RuleTemplate, RuleEditorContext, RuleEditManager
> {

  constructor(
    dataAccessService: DataAccessService,
    store: Store<RuleEditorState>,
    authService: AuthService,
    private ruleTemplateService: RuleTemplateService,
    private ruleBlockService: RuleBlockService,
    logger: Logging,
    registry: Registry,
    lmsService: LmsService,
    dialog: MatDialog,
    translateService: TranslateService,
    snackbar: MatSnackBar,
    zone: NgZone,
    private scenarioService: ScenarioService,
    private lockService: LockDatabaseService,
    private backup: Backup
  ) {
    super(
      dataAccessService, authService, store, registry, logger, lmsService,
      dialog, translateService, snackbar, zone, ruleTemplateService
    );
  }

  newManager(id: string | number): RuleEditManager {
    return new RuleEditManager(
      `${id}`,
      this.store,
      this.dataAccessService,
      this.authService,
      this.ruleTemplateService,
      this.ruleBlockService,
      this.logger,
      this.zone,
      this.dialog,
      this.snackbar,
      this.translateService,
      this.scenarioService.data(),
      this.lockService,
      this.backup
    );
  }

  public override confirmCloseEditor(id: string): SelfCompletingObservable<boolean> {
    const manager = this.getEditManager(id);

    return manager.confirmCloseEditor();
  }
}
