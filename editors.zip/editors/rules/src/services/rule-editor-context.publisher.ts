/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Inject, Injectable } from '@angular/core';
import { ContextPublisher } from '@oksygen-sim-train-libraries/components-services/common';
import { RuleEditorContext } from './rule-editor-context';
import { RuleEditorContextManager } from './rule-editor-context.manager';
import { APP_EVENT_NOTIFICATION_TOKEN, AppEventNotification, onAppEvent$, LOGOUT_EVENT } from '@oksygen-common-libraries/common';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class RuleEditorContextPublisher extends ContextPublisher<string, RuleEditorContext> {

  constructor(
    contextmanager: RuleEditorContextManager,
    @Inject(APP_EVENT_NOTIFICATION_TOKEN) private appEventNotifier: BehaviorSubject<AppEventNotification>
  ) {
    super(contextmanager, onAppEvent$(appEventNotifier, LOGOUT_EVENT));
  }

}
