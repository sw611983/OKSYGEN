/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { of } from 'rxjs';
import { ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainRuleEditModule } from '../rule-edit.module';
import { RuleEditorContextPublisher } from '../services/rule-editor-context.publisher';
import { RuleEditorBlocksPanelBlockComponent } from './rule-editor-blocks-panel/rule-editor-blocks-panel-block/rule-editor-blocks-panel-block.component';
import { RuleEditorBlocksPanelComponent } from './rule-editor-blocks-panel/rule-editor-blocks-panel.component';
import { RuleEditorCanvasComponent } from './rule-editor-canvas/rule-editor-canvas.component';
import { RuleEditorPropertiesPanelComponent } from './rule-editor-properties-panel/rule-editor-properties-panel.component';
import { RuleEditorTopToolbarComponent } from './rule-editor-top-toolbar/rule-editor-top-toolbar.component';

import { RuleEditorComponent } from './rule-editor.component';

describe('RuleEditorComponent', () => {
  let component: RuleEditorComponent;
  let fixture: ComponentFixture<RuleEditorComponent>;
  const activeRouteMap = new Map();
  activeRouteMap.set('id', '1234');

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainRuleEditModule],
      declarations: [
        RuleEditorComponent,
        RuleEditorCanvasComponent,
        RuleEditorBlocksPanelComponent,
        RuleEditorBlocksPanelBlockComponent,
        RuleEditorPropertiesPanelComponent,
        RuleEditorTopToolbarComponent
      ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            paramMap: of(activeRouteMap),
            data: of(null)
          }
        },
        RuleEditorContextPublisher,
        {provide: ContextSupplier, useClass: RuleEditorContextPublisher}
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleEditorComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
