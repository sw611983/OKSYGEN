/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { AfterViewInit, ChangeDetectorRef, Component, HostListener, NgZone, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Data } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';

import { filterTruthy, SuperCalled } from '@oksygen-common-libraries/common';
import { OK_BUTTON, PromptDialogComponent, PromptDialogData, TabService } from '@oksygen-common-libraries/material/components';
import { BaseEditorComponent } from '@oksygen-sim-train-libraries/components-services/editors';
import { PropertyUpdate, RuleBlock, RuleBlockService, RuleTemplate, RuleTemplateConnection } from '@oksygen-sim-train-libraries/components-services/rules';
import { Version, versionCompare, versionLatest } from '@oksygen-sim-train-libraries/components-services/versioning';

import { RULES_CARD_DATA } from '../browser/rule-browser.component';
import { ZoomAvailable, ZoomType } from '../models/rule-editor.model';
import { RuleEditManager } from '../services/rule-edit.manager';
import { RuleEditService } from '../services/rule-edit.service';
import { RuleEditorContext, RuleTemplateUi, TemplateBlockUi } from '../services/rule-editor-context';
import { RuleEditorContextPublisher } from '../services/rule-editor-context.publisher';
import { RuleBlockAddEvent, UpdateTemplateBlockPosition } from './rule-editor-canvas/renderer/rule-editor-canvas.renderer';

// eslint-disable-next-line @typescript-eslint/no-empty-interface, @typescript-eslint/no-empty-object-type
export interface RuleEditorConfig {}

/**
 * This is the main ancestor component for the rule editor screen. It contains a
 * top toolbar, left rule block selection panel, central editing area and right properties panel.
 */
@Component({
  selector: 'oksygen-rule-editor',
  templateUrl: './rule-editor.component.html',
  styleUrls: ['./rule-editor.component.scss']
})
export class RuleEditorComponent
  extends BaseEditorComponent<RuleTemplate, RuleEditorContext, RuleEditManager, RuleEditService>
  implements OnInit, AfterViewInit, OnDestroy
{
  ruleTemplate: RuleTemplateUi;
  selectedBlock: TemplateBlockUi;
  context: RuleEditorContext;

  blocks$: Observable<RuleBlock[]>;
  versions$: Observable<Version[]>;
  editable$: Observable<boolean>;
  selectedBlock$: Observable<TemplateBlockUi>;
  savedTemplateName$: Observable<string>;
  disableSave: boolean;
  triggerFormValidation$ = new Subject<void>();

  canZoomIn = true;
  canZoomOut = true;
  /** If you want to zoom in, zoom out or fit  */
  zoomEventSubject = new Subject<ZoomType>();

  /** If you want to be able to use panning */
  panningSubject = new Subject<void>();
  panningActivated = true;

  constructor(
    activatedRoute: ActivatedRoute,
    private ruleBlockService: RuleBlockService,
    contextSupplier: RuleEditorContextPublisher,
    private ruleEditService: RuleEditService,
    private snackbar: MatSnackBar,
    public dialog: MatDialog,
    private tabService: TabService,
    private cd: ChangeDetectorRef,
    private readonly zone: NgZone,
    private translateService: TranslateService
  ) {
    super(activatedRoute, contextSupplier, ruleEditService);
  }

  ngOnInit(): void {
    // const ruleEditorContext$ = this.contextSupplier.currentContext$();
    this.savedTemplateName$ = this.manager$.pipe(
      filterTruthy(),
      switchMap(ruleEditManager => ruleEditManager?.getSavedRuleTemplateName()),
      tap(rt => this.runCd())
    );
    const ruleTemplate$ = this.manager$.pipe(
      filterTruthy(),
      switchMap(manager => this.contextSupplier.currentContext$()),
      tap(context => {
        this.context = context;
      }),
      // tap(context => { this.selectedBlock = context.selectedBlock$.getValue(); }),
      switchMap(context => context.ruleTemplate$)
    );

    const sub = ruleTemplate$
      .pipe(
        tap(ruleTemplate => {
          const blocks: TemplateBlockUi[] = ruleTemplate?.ruleBlocks?.ruleBlock?.map(rb => {
            const ruleBlock = this.getBlockSync(rb.blockType);
            return { templateBlock: rb, ruleBlock, x: rb?.metaData?.x, y: rb?.metaData?.y };
          });
          this.ruleTemplate = { ruleTemplate, blocks };
          this.context?.setRuleTemplate(this.ruleTemplate);
        }),
        tap(ruleTemplate => {
          const tab = this.tabService.getTabGroupItem(RULES_CARD_DATA.id, ruleTemplate?.id);
          if (!!tab && tab.data.name !== ruleTemplate?.displayName) {
            tab.data.name = ruleTemplate?.displayName || t('Untitled Rule Template');
          }
        }),
        tap(rt => this.runCd())
      )
      .subscribe();
    this.subscription.add(sub);

    this.blocks$ = this.ruleBlockService.data().pipe(
      // we only care about blocks that have connection ports
      map(blocks => blocks?.filter(block => block.inputPorts?.port?.length > 0 || block?.outputPorts?.port?.length > 0))
    );
    this.selectedBlock$ = this.manager$.pipe(
      filterTruthy(),
      switchMap(manager => this.contextSupplier.currentContext$()),
      switchMap(context => combineLatest([context.selectedBlock$, ruleTemplate$])),
      map(([selectedBlock, ruleTemplate]) => {
        if (selectedBlock === null || selectedBlock === undefined || !ruleTemplate) {
          return null;
        }
        return this.getUiBlock(selectedBlock);
      }),
      tap(selectedBlock => {
        this.selectedBlock = selectedBlock;
      }),
      tap(rt => this.runCd())
    );
    this.versions$ = this.manager$.pipe(
      filterTruthy(),
      switchMap(manager => manager.getAllVersions()),
      map(templates => templates.map(template => template.version)),
      map(templates => templates.sort((a, b) => versionCompare(b, a))),
      tap(rt => this.runCd())
    );
    const latestVersion$ = this.versions$.pipe(map(versions => versionLatest(versions)));
    this.editable$ = combineLatest([ruleTemplate$, latestVersion$]).pipe(
      map(([template, latestVersion]) => {
        // new templates are editable
        if (!template || !latestVersion) {
          return true;
        }
        return versionCompare(template?.version, latestVersion) === 0;
      }),
      tap(rt => this.runCd())
    );
  }

  ngAfterViewInit(): void {
    this.initialiseDataManagers();
  }

  override ngOnDestroy(): SuperCalled {
    this.triggerFormValidation$.complete();
    return super.ngOnDestroy();
  }

  processConfig(context: RuleEditorContext, config: Data): void {}
  getDefaultConfig(): RuleEditorConfig {
    return null;
  }
  getEditorDataFromContext(context: RuleEditorContext): Observable<RuleTemplate> {
    return context?.ruleTemplate$ || of(null);
  }

  selectBlock(blockId: number): void {
    this.context.selectBlock(blockId);
  }

  deleteSelectedBlock(): void {
    // if a block is selected delete the block
    if (this.selectedBlock) {
      this.manager$.getValue().removeRuleBlock(this.selectedBlock.templateBlock);
      this.context.selectBlock(null);
    }
  }

  addRuleBlock(ruleBlock: RuleBlockAddEvent): void {
    this.context.selectBlock(null);
    this.manager$.getValue().addRuleBlock(ruleBlock.ruleBlock, ruleBlock.metaData);
  }

  getBlockSync(name: string): RuleBlock {
    let rb: RuleBlock = null;
    const sub = this.ruleBlockService.getRuleBlockByName(name).subscribe(block => {
      rb = block;
    });
    sub?.unsubscribe();
    return rb;
  }

  @HostListener('window:keydown.control.z', ['$event'])
  undo(event: KeyboardEvent): void {
    event.preventDefault();
    this.manager$.getValue().undo();
  }

  @HostListener('window:keydown.control.y', ['$event'])
  redo(event: KeyboardEvent): void {
    event.preventDefault();
    this.manager$.getValue().redo();
  }

  @HostListener('window:keydown.control.s', ['$event'])
  save(event: KeyboardEvent): void {
    event.preventDefault();
    this.saveRuleTemplate();
  }

  onNameUpdate(name: string): void {
    this.manager$.getValue().renameRuleTemplate(name);
  }

  onDescriptionUpdate(description: string): void {
    this.manager$.getValue().renameRuleTemplateDescription(description);
  }

  onBlockNameUpdate(update: { blockId: number; name: string }): void {
    this.manager$.getValue().renameBlock(update.blockId, update.name || '');
  }

  onBlockDescriptionUpdate(update: { blockId: number; description: string }): void {
    this.manager$.getValue().renameBlockDescription(update.blockId, update.description);
  }

  onBlockPropertiesUpdate(update: { blockId: number; updates: PropertyUpdate[] }): void {
    this.manager$.getValue().updateBlockProperties(update.blockId, update.updates);
  }

  disableSaveUpdate(disableSave: boolean): void {
    this.disableSave = disableSave;
  }

  getUiBlock(blockId: number): TemplateBlockUi {
    const templateBlock = this.ruleTemplate.ruleTemplate?.ruleBlocks?.ruleBlock?.find(rb => rb.id === blockId);
    const ruleBlock = this.getBlockSync(templateBlock?.blockType);
    // if (!templateBlock || !ruleBlock) { this.selectedBlock = null; return; }
    // this.selectedBlock = { templateBlock, ruleBlock };
    if (!templateBlock || !ruleBlock) {
      return null;
    }
    return { templateBlock, ruleBlock };
  }

  saveRuleTemplate(): void {
    const ruleTemplateInValid = RuleEditManager.validateRuleTemplateForSave(this.ruleTemplate.ruleTemplate);

    if (ruleTemplateInValid) {
      this.triggerValidation();
      this.zone.run(() => {
        // snackbar needs to run in zone
        const displayString = 'Cannot save the rule. '.concat(ruleTemplateInValid);
        this.snackbar.open(t(displayString), t('Dismiss'));
      });
    } else if (this.disableSave) {
      this.triggerValidation();
      this.zone.run(() => {
        this.snackbar.open(t('Cannot save the rule. There are items that require your attention'), t('Dismiss'));
      });
    } else {
      const sub = this.manager$
        .getValue()
        .saveRuleTemplate()
        .subscribe(ok => {
          if (ok) {
            this.snackbar.open(this.translateService.instant(t('Rule template saved')), '', { duration: 3000 });
          } else {
            const promptData = new PromptDialogData();
            // FIXME More meaningful message please
            promptData.title = t('Could not save Rule template');
            // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
            promptData.content = t('Please contact an administrator.');
            promptData.buttons = OK_BUTTON;
            PromptDialogComponent.open(this.dialog, { id: 'SAVE_FAILED', data: promptData }, () => {});
          }
          sub?.unsubscribe();
        });
    }
  }

  private triggerValidation(): void {
    this.triggerFormValidation$.next(undefined);
  }

  updatePosition(data: UpdateTemplateBlockPosition): void {
    // this will override any other meta properties!
    this.manager$.getValue().updateRuleBlockMeta(data.blockId, { x: data.x, y: data.y });
  }

  updateConnections(connections: RuleTemplateConnection[]): void {
    this.manager$.getValue().updateRuleBlockConnections(connections);
  }

  versionChange(version: Version): void {
    this.manager$.getValue().setVersion(version);
  }

  runCd(): void {
    // a weird bug is that change detection will not run on Cordova on our template with ngIf="{foo: foo$ | async} as obs"
    // this will still work on our shell app, so care is needed!
    setTimeout(() => {
      this.cd.detectChanges();
    }, 10);
  }

  zoomIn(): void {
    this.zoomEventSubject.next(ZoomType.IN);
  }
  zoomOut(): void {
    this.zoomEventSubject.next(ZoomType.OUT);
  }
  zoomToFit(): void {
    this.zoomEventSubject.next(ZoomType.FIT);
  }
  handTool(): void {
    this.panningSubject.next(undefined);
  }
  zoomUpdated(zoomLevel: ZoomAvailable): void {
    this.canZoomIn = zoomLevel.canZoomIn;
    this.canZoomOut = zoomLevel.canZoomOut;
  }
  panningUpdated(panningActivated: boolean): void {
    this.panningActivated = panningActivated;
  }
}
