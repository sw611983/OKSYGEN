/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { cloneDeep } from 'lodash';
import { fromEvent, Observable, Subscription } from 'rxjs';
import { delay, filter, switchMap } from 'rxjs/operators';

import { extractJSONData, filterTruthy, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import {
  getPortType,
  RuleBlock,
  RuleBlockService,
  RuleProperties,
  RuleTemplateConnection,
  RuleTemplateRuleBlock
} from '@oksygen-sim-train-libraries/components-services/rules';

import { ZoomAvailable, ZoomType } from '../../models/rule-editor.model';
import { RuleTemplateUi, TemplateBlockUi } from '../../services/rule-editor-context';
import { RuleEditorContextPublisher } from '../../services/rule-editor-context.publisher';
import { JointjsCanvasRenderer } from './renderer/jointjs-canvas.renderer';
import { RuleBlockAddEvent, UpdateTemplateBlockPosition } from './renderer/rule-editor-canvas.renderer';
import { RoundedRectangle } from './shapes';

/**
 * This component is the main editing area for the rule editor.
 * I am trying to stick to 1 way data binding as much as possible, so this component
 * will generally emit events when you edit your template rather than directly applying them.
 * Sometimes this is tricky due to the nature of jointJS, so it isn't as 100% as I'd like.
 * JointJS logic has been mostly moved to the rule editor canvas renderer helper class.
 */
@Component({
  selector: 'oksygen-rule-editor-canvas',
  templateUrl: './rule-editor-canvas.component.html',
  styleUrls: ['./rule-editor-canvas.component.scss']
})
export class RuleEditorCanvasComponent implements OnDestroy, AfterViewInit, OnChanges {
  @Input('ruleTemplate') ruleTemplateInput: RuleTemplateUi;
  @Input() editable: boolean;
  @Input() zoomEventSubject: Observable<ZoomType>;
  @Input() panningSubject: Observable<void>;
  @Output() readonly selectedBlock: EventEmitter<number> = new EventEmitter();
  @Output() readonly addRuleBlock: EventEmitter<RuleBlockAddEvent> = new EventEmitter();
  @Output() readonly updatePosition: EventEmitter<UpdateTemplateBlockPosition> = new EventEmitter();
  @Output() readonly changeConnections: EventEmitter<RuleTemplateConnection[]> = new EventEmitter();
  @Output() readonly zoomUpdated: EventEmitter<ZoomAvailable> = new EventEmitter();
  @Output() readonly panningUpdated: EventEmitter<boolean> = new EventEmitter();
  @Output() readonly deleteBlock: EventEmitter<number> = new EventEmitter();
  @ViewChild('ruleEditorCanvas') canvas: ElementRef<HTMLElement>;

  /** Map a rule block to it's rendered element via their ids. */
  private ruleTemplate: RuleTemplateUi;
  private renderer: JointjsCanvasRenderer;
  private selectedSub = Subscription.EMPTY;
  private subscription: Subscription = new Subscription();
  private keySubscriptions: Subscription = new Subscription();

  constructor(
    private readonly logger: Logging,
    private readonly contextSupplier: RuleEditorContextPublisher,
    private readonly imageService: ImageService,
    private readonly ruleBlockService: RuleBlockService
  ) {}

  ngOnDestroy(): void {
    this.renderer?.destroy();
    this.subscription?.unsubscribe();
    this.selectedSub.unsubscribe();
  }

  ngAfterViewInit(): void {
    this.renderer = new JointjsCanvasRenderer(this.canvas, this.imageService, this.logger);
    this.renderer.initialiseCanvas(true);
    if (this.ruleTemplateInput) {
      const template = this.deepCopyTemplate(this.ruleTemplateInput);
      this.ruleTemplate = template;
      this.renderRuleBlocks(template);
    }
    const selectedRendererSub = this.renderer.getSelectedNode$().subscribe(ruleBlockId => {
      this.selectedBlock.emit(ruleBlockId);
    });
    const connectedSub = this.renderer.getConnections$().subscribe(connections => {
      this.emitEvent(this.changeConnections, connections);
      // this.changeConnections.emit(connections);
    });
    const positionSub = this.renderer.getPositionUpdates$().subscribe(position => {
      this.emitEvent(this.updatePosition, { x: position.x, y: position.y, blockId: position.blockId });
      // this.updatePosition.emit({x: position.x, y: position.y, blockId: position.blockId});
    });
    /**
     * Get the zoom updates from the renderer and emit them to the parent component.
     * Typically when using the mouse wheel
     */
    const zoomSub = this.renderer.getZoomUpdates$().subscribe(zoom => {
      this.zoomUpdated.emit(zoom);
    });
    /**
     * Listen for zoom events from the parent component and apply them to the renderer.
     */
    const zoomEventSub = this.zoomEventSubject?.subscribe(zoomType => {
      if (zoomType === ZoomType.IN) {
        this.renderer.zoomIn();
      }
      if (zoomType === ZoomType.OUT) {
        this.renderer.zoomOut();
      }
      if (zoomType === ZoomType.FIT) {
        this.renderer.zoomToFit();
      }
    });
    /**
     * Get the panning update from the renderer and handle them in the parent component
     */
    const panningSub = this.renderer.getPanningUpdate$().subscribe(panning => {
      this.panningUpdated.emit(panning);
    });
    /**
     * Listen for panning events from the parent component and apply them to the renderer.
     */
    const panningEventSub = this.panningSubject?.subscribe(() => {
      this.renderer.switchPanningState();
    });

    /** Handle people pressing the space bar to activate panning */
    this.canvas.nativeElement.addEventListener('mouseenter', () => {
        // We unsubscribe to avoid having multiple subscription.
        // We have to create a new subscription since it has been unsubcribed already
        this.keySubscriptions.unsubscribe();
        this.keySubscriptions = new Subscription();
        this.subscription.add(this.keySubscriptions);

        this.keySubscriptions.add(fromEvent(document, 'keydown')
        .pipe(filter((event: any) => event.key === ' '))
        .subscribe(() => {
          // Do stuff when the space key is pressed
          this.renderer.switchPanningState(true);
        }));

      this.keySubscriptions.add(fromEvent(document, 'keyup')
        .pipe(filter((event: any) => event.key === ' '))
        .subscribe(() => {
          // Do stuff when the space key is released
          this.renderer.switchPanningState(false);
        })
        );

     this.keySubscriptions.add(fromEvent(document, 'keydown')
        .pipe(filter((event: any) => event.key === 'Delete'))
        .subscribe(() => {
          // Try to delete a block when the 'suppr' key is pressed
          this.deleteBlock.emit();
        }));
    });

    this.canvas.nativeElement.addEventListener('mouseleave', () => {
      this.keySubscriptions.unsubscribe();
    });
    this.subscription.add(selectedRendererSub);
    this.subscription.add(connectedSub);
    this.subscription.add(positionSub);
    this.subscription.add(zoomSub);
    this.subscription.add(zoomEventSub);
    this.subscription.add(panningSub);
    this.subscription.add(panningEventSub);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.ruleTemplateInput?.currentValue !== changes.ruleTemplateInput?.previousValue) {
      if (this.renderer?.isInitialised()) {
        const current: RuleTemplateUi = changes.ruleTemplateInput?.currentValue;
        const prev: RuleTemplateUi = changes.ruleTemplateInput?.previousValue;
        if (current?.ruleTemplate?.id !== prev?.ruleTemplate?.id) {
          this.renderer.clearGraph();
        }
        const template = this.deepCopyTemplate(changes.ruleTemplateInput.currentValue);
        this.ruleTemplate = template;
        this.renderRuleBlocks(template, changes.ruleTemplateInput.previousValue);
      }
      this.selectedSub.unsubscribe();
      this.selectedSub = this.contextSupplier
      .currentContext$()
      .pipe(
        filterTruthy(),
        switchMap(man => man.selectedBlock$),
        delay(50)
      )
      .subscribe(selectedBlock => {
        this.renderer.resetStyles(true);
        if (selectedBlock !== null && selectedBlock !== undefined) {
          this.renderer.selectElement(selectedBlock);
        }
        this.renderer.selectElement(selectedBlock);
      });
    }
    if (changes.editable) {
      if (changes.editable.currentValue === true) {
        this.enableInteraction();
      } else {
        this.disableInteraction();
      }
    }
  }

  deepCopyTemplate(ruleTemplate: RuleTemplateUi): RuleTemplateUi {
    return cloneDeep(ruleTemplate);
  }

  renderRuleBlocks(ruleTemplate: RuleTemplateUi, previous?: RuleTemplateUi): void {
    const prevPositions = new Map<number, { x: number; y: number }>();
    if (previous) {
      previous?.blocks?.forEach(block => {
        prevPositions.set(block.templateBlock.id, this.renderer.getNodePosition(block.templateBlock.id));
        // check if all previously existing blocks still exist
        const exists = ruleTemplate.blocks.find(b => b.templateBlock.id === block.templateBlock.id);
        if (!exists) {
          this.renderer.removeNode(block.templateBlock.id);
        }
      });
    }
    const canvasBlocks: { block: TemplateBlockUi; canvasBlock: RoundedRectangle }[] = [];
    ruleTemplate?.blocks?.forEach((block, index) => {
      let position: { x: number; y: number };
      if (block.templateBlock?.metaData?.x) {
        position = { x: block.templateBlock?.metaData?.x, y: block.templateBlock?.metaData?.y };
      } else {
        const prevPosition = prevPositions.get(block.templateBlock.id);
        if (prevPosition) {
          position = { x: prevPosition.x, y: prevPosition.y };
        } else {
          position = this.renderer.getBlockPosition(index);
        }
        // this.emitEvent(this.updatePosition, {x: position.x, y: position.y, blockId: block.templateBlock.id});
        // this.updatePosition.emit({x: position.x, y: position.y, blockId: block.templateBlock.id});
      }
      position = this.renderer.getBoundedPosition(position);
      const canvasBlock = this.renderer.renderNode(
        block.templateBlock.id,
        block.templateBlock.displayName,
        block.ruleBlock.name,
        block.ruleBlock.icon,
        block.ruleBlock.category,
        position.x,
        position.y
      );
      block.ruleBlock.inputPorts?.port?.forEach(port => {
        if(
          (port.portType === 'variant')
          && (
            this.isInputPortConnected(block.templateBlock.id, ruleTemplate?.ruleTemplate?.connections?.connection)
            || this.isOutputPortConnected(block.templateBlock.id, ruleTemplate?.ruleTemplate?.connections?.connection)
          )
        ) {
            if (this.isInputPortConnected(block.templateBlock.id, ruleTemplate?.ruleTemplate?.connections?.connection))
            {
              const targetConnection = this.isInputPortConnected(block.templateBlock.id, ruleTemplate?.ruleTemplate?.connections?.connection);
              const sourceRuleBlock = this.getRuleBlock(targetConnection.source.blockId);
              const sourcePortType = sourceRuleBlock.outputPorts.port.find((portTarget: any) => portTarget.name === targetConnection.source.port);
              const p = getPortType(sourcePortType);
              this.renderer.updateInputPortNode(canvasBlock, port.name, p.type, p.image);
              //Update the icon of the output accordingly
              block.ruleBlock.outputPorts?.port?.forEach(output => {
                this.renderer.updatOutputPortNode(canvasBlock, output.name, p.type, p.image);
            });
            }
        }
        else if(port.portType ==='variant') {
          const p = getPortType(port);
          this.renderer.updateInputPortNode(canvasBlock, port.name, p.type, p.image);
        }
        else{
          const p = getPortType(port);
          this.renderer.addInputPortToNode(canvasBlock, port.name, p.type, p.image);
        }
      });
      block.ruleBlock.outputPorts?.port?.forEach(port => {
        if(
          (port.portType === 'variant')
          && (
            this.isInputPortConnected(block.templateBlock.id, ruleTemplate?.ruleTemplate?.connections?.connection)
            || this.isOutputPortConnected(block.templateBlock.id, ruleTemplate?.ruleTemplate?.connections?.connection))
          )
        {
            if (this.isOutputPortConnected(block.templateBlock.id, ruleTemplate?.ruleTemplate?.connections?.connection))
            {
              const targetConnection = this.isOutputPortConnected(block.templateBlock.id, ruleTemplate?.ruleTemplate?.connections?.connection);
              const targetRuleBlock = this.getRuleBlock(targetConnection.destination.blockId);
              const targetPortType = targetRuleBlock.inputPorts.port.find((portTarget: any) => portTarget.name === targetConnection.destination.port);
              const p = getPortType(targetPortType);
              this.renderer.updatOutputPortNode(canvasBlock, port.name, p.type, p.image);
              //Update the icon of the input accordingly
              block.ruleBlock.inputPorts?.port?.forEach(input => {
                this.renderer.updateInputPortNode(canvasBlock, input.name, p.type, p.image);
            });
            }
        }
        else if(port.portType === 'variant') {
          const p = getPortType(port);
          this.renderer.updatOutputPortNode(canvasBlock, port.name, p.type, p.image);
        }
        else {
          const p = getPortType(port);
          this.renderer.addOutputPortToNode(canvasBlock, port.name, p.type, p.image);
        }
      });
      canvasBlock.resetStyle();
      canvasBlocks.push({ block, canvasBlock });
    });
    ruleTemplate?.ruleTemplate?.connections?.connection?.forEach(c => {
      const source = canvasBlocks.find(cb => cb.block.templateBlock.id === c.source.blockId);
      const destination = canvasBlocks.find(cb => cb.block.templateBlock.id === c.destination.blockId);
      this.renderer.renderConnection({ shape: source.canvasBlock, port: c.source.port }, { shape: destination.canvasBlock, port: c.destination.port });
    });
  }

  onDrag(ev: DragEvent): void {
    ev.preventDefault();
    ev.dataTransfer.dropEffect = 'move';
  }

  onDrop(ev: DragEvent): void {
    ev.preventDefault();
    const data = extractJSONData<RuleBlock>(ev.dataTransfer);
    const position = this.renderer.dropBlockAtPosition(ev.offsetX, ev.offsetY);
    const emitData: RuleBlockAddEvent = { ruleBlock: data, metaData: position };
    this.emitEvent(this.addRuleBlock, emitData);
    // this.addRuleBlock.emit(emitData);
  }

  addRuleBlockToTemplate(ruleBlock: RuleBlock, template: RuleTemplateUi, x: number, y: number): void {
    if (!template?.ruleTemplate?.ruleBlocks?.ruleBlock) {
      template.ruleTemplate.ruleBlocks = { ruleBlock: [] };
    }
    const id = template.ruleTemplate.ruleBlocks.ruleBlock.length + 1;
    const templateBlock = this.ruleBlockToRuleBlockReference(id, ruleBlock);
    template.ruleTemplate.ruleBlocks.ruleBlock.push(templateBlock);
    // this.renderRuleBlocks(template);
    const canvasBlock = this.renderer.renderNode(templateBlock.id, templateBlock.displayName, ruleBlock.name, ruleBlock.icon, ruleBlock.category, x, y);
    ruleBlock.inputPorts?.port?.forEach(port => {
      const p = getPortType(port);
      this.renderer.addInputPortToNode(canvasBlock, port.name, p.type, p.image);
    });
    ruleBlock.outputPorts?.port?.forEach(port => {
      const p = getPortType(port);
      this.renderer.addOutputPortToNode(canvasBlock, port.name, p.type, p.image);
    });
    canvasBlock.resetStyle();
  }

  ruleBlockToRuleBlockReference(id: number, ruleBlock: RuleBlock): RuleTemplateRuleBlock {
    const properties: RuleProperties = {
      property:
        ruleBlock?.properties?.property?.map(p => ({
          name: p.name,
          value: p.defaultValue
        })) ?? []
    };
    const ref: RuleTemplateRuleBlock = {
      id,
      displayName: ruleBlock.displayName,
      displayDescription: '',
      blockType: ruleBlock.name,
      version: ruleBlock.version,
      properties
    };
    return ref;
  }

  private emitEvent<T>(eventEmitter: EventEmitter<T>, event: T): void {
    if (this.editable) {
      eventEmitter.emit(event);
    }
  }

  private enableInteraction(): void {
    this.renderer?.enableInteraction();
  }

  private disableInteraction(): void {
    this.renderer?.disableInteraction();
  }

  getRuleBlock(blockId: number): RuleBlock {
    const templateBlock = this.ruleTemplate.ruleTemplate?.ruleBlocks?.ruleBlock?.find(rb => rb.id === blockId);
    let rb: RuleBlock = null;
    this.ruleBlockService.getRuleBlockByName(templateBlock?.blockType).pipe(
      takeOneTruthy()
    ).subscribe(block => {
      rb = block;
    });
    return rb;
  }

  isOutputPortConnected(blockId: number, connections: RuleTemplateConnection[]): RuleTemplateConnection {
    const targetConnection = connections.find(connection => (connection.source.blockId === blockId));
    return targetConnection;
  }

  isInputPortConnected(blockId: number, connections: RuleTemplateConnection[]): RuleTemplateConnection {
    const targetConnection = connections.find(connection => (connection.destination.blockId === blockId));
    return targetConnection;
  }
}
