/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ElementRef } from '@angular/core';
import { dia, linkTools, shapes, util } from 'jointjs';
import { Observable, Subject } from 'rxjs';
import svgPanZoom from 'svg-pan-zoom';

import { Logging } from '@oksygen-common-libraries/pio';
import { CategoryType, RuleTemplateConnection } from '@oksygen-sim-train-libraries/components-services/rules';

import '../shapes'; // "run" the file to include our custom shapes
import { RuleEditorCanvasRenderer, UpdateTemplateBlockPosition } from './rule-editor-canvas.renderer';
import { RoundedRectangle, SimpleLink } from '../shapes';
import { GlobalImageStoreKey, ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import { ZoomAvailable } from '../../../models/rule-editor.model';

export class JointjsCanvasRenderer implements RuleEditorCanvasRenderer {
  private graph: dia.Graph;
  private paper: dia.Paper;
  blockDimensions = { width: 200, height: 100 };
  private selectedNodeSubject = new Subject<number>();
  private positionUpdateSubject = new Subject<UpdateTemplateBlockPosition>();
  private connections$ = new Subject<RuleTemplateConnection[]>();
  /** Enable or disable zooming in/out */
  private zoomSubject = new Subject<ZoomAvailable>();
  /** The panning subject */
  private panSubject = new Subject<boolean>();
  /** Allow panning when pressing the spacebar or if the user select the panning mode */
  private allowPanning = false;

  /** Enables panning and zooming */
  private panAndZoom: SvgPanZoom.Instance;
  /** Canvas Size */
  private canvasSize: { width: number; height: number } = { width: 10000, height: 10000 };
  /** Viewport Size. I'd like to use panAndZoom.getSizes().viewport but it is always zero. Don't know why and already wasted hours on this.
   * This is used to calculate the limit value for the panning and the zoom level.*/
  private windowSize: { width: number; height: number } = { width: 0, height: 0 };

  constructor(private canvas: ElementRef<HTMLElement>, private imageService: ImageService, private logger: Logging) {}

  initialiseCanvas(usePanAndZoom?: boolean): void {
    this.windowSize = { width: this.canvas.nativeElement.clientWidth, height: this.canvas.nativeElement.clientHeight };
    this.graph = new dia.Graph({}, { cellNamespace: shapes });
    // TODO responsive layout
    const defaultLink = new SimpleLink();

    this.paper = new dia.Paper({
      el: this.canvas.nativeElement,
      model: this.graph,
      width: `${this.canvasSize.width}px`,
      height: `${this.canvasSize.height}px`,
      cellViewNamespace: shapes,
      gridSize: 1, // can probably disable this,
      snapLinks: true,
      perpendicularLinks: true,
      defaultLink,
      validateConnection: this.validateConnection.bind(this),
      linkPinning: false,
      markAvailable: true,
      sorting: dia.Paper.sorting.APPROX,
      background: {color: '#f5f5f5' } // match rule-editor.component background
    });

    this.createBorderElements();

    this.paper.on('element:pointerclick', (elementView, evt, x, y) => {
      evt.stopPropagation();
      this.selectedNodeSubject.next(+elementView.model.id);
    });
    this.paper.on('blank:pointerclick', (evt, x, y) => {
      evt.stopPropagation();
      this.selectedNodeSubject.next(null);
    });

    // not using source one because it breaks when you change source
    // const sourceArrowheadTool = new linkTools.SourceArrowhead();
    const targetArrowheadTool = new linkTools.TargetArrowhead();
    const removeButton = new linkTools.Remove();

    const toolsView = new dia.ToolsView({
      tools: [
        targetArrowheadTool,
        removeButton //, sourceArrowheadTool
      ]
    });

    // show link tools
    this.paper.on('link:mouseenter', linkView => {
      if (this.paper.options.interactive) {
        linkView.addTools(toolsView);
      }
    });

    // hide link tools
    this.paper.on('link:mouseleave', linkView => {
      linkView.removeTools();
    });

    // adjust vertices when a cell is removed or its source/target was changed
    this.graph.on('add', (element: dia.Cell, ...args) => {
      // NO-OP
    });
    this.graph.on('remove', (element: dia.Cell, children: any, source: { ui: boolean }) => {
      // don't update connection when the source was not the UI!
      if (element.isLink() && source.ui) {
        this.connectionUpdated();
      }
    });
    this.graph.on('change:source change:target', (link: SimpleLink, evt: any, source: { ui: boolean }) => {
      if (source.ui) {
        this.connectionUpdated();
      }
    });
    // adjust vertices when the user stops interacting with an element
    this.paper.on('cell:pointerup', (cell: dia.CellView, evt: dia.Event, x: number, y: number) => {
      if (!cell.model.isLink()) {
        this.positionUpdated(+cell.model.id, cell.model.getBBox().x, cell.model.getBBox().y);
      }
    });

    if (usePanAndZoom) {
      setTimeout(() => {
        // wait for the graph to be rendered before we can target it.
        const panAndZoomContainer = this.canvas.nativeElement.querySelector('svg');
        this.initialisePanAndZoom(panAndZoomContainer);
      }, 100);
    }
  }

  /**
   * Support Pan and Zoom.
   *
   * @param element the container element that we want to pan and zoom
   */
  initialisePanAndZoom(element: SVGElement): void {
    const interpolateZoom = (s: number): number => {
      const minZoom = this.getMinZoom();
      const maxZoom = this.getMaxZoom();
      // This will return 1 when s >= maxZoom, and 0 when s is minZoom
      return Math.min((s - minZoom) / (maxZoom - minZoom), 1);
    };

    // do not change to arrow syntax! This way we have svgPanZoom object as scope and can use 'this'
    const beforePan = (oldPan: any, newPan: any): { x: number; y: number } => {
      const gutterWidth = 100;
      const gutterHeight = 100;
      // Size.Viewbox is always 0,0,0,0 ...?
      const sizes = this.panAndZoom.getSizes() as any;
      const factorForZoomLevel = interpolateZoom(this.panAndZoom.getZoom());
      const leftLimit = gutterWidth;
      // The current behaviour is not super satisfying but I've spent too much time on this already.
      // bottom and right needs more margin since the anchor for the cell is on the top left.
      // We do | --------- Width ---------//viewport Width // --- //gutter// --|
      const rightLimit = -(sizes.width + gutterWidth + this.blockDimensions.width - this.windowSize.width);
      const topLimit = gutterHeight;
      const bottomLimit = -(sizes.height + gutterHeight + this.blockDimensions.height - this.windowSize.height);
      const customPan = { x: 0, y: 0 };
      // If you drag to the right, the whole diagram will move to the left and vice versa
      // So we have to move the diagram to the opposite direction, so the thing is between 100 and -4900 for a 5000 wide diagram
      customPan.x = this.bounded(newPan.x, rightLimit * factorForZoomLevel, leftLimit * factorForZoomLevel);
      customPan.y = this.bounded(newPan.y, bottomLimit * factorForZoomLevel, topLimit * factorForZoomLevel);
      return customPan;
    };

    this.panAndZoom = svgPanZoom(element, {
      zoomEnabled: true,
      panEnabled: false,
      controlIconsEnabled: false,
      minZoom: this.getMinZoom(),
      maxZoom: this.getMaxZoom(),
      fit: false,
      contain: false,
      // We want to center it BUT if we do it here, we end up in 5000, 5000 and since this is the panning, the diagram is moved the wrong way
      center: false,
      zoomScaleSensitivity: 0.3,
      dblClickZoomEnabled: false,
      beforePan
    });

    // Center the view at the beginning
    this.panAndZoom.pan({ x: -this.canvasSize.width / 2, y: -this.canvasSize.height / 2 + this.windowSize.height / 2 });

    //Enable pan when a blank area is click (held) on
    this.paper.on('blank:pointerdown', (evt, x, y) => {
      if (!this.allowPanning) return;
      this.panAndZoom.enablePan();
    });

    //Disable pan when the mouse button is released
    this.paper.on('cell:pointerup blank:pointerup', (cellView, event) => {
      this.panAndZoom.disablePan();
    });

    this.panAndZoom.setOnZoom(() => {
      this.publishCurrentZoom();
    });

    this.zoomToFit();
    this.publishCurrentPanningState();
  }
  destroy(): void {
    this.graph.destroy();
    this.selectedNodeSubject.complete();
    this.positionUpdateSubject.complete();
    this.connections$.complete();
  }

  isInitialised(): boolean {
    return !!this.graph;
  }

  clearGraph(): void {
    // clear accepts an optional argument we can pass to the graph's "source" param handler above
    // we don't need to, as it already has "ui" which we can use to determine event source
    this.graph?.clear();

    // recreate the borders when the graphs is cleared
    this.createBorderElements();
  }

  getNode(id: string | number): dia.Cell {
    return this.paper.getModelById(id);
  }

  getNodePosition(id: string | number): { x: number; y: number } {
    const rect: RoundedRectangle = this.graph.getCell(id) as any;
    if (!rect) return null;
    return rect.position();
  }

  getSelectedNode$(): Observable<number> {
    return this.selectedNodeSubject.asObservable();
  }

  getConnections$(): Observable<RuleTemplateConnection[]> {
    return this.connections$.asObservable();
  }

  getPositionUpdates$(): Observable<UpdateTemplateBlockPosition> {
    return this.positionUpdateSubject.asObservable();
  }

  /**
   * Renders a (rectangular) node. This is an upsert.
   *
   * @param id the id of the node
   * @param text a text description to display on the node
   * @param blockName the rule block name to find associted ImageHandler
   * @param icon the icon
   * @param x the horizontal position (relative to the top left of the node)
   * @param y the vertical position (relative to the top left of the node)
   */
  renderNode(id: string | number, text: string, blockName: string, icon: string, category: CategoryType, x: number, y: number): RoundedRectangle {
    const filePath = icon?.split('/') ?? [''];
    const filename = filePath[filePath.length - 1]?.split('.')?.[0] ?? '';

    let rect: RoundedRectangle = this.graph.getCell(id) as any;
    const handler = this.imageService.getGlobalImage(GlobalImageStoreKey.RULE_BLOCK, blockName);
    const iconAsBlob = handler.asBlob();
    const found = !!rect;
    if (!rect) {
      rect = new RoundedRectangle(category, {
        id,
        inPorts: [],
        outPorts: []
      });
    }
    //rect.attributes['id'] = id;
    rect.changeInGroup({ position: { name: 'left' } });
    rect.changeOutGroup({ position: { name: 'right' } });
    rect.position(x, y);
    rect.resize(this.blockDimensions.width, this.blockDimensions.height);
    const multiLineText = util.breakText(text, { width: this.blockDimensions.width - 60, height: this.blockDimensions.height });
    iconAsBlob.then(blob => {
      // bit ugly, see https://developer.chrome.com/blog/migrate-way-from-data-urls-in-svg-use
      const url = URL.createObjectURL(blob);
      rect.attr({
        label: {
          text: multiLineText
        },
        image: {
          xmlns: 'http://www.w3.org/2000/svg'
        },
        svgChild: {
          href: url + '#' + filename
        }
      });
    });
    if (!found) {
      rect.addTo(this.graph);
    }
    return rect;
  }

  removeNode(id: string | number): void {
    const rect: RoundedRectangle = this.graph.getCell(id) as any;
    this.graph.removeCells([rect]);
    // rect.remove();
  }

  addInputPortToNode(node: RoundedRectangle, id: string, type: string, imgSrc?: string): void {
    this.addPortToNode(node, 'in', id, type, imgSrc);
  }

  addOutputPortToNode(node: RoundedRectangle, id: string, type: string, imgSrc?: string): void {
    this.addPortToNode(node, 'out', id, type, imgSrc);
  }

  updateInputPortNode(node: RoundedRectangle, id: string, type: string, imgSrc?: string): void {
    node.removePort(id);
    this.addPortToNode(node, 'in', id, type, imgSrc);
  }

  updatOutputPortNode(node: RoundedRectangle, id: string, type: string, imgSrc?: string): void {
    node.removePort(id);
    this.addPortToNode(node, 'out', id, type, imgSrc);
  }

  enableInteraction(): void {
    this.paper.setInteractivity(true);
  }

  disableInteraction(): void {
    this.paper.setInteractivity(false);
  }

  /**
   * Adds a port to a node. imgSrc accepts both svgs and references to our font icons.
   * For *.svgs, just supply "assets/path/to/file.svg".
   * For our font icons, just pass the icon name, ie "train"
   *
   * @param node the node to add to
   * @param group group is either 'in' or 'out'
   * @param id the id of the port
   * @param type type of port, ie only "train" outputs can be connected to "train" inputs
   * @param imgSrc the image to show on the port, supports both .svgs and oksygen font images
   */
  private addPortToNode(node: RoundedRectangle, group: 'in' | 'out', id: string, type: string, imgSrc?: string): void {
    if (node.hasPort(id)) {
      return;
    } // TODO update properties
    const img = imgSrc ?? 'assets/images/train.svg';
    let imageHtml: string;
    // if an image, use an image tag and render. Otherwise, it's one of our icons.
    if (img.match(/^(\w|\/|\\|\.)+\.{1}(jpg|png|gif|svg)+$/g)) {
      // quick and dirty test for images
      imageHtml = `<image href="${img}" width="20px" height="20px" x="-10px" y="-8px" />`;
    } else {
      // FIXME validate icon exists
      // example: \common\tools\oksygen_material_guidelines\web\src\app\pages\components\btn-indicators\icon
      imageHtml = `<text style="font-size: 18px" class="material-icons mat-icon port-icon" x="-9px" y="8px">${img}</text>`;
    }
    if (group === 'in') {
      node.addInPort(id);
      node.changeInGroup({
        markup: `${node.getPortOutlineMarkup()}${imageHtml}`
      });
    } else {
      node.addOutPort(id);
      node.changeOutGroup({
        markup: `${node.getPortOutlineMarkup()}${imageHtml}`
      });
    }
    // only way I've found to kill the auto label jointJS appends
    node.portProp(id, 'attrs/.port-label/text', '');
    node.portProp(id, 'type', type);
  }

  renderConnection(from: { shape: RoundedRectangle; port?: string }, to: { shape: RoundedRectangle; port?: string }): SimpleLink {
    const links = this.graph.getLinks();
    const exists = links.find(lnk => {
      const source = lnk.source();
      const target = lnk.target();
      return source.id === from.shape.id && source.port === from.port && target.id === to.shape.id && target.port === to.port;
    });
    if (exists) {
      return null;
    }
    const link = new SimpleLink();
    link.simpleSource(from.shape, from.port);
    link.simpleTarget(to.shape, to.port);
    link.addTo(this.graph);
    return link;
  }

  connectionUpdated(): void {
    const rawLinks = this.graph.getLinks();
    // list of "valid" links
    let validUpdate = true;
    const connections: RuleTemplateConnection[] = rawLinks.map(link => {
      const source = link.source();
      const target = link.target();
      // irritatingly, we get updates when a user detaches a connection immediately
      // rather than just when they actually confirm their connection change
      // we should not emit in this case as they user hasn't finished their interaction.
      if (!source?.id || !source?.port || !target?.id || !target.port) {
        validUpdate = false;
      }
      return {
        source: { blockId: +source.id, port: source.port },
        destination: { blockId: +target.id, port: target.port }
      };
    });
    if (validUpdate) {
      this.connections$.next(connections);
    }
  }

  positionUpdated(blockId: number, x: number, y: number): void {
    this.positionUpdateSubject.next({ blockId, x, y });
  }

  resetStyles(overrideSelection?: boolean): void {
    if (!this.isInitialised()) {
      this.logger.warn(`[RuleEditorCanvasRenderer] tried to reset styles before graph ready!`);
      return;
    }
    const elements = this.paper.model.getElements();
    elements.forEach(e => {
      if (e.attributes.type === 'sydac.RoundedRectangle') {
        (e as RoundedRectangle).resetStyle(overrideSelection);
      }
    });
  }

  selectElement(id: string | number): void {
    if (!this.isInitialised()) {
      this.logger.warn(`[RuleEditorCanvasRenderer] tried to select element before graph ready!`);
      return;
    }
    const element = this.paper.getModelById(id);
    if (!element) {
      return null;
    }
    // const defaults = element.defaults(); // TODO typing!
    if (element.attributes.type === 'sydac.RoundedRectangle') {
      (element as RoundedRectangle).select();
    } else {
      this.logger.warn(`[RuleEditorCanvasRenderer] tried to select invalid element with id ${id}`);
    }
  }

  getBoundedPosition(position: { x: number; y: number }): { x: number; y: number } {
    const area = this.canvasSize;
    const margin = 50;
    const xMaxBound = area.width - this.blockDimensions.width - margin;
    const yMaxBound = area.height - this.blockDimensions.height - margin;
    const x = this.bounded(position.x, margin, xMaxBound);
    const y = this.bounded(position.y, margin, yMaxBound);
    return { x, y };
  }

  getBlockPosition(index: number): { x: number; y: number } {
    // temporary algorithm so blocks don't render on top of each other
    // delete this once we read positions from somewhere
    const area = this.canvasSize;
    const margin = 50;
    const xMaxBound = area.width - this.blockDimensions.width - margin;
    const yMaxBound = area.height - this.blockDimensions.height - margin;
    const xUnbounded = area.width / 2 + (100 + index * (this.blockDimensions.width + 140)); // 100 + i(w + 140)
    const yUnbounded = area.height / 2;
    const x = this.bounded(xUnbounded, margin + 100, xMaxBound);
    const y = this.bounded(yUnbounded, margin + 50, yMaxBound);
    return { x, y };
  }

  /**
   * Returns a bounded number. This belongs in common.
   * 5, 10, 20 -> 10.
   * 5, 0, 10 -> 5.
   * 5, 0, 3 -> 3.
   *
   * @param num the number
   * @param min the min it can be
   * @param max the max it can be
   */
  bounded(num: number, min: number, max: number): number {
    return Math.max(Math.min(num, max), min);
  }

  /**
   * Apply translations to a block dropped at the top left based specified position.
   * Essentially, apply pan and zoom transforms + drop it on center rather than top left.
   *
   * @param x the raw top left position of the dropped block (x)
   * @param y the raw top left position of the dropped block (y)
   */
  public dropBlockAtPosition(x: number, y: number): { x: number; y: number } {
    // Get the inverse of the current transform matrix to go from viewport to SVG coordinates (for the mouse)
    const svgPoint = this.paper.svg.createSVGPoint();
    svgPoint.x = x;
    svgPoint.y = y;
    const position = svgPoint.matrixTransform(this.paper.viewport.getCTM().inverse());
    // drop should be relative to the center of the block, x, y come in as top left
    position.x -= this.blockDimensions.width / 2;
    position.y -= this.blockDimensions.height / 2;
    return position;
  }

  /**
   * the max zoom level is 1 currently but could evolve
   * @returns the max zoom level
   */
  getMaxZoom(): number {
    return 1;
  }

  /**
   * the min zoom level is the smallest of the canvas size divided by the viewport size
   * So that you can see the whole canvas when fully unzoomed
   * @returns the min zoom level
   */
  getMinZoom(): number {
    return Math.min(this.windowSize.width / this.canvasSize.width, this.windowSize.height / this.canvasSize.height);
  }

  /**
   * for the parent component to subscribe and get updates on the zoom level
   * @returns an observable of the zoom updates
   */
  getZoomUpdates$(): Observable<ZoomAvailable> {
    return this.zoomSubject.asObservable();
  }

  /**
   * Allows the parent component to ask for a zoom in
   */
  public zoomIn(): void {
    /**
     * this.panAndZoom.zoomIn(); looks like it is moving the panning towards the bottom right corner
     * the svg zoom is done in the library using a point defined as SvgUtils.getSvgCenterPoint(this.svg, this.width, this.height)
     * ... which is always width/2, height/2 so 5000,5000 right now
     * That means, that we are going towards the bottom right corner, which is not what we want.
     * Instead, calculate the current center point of the viewport and zoom towards that.
     */
    /** The process is:
     * 1. Calculate the current center of the viewport, which is the SVG point
     * 2. Zoom In
     * 3. Calculate the top left corner of the viewport since the center is still the same
     * 4. Place the pan in this top left corner
     *
     * (This basically consists in creating a scale invariant as the center point)
     */
    const centerPointToZoomAt = this.getCenterPointOfViewport(this.panAndZoom.getZoom());
    // The actual zooming in
    this.panAndZoom.zoomIn();
    const svgPointToPlacePan = this.getTopLeftCornerOfTheViewportFromCenter(centerPointToZoomAt, this.panAndZoom.getZoom());
    this.panAndZoom.pan(svgPointToPlacePan);
    this.publishCurrentZoom();
  }

  /**
   * Allows the parent component to ask for a zoom out
   */
  public zoomOut(): void {
    const centerPointToZoomAt = this.getCenterPointOfViewport(this.panAndZoom.getZoom());
    // The actual zooming out
    this.panAndZoom.zoomOut();
    const svgPointToPlacePan = this.getTopLeftCornerOfTheViewportFromCenter(centerPointToZoomAt, this.panAndZoom.getZoom());
    this.panAndZoom.pan(svgPointToPlacePan);
    this.publishCurrentZoom();
  }

  /**
   * Allows the parent component to ask for a zoom to fit
   */
  public zoomToFit(): void {
    // We need to exclude cells that are not rule templates (Like the border elements)
    const cells = this.graph.getCells().filter(cell => cell.attributes.type === 'sydac.RoundedRectangle');
    // This returns the top left corner so it is perfect, that's where we want the view to be
    const bounds = this.graph.getCellsBBox(cells);
    // If you have no blocks, the bounds are null
    if (!bounds) return;
    // Panning is still negative for whatever reason...?
    const svgPointToZoomAt = { x: -bounds.x, y: -bounds.y };
    // Calculate the zoom level needed to see all of the blocks
    // If it is more than 1, cap it at 1
    const zoomLevel = Math.min(Math.min(this.windowSize.width / bounds.width, this.windowSize.height / bounds.height), 1);
    // zoomAtPoint does not seem to be doing anything so ... we do it manually
    // this.panAndZoom.zoomAtPoint(zoomLevel, svgPointToZoomAt);
    // Apply the zoom level and pan to the top left corner
    this.panAndZoom.zoom(zoomLevel);

    // This can be seen as
    // x/zoomLevel (in svg coordinates) = TopLeftCorner (svg coordinates) + DecalToCenter it (width of viewport - width of the bounds) / 2
    // x (in viewport coordinates) = (TopLeftCorner + DecalToCenter) * zoomLevel
    this.panAndZoom.pan({
      x: (svgPointToZoomAt.x + (this.windowSize.width / zoomLevel - bounds.width) / 2) * zoomLevel,
      y: (svgPointToZoomAt.y + (this.windowSize.height / zoomLevel - bounds.height) / 2) * zoomLevel
    });
    this.publishCurrentZoom();
  }

  /**
   * When the user clicks on the top toolbar to switch the panning state
   */
  public switchPanningState(value?: boolean): void {
    if (value === this.allowPanning) return;
    this.allowPanning = value || !this.allowPanning;
    this.publishCurrentPanningState();
  }

  /**
   * For the parent component to subscribe to get the space bar changes
   * @returns an observable of the panning state
   */
  public getPanningUpdate$(): Observable<boolean> {
    return this.panSubject.asObservable();
  }

  private publishCurrentPanningState(): void {
    this.panSubject.next(this.allowPanning);
  }

  /**
   * send the current state of zoom to the zoomSubject
   */
  private publishCurrentZoom(): void {
    // Get zoom returns some really wonky value so we floor or put some buffer for it to work properly
    this.zoomSubject.next({
      canZoomIn: this.panAndZoom.getZoom() <= this.getMaxZoom() - 1e-3,
      canZoomOut: Math.floor(this.panAndZoom.getZoom() * 100) / 100 >= this.getMinZoom()
    });
  }

  private getTopLeftCornerOfTheViewportFromCenter(centerPoint: { x: number; y: number }, zoomLevel: number): { x: number; y: number } {
    const newZoom = this.panAndZoom.getZoom();
    // We get the top left corner of the viewport from the center point
    const topLeftCornerFromCenter = {
      x: -Math.min(this.windowSize.width / (newZoom * 2), this.panAndZoom.getSizes().width / 2),
      y: -Math.min(this.windowSize.height / (newZoom * 2), this.panAndZoom.getSizes().height / 2)
    };

    // The point in the top left corner
    const svgPointToPlacePan = {
      x: centerPoint.x + topLeftCornerFromCenter.x,
      y: centerPoint.y + topLeftCornerFromCenter.y
    };

    // We take the opposite because panning is inverted and apply the zoom level
    svgPointToPlacePan.x *= -1 * newZoom;
    svgPointToPlacePan.y *= -1 * newZoom;

    return svgPointToPlacePan;
  }

  /**
   * Get the current point in the middle of the svg in the svg coordinates
   * @param zoomLevel The current zoom level
   * @returns the point in the center of the viewport
   */
  private getCenterPointOfViewport(zoomLevel: number): { x: number; y: number } {
    // The current point in the middle of the viewport is X
    // The viewport is represented by /---/
    // The panning current location is represented by the o
    // ================
    // |   o---/      |
    // |   / X /      |
    // |   /---/      |
    // |              |
    // |              |
    // ================
    // When you zoom out
    // =======================
    // |   o-------/  |
    // |   /       /  |
    // |   /   x   /  |
    // |   /       /  |
    // |   /-------/  |
    // =======================

    // If the viewport is fully zoomed out, the viewport width is bigger than the canvas one (or the height) depending on your screen orientation/resolution
    // So the center point is the middle of the canvas and we should not add half the viewport width

    /** This is negative as well */
    const topLeftCorner = this.panAndZoom.getPan();
    const centerFromTheTopLeftCorner = {
      x: Math.min(this.windowSize.width / (zoomLevel * 2), this.panAndZoom.getSizes().width / 2),
      y: Math.min(this.windowSize.height / (zoomLevel * 2), this.panAndZoom.getSizes().height / 2)
    };
    return {
      x: -topLeftCorner.x / zoomLevel + centerFromTheTopLeftCorner.x,
      y: -topLeftCorner.y / zoomLevel + centerFromTheTopLeftCorner.y
    };
  }

  private validateConnection(
    cellViewS: dia.CellView,
    magnetS: SVGElement,
    cellViewT: dia.CellView,
    magnetT: SVGElement,
    end: dia.LinkEnd,
    linkView: dia.LinkView
  ): boolean {
    // FIXME there is a bug in here where moving the connection always returns false.
    // need to do some check on end === 'source' to validate this kind of a change.
    // Also need to change output magnets from passive (to allow this validation).
    // for now we get around this by preventing the source from changing via link tools.
    if (cellViewS === cellViewT) {
      return false;
    }
    if (!magnetS || !magnetT) {
      return false;
    }
    if (!(magnetT?.attributes as NamedNodeMap)?.getNamedItem('port')) {
      return false;
    }
    const links = this.graph.getConnectedLinks(cellViewT.model);
    const portId = magnetT?.attributes?.getNamedItem('port')?.value;
    const portGroup = magnetT?.attributes?.getNamedItem('port-group')?.value;
    if (portGroup !== 'in') {
      return false;
    }
    for (const link of links) {
      const source = link.get('source') || {};
      const target = link.get('target') || {};
      if (source.port === portId && source.id === cellViewT.model.id) {
        return false; // source is used
      }
      if (target.port === portId && target.id === cellViewT.model.id) {
        return false; // target is used
      }
    }
    const output = cellViewS?.model?.attributes?.ports?.items?.find((port: any) => port.group === 'out');
    const input = cellViewT?.model?.attributes?.ports?.items?.find((port: any) => port.group === 'in');
    //Case where the source rule block is a variant with no connections
    const typeInputCellViewSource = cellViewS?.model?.attributes?.ports?.items?.find((portTarget: any) => portTarget.group === 'in');
    if(typeInputCellViewSource && typeInputCellViewSource.type === 'variant')
    {
      return true;
    }
    //Case of a rule block destination with variant type input
    //If no connection already exists --> connection ok
    if (input.type === 'variant' && !links)
    {
      return true;
    }
    //If a connection already exists with another block --> look at the port type of the other block
    if (input.type === 'variant' && links)
    {
      //Assign the output port of the source rule block to the variant input
      input.type = output.type;
      input.image = output.image;
      //Accordingly change the output port of this rule block to fit the new input type
      const portOut = cellViewT?.model?.attributes?.ports?.items?.find((port: any) => port.group === 'out');
      portOut.type = input.type;
      portOut.image = input.image;
    }

    //Case of a rule block source with variant type output
    if (output.type === 'variant')
    {
      //Need to check the input of this rule block
      const typeInputCellViewS = cellViewS?.model?.attributes?.ports?.items?.find((portTarget: any) => portTarget.group === 'in');
      if(typeInputCellViewS.type !== input.type && typeInputCellViewS.type !== 'variant')
      {
        return false;
      }
      else if(typeInputCellViewS.type === input.type)
      {
        return true;
      }
    }
    return !!output && !!input && output?.type === input?.type;
  }

  /**
   * Create a border around the canvas using 4 cells
   * I wanted to use css on the svg... Turns out this issue is making me dumb, nothing works so I'm doing it here.
   */
  private createBorderElements(): void {
    const border = new shapes.basic.Rect();
    border.position(0, 20);
    // That's very arbitrary values that just happen to work fine. There is probably a more maths way to do it though.
    border.size(this.canvasSize.width, this.canvasSize.height - 60);
    // Slightly lighter than the outside
    // The stroke is none for now, until someones complains about it
    // Pointer event is none to keep the panning working when on blank space
    border.attr('rect', { 'fill': '#f5f5f5', 'stroke': 'none', 'stroke-width': 1, 'pointer-events': 'none' });
    border.addTo(this.graph);
  }
}
