/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Observable } from 'rxjs';

import { CategoryType, RuleBlock, RuleTemplateConnection } from '@oksygen-sim-train-libraries/components-services/rules';

export interface RuleBlockAddEvent {
  ruleBlock: RuleBlock;
  metaData?: RuleBlockAddEventMeta;
}

export interface RuleBlockAddEventMeta {
  x?: number;
  y?: number;
}

export interface UpdateTemplateBlockPosition {
  blockId: number;
  x: number;
  y: number;
}

// TODO make sure everything references this and make it factory provided!
export interface RuleEditorCanvasRenderer {
  initialiseCanvas(usePanAndZoom?: boolean): void;
  destroy(): void;
  isInitialised(): boolean;
  clearGraph(): void;
  getNode(id: string|number): any; // TODO typing
  getSelectedNode$(): Observable<number>;
  getConnections$(): Observable<RuleTemplateConnection[]>;
  getPositionUpdates$(): Observable<UpdateTemplateBlockPosition>;
  renderNode(id: string|number, text: string, blockName: string, icon: string, category: CategoryType, x: number, y: number): any; // TODO typing
  removeNode(id: string|number): void;
  addInputPortToNode(node: any, id: string, type: string, imgSrc?: string): void; // TODO typing
  addOutputPortToNode(node: any, id: string, type: string, imgSrc?: string): void; // TODO typing
  renderConnection(from: {shape: any; port?: string}, to: {shape: any; port?: string}): any; // TODO typing
  resetStyles(overrideSelection?: boolean): void;
  selectElement(id: string|number): void;
  getBoundedPosition(position: {x: number; y: number}): {x: number; y: number};
  getBlockPosition(index: number): {x: number; y: number};
  dropBlockAtPosition(x: number, y: number): {x: number; y: number};
}

