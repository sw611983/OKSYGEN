/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';
import { CategoryType } from '@oksygen-sim-train-libraries/components-services/rules';
import { dia, shapes } from 'jointjs';

enum ShapeColor {
  ACTION_PORT_IN = '#FF9254',
  SELECTION_PORT_OUT = '#1CADA3',
  CONSTANT = '#008000',
  OPERATION = '#9E54FC',
  ASSESSMENT = '#FF9255',
  ROUNDED_RECTANGLE = 'cornflowerblue'
}

// TS typing for jointjs. Note class definitions MUST match implementation definitions below!
declare module 'jointjs' {
  // eslint-disable-next-line @typescript-eslint/no-namespace, @typescript-eslint/no-shadow
  namespace shapes {
    // eslint-disable-next-line @typescript-eslint/no-namespace
    namespace sydac {
      class RoundedRectangle extends shapes.devs.Model {
        /** Reset styles to their default. */
        resetStyle(overrideSelected?: boolean): void;
        /** Select this node. Will just set various styles to show the selection. */
        select(): void;
        /** Deselect this node. This is safe to call even if not currently selected. */
        deselect(): void;
        /**
         * Returns the circle outline markup to be used for ports.
         * Optionally supply your own radius, fill colour & stroke width.
         *
         * @param radius of the circle (defaults to 15)
         * @param fill colour of the circle (defaults to white)
         * @param strokeWidth width of the outline (defaults to 2)
         */
        getPortOutlineMarkup(radius?: number, fill?: string, strokeWidth?: number): string;
      }

      class SimpleLink extends shapes.standard.Link {
        simpleSource(from: dia.Cell, portId?: string): this;
        simpleTarget(to: dia.Cell, portId?: string): this;
      }
      // any additional classes we need go here :)
    }
  }
}

export class SimpleLink extends shapes.standard.Link {

  constructor(
    // shapes.LinkSelectors not exported by jointjs
    attributes?: dia.Link.GenericAttributes<any/*shapes.LinkSelectors*/>,
    opt?: dia.Graph.Options
  ) {
    super(attributes, opt);
    this.initAttributes();
    this.initEvents();
  }

  connect(from: dia.Cell, to: dia.Cell): this {
    this.simpleSource(from);
    this.simpleTarget(to);
    return this;
  }

  simpleSource(from: dia.Cell, portId?: string): this {
    const port = from.attributes?.ports?.items?.find((item: any) => item.id === portId);
    return super.source(from, {
      id: from.id,
      port: port ? port.id : undefined,
      anchor: {
        name: 'right'
        // padding: 10
      },
      connectionPoint: {
        name: 'anchor'
      }
    });
  }

  simpleTarget(target: dia.Cell, portId?: string): this {
    const port = target.attributes?.ports?.items?.find((item: any) => item.id === portId);
    return super.target(target, {
      id: target.id,
      port: port ? port.id : undefined,
      anchor: {
        name: 'left'
        // padding: { left: -20, right: 0, top: 0, bottom: 0 }
      },
      connectionPoint: {
        name: 'anchor'
      }
    });
  }

  initAttributes(): void {
    this.attributes = {
      ...this.attributes,
      type: 'sydac.SimpleLink',
      router: { name: 'normal', args: { padding: 0, side: 'right' } },
      source: {
        anchor: {
          name: 'right'
        },
        connectionPoint: {
          name: 'anchor'
        }
      },
      target: {
        anchor: {
          name: 'left'
        },
        connectionPoint: {
          name: 'anchor'
        }
      }
    };
    this.connector('jumpover', { size: 10 });
  }

  private initEvents(): void {
    this.on('change:source', (child: SimpleLink, pos) => {
      const sourceElement = child.getSourceElement();
      if (sourceElement) {
        child.source(sourceElement, {
          ...child.attributes.source,
          anchor: {
            name: 'right'
          },
          connectionPoint: {
            name: 'anchor'
          }
        });
      }
    });
    this.on('change:target', (child: SimpleLink, pos) => {
      const targetElement = child.getTargetElement();
      if (targetElement) {
        child.target(targetElement, {
          ...child.attributes.target,
          anchor: {
            name: 'left'
          },
          connectionPoint: {
            name: 'anchor'
          }
        });
      }
    });
  }
}

// eslint-disable-next-line import/no-deprecated
export class RoundedRectangle extends shapes.devs.Model {

  // Selector is how we refer to it in TS, tagName is the generated HTML tag.
  override markup = [{
    tagName: 'rect',
    selector: 'body'
    }, {
    tagName: 'text',
    selector: 'label'
    }, {
    tagName: 'svg',
    selector: 'image',
    children: [{
      tagName: 'use',
      selector: 'svgChild'
    }]
  }];
  portMarkup = '';

  constructor(private category: CategoryType, attributes?: shapes.devs.ModelAttributes, opt?: { [key: string]: any })
  {
    super(attributes, opt);
    this.initAttributes();
  }

  override addInPort(port: string, opt?: any): this {
    const existingPorts = this.attributes?.ports?.items ?? [];
    super.addInPort(port, opt);
    this.attributes?.ports?.items?.forEach((item: any) => {
      const oldPort = existingPorts.find((p: any) => p.id === item.id);
      if (oldPort) {
        Object.assign(item, oldPort);
        this.portProp(item.id, 'attrs/.port-label/text', '');
      }
    });
    return this;
  }

  override addOutPort(port: string, opt?: any): this {
    const existingPorts = this.attributes?.ports?.items ?? [];
    super.addOutPort(port, opt);
    this.attributes?.ports?.items?.forEach((item: any) => {
      const oldPort = existingPorts.find((p: any) => p.id === item.id);
      if (oldPort) {
        Object.assign(item, oldPort);
        this.portProp(item.id, 'attrs/.port-label/text', '');
      }
    });
    return this;
  }

  resetStyle(overrideSelected?: boolean): void {
    const d = this.defaults();
    const isSelected = this.attr('body/stroke') === d.selectedAttrs.body.stroke;
    this.changeInGroup(d.ports.groups.in);
    this.changeOutGroup(d.ports.groups.out);
    this.attr('body/fill', d.attrs.body.fill);
    if (isSelected && !overrideSelected) { return; } // remaining styles already applied if this is selected
    this.attr('body/strokeWidth', d.attrs.body.strokeWidth);
    let color: string;
    if(this.category === 'constant') {
      color = d.constantAttrs.stroke;
    } else if(this.category === 'operation') {
      color = d.operationAttrs.stroke;
    } else if(this.category === 'action') {
      color = d.actionAttrs.stroke;
    }  else if(this.category === 'selection') {
      color = d.selectionAttrs.stroke;
    } else if(this.category === 'assessment') {
      color = d.assessmentAttrs.stroke;
    }
    this.attr('body/stroke', color);
    this.attr('image/color', color);

    this.getPorts().forEach(p => {
      this.portProp(p.id, 'attrs/.port-icon/color', color);
      this.portProp(p.id, 'attrs/.port-outline/stroke', color);
    });
  }

  deselect(): void {
    this.resetStyle(true);
  }

  select(): void {
    const defaults = this.defaults();
    const outlineColor = defaults.selectedAttrs.body.stroke;
    this.attr('body/stroke', defaults.selectedAttrs.body.stroke);
    this.attr('body/strokeWidth', defaults.selectedAttrs.body.strokeWidth);
    this.attr('image/color', defaults.selectedAttrs.image.color);
    this.getPorts().forEach(p => {
      this.portProp(p.id, 'attrs/.port-icon/color', outlineColor);
      this.portProp(p.id, 'attrs/.port-outline/stroke', outlineColor);
    });
  }

  initAttributes(): void {
    this.attributes = {
      ...this.attributes,
      type: 'sydac.RoundedRectangle', // must match the Object.assign + declare defs below!
      size: { width: 200, height: 100 },
      selectedAttrs: {
        body: {
          stroke: ShapeColor.ROUNDED_RECTANGLE,
          strokeWidth: 4
        },
        image: {
          color: ShapeColor.ROUNDED_RECTANGLE
        }
      },
      // These colors must match the ones in 1) shapes.ts(defaults()) 2) rule-editor-blocks-panel-block.component.ts(findBlockType())
      // 3) rule-editor-blocks-panel-block.component.scss!!!
      selectionAttrs: {
        stroke: ShapeColor.SELECTION_PORT_OUT
      },
      constantAttrs: {
        stroke: ShapeColor.CONSTANT
      },
      operationAttrs: {
        stroke: ShapeColor.OPERATION
      },
      actionAttrs: {
        stroke: ShapeColor.ACTION_PORT_IN
      },
      assessmentAttrs: {
        stroke: ShapeColor.ASSESSMENT
      },
      ports: {
        groups: {
          in: {
            attrs: {
              '.port-icon': { color: ShapeColor.ACTION_PORT_IN },
              '.port-outline': { refR: '15px', stroke: ShapeColor.ACTION_PORT_IN, fill: ThemeColorHex.WHITE },
              '.joint-port-body': { magnet: 'passive' }
            }
          },
          out: {
            attrs: {
              '.port-icon': { color: ShapeColor.SELECTION_PORT_OUT },
              '.port-outline': { refR: '15px', stroke: ShapeColor.SELECTION_PORT_OUT, fill: ThemeColorHex.WHITE },
              '.joint-port-body': { magnet: 'active' }
            }
          }
        },
        items: [] as any[]
      },
      attrs: {
        body: {
          rx: 10,
          ry: 10,
          refWidth: '100%',
          refHeight: '100%',
          strokeWidth: 2,
          fill: ThemeColorHex.WHITE
          // magnet: false
        },
        label: {
          textVerticalAnchor: 'middle',
          textAnchor: 'middle',
          refX: '50%',
          refY: '70%',
          fill: ThemeColorHex.BLACK
          // magnet: false
        },

        image: { width: 200, height: 200 },
        svgChild: { refX: '0%', refY: '10%', width: 200, height: 40}
      }
    };
  }

  // is there a way to explicitly say "same type as super.defaults - ReturnType only seems to work for functions not methods.."
  // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
  override defaults() {
    return {
      ...super.defaults,
      type: 'sydac.RoundedRectangle', // must match the Object.assign + declare defs below!
      size: { width: 200, height: 100 },
      selectedAttrs: {
        body: {
          stroke: ShapeColor.ROUNDED_RECTANGLE,
          strokeWidth: 4
        },
        image: {
          color: ShapeColor.ROUNDED_RECTANGLE
        }
      },
      // These colors must match the ones in 1) shapes.ts(initAttributes()) 2) rule-editor-blocks-panel-block.component.ts(findBlockType())
      // 3) rule-editor-blocks-panel-block.component.scss!!!
      selectionAttrs: {
        stroke: ShapeColor.SELECTION_PORT_OUT
      },
      constantAttrs: {
        stroke: ShapeColor.CONSTANT
      },
      operationAttrs: {
        stroke: ShapeColor.OPERATION
      },
      actionAttrs: {
        stroke: ShapeColor.ACTION_PORT_IN
      },
      assessmentAttrs: {
        stroke: ShapeColor.ASSESSMENT
      },
      ports: {
        groups: {
          in: {
            attrs: {
              '.port-icon': { color: ShapeColor.ACTION_PORT_IN },
              '.port-outline': { refR: '15px', stroke: ShapeColor.ACTION_PORT_IN, fill: ThemeColorHex.WHITE },
              '.joint-port-body': { magnet: 'passive' }
            }
          },
          out: {
            attrs: {
              '.port-icon': { color: ShapeColor.SELECTION_PORT_OUT },
              '.port-outline': { refR: '15px', stroke: ShapeColor.SELECTION_PORT_OUT, fill: ThemeColorHex.WHITE },
              '.joint-port-body': { magnet: 'active' }
            }
          }
        },
        items: [] as any[]
      },
      attrs: {
        body: {
          rx: 10,
          ry: 10,
          refWidth: '100%',
          refHeight: '100%',
          strokeWidth: 2,
          fill: ThemeColorHex.WHITE
          // magnet: false
        },
        label: {
          textVerticalAnchor: 'middle',
          textAnchor: 'middle',
          userSelect: 'none',
          refX: '50%',
          refY: '50%',
          fill: ThemeColorHex.BLACK
          // magnet: false
        },
        image: { width: 200, height: 200 },
        svgChild: { refX: '0%', refY: '10%', width: 200, height: 40}
      }
    };
  }

  getPortOutlineMarkup(radius = 15, fill = ThemeColorHex.WHITE, strokeWidth = 2): string {
    return `<circle class="port-outline" fill="${fill}" stroke-width="${strokeWidth}" r="${radius}" x="-${radius}px" y="-${radius}px" />`;
  }
}

// who doesn't like a library that requires you to modify it's global internal structure (:
// make our custom shapes available via the jointjs.shapes.sydac namespace
Object.assign(shapes, {
  sydac: {
    RoundedRectangle,
    SimpleLink
  }
});
