/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainRuleEditModule } from '../../rule-edit.module';
import { RuleEditorContextPublisher } from '../../services/rule-editor-context.publisher';

import { RuleEditorCanvasComponent } from './rule-editor-canvas.component';

describe('RuleEditorCanvasComponent', () => {
  let component: RuleEditorCanvasComponent;
  let fixture: ComponentFixture<RuleEditorCanvasComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainRuleEditModule],
      declarations: [RuleEditorCanvasComponent],
      providers: [ RuleEditorContextPublisher, {provide: ContextSupplier, useClass: RuleEditorContextPublisher}]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleEditorCanvasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
