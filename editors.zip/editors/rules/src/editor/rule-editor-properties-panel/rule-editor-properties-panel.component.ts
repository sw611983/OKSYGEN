/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { AbstractControl, UntypedFormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { FloatLabelType, MatFormFieldAppearance } from '@angular/material/form-field';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Observable, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map, tap } from 'rxjs/operators';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import {
  AutocompleteInputType,
  errorStateMatcher,
  illegalNameCharacterExists,
  newFormControl,
  newOptionalFormControl,
  quietUpdateOptions,
  UpdateOn
} from '@oksygen-common-libraries/material/components';
import {
  getPropertyDataEntryType,
  PropertyUpdate,
  RuleBlock,
  RuleBlockPropertyConstraintService,
  RuleBlockPropertyDataType,
  RuleEditorRuleBlockProperty,
  RulePropertyAllowedValues,
  RuleTemplateRuleBlock,
  RuleTemplateService
} from '@oksygen-sim-train-libraries/components-services/rules';

import { filterOldVersions } from '../../helpers/rules-filter';
import { SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

interface SelectedTemplateBlock {
  templateBlock: RuleTemplateRuleBlock;
  ruleBlock: RuleBlock;
}

interface BlockPropertyUi {
  name: string;
  value: any;
  displayName: string;
  dataType: RuleBlockPropertyDataType;
  defaultValue: string | number | boolean;
  formControl: UntypedFormControl;
  enabled: boolean;
  allowedValues?: RulePropertyAllowedValues;
  inputFormControl?: UntypedFormControl;
  subscription?: Subscription;
  defaultUnits?: string;
}

@Component({
  selector: 'oksygen-rule-editor-properties-panel',
  templateUrl: './rule-editor-properties-panel.component.html',
  styleUrls: ['./rule-editor-properties-panel.component.scss']
})
export class RuleEditorPropertiesPanelComponent implements OnInit, OnChanges, OnDestroy {
  @Input() block: SelectedTemplateBlock;
  @Input() templateName: string;
  @Input() templateDescription: string;
  @Input() originalTemplateName: string;
  @Input() editable: boolean;
  @Input() triggerFormValidation$?: Observable<void>;
  @Output() readonly back = new EventEmitter<void>();
  @Output() readonly nameUpdated = new EventEmitter<string>();
  @Output() readonly descriptionUpdated = new EventEmitter<string>();
  @Output() readonly blockNameUpdated = new EventEmitter<{ blockId: number; name: string }>();
  @Output() readonly blockDescriptionUpdated = new EventEmitter<{ blockId: number; description: string }>();
  @Output() readonly blockPropertiesUpdated = new EventEmitter<{ blockId: number; updates: PropertyUpdate[] }>();
  @Output() readonly disableSave = new EventEmitter<boolean>();

  templateNameControl: UntypedFormControl;
  templateDescriptionControl = newOptionalFormControl();
  blockNameControl = newFormControl();
  blockDescriptionControl = newOptionalFormControl();
  properties: BlockPropertyUi[] = [];
  breadcrumbChildren: ReadonlyArray<string>;
  autoCompleteType = AutocompleteInputType.FORM_FIELD;
  appearance: MatFormFieldAppearance = 'outline';
  floatLabel: FloatLabelType = 'always';
  sortBy: (a: SimPropertyState, b: SimPropertyState) => number;

  matcher = errorStateMatcher;

  private subscription = new Subscription();
  private blockNameSubscription = new Subscription();
  private blockDescriptionSubscription = new Subscription();
  private existingRuleTemplateNames: string[] = [];
  private readonly formDebounceTime = 750;

  private nameError = false;

  constructor(
    translate: TranslateService,
    private ruleTemplateService: RuleTemplateService,
    private constraints: RuleBlockPropertyConstraintService<RuleEditorRuleBlockProperty>
  ) {
    this.templateNameControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null =>
      this.validateRuleTemplateName(control.value)
    );
    this.sortBy = (a: SimPropertyState, b: SimPropertyState): number => {
      // TODO need to make our options for sorting shared across everything; see INTOSC-7244
      // Note that sensible settings for these options are very closely related to the language being used.
      const sortingOptions: Intl.CollatorOptions = { sensitivity: 'base', numeric: true };
      return a.displayName.localeCompare(b.displayName, translate.currentLocaleString, sortingOptions);
    };
  }

  ngOnInit(): void {
    const ruleTemplateSub = this.ruleTemplateService.data().subscribe(templates => {
      this.existingRuleTemplateNames = templates?.map(tmp => tmp.displayName) || [];
      // We're first reducing the array to only get the latest version for each template.
      this.existingRuleTemplateNames = filterOldVersions(templates).map(tmp => tmp.displayName) || [];
    });

    this.initialiseFormListeners();
    this.subscription.add(ruleTemplateSub);

    this.subscription.add(
      this.triggerFormValidation$?.subscribe(() => {
        if (this.editable) {
          this.templateNameControl.markAsTouched();
          this.templateDescriptionControl.markAsTouched();
        }
      })
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    const currentBlock = changes.block?.currentValue;
    const previousBlock = changes.block?.previousValue;
    if (currentBlock?.templateBlock?.id !== previousBlock?.templateBlock?.id) {
      this.onBlockChange(changes);
      this.blockNameControl.setValue(currentBlock?.templateBlock?.displayName ?? '', quietUpdateOptions);
      this.blockDescriptionControl.setValue(currentBlock?.templateBlock?.displayDescription ?? '', quietUpdateOptions);
        this.cleanupProperties();
        this.initialiseBlockFormListeners();
        this.generateProperties();
        this.setBreadcrumbs();
    }
    if (changes.templateName?.currentValue !== changes.templateName?.previousValue) {
      this.templateNameControl.setValue(this.templateName ?? '', quietUpdateOptions);
    }
    if (changes.templateDescription?.currentValue !== changes.templateDescription?.previousValue) {
      this.templateDescriptionControl.setValue(this.templateDescription ?? '', quietUpdateOptions);
    }
    if (
      currentBlock?.templateBlock?.properties &&
      previousBlock?.templateBlock?.properties &&
      currentBlock.templateBlock.properties !== previousBlock.templateBlock.properties
    ) {
      this.generateProperties();
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.cleanupProperties();
  }

  // FIXME add this to common. This may exist somewhere in vanilla JS somewhere..
  /**
   * configurable method to check if a value is truthy.
   * Can set whether you want to check for 0s and ''s.
   * (1) => true, (0, true) => true, (0, false) => false, etc.
   * @param val the value to check
   * @param zeroValid if true, then 0s should be considered truthy
   * @param emptyStringValid if true, empty strings should be considered truthy
   */
  isTruthy(val: any, zeroValid?: boolean, emptyStringValid?: boolean): boolean {
    const notNull = val !== undefined && val !== null;
    const passZeroCheck = val === 0 ? zeroValid : true;
    const passEmptyStringCheck = val === '' ? emptyStringValid : true;
    return notNull && passZeroCheck && passEmptyStringCheck;
  }

  onBack(): void {
    this.back.emit();
  }

  displayValue(prop: SimPropertyState | string | number): string {
    // if prop is a primitive return it, else try displayName, else name else ''.
    return typeof prop === 'string' || typeof prop === 'number' ? `${prop}` : prop?.displayName ?? prop?.name ?? '';
  }

  restrictNegativeNumbers(event: KeyboardEvent): void {
    if (event.key === '-' || event.key === 'e' || event.key === '+') {
      event.preventDefault();
    }
  }

  valueSelected(property: BlockPropertyUi, value: string | number | boolean, blockId?: number): void {
    if (value === undefined) {
      return;
    }
    const v = (typeof value === 'object' ? (value as any)?.value : value) ?? '';
    const updates = this.constraints.updateProperty(this.block, property.name, v);
    this.blockPropertiesUpdated.emit({ blockId: typeof blockId === 'number' ? blockId : this.block.templateBlock.id, updates });
    // note that name is display name, but type is the actual name (yes, this is confusing)
    // this.blockPropertiesUpdated.emit({name: property.name, value});
  }

  private initialiseFormListeners(): void {
    const nameSub = this.templateNameControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(value => {
      this.nameUpdated.emit(value);
    });
    const descriptionSub = this.templateDescriptionControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(value => {
      this.descriptionUpdated.emit(value);
    });
    this.subscription.add(nameSub);
    this.subscription.add(descriptionSub);
  }

  private initialiseBlockFormListeners(): void {
    // nothing to initalise
    if (!this.block) {
      return;
    }
    this.blockNameSubscription?.unsubscribe();
    this.blockDescriptionSubscription?.unsubscribe();
    this.blockNameSubscription = this.blockNameControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(value => {
      this.blockNameUpdated.emit({ blockId: this.block.templateBlock.id, name: value });
    });
    this.blockDescriptionSubscription = this.blockDescriptionControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(value => {
      this.blockDescriptionUpdated.emit({ blockId: this.block.templateBlock.id, description: value });
    });
  }

  private onBlockChange(changes: SimpleChanges): void {
    /**
     * Our form listeners are debounced because we don't want to emit a new value for every key press - hence we wait for the user to stop typing.
     * This means that a user can stop typing and immediately select another block.
     * If this happens, we get the field update for the old block with the new block selected, so it will try to update the new block with that old block value.
     * To prevent this on block change we must kill our listeners and emit their current values if they're holding onto an update.
     */
    // there are no values to emit if there was no block selected
    if (!changes?.block?.previousValue) {
      return;
    }
    this.blockNameSubscription?.unsubscribe();
    this.blockDescriptionSubscription?.unsubscribe();
    const previousBlock: SelectedTemplateBlock = changes.block.previousValue;
    const blockName = this.blockNameControl.value;
    const blockDescription = this.blockDescriptionControl.value;
    const oldBlockName = previousBlock?.templateBlock?.displayName;
    const oldBlockDescription = previousBlock?.templateBlock?.displayDescription;
    if (blockName !== oldBlockName) {
      this.blockNameUpdated.emit({ blockId: previousBlock.templateBlock.id, name: blockName });
    }
    if (blockDescription !== oldBlockDescription) {
      this.blockDescriptionUpdated.emit({ blockId: previousBlock.templateBlock.id, description: blockDescription });
    }
    this.properties?.forEach(p => {
      const propValue = p.formControl.value;
      const validatedNewValue = typeof propValue?.value === 'object' ? (propValue.value as any)?.value : propValue?.value;
      const oldValue = p.value;
      if (validatedNewValue !== oldValue) {
        this.valueSelected(p, propValue, previousBlock.templateBlock.id);
      }
    });
    this.cleanupProperties();
  }

  private generateProperties(): void {
    this.constraints
      .generatePropertyList(this.block?.templateBlock)
      .pipe(
        takeOneTruthy(),
        map(properties => this.transformProperties(properties)),
        tap(properties => this.initialiseBlockPropertyListeners(properties)),
        tap(properties => (this.properties = properties))
      )
      .subscribe();
  }

  private validateRuleTemplateName(name: string): ValidationErrors {
    let result: ValidationErrors = null;
    if (name) {
      const nameInUse = this.existingRuleTemplateNames.includes(name);
      if (nameInUse && name !== this.originalTemplateName) {
        result = { exists: true };
      } else if (name?.trim() !== name) {
        result = { spacesError: true };
      } else if (illegalNameCharacterExists(name)) {
        result = { specialCharacterError: true };
      }
    } else {
      result = { missing: true };
    }

    this.nameError = result != null;
    this.tryDisableSave();
    return result;
  }

  private setBreadcrumbs(): void {
    if (this.block) {
      this.breadcrumbChildren = [t(this.block.ruleBlock.displayName)];
    } else {
      this.breadcrumbChildren = null;
    }
  }

  /**
   * Reset our list of template properties and unsubscribe from all the old form controls.
   * This should be generally be called when we change templates select a new block.
   */
  private cleanupProperties(): void {
    if (!this.properties?.length) {
      return;
    }
    for (const prop of this.properties) {
      prop.subscription?.unsubscribe();
    }
    this.properties = [];
  }

  private initialiseBlockPropertyListeners(properties: BlockPropertyUi[]): void {
    if (!properties?.length) {
      return;
    }
    for (const prop of properties) {
      if (!prop.subscription && prop.dataType !== 'list') {
        prop.subscription = prop.formControl.valueChanges
          .pipe(
            distinctUntilChanged(),
            debounceTime(this.formDebounceTime),
            filter(newValue => {
              const existingProperty = this.properties.find(cp => cp.name === prop.name);
              // property seems to be frozen - has original object state not updated "property"
              // hence, have to get updated property value to work with here.
              // if the newest version now has allowedValues, we need to unsubscribe.
              if (!existingProperty || existingProperty.allowedValues) {
                prop.subscription?.unsubscribe();
                existingProperty?.subscription?.unsubscribe();
                prop.subscription = undefined;
                if (existingProperty) {
                  existingProperty.subscription = undefined;
                }
                return false;
              }
              return true;
            }),
            filter(newValue => prop.formControl.valid)
          )
          .subscribe(newValue => {
            this.valueSelected(prop, newValue);
          });
      }
    }
  }

  private transformProperties(properties: RuleEditorRuleBlockProperty[]): BlockPropertyUi[] {
    properties?.forEach(property => {
      const oldPropertyIndex = this.properties?.findIndex(p => p.name === property.name);
      const oldProperty = oldPropertyIndex >= 0 ? this.properties[oldPropertyIndex] : null;
      const transform = this.transformProperty(property, oldProperty);
      if (!oldProperty) {
        this.properties.push(transform);
      }
    });
    return this.properties;
  }

  private transformProperty(property: RuleEditorRuleBlockProperty, existingProperty: BlockPropertyUi): BlockPropertyUi {
    const formControl = existingProperty?.formControl ?? newOptionalFormControl(); // TODO form control typing
    const inputFormControl = existingProperty?.inputFormControl ?? newOptionalFormControl(); // TODO form control typing

    // const nullMessage = '';
    // this.isTruthy(property.value, true) ? property.value: nullMessage;
    let value;
    if (property.allowedValues) {
      value =
        property.allowedValues?.displayedValues?.find(v => v.value === property.value) ??
        property.allowedValues?.displayedValues?.find(v => v.value === property.defaultValue) ??
        property.defaultValue;
    } else {
      value = property.value ?? property.defaultValue;
    }

    formControl.setValue(value, quietUpdateOptions);
    inputFormControl.setValue(value, quietUpdateOptions);
    formControl.setValidators(this.propertyValueValidator(property));
    inputFormControl.setValidators(this.propertyValueValidator(property));
    if (!existingProperty) {
      inputFormControl.markAsTouched(); // we want to show error immediately if blank
      inputFormControl.markAsTouched(); // we want to show error immediately if blank
    }
    const displayName = property?.displayName ?? property.name;
    const prop: BlockPropertyUi = existingProperty
      ? Object.assign(existingProperty, {
          displayName,
          defaultValue: property.defaultValue,
          value: property.value,
          allowedValues: property.allowedValues,
          dataType: property.allowedValues ? 'list' : getPropertyDataEntryType(property.type as any),
          enabled: property.enabled,
          defaultUnits: property.defaultUnits
        })
      : {
          displayName,
          defaultValue: property.defaultValue,
          name: property.name,
          value: property.value,
          allowedValues: property.allowedValues,
          dataType: property.allowedValues ? 'list' : getPropertyDataEntryType(property.type as any),
          enabled: property.enabled,
          formControl,
          inputFormControl,
          defaultUnits: property.defaultUnits
        };
    return prop;
  }

  /**
   * Validate user input against our list of allowed values for that property.
   *
   * @param property the property to validate against
   */
  propertyValueValidator(property: RuleEditorRuleBlockProperty): ValidatorFn {
    // return null = no errors, return obj = obj of error messages
    return (control: AbstractControl): ValidationErrors | null => {
      if (property.errorMessage) {
        return { hasError: property.errorMessage };
      }
      // if allowed values is set, validate against it
      // const notBlank = control.value !== null && control.value !== undefined && control.value !== '';
      if (Array.isArray(property.allowedValues?.displayedValues) && property.allowedValues.displayedValues.length > 0) {
        const isAllowed = this.isValidDisplayValue(property, control.value);
        return isAllowed ? null : { forbiddenName: { value: control.value?.value || control.value } };
      } else {
        return null;
      }
    };
  }

  /**
   * Validate a value against it's definition. Note that blank is also valid.
   *
   * @param property the property definition to check
   * @param value the value we're checking
   */
  private isValidDisplayValue(property: RuleEditorRuleBlockProperty, value: any): boolean {
    return (
      !value ||
      !!property.allowedValues.displayedValues.find(
        p =>
          // FIXME this whole autocomplete interaction isn't quite right..
          p.value === value?.value ||
          p.value === value ||
          p.displayName === value?.value ||
          p.displayName === value ||
          (typeof value === 'number' && (p.value === value.toString() || p.displayName === value.toString()))
      )
    );
  }

  private tryDisableSave(): void {
    this.disableSave.emit(this.nameError);
  }

  /**
   * Resets the property to its default values.
   *
   * @param prop
   *        the property
   */
  resetProperties(prop: BlockPropertyUi): void {
    const value = prop.allowedValues ? prop.allowedValues?.displayedValues?.find(v => v.value === prop.defaultValue) : prop.defaultValue;
    prop.formControl.setValue(value);
    this.valueSelected(prop, prop.defaultValue);
  }
}
