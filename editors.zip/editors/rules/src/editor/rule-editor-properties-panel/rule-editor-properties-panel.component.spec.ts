/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { OksygenSimTrainRuleEditModule } from '../../rule-edit.module';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { RuleEditorPropertiesPanelComponent } from './rule-editor-properties-panel.component';
import { DataAccessWebService } from '@oksygen-common-libraries/data-access/web';
import { SIM_PROPERTIES_DATA_ACCESS_SERVICE_TOKEN } from '@oksygen-sim-train-libraries/components-services/sim-properties';

describe('RuleEditorPropertiesPanelComponent', () => {
  let component: RuleEditorPropertiesPanelComponent;
  let fixture: ComponentFixture<RuleEditorPropertiesPanelComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainRuleEditModule],
      declarations: [RuleEditorPropertiesPanelComponent],
      providers: [
        DataAccessWebService,
        {
          provide: SIM_PROPERTIES_DATA_ACCESS_SERVICE_TOKEN,
          useExisting: DataAccessWebService
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleEditorPropertiesPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
