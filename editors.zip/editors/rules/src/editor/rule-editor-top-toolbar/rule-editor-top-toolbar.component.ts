/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { Version, versionCompare, versionLatest } from '@oksygen-sim-train-libraries/components-services/versioning';
import { Observable } from 'rxjs';

@Component({
  selector: 'oksygen-rule-editor-top-toolbar',
  templateUrl: './rule-editor-top-toolbar.component.html',
  styleUrls: ['./rule-editor-top-toolbar.component.scss']
})
export class RuleEditorTopToolbarComponent implements  OnChanges {

  @Input() version: Version;
  @Input() versions: Version[];
  @Input() status: 'Draft'|'Published';
  @Input() canDelete = true;
  @Input() editable = true;
  @Input() canUndo$: Observable<boolean>;
  @Input() canRedo$: Observable<boolean>;
  @Input() disableSave: boolean;

  @Input() canZoomIn = true;
  @Input() canZoomOut = true;
  @Input() canZoomToFit = true;
  @Input() canPan = true;
  @Input() panningActivated = true;

  @Output() readonly save = new EventEmitter();
  @Output() readonly undo = new EventEmitter();
  @Output() readonly redo = new EventEmitter();
  @Output() readonly versionChange = new EventEmitter<Version>();
  @Output('delete') readonly deleteEmit = new EventEmitter();

  @Output() readonly zoomIn = new EventEmitter();
  @Output() readonly zoomOut = new EventEmitter();
  @Output() readonly zoomToFit = new EventEmitter();
  @Output() readonly handTool = new EventEmitter();

  isLatest = false;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.version || changes.versions) {
      this.isLatestVersion(this.version, this.versions);
    }
  }

  private isLatestVersion(version: Version, versions: Version[]): void {
    this.isLatest = versionCompare(version, versionLatest(versions)) >= 0;
  }

}
