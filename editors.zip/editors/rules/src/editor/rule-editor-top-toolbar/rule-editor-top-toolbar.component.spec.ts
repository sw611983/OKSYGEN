/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { OksygenSimTrainRuleEditModule } from '../../rule-edit.module';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { RuleEditorTopToolbarComponent } from './rule-editor-top-toolbar.component';
import { ToolbarComponent } from '@oksygen-sim-train-libraries/components-services/common';

describe('RuleEditorTopToolbarComponent', () => {
  let component: RuleEditorTopToolbarComponent;
  let fixture: ComponentFixture<RuleEditorTopToolbarComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainRuleEditModule],
      declarations: [RuleEditorTopToolbarComponent, ToolbarComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleEditorTopToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
