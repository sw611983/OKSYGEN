/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Input, OnDestroy, OnInit } from '@angular/core';

import { allFilterTypesMatch, Filter, filterMatches, SelectedFilterArray, Sorter, SorterPipe } from '@oksygen-common-libraries/material/components';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { RuleBlock, RuleBlockService } from '@oksygen-sim-train-libraries/components-services/rules';

import { RuleEditorFilterType, RuleEditorUiState } from '../../models/rule-editor.model';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { forkJoin, map, Observable, Subscription } from 'rxjs';

@Component({
  selector: 'oksygen-rule-editor-blocks-panel',
  templateUrl: './rule-editor-blocks-panel.component.html',
  styleUrls: ['./rule-editor-blocks-panel.component.scss']
})
export class RuleEditorBlocksPanelComponent implements OnInit, OnDestroy {
  // The sorter used to sort the rules. Will use the displayName of the rule.
  sorter = new Sorter<RuleBlock>();
  // The current state of the UI, "persistent".
  state: RuleEditorUiState;
  currentLang = this.translateService.currentLang;

  // The filtered rules, grouped by category.
  filteredRuleBlocks: Map<string, RuleBlock[]> = new Map<string, RuleBlock[]>();
  filterCategories: string[] = [];

  private sorterPipe = new SorterPipe();
  private langChangeSubscription: Subscription;

  @Input() blocks: RuleBlock[];
  private readonly subscriptions = new Subscription();

  constructor(private uiStateModelManager: UiStateModelManager, private translateService: TranslateService, private ruleBlockService: RuleBlockService) {
    this.sorter.sortFunction = (c, a, b): number => a?.displayName?.localeCompare(b?.displayName, this.currentLang);
  }

  textToFilter = (text: string): Filter<string> => new Filter(RuleEditorFilterType.NAME, text);

  ngOnInit(): void {
    this.currentLang = this.normalizeLocale(this.translateService.currentLang || 'en');
    this.filterCategories = this.ruleBlockService.getRuleBlockCategoryNames().filter((item, index, self) => self.indexOf(item) === index);
    this.state = this.retrieveUiState();

    this.applyFilterTo(this.blocks).subscribe((filteredMap: Map<string, RuleBlock[]>) => {
  this.filteredRuleBlocks = filteredMap;
});

    this.langChangeSubscription = this.translateService.onLangChange.subscribe(event => {
      this.currentLang = this.normalizeLocale(event.lang);
      this.sorter.sortFunction = (c, a, b): number => a?.displayName?.localeCompare(b?.displayName, this.currentLang);
      this.applyFilterTo(this.blocks).subscribe((filteredMap: Map<string, RuleBlock[]>) => {
  this.filteredRuleBlocks = filteredMap;
});
    });

    this.applyFilters();
  }

  ngOnDestroy(): void {
    this.langChangeSubscription?.unsubscribe();
    this.subscriptions.unsubscribe();
  }

  private normalizeLocale(locale: string): string {
    return locale.replace('_', '-').replace(/-[a-z]{2}$/, m => m.toUpperCase());
  }

  /**
   * Called when the user updates the text in the search bar.
   * @param text The text to filter the rules by.
   */
  onCurrentValueUpdate(text: string): void {
    this.state.filters.search = text;
    this.applyFilters();
  }

  /**
   * Called when the user clicks on a filter chip, in the material menu to the left of the search bar.
   * @param category The category to filter the rules by.
   */
  filterByCategory(category: string): void {
    this.state.filters.selectedFilters.push(new Filter(RuleEditorFilterType.CATEGORY, category));
    this.applyFilters();
  }

  /**
   * Apply the filters to the rules.
   */
  applyFilters(): void {
    this.applyFilterTo(this.blocks).subscribe((filteredMap: Map<string, RuleBlock[]>) => {
  this.filteredRuleBlocks = filteredMap;
});
  }

  /**
   * Called when the user clicks on the "Show All" button. Clears every filters.
   */
  clearFilters(): void {
    this.state.filters.search = '';
    this.state.filters.selectedFilters = new SelectedFilterArray<RuleEditorFilterType>();
    this.applyFilterTo(this.blocks).subscribe((filteredMap: Map<string, RuleBlock[]>) => {
  this.filteredRuleBlocks = filteredMap;
});
  }

  /**
   * Called when the user clicks on the "Sort" button. Toggles the sort order internally, so we just need to apply filters again to refresh the UI.
   */
  sortToggled(): void {
    this.sorter.sortFunction = (c, a, b): number => a?.displayName?.localeCompare(b?.displayName, this.currentLang);
    this.applyFilters();
  }

  /**
   * Apply the filters to the given blocks. First check for the selected filters, then the search bar.
   * @param blocks The blocks to filter.
   * @returns The filtered blocks, grouped by category in a Map, with category as the key.
   */
  private applyFilterTo(blocks: RuleBlock[]): Observable<Map<string, RuleBlock[]>> {
    if (!blocks || blocks.length === 0) {
      return new Observable(observer => {
        observer.next(new Map<string, RuleBlock[]>());
        observer.complete();
      });
    }

    const clonedBlocks: RuleBlock[] = blocks.map(rule => ({ ...rule }));

    const translationObservables = clonedBlocks.map(rule => this.translateService.get(rule.displayName));

    return forkJoin(translationObservables).pipe(
      map((translations: string[]) => {
        translations.forEach((translated, index) => {
          clonedBlocks[index].displayName = translated;
        });

        let filteredRules = clonedBlocks.filter(rule => {
          const name = [rule.displayName];

          if (
            !allFilterTypesMatch(
              [
                { t: RuleEditorFilterType.NAME, v: name },
                { t: RuleEditorFilterType.CATEGORY, v: rule.category }
              ],
              this.state.filters.selectedFilters
            )
          ) {
            return false;
          }

          if (!filterMatches(name, this.state.filters.search)) {
            return false;
          }

          return true;
        });

        filteredRules = this.sorterPipe.transform(filteredRules, this.sorter, this.sorter.refresh);

        const filteredRulesByCategory = new Map<string, RuleBlock[]>();
        for (const category of this.filterCategories) {
          filteredRulesByCategory.set(
            category,
            filteredRules.filter(rule => rule.category === category)
          );
        }

        return filteredRulesByCategory;
      })
    );
  }

  /**
   * ! This means that if you close the tab and create a new one, the state will be persisted so you'll have the same filters as before.
   * ! Might be a good thing, might not.
   * @returns The current state of the UI, persistent.
   */
  private retrieveUiState(): RuleEditorUiState {
    return this.uiStateModelManager.getStateModel<any>('RuleEditorBlockPanelComponent', () => ({
      filters: {
        search: '',
        selectedFilters: [],
        groups: []
      }
    }));
  }
}
