/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainRuleEditModule } from '../../../rule-edit.module';

import { RuleEditorBlocksPanelBlockComponent } from './rule-editor-blocks-panel-block.component';

describe('RuleEditorBlocksPanelBlockComponent', () => {
  let component: RuleEditorBlocksPanelBlockComponent;
  let fixture: ComponentFixture<RuleEditorBlocksPanelBlockComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainRuleEditModule],
      declarations: [RuleEditorBlocksPanelBlockComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleEditorBlocksPanelBlockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
