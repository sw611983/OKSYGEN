/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, ElementRef, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

import { enableDragHandling } from '@oksygen-common-libraries/common';
import { GlobalImageStoreKey, ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import { CategoryType, getPortType, RuleBlock } from '@oksygen-sim-train-libraries/components-services/rules';

@Component({
  selector: 'oksygen-rule-editor-blocks-panel-block',
  templateUrl: './rule-editor-blocks-panel-block.component.html',
  styleUrls: ['./rule-editor-blocks-panel-block.component.scss']
})
export class RuleEditorBlocksPanelBlockComponent implements OnInit, OnChanges {

  @Input() block: RuleBlock;
  icon = 'trigger'; // default icon
  inputPorts: { type: string; image: string }[];
  outputPorts: { type: string; image: string }[];
  category: CategoryType; // must match class name in SCSS
  // Filter to change image color based on the block
  filter: string;

  constructor(private host: ElementRef,
    private imageService: ImageService) {
    enableDragHandling(this.host, () => this.block);
  }

  ngOnInit(): void {
    this.findBlockType(this.block);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.block && changes.block.currentValue !== changes.block.previousValue) {
      const block: RuleBlock = changes.block.currentValue;
      this.inputPorts = block?.inputPorts?.port?.map(port => getPortType(port));
      this.outputPorts = block?.outputPorts?.port?.map(port => getPortType(port));

      const handler = this.imageService.getGlobalImage(GlobalImageStoreKey.RULE_BLOCK, block.name);
      const iconAsUri = handler?.asUri();
      iconAsUri?.then(icon => {
         this.icon = icon;
      });
    }
  }

  findBlockType(block: RuleBlock): void {
    this.category = block?.category;
    // To change color of an image filter value has to be set. The filter values are found from
    // the website https://codepen.io/sosuke/pen/Pjoqqp and the colors are border colors
    // specified in rule-editor-blocks-panel-block.component.scss
    // These must match the ones in 1) shapes.ts(initAttributes() and defaults()) 2) rule-editor-blocks-panel-block.component.scss !!!
    if (this.category === 'constant') {
      // Green color
      this.filter = 'invert(26%) sepia(100%) saturate(1405%) hue-rotate(98deg) brightness(95%) contrast(105%)';
    }
    else if (this.category === 'operation') {
      // Purple color
      this.filter = 'invert(40%) sepia(64%) saturate(3582%) hue-rotate(244deg) brightness(98%) contrast(101%)';
    } else if (this.category === 'action') {
      // Orange color
      this.filter = 'invert(64%) sepia(80%) saturate(1122%) hue-rotate(323deg) brightness(105%) contrast(101%)';
    } else if (this.category === 'selection') {
      // Teal color
      this.filter = 'invert(46%) sepia(82%) saturate(433%) hue-rotate(127deg) brightness(105%) contrast(86%)';
    }
    else if (this.category === 'assessment') {
      // Teal color
      this.filter = 'invert(64%) sepia(80%) saturate(1122%) hue-rotate(323deg) brightness(105%) contrast(101%)';
    }
  }

}
