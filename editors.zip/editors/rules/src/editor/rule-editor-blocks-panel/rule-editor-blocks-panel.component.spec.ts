/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainRuleEditModule } from '../../rule-edit.module';
import { RuleEditorBlocksPanelBlockComponent } from './rule-editor-blocks-panel-block/rule-editor-blocks-panel-block.component';

import { RuleEditorBlocksPanelComponent } from './rule-editor-blocks-panel.component';
import { Component, ViewChild } from '@angular/core';
import { RuleBlock } from '@oksygen-sim-train-libraries/components-services/rules';
import { TranslateTestingModule } from '@oksygen-common-libraries/material/testing';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

const ENGLISH_LANGUAGE = 'en_AU';
const ENGLISH_TRANSLATIONS = {
  greeting: 'Hello',
  appreciation: 'Thank You!'
};

const FRENCH_LANGUAGE = 'fr_FR';
const FRENCH_TRANSLATIONS = {
  greeting: 'Salut',
  appreciation: 'Merci !'
};

const TRANSLATIONS = {
  [ENGLISH_LANGUAGE]: ENGLISH_TRANSLATIONS,
  [FRENCH_LANGUAGE]: FRENCH_TRANSLATIONS
};

const greetingBlockEn = {
  displayName: 'Hello',
  category: 'constant'
} as unknown as RuleBlock;

const appreciationBlockEn = {
  displayName: 'Thank You!',
  category: 'constant'
} as unknown as RuleBlock;

const greetingBlockFr = {
  displayName: 'Salut',
  category: 'constant'
} as unknown as RuleBlock;

const appreciationBlockFr = {
  displayName: 'Merci !',
  category: 'constant'
} as unknown as RuleBlock;


describe('RuleEditorBlocksPanelComponent', () => {
  let component: RuleEditorBlocksPanelComponent;
  let fixture: ComponentFixture<RuleEditorBlocksPanelHostComponent>;
  let parent: RuleEditorBlocksPanelHostComponent;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainRuleEditModule, TranslateTestingModule.withTranslations(TRANSLATIONS).withDefaultLanguage(ENGLISH_LANGUAGE)],
      declarations: [RuleEditorBlocksPanelComponent, RuleEditorBlocksPanelBlockComponent, RuleEditorBlocksPanelHostComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleEditorBlocksPanelHostComponent);
    parent = fixture.componentInstance;
    fixture.detectChanges();
    component = parent.ruleEditorBlocksPanelComponent;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('rule blocks', () => {
    let greetingBlock: RuleBlock;
    let appreciationBlock: RuleBlock;
    let translate: TranslateService;

    beforeEach(() => {
      greetingBlock = {
        displayName: 'greeting',
        category: 'constant'
      } as unknown as RuleBlock;

      appreciationBlock = {
        displayName: 'appreciation',
        category: 'constant'
      } as unknown as RuleBlock;

      parent.blocks = [greetingBlock, appreciationBlock];
      component.filterCategories = ['constant'];
      fixture.detectChanges();
      translate = TestBed.inject(TranslateService);
    });

    describe('should filter rule blocks based on their display name', () => {
      it('should work when the app is translated in english', () => {
        // Setup
        translate.use(ENGLISH_LANGUAGE).subscribe();
        fixture.detectChanges();
        component.applyFilters();

        // We should get both blocks at first
        expect(component.filteredRuleBlocks.get('constant')).toContain(greetingBlockEn);
        expect(component.filteredRuleBlocks.get('constant')).toContain(appreciationBlockEn);

        // Searching for the english word for greeting should return the greeting block
        component.state.filters.search = 'Hello';
        component.applyFilters();
        expect(component.filteredRuleBlocks.get('constant')).toContain(greetingBlockEn);
        expect(component.filteredRuleBlocks.get('constant')).not.toContain(appreciationBlockEn);

        // Changing the text to french should empty the search results.
        component.state.filters.search = 'Merci !';
        component.applyFilters();
        expect(component.filteredRuleBlocks.get('constant')).toEqual([]);
      });

      it('should work when the app is translated in french', () => {
        // Setup
        translate.use(FRENCH_LANGUAGE).subscribe();
        fixture.detectChanges();
        component.applyFilters();
        // We should get both blocks at first
        expect(component.filteredRuleBlocks.get('constant')).toContain(greetingBlockFr);
        expect(component.filteredRuleBlocks.get('constant')).toContain(appreciationBlockFr);

        // Searching for the french word for greeting should return the greeting block
        component.state.filters.search = 'Merci !';
        component.applyFilters();
        expect(component.filteredRuleBlocks.get('constant')).not.toContain(greetingBlockFr);
        expect(component.filteredRuleBlocks.get('constant')).toContain(appreciationBlockFr);
      });
    });
  });
});

@Component({
  template: '<oksygen-rule-editor-blocks-panel [blocks]="blocks" />'
})
class RuleEditorBlocksPanelHostComponent {
  blocks: RuleBlock[];
  @ViewChild(RuleEditorBlocksPanelComponent) ruleEditorBlocksPanelComponent: RuleEditorBlocksPanelComponent;
}
