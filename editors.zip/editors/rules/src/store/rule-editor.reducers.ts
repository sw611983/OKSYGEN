/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createReducer, on } from '@ngrx/store';
import { cloneDeep } from 'lodash';

import {
  PropertyUpdate, RuleProperty, RuleTemplate, RuleTemplateConnection, RuleTemplateRuleBlock, RuleTemplateRuleBlockMeta
} from '@oksygen-sim-train-libraries/components-services/rules';

import { ruleEditorActions } from './rule-editor.actions';
import { initialRuleEditorState, RuleEditorData, ruleEditorDataAdapter, RuleEditorState } from './rule-editor.state';
import { Version, versionCompare } from '@oksygen-sim-train-libraries/components-services/versioning';
import { updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';

export const ruleEditorReducer = createReducer(
  initialRuleEditorState,
  on(
    // FIXME @@@ Hardcoded values need to be parameterised
    ruleEditorActions.newRule,
    (state: RuleEditorState, action: {id: string; name: string}) => {
      const value: RuleEditorData = {
        id: action.id,
        savedName: action.name,
        unsavedChanges: true,
        editorItem: {
          id: action.id,
          displayDescription: '',
          displayName: action.name,
          ruleBlocks: { ruleBlock: [] },
          version: { major: 1, minor: 0, patch: 0 },
          history: { historyLog: [] },
          connections: { connection: [] },
          phantom: false
        },
        canRedo: false,
        canUndo: false
      };

      return ruleEditorDataAdapter.setOne(value, state);
    }
  ),
  on(ruleEditorActions.loadRuleTemplate,
    (state: RuleEditorState, action: {id: string; original: RuleTemplate}) => {
      const value: RuleEditorData = {
        id: action.id,
        editorItem: action.original,
        unsavedChanges: false,
        savedName: action.original.displayName,
        canRedo: false,
        canUndo: false
      };

      return ruleEditorDataAdapter.setOne(value, state);
    }
  ),
  on(ruleEditorActions.saveRuleTemplate,
    (state: RuleEditorState, action: {id: string; save: RuleTemplate}) => {
      const value = cloneDeep(state.entities[action.id]);

      return ruleEditorDataAdapter.setOne({
        ...value,
        unsavedChanges: false,
        savedName: action.save.displayName,
        editorItem: action.save // replacing this, as we updated the version number
      }, state);
    }
  ),
  on(ruleEditorActions.ruleTemplateClosed,
    (state: RuleEditorState, action: {id: string}) => ruleEditorDataAdapter.removeOne(action.id, state)
  ),
  on(ruleEditorActions.setRuleTemplateName,
    (state: RuleEditorState, action: {id: string; name: string}) => {
      const value = cloneDeep(state.entities[action.id]);

      if (value?.editorItem?.displayName === action.name) {// FIXME @@@ A nasty naming issue is starting to arise...
        return state;
      }

      return updateForUnsavedChanges(ruleEditorDataAdapter, state, value, {
          ...value.editorItem,
          displayName: action.name // FIXME @@@ A nasty naming issue is starting to arise...
      });
    }
  ),
  on(ruleEditorActions.setRuleTemplateDescription,
    (state: RuleEditorState, action: {id: string; desc: string}) => {
      const value = cloneDeep(state.entities[action.id]);

      if (value.editorItem.displayDescription === action.desc) { // FIXME @@@ A nasty naming issue is starting to arise...
        return state;
      }

      return updateForUnsavedChanges(ruleEditorDataAdapter, state, value, {
        ...value.editorItem,
        displayDescription: action.desc // FIXME @@@ A nasty naming issue is starting to arise...
      });
    }
  ),
  on(ruleEditorActions.setRuleTemplateVersion,
    (state: RuleEditorState, action: {id: string; version: Version}) => {
      const value = cloneDeep(state.entities[action.id]);

      if (versionCompare(value.editorItem.version, action.version) === 0) {
        return state;
      }

      return updateForUnsavedChanges(ruleEditorDataAdapter, state, value, {
        ...value.editorItem,
          version: action.version
      });
    }
  ),
  on(ruleEditorActions.addRuleBlockToRuleTemplate,
    (state: RuleEditorState, action: {id: string; block: RuleTemplateRuleBlock}) => {
      const cloned = cloneDeep(state.entities[action.id]);
      const ruleBlock = cloned.editorItem?.ruleBlocks?.ruleBlock || [];
      ruleBlock.push(action.block);
      const updatedRuleTemplateEntity: RuleEditorData = {
        ...cloned,
        editorItem: {
          ...cloned.editorItem,
          ruleBlocks: {
            ruleBlock
          }
        }
      };
      return updateForUnsavedChanges(ruleEditorDataAdapter, state, cloned, {
        ...updatedRuleTemplateEntity.editorItem
      });
    }
  ),
  on(ruleEditorActions.removeRuleBlockFromRuleTemplate,
    (state: RuleEditorState, action: {id: string; block: RuleTemplateRuleBlock}) => {
      if (!action.block.id) { return state; } // note id must be non-zero
      const cloned = cloneDeep(state.entities[action.id]);
      const ruleBlock = (
        cloned.editorItem?.ruleBlocks?.ruleBlock || []
        ).filter(rb => rb.id !== action.block.id);
      const updatedRuleTemplateEntity: RuleEditorData = {
        ...cloned,
        editorItem: {
          ...cloned.editorItem,
          ruleBlocks: {
            ruleBlock
          }
        }
      };
      if (cloned.editorItem?.connections?.connection) {
        const connections = cloned.editorItem?.connections?.connection.filter(
          connection => connection.destination.blockId !== action.block.id && connection.source.blockId !== action.block.id
        );
        updatedRuleTemplateEntity.editorItem.connections = { connection: connections };
      }
      return updateForUnsavedChanges(ruleEditorDataAdapter, state, cloned, {
        ...updatedRuleTemplateEntity.editorItem
      });
    }
  ),
  on(ruleEditorActions.updateRuleBlockInRuleTemplateMeta,
    (state: RuleEditorState, action: {id: string; blockId: number; meta: RuleTemplateRuleBlockMeta}) => {
      if (!action.blockId) { return state; } // note id must be non-zero
      const cloned = cloneDeep(state.entities[action.id]);
      const ruleBlock = (
        cloned.editorItem?.ruleBlocks?.ruleBlock || []
        ).find(rb => rb.id === action.blockId);
      if (!ruleBlock) { return state; }
      ruleBlock.metaData = action.meta;
      const updatedRuleTemplateEntity: RuleEditorData = {
        ...cloned,
        editorItem: {
          ...cloned.editorItem,
          ruleBlocks: {
            ruleBlock: cloned.editorItem.ruleBlocks.ruleBlock
          }
        }
      };
      return updateForUnsavedChanges(ruleEditorDataAdapter, state, cloned, {
        ...updatedRuleTemplateEntity.editorItem
      });
    }
  ),
  on(ruleEditorActions.updateRuleTemplateConnections,
    (state: RuleEditorState, action: {id: string; connections: RuleTemplateConnection[]}) => {
      const cloned = cloneDeep(state.entities[action.id]);
      const updatedRuleTemplateEntity: RuleEditorData = {
        ...cloned,
        editorItem: {
          ...cloned.editorItem,
          connections: {
            connection: action.connections
          }
        }
      };
      return updateForUnsavedChanges(ruleEditorDataAdapter, state, cloned, {
        ...updatedRuleTemplateEntity.editorItem
      });
    }
  ),
  on(ruleEditorActions.updateRuleBlockName,
    (state: RuleEditorState, action: {id: string; blockId: number; name: string}) => {
      if (!action.blockId) { return state; } // note id must be non-zero
      const cloned = cloneDeep(state.entities[action.id]);
      const ruleBlock = (
        cloned.editorItem?.ruleBlocks?.ruleBlock || []
        ).find(rb => rb.id === action.blockId);
      if (!ruleBlock) { return state; }
      ruleBlock.displayName = action.name;
      const updatedRuleTemplateEntity: RuleEditorData = {
        ...cloned,
        editorItem: {
          ...cloned.editorItem,
          ruleBlocks: {
            ruleBlock: cloned.editorItem.ruleBlocks.ruleBlock
          }
        }
      };
      return updateForUnsavedChanges(ruleEditorDataAdapter, state, cloned, {
        ...updatedRuleTemplateEntity.editorItem
      });
    }
  ),
  on(ruleEditorActions.updateRuleBlockDescription,
    (state: RuleEditorState, action: {id: string; blockId: number; description: string}) => {
      if (!action.blockId) { return state; } // note id must be non-zero
      const cloned = cloneDeep(state.entities[action.id]);
      const ruleBlock = (
        cloned.editorItem?.ruleBlocks?.ruleBlock || []
        ).find(rb => rb.id === action.blockId);
      if (!ruleBlock) { return state; }
      ruleBlock.displayDescription = action.description;
      const updatedRuleTemplateEntity: RuleEditorData = {
        ...cloned,
        editorItem: {
          ...cloned.editorItem,
          ruleBlocks: {
            ruleBlock: cloned.editorItem.ruleBlocks.ruleBlock
          }
        }
      };
      return updateForUnsavedChanges(ruleEditorDataAdapter, state, cloned, {
        ...updatedRuleTemplateEntity.editorItem
      });
    }
  ),
  on(ruleEditorActions.updateRuleBlockProperty,
    (state: RuleEditorState, action: {id: string; blockId: number; propertyName: string; propertyValue: string|number|boolean}) => {
      if (!action.blockId) { return state; } // note id must be non-zero
      const cloned = cloneDeep(state.entities[action.id]);
      const ruleBlock = (
        cloned.editorItem?.ruleBlocks?.ruleBlock || []
        ).find(rb => rb.id === action.blockId);
      if (!ruleBlock) { return state; }
      const property = ruleBlock.properties?.property?.find(p => p.name === action.propertyName);
      if (!property) { return state; }
      property.value = action.propertyValue;
      const updatedRuleTemplateEntity: RuleEditorData = {
        ...cloned,
        editorItem: {
          ...cloned.editorItem,
          ruleBlocks: {
            ruleBlock: cloned.editorItem.ruleBlocks.ruleBlock
          }
        }
      };
      return updateForUnsavedChanges(ruleEditorDataAdapter, state, cloned, {
        ...updatedRuleTemplateEntity.editorItem
      });
    }
  ),
  on(ruleEditorActions.updateRuleBlockProperties,
    (state: RuleEditorState, action: {id: string; blockId: number; updates: PropertyUpdate[]}) => {
      if (!action.blockId) { return state; } // note id must be non-zero
      const cloned = cloneDeep(state.entities[action.id]);
      const ruleBlock = (
        cloned.editorItem?.ruleBlocks?.ruleBlock || []
        ).find(rb => rb.id === action.blockId);
      if (!ruleBlock) { return state; }
      action.updates?.forEach(update => {
        const property = ruleBlock.properties?.property?.find(p => p.name === update.name);
        if (!property) {
          const prop: RuleProperty = { name: update.name, value: update.value };
          ruleBlock.properties.property.push(prop);
        } else {
          property.value = update.value;
        }
      });
      const updatedRuleTemplateEntity: RuleEditorData = {
        ...cloned,
        editorItem: {
          ...cloned.editorItem,
          ruleBlocks: {
            ruleBlock: cloned.editorItem.ruleBlocks.ruleBlock
          }
        }
      };
      return updateForUnsavedChanges(ruleEditorDataAdapter, state, cloned, {
        ...updatedRuleTemplateEntity.editorItem
      });
    }
  )
);
