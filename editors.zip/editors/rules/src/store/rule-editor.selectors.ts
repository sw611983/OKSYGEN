/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/explicit-function-return-type */

import { EntityState } from '@ngrx/entity';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { RuleEditorData, ruleEditorDataAdapter } from './rule-editor.state';
import { canRedo, canUndo, getEditorItem, getSavedName, getUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';

const ruleEditorSelectors = ruleEditorDataAdapter.getSelectors();

export const selectRuleEditorState = createFeatureSelector<EntityState<RuleEditorData>>('ruleEditor');

export const selectRuleEditorEntities = createSelector(selectRuleEditorState, ruleEditorSelectors.selectEntities);

export const getAllRuleEditorData = createSelector(selectRuleEditorState, ruleEditorSelectors.selectAll);

/**
 * Selector for observing the saved user fault name.
 * This will change when the user fault is saved.
 */
export const getSavedRuleTemplateName = (id: string) =>
  createSelector(getAllRuleEditorData, storeData => getSavedName(id, storeData));

/**
 * Selector for observing the rule under edit.
 * This will change during an editing session to reflect the user's input.
 */
export const getRule = (ruleTemplateId: string) =>
  createSelector(getAllRuleEditorData, storeData => getEditorItem(ruleTemplateId, storeData));

/**
 * Selector for observing the unsaved changes state
 * This will change when the scenario is saved.
 */
export const getRuleTempalteUnsavedChanges = (id: string) =>
  createSelector(getAllRuleEditorData, storeData => getUnsavedChanges(id, storeData));

/**
 * Selector for observing the undo changes state
 * This will change when rule data is changed.
 */
export const canUndoRule = (id: string) =>
 createSelector(getAllRuleEditorData, storeData => canUndo(id, storeData));

/**
 * Selector for observing the redo changes state
 * This will change when rule data is changed.
 */
export const canRedoRule = (id: string) =>
 createSelector(getAllRuleEditorData, storeData => canRedo(id, storeData));
