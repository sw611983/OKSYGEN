/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { BaseEditorStoreData } from '@oksygen-sim-train-libraries/components-services/editors';

import { RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';

export type RuleEditorData = BaseEditorStoreData<RuleTemplate>;
export type RuleEditorState = EntityState<RuleEditorData>;
export const ruleEditorDataAdapter: EntityAdapter<RuleEditorData> = createEntityAdapter<RuleEditorData>();
export const initialRuleEditorState: RuleEditorState = ruleEditorDataAdapter.getInitialState();
