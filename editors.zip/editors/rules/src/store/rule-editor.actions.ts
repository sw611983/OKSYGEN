/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createActionGroup, props } from '@ngrx/store';

import {
  PropertyUpdate, RuleTemplate, RuleTemplateConnection, RuleTemplateRuleBlock, RuleTemplateRuleBlockMeta
} from '@oksygen-sim-train-libraries/components-services/rules';
import { Version } from '@oksygen-sim-train-libraries/components-services/versioning';

/** Our list of possible actions one can take in the Rule Editor. */
export const ruleEditorActions = createActionGroup({
  source: 'RuleEditorActionEnum',
  events: {
    'new Rule': props<{ id: string; name: string }>(),
    'load Rule Template': props<{ id: string; original: RuleTemplate }>(),
    'save Rule Template': props<{ id: string; save: RuleTemplate }>(),
    'rule Template Closed': props<{ id: string }>(),
    'undo Rule Edit': props<{ id: string }>(),
    'redo Rule Edit': props<{ id: string }>(),
    'set Rule Template Name': props<{ id: string; name: string }>(),
    'set Rule Template Description': props<{ id: string; desc: string }>(),
    'set Rule Template Version': props<{ id: string; version: Version }>(),
    'add Rule Block To Rule Template': props<{ id: string; block: RuleTemplateRuleBlock }>(),
    'remove Rule Block From Rule Template': props<{ id: string; block: RuleTemplateRuleBlock }>(),
    'update Rule Block In Rule Template Meta': props<{ id: string; blockId: number; meta: RuleTemplateRuleBlockMeta }>(),
    'update Rule Template Connections': props<{ id: string; connections: RuleTemplateConnection[] }>(),
    'update Rule Block Name': props<{ id: string; blockId: number; name: string }>(),
    'update Rule Block Description': props<{ id: string; blockId: number; description: string }>(),
    'update Rule Block Property': props<{ id: string; blockId: number; propertyName: string; propertyValue: string|number|boolean }>(),
    'update Rule Block Properties': props<{ id: string; blockId: number; updates: PropertyUpdate[] }>()
  }
});
