/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { InjectionToken  } from '@angular/core';

export interface RuleEditModuleConfig {
  constraintConfig: OksygenPropertyConstraintConfig;
}

/** specify which default Oksygen constraints you'd like to use. */
export interface OksygenPropertyConstraintConfig {
  environment?: boolean;
  instrutorPrompt?: boolean;
  train?: boolean;
  trainProperty?: boolean;
  trainSpatial?: boolean;
  unknown?: boolean;
  vehicle?: boolean;
  feature?: boolean;
  featureState?: boolean;
  temporalEvent?: boolean;
  moodleActivity?: boolean;
  moodleActivityAction?: boolean;
  userFault?: boolean;
  setVariable?: boolean;
  getVariable?: boolean;
  assessment?: boolean;
}

const defaultOksygenConstraints: OksygenPropertyConstraintConfig = {
  environment: true,
  instrutorPrompt: true,
  unknown: true,
  vehicle: true,
  train: true,
  trainProperty: true,
  trainSpatial: true,
  feature: true,
  featureState: true,
  temporalEvent: true,
  moodleActivity: true,
  moodleActivityAction: true,
  userFault: true,
  setVariable: true,
  getVariable: true,
  assessment: true
};

/** Token for rule editor config. */
export const RULE_EDITOR_MODULE_CONFIG_TOKEN = new InjectionToken<RuleEditModuleConfig>('Rule Edit Module Config');
/** Default config for the rule editor. */
export const DEFAULT_RULE_EDITOR_CONFIG: RuleEditModuleConfig = { constraintConfig: defaultOksygenConstraints };

// It would be nice to provide constraints by type reference in your forRoot().
// ie forRoot(config: {environment: EnvironmentConstraint}).
// If we do this, we cannot create the constraint because we do not know it's arguments.
// The problem with decorators is now we require constraints to be decorated with their argument list.
// The following code can work out the arguments via using a decorator:

// function decoratorFn(obj: any) {
//   return function(target: { new (...args: any[]): {} }) {
//     return class extends target {
//       providers = obj;
//     };
//   }
// }


// class A {constructor(str: string) {}}
// @decoratorFn({})
// class B extends A {constructor(num: number, str: string) {super(str); }}
// class D {}
// export interface PropertyConstraintConfig {
//   [key: string]: { new (...args: any): A };
// }

// const test: PropertyConstraintConfig = {
//   environment: B
// };

// const foo = new test.environment('asd');
