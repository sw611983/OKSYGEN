/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { RuleImportDialogComponent } from './rule-import-dialog.component';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

describe('RuleImportDialogComponent', () => {
  let component: RuleImportDialogComponent;
  let fixture: ComponentFixture<RuleImportDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [RuleImportDialogComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleImportDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
