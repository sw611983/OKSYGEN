/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { AfterViewInit, Component, ElementRef, Inject, OnDestroy, QueryList, ViewChildren } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef, MatDialogConfig } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { generateUuid } from '@oksygen-common-libraries/common';
import { RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';
import { cloneDeep } from 'lodash';
import { Subject } from 'rxjs';
import { distinctUntilChanged, debounceTime, takeUntil } from 'rxjs/operators';

interface RuleImportDialogRule {
  fileName: string;
  alreadyExists?: boolean;
  import?: boolean;
  formControl: FormControl;
  ruleTemplate: RuleTemplate;
}

export interface RuleImportDialogInput {
  importRules: {fileName: string; ruleTemplate: RuleTemplate}[];
  existingRules: RuleTemplate[];
}

export interface RuleImportDialogResult {
  rules: RuleTemplate[];
}

@Component({
  selector: 'oksygen-rule-import-dialog',
  templateUrl: './rule-import-dialog.component.html',
  styleUrls: ['./rule-import-dialog.component.scss']
})
export class RuleImportDialogComponent implements AfterViewInit, OnDestroy {

  deleteAfter = false;
  rules: RuleImportDialogRule[];
  selectedCount = 0;
  canImport = false;
  confirmButtonText: string;
  @ViewChildren('input') private inputs: QueryList<ElementRef>;
  private destroyed$ = new Subject();

  constructor(
    public dialogRef: MatDialogRef<RuleImportDialogComponent, RuleImportDialogResult>,
    @Inject(MAT_DIALOG_DATA) public data: RuleImportDialogInput,
    private translateService: TranslateService
  ) {
    this.rules = data?.importRules?.map(ruleTemplate => ({
      ruleTemplate: ruleTemplate.ruleTemplate,
      alreadyExists: this.alreadyExists(ruleTemplate.ruleTemplate.displayName),
      fileName: ruleTemplate.fileName,
      formControl: this.formControl(ruleTemplate.ruleTemplate.displayName),
      import: true
    })) ?? [];
    this.calculateSelectedCount();
    this.setCanImport();
  }

  public static openDialog(dialog: MatDialog, input: RuleImportDialogInput): MatDialogRef<RuleImportDialogComponent, RuleImportDialogResult> {
    const config: MatDialogConfig<RuleImportDialogInput> = {
      data: input,
      id: 'rule-importer-dialog',
      width: '70vh',
      height: '70vh'
    };
    const dialogRef = dialog.open<RuleImportDialogComponent, RuleImportDialogInput, RuleImportDialogResult>(RuleImportDialogComponent, config);
    return dialogRef;
  }

  ngAfterViewInit(): void {
    this.rules.forEach(input => {
      // fromEvent(input.formnativeElement, 'keyup').pipe(
      input.formControl.valueChanges.pipe(
        debounceTime(400),
        distinctUntilChanged(),
        takeUntil(this.destroyed$)
      ).subscribe(text => this.onInputChange(input, text), () => {}, () => {console.log('closed subscription'); });
    });
  }

  ngOnDestroy(): void {
    this.destroyed$.next(undefined);
    this.destroyed$.complete();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onConfirmClick(): void {
    const importRules = this.rules
      .filter(r => r.import)
      .map(r => this.toNewRuleTemplate(r));
    this.dialogRef.close({rules: importRules});
  }

  calculateSelectedCount(): void {
    this.selectedCount = this.rules.filter(r => r.import).length;
    this.confirmButtonText = this.translateService.instant(t(`Import ({count}) selected`), {count: this.selectedCount});
    this.setCanImport();
  }

  setCanImport(): void {
    this.canImport = !!this.rules.find(r => r.alreadyExists && r.import);
  }

  private onInputChange(input: RuleImportDialogRule, text: string): void {
    input.alreadyExists = this.alreadyExists(text);
    this.setCanImport();
  }

  private formControl(value: string): FormControl {
    const fc = new FormControl();
    fc.setValue(value, {emitEvent: false, onlySelf: true});
    return fc;
  }

  private alreadyExists(ruleName: string): boolean {
    return !!this.data.existingRules.find(r => r.displayName === ruleName);
  }

  /** Generates a new id and sets displayName to the form field name */
  private toNewRuleTemplate(input: RuleImportDialogRule): RuleTemplate {
    const id = generateUuid();
    const ruleTemplate = cloneDeep(input.ruleTemplate);
    ruleTemplate.id = id;
    ruleTemplate.displayName = input.formControl.getRawValue();
    return ruleTemplate;
  }
}
