/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';
import { versionCompare } from '@oksygen-sim-train-libraries/components-services/versioning';

/**
 * Our raw list of rule templates will list different versions of a rule template as different templates.
 * This function will filter out the old versions of templates from this list.
 *
 * @param ruleTemplates the raw list of rule templates
 */
export function filterOldVersions(ruleTemplates: RuleTemplate[]): RuleTemplate[] {
  const templates: RuleTemplate[] = [];
  ruleTemplates?.forEach(ruleTemplate => {
    // add new templates. If template is already added, use the one with the latest version.
    const existingTemplate = templates.find(rt => rt.id === ruleTemplate.id);
    if (!existingTemplate) {
      templates.push(ruleTemplate);
    } else {
      if (versionCompare(ruleTemplate.version, existingTemplate.version) === 1) {
        const index = templates.findIndex(rt => rt.id === ruleTemplate.id);
        templates[index] = ruleTemplate;
      }
    }
  });
  return templates;
}
