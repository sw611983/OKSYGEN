/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { EnvironmentProviders, ModuleWithProviders, NgModule, Provider } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule, RouteConfig, RoutingPage } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { OksygenSimTrainRuleModule, RuleBlockPropertyConstraintService } from '@oksygen-sim-train-libraries/components-services/rules';
import { OksygenSimTrainVersionModule } from '@oksygen-sim-train-libraries/components-services/versioning';

import { RuleBrowserComponent } from './browser/rule-browser.component';
import { RuleBrowserService } from './browser/rule-browser.service';
import { RuleDetailBlockListComponent } from './browser/rule-detail-panel/rule-detail-block-list/rule-detail-block-list.component';
import { RuleDetailPanelComponent } from './browser/rule-detail-panel/rule-detail-panel.component';
import {
  RuleEditorBlocksPanelBlockComponent
} from './editor/rule-editor-blocks-panel/rule-editor-blocks-panel-block/rule-editor-blocks-panel-block.component';
import { RuleEditorBlocksPanelComponent } from './editor/rule-editor-blocks-panel/rule-editor-blocks-panel.component';
import { RuleEditorCanvasComponent } from './editor/rule-editor-canvas/rule-editor-canvas.component';
import { RuleEditorPropertiesPanelComponent } from './editor/rule-editor-properties-panel/rule-editor-properties-panel.component';
import { RuleEditorTopToolbarComponent } from './editor/rule-editor-top-toolbar/rule-editor-top-toolbar.component';
import { RuleEditorComponent } from './editor/rule-editor.component';
import { RuleImportDialogComponent } from './rule-import-dialog/rule-import-dialog.component';
import { RuleTemplateListComponent } from './rule-template-list/rule-template-list.component';
import { RuleEditService } from './services/rule-edit.service';
import { RuleEditorContextManager } from './services/rule-editor-context.manager';
import { RuleEditorContextPublisher } from './services/rule-editor-context.publisher';
import { RuleEditorRuleBlockPropertyConstraintService } from './services/rule-editor-rule-block-property-constraint.service';
import { DEFAULT_RULE_EDITOR_CONFIG, RULE_EDITOR_MODULE_CONFIG_TOKEN, RuleEditModuleConfig } from './tokens/module-config.token';
import { OksygenSimCoreUnitsModule } from '@oksygen-sim-core-libraries/components-services/measurement-units';

export const ruleBrowserPage: RoutingPage = {
  path: 'rules',
  component: RuleBrowserComponent
};

export function ruleBrowserRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  return { path: ruleBrowserPage.path, component: ruleBrowserPage.component, canActivate: auth };
}

export const ruleEditorPage: RoutingPage = {
  path: 'rules/:id',
  component: RuleEditorComponent
};

export function ruleEditorRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  return { path: ruleEditorPage.path, component: ruleEditorPage.component, canActivate: auth };
}

const components = [
  RuleBrowserComponent,
  RuleEditorCanvasComponent,
  RuleEditorBlocksPanelComponent,
  RuleEditorBlocksPanelBlockComponent,
  RuleEditorPropertiesPanelComponent,
  RuleEditorTopToolbarComponent,
  RuleEditorComponent,
  RuleTemplateListComponent,
  RuleDetailPanelComponent,
  RuleDetailBlockListComponent,
  RuleImportDialogComponent
];

@NgModule({
  declarations: components,
  imports: [
    RouterModule,
    CommonModule,
    DragDropModule,
    OksygenMaterialComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    // this is ugly to repeat everywhere, but it's the only way for this to be properly initialised
    OksygenMaterialTranslateModule.forChild(),
    OksygenSimTrainCommonModule,
    OksygenSimTrainEditorsModule,
    OksygenSimTrainRuleModule,
    OksygenSimTrainVersionModule,
    OksygenSimCoreUnitsModule
  ],
  exports: components,
  providers: [
    RuleEditService, RuleBrowserService, RuleEditorContextPublisher, RuleEditorContextManager,
    { provide: RULE_EDITOR_MODULE_CONFIG_TOKEN, useValue: DEFAULT_RULE_EDITOR_CONFIG },
    { provide: RuleBlockPropertyConstraintService, useClass: RuleEditorRuleBlockPropertyConstraintService }
  ]
})
export class OksygenSimTrainRuleEditModule {

  /**
   * forRoot takes a config object containing which constraints you would like to use.
   */
  public static forRoot(config?: RuleEditModuleConfig): ModuleWithProviders<OksygenSimTrainRuleEditModule> {
    const providers: (Provider | EnvironmentProviders) = [];
    const mergedConfig = { ...DEFAULT_RULE_EDITOR_CONFIG, ...config };
    if (config) { providers.push({ provide: RULE_EDITOR_MODULE_CONFIG_TOKEN, useValue: mergedConfig });}
    return ({
      ngModule: OksygenSimTrainRuleEditModule,
      providers
    });
  }
}
