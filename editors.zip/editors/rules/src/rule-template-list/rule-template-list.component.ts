/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, Observable } from 'rxjs';

import {
  Filter,
  SelectedFilterArray,
  Sorter,
  SorterPipe,
  allFilterTypesMatch,
  filterMatches
} from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';
import { RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { isNil } from 'lodash';

// TODO: Commonize, this was taken from object-type-list.component.ts
interface RuleTemplateTypeListState {
  filters: RuleTemplateTypeListFilter;
}

export interface RuleTemplateTypeListFilter {
  search: string;
  selectedFilters: SelectedFilterArray<RuleTemplateTypeListFilterType>;
}

export enum RuleTemplateTypeListFilterType {
  NAME = 'search',
}

@Component({
  selector: 'oksygen-rule-template-list',
  templateUrl: './rule-template-list.component.html',
  styleUrls: ['./rule-template-list.component.scss']
})
export class RuleTemplateListComponent implements OnInit, OnChanges {
  @Input() ruleTemplates!: RuleTemplate[];
  @Input() searchable: boolean;
  @Input() uiModels!: UiStateModelManager;
  @Input() uiModelKey = 'oksygen-rule-template-list';
  @Input() set sourceFilters(filters: Array<Filter<RuleTemplateTypeListFilterType>>) {
    if (!isNil(filters)) {
      this._sourceFilters = filters;
    }
  }
  @Input() showTitle = false;

  state: RuleTemplateTypeListState;
  _sourceFilters: Array<Filter<RuleTemplateTypeListFilterType>> = [];

  filtersSubject: BehaviorSubject<Array<string>> = new BehaviorSubject([]);
  searchTextSubject = new BehaviorSubject('');
  searchText$: Observable<string>;
  sorter = new Sorter<RuleTemplate>();
  filteredRuleTemplates: Array<RuleTemplate> = [];

  private sorterPipe = new SorterPipe();

  constructor(private logging: Logging, translateService: TranslateService) {
    this.sorter.sortFunction = (c, a, b): number =>
      a?.displayName?.localeCompare(b?.displayName, (translateService).currentLocaleString);
  }

  ngOnInit(): void {
    if (!isNil(this.uiModels)) {
      this.state = this.uiModels.getStateModel<any>(this.uiModelKey, () => ({
        filters: {
          typeGroupFilters: [],
          search: '',
          selectedFilters: new SelectedFilterArray<RuleTemplateTypeListFilterType>()
        }
      }));
    } else {
      this.state = {
        filters: {
          search: '',
          selectedFilters: new SelectedFilterArray<RuleTemplateTypeListFilterType>()
        }
      };
    }

    this.applyFilters();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.ruleTemplates && this.state) {
      this.applyFilters();
    }
  }

  onCurrentValueUpdate(search: string): void {
    this.state.filters.search = search;
    this.applyFilters();
  }

  applyFilters(): void {
    if (!this.ruleTemplates) {
      return;
    }

    this.filteredRuleTemplates =
      this.ruleTemplates?.filter(ruleTemplate => {
        const names = [ruleTemplate.displayName];
        try {
          if (!allFilterTypesMatch([{ t: RuleTemplateTypeListFilterType.NAME, v: names }], this.state.filters.selectedFilters)) {
            return false;
          }
        } catch {
          return false;
        }

        if (!filterMatches(names, this.state.filters.search)) {
          return false;
        }
        return true;
      }) ?? [];

    this.filteredRuleTemplates = this.sorterPipe.transform(this.filteredRuleTemplates, this.sorter, this.sorter.refresh);
  }

  textToFilter(text: string): Filter<string> {
    return new Filter(RuleTemplateTypeListFilterType.NAME, text);
  }

  /**
   * Adds the given filter to the selected filters, removing any other filters of the same type.
   */
  setUniqueFilterType(filter: Filter<RuleTemplateTypeListFilterType>): void {
    if (filter) {
      this.state.filters.selectedFilters.replace(filter.type, filter);
      this.applyFilters();
    }
  }
}
