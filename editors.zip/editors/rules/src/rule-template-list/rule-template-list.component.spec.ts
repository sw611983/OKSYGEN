/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RuleTemplateListItemComponent } from '@oksygen-sim-train-libraries/components-services/rules';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { RuleTemplateListComponent } from './rule-template-list.component';

describe('RuleTemplateListComponent', () => {
  let component: RuleTemplateListComponent;
  let fixture: ComponentFixture<RuleTemplateListComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [RuleTemplateListItemComponent, RuleTemplateListComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleTemplateListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
