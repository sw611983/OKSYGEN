/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/explicit-function-return-type */

import { EntityState } from '@ngrx/entity';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { canRedo, canUndo, getEditorItem, getSavedName, getUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { UserFaultEditorStoreData, userFaultEditorDataAdapter } from './user-fault-editor.state';

const userFaultEditorSelectors = userFaultEditorDataAdapter.getSelectors();

export const selectUserFaultEditorState = createFeatureSelector<EntityState<UserFaultEditorStoreData>>('userFaultEditor');

export const selectUserFaultEditorEntities = createSelector(selectUserFaultEditorState, userFaultEditorSelectors.selectEntities);

export const getAllUserFaultEditorData = createSelector(selectUserFaultEditorState, userFaultEditorSelectors.selectAll);

/**
 * Selector for observing the saved user fault name.
 * This will change when the user fault is saved.
 */
export const getSavedUserFaultName = (id: string) =>
  createSelector(getAllUserFaultEditorData, storeData => getSavedName(id, storeData));

/**
 * Selector for observing the unsaved changes state
 * This will change when the user fault is saved.
 */
export const getUserFaultUnsavedChanges = (id: string) =>
  createSelector(getAllUserFaultEditorData, storeData => getUnsavedChanges(id, storeData));

/**
 * Selector for observing the user fault under edit.
 * This will change during an editing session to reflect the user's input.
 */
export const getUserFault = (id: string) =>
  createSelector(getAllUserFaultEditorData, storeData => getEditorItem(id, storeData));

/**
 * Selector for observing the undo changes state
 * This will change when User Fault data is changed.
 */
export const canUndoUserFault = (id: string) =>
 createSelector(getAllUserFaultEditorData, storeData => canUndo(id, storeData));

/**
 * Selector for observing the redo changes state
 * This will change when User Fault data is changed.
 */
export const canRedoUserFault = (id: string) =>
 createSelector(getAllUserFaultEditorData, storeData => canRedo(id, storeData));
