/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createReducer, on } from '@ngrx/store';
import { SimProperty } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { cloneDeep } from 'lodash';
import {
  EditorMonitoredSimProperties, EditorUserFault, EditorUserFaultMonitoredProperty, EditorUserFaultSimProperty, EditorUserFaultState, EditorUserFaultStates
} from '../models/user-fault-editor.model';
import { userFaultEditorActions } from './user-fault-editor.actions';
import { updateForUnsavedChanges, updateSimpleProperty } from '@oksygen-sim-train-libraries/components-services/editors';
import { initialUserFaultEditorState, userFaultEditorDataAdapter, UserFaultEditorState, UserFaultEditorStoreData } from './user-fault-editor.state';

function userFaultUpdateForUnsavedChanges(
  state: UserFaultEditorState,
  original: UserFaultEditorStoreData,
  userFault: EditorUserFault
): UserFaultEditorState {
  return updateForUnsavedChanges(userFaultEditorDataAdapter, state, original, userFault);
}

function generateNewUserFaultStates(): EditorUserFaultStates {
  return {
    userFaultState: [
      {
        name: 'Set',
        mappedSimProperties: {
          mappedSimProperty: []
        }
      },
      {
        name: 'Cleared',
        mappedSimProperties: {
          mappedSimProperty: []
        }
      },
      {
        name: 'Raw',
        mappedSimProperties: {
          mappedSimProperty: []
        }
      }
    ]
  };
}

function generateNewUserFault(id?: string, displayName?: string): EditorUserFault {
  const userFault: EditorUserFault = {
    id,
    displayName,
    history: {
      historyLog: []
    },
    monitoredSimProperties: generateNewMonitoredProperties(),
    userFaultStates: generateNewUserFaultStates(),
    version: 1,
    cause: undefined,
    consequence: undefined,
    troubleshooting: undefined,
    train: undefined
  };
  return userFault;
}

function generateNewMonitoredProperties(): EditorMonitoredSimProperties {
  return {
    simProperty: []
  };
}

export const userFaultEditorReducer = createReducer(
  initialUserFaultEditorState,
  on(
    userFaultEditorActions.newUserFault,
    (state: UserFaultEditorState, action: {id: string; name: string}) => {
      const value: UserFaultEditorStoreData = {
        id: action.id,
        savedName: undefined,
        unsavedChanges: false,
        editorItem: generateNewUserFault(action.id, action.name),
        canRedo: false,
        canUndo: false
      };
      return userFaultEditorDataAdapter.setOne(value, state);
    }
  ),
  on(userFaultEditorActions.loadUserFaultUnsafe,
    (state: UserFaultEditorState, action: {id: string; original: EditorUserFault}) => {
      const value: UserFaultEditorStoreData = {
        id: action.id,
        savedName: action.original.displayName,
        unsavedChanges: false,
        editorItem: action.original,
        canRedo: false,
        canUndo: false
      };

      return userFaultEditorDataAdapter.setOne(value, state);
    }
  ),
  on(userFaultEditorActions.userFaultClosed,
    (state: UserFaultEditorState, action: {id: string}) => userFaultEditorDataAdapter.removeOne(action.id, state)
  ),
  on(userFaultEditorActions.addFault,
    (state: UserFaultEditorState, action: {
      id: string; simProperty: SimProperty; simPropertyGroup: string; vehiclePosition?: number; value?: number|string;
    }) => {
      const value = cloneDeep(state.entities[action.id]);
      const updatedStates: EditorUserFaultState[] = [...value.editorItem.userFaultStates.userFaultState];
      // adding a fault must add it to both 'Set' and 'Cleared' user fault groups so both can be mapped
      updatedStates.forEach(userFaultState => {
        const newProp: EditorUserFaultSimProperty = {
          group: action.simPropertyGroup,
          name: action.simProperty.name,
          stateName: undefined,
          value: undefined, // user to fill this in - no defaults available
          vehiclePosition: action.vehiclePosition
        };
        userFaultState.mappedSimProperties.mappedSimProperty.push(newProp);
      });
      return userFaultUpdateForUnsavedChanges(state, value, {
        ...value.editorItem,
        userFaultStates: {
          userFaultState: updatedStates
        }
      });
    }
  ),


  on(userFaultEditorActions.updateFault,
    (state: UserFaultEditorState, action: {
      id: string; userFaultState: string; simPropertyName: string; simPropertyGroup: string; name: number|string; value: any;
    }) => {
      const value = cloneDeep(state.entities[action.id]);
      const updatedStates: EditorUserFaultState[] = [...value.editorItem.userFaultStates.userFaultState];
      const updatedState = updatedStates.find(us => us.name === action.userFaultState);
      if (!updatedState) { return state; }
      const msp = updatedState.mappedSimProperties.mappedSimProperty.find(p => p.name === action.simPropertyName && p.group === action.simPropertyGroup);
      if (!msp) { return state; }
      msp.stateName = action.name;
      msp.value = action.value;
      return userFaultUpdateForUnsavedChanges(state, value, {
        ...value.editorItem,
        userFaultStates: {
          userFaultState: updatedStates
        }
      });
    }
  ),
  on(userFaultEditorActions.saveUserFault,
    (state: UserFaultEditorState, action: {id: string; save: EditorUserFault }) => {
      const value = cloneDeep(state.entities[action.id]);
    return userFaultEditorDataAdapter.setOne({
      ...value,
      unsavedChanges: false,
      editorItem: {
            ...value?.editorItem, version:  action.save.version,
            history: action.save.history
      }}, state);
    }
  ),
  on(userFaultEditorActions.deleteProperty,
    (state: UserFaultEditorState, action: {
      id: string; simPropertyName: string; simPropertyGroup: string;
    }) => {
      const value = cloneDeep(state.entities[action.id]);
      const updatedStates: EditorUserFaultState[] = [...value.editorItem.userFaultStates.userFaultState];
      // adding a fault must add it to both 'Set' and 'Cleared' user fault groups so both can be mapped
      updatedStates.forEach(userFaultState => {
        const filtered = userFaultState.mappedSimProperties.mappedSimProperty
          .filter(msp => !(msp.name === action.simPropertyName && msp.group === action.simPropertyGroup));
        userFaultState.mappedSimProperties.mappedSimProperty = filtered;
      });
      const updatedProps = [...value.editorItem.monitoredSimProperties.simProperty].filter(prop => (
        !(prop.name === action.simPropertyName && prop.group === action.simPropertyGroup)
      ));
      return userFaultUpdateForUnsavedChanges(state, value, {
        ...value.editorItem,
        userFaultStates: {
          userFaultState: updatedStates
        },
        monitoredSimProperties: {
          simProperty: updatedProps
        }
      });
    }
  ),
  on(userFaultEditorActions.updateFaultVehicle,
    (state: UserFaultEditorState, action: {
      id: string; simPropertyName: string; simPropertyGroup: string; vehiclePosition: number;
    }) => {
      const value = cloneDeep(state.entities[action.id]);
      const updatedStates: EditorUserFaultState[] = [...value.editorItem.userFaultStates.userFaultState];
      // vehicle position updates currently apply to all instances
      for (const updatedState of updatedStates) {
        if (!updatedState) { return state; }
        const msp = updatedState?.mappedSimProperties?.mappedSimProperty?.find(p => p.name === action.simPropertyName && p.group === action.simPropertyGroup);
        if (!msp) { return state; }
        msp.vehiclePosition = action.vehiclePosition;
      }
      return userFaultUpdateForUnsavedChanges(state, value, {
        ...value.editorItem,
        userFaultStates: {
          userFaultState: updatedStates
        }
      });
    }
  ),
  on(userFaultEditorActions.addMonitor,
    (state: UserFaultEditorState, action: {
      id: string; simProperty: SimProperty; simPropertyGroup: string; vehiclePosition?: number; value?: number|string;
    }) => {
      const value = cloneDeep(state.entities[action.id]);
      const updatedProps: EditorUserFaultMonitoredProperty[] = [...value.editorItem.monitoredSimProperties.simProperty];
        const newProp: EditorUserFaultMonitoredProperty = {
          group: action.simPropertyGroup,
          name: action.simProperty.name,
          vehiclePosition: action.vehiclePosition
        };
        updatedProps.push(newProp);
      return userFaultUpdateForUnsavedChanges(state, value, {
        ...value.editorItem,
        monitoredSimProperties: {
          simProperty: updatedProps
        }
      });
    }
  ),
  on(userFaultEditorActions.updateMonitorVehicle,
    (state: UserFaultEditorState, action: {
      id: string; simPropertyName: string; simPropertyGroup: string; vehiclePosition: number;
    }) => {
      const value = cloneDeep(state.entities[action.id]);
      const updatedProps: EditorUserFaultSimProperty[] = [...value.editorItem.monitoredSimProperties.simProperty];
      // vehicle position updates currently apply to all instances
      for (const updatedProp of updatedProps) {
        if (!updatedProp) { return state; }
        if(updatedProp?.name === action.simPropertyName && updatedProp?.group === action.simPropertyGroup) {
          updatedProp.vehiclePosition = action.vehiclePosition;
        }
      }
      return userFaultUpdateForUnsavedChanges(state, value, {
        ...value.editorItem,
        monitoredSimProperties: {
          simProperty: updatedProps
        }
      });
    }
  ),
  on(userFaultEditorActions.setUserFaultName,
    (state: UserFaultEditorState, action: {id: string; name: string}) =>
      updateSimpleProperty(state, userFaultEditorDataAdapter, {
        id: action.id,
        displayName: action.name
      })
  ),
  on(userFaultEditorActions.setUserFaultTrain,
    (state: UserFaultEditorState, action: {id: string; train: string; sameTrainType: boolean}) => {
      const value = cloneDeep(state.entities[action.id]);

      if (value.editorItem.train === action.train) {
        return state;
      }

      if (action.sameTrainType) {
        return userFaultUpdateForUnsavedChanges(state, value, {
            ...value.editorItem,
            train: action.train
          }
        );
      }

      return userFaultUpdateForUnsavedChanges(state, value, {
          ...value.editorItem,
          userFaultStates: generateNewUserFaultStates(),
          monitoredSimProperties: generateNewMonitoredProperties(),
          train: action.train
        }
      );
    }
  ),
  on(userFaultEditorActions.setUserFaultCause,
    (state: UserFaultEditorState, action: {id: string; cause: string}) =>
      updateSimpleProperty(state, userFaultEditorDataAdapter, {
        id: action.id,
        cause: action.cause
      })
  ),
  on(userFaultEditorActions.setUserFaultConsequence,
    (state: UserFaultEditorState, action: {id: string; consequence: string}) =>
      updateSimpleProperty(state, userFaultEditorDataAdapter, {
        id: action.id,
        consequence: action.consequence
      })
  ),
  on(userFaultEditorActions.setUserFaultTroubleshooting,
    (state: UserFaultEditorState, action: {id: string; troubleshooting: string}) =>
      updateSimpleProperty(state, userFaultEditorDataAdapter, {
        id: action.id,
        troubleshooting: action.troubleshooting
      })
  )
);
