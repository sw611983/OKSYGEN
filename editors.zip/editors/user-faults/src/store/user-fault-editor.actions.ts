/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/explicit-function-return-type */

import { createActionGroup, props } from '@ngrx/store';
import { SimProperty } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { cloneDeep } from 'lodash';
import {EditorUserFault } from '../models/user-fault-editor.model';

/** Our list of possible actions one can take in the User Fault Editor. */
export const userFaultEditorActions = createActionGroup({
  source: 'UserFaultEditorActionEnum',
  events: {
    'new User Fault': props<{ id: string; name: string }>(),
    'load User Fault Unsafe': props<{ id: string; original: EditorUserFault }>(),
    'user Fault Closed': props<{ id: string }>(),
    'user Fault Undo': props<{ id: string }>(),
    'user Fault Redo': props<{ id: string }>(),
    'add Fault': props<{ id: string; simProperty: SimProperty; simPropertyGroup: string; vehiclePosition?: number; value?: number|string }>(),
    'save User Fault': props<{ id: string; save: EditorUserFault }>(),
    'update Fault': props<{ id: string; userFaultState: string; simPropertyGroup: string; simPropertyName: string; name: number|string; value: any }>(),
    'update Fault Vehicle': props<{ id: string; simPropertyGroup: string; simPropertyName: string; vehiclePosition: number }>(),
    'delete Property': props<{ id: string; simPropertyName: string; simPropertyGroup: string }>(),
    'add Monitor': props<{ id: string; simProperty: SimProperty; simPropertyGroup: string; vehiclePosition?: number; value?: number|string }>(),
    'update Monitor Vehicle': props<{ id: string; simPropertyGroup: string; simPropertyName: string; vehiclePosition: number }>(),
    'set User Fault Name': props<{ id: string; name: string }>(),
    'set User Fault Train': props<{ id: string; train: string; sameTrainType: boolean }>(),
    'set User Fault Cause': props<{ id: string; cause: string }>(),
    'set User Fault Consequence': props<{ id: string; consequence: string }>(),
    'set User Fault Troubleshooting': props<{ id: string; troubleshooting: string }>()
  }
});

export const loadUserFault = (properties: { id: string; original: EditorUserFault }) => {
  // Note that we're putting things in the store here, which means they will get frozen.
  // We do not want to freeze common objects (e.g. ObjectTypes' icons have caches that must remain writable),
  // See INTOSC-8421
  const original = cloneDeep(properties.original);
  return userFaultEditorActions.loadUserFaultUnsafe({ id: properties.id, original });
};
