/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { BaseEditorStoreData } from '@oksygen-sim-train-libraries/components-services/editors';
import { EditorUserFault } from '../models/user-fault-editor.model';

export type UserFaultEditorStoreData = BaseEditorStoreData<EditorUserFault>;
export type UserFaultEditorState = EntityState<UserFaultEditorStoreData>;
export const userFaultEditorDataAdapter: EntityAdapter<UserFaultEditorStoreData> = createEntityAdapter<UserFaultEditorStoreData>();
export const initialUserFaultEditorState: UserFaultEditorState = userFaultEditorDataAdapter.getInitialState();
