/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';

import { SelectedFilterArray } from '@oksygen-common-libraries/material/components';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { ContextManager } from '@oksygen-sim-train-libraries/components-services/common';
import { ConsistDataService, TrainConsistManager } from '@oksygen-sim-train-libraries/components-services/trains';
import { UserFaultDatabaseService } from '@oksygen-sim-train-libraries/components-services/user-faults';

import { UserFaultEditorFilterType, UserFaultEditorUiState } from '../models/user-fault-editor.model';
import { UserFaultEditorContext } from './user-fault-editor-context';

/**
 * A ContextManager for the User Fault Editor.
 */
@Injectable()
export class UserFaultEditorContextManager extends ContextManager<string, UserFaultEditorContext> {

  constructor(
    private registry: Registry,
    private logger: Logging,
    private consistDataService: ConsistDataService,
    private userFaultService: UserFaultDatabaseService,
    private uiState: UiStateModelManager
  ) {
    super();
  }

  protected createContext(id: string): UserFaultEditorContext {
    const context = new UserFaultEditorContext();
    context.uiState = new UiStateModelManager();
    context.uiState.getStateModel<UserFaultEditorUiState>('list', () => ({
      filters: {
        groups: [],
        search: '',
        selectedFilters: new SelectedFilterArray<UserFaultEditorFilterType>()
      }
    }));
    const trainMan = new TrainConsistManager(this.consistDataService);
    context.consists = trainMan;
    context.otherUserFaultNames$ = this.userFaultService.data().pipe(
      map(userFaults => userFaults?.filter(uf => uf.id !== id)?.map(uf => uf.displayName) ?? [])
    );
    // context.userFault$ is set in ```UserFaultEditManager.setEditingContext()```
    // context.selectable$ is set in ```UserFaultEditManager.setEditingContext()```
    // context.unsavedChanges$ is set in ```UserFaultEditManager.setEditingContext()```
    return context;
  }

}
