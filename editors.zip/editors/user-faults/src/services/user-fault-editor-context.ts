/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { SimPropertyGroup } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { Observable } from 'rxjs';
import { EditorUserFault, UserFaultEditorSelection } from '../models/user-fault-editor.model';
import { TrainConsistManager } from '@oksygen-sim-train-libraries/components-services/trains';
import { Context } from '@oksygen-sim-train-libraries/components-services/common';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';


export class UserFaultEditorContext implements Context {

  uiState: UiStateModelManager;
  // Set by the manager (which is a code smell)
  userFault$: Observable<EditorUserFault>;
  otherUserFaultNames$: Observable<string[]>;
  consists: TrainConsistManager;
  simProperties$: Observable<SimPropertyGroup[]>;
  // Set by the manager (which is a code smell)
  selection$: Observable<UserFaultEditorSelection>;
  // Set by the manager (which is a code smell)
  unsavedChanges$: Observable<boolean>;

  destroy(): void {
    this.consists?.destroy();
  }
}
