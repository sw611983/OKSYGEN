/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { cloneDeep, isNil } from 'lodash';
import moment from 'moment';
import { BehaviorSubject, Observable, of, zip } from 'rxjs';
import { catchError, first, map, switchMap, tap } from 'rxjs/operators';

import {
  Dictionary,
  filterTruthy,
  momentToString,
  selfCompletingObservable,
  SelfCompletingObservable,
  shareReplayOne,
  SuperCalled,
  takeOneTruthy
} from '@oksygen-common-libraries/common';
import { camelCaseToSnakeCasePostProcessor, DataAccessService, dateToStringCustomiser, XmlJsonUtil } from '@oksygen-common-libraries/data-access';
import { OK_BUTTON, PromptDialogComponent, PromptDialogData } from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { BaseDataEditorManager, LockDatabaseService } from '@oksygen-sim-train-libraries/components-services/editors';
import { SimPropertiesService, SimProperty, SimPropertyGroup } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { UserFaultDatabaseService } from '@oksygen-sim-train-libraries/components-services/user-faults';

import { EditorUserFault, UserFaultEditorSelection } from '../../models/user-fault-editor.model';
import { toUserFaultXml } from '../../models/user-fault-xml.model';
import { UserFaultEditorContext } from '../../services/user-fault-editor-context';
import { loadUserFault, userFaultEditorActions } from '../../store/user-fault-editor.actions';
import { canRedoUserFault, canUndoUserFault, getSavedUserFaultName, getUserFault, getUserFaultUnsavedChanges } from '../../store/user-fault-editor.selectors';
import { UserFaultEditorState } from '../../store/user-fault-editor.state';
import { TrainType } from '@oksygen-sim-train-libraries/components-services/trains';

// import { momentToString } from '../../../../session-setup/session-setup-utils';

export class UserFaultEditManager extends BaseDataEditorManager<EditorUserFault, UserFaultEditorContext> {
  private userFault: BehaviorSubject<EditorUserFault> = new BehaviorSubject(null);
  private selection: BehaviorSubject<UserFaultEditorSelection> = new BehaviorSubject(null);
  private simProperties: BehaviorSubject<Array<SimPropertyGroup>> = new BehaviorSubject(null);

  public canUndo$: Observable<boolean>;
  public canRedo$: Observable<boolean>;

  constructor(
    public id: string,
    protected store: Store<UserFaultEditorState>,
    private authService: AuthService,
    private dataAccessService: DataAccessService,
    private userFaultService: UserFaultDatabaseService,
    dialog: MatDialog,
    translateService: TranslateService,
    private snackbar: MatSnackBar,
    private readonly zone: NgZone,
    private lockService: LockDatabaseService,
    protected logging: Logging,
    private simPropertiesService: SimPropertiesService
  ) {
    super(translateService, dialog);
    const sub = this.store.select(getUserFaultUnsavedChanges(this.id)).subscribe(unsavedChanges => (this.unsavedChanges = unsavedChanges));
    this.subscription.add(sub);
    this.canUndo$ = this.store.select(canUndoUserFault(this.id));
    this.canRedo$ = this.store.select(canRedoUserFault(this.id));
  }

  override confirmCloseEditor(): Observable<boolean> {
    return of(true);
  }

  setEditingContext(dm: UserFaultEditorContext): void {
    this.context = dm;
    this.subscription.add(
      this.store
        .select(getUserFault(this.id))
        .pipe(filterTruthy())
        .subscribe(uf => {
          this.userFault.next(uf);
          const trainId = this.getTrainId(uf.train);
          this.simProperties.next([
            ...this.simPropertiesService.getUserFaultTrainSimProperties(trainId),
            ...this.simPropertiesService.getUserFaultGroupedVehicleSimProperties(trainId)
          ]);
        })
    );
    // feels like a bit of a code smell setting context properties here rather than the provider
    dm.userFault$ = this.userFault.asObservable();
    dm.selection$ = this.selection.asObservable();
    dm.unsavedChanges$ = this.store.select(getUserFaultUnsavedChanges(this.id));
    dm.simProperties$ = this.simProperties.asObservable().pipe(shareReplayOne());
  }

  newItem(name: string): void {
    this.store.dispatch(userFaultEditorActions.newUserFault({ id: this.id, name }));
  }

  loadItem(item: EditorUserFault): void {
    this.store.dispatch(loadUserFault({ id: this.id, original: item }));
  }

  saveItem(): SelfCompletingObservable<boolean> {
    return this.saveUserFault();
  }

  override saveItemDirect(item: EditorUserFault): SelfCompletingObservable<any> {
    throw new Error('Method not implemented.');
  }

  getItemName(): string {
    return this.userFault?.value?.displayName || '';
  }

  duplicateItem(item: EditorUserFault, newName?: string): SelfCompletingObservable<any> {
    const newFault = cloneDeep(item);
    if (newFault.id !== this.id) {
      newFault.id = this.id;
    }
    newFault.displayName = newName;
    const loggedInUser = this.authService.getLoggedInUser();
    newFault.history.historyLog = [
      {
        type: 'Copied',
        authorFirstName: loggedInUser.firstName,
        authorLastName: loggedInUser.lastName,
        timestamp: momentToString(moment()),
        userFaultName: item.displayName,
        userFaultVersion: item.version
      }
    ];
    newFault.version = 1;
    return this.duplicateUserFault(newFault).pipe(
      catchError(err => selfCompletingObservable(false)),
      tap(result => {
        if (result) {
          this.zone.run(() => { // snackbar needs to run in zone
            this.snackbar.open(this.translateService.instant(t('User Fault Duplicated')), '', { duration: 3000 });
          });
        } else {
          const promptData = new PromptDialogData();
          // FIXME More meaningful message please
          promptData.title = t(`Could not duplicate User Fault`);
          // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
          promptData.content = t('Please contact an administrator.');
          promptData.buttons = OK_BUTTON;
          PromptDialogComponent.open(this.dialog, { id: 'DUPLICATE_FAILED', data: promptData });
        }
      })
    );
  }

  deleteItem(item: EditorUserFault, reload = false): SelfCompletingObservable<any> {
    if (!item || !item.displayName) {
      this.zone.run(() => { // snackbar needs to run in zone
        this.snackbar.open(this.translateService.instant(t('User Fault not found')), '', { duration: 5000 });
      });
      return of();
    }
    return UserFaultEditManager.deleteUserFault(this.dataAccessService, item).pipe(
      catchError(err => selfCompletingObservable(false)),
      tap(destroyed => {
        if (destroyed && reload) {
          this.userFaultService.reloadData();
        }
      }),
      tap(result => {
        if (result) {
          this.zone.run(() => { // snackbar needs to run in zone
            this.snackbar.open(this.translateService.instant(t('User Fault Deleted')), '', { duration: 3000 });
          });
        } else {
          const promptData = new PromptDialogData();
          // FIXME More meaningful message please
          promptData.title = t(`Could not destroy User Fault`);
          // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
          promptData.content = t('Please contact an administrator.');
          promptData.buttons = OK_BUTTON;
          PromptDialogComponent.open(this.dialog, { id: 'DESTROY_FAILED', data: promptData });
        }
      })
    );
  }

  get data$(): Observable<EditorUserFault> {
    return this.userFault.asObservable();
  }

  override destroy(): SuperCalled {
    this.userFault.complete();
    this.simProperties.complete();
    this.selection.complete();
    this.store.dispatch(userFaultEditorActions.userFaultClosed({ id: this.id }));
    return super.destroy();
  }

  /**
   * Saving a user fault will automatically reload the data and show success / failure snackbars.
   */
  public save(): SelfCompletingObservable<boolean> {
    return this.validateUserFault().pipe(
      switchMap(errors => {
        if (errors.length) {
          this.snackbar.open(
            this.translateService.instant(t('Cannot save the user fault. There are items that require your attention.')),
            this.translateService.instant(t('Dismiss'))
          );
          let errorMessage = '';
          errors.forEach(err => {
            errorMessage = errorMessage + '\n' + err;
         });
          this.logging.error('Cannot save the user fault\n' + errorMessage);
          return of(false);
        }
        return this.saveUserFault().pipe(
          catchError(err => selfCompletingObservable(false)),
          tap(result => {
            this.displaySaveResult(result);
          })
        );
      })
    );
  }

  public undo(): void {
    this.store.dispatch(userFaultEditorActions.userFaultUndo({ id: this.id }));
  }

  public redo(): void {
    this.store.dispatch(userFaultEditorActions.userFaultRedo({ id: this.id }));
  }

  public selectProperty(simPropertyName: string, group: string): void {
    this.selection.next({simPropertyName, group});
  }

  public selectPropertyClear(): void {
    this.selection.next(null);
  }

  public addFault(simProperty: SimProperty, group: string): void {
    this.store.dispatch(userFaultEditorActions.addFault({id: this.id, simProperty, simPropertyGroup: group }));
  }

  public updateFault(userFaultState: string, simPropertyName: string, group: string, name: string|number, value: any): void {
    this.store.dispatch(userFaultEditorActions.updateFault({id: this.id, userFaultState, simPropertyName, simPropertyGroup: group, name, value }));
  }

  public updateFaultVehicle(simPropertyName: string, group: string, vehiclePosition: number): void {
    this.store.dispatch(userFaultEditorActions.updateFaultVehicle({id: this.id, simPropertyName, simPropertyGroup: group , vehiclePosition}));
  }

  public deleteProperty(simPropertyName: string, group: string): void {
    this.store.dispatch(userFaultEditorActions.deleteProperty({id: this.id, simPropertyName, simPropertyGroup: group }));
  }

  public deleteSelectedProperty(): void {
    const selected = this.selection.getValue();
    this.store.dispatch(userFaultEditorActions.deleteProperty({
      id: this.id, simPropertyName: selected.simPropertyName, simPropertyGroup: selected.group
    }));
  }

  public addMonitor(simProperty: SimProperty, group: string): void {
    this.store.dispatch(userFaultEditorActions.addMonitor({id: this.id, simProperty, simPropertyGroup: group }));
  }

  public updateMonitorVehicle(simPropertyName: string, group: string, vehiclePosition: number): void {
    this.store.dispatch(userFaultEditorActions.updateMonitorVehicle({id: this.id, simPropertyName, simPropertyGroup: group , vehiclePosition}));
  }

  public setName(name: string): void {
    name = name ?? '';
    if (this.userFault.getValue()?.displayName !== name) {
      this.store.dispatch(userFaultEditorActions.setUserFaultName({ id: this.id, name }));
    }
  }

  /**
   * WARNING: setting a new train will WIPE your faults & events + monitored properties!
   *
   * @param train the new train (consist)
   */
  public setTrain(train: string): void {
    const prevTrain = this.userFault.getValue()?.train;

    if (isNil(prevTrain) && isNil(train)) {
      return;
    }

    train = train ?? '';

    const sameTrainType = this.getTrainType(prevTrain) === this.getTrainType(train);

    if(prevTrain !== train){
      this.store.dispatch(userFaultEditorActions.setUserFaultTrain({ id: this.id, train, sameTrainType }));
    }
  }

  private getTrainType(trainName: string): TrainType {
    if(trainName)
    {
      return this.context?.consists?.consists?.find( consist => consist.name === trainName).trainType ?? null;
    }
    return null;
  }

  private getTrainId(trainName: string): number {
    if (trainName) {
      return this.context?.consists?.consists?.find(consist => consist.name === trainName).id ?? null;
    }
    return null;
  }

  public setCause(cause: string): void {
    cause = cause ?? '';
    if (this.userFault.getValue()?.cause !== cause) {
      this.store.dispatch(userFaultEditorActions.setUserFaultCause({ id: this.id, cause }));
    }
  }

  public setConsequence(consequence: string): void {
    consequence = consequence ?? '';
    if (this.userFault.getValue()?.consequence !== consequence) {
      this.store.dispatch(userFaultEditorActions.setUserFaultConsequence({ id: this.id, consequence }));
    }
  }

  public setTroubleshooting(troubleshooting: string): void {
    troubleshooting = troubleshooting ?? '';
    if (this.userFault.getValue()?.troubleshooting !== troubleshooting) {
      this.store.dispatch(userFaultEditorActions.setUserFaultTroubleshooting({ id: this.id, troubleshooting }));
    }
  }

  private duplicateUserFault(userFault: EditorUserFault): SelfCompletingObservable<boolean> {
    const user = this.authService.getLoggedInUser();
    const userFaultXml = toUserFaultXml(null, userFault, user);
    const xml = XmlJsonUtil.convertObjectToXmlWith(
      userFaultXml,
      'user_fault',
      {
        customisers: [dateToStringCustomiser],
        postProcessors: [camelCaseToSnakeCasePostProcessor]
    });
    const successPreProcess = (): void => {};
    const successPostProcess = (): void => {
      this.userFaultService.reloadData();
    };
    successPostProcess.bind(this);
    return this.doUserFaultSave(userFault, xml, this.dataAccessService, successPreProcess, successPostProcess);
  }

  private saveUserFault(): SelfCompletingObservable<boolean> {
    const oldUserFault$ = this.userFaultService.getUserFault(this.id);
    const userFault$ = this.userFault.asObservable();
    const savedName$ = this.store.select(getSavedUserFaultName(this.id));
    return zip(
      oldUserFault$.pipe( first() ),
      userFault$.pipe( takeOneTruthy() ),
      savedName$.pipe( first() )
    ).pipe(
      switchMap(([oldUserFault, userFault, savedName]) => {
        const user = this.authService.getLoggedInUser();
        const updatedUserFault = cloneDeep(userFault);
        if(oldUserFault) {
          updatedUserFault.version = oldUserFault.version + 1;
        } else {
          if (this.lockService.isEnabled('userFault')) {
            const lock = this.lockService.createLockData(updatedUserFault.id, 'userFault'); // FIXME magic string
            this.lockService.addDatabaseLock(lock);
          }
        }
        const userFaultXml = toUserFaultXml(oldUserFault, updatedUserFault, user);
        const xml = XmlJsonUtil.convertObjectToXmlWith(
          userFaultXml,
          'user_fault',
          {
            customisers: [dateToStringCustomiser],
            postProcessors: [camelCaseToSnakeCasePostProcessor]
        });
        const successPreProcess = (): void => {};

        const successPostProcess = (): void => {
          this.userFaultService.reloadData();
        };
        successPostProcess.bind(this);

        // delete old user fault when it's renamed
        if (!!savedName && savedName !== updatedUserFault.displayName) {
          return UserFaultEditManager.deleteUserFault(this.dataAccessService, oldUserFault).pipe(
            catchError(() => selfCompletingObservable(false)),
            // will receive success/failure either directly from the deleteScenario, or the catchError
            switchMap(success => {
              if (success) {
                return this.doUserFaultSave(updatedUserFault, xml, this.dataAccessService, successPreProcess, successPostProcess);
              }

              return selfCompletingObservable(false);
            })
          );
        } else {
          return this.doUserFaultSave(updatedUserFault, xml, this.dataAccessService, successPreProcess, successPostProcess);
        }
      })
    );
  }

  /**
   * Validate a user fault, and return a list of errors (empty if valid).
   *
   * @param userFault the user fault to validate
   * @param otherUserFaults other user faults
   * @param simPropertyGroups
   * @param consists
   */
  private validateUserFault(): Observable<string[]> {
    return zip(
      this.context.userFault$,
      this.context.otherUserFaultNames$,
      this.context.simProperties$,
      of(this.context.consists.consists)
    ).pipe(
      map(([userFault, names, groups, consists]) => {
        const errors: string[] = [];
        const EMPTY = 'User fault is empty.';
        const NO_TRAIN = 'Must set train.';
        if (!userFault) { errors.push(this.translateService.instant(t(EMPTY))); }
        if(!userFault.displayName) { errors.push(this.translateService.instant(t('User fault must have a name.'))); }
        const existingName = names.find(ouf => ouf === userFault.displayName);
        if (existingName) { errors.push(this.translateService.instant(t('User fault name {displayName} is taken.'), { displayName: userFault.displayName})); }
        if (!userFault.train) { errors.push(this.translateService.instant(t(NO_TRAIN))); }
        const consist = consists.find(c => c.name === userFault.train);
        if (!consist) { errors.push(this.translateService.instant(t('Train {userFaultTrain} does not exist.'), {userFaultTrain: userFault.train})); }
        for (const state of userFault.userFaultStates?.userFaultState ?? []) {
          for (const msp of state?.mappedSimProperties?.mappedSimProperty ?? []) {
            const simProp = groups?.find(g  => g.name === msp.group)
              ?.simProperty?.find(sp => sp.name === msp.name);
            const isNamedState = state?.name === 'Set' || state?.name === 'Cleared';
            if(simProp?.valueType === 'ENUMERATED' && isNamedState) {
              if (!simProp && !simProp.valueType) { errors.push(this.translateService.instant(t('property {mspName} does not exist.'), {mspName: msp.name})); }

              if (simProp.provider === 'vehicle' && msp.vehiclePosition === undefined) {
                errors.push(
                  this.translateService.instant(t(`Please select a vehicle for {mspName} {stateName}.`), { mspName: msp.name, stateName: state?.name ?? '' })
                );
              }
              if (msp.value === undefined || msp.value === null && !simProp.valueType) {
                errors.push(this.translateService.instant(t(`Please select a value for {mspName} {stateName}`), { mspName: msp.name, stateName: state.name }));
              }
            }
          }
        }
        for (const monProp of userFault.monitoredSimProperties?.simProperty ?? []) {
          const simProp = groups?.find(g  => g.name === monProp.group)
            ?.simProperty?.find(sp => sp.name === monProp.name);
          if (!simProp) { errors.push(this.translateService.instant(t('property {monPropName} does not exist'), {monPropName: monProp.name})); }
        }
        return errors;
      })
    );
  }

  private displaySaveResult(result: boolean): void {
    if (result) {
      this.zone.run(() => { // snackbar needs to run in zone
        this.snackbar.open(this.translateService.instant(t('User Fault Saved')), '', { duration: 3000 });
      });
    } else {
      const promptData = new PromptDialogData();
      // FIXME More meaningful message please
      promptData.title = t(`Could not save User Fault`);
      // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
      promptData.content = t('Please contact an administrator.');
      promptData.buttons = OK_BUTTON;
      PromptDialogComponent.open(this.dialog, { id: 'SAVE_FAILED', data: promptData });
    }
  }

  private static deleteUserFault(dataAccessService: DataAccessService, userFault: EditorUserFault): SelfCompletingObservable<any> {
    return dataAccessService.callQueryJson({
      query: 'delete_user_fault',
      debugMsg: `Deleting user fault ${userFault.displayName}`,
      parameters: { id: userFault.id }
    });
  }

  /**
   * This is called by both duplicateUserFault and doSaveUserFault
   */
  private doUserFaultSave(
    userFault: EditorUserFault,
    xml: string,
    dataAccessService: DataAccessService,
    successPreProcess: () => void,
    successPostProcess: () => void
  ): SelfCompletingObservable<any> {
    successPreProcess();
    const savePath = `/user_faults/${userFault.displayName}.xml`;

    const dictionary: Dictionary<string> = {};
    dictionary.xmlContent = xml;
    dictionary.savePath = savePath;
    dictionary.id = userFault.id;
    dictionary.userId = this.authService.getLoggedInUser().id;

    return this.dataAccessService.callQueryJsonPost(
      {
        query: 'update_user_fault.xq',
        parameters: dictionary,
        operation: 'update_user_fault.xq',
        debugMsg: `Updating User Fault ${userFault.id}`
      }
    )
    .pipe(
      tap(result => {
        if(result) {
          this.store.dispatch(userFaultEditorActions.saveUserFault({ id: this.id, save: userFault }));
          successPostProcess();
        }
      })
    );
  }
}
