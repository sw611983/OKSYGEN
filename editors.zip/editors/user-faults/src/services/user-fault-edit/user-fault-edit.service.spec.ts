/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { TestBed } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainUserFaultEditModule } from '../../user-fault.module';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserFaultEditService } from './user-fault-edit.service';

describe('UserFaultEditService', () => {
  let service: UserFaultEditService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainUserFaultEditModule],
      providers: [MatSnackBar]
    });
    service = TestBed.inject(UserFaultEditService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
