/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable, NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LmsService } from '@oksygen-sim-core-libraries/components-services/lms';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { EditorManagementService, LockDatabaseService } from '@oksygen-sim-train-libraries/components-services/editors';
import { EditorUserFault } from '../../models/user-fault-editor.model';
import { UserFaultEditManager } from './user-fault-edit.manager';
import { UserFaultEditorState } from '../../store/user-fault-editor.state';
import { UserFaultEditorContext } from '../user-fault-editor-context';
import { UserFaultDatabaseService } from '@oksygen-sim-train-libraries/components-services/user-faults';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

@Injectable()
export class UserFaultEditService extends EditorManagementService<
  UserFaultEditorState, EditorUserFault, UserFaultEditorContext, UserFaultEditManager
> {

  private monPropertiesEnabled;
  constructor(
    dataAccessService: DataAccessService,
    authService: AuthService,
    store: Store<UserFaultEditorState>,
    registry: Registry,
    logger: Logging,
    lmsService: LmsService,
    dialog: MatDialog,
    translateService: TranslateService,
    snackbar: MatSnackBar,
    zone: NgZone,
    private userFaultService: UserFaultDatabaseService,
    private lockService: LockDatabaseService,
    private simPropertiesService: SimPropertiesService
  ) {
    super(
      dataAccessService, authService, store, registry, logger, lmsService,
      dialog, translateService, snackbar, zone, userFaultService
    );
    this.monPropertiesEnabled = this.registry.getBoolean('editor.userFault.monitorPropertiesEnabled', false);
  }
  newManager(id: string | number): UserFaultEditManager {
    return new UserFaultEditManager(
      `${id}`,
      this.store,
      this.authService,
      this.dataAccessService,
      this.userFaultService,
      this.dialog,
      this.translateService,
      this.snackbar,
      this.zone,
      this.lockService,
      this.logger,
      this.simPropertiesService
      );
  }

  public monitorPropertiesEnabled(): boolean {
    return this.monPropertiesEnabled;
  }

  duplicate(item: EditorUserFault): SelfCompletingObservable<EditorUserFault> {
    throw new Error('Method not implemented.');
  }
}
