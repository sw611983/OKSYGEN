/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, combineLatest, Observable, of, Subscription } from 'rxjs';
import { first } from 'rxjs/operators';

import { SuperCalled } from '@oksygen-common-libraries/common';
import {
  allFilterTypesMatch,
  BasicSingleInputDialogComponent,
  BasicSingleInputDialogData,
  BasicSingleInputDialogInput,
  BasicTabNavItem,
  BasicTabNavItemComponent,
  Breadcrumb,
  ButtonInfo,
  CANCEL_BUTTON,
  FileManagerTableComponent,
  FileManagerTableData,
  Filter,
  filterMatches,
  illegalNameCharacterExists,
  newFormControl,
  SelectedFilterArray,
  SideNavService,
  TabGroupChild,
  TabService,
  UpdateOn
} from '@oksygen-common-libraries/material/components';
import { MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { User, UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import {
  BrowserFilterText,
  BrowserState,
  deleteDialog,
  EditorBrowserFilterIOConfig,
  newName
} from '@oksygen-sim-train-libraries/components-services/common';
import { BaseLockableBrowserTabPage, EditorLock, LockDatabaseService } from '@oksygen-sim-train-libraries/components-services/editors';
import { Consist, ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { UserFaultDatabaseService } from '@oksygen-sim-train-libraries/components-services/user-faults';

import {
  EditorUserFault,
  FAULTS_CARD_DATA,
  UserFaultEditorTabType,
  UserFaultTableData,
  userFaultToTable
} from '../models/user-fault-editor.model';
import { UserFaultBrowserService } from '../services/user-fault-browser.service';
import { UserFaultEditService } from '../services/user-fault-edit/user-fault-edit.service';
import { UserFaultEditorContextManager } from '../services/user-fault-editor-context.manager';

interface UserFaultFilterFields extends BrowserFilterText {
  authorText: string;
  faultText: string;
}

enum UserFaultFilterIcons {
  // names of the icons in the filtering of user faults
  TRAIN = 'train',
  FAULT = 'exclamation_triangle',
  AUTHOR = 'author'
}

/**
 * To be used when multiple user faults are selected and to be deleted
 *
 * @param userFaultsName The names of the user faults to delete
 * @returns A dialog data object for the confirmation dialog
 */

// some more work is required to get the filtering stuff done properly - it's a bit of a mess at the moment
@Component({
  selector: 'oksygen-user-fault-browser',
  templateUrl: './user-fault-browser.component.html',
  styleUrls: ['./user-fault-browser.component.scss']
})
export class UserFaultBrowserComponent
  extends BaseLockableBrowserTabPage<EditorUserFault, UserFaultTableData, UserFaultFilterFields, /*UserFaultFilterIcons*/ string>
  implements OnInit, OnDestroy
{
  readonly DEFAULT_FAULT_TEMPLATE_NAME: string = t('New user fault');
  readonly DUPLICATE_FAULT_NAME_ERROR: string = t('A user fault with this name already exists.');
  readonly MISSING_FAULT_NAME_ERROR: string = t('A user fault name is required.');
  readonly SPACES_FAULT_NAME_ERROR: string = t('A user fault name cannot have leading or trailing spaces.');
  readonly SPECIAL_CHARACTER_FAULT_NAME_ERROR: string = t('A user fault name cannot have the special characters " < % > * | ? :');
  readonly BREADCRUMB: Breadcrumb = {
    text: t('User Faults'),
    icon: 'exclamation_triangle'
  };

  @ViewChild(FileManagerTableComponent) fileManagerTable: FileManagerTableComponent<UserFaultTableData>;

  private masterSubscription = new Subscription();

  consists: Consist[];
  selectedConsist: Consist;
  monitorPropertiesEnabled: boolean;

  constructor(
    public userFaultBrowserService: UserFaultBrowserService,
    private userFaultDatabaseService: UserFaultDatabaseService,
    sideNavService: SideNavService,
    router: Router,
    tabService: TabService,
    logger: Logging,
    private registry: Registry,
    private userService: UserService,
    private uiStateModelManager: UiStateModelManager,
    private userFaultEditService: UserFaultEditService,
    translateService: TranslateService,
    private consistService: ConsistDataService,
    private dataService: UserFaultEditorContextManager,
    private dialog: MatDialog,
    private cd: ChangeDetectorRef,
    lockService: LockDatabaseService,
    authService: AuthService
  ) {
    super(
      {
        create: { visible: true, enabled: true },
        delete: { visible: true, enabled: true },
        duplicate: { visible: true, enabled: true },
        edit: { visible: false, enabled: false },
        open: { visible: true, enabled: true },
        search: { visible: true, enabled: true },
        refresh: { visible: true, enabled: true }
      },
      userFaultBrowserService,
      sideNavService,
      router,
      FAULTS_CARD_DATA,
      tabService,
      logger,
      translateService,
      lockService,
      authService,
      dialog
    );
    this.monitorPropertiesEnabled = this.userFaultEditService.monitorPropertiesEnabled();
    this.refreshDisabled.set(false);
    this.sorter.sortFunction = this.sorterFunction.bind(this);
  }

  override ngOnInit(): SuperCalled {
    const superCalled = super.ngOnInit();
    this.pageOpening();
    this.loadLocks(this.registry);
    // this.userFaultDatabaseService.reloadData();
    this.state = this.uiStateModelManager.getStateModel</*BrowserState<UserFaultFilterFields, string>*/ any>('UserFaultBrowserComponent', () => ({
      filters: {
        authorText: '',
        faultText: '',
        selectedFilters: new SelectedFilterArray<string>()
      }
    }));
    const dataSub = combineLatest([
      this.userFaultDatabaseService.data(),
      this.lockService.getEditorLocks(this.editorName())
    ]).subscribe(([userFaults, locks]) => {
      this.data.set(userFaults);
      this.locks.set(locks ?? []);
      this.cd.detectChanges(); // updating the file manager double triggers CD which gives the changed after checked err
      // If you apply the filter before, it does not get applied when switching tabs and coming back if you comment the reloadData just above
      this.fileManagerTable?.applyFilter();
    });
    // const dataSub = this.userFaultDatabaseService.data().subscribe(userFaults => {
    //   this.data = userFaults;

    //   this.tableData = this.toTableData(userFaults);
    //   this.cd.detectChanges(); // updating the file manager double triggers CD which gives the changed after checked err
    //   // If you apply the filter before, it does not get applied when switching tabs and coming back if you comment the reloadData just above
    //   this.fileManagerTable?.applyFilter();
    // });
    const consistSub = this.consistService.data().subscribe(consists => {
      this.consists = consists;
    });
    this.masterSubscription.add(consistSub);
    this.masterSubscription.add(dataSub);

    const faultsTab: TabGroupChild<BasicTabNavItem> = {
      data: {
        id: FAULTS_CARD_DATA.id,
        groupId: FAULTS_CARD_DATA.id,
        icon: 'file_manager',
        routerLink: FAULTS_CARD_DATA.routerLink,
        name: t('Manager'),
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => of(true),
        onClose: () => {
          this.tabClosing();
          this.clearFilters();
        }
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: FAULTS_CARD_DATA.id,
        groupName: FAULTS_CARD_DATA.name,
        route: FAULTS_CARD_DATA.routerLink,
        // groupIcon: FAULTS_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [faultsTab],
      childrenIndex: 0
    });
    return superCalled;
  }

  ngOnDestroy(): void {
    this.pageClosing();
    this.setSelectedTableData();
    this.masterSubscription.unsubscribe();
  }

  sorterFunction(userFaultKey: string, a: UserFaultTableData, b: UserFaultTableData): number {
    switch (userFaultKey) {
      case 'name': {
        return a.name.localeCompare(b.name, this.getCurrentLocale());
      }
      case 'train': {
        return a.train.localeCompare(b.train, this.getCurrentLocale());
      }
      case 'created': {
        return a.created.date.isBefore(b.created.date) ? 1 : -1;
      }
      case 'modified': {
        return a.modified.date.isBefore(b.modified.date) ? 1 : -1;
      }
      case 'status': {
        return a.status.localeCompare(b.status, this.getCurrentLocale());
      }
      default: {
        return 0;
      }
    }
  }

  override editorName(): string {
    return 'userFault';
  }

  onImport(): void {
    throw new Error('Method not implemented.');
  }
  onExport(): void {
    throw new Error('Method not implemented.');
  }
  onPrint(item: EditorUserFault | EditorUserFault[]): void {
    throw new Error('Method not implemented.');
  }

  onRefresh(): void {
    this.userFaultDatabaseService.reloadData();
    this.loadLocks(this.registry);
  }

  override onUnlock(): void {
    this.lockService.deleteDatabaseLock(this.selectedLock.id, this.selectedLock.editor).subscribe(() => this.loadLocks(this.registry));
  }

  onEdit(item: EditorUserFault): void {
    this.userFaultEditService.loadItem(item);
    this.startEditing(item.id);
  }

  onDelete(item: EditorUserFault | EditorUserFault[]): void {
    const items = Array.isArray(item) ? item : [item];
    const title = items.length > 1 ? 'Are you sure you want to delete these user faults?' : 'Are you sure you want to delete this user fault?';
    const content = items.length > 1 ? items.map(s => s.displayName).reduce((p, n) => `${p}<br />${n}`) : `<b>${this.selectedItem().displayName}</b>`;
    deleteDialog(title, content, this.dialog).subscribe(result => {
      if (!result) { return; }
      this.userFaultEditService.deleteItems(items, true).subscribe(results => {
        // It returns a string if it succeeded, false if it failed
        if (results) {
          items.forEach(deletedItem => {
            if (this.tabService.getTabGroupItem(FAULTS_CARD_DATA.id, deletedItem.id.toString())) {
              this.tabService.removeItemFromTabGroup(FAULTS_CARD_DATA.id, { id: deletedItem.id.toString() }, true);
            }
          });
        }
      });
    });
  }

  onDuplicate(item: EditorUserFault): void {
    this.promptDuplicateName(item)
      .pipe(first())
      .subscribe(name => {
        this.userFaultEditService.duplicateItem(item, name);
      });
  }

  onCreate(): void {
    const existingNames = this.tableData().map(td => td.name);
    const name = newName('New User Fault', this.translateService, existingNames);
    this.userFaultEditService.newItem(name).then(id => this.startEditing(id));
  }

  initialiseFilterConfig(): EditorBrowserFilterIOConfig<any>[] {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;
    const faultFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: UserFaultFilterIcons.FAULT,
        placeholder: 'User faults',
        value: this.state.filters.faultText
      },
      outputs: {
        currentValue: this.onFaultTextChange.bind(self),
        selectedValue: this.addFaultFilter.bind(self)
      }
    };
    const authorFilter: EditorBrowserFilterIOConfig<User> = {
      inputs: {
        icon: 'author',
        placeholder: 'Author',
        value: this.state.filters.authorText
      },
      outputs: {
        currentValue: this.onAuthorTextChange.bind(self),
        selectedValue: this.addAuthorFilter.bind(self)
      }
    };
    const filterConfig: EditorBrowserFilterIOConfig<any>[] = [faultFilter, authorFilter];
    return filterConfig;
  }

  initialiseColumns(): FileManagerTableData[] {
    const columns: FileManagerTableData[] = [];
    return columns;
  }

  initialiseDisplayedColumns(): string[] {
    const columns: string[] = ['name', 'train', 'created', 'modified', 'status' /*, 'version'*/];
    return columns;
  }

  toTableData(data: EditorUserFault[], locks?: EditorLock[]): UserFaultTableData[] {
    const tableData: UserFaultTableData[] =
      data?.map(userFault => {
        const locked = !!locks?.find(lock => lock.editor === this.editorName() && lock.id === userFault.id);
        const tablified = userFaultToTable(this.userService, userFault, locked);
        const selectedData = this.editorService.getSelectedTableData()?.find(selected => selected?.name === userFault.displayName);
        tablified.fmtChecked = !!selectedData?.fmtChecked;
        tablified.fmtSelected = !!selectedData?.fmtSelected;
        return tablified;
      }) ?? [];
    return tableData;
  }

  onFilterChange(): void {
    this.fileManagerTable.applyFilter();
  }

  onFaultTextChange(text: string): void {
    this.state.filters.faultText = text;
    this.fileManagerTable.applyFilter();
  }

  onAuthorTextChange(text: User | string): void {
    this.state.filters.authorText = typeof text === 'object' ? `${text.firstName} ${text.lastName}` : text;
    this.fileManagerTable.applyFilter();
  }

  addAuthorFilter(value: User): void {
    const name = typeof value === 'object' ? `${value.firstName} ${value.lastName}` : value;
    this.state.filters.selectedFilters.push(new Filter(UserFaultFilterIcons.AUTHOR, name));
    this.fileManagerTable.applyFilter();
  }

  addFaultFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(UserFaultFilterIcons.FAULT, value));
    this.fileManagerTable.applyFilter();
  }

  applyFilters(fault: UserFaultTableData): boolean {
    const names = [fault.name];
    const authors = [fault.created?.name, fault.modified?.name];

    if (
      !allFilterTypesMatch(
        [
          { t: UserFaultFilterIcons.FAULT, v: names },
          { t: UserFaultFilterIcons.AUTHOR, v: authors }
        ],
        this.state.filters.selectedFilters
      )
    ) {
      return false;
    }

    if (!filterMatches(names, this.state.filters.faultText)) {
      return false;
    }

    if (!filterMatches(authors, this.state.filters.authorText)) {
      return false;
    }

    return true;
  }

  override selectionChanged(): void {
    this.detailEditDisabled.set(false);
    this.detailDeleteDisabled.set(false);
    super.selectionChanged();
    if (this.selectedCount() === 1) {
      this.selectedConsist = this.consists?.find(c => c.name === this.selectedItem().train);
    } else {
      this.selectedConsist = null;
    }
  }

  protected getItemFromTableItem(data: UserFaultTableData): EditorUserFault {
    if (!data || !this.data) {
      return null;
    }
    // displayName must be unique!
    return this.data().find(userFault => userFault.displayName === data.name);
  }

  private startEditing(id: string): void {
    // FIXME magic string
    // FIXME copy pasted
    const url = `/editors/user-faults/${id}`;
    this.router.navigateByUrl(url);
    const userFaultTabData: UserFaultEditorTabType = {
      data: {
        groupId: FAULTS_CARD_DATA.id,
        icon: 'file_new',
        id: id.toString(),
        routerLink: url,
        name: id === this.selectedItem()?.id ? this.selectedItem()?.displayName : t('New User Fault'),
        destroyGroupOnAllCleared: true,
        // FIXME @@@ implement confirm/save dialog
        preCloseCheck: () => this.userFaultEditService.confirmCloseEditor(id),
        onClose: () => this.destroyManagers(id)
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: FAULTS_CARD_DATA.id,
        groupName: FAULTS_CARD_DATA.name,
        route: FAULTS_CARD_DATA.routerLink,
        groupIcon: FAULTS_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [userFaultTabData]
    });
    this.lockEditorItem(id);
  }

  private destroyManagers(id: string): void {
    // TODO context manager
    this.userFaultEditService.destroyManagers(id);
    this.dataService.destroyContext(id);
    if (this.lockService.isEnabled(this.editorName())) {
      this.lockService.deleteDatabaseLock(id, this.editorName()).subscribe(() => this.loadLocks(this.registry));
    }
  }

  private promptDuplicateName(userFault: EditorUserFault): Observable<string> {
    const existingNames = this.data().map(s => s.displayName);
    const name = newName(`${userFault.displayName} - ${this.COPY}`, this.translateService, existingNames);
    const duplicateNameError = 'duplicateName';
    const missingError = 'missing';
    const spacesError = 'spaces';
    const specialCharacterError = 'specialCharacter';
    const duplicateFormControl = newFormControl(UpdateOn.CHANGE, c => {
      if (c.value) {
        const match = this.data().find(s => s.displayName === c.value);
        const exists = !!match;
        if (exists) {
          return { [duplicateNameError]: true };
        } else if (c.value?.trim() !== c.value) {
          return { [spacesError]: true };
        } else if (illegalNameCharacterExists(c.value)) {
          return { [specialCharacterError]: true };
        }
      } else {
        return { [missingError]: true };
      }
      return null;
    });

    duplicateFormControl.setValue(name);
    const buttons: ButtonInfo[] = [
      CANCEL_BUTTON,
      {
        color: MaterialThemePalette.PRIMARY,
        text: t('Duplicate'),
        data: true,
        disableOnError: true
      }
    ];
    const input: BasicSingleInputDialogInput = {
      appearance: 'outline',
      floatLabel: 'always',
      label: t('Name'),
      inputFormControl: duplicateFormControl,
      formControlErrors: [
        // TODO: Possibly put these two messages in a shared place
        // (they're copied from rule-browser.component which is itself copied from scenario-detail-panel)
        {
          type: duplicateNameError,
          text: this.DUPLICATE_FAULT_NAME_ERROR
        },
        {
          type: missingError,
          text: this.MISSING_FAULT_NAME_ERROR
        },
        {
          type: spacesError,
          text: this.SPACES_FAULT_NAME_ERROR
        },
        {
          type: specialCharacterError,
          text: this.SPECIAL_CHARACTER_FAULT_NAME_ERROR
        }
      ]
    };
    const data = new BasicSingleInputDialogData(t('Duplicate'), buttons, input);
    return new Observable(o => {
      BasicSingleInputDialogComponent.open(this.dialog, data, result => {
        if (result?.buttonData) {
          o.next(result.value);
          o.complete();
        }
      });
    });
  }

  protected initialiseState(): BrowserState<UserFaultFilterFields, UserFaultFilterIcons> {
    return this.uiStateModelManager.getStateModel</*BrowserState<UserFaultFilterFields, string>*/ any>('UserFaultBrowserComponent', () => ({
      filters: {
        authorText: '',
        faultText: '',
        selectedFilters: new SelectedFilterArray<string>()
      }
    }));
  }

  onPublish(item: EditorUserFault | EditorUserFault[], isActive: boolean): void {
    throw new Error('Method not implemented.');
  }
}
