/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import moment from 'moment';

import { HISTORY_TYPE_CREATED, HISTORY_TYPE_MODIFIED, momentToString } from '@oksygen-common-libraries/common';
import { User } from '@oksygen-sim-core-libraries/components-services/users';

import { handleUnknownXmlData } from '@oksygen-sim-train-libraries/components-services/common';

import { EditorMonitoredSimProperties, EditorUserFault, EditorUserFaultHistoryLog, EditorUserFaultStates } from './user-fault-editor.model';

class UserFaultXml {
  id: string;
  version: number;
  displayName: string;
  train: string;
  cause: string;
  consequence: string;
  troubleshooting: string;
  userFaultStates?: UserFaultStatesXml;
  monitoredSimProperties?: MonitoredSimPropertiesXml;
  history?: {
    historyLog: {
      $: {
        type: string;
        authorFirstName: string;
        authorLastName: string;
        userFaultName: string;
        userFaultVersion: number;
        timestamp: string;
      };
    }[];
  };
  rawValue: string;

  /**
   * Creates a dummy object, with all fields being a valid object, so that the for/in loop works
   */
  static createForKnownKeysHandling(): UserFaultXml {
    const xml = new UserFaultXml();

    xml.id = '';
    xml.displayName = '';
    xml.train = '';
    xml.version = 1;
    xml.cause = '';
    xml.consequence = '';
    xml.troubleshooting = '';
    xml.history = {} as any; // don't need to create a full object, just a non-null value
    xml.userFaultStates = {} as any; // don't need to create a full object, just a non-null value
    xml.monitoredSimProperties = {} as any; // don't need to create a full object, just a non-null value
    xml.rawValue = '';
    return xml;
  }
}

interface UserFaultStatesXml {
  userFaultState: UserFaultStateXml[];
}

interface UserFaultStateXml {
  name: string;
  mappedSimProperties: MappedSimPropertiesXml;
}

interface MappedSimPropertiesXml {
  mappedSimProperty: UserFaultSimPropertyXml[];
}

interface MappedSimPropertyXml {
  name: string;
  group: string;
  vehiclePosition?: number;
}

interface UserFaultSimPropertyXml extends MappedSimPropertyXml {
  stateName?: string|number;
  value?: any;
}

interface MonitoredSimPropertiesXml {
  simProperty: MappedSimPropertyXml[];
}

export function toUserFaultXml(oldUserFault: EditorUserFault, newUserFault: EditorUserFault, user: User): UserFaultXml {
  // FIXME copied this fixme block from scenario-xml.model.ts
  // FIXME Added as a result of INTOSC-8817.
  // Possibly we want to retain this test after the bug is fixed; in that case determine the right course of action here.
  if (!user) {
    user = {firstName: 'Unknown', lastName: 'User', id: ''};
    console.log('NO USER SET WHILE SAVING A SCENARIO. This seems incorrect.');
  }

  const data: UserFaultXml = {
    id: newUserFault.id,
    displayName: newUserFault.displayName,
    version: newUserFault.version,
    train: newUserFault.train,
    cause: newUserFault.cause,
    consequence: newUserFault.consequence,
    troubleshooting: newUserFault.troubleshooting,
    history: { historyLog: [] },
    rawValue: newUserFault.rawValue
  };

  // FIXME history processing is (mostly) generic
  newUserFault.history?.historyLog?.forEach(history => {
    data.history.historyLog.push({
      $: {
        type: history.type,
        authorFirstName: history.authorFirstName,
        authorLastName: history.authorLastName,
        userFaultName: history.userFaultName,
        userFaultVersion: history.userFaultVersion,
        timestamp: history.timestamp
      }
    });
  });

  if (!newUserFault.history || newUserFault.history.historyLog.length === 0) {
    data.history.historyLog.push({
      $: {
        type: HISTORY_TYPE_CREATED,
        authorFirstName: user.firstName,
        authorLastName: user.lastName,
        userFaultName: newUserFault.displayName,
        userFaultVersion: 1,
        timestamp: momentToString(moment())
      }
    });
  } else {
    // add new entries to the start of the array
    data.history.historyLog.unshift({
      $: {
        type: HISTORY_TYPE_MODIFIED,
        authorFirstName: user.firstName,
        authorLastName: user.lastName,
        userFaultName: newUserFault.displayName,
        userFaultVersion: newUserFault.version,
        timestamp: momentToString(moment())
      }
    });
  }
  // Populate the user fault with the latest history log.
  const historyLogArray: EditorUserFaultHistoryLog[] = [];
  data.history?.historyLog.forEach(x => {
    const historyLog: EditorUserFaultHistoryLog = {
      type: x.$.type as 'Created' | 'Modified' | 'Copied',
      authorFirstName: x.$.authorFirstName,
      authorLastName: x.$.authorLastName,
      userFaultName: x.$.userFaultName,
      userFaultVersion: x.$.userFaultVersion,
      timestamp: x.$.timestamp
    };
    historyLogArray.push(historyLog);
  });
  newUserFault.history =  { historyLog: historyLogArray };

  if (newUserFault.userFaultStates.userFaultState.length > 0) {
    data.userFaultStates = toUserFaultStatesXml(newUserFault.userFaultStates);
  }
  if (newUserFault.monitoredSimProperties.simProperty.length > 0) {
    data.monitoredSimProperties = toUserFaultMonitoredProperties(newUserFault.monitoredSimProperties);
  }
  return handleUnknownXmlData(oldUserFault, data, getKnownUserFaultKeys());
}

function getKnownUserFaultKeys(): string[] {
  const knownUserFaultKeys: string[] = [];

  const userFaultXmlObj = UserFaultXml.createForKnownKeysHandling();

  for (const key in userFaultXmlObj) {
    if (Object.prototype.hasOwnProperty.call(userFaultXmlObj, key)) {
      knownUserFaultKeys.push(key);
    }
  }

  return knownUserFaultKeys;
}

function toUserFaultStatesXml(userFaultStates: EditorUserFaultStates): UserFaultStatesXml {
  const states: UserFaultStatesXml = {
    userFaultState: userFaultStates.userFaultState.map(ufs => {
      const mappedSimProperties: MappedSimPropertiesXml = {
        mappedSimProperty: ufs.mappedSimProperties.mappedSimProperty.map(msp => {
          const prop: UserFaultSimPropertyXml = {
            group: msp.group,
            name: msp.name
          };
          if (Object.prototype.hasOwnProperty.call(msp, 'stateName') && !!msp.stateName) { prop.stateName = msp.stateName; }
          if (Object.prototype.hasOwnProperty.call(msp, 'value')) { prop.value = msp.value; }
          if (
            Object.prototype.hasOwnProperty.call(msp, 'vehiclePosition') && typeof msp.vehiclePosition === 'number'
          ) { prop.vehiclePosition = msp.vehiclePosition; }
          return prop;
        })
      };
      const xml: UserFaultStateXml = {
        name: ufs.name,
        mappedSimProperties
      };
      return xml;
    })
  };
  return states;
}

function toUserFaultMonitoredProperties(props: EditorMonitoredSimProperties): MonitoredSimPropertiesXml {
  const monProps: MonitoredSimPropertiesXml = {
    simProperty: props.simProperty.map(sp => {
      const xml: MappedSimPropertyXml = {
        group: sp.group,
        name: sp.name
      };
      if (Object.prototype.hasOwnProperty.call(sp, 'vehiclePosition') && typeof sp.vehiclePosition === 'number') { xml.vehiclePosition = sp.vehiclePosition; }
      return xml;
    })
  };
  return monProps;
}
