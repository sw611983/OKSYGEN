/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Data } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import moment from 'moment';
import { Observable, Observer } from 'rxjs';

import { EditHistory, getLastModified, HISTORY_TYPE_COPIED, HISTORY_TYPE_CREATED, UNKNOWN } from '@oksygen-common-libraries/common';
import { BasicTabNavItem, DynamicComponent, SelectedFilterArray, TabGroupChild } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';

import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { ComponentConfig, EditorBrowserTableData, EditorBrowserTableStatus } from '@oksygen-sim-train-libraries/components-services/common';
import { BaseEditorStoreItem, EditorData } from '@oksygen-sim-train-libraries/components-services/editors';
import { SimProperty, SimPropertyGroup } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { Consist } from '@oksygen-sim-train-libraries/components-services/trains';

export enum UserFaultEditorFilterType {
  // ```no-mat-icon``` prefix prevents the chip list from displaying mat-icons
  PROPERTY = 'no-mat-icon-sim_property',
  GROUP = 'no-mat-icon-group'
}

// internal helper interface
export interface UserFaultDetailPanelPropertyItem {
  name: string;
  vehicle?: string;
  vehiclePosition?: number;
}

export interface UserFaultEditorSelection {
  simPropertyName: string;
  group: string;
}

export interface UserFaultEditorUiState {
  filters: {
    groups: { name: string; displayName: string }[];
    search: string;
    selectedFilters: SelectedFilterArray<UserFaultEditorFilterType>;
  };
}

export interface UserFaultEditorData {
  userFault$: Observable<EditorUserFault>;
}

export interface UserFaultEditorListPanelData extends UserFaultEditorData {
  uiState$: Observable<UserFaultEditorUiState>;
  consist$: Observable<Consist>;
  simProperties$: Observable<SimPropertyGroup[]>;
  monitorPropertiesEnabled: boolean;
}
export interface UserFaultEditorPropertiesData extends UserFaultEditorData {
  consist$: Observable<Consist>;
  simProperties$: Observable<SimPropertyGroup[]>;
  selection$: Observable<UserFaultEditorSelection>;
  simPropertyAdded: Observer<{ simProperty: SimProperty; group: string }>;
  simPropertySelected: Observer<{ simPropertyName: string; group: string }>;
  monitorPropertiesEnabled: boolean;
  triggerFormValidation$?: Observable<void>;
}
export interface UserFaultEditorFaultsEventsData extends UserFaultEditorPropertiesData {
  simPropertyUpdated: Observer<{ userFaultState: string; simPropertyName: string; group: string; name: string | number; value: any }>;
  simPropertyUpdatedVehicle: Observer<{ simPropertyName: string; group: string; vehiclePosition: number }>;
}
export interface UserFaultEditorMonitoredPropertiesData extends UserFaultEditorPropertiesData {
  simPropertyUpdatedVehicle: Observer<{ simPropertyName: string; group: string; vehiclePosition: number }>;
}
export interface UserFaultEditorDetailPanelData extends UserFaultEditorData {
  trains$: Observable<string[]>;
  nameUpdate?: Observer<string>;
  trainUpdate?: Observer<string>;
  causeUpdate?: Observer<string>;
  consequenceUpdate?: Observer<string>;
  troubleshootingUpdate?: Observer<string>;
  triggerFormValidation$?: Observable<void>;
}

/**
 * Note you cannot currently configure the top toolbar.
 */
export interface UserFaultEditorConfig {
  listPanel: ComponentConfig<DynamicComponent<UserFaultEditorListPanelData, any>, UserFaultEditorListPanelData>;
  faultsEventsPanel: ComponentConfig<DynamicComponent<UserFaultEditorFaultsEventsData, any>, UserFaultEditorFaultsEventsData>;
  monitoredPropertiesPanel: ComponentConfig<DynamicComponent<UserFaultEditorMonitoredPropertiesData, any>, UserFaultEditorMonitoredPropertiesData>;
  detailsPanel: ComponentConfig<DynamicComponent<UserFaultEditorDetailPanelData, any>, UserFaultEditorDetailPanelData>;
}

/**
 * Returns whether the passed in data is user fault editor config. All fields are required!!
 *
 * @param config the config to check
 */
export function isUserFaultEditorConfig(config: UserFaultEditorConfig | Data): config is UserFaultEditorConfig {
  return !!config && !!config.listPanel && !!config.faultsEventsPanel && !!config.monitoredPropertiesPanel && !!config.detailsPanel;
}

export interface EditorUserFault extends BaseEditorStoreItem {
  version: number;
  /** displayName is expected to be unique! */
  displayName: string;
  history: EditorUserFaultHistory;
  train: string;
  userFaultStates: EditorUserFaultStates;
  cause: string;
  consequence: string;
  troubleshooting: string;
  monitoredSimProperties: EditorMonitoredSimProperties;
  rawValue?: string;
}

export interface EditorUserFaultHistory {
  historyLog: EditorUserFaultHistoryLog[];
}

export interface EditorUserFaultHistoryLog extends EditHistory {
  userFaultName: string;
  userFaultVersion: number;
}

export interface EditorUserFaultStates {
  userFaultState: EditorUserFaultState[];
}

export interface EditorUserFaultState {
  name: string;
  mappedSimProperties: EditorMappedSimProperties;
}

export interface EditorMappedSimProperties {
  mappedSimProperty: EditorUserFaultSimProperty[];
}

export interface EditorUserFaultMonitoredProperty {
  name: string;
  group: string;
  vehiclePosition?: number;
}

export interface EditorUserFaultSimProperty extends EditorUserFaultMonitoredProperty {
  stateName?: string | number;
  value?: any;
  displayName?: string;
}

export interface EditorMonitoredSimProperties {
  simProperty: EditorUserFaultMonitoredProperty[];
}

export interface UserFaultTableData extends EditorBrowserTableData {
  train: string;
}

export const FAULTS_CARD_DATA = new EditorData(t('User Faults'), '/editors/user-faults', OksygenIcon.EXCLAMATION_TRIANGLE, 'faults');

export function userFaultToTable(userService: UserService, userFault: EditorUserFault, locked = false): UserFaultTableData {
  let created = userFault?.history?.historyLog?.find(history => history.type === HISTORY_TYPE_CREATED);
  if (!created) {
    created = userFault?.history?.historyLog?.find(history => history.type === HISTORY_TYPE_COPIED);
  }

  // In case there's missing data...
  if (!created) {
    created = {
      type: HISTORY_TYPE_CREATED,
      authorFirstName: 'Unknown',
      authorLastName: 'Unknown',
      userFaultName: 'Unknown',
      userFaultVersion: userFault.version,
      timestamp: 'Unknown'
    };
  }

  const modified: EditHistory = getLastModified(userFault?.history?.historyLog);

  const creator = userService.users.find(u => u.firstName === created.authorFirstName && u.lastName === created.authorLastName);
  const modifier = userService.users.find(u => u.firstName === modified.authorFirstName && u.lastName === modified.authorLastName);

  const td: UserFaultTableData = {
    name: userFault.displayName,
    created: {
      name:
        created.authorFirstName === UNKNOWN && created.authorLastName === UNKNOWN ? UNKNOWN : (created.authorFirstName + ' ' + created.authorLastName).trim(),
      avatar: creator?.avatar,
      date: moment(created.timestamp)
    },
    modified: {
      name:
        modified.authorFirstName === UNKNOWN && modified.authorLastName === UNKNOWN
          ? UNKNOWN
          : (modified.authorFirstName + ' ' + modified.authorLastName).trim(),
      avatar: modifier?.avatar,
      date: moment(modified.timestamp)
    },
    status: userFaultStatus(userFault),
    train: userFault.train
  };
  td.locked = locked;
  return td;
}

export function userFaultStatus(userFault: EditorUserFault): EditorBrowserTableStatus {
  if (!userFault?.history?.historyLog) {
    return 'Unknown';
  }
  // FIXME draft if there's an error
  return userFault?.history?.historyLog?.length ? 'Published' : 'Draft';
}

export type UserFaultEditorTabType = TabGroupChild<BasicTabNavItem>;
