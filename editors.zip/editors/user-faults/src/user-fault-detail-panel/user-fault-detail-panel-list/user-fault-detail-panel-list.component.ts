/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Input } from '@angular/core';
import { UserFaultDetailPanelPropertyItem } from '../../models/user-fault-editor.model';

@Component({
  selector: 'oksygen-user-fault-detail-panel-list',
  templateUrl: './user-fault-detail-panel-list.component.html',
  styleUrls: ['./user-fault-detail-panel-list.component.scss']
})
export class UserFaultDetailPanelListComponent {
  @Input() icon: string;
  @Input() title: string;
  @Input() properties: UserFaultDetailPanelPropertyItem[];

  constructor() { }

}
