/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserConfigurationModule } from '@oksygen-sim-train-libraries/components-services/user-configuration';

import { UserFaultDetailPanelComponent } from './user-fault-detail-panel.component';

describe('UserFaultDetailPanelComponent', () => {
  let component: UserFaultDetailPanelComponent;
  let fixture: ComponentFixture<UserFaultDetailPanelComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainTrainsModule, OksygenSimTrainUserConfigurationModule],
      declarations: [UserFaultDetailPanelComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserFaultDetailPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
