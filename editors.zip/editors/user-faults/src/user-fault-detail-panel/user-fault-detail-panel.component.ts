/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Consist } from '@oksygen-sim-train-libraries/components-services/trains';
import { EditorUserFault, UserFaultDetailPanelPropertyItem } from '../models/user-fault-editor.model';

@Component({
  selector: 'oksygen-user-fault-detail-panel',
  templateUrl: './user-fault-detail-panel.component.html',
  styleUrls: ['./user-fault-detail-panel.component.scss']
})
export class UserFaultDetailPanelComponent implements OnChanges {

  @Input() userFault: EditorUserFault;
  @Input() toolbox = true;
  @Input() consist: Consist;
  @Input() monitorPropertiesEnabled = true;

  propertyList: UserFaultDetailPanelPropertyItem[];
  monitorList: UserFaultDetailPanelPropertyItem[];

  constructor() {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.userFault) {
      this.regenerateLists(changes.userFault.currentValue);
    }
  }

  regenerateLists(userFault: EditorUserFault): void {
    this.propertyList = this.stringifyPropertyList(userFault);
    this.monitorList = this.stringifyMonitoredList(userFault);
  }

  private stringifyPropertyList(userFault: EditorUserFault): UserFaultDetailPanelPropertyItem[] {
    if (!userFault?.userFaultStates?.userFaultState?.length) { return []; }
    const properties: UserFaultDetailPanelPropertyItem[] = [];
    userFault.userFaultStates.userFaultState.forEach(ufs => {
      ufs?.mappedSimProperties?.mappedSimProperty?.forEach(prop => {
        // FIXME mildly inefficient to do this lookup each iteration, should be done once prior
        const vehicle = this.vehiclePositionToName(prop.vehiclePosition);
        const existing = properties.find(p => p.name === prop.name && p.vehicle === vehicle);
        if (!existing) {
          properties.push({ name: prop.name, vehicle, vehiclePosition: prop.vehiclePosition });
        }
      });
    });
    return properties;
  }

  private stringifyMonitoredList(userFault: EditorUserFault): UserFaultDetailPanelPropertyItem[] {
    if (!userFault?.monitoredSimProperties?.simProperty?.length) { return []; }
    const list: UserFaultDetailPanelPropertyItem[] = userFault.monitoredSimProperties.simProperty.map(sp => {
      const vehicle = this.vehiclePositionToName(sp.vehiclePosition);
      const item: UserFaultDetailPanelPropertyItem = {
        name: sp.name,
        vehicle,
        vehiclePosition: sp.vehiclePosition
      };
      return item;
    });
    return list;
  }

  private vehiclePositionToName(vehiclePosition: number): string {
    const name = this.consist?.vehicles[vehiclePosition]?.carClass?.description;
    return vehiclePosition === undefined ? undefined : name;
  }

}
