/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserConfigurationModule } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { OksygenSimTrainUserFaultEditModule } from '../../user-fault.module';
import { of } from 'rxjs';

import { UserFaultEditorDetailPanelComponent } from './user-fault-editor-detail-panel.component';

describe('UserFaultEditorDetailPanelComponent', () => {
  let component: UserFaultEditorDetailPanelComponent;
  let fixture: ComponentFixture<UserFaultEditorDetailPanelComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainTrainsModule, OksygenSimTrainUserFaultEditModule, OksygenSimTrainUserConfigurationModule],
      declarations: [UserFaultEditorDetailPanelComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserFaultEditorDetailPanelComponent);
    component = fixture.componentInstance;
    component.data = {trains$: of(null), userFault$: of(null)};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
