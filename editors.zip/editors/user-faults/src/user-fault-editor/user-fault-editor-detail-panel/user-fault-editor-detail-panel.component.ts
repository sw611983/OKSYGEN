/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, UntypedFormControl, ValidationErrors } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { filterTruthy, SelfCompletingObservable } from '@oksygen-common-libraries/common';
import {
  AutocompleteInputType,
  DynamicComponent,
  InputError,
  newFormControl,
  newOptionalFormControl,
  UpdateOn,
  validateMandatoryString
} from '@oksygen-common-libraries/material/components';
import { ConfirmResult, yesNoDialog } from '@oksygen-sim-train-libraries/components-services/common';

import { EditorUserFault, UserFaultEditorDetailPanelData } from '../../models/user-fault-editor.model';

// verbose way of providing strongly typed forms, could be made generic
// source: https://indepth.dev/posts/1198/angular-forms-story-strong-types
interface UserFaultForm {
  name: string;
  train: string;
  cause: string;
  consequence: string;
  troubleshooting: string;
}
type UserFaultControls = { [key in keyof UserFaultForm]: FormControl};
type UserFaultFormGroup = FormGroup & { value: UserFaultForm; controls: UserFaultControls };

/**
 * DynamicComponent - inputs come via this.data and are defined on ```UserFaultEditorDetailPanelData```
 */
@Component({
  selector: 'oksygen-user-fault-editor-detail-panel',
  templateUrl: './user-fault-editor-detail-panel.component.html',
  styleUrls: ['./user-fault-editor-detail-panel.component.scss']
})
export class UserFaultEditorDetailPanelComponent extends DynamicComponent<UserFaultEditorDetailPanelData, any> implements OnInit, OnDestroy {

  userFaultFormGroup: UserFaultFormGroup;

  /** stored reference for the HTML, only train needed as it's an autocomplete */
  trainControl: FormControl;

  trainInputControl: UntypedFormControl;  // for value validation

  // properties for the train selection
  autocompleteInputType = AutocompleteInputType.FORM_FIELD;
  trainControlErrors: InputError[] = [
    { type: 'missing', text: t('A train is required.') }
  ];

  private subscription = new Subscription();

  constructor(private dialog: MatDialog, private translateService: TranslateService) {
    super();
  }

  ngOnInit(): void {
    this.userFaultFormGroup = this.createUserFaultForm();
    this.listenToUserFaultUpdates();
    this.subscription.add(this.data.triggerFormValidation$?.subscribe(() => this.trainInputControl.markAsTouched()));
    this.trainInputControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => validateMandatoryString(control.value));
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  echo(o: any): any {
    return o; // used to render trains by autocomplete in HTML
  }

  selectTrain(train: string): void {
    this.trainControl.setValue(train);
  }

  // pre-clear check for train auto complete
  // arrow function allows it to retain context
  onTrainClear = (consistName: string): SelfCompletingObservable<boolean> => yesNoDialog(
      t('Train in use'),
      t('This train has properties in use against it - clearing it will clear them as well. Do you wish to proceed?'),
      this.translateService,
      this.dialog,
      t('Clear')
    ).pipe(
      map(result => result === ConfirmResult.SAVE ? true : false)
    );

  private createUserFaultForm(): UserFaultFormGroup {
    const nameControl = newFormControl();
    const trainControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;
      if (!control.value || control.value?.length === 0) {
        result = { missing: true };
      }
      return result;
    });
    const causeControl = newOptionalFormControl();
    const consequenceControl = newOptionalFormControl();
    const troubleshootingControl = newOptionalFormControl();
    const userFaultFormGroup = new FormGroup({
      name: nameControl,
      train: trainControl,
      cause: causeControl,
      consequence: consequenceControl,
      troubleshooting: troubleshootingControl
    } as UserFaultControls ) as UserFaultFormGroup;
    this.trainControl = trainControl; // needs it's own reference as it's an autocomplete
    if (this.data?.nameUpdate) {
      const nameSub = nameControl.valueChanges.subscribe(this.data.nameUpdate);
      this.subscription.add(nameSub);
    }
    if (this.data?.trainUpdate) {
      const trainSub = trainControl.valueChanges.subscribe(this.data.trainUpdate);
      this.subscription.add(trainSub);
    }
    if (this.data?.causeUpdate) {
      const causeSub = causeControl.valueChanges.subscribe(this.data.causeUpdate);
      this.subscription.add(causeSub);
    }
    if (this.data?.consequenceUpdate) {
      const consequenceSub = consequenceControl.valueChanges.subscribe(this.data.consequenceUpdate);
      this.subscription.add(consequenceSub);
    }
    if (this.data?.troubleshootingUpdate) {
      const sub = troubleshootingControl.valueChanges.subscribe(this.data.troubleshootingUpdate);
      this.subscription.add(sub);
    }
    return userFaultFormGroup;
  }

  private listenToUserFaultUpdates(): void {
    const ufSub = this.data?.userFault$.pipe(
      filterTruthy()
    ).subscribe(uf => {
      this.processUserFaultUpdate(uf);
    });
    this.subscription.add(ufSub);
  }

  private processUserFaultUpdate(userFault: EditorUserFault): void {
    const opts = { emitEvent: false, onlySelf: true };
    this.userFaultFormGroup.get('name').setValue(userFault.displayName, opts);
    this.userFaultFormGroup.get('train').setValue(userFault.train, opts);
    this.userFaultFormGroup.get('cause').setValue(userFault.cause, opts);
    this.userFaultFormGroup.get('consequence').setValue(userFault.consequence, opts);
    this.userFaultFormGroup.get('troubleshooting').setValue(userFault.troubleshooting, opts);
  }
}
