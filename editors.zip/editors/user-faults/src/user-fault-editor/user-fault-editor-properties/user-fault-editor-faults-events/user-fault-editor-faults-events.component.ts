/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, OnDestroy, OnInit } from '@angular/core';
import { SimProperty, SimPropertyGroup, VehicleSimProperty } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { Consist } from '@oksygen-sim-train-libraries/components-services/trains';
import { EditorUserFault, EditorUserFaultSimProperty, UserFaultEditorFaultsEventsData } from '../../../models/user-fault-editor.model';
import { UserFaultEditorPropertyList } from '../user-fault-editor-property-list.component';
import { UserFaultEditorFaultInputs } from '../user-fault-editor-sim-property-item/user-fault-editor-sim-property-item.component';

@Component({
  selector: 'oksygen-user-fault-editor-faults-events',
  templateUrl: './user-fault-editor-faults-events.component.html',
  styleUrls: ['./user-fault-editor-faults-events.component.scss']
})
export class UserFaultEditorFaultsEventsComponent extends UserFaultEditorPropertyList<UserFaultEditorFaultsEventsData> implements OnInit, OnDestroy {
  simproperty: SimProperty;
  onPropertyUpdate(
    propertyUpdate: { name: 'Set' | 'Cleared' | 'Vehicle' | 'Raw'; value: { value: string | number; displayName: string } },
    prop: UserFaultEditorFaultInputs
  ): void {
    const group = this.getSimPropertyGroupName(prop.simPropertyName);
    if (propertyUpdate.name === 'Vehicle') {
      this.data.simPropertyUpdatedVehicle.next({
        group,
        simPropertyName: prop.simPropertyName,
        vehiclePosition: propertyUpdate.value?.value as any
      });
    } else {
      const value =
        propertyUpdate.name === 'Raw' ? propertyUpdate.value.value : this.getSimPropertyValue(prop.simPropertyName, `${propertyUpdate.value?.value}`);
      this.data.simPropertyUpdated.next({
        userFaultState: propertyUpdate.name,
        group,
        simPropertyName: prop.simPropertyName,
        name: propertyUpdate.value?.value,
        value
      });
    }
  }

  private getSimPropertyValue(simPropertyName: string, valueName: string): any {
    for (const p of this.groups) {
      for (const sp of p.simProperty) {
        if (sp.name === simPropertyName) {
          const simPropAssoc = sp?.states?.find(spa => spa.displayName === valueName);
          return simPropAssoc?.value;
        }
      }
    }
    return null;
  }

  isDraggedDataValid(data: { type: string; data: { simProperty: SimProperty; group: string } }): boolean {
    const valid = data?.type === 'simProperty' && data.data.simProperty.isWritable;
    return valid;
  }

  processUserFault(userFault: EditorUserFault, groups: SimPropertyGroup[], consist: Consist): UserFaultEditorFaultInputs[] {
    const faults: UserFaultEditorFaultInputs[] = [];
    if (!userFault) {
      return faults;
    }
    userFault?.userFaultStates?.userFaultState?.forEach(ufs => {
      ufs?.mappedSimProperties?.mappedSimProperty?.forEach(msp => {
        const simProperty = this.getSimProperty(msp, groups);
        this.simproperty = simProperty;
        const existingFaultIndex = faults.findIndex(f => f.simPropertyName === msp.name);
        if (existingFaultIndex === -1) {
          const newProp = this.createProperty(msp, ufs.name, simProperty, consist);
          faults.push(newProp);
        } else {
          this.updateProperty(faults[existingFaultIndex], ufs.name, msp, simProperty);
          const updateVehicle = this.isVehicleProperty(simProperty);
          if (updateVehicle) {
            this.updatePropertyVehicle(faults[existingFaultIndex], msp, consist, simProperty);
          }
        }
      });
    });
    return faults;
  }

  private createProperty(
    mappedSimProperty: EditorUserFaultSimProperty,
    type: string,
    simProperty: VehicleSimProperty,
    consist: Consist
  ): UserFaultEditorFaultInputs {
    const values = simProperty?.states?.map(spsa => ({ value: spsa.displayName, displayName: spsa.displayName }));
    const value = mappedSimProperty?.stateName ? `${mappedSimProperty.stateName}` : undefined;
    const newProp: UserFaultEditorFaultInputs = {
      simPropertyName: mappedSimProperty.name,
      set: {
        value: type === 'Set' ? values?.find(v => v.value === value) : undefined,
        values
      },
      cleared: {
        value: type === 'Cleared' ? values?.find(v => v.value === value) : undefined,
        values
      },
      displayName: simProperty?.displayName,
      raw: {
        value: type === 'Raw' && simProperty.valueType === 'RAW' ? { displayName: 'Raw', value: simProperty.rawValue } : undefined
      }
    };
    if (this.isVehicleProperty(simProperty)) {
      let vehicleValue: { value: number; displayName: string };
      if (typeof mappedSimProperty.vehiclePosition === 'number') {
        vehicleValue = {
          value: mappedSimProperty.vehiclePosition,
          displayName: consist.vehicles[mappedSimProperty.vehiclePosition]?.carClass?.description
        };
      }
      const vehicleValues = simProperty?.vehicleNames
        ?.map(v => consist?.vehicles?.find(cv => cv.carClass.description === v))
        ?.map(v => ({ value: v.position, displayName: v.carClass.description }));
      newProp.vehicle = {
        value: vehicleValue,
        values: vehicleValues
      };
    }
    return newProp;
  }

  private updateProperty(fault: UserFaultEditorFaultInputs, type: string, mappedSimProperty: EditorUserFaultSimProperty, simProperty: SimProperty): void {
    const values = simProperty?.states?.map(spsa => ({ value: spsa.displayName, displayName: spsa.displayName }));
    const value = mappedSimProperty?.stateName ? `${mappedSimProperty.stateName}` : undefined;
    if (type === 'Set') {
      fault.set.value = { value, displayName: value };
      fault.set.values = values;
    }
    if (type === 'Cleared') {
      fault.cleared.value = { value, displayName: value };
      fault.cleared.values = values;
    }
    if (type === 'Raw') {
      fault.raw.value = { value: value ? value : simProperty.rawValue, displayName: 'Raw' };
    }
  }
}
