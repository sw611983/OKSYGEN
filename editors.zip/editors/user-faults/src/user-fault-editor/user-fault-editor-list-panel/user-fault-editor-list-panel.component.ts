/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { DynamicComponent, Filter } from '@oksygen-common-libraries/material/components';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { SimProperty, SimPropertyGroup } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { Consist } from '@oksygen-sim-train-libraries/components-services/trains';
import { cloneDeep } from 'lodash';
import { combineLatest, Subscription } from 'rxjs';
import { startWith, tap } from 'rxjs/operators';
import { UserFaultEditorFilterType, UserFaultEditorListPanelData } from '../../models/user-fault-editor.model';

type SelectedList = 'faults' | 'monitor'; // TODO use this typing in the HTML as well

const SELECTOR = 'oksygen-user-fault-editor-list-panel';
@Component({
  selector: SELECTOR,
  templateUrl: './user-fault-editor-list-panel.component.html',
  styleUrls: ['./user-fault-editor-list-panel.component.scss']
})
export class UserFaultEditorListPanelComponent extends DynamicComponent<UserFaultEditorListPanelData, any> implements OnInit, OnDestroy {
  noConsist = true;

  simPropertiesGroup: SimPropertyGroup[] = [];
  listSelectionControl = new FormControl('faults');
  consist: Consist;

  private subscription = new Subscription();

  constructor(translateService: TranslateService) {
    super();
  }

  textToFilter = (text: string): Filter<string> => new Filter(UserFaultEditorFilterType.PROPERTY, text);

  ngOnInit(): void {
    if (!this.data) {
      return;
    }

    const sub = combineLatest([this.data.consist$, this.data.simProperties$, this.listSelectionControl.valueChanges.pipe(startWith('faults'))])
      .pipe(
        tap(([consist, simPropertyGroups, selectedList]) => {
          if (!consist) {
            this.noConsist = true;
            return;
          }
          this.noConsist = false;
          if (!simPropertyGroups) {
            // todo sim prop error handling
            return;
          }
          this.consist = consist;
          this.processInputUpdates(consist, simPropertyGroups, selectedList as 'faults' | 'monitor');
        })
      )
      .subscribe();
    this.subscription.add(sub);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private processInputUpdates(consist: Consist, simPropertyGroups: SimPropertyGroup[], selectedList: SelectedList): void {
    const simPropertiesGroup: SimPropertyGroup[] = [];
    simPropertyGroups.forEach(group => {
      let simProperty: SimProperty = null;
      if (!group.simProperty) {
        return;
      }
      for (const prop of group.simProperty) {
        simProperty = prop;
      }
      if (!this.isPropertyOfType(simProperty, selectedList)) {
        return;
      }
      simPropertiesGroup.push(group);
    });
    this.simPropertiesGroup = cloneDeep(simPropertiesGroup);
  }

  /**
   * Returns whether the sim property is of the list type.
   *
   * @param sp the sim property to check
   * @param type refers to which list we're currently showing
   */
  private isPropertyOfType(sp: SimProperty, type: SelectedList): boolean {
    return !!sp && ((sp.isWritable && type === 'faults') || (!sp.isWritable && type === 'monitor'));
  }
}
