/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RuleBlockPropertyTypePipe } from './rule-block-propertytype.pipe';
import { RuleBlockProperties, RuleBlockProperty } from '@oksygen-sim-train-libraries/components-services/rules';

describe('RuleBlockPropertyTypePipe', () => {
  let pipe: RuleBlockPropertyTypePipe;

  beforeEach(() => {
    pipe = new RuleBlockPropertyTypePipe();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should return "number" if any property has propertyType "number" or "time"', () => {
    const block: RuleBlockProperties = {
      property: [
        { propertyType: 'string' },
        { propertyType: 'time' }
      ] as RuleBlockProperty[]
    };
    const result = pipe.transform(block);
    expect(result).toBe('number');
  });

  it('should return "number" if any property has propertyType "number"', () => {
    const block: RuleBlockProperties = {
      property: [
        { propertyType: 'number' },
        { propertyType: 'string' }
      ] as RuleBlockProperty[]
    };
    const result = pipe.transform(block);
    expect(result).toBe('number');
  });

  it('should return "text" if no property has propertyType "number" or "time"', () => {
    const block: RuleBlockProperties = {
      property: [
        { propertyType: 'string' },
        { propertyType: 'boolean' }
      ] as RuleBlockProperty[]
    };
    const result = pipe.transform(block);
    expect(result).toBe('text');
  });

  it('should return "text" if the properties array is empty', () => {
    const block: RuleBlockProperties = { property: [] };
    const result = pipe.transform(block);
    expect(result).toBe('text');
  });
});
