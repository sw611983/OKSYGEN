/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { PipeTransform, Pipe } from '@angular/core';
import { RuleBlockProperties, RuleBlockProperty } from '@oksygen-sim-train-libraries/components-services/rules';

@Pipe({
  name: 'ruleBlockPropertyType',
  pure: true
})

export class RuleBlockPropertyTypePipe implements PipeTransform {
  transform(block: RuleBlockProperties): string {
    const isNumberType = block.property.some((property: RuleBlockProperty) =>
      property.propertyType === 'number' || property.propertyType === 'time'
    );
    return isNumberType ? 'number' : 'text';
  }
}
