/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RuleBlock, RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';
import {
  ScenarioRule
} from '@oksygen-sim-train-libraries/components-services/scenarios';
import { cloneDeep } from 'lodash';
import { BasePropertyConstraint } from '../services/rule-block-property-constraints/base-property.constraint';
import { ScenarioRuleItem } from '../models/scenario-rule-item.model';

class ScenarioRuleCreater {
  private constraints: Map<string, BasePropertyConstraint> = new Map();
  private unknownConstraint: BasePropertyConstraint;
  private ruleBlocks: RuleBlock[];
  private ruleTemplates: RuleTemplate[];

  setRuleBlocks(blocks: RuleBlock[]): void {
    this.ruleBlocks = cloneDeep(blocks);
  }

  setRuleTemplates(ruleTemplates: RuleTemplate[]): void {
    this.ruleTemplates = cloneDeep(ruleTemplates);
  }

  /**
   * This is used to add custom handling to rule blocks.
   *
   * @param id the id to use for this rule block handler
   * @param constraint the handler function
   */
  addConstraint(id: string, constraint: BasePropertyConstraint): void {
    this.constraints.set(id, constraint);
  }

  setUnknownConstraint(constraint: BasePropertyConstraint): void {
    this.unknownConstraint = constraint;
  }

  /**
   * Create a new scenario rule, optionally supplying the scenario rule data.
   * Note that we clone the supplied data, so changes to the created rule will NOT perforate
   *
   * @param data the scenario rule, if it exists
   */
  createScenarioRule(data?: ScenarioRule): ScenarioRuleItem {
    // deep cloned so we do not edit the original data.
    const rule = cloneDeep(data);
    return new ScenarioRuleItem(
      rule,
      this.ruleBlocks,
      this.ruleTemplates,
      this.constraints,
      this.unknownConstraint
    );
  }
}
/**
 * Singleton scenario rule factory. Use this to create ScenarioRuleItems.
 * A ScenarioRule is the raw data we get from the database.
 * A ScenarioRuleItem is a wrapper that has some helper methods to make working with it easier.
 */
export const ScenarioRuleFactory = new ScenarioRuleCreater();
