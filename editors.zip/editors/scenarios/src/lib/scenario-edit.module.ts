/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreDataServicesModule } from '@oksygen-sim-core-libraries/components-services/data-services';
import { OksygenSimCoreMultimediaModule } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { OksygenSimTrainMapsModule } from '@oksygen-sim-train-libraries/components-services/maps';
import { OksygenSimTrainObjectsModule } from '@oksygen-sim-train-libraries/components-services/objects';
import { OksygenSimTrainRobotDriversModule } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { OksygenSimTrainRuleModule } from '@oksygen-sim-train-libraries/components-services/rules';
import { OksygenSimTrainScenarioViewModule, SessionLoggingConfigToken } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserFaultsModule } from '@oksygen-sim-train-libraries/components-services/user-faults';
import { OksygenSimTrainVersionModule } from '@oksygen-sim-train-libraries/components-services/versioning';

import { ScenarioBrowserComponent } from './components/scenario-browser/scenario-browser.component';
import { ScenarioEditorTopToolbarComponent } from './components/scenario-editor-top-toolbar/scenario-editor-top-toolbar.component';
import { ScenarioEditorComponent } from './components/scenario-editor/scenario-editor.component';
import { ScenarioRulesEditRuleBlockComponent } from './components/scenario-rules-panel/scenario-rules-edit/scenario-rules-edit-rule-block/scenario-rules-edit-rule-block.component';
import { ScenarioRulesEditComponent } from './components/scenario-rules-panel/scenario-rules-edit/scenario-rules-edit.component';
import { ScenarioRulesListItemComponent } from './components/scenario-rules-panel/scenario-rules-list/scenario-rules-list-item/scenario-rules-list-item.component';
import { ScenarioRulesListComponent } from './components/scenario-rules-panel/scenario-rules-list/scenario-rules-list.component';
import { ScenarioRulesPanelComponent } from './components/scenario-rules-panel/scenario-rules-panel.component';
import { HardwareInitialStatesComponent } from './components/train-hardware-initial-states-dialog/hardware-initial-states/hardware-initial-states.component';
import { TrainHardwareInitialStatesDialogComponent } from './components/train-hardware-initial-states-dialog/train-hardware-initial-states-dialog.component';
import { TrainsPanelTrainsDetailsEditorComponent } from './components/trains-panel-trains-details-editor/trains-panel-trains-details-editor.component';
import { TrainsPanelTrainsEditorComponent } from './components/trains-panel-trains-editor/trains-panel-trains-editor.component';
import { ScenarioBrowserService } from './services/scenario-browser.service';
import { ScenarioEditService } from './services/scenario-edit.service';
import { ScenarioEditorContextManager } from './services/scenario-editor-context.manager';
import { RuleBlockPropertyTypePipe } from './pipes/rule-block-propertytype.pipe';
import { OksygenSimTrainSimPropertiesModule } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { ScenarioRuleVariablesComponent } from './components/scenario-rule-variables/scenario-rule-variables.component';
import { ScenarioRuleVariableEditComponent } from './components/scenario-rule-variables/scenario-rule-variable-edit/scenario-rule-variable-edit.component';
// eslint-disable-next-line max-len
import { ObjectDialogComponent } from './components/scenario-rules-panel/scenario-rules-edit/scenario-rules-edit-rule-block/object-dialog/object-dialog.component';
// eslint-disable-next-line max-len
import { ObjectsDialogListItemComponent } from './components/scenario-rules-panel/scenario-rules-edit/scenario-rules-edit-rule-block/object-dialog/objects-list-item/objects-list-item.component';

import { InitalConditionsDialogComponent } from './components/initial-conditions/initial-conditions-dialog/initial-conditions-dialog.component';
import { InitialConditionsListComponent } from './components/initial-conditions/initial-conditions-list/initial-conditions-list.component';
import { InitialConditionsListItemComponent } from './components/initial-conditions/initial-conditions-list-item/initial-conditions-list-item.component';
import { InitialConditionsTreeComponent } from './components/initial-conditions/initial-conditions-tree/initial-conditions-tree.component';

const components = [
  TrainsPanelTrainsDetailsEditorComponent,
  TrainsPanelTrainsEditorComponent,
  ScenarioRulesEditRuleBlockComponent,
  ScenarioRulesEditComponent,
  ScenarioRulesListComponent,
  ScenarioRulesListItemComponent,
  ScenarioRulesPanelComponent,
  ScenarioBrowserComponent,
  ScenarioEditorComponent,
  ScenarioEditorTopToolbarComponent,
  TrainHardwareInitialStatesDialogComponent,
  InitalConditionsDialogComponent,
  InitialConditionsListComponent,
  InitialConditionsListItemComponent,
  InitialConditionsTreeComponent,
  HardwareInitialStatesComponent,
  RuleBlockPropertyTypePipe,
  ScenarioRuleVariablesComponent,
  ScenarioRuleVariableEditComponent,
  ObjectDialogComponent,
  ObjectsDialogListItemComponent
];

@NgModule({
  declarations: components,
  imports: [
    RouterModule,
    CommonModule,
    DragDropModule,
    OksygenMaterialComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    // OksygenSimCoreComponentsModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenMaterialTranslateModule.forChild(),
    OksygenSimCoreDataServicesModule.forChild(),
    OksygenSimCoreMultimediaModule,
    OksygenSimTrainCommonModule,
    OksygenSimTrainEditorsModule,
    OksygenSimTrainTrainsModule,
    OksygenSimTrainRobotDriversModule,
    OksygenSimTrainRuleModule,
    OksygenSimTrainObjectsModule,
    OksygenSimTrainMapsModule,
    OksygenSimTrainScenarioViewModule,
    OksygenSimTrainVersionModule,
    OksygenSimTrainUserFaultsModule,
    OksygenSimTrainSimPropertiesModule
  ],
  providers: [
    ScenarioEditorContextManager,
    ScenarioEditService,
    ScenarioBrowserService,
    MatSnackBar,
    {
      provide: SessionLoggingConfigToken,
      useValue: {}
    }
  ],
  exports: components
})
export class OksygenSimTrainScenarioEditModule {}
