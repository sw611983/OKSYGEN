/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NavigationEnd, Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { cloneDeep, isNil } from 'lodash';
import moment from 'moment';
import { BehaviorSubject, combineLatest, Observable, of, zip } from 'rxjs';
import { catchError, filter, first, switchMap, tap } from 'rxjs/operators';

import {
  Dictionary,
  filterTruthy,
  generateUuid,
  HISTORY_TYPE_COPIED,
  momentToString,
  selfCompletingObservable,
  SelfCompletingObservable,
  SuperCalled,
  takeOneTruthy
} from '@oksygen-common-libraries/common';
import { camelCaseToSnakeCasePostProcessor, DataAccessService, dateToStringCustomiser, XmlJsonUtil } from '@oksygen-common-libraries/data-access';
import {
  ConfirmDataActionComponent,
  ConfirmDataActionDialogData,
  DONT_SAVE_TEXT,
  OK_BUTTON,
  PromptDialogComponent,
  PromptDialogData,
  SAVE_TEXT,
  UNSAVED_CHANGES_TEXT
} from '@oksygen-common-libraries/material/components';
import { MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { LmsService } from '@oksygen-sim-core-libraries/components-services/lms';
import { MultimediaDataItem, MultimediaDataService, MultimediaLmsScormActivityItem } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { User } from '@oksygen-sim-core-libraries/components-services/users';
import {
  findDistanceFromLine2D,
  LngLatCoord,
  normaliseDegrees,
  Orientation,
  Point2D,
  SegOffset,
  SegOffsetOriented,
  toDegrees,
  toOrientation
} from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectGeometry, ObjectProperties, ObjectModification as OM, TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import { ReportingEventItem, ReportItem } from '@oksygen-sim-train-libraries/components-services/assessment-criteria';
import { ScenarioAssessmentCriteriaEditManager } from '@oksygen-sim-train-libraries/components-services/assessment-criteria/scenario';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import {
  InitialConditionsTrains,
  ParameterDefinitionValueType,
  Range,
  roundToWithThreshold,
  SegmentPosition,
  WorldData
} from '@oksygen-sim-train-libraries/components-services/common';
import { BaseDataEditorManager, LockDatabaseService, StoreObjectModification } from '@oksygen-sim-train-libraries/components-services/editors';
import { MultipleInitialObjectStates } from '@oksygen-sim-train-libraries/components-services/maps';
import { MultimediaReference } from '@oksygen-sim-train-libraries/components-services/multimedia';
import {
  AUTOMATED_STATE_VALUE,
  DISPLAY_STATE,
  DISPLAY_STATE_OVERRIDE,
  getTrackAssocHeading,
  INITIAL_STATE,
  ObjectContainer,
  ObjectEditManager,
  ObjectPropertyChange,
  ObjectSource,
  ObjectStateChange,
  ObjectTypeContainer,
  ObjectTypeState,
  ObjectWorldGeometry,
  SimObject,
  USER_STATE,
  VIRTUAL_STATE
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockPropertyNameEnum, RuleBlockReference } from '@oksygen-sim-train-libraries/components-services/rules';
import {
  AddScenarioIdResponse,
  isValidScenarioId,
  Scenario,
  ScenarioEditorExtensions,
  ScenarioRuleVariable,
  ScenarioService,
  toScenarioXml,
  TrainTypeEquipment
} from '@oksygen-sim-train-libraries/components-services/scenarios';
import { EnvironmentProperty, ScenarioContext } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import {
  Consist,
  ConsistPlacementInfo,
  ITrainReachablePathFinder,
  TrainReachablePath,
  UsefulTrain
} from '@oksygen-sim-train-libraries/components-services/trains';
import { NetworkDefinitionManager, WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { scenarioEditorActions } from '../store/scenario-editor.actions';
import { canRedoScenario, canUndoScenario, getSavedScenarioName, getScenario, getScenarioUnsavedChanges } from '../store/scenario-editor.selectors';
import { ScenarioEditorState } from '../store/scenario-editor.state';

// TODO Decide the correct place for business logic like this.
// Keep in mind that some of this sort of logic will need to come in from the project side.
interface TrainsConfig {
  maxSimulated: number;
  maxAuto: number;
  maxTotal: number;
  enforceDriver: boolean;
}

/**
 * Helper interface to say which field was updated and to what.
 * Generic, but unused anywhere asides here.
 */
interface PropertyUpdated {
  propertyName: string;
  newValue: string | number;
}

export type PositioningFailureReasons = 'NOT_ENOUGH_ROOM' | 'OVERLAPS_EXISTING_TRAIN';

export type TrainRepositionTestResult = {
  allowed: boolean;
  reason?: PositioningFailureReasons;
};

export type TrainPlacementTestResult = {
  allowed: boolean;
  reason?: 'TOTAL_TRAIN_LIMIT_REACHED' | PositioningFailureReasons;
};

/**
 * Allows callers to request updates to a Scenario, such as adding Trains and Objects or tweaking the weather.
 *
 * FIXME Should be responsible for validating the Scenario.
 * Unfortunately a lot of that validation code is sprinkled through UI classes.
 *
 * Instances of this class need to be retained while the Scenario editing is in progress.
 * Typically a long lived service would manage object lifetime.
 * It's usually not a good idea for a UI component to manage these objects,
 * as components may be destroyed when you navigate away from them.
 */
export class ScenarioEditManager extends BaseDataEditorManager<Scenario, ScenarioContext> implements ObjectEditManager, ScenarioAssessmentCriteriaEditManager {
  private trainsConfig: TrainsConfig;

  /**
   * @deprecated Should be private.
   * Code calling this should get the scenario from the context.
   */
  scenario: Scenario;
  private worldSelectionLocked = false;
  private pathFinder: ITrainReachablePathFinder;

  private missingScenarioDetails = true;
  private missingDriver = true;
  private invalidRule = true;
  private missingTrainName = true;
  private specialCharactersUsed = true;

  // FIXME These need docs and possibly better names describing what they are for and why they are public.
  private saveDisabled = true;
  public saveButtonDisabled = true;

  // FIXME presumably this is here to ensure that we don't use a duplicate name, but it is not being used.
  // That indicates validation is done elsewhere (in the wrong place).
  private allScenarios: Scenario[] = [];
  private multimediaItems: MultimediaDataItem[] = [];
  private multimediaReferences: MultimediaReference[] = [];
  currentRoute: string;
  snackBarToShow: boolean;

  public canUndo$: Observable<boolean>;
  public canRedo$: Observable<boolean>;
  public objectDeletion$ = new BehaviorSubject<boolean>(false);

  constructor(
    public id: string,
    private dataAccessService: DataAccessService,
    private authService: AuthService,
    // Note that we wrap the store with this service so that we can easily migrate to a Store hosted on a server.
    // No other code should interact with this store.
    private store: Store<ScenarioEditorState>,
    private registry: Registry,
    private lmsService: LmsService,
    private scenarioService: ScenarioService,
    private multimediaDataService: MultimediaDataService,
    dialog: MatDialog,
    translateService: TranslateService,
    private snackbar: MatSnackBar,
    private readonly zone: NgZone,
    private logger: Logging,
    private worldDefinitionService: WorldDefinitionService,
    private router: Router,
    private lockService: LockDatabaseService,
    private scenarioEditorExtensionsToken: ScenarioEditorExtensions
  ) {
    super(translateService, dialog);
    this.subscription.add(
      this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe((e: any) => {
        this.updateSnackBarAction(e);
      })
    );
    this.trainsConfig = this.registry.getObject<{ trains: TrainsConfig }>(['editor', 'scenario']).trains;

    this.subscription.add(
      this.store.select(getScenarioUnsavedChanges(this.id)).subscribe(unsavedChanges => {
        this.unsavedChanges = unsavedChanges;
        this.updateSaveDisabled();
      })
    );
    this.subscription.add(this.scenarioService.data().subscribe(scenarios => (this.allScenarios = scenarios)));

    this.canUndo$ = this.store.select(canUndoScenario(this.id));
    this.canRedo$ = this.store.select(canRedoScenario(this.id));

    this.subscription.add(
      this.multimediaDataService.data().subscribe(multimediaItems => {
        this.multimediaItems = multimediaItems ?? [];
        this.multimediaReferences = [];

        this.multimediaItems.forEach(m => {
          const reference: MultimediaReference = { name: m.displayName, id: m.id, scormReference: null };

          if (m instanceof MultimediaLmsScormActivityItem) {
            reference.scormReference = m.scormReference;
          }

          this.multimediaReferences.push(reference);
        });
      })
    );

    // TODO Determine if we should be doing the following instead of exposing setDataManager
    // this.subscription.add(this.contextSupplier.manager$().pipe(
    //   filterTruthy(),
    //   switchMap(manager => {
    //     this.context = manager;
    //     this.context.map.showTrainPath(false); // no path based filtering (for now)
    //     return this.store.select(getScenario);
    //   })).subscribe(s => {
    //     this.scenario = s;
    //     // FIXME use of context is a bit suspect here
    //     (this.context.data$ as BehaviorSubject<Scenario>).next(s);
    //   })
    // );
  }

  updateObjectBoundaries(id: number, boundaries: Array<Array<LngLatCoord>>): void {
    throw new Error('Method not implemented.');
  }

  // Note we can't inject ContextSupplier.
  setEditingContext(dm: ScenarioContext): void {
    this.context = dm;

    this.subscription.add(
      this.store
        .select(getScenario(this.id))
        .pipe(filterTruthy())
        .subscribe(s => {
          this.scenario = s;

          // FIXME use of context is a bit suspect here
          (this.context.data$ as BehaviorSubject<Scenario>).next(s);
        })
    );
    this.subscription.add(this.context.pathFinder$.subscribe(p => (this.pathFinder = p)));
  }

  override destroy(): SuperCalled {
    this.store.dispatch(scenarioEditorActions.scenarioClosed({ id: this.id }));
    return super.destroy();
  }

  deleteItem(item: Scenario, reload?: boolean): SelfCompletingObservable<any> {
    return ScenarioEditManager.deleteScenario(this.dataAccessService, this.lmsService, item).pipe(
      tap(result => {
        if (result) {
          this.zone.run(() => {
            // snackbar needs to run in zone
            this.snackbar.open(this.translateService.instant(t('User Fault Deleted')), '', { duration: 3000 });
          });
        }
        if (reload) {
          // setTimeout to prevent expression changed after it was checked error
          setTimeout(() => this.scenarioService.reloadData());
        }
      })
    );
  }

  duplicateItem(item: Scenario, newName?: string): SelfCompletingObservable<void> {
    return ScenarioEditManager.duplicateScenario(
      item,
      newName,
      this.multimediaItems,
      this.scenarioService,
      this.dataAccessService,
      this.lmsService,
      this.worldDefinitionService,
      this.authService.getLoggedInUser(),
      this.logger
    );
  }

  get data$(): Observable<Scenario> {
    return this.context.data$;
  }

  public newItem(name: string): void {
    this.store.dispatch(scenarioEditorActions.newScenario({ id: this.id, name }));
    this.worldSelectionLocked = false;
  }

  public loadItem(scenario: Scenario): void {
    this.store.dispatch(scenarioEditorActions.loadScenario({ id: scenario.id, original: scenario }));
    this.worldSelectionLocked = true;
  }

  saveItem(): SelfCompletingObservable<boolean> {
    return this.doSaveScenario();
  }

  override saveItemDirect(item: Scenario): SelfCompletingObservable<any> {
    throw new Error('Method not implemented.');
  }

  getItemName(): string {
    return this.scenario?.name || '';
  }

  public getScenario(): Scenario {
    return this.scenario;
  }

  public undo(): void {
    this.store.dispatch(scenarioEditorActions.undoScenarioEdit({ id: this.id }));
  }

  public redo(): void {
    this.store.dispatch(scenarioEditorActions.redoScenarioEdit({ id: this.id }));
  }

  public setScenarioName(name: string): void {
    name = (name ?? '').trim();

    if (this.scenario.name !== name) {
      this.store.dispatch(scenarioEditorActions.setScenarioName({ id: this.id, name }));
    }
  }

  public setScenarioDescription(desc: string): void {
    desc = (desc ?? '').trim();

    if (this.scenario.scenarioDescription !== desc) {
      this.store.dispatch(scenarioEditorActions.setScenarioDescription({ id: this.id, desc }));
    }
  }

  public setSubject(subject: string): void {
    subject = (subject ?? '').trim();

    if (this.scenario.subject !== subject) {
      this.store.dispatch(scenarioEditorActions.setSubject({ id: this.id, subject }));
    }
  }

  public isWorldSelectionLocked(): boolean {
    return this.worldSelectionLocked;
  }

  public setSelectedWorld(trackName: string): void {
    if (!this.worldSelectionLocked) {
      trackName = trackName ?? '';
      if (this.scenario.tracknetworkName !== trackName) {
        this.store.dispatch(scenarioEditorActions.setSelectedWorld({ id: this.id, trackName }));
      }
    }
  }

  public lockSelectedWorld(): void {
    if (!this.worldSelectionLocked) {
      this.worldSelectionLocked = true;

      // A slightly hacky way of getting observers to update without requiring a secondary subscription to a "world selection locked" observable.
      (this.context.data$ as BehaviorSubject<Scenario>).next(this.scenario);
    }
  }

  public setSelectedSkin(skinName: string): void {
    skinName = skinName ?? '';
    if (this.scenario.tracknetworkSkinName !== skinName) {
      this.store.dispatch(scenarioEditorActions.setSelectedSkin({ id: this.id, skinName }));
    }
  }

  public setDateTime(dateTime: string): void {
    this.store.dispatch(scenarioEditorActions.setDateTime({ id: this.id, dateTime }));
  }

  public setInitialEnvironmentState(property: EnvironmentProperty, value: number): void {
    this.store.dispatch(scenarioEditorActions.setInitialEnvironmentState({ id: this.id, property, value }));
  }

  public scenarioAssessmentChanged(assessment: boolean): void {
    this.store.dispatch(scenarioEditorActions.setAssessment({ id: this.id, assessment }));
  }

  public initialScoreUpdated(initialScore: number): void {
    this.store.dispatch(scenarioEditorActions.setInitialScore({ id: this.id, initialScore }));
  }

  public targetScoreUpdated(targetScore: number): void {
    this.store.dispatch(scenarioEditorActions.setTargetScore({ id: this.id, targetScore }));
  }

  public scenarioActivationStatusChanged(status: boolean): void {
    this.store.dispatch(scenarioEditorActions.setActiveStatus({ id: this.id, status }));
  }

  /**
   * Tests whether the described Scenario Train would be allowed in this Scenario.
   * Note that you do not need to call this before calling ```newScenarioTrainFromConsist```,
   * this method is exposed to make proactive feedback easy.
   *
   * @param consist The template Consist to examine.
   * @param simulated Indicates whether the proposed Scenario Train would be driven by a trainee and simulated by a full model.
   */
  // TODO Decide the correct place for business logic like this.
  // Keep in mind that some of this sort of logic will need to come in from the project side.
  public newScenarioTrainFromConsistAllowed(consist: Consist, segOffset?: SegOffset): TrainPlacementTestResult {
    if (this.scenario.scenarioTrains.scenarioTrain.length >= this.trainsConfig.maxTotal) {
      return {
        allowed: false,
        reason: 'TOTAL_TRAIN_LIMIT_REACHED'
      };
    }

    if (segOffset) {
      const path = this.scanPathFromAlpha(segOffset);
      const startPos = path.toValidSegOffset(segOffset);
      const result = path.placeConsistOnPath(consist, startPos);

      if (result === 'Train too long!') {
        return {
          allowed: false,
          reason: 'NOT_ENOUGH_ROOM'
        };
      }

      let overlap = false;

      this.context.trains
        .data()
        .pipe(takeOneTruthy([], 100))
        .subscribe(trains => {
          for (const train of trains) {
            if (this.placementOverlaps(path, result, train)) {
              overlap = true;
              return;
            }
          }
        });

      if (overlap) {
        return {
          allowed: false,
          reason: 'OVERLAPS_EXISTING_TRAIN'
        };
      }
    }

    return { allowed: true };
  }

  /**
   * Adds a new Scenario Train, based on the given Consist.
   * Note that '''newScenarioTrainFromConsistAllowed''' is called by this method,
   * and its result may prevent the request from being serviced.
   *
   * @param consist The template consist for this train.
   * @param simulated Indicates whether the Scenario Train may be driven by a trainee and simulated by a full model.
   * @param pos The default starting position for the Scenario Train.
   */
  public newScenarioTrainFromConsist(consist: Consist, name: string, pos: SegOffsetOriented | SegmentPosition = null): void {
    this.lockSelectedWorld();

    if (this.newScenarioTrainFromConsistAllowed(consist, pos).allowed) {
      if (pos) {
        const startOffset = this.toValidSegOffset(pos).offset;
        const posAsAny = pos as any;

        this.context.world.world$.pipe(first()).subscribe(w => {
          const segment = w.segmentMap.get(pos.segmentId);

          if (segment) {
            this.store.dispatch(
              scenarioEditorActions.newScenarioTrainFromConsist({
                id: this.id,
                consist,
                name,
                pos: {
                  startSegmentName: segment.name,
                  startOffset,
                  fromAlpha: posAsAny.orientation ? posAsAny.orientaion === Orientation.ALPHA_TO_BETA : posAsAny.fromAlpha
                }
              })
            );
          }
        });
      } else {
        this.store.dispatch(scenarioEditorActions.newScenarioTrainFromConsist({ id: this.id, name, consist }));
      }
    }
  }

  /**
   * Tests whether the given Driver is allowed to drive the given Scenario Train.
   * Note that you do not need to call this before calling ```setDriverForScenarioTrain```,
   * this method is exposed to make proactive feedback easy.
   *
   * @param driver The Driver to examine.
   * @param scenarioTrainId ID of the target train
   */
  // TODO Decide the correct place for business logic like this.
  // Keep in mind that some of this sort of logic will need to come in from the project side.
  public newDriverForScenarioTrainAllowed(
    id: number,
    driver: DriverType
  ): { allowed: boolean; reason?: 'SIM_TRAIN_LIMIT_REACHED' | 'AUTO_TRAIN_LIMIT_REACHED' | 'NOT_COMPATIBLE' | 'UNKNOWN_TRAIN' } {
    const scenarioTrain = this.scenario.scenarioTrains.scenarioTrain.find(st => st.id === id);

    // Make sure the assignment is sensible
    if (!scenarioTrain) {
      return {
        allowed: false,
        reason: 'UNKNOWN_TRAIN'
      };
    }

    // TODO Need to test driver/train compatibility
    // if (false /* !driver.compatibleTrainTypes.contains(scenarioTrain.trainType) */) {
    //   return {
    //     allowed: false,
    //     reason: 'NOT_COMPATIBLE'
    //   };
    // }

    // Make sure we're not hitting any limits
    if (scenarioTrain.driverType !== driver) {
      const count = this.scenario.scenarioTrains.scenarioTrain.reduce((cnt, st) => (st.driverType?.toUpperCase() === driver?.toUpperCase() ? cnt + 1 : cnt), 0);

      if (driver?.toUpperCase() === DriverType.HUMAN.toUpperCase() && count >= this.trainsConfig.maxSimulated) {
        return {
          allowed: false,
          reason: 'SIM_TRAIN_LIMIT_REACHED'
        };
      } else if (driver?.toUpperCase() === DriverType.ROBOT.toUpperCase() && count >= this.trainsConfig.maxAuto) {
        return {
          allowed: false,
          reason: 'AUTO_TRAIN_LIMIT_REACHED'
        };
      }
    }

    return { allowed: true };
  }

  /**
   * Sets the driver for a particular scenario train.
   * To clear, send through a null driverType & driverName.
   *
   * @param trainId the id of the train
   * @param driverType the type of driver, Human or Robot
   * @param driverName the name of the driver. This will be null for Human drivers.
   */
  public setDriverForScenarioTrain(trainId: number, driverType: DriverType, driverName: string, driverId: string, driverVersion: string): void {
    if (this.newDriverForScenarioTrainAllowed(trainId, driverType).allowed) {
      this.store.dispatch(
        scenarioEditorActions.setDriverForScenarioTrain({ id: this.id, scenarioTrainId: trainId, driverType, driverName, driverId, driverVersion })
      );
    }
  }

  public updateScenarioTrainName(id: number, name: string): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioTrainName({ id: this.id, scenarioTrainId: id, name }));
  }

  /**
   * Returns world & pos if segmentId + offset is set.
   * Returns only world if segmentId + offset is not set.
   * Returns null if data is invalid.
   */
  private updateScenarioTrainPositionTest(
    id: number,
    segmentId: number,
    offset: number,
    orientation?: Orientation
  ): { world: WorldData; pos?: SegOffsetOriented } {
    let result = null;

    combineLatest([this.context.world.world$.pipe(first()), this.context.trains.data().pipe(first())]).subscribe(([world, trains]) => {
      if (!segmentId) {
        result = { world, pos: null };
        return;
      }
      orientation =
        orientation === undefined ? toOrientation(trains.find(train => train.id === id).vehicles?.[0]?.orientation) ?? Orientation.ALPHA_TO_BETA : orientation;

      const path = this.scanPath({ segmentId, offset, orientation });
      const pos = this.toValidSegOffsetOriented({ segmentId, offset, orientation });
      const consist = this.context.trains.getConsist(trains.find(st => st.id === id));

      const placementResult = path.placeConsistOnPath(consist, pos);

      if (placementResult === 'Train too long!') {
        return;
      }

      for (const train of trains) {
        if (train.id === id) continue;

        if (this.placementOverlaps(path, placementResult, train)) {
          return;
        }
      }

      result = { world, pos };
    });

    return result;
  }

  public updateScenarioTrainPositionAllowed(id: number, segmentId: number, offset: number, orientation?: Orientation): TrainRepositionTestResult {
    return this.updateScenarioTrainPositionTest(id, segmentId, offset, orientation) ? { allowed: true } : { allowed: false, reason: 'OVERLAPS_EXISTING_TRAIN' };
  }

  public updateScenarioTrainPosition(id: number, segmentId: number, offset: number, orientation?: Orientation): boolean {
    const testResult = this.updateScenarioTrainPositionTest(id, segmentId, offset, orientation);

    if (testResult?.pos) {
      this.store.dispatch(
        scenarioEditorActions.updateScenarioTrainPosition({
          id: this.id,
          scenarioTrainId: id,
          segment: testResult.world.segmentMap.get(testResult.pos.segmentId)?.name,
          offset: testResult.pos.offset,
          orientation: testResult.pos.orientation
        })
      );
      return true;
    } else if (testResult) {
      this.store.dispatch(
        scenarioEditorActions.clearScenarioTrainPosition({
          id: this.id,
          scenarioTrainId: id
        })
      );
      return true;
    }
    return false;
  }

  /**
   * Returns true if it is determined that the given placement info will overlap the given train.
   *
   * @param path The path of the train being placed.
   * @param placement Placement info.
   * @param train A train to check for overlap.
   */
  private placementOverlaps(path: Readonly<TrainReachablePath>, placement: ConsistPlacementInfo, train: UsefulTrain): boolean {
    const v0pos = train.vehicles?.[0]?.position;
    const start = { segmentId: v0pos.segmentId, offset: v0pos.segmentOffset, orientation: v0pos.segmentOrientation };
    const rear = train.rearPosition;

    if (!start || !rear) {
      return false;
    }
    // It is possible for a train to partially occupy the same path as another (due to spring points),
    // but I don't believe it's possible for both ends to be off the path in that case.
    if (path.indexOf(start.segmentId) === -1 && path.indexOf(rear.segmentId) === -1) {
      return false;
    }

    const otherTrainPlacement = path.placeConsistOnPath(this.context.trains.getConsist(train), start);

    if (otherTrainPlacement !== 'Train too long!') {
      const otherTrainOccupancy = otherTrainPlacement.segmentOccupancy;

      outer: for (const occupancy of placement.segmentOccupancy) {
        for (const otOcc of otherTrainOccupancy) {
          if (otOcc.segmentId === occupancy.segmentId) {
            if (occupancy.offsetRange.overlaps(otOcc.offsetRange)) {
              return true;
            }

            continue outer;
          }
        }
      }
    }

    return false;
  }

  public deleteScenarioTrain(id: number): void {
    this.store.dispatch(scenarioEditorActions.deleteScenarioTrain({ id: this.id, scenarioTrainId: id }));
  }

  public newObjectFromType(objectType: ObjectTypeContainer, name: string, pos: LngLatCoord, assocs: TrackSegmentAssociation[] = []): void {
    this.lockSelectedWorld();

    this.context.world.netDef$.pipe(first()).subscribe(nd => {
      this.context.world.world$.pipe(first()).subscribe(w => {
        const placement = this.findPlacement(w, nd, objectType, pos, assocs, true);

        // Not a valid placement; ignore.
        if (!placement) return;

        this.store.dispatch(
          scenarioEditorActions.newObjectFromType({
            id: this.id,
            objectType,
            name,
            ...placement,
            assocs
          })
        );
      });
    });
  }

  private findPlacement(
    world: WorldData,
    nd: NetworkDefinitionManager,
    objectType: ObjectTypeContainer,
    lngLat: LngLatCoord,
    assocs: TrackSegmentAssociation[],
    isNew = false
  ): { lngLat: LngLatCoord; pos: ObjectGeometry; assocs: TrackSegmentAssociation[] } {
    // Ensure segment/offsets are valid.
    // We attempt to intelligently handle segment offsets < 0 or > length by following the path.

    assocs = assocs.map(a => {
      if (!Range.including(0, world.segmentMap.get(a.segmentId).length).includes(a.offset)) {
        return {
          ...a,
          ...this.toValidSegOffset(a)
        };
      }

      return a;
    });

    // Ensure the placement follows the rules.
    // please see https://adl-atlassian.simu.lan/confluence/x/cCSjCw
    const xDistanceFromTrackCentreline = objectType.placementRules?.distanceFromTrackCentreline?.x;
    let posXY = nd.lngLatToXYIndividual(lngLat[0], lngLat[1]);

    if (isNew && assocs?.length === 1) {
      const assocLL = nd.segOffsetToLngLat(assocs[0]);
      const assocXY = nd.lngLatToXYIndividual(assocLL[0], assocLL[1]);
      const heading = getTrackAssocHeading(nd, assocs[0]);
      // treat NONE / BOTH as A_B
      const xDistance = roundToWithThreshold(findDistanceFromLine2D(posXY, assocXY, heading, assocs[0].orientation !== Orientation.BETA_TO_ALPHA), 0.1, 0.01);
      // new objects will only have an "x" offset
      // if the config sets x range to be 0 then we should "snap" to the closest track position.
      if (xDistanceFromTrackCentreline.isExact() && !xDistanceFromTrackCentreline.includes(Math.abs(xDistance))) {
        lngLat = assocLL;
        posXY = assocXY;
      }
    }

    if (xDistanceFromTrackCentreline?.isExact() && assocs?.length === 1) {
      const assocLL = nd.segOffsetToLngLat(assocs[0]);
      const assocXY = nd.lngLatToXYIndividual(assocLL[0], assocLL[1]);

      const xAssocDist = roundToWithThreshold(Math.sqrt(Math.pow(assocXY.x - posXY.x, 2) + Math.pow(assocXY.y - posXY.y, 2)), 0.1, 0.01);

      // TODO support non-zero distances.
      if (!xDistanceFromTrackCentreline.includes(Math.abs(xAssocDist)) && xDistanceFromTrackCentreline.includes(0)) {
        // Set the geometric position to the associated track
        lngLat = assocLL;
        posXY = assocXY;
      }
    }

    let h = 0;
    let z = 0;

    if (assocs.length === 1) {
      const assoc0 = assocs[0];
      const owp = nd.segmentOffsetToOrientedWorldPoint(assoc0.segmentId, assoc0.offset);
      h = toDegrees(owp.headingInRadians);
      h *= assoc0.orientation === Orientation.BETA_TO_ALPHA ? -1 : 1;
      // Note that objects are naturally oriented so that they face oncoming trains,
      // so we need to reverse them when we're matching track headings.
      h += 180;
      z = owp.z;
    }

    const pos = {
      ...posXY,
      z,
      h: normaliseDegrees(h),
      p: 0,
      r: 0
    };

    if (this.validatePlacement(nd, objectType, pos, assocs)) {
      return { lngLat, pos, assocs };
    }

    return undefined;
  }

  private scanPathFromAlpha(so: SegOffset): Readonly<TrainReachablePath> {
    return (
      this.pathFinder
        // We always want the path to be A->B when correcting for an out of bounds offset
        .scanTrainPath({ ...so, orientation: Orientation.ALPHA_TO_BETA })
    );
  }

  private scanPath(so: SegOffsetOriented): Readonly<TrainReachablePath> {
    return this.pathFinder.scanTrainPath(so);
  }

  private toValidSegOffset(so: SegOffset): SegOffset {
    // We always want the path to be A->B when correcting for an out of bounds offset
    return this.scanPathFromAlpha(so).toValidSegOffset(so);
  }

  private toValidSegOffsetOriented(so: SegOffsetOriented): SegOffsetOriented {
    return this.scanPath(so).toValidSegOffsetOriented(so);
  }

  private validateTrainPlacement(train: Consist, startPosition: SegOffsetOriented): boolean {
    //const allPositions = this.getTrainPositions(train, startPosition);
    // FIXME why is this commented?
    // for (const pos of allPositions) {
    // const taken = this.isPositionOccupied(pos);
    // if (taken) { return false; }
    //}
    return true;
  }

  private getTrainPositions(train: Consist, startPosition: SegOffsetOriented): SegOffsetOriented[] {
    return [startPosition];
  }

  private isPositionOccupied(position: SegOffset, blockers: SegOffset[]): boolean {
    // const existingTrainPositions = [];
    // const blockingFeaturePositions = [];
    return true;
  }

  private validatePlacement(
    nd: NetworkDefinitionManager,
    objectType: ObjectTypeContainer,
    geom: ObjectWorldGeometry,
    assocs: TrackSegmentAssociation[]
  ): boolean {
    // Ensure the placement follows the rules.
    const xDistanceFromTrackCentreline = objectType.placementRules?.distanceFromTrackCentreline?.x;
    const yDistanceFromTrackCentreline = objectType.placementRules?.distanceFromTrackCentreline?.y;

    for (const assoc of assocs) {
      const assocLL = nd.segOffsetToLngLat(assoc);
      const assocXY = nd.lngLatToXYIndividual(assocLL[0], assocLL[1]);
      let xAssocDist = assocXY.x - geom.x;
      let yAssocDist = assocXY.y - geom.y;
      // let xAssocDist = Math.sqrt(Math.pow(assocXY.x - geom.x, 2) + Math.pow(assocXY.y - geom.y, 2));
      // if the X-offset is set to 2, the object should be placed 2m to the right of the track centreline.
      // Unfortunately, with sqrt and precision, we sometimes get 1.99999999... instead of 2.
      // Except that 1.999... is not in the range so it does not update the object.
      // See PRDOKS-1900 for a screenshot of the issue.
      // To fix this, we round the distance to the nearest 0.001m.
      xAssocDist = roundToWithThreshold(xAssocDist);
      yAssocDist = roundToWithThreshold(yAssocDist);
      const heading = getTrackAssocHeading(nd, assoc);
      const hypot = Math.sqrt(Math.pow(xAssocDist, 2) + Math.pow(yAssocDist, 2));
      // treat NONE / BOTH as A_B
      const xDistance = roundToWithThreshold(
        findDistanceFromLine2D(geom as Point2D, assocXY, heading, assoc.orientation !== Orientation.BETA_TO_ALPHA),
        0.1,
        0.01
      );
      const yDistance = roundToWithThreshold(Math.sqrt(Math.pow(hypot, 2) - Math.pow(xDistance, 2)), 0.1, 0.01);
      if (xDistanceFromTrackCentreline && !xDistanceFromTrackCentreline.includes(Math.abs(xDistance))) {
        // Not a valid placement; ignore.
        return false;
      }
      if (yDistanceFromTrackCentreline && !yDistanceFromTrackCentreline.includes(Math.abs(yDistance))) {
        // Not a valid placement; ignore.
        return false;
      }
    }

    return true;
  }

  public updateObjectName(id: number, name: string): void {
    this.store.dispatch(scenarioEditorActions.updateObjectName({ id: this.id, objectId: id, name }));
  }

  public savedScenarioName$(): Observable<string> {
    return this.store.select(getSavedScenarioName(this.id));
  }

  public updateObjectPosition(object: ObjectContainer, pos: LngLatCoord, assocs?: TrackSegmentAssociation[]): void {
    this.lockSelectedWorld();

    this.context.world.netDef$.pipe(first()).subscribe(nd => {
      this.context.world.world$.pipe(first()).subscribe(w => {
        const placement = this.findPlacement(w, nd, object.objectType, pos, assocs);

        // Not a valid placement; ignore.
        if (!placement) return;

        this.store.dispatch(
          scenarioEditorActions.updateObjectPosition({
            id: this.id,
            objectId: object.id,
            ...placement
          })
        );
      });
    });
  }

  public updateObjectGeometry(object: ObjectContainer, geom: ObjectWorldGeometry): void {
    this.lockSelectedWorld();

    this.context.world.netDef$.pipe(first()).subscribe(nd => {
      const pos = {
        x: geom.x ?? object.location?.geometry?.x ?? 0,
        y: geom.y ?? object.location?.geometry?.y ?? 0,
        z: geom.z ?? object.location?.geometry?.z ?? 0,
        h: normaliseDegrees(geom.h ?? object.location?.geometry?.h ?? 0),
        p: normaliseDegrees(geom.p ?? object.location?.geometry?.p ?? 0),
        r: normaliseDegrees(geom.r ?? object.location?.geometry?.r ?? 0)
      };
      const p = nd.xyTolngLatIndividual(pos.x, pos.y);
      const lngLat: LngLatCoord = [p.longitude, p.latitude];

      // Only allow valid placements.
      if (this.validatePlacement(nd, object.objectType, pos, object.trackAssociations)) {
        this.store.dispatch(
          scenarioEditorActions.updateObjectPosition({
            id: this.id,
            objectId: object.id,
            lngLat,
            pos,
            assocs: object.trackAssociations
          })
        );
      }
    });
  }

  public deleteObject(id: number): void {
    this.store.dispatch(scenarioEditorActions.deleteObject({ id: this.id, objectId: id }));
  }

  objectStateChange(obj: ObjectContainer, state: ObjectStateChange): PropertyUpdated[] {
    let propertiesUpdated: PropertyUpdated[] = [];
    if (obj) {
      if (!isNil(state.autoToggled)) {
        // Automatic State Update
        if (state.autoToggled !== obj.stateAutomated) {
          if (state.autoToggled) {
            propertiesUpdated = this.objectToggleAutoOn(obj);
          } else {
            propertiesUpdated = this.objectToggleAutoOff(obj);
          }
        }
        if (state.state.id !== obj.selectedState.id) {
          if (state.autoToggled) {
            propertiesUpdated = this.objectChangeStateAutoOn(obj, state.state.name);
          } else {
            propertiesUpdated = this.objectChangeStateAutoOff(obj, state.state.name);
          }
        }
      } else if (
        !isNil(state.displayOverrideToggled) &&
        (state.displayOverrideToggled !== !!obj.properties[DISPLAY_STATE_OVERRIDE] || obj.displayState !== state.state)
      ) {
        // Diplay State Update
        if (state.displayOverrideToggled) {
          propertiesUpdated = this.objectToggleDisplayOverrideOn(obj, state.state.name);
        } else {
          propertiesUpdated = this.objectToggleDisplayOverrideOff(obj);
        }
      } else {
        propertiesUpdated = this.objectChangeStateAutoOff(obj, state.state.name);
      }
    }
    return propertiesUpdated;
  }

  setScenarioObjectProperties(obj: ObjectContainer, properties: ObjectProperties): void {
    this.store.dispatch(
      scenarioEditorActions.setScenarioObjectProperties({
        id: this.id,
        objectId: obj.id,
        properties
      })
    );
  }

  objectPropertyChange(obj: ObjectContainer, property: ObjectPropertyChange): PropertyUpdated[] {
    const propertiesUpdated: PropertyUpdated[] = [{ propertyName: property.propertyName, newValue: property.propertyValue as any }];
    const isWorldObj = obj?.source.id === ObjectSource.TRACK.id;
    if (isWorldObj) {
      if (property.propertyName === VIRTUAL_STATE && obj.children != null) {
        this.updateVirtualProperty(this.scenario.id, obj, propertiesUpdated);
      } else {
        this.updateScenarioObjectProperties(this.scenario.id, obj, propertiesUpdated);
      }
    } else {
      const properties: ObjectProperties = {
        ...obj.properties
      };
      properties[property.propertyName] = property.propertyValue;
      this.setScenarioObjectProperties(obj, properties);
    }
    return propertiesUpdated;
  }

  // https://adl-atlassian.simu.lan/confluence/display/PRDOKS/Feature+Initial+Conditions
  public objectToggleAutoOn(obj: SimObject): PropertyUpdated[] {
    const updates: PropertyUpdated[] = [
      { propertyName: INITIAL_STATE, newValue: obj.selectedState.name },
      { propertyName: USER_STATE, newValue: AUTOMATED_STATE_VALUE }
    ];
    this.updateScenarioObjectProperties(this.scenario.id, obj, updates);
    return updates;
  }

  // https://adl-atlassian.simu.lan/confluence/display/PRDOKS/Feature+Initial+Conditions
  public objectToggleAutoOff(obj: SimObject): PropertyUpdated[] {
    const updates: PropertyUpdated[] = [
      { propertyName: INITIAL_STATE, newValue: obj.selectedState.name },
      { propertyName: USER_STATE, newValue: obj.selectedState.name }
    ];
    this.updateScenarioObjectProperties(this.scenario.id, obj, updates);
    return updates;
  }

  // https://adl-atlassian.simu.lan/confluence/display/PRDOKS/Feature+Initial+Conditions
  public objectChangeStateAutoOn(obj: SimObject, stateName: string): PropertyUpdated[] {
    const updates: PropertyUpdated[] = [{ propertyName: INITIAL_STATE, newValue: stateName }];
    this.updateScenarioObjectProperties(this.scenario.id, obj, updates);
    return updates;
    // USER_STATE should already be set to Automated
  }

  // https://adl-atlassian.simu.lan/confluence/display/PRDOKS/Feature+Initial+Conditions
  public objectChangeStateAutoOff(obj: SimObject, stateName: string): PropertyUpdated[] {
    const updates: PropertyUpdated[] = [{ propertyName: INITIAL_STATE, newValue: stateName }];
    if (obj.stateAutomated !== undefined) {
      updates.push({ propertyName: USER_STATE, newValue: stateName });
    }
    this.updateScenarioObjectProperties(this.scenario.id, obj, updates);
    return updates;
  }

  // https://adl-atlassian.simu.lan/confluence/display/PRDOKS/Display+State
  public objectToggleDisplayOverrideOn(obj: SimObject, stateName: string): PropertyUpdated[] {
    const updates: PropertyUpdated[] = [
      { propertyName: DISPLAY_STATE, newValue: stateName },
      { propertyName: DISPLAY_STATE_OVERRIDE, newValue: 1 }
    ];
    this.updateScenarioObjectProperties(this.scenario.id, obj, updates);
    return updates;
  }

  // https://adl-atlassian.simu.lan/confluence/display/PRDOKS/Display+State
  public objectToggleDisplayOverrideOff(obj: SimObject): PropertyUpdated[] {
    const updates: PropertyUpdated[] = [
      { propertyName: DISPLAY_STATE, newValue: obj.objectType?.defaultState?.name },
      { propertyName: DISPLAY_STATE_OVERRIDE, newValue: 0 }
    ];
    this.updateScenarioObjectProperties(this.scenario.id, obj, updates);
    return updates;
  }

  public multipleObjectChangeStateAutoOff(settings: MultipleInitialObjectStates): void {
    const modifications: StoreObjectModification[] = [];

    settings.initialStates.forEach(s => {
      const objectName = s.object.name;
      const updates: PropertyUpdated[] = [{ propertyName: INITIAL_STATE, newValue: s.stateName }];
      if (s.object.stateAutomated !== undefined) {
        updates.push({ propertyName: USER_STATE, newValue: s.stateName });
      }
      updates.forEach(update => {
        modifications.push({
          objectName,
          propertyName: update.propertyName,
          propertyValue: update.newValue
        });
      });
    });

    this.store.dispatch(scenarioEditorActions.setMultipleObjectModifications({ id: this.scenario.id, modifications }));
  }

  public addMultimedia(multimedia: MultimediaDataItem): void {
    this.store.dispatch(scenarioEditorActions.addMultimedia({ id: this.id, displayName: multimedia.displayName, multimediaId: multimedia.id }));
  }

  public deleteMultimedia(ruleId: number): void {
    this.store.dispatch(scenarioEditorActions.deleteMultimedia({ id: this.id, ruleId }));
  }

  updateScenarioMultimediaName(ruleId: number, name: string, phantom?: boolean): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioMultimediaName({ id: this.id, ruleId, name, phantom }));
  }

  public addScenarioRule(name: string, description: string, ruleTemplateId: string, version: string, multimediaId?: string): void {
    this.store.dispatch(
      scenarioEditorActions.addScenarioRule({ id: this.id, name, description, ruleTemplateId, version, multimedia: this.multimediaReferences, multimediaId })
    );
  }

  public addScenarioRuleVariable(variable: ScenarioRuleVariable): void {
    this.store.dispatch(scenarioEditorActions.addScenarioRuleVariable({ id: this.id, variable }));
  }

  public updateScenarioRuleVariable(name: string, variable: Partial<ScenarioRuleVariable>): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioRuleVariable({ id: this.id, name, variable }));
  }

  public deleteScenarioRuleVariable(name: string): void {
    this.store.dispatch(scenarioEditorActions.deleteScenarioRuleVariable({ id: this.id, name }));
  }

  public duplicateScenarioRule(name: string, description: string, ruleId: number): void {
    this.store.dispatch(scenarioEditorActions.duplicateScenarioRule({ id: this.id, name, description, ruleId, multimedia: this.multimediaReferences }));
  }

  public deleteScenarioRule(ruleId: number): void {
    this.store.dispatch(scenarioEditorActions.deleteScenarioRule({ id: this.id, ruleId, multimedia: this.multimediaReferences }));
  }

  public updateScenarioRuleName(ruleId: number, name: string): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioRuleName({ id: this.id, ruleId, name }));
  }

  public updateScenarioRuleDescription(ruleId: number, description: string): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioRuleDescription({ id: this.id, ruleId, description }));
  }

  public updateScenarioRuleBlock(ruleId: number, block: RuleBlockReference): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioRuleBlock({ id: this.id, ruleId, block, multimedia: this.multimediaReferences }));
  }

  public updateScenarioRuleActive(ruleId: number, active: boolean): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioRuleActive({ id: this.id, ruleId, active }));
  }

  public override confirmCloseEditor(): SelfCompletingObservable<boolean> {
    if (!this.unsavedChanges) {
      return of(true);
    } else {
      enum ConfirmResult {
        SAVE,
        CANCEL,
        NO_SAVE
      }

      const data: ConfirmDataActionDialogData<ConfirmResult> = {
        title: UNSAVED_CHANGES_TEXT,
        content: this.translateService.instant(t('Do you want to save changes to <b>{scenarioName}</b>?'), { scenarioName: this.scenario.name }),
        primaryActionText: SAVE_TEXT,
        primaryActionResult: ConfirmResult.SAVE,
        cancelActionResult: ConfirmResult.CANCEL,
        secondaryActionText: DONT_SAVE_TEXT,
        secondaryActionColor: MaterialThemePalette.PRIMARY,
        secondaryActionResult: ConfirmResult.NO_SAVE
      };

      const dialogRef = this.dialog.open<ConfirmDataActionComponent<ConfirmResult>, ConfirmDataActionDialogData<ConfirmResult>, ConfirmResult>(
        ConfirmDataActionComponent,
        {
          disableClose: true,
          minHeight: '100px',
          minWidth: '400px',
          data
        }
      );

      return dialogRef.afterClosed().pipe(
        switchMap(dialogResult => {
          switch (dialogResult) {
            case ConfirmResult.SAVE:
              if (this.saveDisabled) {
                // we can't actually save, so pretend to, and this will open the snackbar
                this.saveScenario();
                return of(false);
              } else {
                // we're all good to close, so bypass the method that uses the snackbar
                // but make sure we force a reload after the save
                return this.doSaveScenario().pipe(
                  tap(ok => {
                    this.saveButtonDisabled = false;
                    if (ok) {
                      this.scenarioService.reloadData();
                    }
                  })
                );
              }
            case ConfirmResult.NO_SAVE:
              return of(true);
            default:
              return of(false);
          }
        })
      );
    }
  }

  public updateSnackBarAction(navEvent: NavigationEnd): void {
    this.currentRoute = navEvent?.urlAfterRedirects ?? '';
    // if we navigate to another page we need to update the snackbar with the new context
    if (!this.currentRoute.includes('scenarios/')) {
      this.snackbar.dismiss();
    } else {
      if (this.snackBarToShow) {
        this.saveScenario();
      }
    }
  }

  public saveScenario(): void {
    if (this.saveDisabled) {
      this.zone.run(() => {
        // snackbar needs to run in zone
        // eslint-disable-next-line @typescript-eslint/no-unused-vars, max-len
        const snackBarRef = this.snackbar.open(
          this.translateService.instant(t('Cannot save the scenario. There are items that require your attention.')),
          t('Dismiss')
        );
        this.snackBarToShow = true;
        snackBarRef.afterDismissed().subscribe(() => {
          if (this.currentRoute.includes('scenarios/')) {
            this.snackBarToShow = false;
          }
        });
      });
    } else {
      // can save
      const sub = this.doSaveScenario().subscribe(ok => {
        this.saveButtonDisabled = false;
        if (ok) {
          this.scenarioService.reloadData();
          this.zone.run(() => {
            // snackbar needs to run in zone
            this.snackbar.open(this.translateService.instant(t('Scenario saved')), '', { duration: 3000 });
          });
        } else {
          const promptData = new PromptDialogData();
          // FIXME More meaningful message please
          promptData.title = t('Could not save Scenario');
          // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
          promptData.content = t('Please contact an administrator.');
          promptData.buttons = OK_BUTTON;
          PromptDialogComponent.open(this.dialog, { id: 'SAVE_FAILED', data: promptData });
        }

        sub.unsubscribe();
      });
    }
  }

  public static scenarioObjectModificationsValid(objectModifications: OM[]): boolean {
    let validWorldObjects = true;
    objectModifications?.forEach(om => {
      const keys = Object.keys(om.properties);
      keys.forEach(key => {
        const value = om.properties[key];
        if (value === '' || value === null || value === undefined) {
          validWorldObjects = false;
        }
      });
    });
    return validWorldObjects;
  }

  /**
   * Returns a stringified error message of any errors in this scenario (ie missing required data).
   * @param scenario the scenario to validate
   */
  public static validateScenarioForSave(scenario: Scenario): string {
    if (!scenario) {
      return 'Scenario missing';
    }
    if (!scenario.name) {
      return 'Enter a scenario name.';
    }
    const validWorldObjects = ScenarioEditManager.scenarioObjectModificationsValid(scenario?.world?.objectModification);
    if (!validWorldObjects) {
      return 'Missing object property value.';
    }
    return '';
  }

  public static deleteScenario(dataAccessService: DataAccessService, lmsService: LmsService, scenario: Scenario): SelfCompletingObservable<any> {
    return ScenarioEditManager.doDeleteScenario(dataAccessService, scenario).pipe(
      tap(result => {
        if (result && lmsService.isEnabled()) {
          // make sure we have some form of valid version and description
          const scenarioVersion = scenario.version ? scenario.version : '0';
          const scenarioDescription = scenario.scenarioDescription ? scenario.scenarioDescription : '';

          lmsService
            .deleteScenario({
              id: undefined,
              scenarioId: scenario.id,
              name: scenario.name,
              description: scenarioDescription,
              version: scenarioVersion.toString()
            })
            .pipe(catchError(() => selfCompletingObservable(false)))
            .subscribe();
        }
      })
    );
  }

  private static doDeleteScenario(dataAccessService: DataAccessService, scenario: Scenario): SelfCompletingObservable<any> {
    return dataAccessService.callQueryJson({
      query: 'delete_scenario',
      debugMsg: `Deleting scenario ${scenario.name}`,
      parameters: { id: scenario.id }
    });
  }

  /**
   * This is called by both saveScenario and confirmCloseEditor (directly, to bypass the extra stuff saveScenario does after saving)
   */
  private doSaveScenario(): SelfCompletingObservable<any> {
    this.saveButtonDisabled = true;
    return zip(
      this.scenarioService.getRawScenario(this.id),
      this.context.data$,
      this.store.select(getSavedScenarioName(this.id)),
      this.context.world.world$
    ).pipe(
      switchMap(([rawScenario, scenario, savedScenarioName, world]) => {
        const updatedScenario = cloneDeep(scenario);

        // FIXME: This is required so that the World Model knows the scenario has changed (INTOSC-8736)
        // to be replaced with proper versioning once we decide what that is
        if (rawScenario) {
          // only increment the version if we've previously saved this scenario
          updatedScenario.version += 1;
        } else {
          if (this.lockService.isEnabled('scenario')) {
            const lock = this.lockService.createLockData(scenario.id, 'scenario'); // FIXME magic string
            this.lockService.addDatabaseLock(lock);
          }
        }

        const scenarioXml = toScenarioXml(
          rawScenario,
          updatedScenario,
          world,
          this.authService.getLoggedInUser(),
          this.logger,
          this.scenarioEditorExtensionsToken?.scenarioAdditionalFields,
          this.scenarioEditorExtensionsToken?.saveScenarioAdditionalFields
        );

        const xml = XmlJsonUtil.convertObjectToXmlWith(scenarioXml, 'scenario', {
          customisers: [dateToStringCustomiser],
          postProcessors: [camelCaseToSnakeCasePostProcessor]
        });

        const successPreProcess = (): void => {
          // update the original scenario
          this.store.dispatch(scenarioEditorActions.saveScenario({ id: updatedScenario.id, save: updatedScenario }));
        };
        successPreProcess.bind(this);

        const successPostProcess = (): void => {
          this.scenarioService.reloadData();
          // update the original scenario from the DB, to get the new ID.
          // TODO determine if this obsoletes successPreProcess
          this.scenarioService.getScenario(updatedScenario.id).subscribe(s => this.store.dispatch(scenarioEditorActions.saveScenario({ id: s.id, save: s })));
        };
        successPostProcess.bind(this);

        if (!!savedScenarioName && savedScenarioName !== updatedScenario.name) {
          return ScenarioEditManager.doDeleteScenario(this.dataAccessService, scenario).pipe(
            catchError(() => selfCompletingObservable(false)),
            // will receive success/failure either directly from the deleteScenario, or the catchError
            switchMap(success => {
              if (success) {
                return ScenarioEditManager.doScenarioSave(
                  updatedScenario,
                  xml,
                  this.multimediaItems,
                  this.dataAccessService,
                  this.lmsService,
                  successPreProcess,
                  successPostProcess,
                  this.logger
                );
              }

              return selfCompletingObservable(false);
            })
          );
        } else {
          return ScenarioEditManager.doScenarioSave(
            scenario,
            xml,
            this.multimediaItems,
            this.dataAccessService,
            this.lmsService,
            successPreProcess,
            successPostProcess,
            this.logger
          );
        }
      })
    );
  }

  public static duplicateScenario(
    scenario: Scenario,
    duplicateScenarioName: string,
    multimediaItems: MultimediaDataItem[],
    scenarioService: ScenarioService,
    dataAccessService: DataAccessService,
    lmsService: LmsService,
    worldDefinitionService: WorldDefinitionService,
    loggedInUser: User,
    logger: Logging
  ): SelfCompletingObservable<any> {
    const copiedScenario = cloneDeep(scenario);
    copiedScenario.id = generateUuid();
    copiedScenario.scenarioId = null;
    copiedScenario.name = duplicateScenarioName;
    copiedScenario.scenarioIsActive = false;
    // copiedScenario.scenarioDescription = copiedScenario.scenarioDescription;
    copiedScenario.version = 1;
    copiedScenario.scenarioHistory = [
      // replace the scenario history to show it was copied
      {
        type: HISTORY_TYPE_COPIED,
        authorFirstName: loggedInUser.firstName,
        authorLastName: loggedInUser.lastName,
        timestamp: momentToString(moment()),
        scenarioName: scenario.name,
        scenarioVersion: scenario.version
      }
    ];

    const successPreProcess = (): void => {};

    const successPostProcess = (): void => {
      scenarioService.reloadData();
    };

    return zip(scenarioService.getRawScenario(scenario.id), worldDefinitionService.loadWorld(scenario.tracknetworkName)).pipe(
      switchMap(([rawScenario, world]) => {
        const xml = XmlJsonUtil.convertObjectToXml(toScenarioXml(rawScenario, copiedScenario, world, loggedInUser, logger), 'scenario');

        return ScenarioEditManager.doScenarioSave(
          copiedScenario,
          xml,
          multimediaItems,
          dataAccessService,
          lmsService,
          successPreProcess,
          successPostProcess,
          logger
        );
      })
    );
  }

  public static modifyScenarioActivationStatus(
    scenario: Scenario,
    multimediaItems: MultimediaDataItem[],
    scenarioService: ScenarioService,
    dataAccessService: DataAccessService,
    lmsService: LmsService,
    worldDefinitionService: WorldDefinitionService,
    loggedInUser: User,
    logger: Logging
  ): SelfCompletingObservable<any> {
    const successPreProcess = (): void => {};

    const successPostProcess = (): void => {};

    return zip(scenarioService.getRawScenario(scenario.id), worldDefinitionService.loadWorld(scenario.tracknetworkName)).pipe(
      switchMap(([rawScenario, world]) => {
        const xml = XmlJsonUtil.convertObjectToXml(toScenarioXml(rawScenario, scenario, world, loggedInUser, logger), 'scenario');

        return ScenarioEditManager.doScenarioSave(scenario, xml, multimediaItems, dataAccessService, lmsService, successPreProcess, successPostProcess, logger);
      })
    );
  }

  /**
   * This is called by both duplicateScenario and doSaveScenario
   */
  private static doScenarioSave(
    scenario: Scenario,
    xml: string,
    multimediaItems: MultimediaDataItem[],
    dataAccessService: DataAccessService,
    lmsService: LmsService,
    successPreProcess: () => void,
    successPostProcess: () => void,
    logger: Logging
  ): SelfCompletingObservable<any> {
    const savePath = `/scenarios/${scenario.name}.xml`;

    const dictionary: Dictionary<string> = {};
    dictionary.xmlContent = xml;
    console.log(xml);
    dictionary.savePath = savePath;
    dictionary.id = scenario.id;

    // TODO: Check for what type should be returned here
    return dataAccessService
      .callQueryJsonPost({
        query: 'update_scenario.xq',
        parameters: dictionary,
        operation: 'updateScenario.xq',
        debugMsg: `Updating scenario ${scenario.id}`
      })
      .pipe(
        tap(result => {
          if (result) {
            if (isValidScenarioId(scenario)) {
              ScenarioEditManager.postSaveScenario(scenario, multimediaItems, lmsService, successPreProcess, successPostProcess);
            } else {
              // TODO: Remove this step once scenarioId is redundant
              // we don't have a valid scenarioId, so update this in the database and return it
              dataAccessService
                .callQueryJson<AddScenarioIdResponse>({
                  query: 'add_scenario_id',
                  operation: 'addScenarioId',
                  debugMsg: 'Add the Scenario Id',
                  parameters: { id: scenario.id }
                })
                .subscribe(
                  (response: any) => {
                    ScenarioEditManager.postSaveScenario(
                      {
                        ...scenario,
                        scenarioId: response.scenarioId
                      },
                      multimediaItems,
                      lmsService,
                      successPreProcess,
                      successPostProcess
                    );
                  },
                  (error: any) => {
                    logger?.log(error);
                  }
                );
            }
          }
        })
      );
  }

  private static postSaveScenario(
    scenario: Scenario,
    multimediaItems: MultimediaDataItem[],
    lmsService: LmsService,
    successPreProcess: () => void,
    successPostProcess: () => void
  ): void {
    successPreProcess();

    // FIXME: This really should happen on the publish of the scenario, not the save
    // Add the scenario to the LMS where available, the subscribe is required to complete the call
    // but we use the subscribe to know that it's been completed, and that we can now save any associated
    // multimedia
    if (lmsService.isEnabled()) {
      const scenarioVersion = scenario.version ? scenario.version : 0;
      const scenarioDescription = scenario.scenarioDescription ? scenario.scenarioDescription : '';

      lmsService
        .addScenario({
          id: undefined,
          scenarioId: scenario.id,
          name: scenario.name,
          description: scenarioDescription,
          version: scenarioVersion.toString()
        })
        .subscribe(lmsId => {
          if (lmsId) {
            successPostProcess();

            // add multimedia to lms
            scenario.multimedia?.forEach(m => {
              if (m.moodleScormActivity) {
                // need to subscribe to make sure the call is completed
                // FIXME should this also delete deleted multimedia?
                const multimedia = multimediaItems.find(item => item.id === m.moodleScormActivity.multimediaId);

                if (multimedia instanceof MultimediaLmsScormActivityItem) {
                  lmsService.addScenarioMultimedia(scenario.id, multimedia.scormReference, m.moodleScormActivity.name).subscribe();
                }
              }
            });

            scenario.rule?.forEach(r => {
              r?.ruleTemplateReference?.ruleBlocks?.ruleBlock?.forEach(rb => {
                rb?.properties?.property?.forEach(p => {
                  if (p.name === RuleBlockPropertyNameEnum.MULTIMEDIA_NAME) {
                    if (scenario.multimedia) {
                      // only add if we haven't already added
                      if (!scenario.multimedia.find(m => m.moodleScormActivity.name === p.value)) {
                        const name: string = p.value as string;
                        // FIXME should this also delete deleted multimedia?
                        lmsService.addScenarioMultimedia(scenario.id, name, name).subscribe();
                      }
                    }
                  }
                });
              });
            });
          }
        });
    } else {
      successPostProcess();
    }
  }

  private updateVirtualProperty(id: string, object: ObjectContainer, updates: PropertyUpdated[]): void {
    object.children.forEach(child => {
      this.updateScenarioObjectProperties(id, child, updates);
    });

    this.updateScenarioObjectProperties(id, object, updates); //storing parent's virtual state as well for vitrual toggle button
  }

  private updateScenarioObjectProperties(id: string, object: SimObject, updates: PropertyUpdated[]): void {
    // FIXME this should be an update many
    updates.forEach(update => {
      const isWorldObj = object?.source.id === ObjectSource.TRACK.id;
      // world objects have a separate data structure to scenario objects when modified in a scenario
      if (isWorldObj) {
        this.store.dispatch(
          scenarioEditorActions.setObjectModification({
            id,
            objectName: object.name,
            propertyName: update.propertyName,
            propertyValue: update.newValue
          })
        );
      } else {
        if (updates.some(u => u.propertyName === DISPLAY_STATE || u.propertyName === DISPLAY_STATE_OVERRIDE)) {
          let state: ObjectTypeState;
          object.states.forEach(s => {
            if (s.name === update.newValue) {
              state = s;
            }
          });
          this.store.dispatch(
            scenarioEditorActions.updateObjectDisplayState({
              id: this.scenario.id,
              objectId: object.id,
              state,
              propertyUpdated: update
            })
          );
        } else {
          let state: ObjectTypeState;
          object.states.forEach(s => {
            if (s.name === update.newValue) {
              state = s;
            }
          });
          if (state) {
            this.store.dispatch(
              scenarioEditorActions.updateObjectInitialState({
                id: this.scenario.id,
                objectId: object.id,
                state
              })
            );
          }
        }
      }
    });
  }

  updateInvalidRule(invalidRule: boolean): void {
    this.invalidRule = invalidRule;
    this.updateSaveDisabled();
  }

  private updateSaveDisabled(): void {
    const noTrains = isNil(this.scenario?.scenarioTrains?.scenarioTrain) || this.scenario?.scenarioTrains?.scenarioTrain?.length === 0;
    const missingScenarioDetails =
      isNil(this.scenario?.scenarioDescription) &&
      isNil(this.scenario?.tracknetworkSkinName) &&
      isNil(this.scenario?.name) &&
      isNil(this.scenario?.tracknetworkName);
    const trainNameMissing = this.scenario?.scenarioTrains?.scenarioTrain?.filter(train => !train?.name)?.length > 0;
    let driverMissing = false;
    if (this.enforceDriver()) {
      driverMissing = this.scenario?.scenarioTrains?.scenarioTrain?.filter(train => !train?.driverType)?.length > 0;
    }
    this.saveDisabled = missingScenarioDetails || trainNameMissing || driverMissing || noTrains || this.invalidRule || !this.unsavedChanges;
    this.saveButtonDisabled = this.saveDisabled;
  }

  enforceDriver(): boolean {
    return this.trainsConfig?.enforceDriver;
  }

  public updateHardwareStatesConfig(config: TrainTypeEquipment): void {
    this.store.dispatch(scenarioEditorActions.updateHardwareStatesConfig({ id: this.id, config }));
  }

  public updateInitialConditionsConfig(trainSimPropertiesAll: InitialConditionsTrains): void {
    this.store.dispatch(scenarioEditorActions.updateInitialConditionsConfig({ id: this.id, trainSimPropertiesAll }));
  }

  addScenarioAssessmentCriteria(displayName: string, assessmentCriteria: ReportItem, events: Array<ReportingEventItem>): void {
    this.store.dispatch(scenarioEditorActions.addScenarioAssessment({ id: this.id, displayName, assessmentCriteria, events }));
  }

  deleteScenarioAssessmentCriteria(assessmentCriteriaId: number): void {
    this.store.dispatch(scenarioEditorActions.deleteScenarioAssessment({ id: this.id, assessmentCriteriaId }));
  }

  updateScenarioAssessmentCriteriaName(assessmentCriteriaId: number, displayName: string): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioAssessmentName({ id: this.id, assessmentCriteriaId, displayName }));
  }

  updateScenarioAssessmentCriteriaDescription(assessmentCriteriaId: number, description: string): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioAssessmentDescription({ id: this.id, assessmentCriteriaId, description }));
  }

  updateScenarioAssessmentCriteriaAssessed(assessmentCriteriaId: number, assessed: boolean): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioAssessmentAssessed({ id: this.id, assessmentCriteriaId, assessed }));
  }

  updateScenarioAssessmentAssessmentParameter(assessmentCriteriaId: number, assessmentParameterName: string, value: ParameterDefinitionValueType): void {
    this.store.dispatch(
      scenarioEditorActions.updateScenarioAssessmentAssessmentParameter({ id: this.id, assessmentCriteriaId, assessmentParameterName, value })
    );
  }

  updateScenarioAssessmentParameter(assessmentCriteriaId: number, parameterName: string, value: ParameterDefinitionValueType): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioAssessmentParameter({ id: this.id, assessmentCriteriaId, parameterName, value }));
  }

  updateScenarioAssessmentEventParameter(assessmentCriteriaId: number, eventName: string, parameterName: string, value: ParameterDefinitionValueType): void {
    this.store.dispatch(scenarioEditorActions.updateScenarioAssessmentEventParameter({ id: this.id, assessmentCriteriaId, eventName, parameterName, value }));
  }
}
