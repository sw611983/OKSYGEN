/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, Injectable, NgZone } from '@angular/core';
import { Store } from '@ngrx/store';
import { BehaviorSubject } from 'rxjs';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import {
  MapIoManagerFactory,
  OBJECT_MAP_RENDERER_TOKEN,
  ObjectMapRenderer,
  TrainObjectsTrackAtlasManager,
  TrainReachablePathFinder
} from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectTypeDataService, PointTypeDataService } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockService, RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import {
  BaseScenarioSessionContextManager,
  createAtlasManagerConfiguration,
  SessionContext,
  TrainScenarioManager
} from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { UserConfigService } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { WorldDefinitionService, WorldManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ScenarioEditorState } from '../store/scenario-editor.state';
import { ObjectBasexManager } from './object-basex.manager';
import { RobotDriverService } from '@oksygen-sim-train-libraries/components-services/robot-drivers';

/**
 * A ContextManager for the Scenario Editor.
 */
@Injectable()
export class ScenarioEditorContextManager extends BaseScenarioSessionContextManager<string> {
  constructor(
    protected readonly registry: Registry,
    protected readonly logger: Logging,
    protected readonly pointTypeDataService: PointTypeDataService,
    protected readonly objectTypeService: ObjectTypeDataService,
    protected readonly worldDefService: WorldDefinitionService,
    protected readonly zone: NgZone,
    protected readonly consistDataService: ConsistDataService,
    protected readonly ruleBlockService: RuleBlockService,
    protected readonly ruleTemplateService: RuleTemplateService,
    protected readonly userService: UserService,
    protected readonly store: Store<ScenarioEditorState>,
    protected readonly userConfigService: UserConfigService,
    protected readonly robotDriverService: RobotDriverService,
    @Inject(OBJECT_MAP_RENDERER_TOKEN) protected overrideObjectMapRenderer: ObjectMapRenderer
  ) {
    super();
  }

  protected createContext(id: string): SessionContext {
    const scenario$ = new BehaviorSubject<Scenario>(null);
    const context = new SessionContext(scenario$);

    const featureTypes$ = this.objectTypeService.placementTypes$({ domain: 'editor', key: 'scenario' });
    const world = new WorldManager(new BehaviorSubject<WorldData>(null), this.getWorldProcessorFromScenario(this.worldDefService, scenario$));
    const objMan = new ObjectBasexManager(this.registry, this.logger, featureTypes$, scenario$, world, this.store);

    const pathFinder$ = new BehaviorSubject<TrainReachablePathFinder>(null);
    const pathFinder = new TrainReachablePathFinder(this.pointTypeDataService.pointType(), objMan.getObject.bind(objMan));
    world.world$.subscribe(w => {
      pathFinder.setWorldData(w);
      pathFinder$.next(w ? pathFinder : null);
    });
    const trainMan = new TrainScenarioManager(
      this.registry,
      this.logger,
      scenario$,
      this.consistDataService,
      world,
      objMan,
      this.pointTypeDataService.pointType(),
      pathFinder$,
      this.robotDriverService
    );
    context.mapIo = MapIoManagerFactory();
    context.world = world;
    context.objects = objMan;
    context.ruleBlocks$ = this.ruleBlockService.data();
    context.ruleTemplates$ = this.ruleTemplateService.data();
    context.trains = trainMan;
    context.world = world;
    context.pathFinder$ = pathFinder$;

    // Note that the order is important here; we make sure the context is set up as fully as possible so the map manager can use it.
    context.map = new TrainObjectsTrackAtlasManager(
      createAtlasManagerConfiguration(
        this.pointTypeDataService.pointType(),
        this.objectTypeService,
        this.consistDataService,
        context.objects,
        context.hubs,
        context.trains,
        context.world,
        context.pathFinder$,
        context.data$,
        this.logger,
        this.registry,
        this.overrideObjectMapRenderer
      ),
      this.logger,
      this.registry,
      this.zone
    );

    return context;
  }
}
