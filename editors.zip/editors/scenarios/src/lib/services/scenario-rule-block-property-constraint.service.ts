/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { Logging } from '@oksygen-common-libraries/pio';
import { MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import {
  RuleBlockPropertyConstraintService,
  RuleBlockNames,
  RuleTemplateRuleBlock,
  PropertyUpdate,
  RuleBlockPair
} from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';

import { ScenarioRuleFactory } from '../factories/scenario-rule.factory';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { EnvironmentConstraint } from './rule-block-property-constraints/environment.constraint';
import { InstructorPromptConstraint } from './rule-block-property-constraints/instructor-prompt.constraint';
import { FeatureConstraint } from './rule-block-property-constraints/feature.constraint';
import { FeatureStateConstraint } from './rule-block-property-constraints/feature-state.constraint';
import { TrainConstraint } from './rule-block-property-constraints/train.constraint';
import { TemporalEventConstraint } from './rule-block-property-constraints/temporal-event.constraint';
import { TrainPropertyConstraint } from './rule-block-property-constraints/train-property.constraint';
import { TrainSpatialConstraint } from './rule-block-property-constraints/train-spatial.constraint';
import { VehiclePropertyConstraint } from './rule-block-property-constraints/vehicle-property.constraint';
import { MoodleScormActivityConstraint } from './rule-block-property-constraints/moodle-scorm-activity.constraint';
import { MoodleScormActivityActionConstraint } from './rule-block-property-constraints/moodle-scorm-activity-action.constraint';
import { UnknownPropertyConstraint } from './rule-block-property-constraints/unknown-property.constraint';
import { SessionContext } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { UserFaultConstraint } from './rule-block-property-constraints/user-fault-constraint';
import { UserFaultDatabaseService } from '@oksygen-sim-train-libraries/components-services/user-faults';
import { GetVariableConstraint } from './rule-block-property-constraints/get-variable.constraint';
import { SetVariableConstraint } from './rule-block-property-constraints/set-variable.constraint';
import { AssessmentConstraint } from './rule-block-property-constraints/assessment.constraint';
// this currently doesn't actually need to be a service.
// could make it a class that hangs off RuleBlockService instead.
// only a service for convenience of DI, but easily could provide these via the above..
/**
 * Responsible for setting up our rule block handlers.
 * These are used during scenario editing. Scenario Rule Blocks have a lot of specific
 * business logic per block type, so we need to support various handlers per type.
 */
@Injectable()
export class ScenarioRuleBlockPropertyConstraintService extends RuleBlockPropertyConstraintService<any> {

  private scenarioRuleFactory = ScenarioRuleFactory;
  constructor(
    logging: Logging,
    simPropertyService: SimPropertiesService,
    private consistDataService: ConsistDataService,
    private multimediaDataService: MultimediaDataService,
    private userFaultDbService: UserFaultDatabaseService
  ) {
    super(logging, simPropertyService);
  }

  /**
   * Initialises the default set of rule block handlers.
   * FIXME these should be configurable, and custom ones should be able to be provided.
   */
  initialiseConstraints(getScenario: () => Scenario, context: () => SessionContext): void {
    // create our various rule block handlers
    const envConstraint = new EnvironmentConstraint(this.simPropertyService, this.logging);
    const instructorPromptConstraint = new InstructorPromptConstraint(this.simPropertyService, this.logging);
    const assessmentConstraint = new AssessmentConstraint(this.simPropertyService, this.logging);
    const featureConstraint = new FeatureConstraint(this.simPropertyService, this.logging, context);
    const featureStateConstraint = new FeatureStateConstraint(this.simPropertyService, this.logging, context);
    const trainConstraint = new TrainConstraint(this.simPropertyService, this.logging, this.consistDataService, getScenario);
    const temporalEventConstraint = new TemporalEventConstraint(this.simPropertyService, this.logging);
    const trainPropertyConstraint = new TrainPropertyConstraint(this.simPropertyService, this.logging, this.consistDataService, getScenario);
    const trainSpatialEventConstraint = new TrainSpatialConstraint(this.simPropertyService, this.logging, this.consistDataService, getScenario, context);
    const vehiclePropertyConstraint = new VehiclePropertyConstraint(this.simPropertyService, this.logging, this.consistDataService, getScenario);
    const moodleConstraint = new MoodleScormActivityConstraint(this.simPropertyService, this.multimediaDataService, this.logging);
    const moodleActionConstraint = new MoodleScormActivityActionConstraint(this.simPropertyService, this.multimediaDataService, this.logging);
    const userFaultConstraint = new UserFaultConstraint(this.simPropertyService, this.logging, this.consistDataService, getScenario, this.userFaultDbService);
    const getVariableConstraint = new GetVariableConstraint(this.simPropertyService, this.logging, getScenario);
    const setVariableConstraint = new SetVariableConstraint(this.simPropertyService, this.logging, getScenario);
    const unknownBlockConstraint = new UnknownPropertyConstraint(this.simPropertyService, this.logging);
    // let our scenario rule processor know about the handler
    // each handler registers both it's "read" and "write" method
    // (this is because there is specific business logic to execute on both reads and writes)
    // ENVIRONMENT
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.ENVIRONMENT, envConstraint);
    // INSTRUCTOR PROMPT
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.INSTRUCTOR_MESSAGE, instructorPromptConstraint);
    // ASSESSMENT
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.ASSESSMENT_SCORE, assessmentConstraint);
    // TRAIN SPATIAL EVENTS
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.TRAIN_SPATIAL_EVENT, trainSpatialEventConstraint);
    // FEATURE STATE
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.FEATURE_STATE, featureStateConstraint);
    // FEATURES
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.FEATURE, featureConstraint);
    // TRAIN
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.TRAIN, trainConstraint);
    // TEMPORAL EVENTS
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.TEMPORAL_EVENT, temporalEventConstraint);
    // TRAIN PROPERTY
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.TRAIN_PROPERTY, trainPropertyConstraint);
    // VEHICLES
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.VEHICLE, vehiclePropertyConstraint);
    // MULTIMEDIA
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.MOODLE_SCORM_ACTIVITY, moodleConstraint);
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.MOODLE_SCORM_ACTIVITY_ACTION, moodleActionConstraint);
    // USER FAULT
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.USER_FAULT, userFaultConstraint);
    // TRAVELLED DISTANCE
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.TRAVELLED_DISTANCE, trainConstraint);
    // TRAIN SPEED
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.TRAIN_SPEED, trainConstraint);
    // SET VARIABLE
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.SET_NUMBER_VARIABLE, setVariableConstraint);
    // GET VARIABLE
    this.scenarioRuleFactory.addConstraint(RuleBlockNames.GET_NUMBER_VARIABLE, getVariableConstraint);
    // UNKNOWN
    this.scenarioRuleFactory.setUnknownConstraint(unknownBlockConstraint);
  }

  generatePropertyList(ruleTemplateRuleBlock: RuleTemplateRuleBlock): Observable<any[]> {
    return of(null);
  }

  updateProperty(block: RuleBlockPair, propertyName: string, value: string | number | boolean): PropertyUpdate[] {
    return [];
  }
}
