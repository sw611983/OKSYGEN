/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, Injectable, NgZone, OnDestroy, Optional } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Router, RouteReuseStrategy } from '@angular/router';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

import { computeIfAbsent, generateUuid, SelfCompletingObservable, shareReplayOne } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LmsService } from '@oksygen-sim-core-libraries/components-services/lms';
import { MultimediaDataItem, MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { EditorManagementService, LockDatabaseService } from '@oksygen-sim-train-libraries/components-services/editors';
import { CustomRouteReuseStrategy, RouteReuseType } from '@oksygen-sim-train-libraries/components-services/routing';
import {
  Scenario,
  SCENARIO_EDITOR_EXTENSIONS_TOKEN,
  ScenarioEditorExtensions,
  ScenarioService
} from '@oksygen-sim-train-libraries/components-services/scenarios';
import { ScenarioContext, ScenarioPreviewManager } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { ConsistDataService, TrainVisionManager } from '@oksygen-sim-train-libraries/components-services/trains';
import { TrackDataService, WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ScenarioEditorState } from '../store/scenario-editor.state';
import { ScenarioEditManager } from './scenario-edit.manager';

/**
 * Facilitates some quick Scenario management actions.
 *
 * Retains instances of {@link ScenarioEditManager} and {@link ScenarioPreviewManager}
 * for Scenarios being edited.
 *
 * Instances would usually have a lifetime as long as the application.
 */
@Injectable()
export class ScenarioEditService extends EditorManagementService<
  ScenarioEditorState, Scenario, ScenarioContext, ScenarioEditManager
> implements OnDestroy {

  private previewVisionManagers = new Map<string, ScenarioPreviewManager>();
  private previewSessions: string[] = [];
  private multimediaItems: MultimediaDataItem[] = [];
  private route: Router;

  constructor(
    dataAccessService: DataAccessService,
    authService: AuthService,
    public readonly consistDataService: ConsistDataService,
    public readonly trackDataService: TrackDataService,
    store: Store<ScenarioEditorState>,
    public readonly visionManager: TrainVisionManager,
    registry: Registry,
    logger: Logging,
    lmsService: LmsService,
    public readonly scenarioService: ScenarioService,
    public readonly multimediaDataService: MultimediaDataService,
    dialog: MatDialog,
    translateService: TranslateService,
    snackbar: MatSnackBar,
    zone: NgZone,
    router: Router,
    public worldDefinitionService: WorldDefinitionService,
    private lockService: LockDatabaseService,
    @Optional() private routeReuseStrategy: RouteReuseStrategy,
    @Optional() @Inject(SCENARIO_EDITOR_EXTENSIONS_TOKEN) protected scenarioEditorExtensionsToken: ScenarioEditorExtensions,
  ) {
    super(
      dataAccessService, authService, store, registry, logger, lmsService, dialog, translateService, snackbar, zone, scenarioService
    );
    this.subscription.add(this.multimediaDataService.data().subscribe(multimediaItems => (this.multimediaItems = multimediaItems ?? [])));
    this.route = router;
  }

  ngOnDestroy(): void {
    this.destroy();
    // this.editManagers.forEach(value => value.destroy());
    // this.editManagers.clear();

    this.previewVisionManagers.forEach(value => value.destroy());
    this.previewVisionManagers.clear();

    this.subscription.unsubscribe();
  }

  /** Get the specified manager. Creates it if it does not already exist. */
  newManager(id: string): ScenarioEditManager {
    if (this.routeReuseStrategy && typeof (this.routeReuseStrategy as CustomRouteReuseStrategy).enableStorage === 'function') {
     (this.routeReuseStrategy as CustomRouteReuseStrategy).enableStorage(RouteReuseType.SCENARIO);
    }
    return new ScenarioEditManager(
      id,
      this.dataAccessService,
      this.authService,
      this.store,
      this.registry,
      this.lmsService,
      this.scenarioService,
      this.multimediaDataService,
      this.dialog,
      this.translateService,
      this.snackbar,
      this.zone,
      this.logger,
      this.worldDefinitionService,
      this.route,
      this.lockService,
      this.scenarioEditorExtensionsToken
    );
  }

  /** Get the specified manager. Creates it if it does not already exist. */
  getPreviewManager(
    id: string,
    context: ScenarioContext
  ): ScenarioPreviewManager {
    return computeIfAbsent(this.previewVisionManagers, id, i =>
      new ScenarioPreviewManager(
        i, this.logger, this.consistDataService, this.trackDataService, context, this.visionManager
      ));
  }

  public newScenario(name: string): Promise<string> {
    return new Promise(resolve => {
      const id = generateUuid();

      const manager = this.getEditManager(id);
      manager.newItem(name);
      resolve(id);
    });
  }

  public loadScenario(scenario: Scenario): void {
    const manager = this.getEditManager(scenario.id);

    manager.loadItem(scenario);
  }

  public deleteScenario(scenario: Scenario): SelfCompletingObservable<any> {
    return ScenarioEditManager.deleteScenario(this.dataAccessService, this.lmsService, scenario).pipe(
      tap(result => {
        if (result) {
          this.zone.run(() => { // snackbar needs to run in zone
            this.snackbar.open(this.translateService.instant(t('Scenario Deleted')), '', { duration: 3000 });
          });
        }
        // setTimeout to prevent expression changed after it was checked error
        setTimeout(() => this.scenarioService.reloadData());
      })
    );
  }

  public duplicateScenario(
    scenario: Scenario,
    duplicateScenarioName: string
  ): SelfCompletingObservable<any> {
    return ScenarioEditManager.duplicateScenario(
      scenario,
      duplicateScenarioName,
      this.multimediaItems,
      this.scenarioService,
      this.dataAccessService,
      this.lmsService,
      this.worldDefinitionService,
      this.authService.getLoggedInUser(),
      this.logger
    );
  }

  public modifyScenarioActivationStatus(
    scenario: Scenario
  ): SelfCompletingObservable<any> {
    return ScenarioEditManager.modifyScenarioActivationStatus(
      scenario,
      this.multimediaItems,
      this.scenarioService,
      this.dataAccessService,
      this.lmsService,
      this.worldDefinitionService,
      this.authService.getLoggedInUser(),
      this.logger
    );
  }

  /**
   * It should be called when the scenario is launched for preview.
   * @param id The session id
   */
  public openPreview(id: string): void{
    this.previewSessions.push(id);
  }

  /**
   * This method is used to get the list of opened preview sessions.
   * @returns The list of opened preview sessions
   */
  public getPreviewSession(): string[] {
    return this.previewSessions;
  }

  public override confirmCloseEditor(id: string): SelfCompletingObservable<boolean> {
    /** Remove the closed session from the list of opened preview sessions */
    this.previewSessions = this.previewSessions.filter(session => session !== id);
    const manager = this.getEditManager(id);
    return manager.confirmCloseEditor();
  }

  override getActiveEditorCount(): number {
    return this.editorsActiveSubject.getValue();
  }

  override get activeEditors$(): Observable<number> {
    return this.editorsActiveSubject.pipe(shareReplayOne());
  }

  /** Destroy a manager (and recursively all it's data). */
  override destroyManagers(id: string): void {
    super.destroyManagers(id);

    this.editManagers.delete(id);
    if (this.routeReuseStrategy) {
      const routeReuseStrategy = this.routeReuseStrategy as CustomRouteReuseStrategy;
      routeReuseStrategy.disableStorage(RouteReuseType.SCENARIO);
      routeReuseStrategy.clearRoute(RouteReuseType.SCENARIO, routeReuseStrategy.getStoreKeyById(RouteReuseType.SCENARIO, id));
    }

    this.previewVisionManagers.get(id)?.destroy();
    this.previewVisionManagers.delete(id);
    if (this.editManagers.size !== this.editorsActiveSubject.getValue()) {
      this.editorsActiveSubject.next(this.editManagers.size);
    }
  }
}
