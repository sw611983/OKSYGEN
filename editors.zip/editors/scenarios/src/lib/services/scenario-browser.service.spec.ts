/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

// TODO Perhaps we should use Spectator for writing tests...
// import { createServiceFactory, mockProvider, SpectatorService } from '@ngneat/spectator';
// import { TestBed, waitForAsync } from '@angular/core/testing';
// import { provideMockStore } from '@ngrx/store/testing';

// import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
// import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { ScenarioBrowserService } from './scenario-browser.service';

describe('ScenarioBrowserService', () => {
  // TODO Perhaps we should use Spectator for writing tests...
  // let spectator: SpectatorService<ScenariosEditorService>;
  // const createService = createServiceFactory({
  //   service: ScenariosEditorService,
  //   providers: [
  //     mockProvider(TranslateService),
  //     provideMockStore({})
  //   ]
  // });

  // beforeEach(() => spectator = createService());

  // it('should be created', () => {
  //   expect(spectator.service).toBeTruthy();
  // });

  let service: ScenarioBrowserService;

  beforeEach(() => {
    // waitForAsync(() => {
    //   configureSimTrainTestingModule({
    //     imports: [ OksygenSimTrainEditorsModule ],
    //     providers: [provideMockStore({})]
    //   });
    //   service = TestBed.inject(ScenarioBrowserService);
    // })
    service = new ScenarioBrowserService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
