/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ScenarioEditService } from './scenario-edit.service';
import { OksygenSimTrainScenarioEditModule } from '../scenario-edit.module';

describe('ScenarioEditService', () => {
  let service: ScenarioEditService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainScenarioEditModule],
      providers: [ ScenarioEditService ] // why do we need to provide ourself???
    });
    service = TestBed.inject(ScenarioEditService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
