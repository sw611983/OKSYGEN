/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { BasePropertyConstraint } from './base-property.constraint';

/**
 * Rule block handler for rule blocks we don't support out of the box. Each property will simply be free text entry with no validation or linked properties.
 */
export class UnknownPropertyConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const properties: ScenarioRulePropertyItem[] = [];
    block.ruleBlock.properties?.property?.forEach(p => {
      const property = this.generateProperty(block, p.name);
      properties.push(property);
    });
    return properties;
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    this.updateScenarioBlockSimple(block, propertyName, value);
  }
}
