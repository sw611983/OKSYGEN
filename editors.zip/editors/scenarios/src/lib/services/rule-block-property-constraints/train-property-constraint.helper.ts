/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { map, tap } from 'rxjs/operators';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { RuleBlockPropertyNameEnum, RuleBlockPropertyTypeEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { Consist, ConsistDataService, ScenarioTrain } from '@oksygen-sim-train-libraries/components-services/trains';
import { ScenarioRuleBlockItem } from '../../models/scenario-rule-item.model';
import { findRuleBlockProperty, findRuleProperty } from './base-property.constraint';
import { SimPropertiesService, SimProperty, SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class TrainPropertyConstraintHelper {
  constructor(
    private simPropertyService: SimPropertiesService,
    private consistDataService: ConsistDataService,
    // FIXME should probably use a DataManager, so we're not restricted to using static data
    private getScenario: () => Scenario
  ) {}

  public findProperties(
    consist: Consist,
    isVehicle: boolean,
    selectedPropertyName: string,
    isDriven: boolean
  ): { selectedProperty: SimProperty; allProperties: SimPropertyState[] } {
    const allProperties: SimPropertyState[] = [];
    let selectedProperty: SimProperty;
    const properties = isVehicle
      ? this.simPropertyService.getConsistAllVehicleSimProperties(consist.id, isDriven)
      : this.simPropertyService.getConsistTrainSimProperties(consist.id, isDriven);
    properties.forEach(group => {
      group.simProperty.forEach(property => {
        // only properties with state that are writable can be considered
        if (property?.states?.length > 0 && property?.isWritable || property?.valueType==='RAW') {
          const prop: SimPropertyState = { name: property.name, displayName: property.displayName, value: property.name };

          if (property.name === selectedPropertyName) {
            selectedProperty = property;
          }
          prop.displayName = this.simPropertyService.translateService.instant(t(prop.displayName));
          prop.name = this.simPropertyService.translateService.instant(t(prop.name));
          prop.value = this.simPropertyService.translateService.instant(t(prop.value));
          allProperties.push(prop);
        }
      });
    });
    return { selectedProperty, allProperties };
  }

  public findValidTrains(): SimPropertyState[] {
    let validTrains: SimPropertyState[] = [];

    const trains = this.getScenarioTrains();
    // FIXME The typeing is wrong here. This is a collection of available train IDs.
    if (trains) {
      validTrains = trains.map(train => ({ name: train.name, displayName: train.name, value: train.id }));
    }

    return validTrains;
  }

  public getTrainIdFromBlock(block: ScenarioRuleBlockItem): number {
    const ruleTrain = findRuleBlockProperty(block.ruleBlock, RuleBlockPropertyTypeEnum.TRAIN_ID);
    const templateTrain = findRuleProperty(block.templateBlock, RuleBlockPropertyNameEnum.TRAIN_ID);
    const scenarioTrain = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.TRAIN_ID);
    if (scenarioTrain) {
      return scenarioTrain.value as any; // FIXME number validation
    }
    if (templateTrain) {
      return templateTrain.value as any; // FIXME number validation
    }
    if (ruleTrain) {
      return ruleTrain.defaultValue;
    }
    return null;
  }

  private getScenarioTrains(): ScenarioTrain[] {
    const scenario = this.getScenario();
    const trains = scenario?.scenarioTrains?.scenarioTrain;
    return trains;
  }

  public getScenarioTrainConsist(scenarioTrain: ScenarioTrain): Consist {
    if (!scenarioTrain) {
      return undefined;
    }
    const consist = this.getConsistByName(scenarioTrain.trainDescription);
    return consist;
  }

  private getConsistByName(name: string): Consist {
    if (!name) {
      return undefined;
    }
    let consist: Consist = null;
    const sub = this.consistDataService
      .data()
      .pipe(
        takeOneTruthy(),
        map(trains => trains.find(train => train.name === name)),
        tap(c => (consist = c))
      )
      .subscribe();
    sub?.unsubscribe();
    return consist;
  }

  public getScenarioTrainById(trainId: number): ScenarioTrain {
    if (trainId === null || trainId === undefined) {
      return undefined;
    }
    const trains = this.getScenarioTrains();
    return trains?.find(train => train.id === trainId);
  }

  public findValidVehiclesAndProperties(
    scenarioTrain: ScenarioTrain,
    consist: Consist,
    selectedVehicle: string
  ): { validVehicles: SimPropertyState[]; selectedVehicleAllProperties: SimPropertyState[]; selectedVehiclePropertyState: SimProperty } {
    let selectedVehiclePropertyState: SimProperty;
    // FIXME not sure this is the correct type, the vehicle index isn't a Sim Property.
    let allVehicleProperties: SimPropertyState[] = [];
    let validVehicles: SimPropertyState[] = [];

    if (scenarioTrain) {
      const isDriven = scenarioTrain.driverType === DriverType.HUMAN;
      const props = this.findProperties(consist, true, selectedVehicle, isDriven);
      allVehicleProperties = props.allProperties;
      selectedVehiclePropertyState = props.selectedProperty;

      if (consist?.vehicles) {
        validVehicles = consist.vehicles.map((v, i) => {
          const displayName = this.simPropertyService.translateService.instant(t('Car {carIndex} ({carClass})'), {
            carIndex: i + 1,
            carClass: v.carClass.description
          });

          return { name: displayName, displayName, value: i };
        });
      }
    }

    return { validVehicles, selectedVehicleAllProperties: allVehicleProperties, selectedVehiclePropertyState };
  }
}
