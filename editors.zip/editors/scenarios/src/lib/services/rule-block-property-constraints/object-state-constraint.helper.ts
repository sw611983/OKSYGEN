/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import { ObjectContainer, getDisplayObject } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { SessionContext } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

import { findRuleProperty } from './base-property.constraint';
import { ScenarioRuleBlockItem } from '../../models/scenario-rule-item.model';
import { SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

interface DisplayObject {
  displayName: string;
  name: string;
  value: string;
}

interface AllowedSelectedObject {
  allowedObjects: DisplayObject[];
  displayedObjects: DisplayObject[];
  selectedObject: ObjectContainer;
}

export class ObjectStateConstraintHelper {

  constructor(private context: () => SessionContext) {
  }

  /**
   * Finds all objects. If you want only track associated objects, use findTrackObjects instead.
   * This filters out container objects.
   * If the rule block value is a container object, it will only return the child objects, with the promoted child becoming the selected object
   *
   * @param block the rule block you want objects for
   */
  findObjects(block: ScenarioRuleBlockItem): AllowedSelectedObject {
    return this.filterObjects(block, object => !!object);
  }

  // FIXME roll this and findObjects into 1 with an optional "validateObjectFn" param
  /**
   * Finds only objects with track associations. If you want all objects, you findObjects.
   * This filters out container objects.
   * If the rule block value is a container object, it will only return the child objects, with the promoted child becoming the selected object
   *
   * @param block the rule block you want objects for
   */
  findTrackObjects(block: ScenarioRuleBlockItem): AllowedSelectedObject  {
    return this.filterObjects(block, object => object?.trackAssociations?.length > 0);
  }

  // TODO: Correct this when we can change the state on a container object
  /**
   * Finds all objects, filtered by the passed objectFilter
   * This filters out container objects.
   * If the rule block value is a container object, it will only return the child objects, with the promoted child becoming the selected object
   *
   * @param block the rule block you want objects for
   * @param objectFilter the filter
   */
  private filterObjects(block: ScenarioRuleBlockItem, objectFilter: (o: ObjectContainer) => boolean): AllowedSelectedObject {
    const prop = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.FEATURE_NAME);
    const objectName = prop?.value;
    let selectedObject: ObjectContainer;
    let availableObjects: ObjectContainer[] = [];

    this.context()?.objects.data().pipe(
      // FIXME magic number
      takeOneTruthy<ObjectContainer[]>(undefined, 100)
    ).subscribe(f => {
      availableObjects = f?.filter(objectFilter) ?? [];
    }, err => { /* FIXME log here! */});

    selectedObject = availableObjects.find(o => o.name === objectName || o.name === `${objectName}`);

    const allowedObjects = availableObjects.map(f => ({ name: f.name, displayName: f.name, value: f.name }));
    let displayedObjects: DisplayObject[] = [];

    // if the selected object is a container object, then return only it's children
    // this assumes that if the container object has track association, the children do as well (when called from findTrackObjects).
    if (selectedObject?.children?.length > 0) {
      displayedObjects = selectedObject.children.map(f => ({ name: f.name, displayName: f.name, value: f.name}));
    } else {
      displayedObjects = availableObjects.filter(o => !o.children || o.children.length === 0).map(f => ({ name: f.name, displayName: f.name, value: f.name }));
    }

    // if the selected object is a container object, then return it's promoted child instead, as the first selection
    if (selectedObject?.children?.length > 0) {
      selectedObject = getDisplayObject(selectedObject) /* selectedObject.children.find(c => c.promotedChild)*/ as ObjectContainer;
      // hack, need to change the prop value to this new object, otherwise it won't select the
      prop.value = selectedObject.name;
    }

    return {allowedObjects, displayedObjects, selectedObject};
  }

  findAllowedStates(object: ObjectContainer): SimPropertyState[] {
    const allowedStates: SimPropertyState[] = [];
    object?.objectType.states?.forEach((v, k) => allowedStates.push({ name: v.name, displayName: v.name, value: v.name }));
    return allowedStates;
  }
}
