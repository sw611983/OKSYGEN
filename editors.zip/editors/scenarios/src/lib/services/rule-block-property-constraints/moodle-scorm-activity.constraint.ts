/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Logging } from '@oksygen-common-libraries/pio';
import { MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { MoodleConstraintHelper } from './moodle-constraint.helper';
import { BasePropertyConstraint } from './base-property.constraint';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class MoodleScormActivityConstraint extends BasePropertyConstraint {

  helper: MoodleConstraintHelper;
  constructor(
    simPropertyService: SimPropertiesService,
    private multimediaDataService: MultimediaDataService,
    logging: Logging
  ) {
    super(simPropertyService, logging);
    this.helper = new MoodleConstraintHelper(this.multimediaDataService);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.MULTIMEDIA_NAME
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const allowedMoodles = this.helper.getMultimediaLmsScormActivities().map(val => ({ name: val.displayName, displayName: val.displayName, value: val.id }));
    const prop = this.generateProperty(block, RuleBlockPropertyNameEnum.MULTIMEDIA_NAME, allowedMoodles);
    return [ prop ];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.MULTIMEDIA_NAME, value);
  }
}
