/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Logging } from '@oksygen-common-libraries/pio';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { SessionContext } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

import { BasePropertyConstraint } from './base-property.constraint';
import { ObjectStateConstraintHelper } from './object-state-constraint.helper';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

export class FeatureStateConstraint extends BasePropertyConstraint {
  private objectHelper: ObjectStateConstraintHelper;

  constructor(simPropertyService: SimPropertiesService, logging: Logging, context: () => SessionContext) {
    super(simPropertyService, logging);
    this.objectHelper = new ObjectStateConstraintHelper(context);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.FEATURE_NAME,
      RuleBlockPropertyNameEnum.STATE
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const objectInfo = this.objectHelper.findObjects(block);
    const feature: ObjectContainer = objectInfo.selectedObject;

    const featureStateProperty = this.generateKeyValueProperty(
      block,
      RuleBlockPropertyNameEnum.FEATURE_NAME,
      RuleBlockPropertyNameEnum.STATE,
      {
        allowedKeyValues: objectInfo.allowedObjects,
        allowedValueValues: !feature?.properties?.Locked ? this.objectHelper.findAllowedStates(feature) : [],
        displayedKeyValues: objectInfo.displayedObjects
      }
    );
    if (feature?.properties?.Locked)
    {
      const errorMessage = t('State for this object is locked');
      featureStateProperty[1]?.assignData({enabled: false, errorMessage});
    }
    return featureStateProperty;
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    if (propertyName === RuleBlockPropertyNameEnum.FEATURE_NAME) {
      // if updating the feature property, reset value to default
      const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.STATE);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.STATE, defaultValue);
    } else if (propertyName === RuleBlockPropertyNameEnum.STATE) {
      // value only need update value
      this.updateScenarioBlockSimple(block, propertyName, value);
    } else {
      this.logging.warn(`[RuleBlockTrainHandler] failed to update unknown property ${propertyName}!`);
    }
  }
}
