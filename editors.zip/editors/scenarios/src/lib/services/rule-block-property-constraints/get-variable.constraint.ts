/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RuleBlockNames, RuleBlockPropertyNameEnum, RuleBlockPropertyTypeEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';

import { Logging } from '@oksygen-common-libraries/pio';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { BasePropertyConstraint } from './base-property.constraint';
import { SimPropertiesService, SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class GetVariableConstraint extends BasePropertyConstraint {
  constructor(simPropertyService: SimPropertiesService, logging: Logging, private getScenario: () => Scenario) {
    super(simPropertyService, logging);
  }

  managedProperties(): string[] {
    return [RuleBlockPropertyNameEnum.VARIABLE];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const variables = this.getScenario()?.ruleVariables;

    const propertyType: RuleBlockPropertyTypeEnum = this.getPropertyType(block);
    let validVariable: SimPropertyState[];
    if (variables) {
      validVariable = variables
        .filter(variable => variable.type === propertyType)
        .map(variable => ({ name: variable.name, displayName: variable.name, value: variable.name }));
    }

    const variable = this.generateProperty(block, RuleBlockPropertyNameEnum.VARIABLE, validVariable);
    return [variable];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number | string | boolean): void {
    this.updateScenarioBlockSimple(block, propertyName, value);
  }

  private getPropertyType(block: ScenarioRuleBlockItem): RuleBlockPropertyTypeEnum {
    if (block.ruleBlock.name === RuleBlockNames.GET_NUMBER_VARIABLE) {
      return RuleBlockPropertyTypeEnum.NUMBER;
    } else if (block.ruleBlock.name === RuleBlockNames.GET_BOOLEAN_VARIABLE) {
      return RuleBlockPropertyTypeEnum.BOOLEAN;
    } else {
      return null;
    }
  }
}
