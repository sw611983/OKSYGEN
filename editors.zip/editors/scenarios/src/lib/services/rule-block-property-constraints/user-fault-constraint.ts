/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { RuleBlockPropertyNameEnum, RuleEditorRuleBlockProperty
} from '@oksygen-sim-train-libraries/components-services/rules';
import { TrainPropertyConstraintHelper } from './train-property-constraint.helper';
import { Logging } from '@oksygen-common-libraries/pio';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { BasePropertyConstraint, findRuleProperty } from './base-property.constraint';
import { UserFault, UserFaultDatabaseService } from '@oksygen-sim-train-libraries/components-services/user-faults';
import { map, tap } from 'rxjs/operators';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { ScenarioRuleBlockItem } from '../../models/scenario-rule-item.model';
import { SimPropertiesService, SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class UserFaultConstraint extends BasePropertyConstraint {

  private trainHelper: TrainPropertyConstraintHelper;

  constructor(
    simPropertyService: SimPropertiesService,
    logging: Logging,
    consistDataService: ConsistDataService,
    getScenario: () => Scenario,
    private userFaultDbService: UserFaultDatabaseService
  ) {
    super(simPropertyService, logging);
    this.trainHelper = new TrainPropertyConstraintHelper(simPropertyService, consistDataService, getScenario);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.USER_FAULT,
      RuleBlockPropertyNameEnum.VALUE
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): RuleEditorRuleBlockProperty[] {
    const validTrains = this.trainHelper.findValidTrains();
    const trainId = this.trainHelper.getTrainIdFromBlock(block);
    const scenarioTrain = this.trainHelper.getScenarioTrainById(trainId);
    const consist = this.trainHelper.getScenarioTrainConsist(scenarioTrain);
    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID, validTrains);

    const prop = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.USER_FAULT);
    const propName = prop?.value as string;

    let userFaults: UserFault[] = null;
    const dataSub = this.userFaultDbService.data().pipe(
      map(faults => faults.filter(fault => fault.train === consist?.name)),
      tap(filteredFaults => userFaults = filteredFaults)
    ).subscribe();
    dataSub?.unsubscribe();

    const props = this.findUserFaultProperties(userFaults, propName);
    const selectedUserFaultProperty = this.generateKeyValueProperty(
      block,
      RuleBlockPropertyNameEnum.USER_FAULT,
      RuleBlockPropertyNameEnum.VALUE,
      {
        allowedKeyValues: props?.allFaults,
        allowedValueValues: props?.values? props.values : []
      }
    );

    // must select a train before you can set property / value
    if (!trainIdProperty.isValid()) {
      selectedUserFaultProperty.forEach(p => { p.assignData({enabled: false}); });
    }
    if (!userFaults?.length) {
      const errorMessage = t(`User Faults not configured for this train.`);
      selectedUserFaultProperty.forEach((p, i) => {
        if (i === 0) { // only property selection shows error
          p.assignData({ enabled: false, errorMessage });
        } else { // value doesn't need to show the error
          p.assignData({ enabled: false });
        }
      });
    }
    return [ trainIdProperty, ...selectedUserFaultProperty ];
  }

  protected setClearedSimProperty(): SimPropertyState[] {
    const setTranslation = this.simPropertyService.translateService.instant(t('Set'));
    const clearedTranslation = this.simPropertyService.translateService.instant(t('Cleared'));
    // PRDOKS-1182: temporary hardcode Set = 1 and Clear = 2 until BE can handle string here
    const bool: SimPropertyState[] = [
      { name: setTranslation, displayName: setTranslation, value: 1 },
      { name: clearedTranslation, displayName: clearedTranslation, value: 2 }
    ];
    return bool;
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    if(propertyName === RuleBlockPropertyNameEnum.TRAIN_ID) {
      // if we're updating the train, reset the rule AND it's value to defaults
      const defaultuserFaultProperty = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.USER_FAULT);
      const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.USER_FAULT, defaultuserFaultProperty);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VALUE, defaultValue);
    } else if (propertyName === RuleBlockPropertyNameEnum.USER_FAULT) {
      // if updating the user fault, reset value to default
      const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VALUE, defaultValue);
    } else if (propertyName === RuleBlockPropertyNameEnum.VALUE) {
      // value only need update value
      this.updateScenarioBlockSimple(block, propertyName, value);
    } else {
      this.logging.warn(`[RuleBlockTrainHandler] failed to update unknown property ${propertyName}!`);
    }
  }

  private findUserFaultProperties(userFaults: UserFault[], propName: string): {allFaults: SimPropertyState[]; values: SimPropertyState[] } {
    const allFaults: SimPropertyState[] = [];
    // let selectedFault: SimProperty;

    userFaults?.forEach(f => {
      allFaults.push({name: f.displayName, displayName: f.displayName, value: f.id});
    });
    return { allFaults, values: this.setClearedSimProperty()};
  }
}
