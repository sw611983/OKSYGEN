/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';

import { BasePropertyConstraint, findRuleProperty } from './base-property.constraint';

export class AssessmentConstraint extends BasePropertyConstraint {
  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.ASSESSMENT_CATEGORY,
      RuleBlockPropertyNameEnum.REPORT_MESSAGE,
      RuleBlockPropertyNameEnum.ASSESSMENT_POINTS,
      RuleBlockPropertyNameEnum.TRIGGERED_ONCE
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const boolType = this.booleanSimProperty();
    const triggeredOnce = this.generateProperty(block, RuleBlockPropertyNameEnum.TRIGGERED_ONCE, boolType);

    //this code needs to be updated after the raw-string feature development is done (report-messge).
    const messDesc = this.description();
    const reportMessage = this.generateProperty(block, RuleBlockPropertyNameEnum.REPORT_MESSAGE, messDesc);
    reportMessage.assignData({ enabled: true });

    const assessmentPoints = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.ASSESSMENT_POINTS);
    const propAssessmentPoints = assessmentPoints?.value as string;
    const selectedAssessmentPoints = this.generateProperty(block, RuleBlockPropertyNameEnum.ASSESSMENT_POINTS);
    if (assessmentPoints && !propAssessmentPoints?.toString().match(new RegExp('^[0-9]*$'))) {
      const errorMessage = t(`This field can only contain numbers.`);
      selectedAssessmentPoints.assignData({ enabled: true, errorMessage });
    }

    const messageType = this.assessmentCategories();
    const assessmentCategory = this.generateProperty(block, RuleBlockPropertyNameEnum.ASSESSMENT_CATEGORY, messageType);
    assessmentCategory.assignData({ enabled: true });

    return [assessmentCategory, reportMessage, triggeredOnce, selectedAssessmentPoints];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number | string | boolean): void {
    this.updateScenarioBlockSimple(block, propertyName, value);
  }

  private assessmentCategories(): AssessmentCategory[] {
    const braking = this.simPropertyService.translateService.instant('Braking');
    const doors = this.simPropertyService.translateService.instant('Doors');
    const horn = this.simPropertyService.translateService.instant('Horn');
    const speed = this.simPropertyService.translateService.instant('Speed');
    const value: AssessmentCategory[] = [
      { name: braking, displayName: braking, value: 'Braking' },
      { name: doors, displayName: doors, value: 'Doors' },
      { name: horn, displayName: horn, value: 'Horn' },
      { name: speed, displayName: speed, value: 'Speed' }
    ];
    return value;
  }

  private description(): AssessmentCategory[] {
      // this enum is because the rule editor does not support the raw-string properties till the time of this development.
      // so to avoid any errors, we are passing an enum which is supported.
      // need to remove this once the raw-string property is supported.
      const assessment_desc = this.simPropertyService.translateService.instant('Rule based assessment');
      const value: AssessmentCategory[] = [
        { name: assessment_desc, displayName: assessment_desc, value: 'Rule based assessment' }
      ];
      return value;
    }
}

export interface AssessmentCategory {
  /** this is unique id of this sim property state */
  name: string;
  /** this is what we display */
  displayName: string;
  /** value should be a primitive (string, number, boolean) */
  value: any;
}
