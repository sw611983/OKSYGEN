/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Logging } from '@oksygen-common-libraries/pio';
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { ObjectStateConstraintHelper } from './object-state-constraint.helper';
import { BasePropertyConstraint } from './base-property.constraint';
import { SessionContext } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class FeatureConstraint extends BasePropertyConstraint {
  private objectHelper: ObjectStateConstraintHelper;

  constructor(simPropertyService: SimPropertiesService, logging: Logging, context: () => SessionContext) {
    super(simPropertyService, logging);
    this.objectHelper = new ObjectStateConstraintHelper(context);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.FEATURE_NAME
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const objectInfo = this.objectHelper.findTrackObjects(block);
    return [this.generateProperty(block, RuleBlockPropertyNameEnum.FEATURE_NAME, objectInfo.allowedObjects, objectInfo.displayedObjects)];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    this.updateScenarioBlockSimple(block, propertyName, value);
  }
}
