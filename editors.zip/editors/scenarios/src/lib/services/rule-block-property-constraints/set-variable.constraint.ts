/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RuleBlockPropertyNameEnum, RuleBlockPropertyTypeEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';

import { BasePropertyConstraint } from './base-property.constraint';
import { Logging } from '@oksygen-common-libraries/pio';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { isNil } from 'lodash';
import { SimPropertiesService, SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class SetVariableConstraint extends BasePropertyConstraint {
  constructor(simPropertyService: SimPropertiesService, logging: Logging, private getScenario: () => Scenario) {
    super(simPropertyService, logging);
  }

  managedProperties(): string[] {
    return [RuleBlockPropertyNameEnum.VARIABLE, RuleBlockPropertyNameEnum.VALUE];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const variables = this.getScenario()?.ruleVariables;

    const propertyType: RuleBlockPropertyTypeEnum = this.getPropertyType(block);
    let validVariable: SimPropertyState[];
    if (variables) {
      validVariable = variables
        .filter(variable => variable.type === propertyType)
        .map(variable => ({ name: variable.name, displayName: variable.name, value: variable.name }));
    }

    const variable = this.generateProperty(block, RuleBlockPropertyNameEnum.VARIABLE, validVariable);
    const value = this.generateProperty(block, RuleBlockPropertyNameEnum.VALUE);
    value.assignData({ enabled: false });

    return [variable, value];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number | string | boolean): void {
    this.updateScenarioBlockSimple(block, propertyName, value);

    const propertyType: RuleBlockPropertyTypeEnum = this.getPropertyType(block);
    const variableValue = this.getScenario()
      ?.ruleVariables.filter(variable => variable.type === propertyType)
      .find(variable => variable.name === value);

    this.updateScenarioBlockSimple(
      block,
      RuleBlockPropertyNameEnum.VALUE,
      !isNil(variableValue?.value) ? variableValue?.value : this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE)
    );
  }

  private getPropertyType(block: ScenarioRuleBlockItem): RuleBlockPropertyTypeEnum {
    if (block.ruleBlock.properties?.property[1]?.propertyType === RuleBlockPropertyTypeEnum.NUMBER) {
      return RuleBlockPropertyTypeEnum.NUMBER;
    } else if (block.ruleBlock.properties?.property[1]?.propertyType === RuleBlockPropertyTypeEnum.BOOLEAN) {
      return RuleBlockPropertyTypeEnum.BOOLEAN;
    } else {
      return null;
    }
  }
}
