/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Logging } from '@oksygen-common-libraries/pio';
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { ObjectStateConstraintHelper } from './object-state-constraint.helper';
import { TrainPropertyConstraintHelper } from './train-property-constraint.helper';
import { BasePropertyConstraint, findRuleProperty } from './base-property.constraint';
import { SessionContext } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class TrainSpatialConstraint extends BasePropertyConstraint {
  private objectHelper: ObjectStateConstraintHelper;
  private trainHelper: TrainPropertyConstraintHelper;

  constructor(
    simPropertyService: SimPropertiesService,
    logging: Logging,
    consistDataService: ConsistDataService,
    getScenario: () => Scenario,
    context: () => SessionContext
  ) {
    super(simPropertyService, logging);
    this.objectHelper = new ObjectStateConstraintHelper(context);
    this.trainHelper = new TrainPropertyConstraintHelper(simPropertyService, consistDataService, getScenario);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.VEHICLE_INDEX,
      RuleBlockPropertyNameEnum.FEATURE_NAME,
      RuleBlockPropertyNameEnum.PROMPT_ENABLE,
      RuleBlockPropertyNameEnum.PROMPT_TIME
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const validTrains = this.trainHelper.findValidTrains();
    const trainId = this.trainHelper.getTrainIdFromBlock(block);
    const scenarioTrain = this.trainHelper.getScenarioTrainById(trainId);
    const consist = this.trainHelper.getScenarioTrainConsist(scenarioTrain);

    const prop = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY);
    const propName = prop?.value as string;

    const data = this.trainHelper.findValidVehiclesAndProperties(scenarioTrain, consist, propName);

    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID, validTrains);
    const vehicleIndex = this.generateProperty(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX, data.validVehicles);
    // const selectedStateProperty = this.generateKeyValueProperty(
    //   block,
    //   RuleBlockPropertyNameEnum.VEHICLE_PROPERTY,
    //   RuleBlockPropertyNameEnum.VALUE,
    //   {
    //     allowedKeyValues: data.selectedVehicleAllProperties,
    //     allowedValueValues: data.selectedVehiclePropertyState?.simPropertyStateAssoc ?? []
    //   }
    // );
    // must select a train before you can set property / value
    if (!trainIdProperty.isValid()) {
      vehicleIndex.assignData({ enabled: false });
      // selectedStateProperty.forEach(p => { p.assignData({enabled: false}); });
    }
    // if (!vehicleIndex.isValid()) {
    //   selectedStateProperty.forEach(p => { p.assignData({enabled: false}); });
    // }

    const objectInfo = this.objectHelper.findTrackObjects(block);
    const featureProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.FEATURE_NAME, objectInfo.allowedObjects, objectInfo.displayedObjects);

    const boolType = this.booleanSimProperty();
    const promptEnable = this.generateProperty(block, RuleBlockPropertyNameEnum.PROMPT_ENABLE, boolType);
    const promptTime = this.generateProperty(block, RuleBlockPropertyNameEnum.PROMPT_TIME);
    return [trainIdProperty, vehicleIndex, featureProperty, promptEnable, promptTime];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number | string | boolean): void {
    if (propertyName === RuleBlockPropertyNameEnum.TRAIN_ID) {
      // if we're updating the train, reset the vehicle
      const defaultVehicleIndex = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX, defaultVehicleIndex);
    } else {
      // Other fields don't have dependants
      this.updateScenarioBlockSimple(block, propertyName, value);
    }
  }
}
