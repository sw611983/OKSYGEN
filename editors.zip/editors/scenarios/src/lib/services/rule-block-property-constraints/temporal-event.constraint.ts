/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';

import { BasePropertyConstraint, findRuleProperty } from './base-property.constraint';

export class TemporalEventConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.ELAPSED_TIME,
      RuleBlockPropertyNameEnum.PROMPT_ENABLE,
      RuleBlockPropertyNameEnum.PROMPT_TIME
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const boolType = this.booleanSimProperty();

    const propElapsed = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.ELAPSED_TIME);
    const propNameElapsed = propElapsed?.value as string;

    const selectedElapsedTime = this.generateProperty(
      block,
      RuleBlockPropertyNameEnum.ELAPSED_TIME
    );
    if(propElapsed && !propNameElapsed?.toString().match( new RegExp('^[0-9]*$'))) {
      const errorMessage = t(`This field can only contain numbers.`);
      selectedElapsedTime.assignData({ enabled: true, errorMessage });
    }

    const propPrompt = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.PROMPT_TIME);
    const propNamePrompt = propPrompt?.value as string;
    const selectedPromptTime = this.generateProperty(block, RuleBlockPropertyNameEnum.PROMPT_TIME);

    if(propNamePrompt && !propNamePrompt?.toString().match( new RegExp('^[0-9]*$'))) {
      const errorMessage = t(`This field can only contain numbers.`);
      selectedPromptTime.assignData({ enabled: true, errorMessage });
    }

    const promptEnable = this.generateProperty(block, RuleBlockPropertyNameEnum.PROMPT_ENABLE, boolType);

    return [ selectedElapsedTime, promptEnable, selectedPromptTime ];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    this.updateScenarioBlockSimple(block, propertyName, value);
  }
}
