/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Logging } from '@oksygen-common-libraries/pio';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { TrainPropertyConstraintHelper } from './train-property-constraint.helper';
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { BasePropertyConstraint, findRuleProperty } from './base-property.constraint';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';
//import { TranslateService } from '@oksygen-common-libraries/material/translate';

export class VehiclePropertyConstraint extends BasePropertyConstraint {
  private trainHelper: TrainPropertyConstraintHelper;

  constructor(
    simPropertyService: SimPropertiesService,
    logging: Logging,
    consistDataService: ConsistDataService,
    getScenario: () => Scenario
  ) {
    super(simPropertyService, logging);
    this.trainHelper = new TrainPropertyConstraintHelper(simPropertyService, consistDataService, getScenario);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.VEHICLE_INDEX,
      RuleBlockPropertyNameEnum.VEHICLE_PROPERTY,
      RuleBlockPropertyNameEnum.VALUE
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const validTrains = this.trainHelper.findValidTrains();
    const trainId = this.trainHelper.getTrainIdFromBlock(block);
    const scenarioTrain = this.trainHelper.getScenarioTrainById(trainId);
    const consist = this.trainHelper.getScenarioTrainConsist(scenarioTrain);

    const prop = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY);
    const propName = prop?.value as string;

    const data = this.trainHelper.findValidVehiclesAndProperties(scenarioTrain, consist, propName);

    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID, validTrains);
    const vehicleIndex = this.generateProperty(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX, data.validVehicles);
    const selectedStateProperty = this.generateKeyValueProperty(
      block,
      RuleBlockPropertyNameEnum.VEHICLE_PROPERTY,
      RuleBlockPropertyNameEnum.VALUE,
      {
        allowedKeyValues: data.selectedVehicleAllProperties,
        allowedValueValues: data.selectedVehiclePropertyState?.states ?? []
      }
    );
    // must select a train before you can set property / value
    if (!trainIdProperty.isValid()) {
      // eslint-disable-next-line max-len
      const errorMessage = data.validVehicles?.length > 0 ? undefined : this.simPropertyService.translateService.instant(t('{trainIdPropertyName} has no vehicles.'), {trainIdPropertyName: trainIdProperty.name});
      vehicleIndex.assignData({enabled: false, errorMessage });
      selectedStateProperty.forEach(p => { p.assignData({enabled: false }); });
    }
    if (!vehicleIndex.isValid()) {
      // eslint-disable-next-line max-len
      const errorMessage = data.selectedVehicleAllProperties?.length > 0 ? undefined : this.simPropertyService.translateService.instant(t('{vehicleIndexName} has no settable properties.'), {vehicleIndexName: vehicleIndex.name});
      selectedStateProperty.forEach(p => { p.assignData({enabled: false, errorMessage }); });
    }
    if (!data.selectedVehicleAllProperties?.length) {
      const errorMessage = t(`Train not configured for rules.`);
      selectedStateProperty.forEach((p, i) => {
        if (i === 0) { // only property selection shows error
          p.assignData({ enabled: false, errorMessage });
        } else { // value doesn't need to show the error
          p.assignData({ enabled: false });
        }
      });
    }
    return [ trainIdProperty, vehicleIndex, ...selectedStateProperty ];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    if(propertyName === RuleBlockPropertyNameEnum.TRAIN_ID) {
      // if we're updating the train, reset the vehicle, property AND it's value to defaults
      const defaultVehicleIndex = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX);
      const defaultVehicleProperty = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY);
      const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VEHICLE_INDEX, defaultVehicleIndex);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY, defaultVehicleProperty);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VALUE, defaultValue);
    } else if (propertyName === RuleBlockPropertyNameEnum.VEHICLE_INDEX) {
      // if we're updating the vehicle, reset the property AND it's value to defaults
      const defaultVehicleProperty = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY);
      const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VEHICLE_PROPERTY, defaultVehicleProperty);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VALUE, defaultValue);
    }
    else if (propertyName === RuleBlockPropertyNameEnum.VEHICLE_PROPERTY) {
      // if updating the train property, reset value to default
      const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VALUE, defaultValue);
    } else if (propertyName === RuleBlockPropertyNameEnum.VALUE) {
      // value only need update value
      this.updateScenarioBlockSimple(block, propertyName, value);
    } else {
      this.logging.warn(`[RuleBlockTrainHandler] failed to update unknown property ${propertyName}!`);
    }
  }
}
