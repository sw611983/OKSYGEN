/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { BasePropertyConstraint } from './base-property.constraint';
import { Logging } from '@oksygen-common-libraries/pio';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { TrainPropertyConstraintHelper } from './train-property-constraint.helper';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class TrainConstraint extends BasePropertyConstraint {
  private trainHelper: TrainPropertyConstraintHelper;

  constructor(
    simPropertyService: SimPropertiesService,
    logging: Logging,
    consistDataService: ConsistDataService,
    getScenario: () => Scenario
  ) {
    super(simPropertyService, logging);
    this.trainHelper = new TrainPropertyConstraintHelper(simPropertyService, consistDataService, getScenario);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.UNIT_CONVERSION
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const validTrains = this.trainHelper.findValidTrains();
    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID, validTrains);

    // TODO ,Modify unitConversion while working on Unit Conversion Implementation for Distance (Km  <->  Metre) and Speed (Km/h  <->  Metre/sec)
    const unitConversion = this.generateProperty(block, RuleBlockPropertyNameEnum.UNIT_CONVERSION);
    unitConversion.assignData({enabled: false});

    return [ trainIdProperty, unitConversion ];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    this.updateScenarioBlockSimple(block, propertyName, value);
  }
}
