/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FALSE_STR, TRUE_STR } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import {
  RuleBlock,
  RuleBlockConstraint,
  RuleBlockProperty,
  RuleBlockPropertyNameEnum,
  RuleBlockReference,
  RuleProperty,
  RulePropertyAllowedValues,
  RuleTemplateRuleBlock
} from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { SimPropertiesService, SimProperty, SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

/**
 * Returns the Property with the given name from the given Rule Block, if possible.
 *
 * @param ruleBlock May be null.
 * @param propName  The name of the property of interest.
 */
export function findRuleBlockProperty(ruleBlock: RuleBlock, propName: string): RuleBlockProperty {
  return ruleBlock?.properties?.property?.find(p => p.name === propName);
}

/**
 * Returns the Property with the given name from the given Rule Block, if possible.
 *
 * @param ruleBlock May be null.
 * @param propName  The name of the property of interest.
 */
export function findRuleProperty(ruleBlock: RuleTemplateRuleBlock | RuleBlockReference, propName: string): RuleProperty {
  return ruleBlock?.properties?.property?.find(p => p.name === propName);
}

/**
 * Rule Blocks are tricky.
 * We must note that there are 3 types - Rule Block, Template Rule Block and Scenario Rule Block.
 * Rule Blocks are the most base level building blocks
 * and can be all kinds of things (conditions, variables, object references).
 * A Template Block is built in the rule editor, and can have multiple rule blocks.
 * A Template Block could be "at time foo (rule block 1), set the rain level (rule block 2) to bar".
 * A Scenario Block would then "implement" this template block and fill in the foo and bar.
 * So the Scenario Block would say foo time = 30 seconds, bar rain level = 50 Percent.
 * So our hypothetical scenario would then set the rain level to 50% 30 seconds in.
 * this is all done through the use of "properties".
 * A Rule Blocks property defines meta data for the Template & Scenario Blocks to use.
 * Things like it's display name, it's type, possible values (if an enum), units, etc.
 * A Template Block then may implement the rule block properties.
 * If it does not, the scenario block may implement them.
 */
export abstract class BasePropertyConstraint extends RuleBlockConstraint<ScenarioRuleBlockItem, ScenarioRulePropertyItem, void> {

  constructor(
    protected simPropertyService: SimPropertiesService,
    protected logging: Logging
  ) { super(); }
  abstract override generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[];
  abstract override updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void;

  protected newBlankProperty(type: string): ScenarioRulePropertyItem {
    const property = new ScenarioRulePropertyItem({ type, enabled: true });
    return property;
  }

  /**
   * Get the ```SimProperty```s that are in this group.
   * NOTE that we only return properties that are scriptable AND have state!
   *
   * @param groupName the sim property group name
   */
  protected getSimPropertyGroup(groupName: string): SimProperty[] {
    const group = this.simPropertyService.getSimPropertyGroupSync(groupName);
    if (!group || !group.simProperty) {
      return [];
    }
    return group.simProperty.filter(prop => prop.isWritable && prop.states?.length > 0);
  }

  /**
   * Get the list of sim properties that are in this group.
   * NOTE that we only return properties that are scriptable AND have state!
   *
   * @param groupName the sim property group name
   */
  protected getSimPropertyGroupProperties(groupName: string): SimPropertyState[] {
    const properties = this.getSimPropertyGroup(groupName).map(sp => {
      const stateAssoc: SimPropertyState = {
        name: sp.name,
        displayName: sp.displayName,
        value: sp.displayName
      };
      return stateAssoc;
    });
    return properties;
  }

  protected booleanSimProperty(): SimPropertyState[] {
    const trueTranslation = this.simPropertyService.translateService.instant(TRUE_STR);
    const falseTranslation = this.simPropertyService.translateService.instant(FALSE_STR);
    const bool: SimPropertyState[] = [
      { name: trueTranslation, displayName: trueTranslation, value: true },
      { name: falseTranslation, displayName: falseTranslation, value: false }
    ];
    return bool;
  }

  protected instructorPromptMessage(): SimPropertyState[] {
    const InformationTranslation = this.simPropertyService.translateService.instant('Information');
    const ValidationTranslation = this.simPropertyService.translateService.instant('Validation');
    const WarningTranslation = this.simPropertyService.translateService.instant('Warning');
    const ErrorTranslation = this.simPropertyService.translateService.instant('Error');
    const value: SimPropertyState[] = [
      { name: InformationTranslation, displayName: InformationTranslation, value: 'Information' },
      { name: ValidationTranslation, displayName: ValidationTranslation, value: 'Validation' },
      { name: WarningTranslation, displayName: WarningTranslation, value: 'Warning' },
      { name: ErrorTranslation, displayName: ErrorTranslation, value: 'Error' }
    ];
    return value;
  }

  /**
   * Generate a scenario rule property that has a key/value property.
   * You should refer to the comment on ```RuleBlockHandler``` for why this is necessary.
   * In short, a property can be "nested" within another property.
   * In pseudo JSON, "environmentProperty.cloudDensityPercentage = 100"
   * This is structured as key1 = "environment", value1 = "cloudDensity",
   * key2 ="cloudDensity", value2 = "100 Percent".
   * Note that key1 value1 will be referred to as the "name" property.
   * Note that key2 value2 will be referred to as the "value" property.
   * This function will parse the above data structure and produce 1-2 properties depending on the block.
   * 1 property if template was supplied (as can only override the value), 2 if not.
   *
   * @param block the block this property is on
   * @param keyname the property name of the key property
   * @param valueName the property name of the value property (this is usually just "value"), which is the default if unsupplied
   * @param keyValues (optional) list of allowed values for the value property
   */
  protected generateKeyValueProperty(
    block: ScenarioRuleBlockItem,
    keyname: string,
    valueName: string = RuleBlockPropertyNameEnum.VALUE,
    allowedValues: {allowedKeyValues?: SimPropertyState[]; allowedValueValues?: SimPropertyState[]; displayedKeyValues?: SimPropertyState[]}
  ): ScenarioRulePropertyItem[] {
    // WARNING - this is generating properties, so DO NOT try and access block.properties!!
    // Refer to the above comments on ```RuleBlockHandler``` for a high level of what we're doing.
    // first get rule, template & scenario block properties (both their name and value)
    const property = this.newBlankProperty(keyname);
    const properties = [ property ];
    // first get rule block, template block and scenario block properties
    const ruleBlockProperty      = findRuleBlockProperty(block.ruleBlock, keyname);
    const ruleBlockValueProperty = findRuleBlockProperty(block.ruleBlock, valueName);
    const templateNameProperty   = findRuleProperty(block.templateBlock, keyname);
    const templateValueProp      = findRuleProperty(block.templateBlock, valueName);
    const scenarioNameProperty   = findRuleProperty(block.scenarioBlock, keyname);
    const scenarioValueProperty  = findRuleProperty(block.scenarioBlock, valueName);
    if (!ruleBlockProperty || !ruleBlockValueProperty) {
      const err = `Scenario rule block ${block?.scenarioBlock?.blockId} in template ${block?.templateBlock?.id}`;
      this.logging.warn(`[RuleblockHandler] ${err} key value block ${keyname} ${valueName} does not exist!`);
      return [];
    }
    let propertyName: string;
    let propertyDisplayName: string;
    let propertyValue: string | number | boolean;
    // order of value priority is rule block < template block < scenario block
    // start by setting property to rule block
    // then if template is supplied, override. Then if scenario is supplied, override.
    if (ruleBlockProperty) {
      propertyName = ruleBlockProperty.name;
      propertyDisplayName = ruleBlockValueProperty.displayName;
    }

    if (templateNameProperty && this.isNotEmpty(templateNameProperty.value)) {
      // if the rule template defines a value we cannot overwrite it and are setting it's corresponding value
      propertyName = templateNameProperty.value as string;
      const simProp = this.simPropertyService.getSimPropertySync(propertyName);
      propertyDisplayName = simProp?.displayName ?? propertyName;
      if (scenarioValueProperty) {
        propertyValue = scenarioValueProperty.value;
      } else if (templateValueProp) {
        propertyValue = templateValueProp.value;
      } else {
        propertyValue = ruleBlockValueProperty.defaultValue;
      }
      // user is setting the value NOT the "type". IE, env property -> rain % -> 5%, we can only set 5%, hence set type to valueName
      property.assignData({type: valueName});
    } else {
      // if template was not supplied we must generate a new value property
      // this is because we'll only have name = environment, value = "cloud %"
      // but will be missing the name = "cloud %" value = "100%"
      const valueProperty = this.newBlankProperty(valueName);
      let valuePropertyName: string;
      let valuePropertyDisplayName: string;
      let valuePropertyValue: string | number | boolean;
      propertyName = ruleBlockProperty.name;
      propertyDisplayName = ruleBlockProperty.displayName;

      if (scenarioNameProperty) {
        propertyValue = scenarioNameProperty.value;
        valuePropertyName = scenarioValueProperty.name;
        // prefer to use what was selected, default to value if it can't find it
        const simProp = this.simPropertyService.getSimPropertySync(scenarioNameProperty.value as string ?? valuePropertyName);
        valuePropertyDisplayName = simProp?.displayName ?? ruleBlockValueProperty.displayName;
      } else {
        propertyValue = ruleBlockProperty.defaultValue;
        valuePropertyName = ruleBlockValueProperty.name;
        valuePropertyDisplayName = ruleBlockValueProperty.displayName;
      }

      if (scenarioValueProperty) {
        valuePropertyValue = scenarioValueProperty.value;
      } else {
        valuePropertyValue = ruleBlockValueProperty.defaultValue;
      }

      valueProperty.assignData({ name: valuePropertyName, displayName: valuePropertyDisplayName, value: valuePropertyValue });
      properties.push(valueProperty);

      if (allowedValues) {
        this.setAllowedValues(property, allowedValues.allowedKeyValues, allowedValues.displayedKeyValues);
        this.setAllowedValues(valueProperty, allowedValues.allowedValueValues);
      }
    }

    property.assignData({ name: propertyName, displayName: propertyDisplayName, value: propertyValue });
    // finally, we need to get our list of options (if they exist)
    properties.forEach(p => {
      if (p.name && !p.allowedValues) {
        const simProp = this.simPropertyService.getSimPropertySync(p.name);
        if (simProp) {
          // if it doesn't have state, shouldn't be a dropdown
          if (simProp?.states?.length > 0) {
            p.allowedValues = new RulePropertyAllowedValues(simProp.states);
          }
        }
      }
    });
    // shouldn't be able to set value if property isn't valid!
    if (!property.isValid() && properties.length === 2) {
      properties[1].assignData({enabled: false});
    }
    return properties;
  }

  private setAllowedValues(
    property: ScenarioRulePropertyItem, allowedValues: SimPropertyState[], displayedValues?: SimPropertyState[]
  ): void {
    if (allowedValues?.length > 0) {
      property.allowedValues = new RulePropertyAllowedValues(allowedValues, displayedValues);
    }
  }

  /**
   * Simple block properties are just key value.
   * This method will read through the rule, template and scenario blocks to generate
   * the appropriate property.
   *
   * @param block the block this property is on
   * @param keyname the "name" of this property
   * @param allowedValues (optional) a list of values it's allowed to have
   * @param displayedValues (optional) a list of values it's allowed to display
   */
  generateProperty(
    block: ScenarioRuleBlockItem,
    keyname: string,
    allowedValues?: SimPropertyState[],
    displayedValues?: SimPropertyState[]
  ): ScenarioRulePropertyItem {
    // WARNING - this is generating properties, so DO NOT try and access block.properties!!
    const property = this.newBlankProperty(keyname);
    // the rule block defined in the template may supply a default
    const ruleBlockProperty = findRuleBlockProperty(block?.ruleBlock,  keyname);
    let propertyName: string;
    let propertyDisplayName: string;
    let propertyValue: string | number | boolean;
    let propertyDefault: string | number | boolean;
    let propertyDefaultUnits: string;
    if (ruleBlockProperty) {
      propertyName = ruleBlockProperty.name;
      propertyDisplayName = ruleBlockProperty.displayName;
      propertyDefault = ruleBlockProperty.defaultValue;
      propertyValue = ruleBlockProperty.defaultValue;
      propertyDefaultUnits = ruleBlockProperty.defaultUnits;
    }
    // if the template defines the values use it, scenario cannot override.
    const templateNameProperty = findRuleProperty(block?.templateBlock, keyname);
    if (templateNameProperty) {
      propertyValue = templateNameProperty.value;
    }
    // the rule block defined in the scenario defines which property we're setting
    const nameProperty = findRuleProperty(block?.scenarioBlock, keyname);
    if (nameProperty) {
      propertyValue = nameProperty.value;
    }
    if (!property.defaultValue) { property.defaultValue = property.value; }
    // finally, we need to get our list of options (if they exist)
    if (allowedValues) {
      property.allowedValues = new RulePropertyAllowedValues(allowedValues, displayedValues);
    }
    if (property.name && !allowedValues) {
      const simProp = this.simPropertyService.getSimPropertySync(property.name);
      if (simProp) {
        property.allowedValues = new RulePropertyAllowedValues(simProp.states, displayedValues);
      }
    }
    property.assignData({
      name: propertyName,
      displayName: propertyDisplayName,
      defaultValue: propertyDefault,
      value: propertyValue,
      defaultUnits: propertyDefaultUnits
    });
    return property;
  }

  // FIXME Appears unused?
  getPropertyValue(block: ScenarioRuleBlockItem, propName: string): string | number | boolean {
    // the rule block defined in the template may supply a default
    const ruleBlockProperty = block?.ruleBlock?.properties?.property
      .find(p => p.name === propName);
    let propertyValue: string | number | boolean;
    if (ruleBlockProperty) {
      propertyValue = ruleBlockProperty.defaultValue;
    }
    // if the template defines the values use them. Overridden by scenario later if it exists
    const templateNameProperty = block?.templateBlock?.properties?.property
      .find(p => p.name === propName);
    if (templateNameProperty) {
      propertyValue = templateNameProperty.value;
    }
    // the rule block defined in the scenario defines which property we're setting
    const nameProperty = block?.scenarioBlock?.properties?.property
      .find(p => p.name === propName);
    if (nameProperty) {
      propertyValue = nameProperty.value;
    }
    return propertyValue;
  }

  getPropertyDefault(block: ScenarioRuleBlockItem, propName: string): string | number | boolean {
    // the rule block defined in the template may supply a default
    const ruleBlockProperty = block?.ruleBlock?.properties?.property
      .find(p => p.name === propName);
    let propertyValue: string | number | boolean;
    if (ruleBlockProperty) {
      propertyValue = ruleBlockProperty.defaultValue;
    }
    return propertyValue;
  }

  /**
   * Update a scenario block property value.
   * If the scenario block doesn't exist, this will also create that scenario block and append it.
   * Note that if you're updating a "name" property, we must also update the "value" property.
   * IE, if we're changing "cloud%" to "rain%", we must also change it's value to rain%'s default value.
   *
   * @param block the block this property is on
   * @param value the new value
   * @param simPropertyGroupName (optional) the name of the sim property group if it's part of one
   * @param keyname (optional) the name of the "name" property, ie "environment_property"
   * @param valuename (optional) the name of the "value" property (defaults to "value")
   *
   * @deprecated
   */
  protected updateScenarioBlockKeyValue(
    block: ScenarioRuleBlockItem,
    value: number|string|boolean,
    simPropertyGroupName?: string,
    keyname?: string,
    valuename = RuleBlockPropertyNameEnum.VALUE
  ): void {
    this.upsertScenarioBlock(block);
    const simPropertyGroup = this.simPropertyService.getSimPropertyGroupSync(simPropertyGroupName);
    // FIXME equivocating displayName and name is incorrect and could cause weird bugs
    const simProperty = simPropertyGroup?.simProperty.find(sp => sp.name === value || sp.displayName === value);
    const ruleBlockValue = block.ruleBlock.properties.property.find(rb => rb.name === valuename);
    // FIXME this won't work if the value field is updated to a valid name field!
    if (simProperty) {
      // in this case we're updating the type, ie cloud density -> rain percentage
      this.upsertScenarioBlockProperty(block, keyname, value);
      // need to also update the value to the new properties default
      const newValue = ruleBlockValue.defaultValue;
      this.upsertScenarioBlockProperty(block, valuename, newValue);
    } else {
      // else we're just updating the value, ie 15 -> 45
      this.upsertScenarioBlockProperty(block, valuename, value);
    }
    // once we've updated our scenario properties, we can re-generate our property list
    block.properties = this.generatePropertyList(block);
  }

  /**
   * Updates a property.
   * Note that if the scenario block doesn't exist, it must also be created.
   *
   * @param block the block this property is on
   * @param propertyName the name of the property to update
   * @param value the new value
   */
  protected updateScenarioBlockSimple(
    block: ScenarioRuleBlockItem,
    propertyName: string,
    value: number|string|boolean
  ): void {
    this.upsertScenarioBlock(block);
    this.upsertScenarioBlockProperty(block, propertyName, value);
    return;
  }

  /**
   * If our block doesn't have the required scenario block, append it with empty properties.
   * Does nothing if the block already exists.
   *
   * @param block our rule block to work with
   */
  protected upsertScenarioBlock(block: ScenarioRuleBlockItem): RuleBlockReference {
    if (!block.scenarioBlock) {
      block.scenarioBlock = { blockId: block.templateBlock.id, properties: { property: [] }};
    }
    if (!block.scenarioBlock.properties) {
      block.scenarioBlock.properties = { property: [] };
    }
    if (!block.scenarioBlock.properties.property) {
      block.scenarioBlock.properties.property = [];
    }
    return block.scenarioBlock;
  }

  /**
   * Upsert a scenario block property.
   *
   * @param block the block to upsert
   * @param name the name of the property we're updating
   * @param value the new value of the property
   */
  protected upsertScenarioBlockProperty(
    block: ScenarioRuleBlockItem,
    name: string,
    value: string|number|boolean
  ): RuleProperty {
    this.upsertScenarioBlock(block);
    const property = block.scenarioBlock.properties.property.find(p => p.name === name);
    if (!property) {
      const newProperty: RuleProperty = {
        name,
        value
      };
      block.scenarioBlock.properties.property.push(newProperty);
      return newProperty;
    } else {
      property.value = value;
      return property;
    }
  }

  /**
   * Returns whether the value has been "set". "" null and undefined are false, everything else (including false and 0) are true.
   * @param value a value to check - can be anything.
   */
  isNotEmpty(value: any): boolean {
    return value !== '' && value !== undefined && value !== null;
  }
}
