/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';

import { BasePropertyConstraint as BasePropertyConstraint } from './base-property.constraint';

export class InstructorPromptConstraint extends BasePropertyConstraint {

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.MESSAGE,
      RuleBlockPropertyNameEnum.MESSAGE_TYPE,
      RuleBlockPropertyNameEnum.AUTO_DISMISS,
      RuleBlockPropertyNameEnum.DISMISS_DURATION
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {

    const selectedMessage = this.generateProperty(block, RuleBlockPropertyNameEnum.MESSAGE);

    const messageType = this.instructorPromptMessage();
    const selectedMessageType = this.generateProperty(block, RuleBlockPropertyNameEnum.MESSAGE_TYPE, messageType);

    const boolType = this.booleanSimProperty();
    const autoDismiss = this.generateProperty(block, RuleBlockPropertyNameEnum.AUTO_DISMISS, boolType);

    const selectedDismissDuration = this.generateProperty(block, RuleBlockPropertyNameEnum.DISMISS_DURATION);

    return [ selectedMessage, selectedMessageType, autoDismiss, selectedDismissDuration ];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    this.updateScenarioBlockSimple(block, propertyName, value);
  }
}
