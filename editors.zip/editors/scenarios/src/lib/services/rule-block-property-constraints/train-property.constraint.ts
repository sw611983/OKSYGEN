/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Logging } from '@oksygen-common-libraries/pio';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { ScenarioRuleBlockItem, ScenarioRulePropertyItem } from '../../models/scenario-rule-item.model';
import { BasePropertyConstraint, findRuleProperty } from './base-property.constraint';
import { TrainPropertyConstraintHelper } from './train-property-constraint.helper';
import { SimPropertiesService, SimProperty, SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

export class TrainPropertyConstraint extends BasePropertyConstraint {
  private trainHelper: TrainPropertyConstraintHelper;

  constructor(
    simPropertyService: SimPropertiesService,
    logging: Logging,
    consistDataService: ConsistDataService,
    getScenario: () => Scenario
  ) {
    super(simPropertyService, logging);
    this.trainHelper = new TrainPropertyConstraintHelper(simPropertyService, consistDataService, getScenario);
  }

  managedProperties(): string[] {
    return [
      RuleBlockPropertyNameEnum.TRAIN_ID,
      RuleBlockPropertyNameEnum.TRAIN_PROPERTY,
      RuleBlockPropertyNameEnum.VALUE
    ];
  }

  generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const validTrains = this.trainHelper.findValidTrains();
    const trainId = this.trainHelper.getTrainIdFromBlock(block);
    const scenarioTrain = this.trainHelper.getScenarioTrainById(trainId);
    const consist = this.trainHelper.getScenarioTrainConsist(scenarioTrain);

    const prop = findRuleProperty(block.scenarioBlock, RuleBlockPropertyNameEnum.TRAIN_PROPERTY);
    const propName = prop?.value as string;

    let selectedProperty: SimProperty;
    let trainProperties: SimPropertyState[] = [];

    if(scenarioTrain) {
      const isDriven = scenarioTrain.driverType === DriverType.HUMAN;
      const props = this.trainHelper.findProperties(consist, false, propName, isDriven);
      trainProperties  = props.allProperties;
      selectedProperty = props.selectedProperty;
    }

    const trainIdProperty = this.generateProperty(block, RuleBlockPropertyNameEnum.TRAIN_ID, validTrains);
    const selectedStateProperty = this.generateKeyValueProperty(
      block,
      RuleBlockPropertyNameEnum.TRAIN_PROPERTY,
      RuleBlockPropertyNameEnum.VALUE,
      {
        allowedKeyValues: trainProperties,
        allowedValueValues: selectedProperty?.states ?? []
      }
    );
    // must select a train before you can set property / value
    // FIXME changing driver type of selected train needs to reset fields
    if (!trainIdProperty.isValid()) {
      selectedStateProperty.forEach(p => { p.assignData({enabled: false}); });
    }
    if (!trainProperties?.length) {
      const errorMessage = t(`Train not configured for rules.`);
      selectedStateProperty.forEach((p, i) => {
        if (i === 0) { // only property selection shows error
          p.assignData({ enabled: false, errorMessage });
        } else { // value doesn't need to show the error
          p.assignData({ enabled: false });
        }
      });
    }
    return [ trainIdProperty, ...selectedStateProperty ];
  }

  updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean): void {
    if(propertyName === RuleBlockPropertyNameEnum.TRAIN_ID) {
      // if we're updating the train, reset the property AND it's value to defaults
      const defaultTrainProperty = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.TRAIN_PROPERTY);
      const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.TRAIN_PROPERTY, defaultTrainProperty);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VALUE, defaultValue);
    } else if (propertyName === RuleBlockPropertyNameEnum.TRAIN_PROPERTY) {
      // if updating the train property, reset value to default
      const defaultValue = this.getPropertyDefault(block, RuleBlockPropertyNameEnum.VALUE);
      this.updateScenarioBlockSimple(block, propertyName, value);
      this.updateScenarioBlockSimple(block, RuleBlockPropertyNameEnum.VALUE, defaultValue);
    } else if (propertyName === RuleBlockPropertyNameEnum.VALUE) {
      // value only need update value
      this.updateScenarioBlockSimple(block, propertyName, value);
    } else {
      this.logging.warn(`[RuleBlockTrainHandler] failed to update unknown property ${propertyName}!`);
    }
  }
}
