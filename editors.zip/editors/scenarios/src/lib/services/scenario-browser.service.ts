/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { AbstractBrowserService } from '@oksygen-sim-train-libraries/components-services/editors';

/**
 * Holds the state of the scenario browser screen.
 */
@Injectable()
export class ScenarioBrowserService extends AbstractBrowserService {
  private selectedScenario = new BehaviorSubject<Scenario>(null);
  private searchText = new BehaviorSubject<string>('');


  constructor() {
    super('ScenarioBrowserService');
  }

  /**
   * This is called when the page is first opened
   */
  public override initialiseEditing(): void {
    super.initialiseEditing();
    // TODO: Any local initialisation for this
  }

  public setSelectedScenario(scenario: Scenario): void {
    this.selectedScenario.next(scenario);
  }

  public getSelectedScenario$(): Observable<Scenario> {
    return this.selectedScenario.asObservable();
  }

  public setSearchText(text: string): void {
    this.searchText.next(text);
  }

  public getSearchText$(): Observable<string> {
    return this.searchText.asObservable();
  }
}
