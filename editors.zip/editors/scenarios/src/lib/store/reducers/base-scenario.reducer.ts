/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { on } from '@ngrx/store';
import { cloneDeep, merge } from 'lodash';

import { updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { asFreezableScenario, Scenario, ScenarioRuleVariable } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { scenarioEditorActions } from '../scenario-editor.actions';
import { ScenarioEditorData, scenarioEditorDataAdapter, ScenarioEditorState } from '../scenario-editor.state';

export const BASE_SCENARIO_REDUCER_TYPES = [
  on(
    // FIXME @@@ Hardcoded values need to be parameterised
    scenarioEditorActions.newScenario,
    (state: ScenarioEditorState, action: { id: string; name: string }) => {
      const value: ScenarioEditorData = {
        id: action.id,
        savedName: undefined,
        unsavedChanges: true,
        editorItem: {
          id: action.id,
          scenarioId: null,
          version: 1,
          tracknetworkName: '', // FIXME Handle the single track case
          tracknetworkSkinName: '', // FIXME Handle the single track with single skin case
          scenarioDescription: '',
          subject: '',
          name: action.name, // Note this is deliberately duplicating the above property
          scenarioStartTime: '2021-01-01T12:00:00Z', // TODO use a better default date
          scenarioIsCore: false,
          scenarioIsActive: false,
          type: t('Driver Scenario'),
          scenarioType: { id: -1, name: t('Driver Scenario') }, // Note this is should be a more detailed version of the above property
          world: {
            trackNetwork: {
              title: '',
              version: '1'
            },
            trackSkin: {
              name: ''
            },
            signallingScheme: {
              name: '',
              version: '1'
            },
            object: [],
            objectModification: []
          },
          scenarioTrains: {
            scenarioTrain: []
          },
          scenarioTrainDrivers: {
            scenarioTrainDriver: []
          },
          virtualLocations: {
            virtualLocation: []
          },
          rule: [],
          multimedia: [],
          environment: {
            cloudDensityPercentage: 0,
            fogPercentage: 0,
            hazePercentage: 0,
            lightningPercentage: 0,
            rainPercentage: 0,
            snowPercentage: 0,
            sunBrightnessPercentage: 0,
            sunGlarePercentage: 0,
            tunnelSmokePercentage: 0,
            windDirectionAngle: 0,
            windGust: 0,
            windStrengthKmH: 0
          },
          scenarioHistory: [],
          ruleVariables: []
        },
        canRedo: false,
        canUndo: false
      };

      return scenarioEditorDataAdapter.setOne(value, state);
    }
  ),
  on(scenarioEditorActions.loadScenario, (state: ScenarioEditorState, action: { id: string; original: Scenario }) => {
  // Note that we're putting things in the store here, which means they will get frozen.
  // We do not want to freeze common objects (e.g. ObjectTypes' icons have caches that must remain writable),
  // so we clone the scenario before giving it to the store.
  // FIXME A safer solution to this is to avoid having mutable objects in the scenario.
  // This means having some way of storing object icons separate from the types. See INTOSC-8421
  const scenario = action.original;
  const original = cloneDeep(asFreezableScenario(scenario));

    const value = {
      id: action.id,
      savedName: original.name,
      unsavedChanges: false,
      editorItem: original,
      canRedo: false,
      canUndo: false
    };

    return scenarioEditorDataAdapter.setOne(value, state);
  }),
  on(scenarioEditorActions.loadScenarioUnsafe, (state: ScenarioEditorState, action: { id: string; original: Scenario }) => {
    const value = {
      id: action.id,
      savedName: action.original.name,
      unsavedChanges: false,
      editorItem: action.original,
      canRedo: false,
      canUndo: false
    };

    return scenarioEditorDataAdapter.setOne(value, state);
  }),
  on(scenarioEditorActions.saveScenario, (state: ScenarioEditorState, action: { id: string; save: Scenario }) => {
    const value = cloneDeep(state.entities[action.id]);

    return scenarioEditorDataAdapter.setOne(
      {
        ...value,
        unsavedChanges: false,
        savedName: action.save.name,
        editorItem: action.save // replacing this, as we updated the version number
      },
      state
    );
  }),
  on(scenarioEditorActions.scenarioClosed, (state: ScenarioEditorState, action: { id: string }) => scenarioEditorDataAdapter.removeOne(action.id, state)),
  on(scenarioEditorActions.setScenarioName, (state: ScenarioEditorState, action: { id: string; name: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    if (value.editorItem.scenarioDescription === action.name) {
      // FIXME @@@ A nasty naming issue is starting to arise...
      return state;
    }

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      name: action.name
    });
  }),

  on(scenarioEditorActions.setSelectedWorld, (state: ScenarioEditorState, action: { id: string; trackName: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    if (value.editorItem.tracknetworkName === action.trackName) {
      return state;
    }

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      tracknetworkName: action.trackName,
      tracknetworkSkinName: '', // FIXME Handle the single skin case
      world: {
        ...value.editorItem.world,
        trackNetwork: {
          ...value.editorItem.world.trackNetwork,
          title: action.trackName
        },
        trackSkin: { name: '' }
      }
    });
  }),
  on(scenarioEditorActions.setSelectedSkin, (state: ScenarioEditorState, action: { id: string; skinName: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    if (value.editorItem.tracknetworkSkinName === action.skinName) {
      return state;
    }

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      tracknetworkSkinName: action.skinName,
      world: {
        ...value.editorItem.world,
        trackSkin: { name: action.skinName }
      }
    });
  }),
  on(scenarioEditorActions.setDateTime, (state: ScenarioEditorState, action: { id: string; dateTime: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    if (value.editorItem.scenarioStartTime === action.dateTime) {
      return state;
    }

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      scenarioStartTime: action.dateTime
    });
  }),
  on(scenarioEditorActions.setScenarioDescription, (state: ScenarioEditorState, action: { id: string; desc: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      scenarioDescription: action.desc
    });
  }),
  on(scenarioEditorActions.setProperty, (state: ScenarioEditorState, action: { id: string; propertyName: string; propertyValue: any }) => {
    const value = cloneDeep(state.entities[action.id]);
    // cast to any to support projects adding extra fields to the Scenario.
    (value.editorItem as any)[action.propertyName] = action.propertyValue;

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem
    });
  }),
  on(scenarioEditorActions.setSubject, (state: ScenarioEditorState, action: { id: string; subject: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      subject: action.subject
    });
  }),
  on(scenarioEditorActions.setInitialEnvironmentState, (state: ScenarioEditorState, action: { id: string; property: string; value: number }) => {
    const value = cloneDeep(state.entities[action.id]);
    const environment = value.editorItem.environment;
    if ((environment as any)[action.property] === action.value) {
      return state;
    }
    if (action.property === 'cloudDensityPercentage') {
      if (environment.fogPercentage) { environment.fogPercentage = 0; }
      if (environment.hazePercentage) { environment.hazePercentage = 0; }
    }
    if (action.property === 'fogPercentage') {
      if (environment.cloudDensityPercentage) { environment.cloudDensityPercentage = 0; }
      if (environment.hazePercentage) { environment.hazePercentage = 0; }
    }
    if (action.property === 'hazePercentage') {
      if (environment.fogPercentage) { environment.fogPercentage = 0; }
      if (environment.cloudDensityPercentage) { environment.cloudDensityPercentage = 0; }
    }

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      environment: {
        ...environment,
        [action.property]: action.value
      }
    });
  }),
  on(scenarioEditorActions.setAssessment, (state: ScenarioEditorState, action: { id: string; assessment: boolean }) => {
    const value = cloneDeep(state.entities[action.id]);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      assessment: action.assessment
    });
  }),
  on(scenarioEditorActions.setInitialScore, (state: ScenarioEditorState, action: { id: string; initialScore: number }) => {
    const value = cloneDeep(state.entities[action.id]);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      initialScore: action.initialScore
    });
  }),
  on(scenarioEditorActions.setTargetScore, (state: ScenarioEditorState, action: { id: string; targetScore: number }) => {
    const value = cloneDeep(state.entities[action.id]);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      targetScore: action.targetScore
    });
  }),
  on(scenarioEditorActions.setActiveStatus, (state: ScenarioEditorState, action: { id: string; status: boolean }) => {
    const value = cloneDeep(state.entities[action.id]);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      scenarioIsActive: action.status
    });
  }),
  on(scenarioEditorActions.addScenarioRuleVariable, (state: ScenarioEditorState, action: { id: string; variable: ScenarioRuleVariable }) => {
    const value = cloneDeep(state.entities[action.id]);
    const ruleVariables = value?.editorItem?.ruleVariables ?? [];
    ruleVariables.push(action.variable);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      ruleVariables
    });
  }),
  on(
    scenarioEditorActions.updateScenarioRuleVariable,
    (state: ScenarioEditorState, action: { id: string; name: string; variable: Partial<ScenarioRuleVariable> }) => {
      const value = cloneDeep(state.entities[action.id]);
      const ruleVariables = value?.editorItem?.ruleVariables ?? [];
      const index = ruleVariables.findIndex(variable => variable.name === action.name);

      if (index > -1) {
        ruleVariables[index] = merge(ruleVariables[index], cloneDeep(action.variable));
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
        ...value.editorItem,
        ruleVariables
      });
    }
  ),
  on(scenarioEditorActions.deleteScenarioRuleVariable, (state: ScenarioEditorState, action: { id: string; name: string }) => {
    const value = cloneDeep(state.entities[action.id]);
    let ruleVariables = value?.editorItem?.ruleVariables ?? [];
    ruleVariables = ruleVariables.filter(variable => variable.name !== action.name);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      ruleVariables
    });
  })
];
