/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { on } from '@ngrx/store';
import { cloneDeep } from 'lodash';

import { asArray } from '@oksygen-common-libraries/common';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { Scenario, VirtualLocationVehicle } from '@oksygen-sim-train-libraries/components-services/scenarios';
import {
  CarClassOrientationLocation,
  Consist,
  ConsistVehicleOrientation,
  ScenarioTrain,
  ScenarioTrainDriver
} from '@oksygen-sim-train-libraries/components-services/trains';

import { scenarioEditorActions } from '../scenario-editor.actions';
import { scenarioEditorDataAdapter, ScenarioEditorState, ScenarioTrainStartPos } from '../scenario-editor.state';

export const TRAIN_REDUCER_TYPES = [
  on(
    scenarioEditorActions.newScenarioTrainFromConsist,
    (state: ScenarioEditorState, action: { id: string; consist: Consist; name: string; pos?: ScenarioTrainStartPos }) => {
      const value = cloneDeep(state.entities[action.id]);

      const consist = action.consist;

      const scenarioTrains = { scenarioTrain: [...value.editorItem.scenarioTrains.scenarioTrain] };
      const virtualLocations = { virtualLocation: [...value.editorItem.virtualLocations.virtualLocation] };

      const updatedScenario: Scenario = {
        ...value.editorItem,
        scenarioTrains,
        virtualLocations
      };

      // New ID is previous biggest plus one.
      const id = scenarioTrains.scenarioTrain.reduce((max, st) => (st.id > max ? st.id : max), 0) + 1;

      const newTrain: ScenarioTrain = {
        id,
        name: action.name,
        driverType: null,
        startSegmentName: action.pos?.startSegmentName,
        startOffset: action.pos?.startOffset,
        isHeadingAlpha: action.pos?.fromAlpha ? 1 : 0,
        tripNumber: null, // TODO
        trainDescription: consist.name,
        trainType: consist.trainType.name
      };

      scenarioTrains.scenarioTrain.push(newTrain);

      consist.vehicles.forEach((v, i) => {
        // eslint-disable-next-line no-underscore-dangle
        const cco = v.orientation === ConsistVehicleOrientation._1_2 ? v.carClass.carOrientation12 : v.carClass.carOrientation21;

        if (cco?.carLocations.size > 0) {
          const vlvArray = new Array<VirtualLocationVehicle>();
          cco.carLocations.forEach(l => vlvArray.push(toVirtualLocationVehicle(newTrain, i, l)));
          virtualLocations.virtualLocation.push(...vlvArray);
        }
      });

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.setDriverForScenarioTrain,
    (
      state: ScenarioEditorState,
      action: { id: string; scenarioTrainId: number; driverType: DriverType; driverName: string; driverId: string; driverVersion: string }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const original = value.editorItem.scenarioTrains.scenarioTrain.find(st => st.id === action.scenarioTrainId);

      if (!original) {
        return state;
      }

      // Build up the scenario train array
      const scenarioTrain: ScenarioTrain[] = asArray(
        value.editorItem.scenarioTrains.scenarioTrain.map(st => {
          // Skip other trains
          if (st.id !== action.scenarioTrainId) {
            return st;
          }

          // Apply edits
          return {
            ...st,
            driverType: action.driverType
          };
        })
      );

      let drivers = asArray(value.editorItem.scenarioTrainDrivers.scenarioTrainDriver);
      if (action.driverName === null || action.scenarioTrainId === null) {
        drivers = drivers.filter(d => d.initialTrainAssociation !== action.scenarioTrainId);
      } else {
        const maxId = drivers.map(d => d.id).reduce((prev, curr) => (!prev || curr > prev ? curr : prev), 0);
        const driverTemplateReference = {
          id: action.driverId,
          version: action.driverVersion
        };
        const newDriver: ScenarioTrainDriver = {
          id: maxId + 1,
          initialTrainAssociation: action.scenarioTrainId,
          type: action.driverName,
          driverTemplateReference
        };
        drivers.push(newDriver);
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
        ...value.editorItem,
        scenarioTrains: {
          scenarioTrain
        },
        scenarioTrainDrivers: {
          scenarioTrainDriver: drivers
        }
      });
    }
  ),
  on(scenarioEditorActions.updateScenarioTrainName, (state: ScenarioEditorState, action: { id: string; scenarioTrainId: number; name: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.scenarioTrains.scenarioTrain.find(st => st.id === action.scenarioTrainId);

    if (!original) {
      return state;
    }

    // Rebuild the scenario train array
    const scenarioTrain: ScenarioTrain[] = asArray(
      value.editorItem.scenarioTrains.scenarioTrain.map(st => {
        // Skip other trains
        if (st.id !== action.scenarioTrainId) {
          return st;
        }

        // Apply edits
        return {
          ...st,
          name: action.name
        };
      })
    );

    // Find and update the associated virtual locations if there was a name change
    const originalName = original.name;
    const newName = action.name;
    const nameChange = originalName !== newName;
    const virtualLocations = { virtualLocation: [...value.editorItem.virtualLocations.virtualLocation] };

    if (nameChange) {
      virtualLocations.virtualLocation = virtualLocations.virtualLocation.map(vl => {
        if (vl.scenarioTrainName !== originalName) {
          return vl;
        }

        return {
          ...vl,
          scenarioTrainName: newName
        };
      });
    }

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      scenarioTrains: {
        scenarioTrain
      },
      virtualLocations
    });
  }),
  on(
    scenarioEditorActions.updateScenarioTrainPosition,
    (state: ScenarioEditorState, action: { id: string; scenarioTrainId: number; segment: string; offset: number; orientation: Orientation }) => {
      const value = cloneDeep(state.entities[action.id]);

      const original = value.editorItem.scenarioTrains.scenarioTrain.find(st => st.id === action.scenarioTrainId);

      if (!original) {
        return state;
      }

      // Rebuild the scenario train array
      const scenarioTrain: ScenarioTrain[] = asArray(
        value.editorItem.scenarioTrains.scenarioTrain.map(st => {
          // Skip other trains
          if (st.id !== action.scenarioTrainId) {
            return st;
          }

          // Apply edits
          return {
            ...st,
            startSegmentName: action.segment,
            startOffset: action.offset,
            isHeadingAlpha: action.orientation === Orientation.ALPHA_TO_BETA ? 1 : 0
          };
        })
      );

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
        ...value.editorItem,
        scenarioTrains: {
          scenarioTrain
        }
      });
    }
  ),
  on(scenarioEditorActions.clearScenarioTrainPosition, (state: ScenarioEditorState, action: { id: string; scenarioTrainId: number }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.scenarioTrains.scenarioTrain.find(st => st.id === action.scenarioTrainId);

    if (!original) {
      return state;
    }

    // Rebuild the scenario train array
    const scenarioTrain: ScenarioTrain[] = asArray(
      value.editorItem.scenarioTrains.scenarioTrain.map(st => {
        // Skip other trains
        if (st.id !== action.scenarioTrainId) {
          return st;
        }

        // Apply edits
        // using "object destructuring" to remove unwanted fields.
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { isHeadingAlpha, startOffset, startSegmentName, ...newScenarioTrain } = st;
        return newScenarioTrain;
        // const newSt: ScenarioTrain = { ...st };
        // delete newSt.isHeadingAlpha;
        // delete newSt.startOffset;
        // delete newSt.startSegmentName;
        // return newSt;
        // return {
        //   ...st,
        //   startSegmentName: action.segment,
        //   startOffset: action.offset,
        //   isHeadingAlpha: action.orientation === Orientation.ALPHA_TO_BETA ? 1 : 0
        // };
      })
    );

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      scenarioTrains: {
        scenarioTrain
      }
    });
  }),
  on(scenarioEditorActions.deleteScenarioTrain, (state: ScenarioEditorState, action: { id: string; scenarioTrainId: number }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.scenarioTrains.scenarioTrain.find(st => st.id === action.scenarioTrainId);

    if (!original) {
      return state;
    }

    // Rebuild the scenario train array
    const scenarioTrain: ScenarioTrain[] = value.editorItem.scenarioTrains.scenarioTrain.reduce((p, st) => {
      // Exclude the deleted train
      if (st.id !== action.scenarioTrainId) {
        p.push(st);
      }

      return p;
    }, []);

    // Find and remove the associated virtual locations
    const originalName = original.name;
    const virtualLocations = { virtualLocation: [...value.editorItem.virtualLocations.virtualLocation] };

    virtualLocations.virtualLocation = virtualLocations.virtualLocation.reduce((p, vl) => {
      if (vl.scenarioTrainName !== originalName) {
        p.push(vl);
      }

      return p;
    }, []);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      scenarioTrains: {
        scenarioTrain
      },
      virtualLocations
    });
  })
];

function toVirtualLocationVehicle(scenarioTrain: ScenarioTrain, index: number, loc: CarClassOrientationLocation): VirtualLocationVehicle {
  return {
    scenarioTrainName: scenarioTrain.name,
    vehicleIndex: index,
    locationType: 'Vehicle',
    locationName: loc.name,
    description: loc.name,
    hubMode: loc.hubMode,
    xOffset: loc.x,
    yOffset: loc.y,
    zOffset: loc.z,
    headingOffset: loc.h,
    pitchOffset: loc.p,
    rollOffset: loc.r
  };
}
