/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { on } from '@ngrx/store';
import { cloneDeep, isNil } from 'lodash';

import { ReportItem, ReportingEventItem } from '@oksygen-sim-train-libraries/components-services/assessment-criteria';
import { ScenarioReportData } from '@oksygen-sim-train-libraries/components-services/assessment-criteria/scenario';
import { ParameterDefinitionValueType } from '@oksygen-sim-train-libraries/components-services/common';
import { updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { scenarioEditorActions } from '../scenario-editor.actions';
import { scenarioEditorDataAdapter, ScenarioEditorState } from '../scenario-editor.state';

export const ASSESSMENT_REDUCER_TYPES = [
  on(
    scenarioEditorActions.addScenarioAssessment,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        displayName: string;
        assessmentCriteria: ReportItem;
        events: Array<ReportingEventItem>;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem
      };

      const maxIdAssessment = updatedScenario.reportData.reduce((prev, curr) => (prev?.id < curr?.id ? curr : prev), { id: 0 });

      const assessment: ScenarioReportData = {
        id: maxIdAssessment.id + 1,
        displayName: action.displayName,
        description: action.assessmentCriteria.displayDescription,
        assessed: true,
        reportItemReference: {
          name: action.assessmentCriteria.name,
          version: action.assessmentCriteria.version,
          assessmentParameters: action.assessmentCriteria.assessmentParameters.map(param => ({
            name: param.name,
            value: param.default
          })),
          parameters: action.assessmentCriteria.parameters.map(param => ({
            name: param.name,
            value: param.default
          })),
          events: action.assessmentCriteria.events.map(criteriaEvent => {
            const assessmentEvent = action.events.find(e => e.name === criteriaEvent.name && e.version === criteriaEvent.version);

            return {
              name: criteriaEvent.name,
              parameters: assessmentEvent.parameters.map(param => ({
                name: param.name,
                value: param.default
              }))
            };
          })
        }
      };

      updatedScenario.reportData.push(assessment);

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.deleteScenarioAssessment,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        assessmentCriteriaId: number;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem
      };

      updatedScenario.reportData = updatedScenario.reportData.filter(ac => ac.id !== action.assessmentCriteriaId);

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.updateScenarioAssessmentName,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        assessmentCriteriaId: number;
        displayName: string;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem
      };

      const assessment = updatedScenario.reportData.find(ac => ac.id === action.assessmentCriteriaId);

      if (!isNil(assessment)) {
        assessment.displayName = action.displayName;
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.updateScenarioAssessmentDescription,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        assessmentCriteriaId: number;
        description: string;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem
      };

      const assessment = updatedScenario.reportData.find(ac => ac.id === action.assessmentCriteriaId);

      if (!isNil(assessment)) {
        assessment.description = action.description;
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.updateScenarioAssessmentAssessed,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        assessmentCriteriaId: number;
        assessed: boolean;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem
      };

      const assessment = updatedScenario.reportData.find(ac => ac.id === action.assessmentCriteriaId);

      if (!isNil(assessment)) {
        assessment.assessed = action.assessed;
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.updateScenarioAssessmentAssessmentParameter,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        assessmentCriteriaId: number;
        assessmentParameterName: string;
        value: ParameterDefinitionValueType;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem
      };

      const assessment = updatedScenario.reportData.find(ac => ac.id === action.assessmentCriteriaId);

      if (!isNil(assessment)) {
        const parameter = assessment.reportItemReference.assessmentParameters.find(p => p.name === action.assessmentParameterName);

        if (!isNil(parameter)) {
          parameter.value = action.value;
        }
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.updateScenarioAssessmentParameter,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        assessmentCriteriaId: number;
        parameterName: string;
        value: ParameterDefinitionValueType;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem
      };

      const assessment = updatedScenario.reportData.find(ac => ac.id === action.assessmentCriteriaId);

      if (!isNil(assessment)) {
        const parameter = assessment.reportItemReference.parameters.find(p => p.name === action.parameterName);

        if (!isNil(parameter)) {
          parameter.value = action.value;
        }
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.updateScenarioAssessmentEventParameter,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        assessmentCriteriaId: number;
        eventName: string;
        parameterName: string;
        value: ParameterDefinitionValueType;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem
      };

      const assessment = updatedScenario.reportData.find(ac => ac.id === action.assessmentCriteriaId);

      if (!isNil(assessment)) {
        const event = assessment.reportItemReference.events.find(e => e.name === action.eventName);

        if (!isNil(event)) {
          const parameter = event.parameters.find(p => p.name === action.parameterName);

          if (!isNil(parameter)) {
            parameter.value = action.value;
          }
        }
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  )
];
