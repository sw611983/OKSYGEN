/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { on } from '@ngrx/store';
import { cloneDeep, isEqual } from 'lodash';

import { updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { TrainTypeEquipment } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { scenarioEditorActions } from '../scenario-editor.actions';
import { scenarioEditorDataAdapter, ScenarioEditorState } from '../scenario-editor.state';

export const HARDWARE_REDUCER_TYPES = [
  on(scenarioEditorActions.updateHardwareStatesConfig,
    (state: ScenarioEditorState, action: {id: string; config: TrainTypeEquipment}) => {
      const value = cloneDeep(state.entities[action.id]);

      if (isEqual(value.editorItem.trainTypeEquipment, action.config)) {
        return state;
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
          ...value.editorItem,
          trainTypeEquipment: action.config
        }
      );
  })
];
