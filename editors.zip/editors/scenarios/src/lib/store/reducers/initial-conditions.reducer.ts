/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { on } from '@ngrx/store';
import { cloneDeep, isEqual } from 'lodash';

import { updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { InitialConditionsTrains } from '@oksygen-sim-train-libraries/components-services/common';

import { scenarioEditorActions } from '../scenario-editor.actions';
import { scenarioEditorDataAdapter, ScenarioEditorState } from '../scenario-editor.state';

export const INTIAL_CONDITIONS_REDUCER_TYPES = [
  on(scenarioEditorActions.updateInitialConditionsConfig,
    (state: ScenarioEditorState, action: {id: string; trainSimPropertiesAll: InitialConditionsTrains}) => {
      const value = cloneDeep(state.entities[action.id]);

      if (isEqual(value.editorItem.initialConditionsTrains, action.trainSimPropertiesAll)) {
        return state;
      }

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
          ...value.editorItem,
          initialConditionsTrains: action.trainSimPropertiesAll
        }
      );
  })
];
