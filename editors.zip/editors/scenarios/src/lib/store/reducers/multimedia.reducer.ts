/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { on } from '@ngrx/store';
import { cloneDeep } from 'lodash';

import { asArray } from '@oksygen-common-libraries/common';
import { updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { RuleBlockPropertyNameEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario, ScenarioMultimedia, ScenarioRule } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { scenarioEditorActions } from '../scenario-editor.actions';
import { scenarioEditorDataAdapter, ScenarioEditorState } from '../scenario-editor.state';

export const MULTIMEDIA_REDUCER_TYPES = [
  on(scenarioEditorActions.addMultimedia, (state: ScenarioEditorState, action: { id: string; displayName: string; multimediaId: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    const updatedScenario: Scenario = {
      ...value.editorItem,
      multimedia: [...asArray(value.editorItem.multimedia)],
      rule: [...asArray(value.editorItem.rule)]
    };

    let ruleId = 1;

    if (updatedScenario.rule?.length > 1) {
      const maxIdRule = updatedScenario.rule.reduce((prev, curr) => (prev?.id < curr?.id ? curr : prev));

      ruleId = maxIdRule.id + 1;
    } else if (updatedScenario.rule?.length === 1) {
      ruleId = updatedScenario.rule[0].id + 1;
    }

    // FIXME: hard coding some values for now, until we know how to look this up
    // As a note, the id (GUID) of the rule will always be the same, the version may change

    const newRule: ScenarioRule = {
      id: ruleId,
      ruleType: 'Multimedia',
      displayName: action.displayName,
      ruleTemplateReference: {
        id: '4b67fe63-28ce-4d02-9d84-afaccee01528',
        version: '1.0.0',
        ruleBlocks: {
          ruleBlock: [
            {
              blockId: 1,
              properties: {
                property: [
                  {
                    name: RuleBlockPropertyNameEnum.MULTIMEDIA_NAME,
                    value: action.multimediaId
                  }
                ]
              }
            }
          ]
        }
      }
    };

    if (!updatedScenario.rule) {
      updatedScenario.rule = [];
    }

    updatedScenario.rule.push(newRule);

    const newMultimedia: ScenarioMultimedia = {
      moodleScormActivity: {
        name: action.displayName,
        multimediaId: action.multimediaId,
        ruleId
      }
    };

    if (!updatedScenario.multimedia) {
      updatedScenario.multimedia = [];
    }

    updatedScenario.multimedia.push(newMultimedia);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
  }),
  on(scenarioEditorActions.deleteMultimedia, (state: ScenarioEditorState, action: { id: string; ruleId: number }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.multimedia.find(m => m?.moodleScormActivity?.ruleId === action.ruleId);

    if (!original) {
      return state;
    }

    const multimedia = value.editorItem.multimedia.filter(m => m.moodleScormActivity?.ruleId !== action.ruleId);
    const rule = value.editorItem.rule.filter(r => r.id !== action.ruleId);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      multimedia,
      rule
    });
  }),
  on(
    scenarioEditorActions.updateScenarioMultimediaName,
    (state: ScenarioEditorState, action: { id: string; ruleId: number; name: string; phantom?: boolean }) => {
      const value = cloneDeep(state.entities[action.id]);

      const original = value.editorItem.multimedia.find(m => m?.moodleScormActivity?.ruleId === action.ruleId);

      if (!original) {
        return state;
      }

      const multimedia = asArray(
        value.editorItem.multimedia.map(m => {
          // Skip other trains
          if (m?.moodleScormActivity?.ruleId !== action.ruleId) {
            return m;
          }

          // Apply edits
          return {
            moodleScormActivity: {
              name: action.name,
              multimediaId: m.moodleScormActivity.multimediaId,
              ruleId: m.moodleScormActivity.ruleId
            },
            isFavourite: m.isFavourite
          };
        })
      );

      // we need to also rename phantom rules, as in this case the multimedia is the master
      const rule = asArray(
        value.editorItem.rule.map(r => {
          // only rename phantoms
          if (r?.id !== action.ruleId || !action.phantom) {
            return r;
          }
          // Apply edits
          return {
            id: r.id,
            ruleType: r.ruleType,
            displayName: action.name,
            description: r.description,
            ruleTemplateReference: r.ruleTemplateReference
          };
        })
      );

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
        ...value.editorItem,
        multimedia,
        rule
      });
    }
  )
];
