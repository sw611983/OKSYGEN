/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { on } from '@ngrx/store';
import { cloneDeep, isNil } from 'lodash';

import { asArray } from '@oksygen-common-libraries/common';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectGeometry, ObjectProperties, TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import { BaseEditorState, StoreObjectModification, updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import {
  asFreezableObjectType,
  cloneObjectState,
  createChildObjectFromType,
  DISPLAY_STATE,
  DISPLAY_STATE_OVERRIDE,
  INITIAL_STATE,
  maxObjectId,
  ObjectContainer,
  ObjectSource,
  ObjectTypeContainer,
  ObjectTypeState,
  ObjectWorldLocation,
  SimObject,
  USER_STATE
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { scenarioEditorActions } from '../scenario-editor.actions';
import { scenarioEditorDataAdapter, ScenarioEditorState } from '../scenario-editor.state';
import { PropertyUpdated } from '@oksygen-sim-train-libraries/components-services/common';

export const OBJECT_REDUCER_TYPES = [
  on(
    scenarioEditorActions.newObjectFromType,
    (
      state: ScenarioEditorState,
      action: { id: string; objectType: ObjectTypeContainer; name: string; lngLat: LngLatCoord; pos: ObjectGeometry; assocs?: TrackSegmentAssociation[] }
    ) =>
      // Note that we're putting things in the store here, which means they will get frozen.
      // We do not want to freeze ObjectTypes as they contain icons which have caches that must remain writable,
      // so we clone them here first.
      // FIXME A safer solution to this is to avoid having mutable objects in the scenario.
      // This means having some way of storing object icons separate from the types. See INTOSC-8421
      newObjectFromTypeUnsafe(state, { ...action, objectType: asFreezableObjectType(action.objectType) })
  ),
  on(
    scenarioEditorActions.newObjectFromTypeUnsafe,
    (
      state: ScenarioEditorState,
      action: { id: string; objectType: ObjectTypeContainer; name: string; lngLat: LngLatCoord; pos: ObjectGeometry; assocs?: TrackSegmentAssociation[] }
    ) => newObjectFromTypeUnsafe(state, action)
  ),
  on(scenarioEditorActions.updateObjectName, (state: ScenarioEditorState, action: { id: string; objectId: number; name: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.world.object.find(o => o.id === action.objectId);

    if (!original || original.source.id !== ObjectSource.SCENARIO.id) {
      return state;
    }

    // Rebuild the object array, updating the modified object as we go.
    const object: ObjectContainer[] = value.editorItem.world.object.map(o => (o.id === original.id ? { ...o, name: action.name } : o));
    // rename all rule references to the old object
    value.editorItem.rule.forEach(rule => {
      rule.ruleTemplateReference.ruleBlocks.ruleBlock.forEach(rb => {
        rb.properties.property.forEach(prop => {
          if (prop.value === original.name) {
            prop.value = action.name;
          }
        });
      });
    });

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      world: {
        ...value.editorItem.world,
        object
      }
    });
  }),
  on(
    scenarioEditorActions.updateObjectPosition,
    (state: ScenarioEditorState, action: { id: string; objectId: number; lngLat: LngLatCoord; pos: ObjectGeometry; assocs?: TrackSegmentAssociation[] }) => {
      const value = cloneDeep(state.entities[action.id]);

      const original = value.editorItem.world.object.find(o => o.id === action.objectId);

      if (!original || original.source.id !== ObjectSource.SCENARIO.id) {
        return state;
      }

      const location: ObjectWorldLocation = {
        lnglat: action.lngLat,
        geometry: action.pos
      };
      const trackAssociations = action.assocs;

      // Rebuild the object array, updating the modified object as we go.
      // note we also update the children's positions.
      const object: ObjectContainer[] = value.editorItem.world.object.map(o =>
        o.id === original.id || original?.children.find(c => c.id === o.id)
          ? { ...o, location, trackAssociations, children: o.children?.map(c => ({ ...c, location, trackAssociations })) }
          : o
      );

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
        ...value.editorItem,
        world: {
          ...value.editorItem.world,
          object
        }
      });
    }
  ),
  on(scenarioEditorActions.updateObjectInitialState, (state: ScenarioEditorState, action: { id: string; objectId: number; state: ObjectTypeState }) =>
    // Note that we're putting things in the store here, which means they will get frozen.
    // We do not want to freeze ObjectTypes as they contain icons which have caches that must remain writable,
    // so we clone them here first.
    // FIXME A safer solution to this is to avoid having mutable objects in the scenario.
    // This means having some way of storing object icons separate from the types. See INTOSC-8421
    updateObjectInitialStateUnsafe(state, { ...action, state: cloneObjectState(action.state) })
  ),
  on(scenarioEditorActions.updateObjectInitialStateUnsafe, (state: ScenarioEditorState, action: { id: string; objectId: number; state: ObjectTypeState }) =>
    updateObjectInitialStateUnsafe(state, action)
  ),
  on(
    scenarioEditorActions.updateObjectDisplayState,
    (state: ScenarioEditorState, action: { id: string; objectId: number; state: ObjectTypeState; propertyUpdated: PropertyUpdated }) =>
      // Note that we're putting things in the store here, which means they will get frozen.
      // We do not want to freeze ObjectTypes as they contain icons which have caches that must remain writable,
      // so we clone them here first.
      // FIXME A safer solution to this is to avoid having mutable objects in the scenario.
      // This means having some way of storing object icons separate from the types. See INTOSC-8421
      updateObjectDisplayStateUnsafe(state, { ...action, state: cloneObjectState(action.state)})
  ),
  on(
    scenarioEditorActions.updateObjectDisplayStateUnsafe,
    (state: ScenarioEditorState, action: { id: string; objectId: number; state: ObjectTypeState; propertyUpdated: PropertyUpdated }) =>
      updateObjectDisplayStateUnsafe(state, action)
  ),
  on(
    scenarioEditorActions.setScenarioObjectProperties,
    (state: ScenarioEditorState, action: { id: string; objectId: number; properties: ObjectProperties }) => {
      const value = cloneDeep(state.entities[action.id]);

      const original = value.editorItem.world.object.find(o => o.id === action.objectId);

      if (!original || original.source.id !== ObjectSource.SCENARIO.id) {
        return state;
      }

      // Rebuild the object array, updating the modified object as we go.
      const object: ObjectContainer[] = value.editorItem.world.object.map(o => {
        if (o.id === original.id) {
          return { ...o, properties: action.properties };
        }
        // if this is a child ref, the parent's ref to it is a different object so have to update that as well
        if (original.parentId === o.id) {
          const childRef = o.children?.find(c => c.id === original.id);
          childRef.properties = action.properties;
        }
        return o;
      });

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
        ...value.editorItem,
        world: {
          ...value.editorItem.world,
          object
        }
      });
    }
  ),
  on(scenarioEditorActions.deleteObject, (state: ScenarioEditorState, action: { id: string; objectId: number }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.world.object.find(o => o.id === action.objectId);

    if (!original || original.source.id !== ObjectSource.SCENARIO.id) {
      return state;
    }

    // Rebuild the object array...
    const object: ObjectContainer[] = value.editorItem.world.object.reduce((p, o) => {
      // ...excluding the deleted object and it's children
      if (o.id !== original.id && !original.children?.find(c => c.id === o.id)) {
        p.push(o);
      }

      return p;
    }, []);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      world: {
        ...value.editorItem.world,
        object
      }
    });
  }),
  on(
    scenarioEditorActions.setObjectModification,
    (state: ScenarioEditorState, action: { id: string; objectName: string; propertyName: string; propertyValue: number | string | boolean }) => {
      const value = cloneDeep(state.entities[action.id]);
      const objectMods = value?.editorItem?.world.objectModification || [];
      const originalObjectMod = objectMods.find(o => o.name === action.objectName);
      // already cloned so can just modify to simplify
      if (originalObjectMod) {
        originalObjectMod.properties[action.propertyName] = action.propertyValue;
      } else {
        const properties: ObjectProperties = {};
        properties[action.propertyName] = action.propertyValue;
        objectMods.push({ name: action.objectName, properties });
      }
      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
        ...value.editorItem,
        world: {
          ...value.editorItem.world,
          objectModification: objectMods
        }
      });
    }
  ),
  on(scenarioEditorActions.setMultipleObjectModifications, (state: ScenarioEditorState, action: { id: string; modifications: StoreObjectModification[] }) => {
    const value = cloneDeep(state.entities[action.id]);
    const objectMods = value?.editorItem?.world.objectModification || [];

    action.modifications.forEach(m => {
      const originalObjectMod = objectMods.find(o => o.name === m.objectName);
      // already cloned so can just modify to simplify
      if (originalObjectMod) {
        originalObjectMod.properties[m.propertyName] = m.propertyValue;
      } else {
        const properties: ObjectProperties = {};
        properties[m.propertyName] = m.propertyValue;
        objectMods.push({ name: m.objectName, properties });
      }
    });

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      world: {
        ...value.editorItem.world,
        objectModification: objectMods
      }
    });
  }),
  on(scenarioEditorActions.removeObjectModification, (state: ScenarioEditorState, action: { id: string; objectName: string; propertyName: string }) => {
    const value = cloneDeep(state.entities[action.id]);
    const originalObjectMods = value.editorItem?.world.objectModification;
    if (!originalObjectMods) {
      return state;
    }
    const objectMods = originalObjectMods
      .map(om => {
        if (om.name === action.objectName) {
          delete om.properties[action.propertyName];
        }

        return om;
      })
      .filter(om => Object.keys(om.properties).length > 0);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      world: {
        ...value.editorItem.world,
        objectModification: objectMods
      }
    });
  })
];

function newObjectFromTypeUnsafe(
  state: ScenarioEditorState,
  action: { id: string; objectType: ObjectTypeContainer; name: string; lngLat: LngLatCoord; pos: ObjectGeometry; assocs?: TrackSegmentAssociation[] }
): BaseEditorState<Scenario> {
  const value = cloneDeep(state.entities[action.id]);
  const objectType = action.objectType;
  const object = [...asArray(value.editorItem.world.object)];

  const updatedScenario: Scenario = {
    ...value.editorItem,
    world: {
      ...value.editorItem.world,
      object
    }
  };

  // New ID is previous biggest plus one, starting from a large number to avoid collision with track features.
  const id = maxObjectId(object, 100000) + 1;

  const initialState = objectType.defaultState ?? objectType.states?.values().next(undefined)?.value;
  const userState = objectType.automatedState;

  const properties: ObjectProperties = {};

  objectType.textProperties.forEach(p => (properties[p.name] = p.defaultValue));
  objectType.numericProperties.forEach(p => (properties[p.name] = Number(p.defaultValue)));
  objectType.booleanProperties.forEach(p => (properties[p.name] = !!Number(p.defaultValue)));
  objectType.enumProperties.forEach(p => {
    const defaultValue = p.defaultValue?.value ?? p.values[0]?.value;
    properties[p.name] = defaultValue;
  });

  let displayState: ObjectTypeState;
  // first check for defaults
  if (objectType.displayState) {
    displayState = objectType.states.get(objectType.displayState.id);
  }

  // then check for display state via it's properties
  const defaultDisplayState = properties ? (properties as any)[DISPLAY_STATE] : null;

  if (defaultDisplayState) {
    for (const s of objectType.states.values()) {
      if (s.name === defaultDisplayState) {
        displayState = s;
        break;
      }
    }
  }

  if (initialState) {
    properties[INITIAL_STATE] = initialState.name;
  }
  if (userState) {
    properties[USER_STATE] = userState.name;
  }

  const children: SimObject[] = [];
  objectType.children?.forEach((child, i) => {
    const location = {
      lnglat: action.lngLat,
      geometry: action.pos
    };
    const childId = id + i + 1;
    const childName = `${action.name}_${child.name}`;
    const childObj = createChildObjectFromType(child, childId, childName, id, location, action.assocs, ObjectSource.SCENARIO);
    // scenario objects is flat - so we must add the object BOTH to the parent AND to the added objects array
    object.push({ ...childObj, children: [] });
    children.push(childObj);
  });

  const stateAutomated = isNil(objectType?.automatedState) ? null :
    Object.prototype.hasOwnProperty.call(properties, USER_STATE) &&
    !isNil(objectType.automatedState) &&
    (properties as any)[USER_STATE] === objectType.automatedState.name;

  const newObject: ObjectContainer = {
    id,
    name: action.name,
    objectType,
    source: ObjectSource.SCENARIO,
    states: objectType.states,
    properties,
    selectedState: initialState,
    selectedIcon: initialState?.icons,
    stateAutomated,
    stateVirtual: undefined,
    location: {
      lnglat: action.lngLat,
      geometry: action.pos
    },
    trackAssociations: action.assocs,
    children,
    displayState
  };

  // make sure the parent's feature properties point to the newly generated child objects
  children.forEach(child => {
    const objectTypeChild = newObject.objectType.children.find(otc => otc.child.name === child.objectType.name);
    newObject.properties[objectTypeChild.name] = child.id;
  });

  object.push(newObject);

  return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
}

function updateObjectInitialStateUnsafe(
  state: ScenarioEditorState,
  action: { id: string; objectId: number; state: ObjectTypeState }
): BaseEditorState<Scenario> {
  const value = cloneDeep(state.entities[action.id]);

  const original = value.editorItem.world.object.find(o => o.id === action.objectId);

  if (!original || original.source.id !== ObjectSource.SCENARIO.id) {
    return state;
  }

  // Rebuild the object array, updating the modified object as we go.
  const object: ObjectContainer[] = value.editorItem.world.object.map(o => {
    if (o.id === original.id) {
      const properties = cloneDeep(o.properties) ?? {};

      properties[INITIAL_STATE] = action.state.name;
      return { ...o, selectedState: action.state, properties };
    }
    // if this is a child ref, the parent's ref to it is a different object so have to update that as well
    if (original.parentId === o.id) {
      const childRef = o.children?.find(c => c.id === original.id);
      childRef.selectedState = action.state;
      childRef.properties[INITIAL_STATE] = action.state.name;
    }

    return o;
  });

  return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
    ...value.editorItem,
    world: {
      ...value.editorItem.world,
      object
    }
  });
}

function updateObjectDisplayStateUnsafe(
  state: ScenarioEditorState,
  action: { id: string; objectId: number; state: ObjectTypeState; propertyUpdated: PropertyUpdated }
): BaseEditorState<Scenario> {
  const value = cloneDeep(state.entities[action.id]);

  const original = value.editorItem.world.object.find(o => o.id === action.objectId);

  if (!original || original.source.id !== ObjectSource.SCENARIO.id) {
    return state;
  }

  // Rebuild the object array, updating the modified object as we go.
  const object: ObjectContainer[] = value.editorItem.world.object.map(o => {
    if (o.id === original.id) {
      const properties = cloneDeep(o.properties) ?? {};
      if (action.propertyUpdated.propertyName === DISPLAY_STATE) {
        properties[DISPLAY_STATE] = action.state.name;
        return { ...o, displayState: action.state, properties };
      } else {
        properties[DISPLAY_STATE_OVERRIDE] = action.propertyUpdated.newValue;
        return { ...o, properties };
      }
    }
    // if this is a child ref, the parent's ref to it is a different object so have to update that as well
    if (original.parentId === o.id) {
      const childRef = o.children?.find(c => c.id === original.id);
      if (action.propertyUpdated.propertyName === DISPLAY_STATE) {
        childRef.displayState = action.state;
        childRef.properties[DISPLAY_STATE] = action.state.name;
      } else {
        childRef.properties[DISPLAY_STATE_OVERRIDE] = action.propertyUpdated.newValue;
      }
    }

    return o;
  });

  return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
    ...value.editorItem,
    world: {
      ...value.editorItem.world,
      object
    }
  });
}
