/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { on } from '@ngrx/store';
import { cloneDeep } from 'lodash';

import { asArray } from '@oksygen-common-libraries/common';
import { updateForUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';
import { MultimediaReference } from '@oksygen-sim-train-libraries/components-services/multimedia';
import { RuleBlockPropertyNameEnum, RuleBlockReference } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario, ScenarioMultimedia, ScenarioRule } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { scenarioEditorActions } from '../scenario-editor.actions';
import { scenarioEditorDataAdapter, ScenarioEditorState } from '../scenario-editor.state';

export const RULE_REDUCER_TYPES = [
  on(
    scenarioEditorActions.addScenarioRule,
    (
      state: ScenarioEditorState,
      action: {
        id: string;
        name: string;
        description: string;
        ruleTemplateId: string;
        version: string;
        multimedia: MultimediaReference[];
        multimediaId?: string;
      }
    ) => {
      const value = cloneDeep(state.entities[action.id]);

      const updatedScenario: Scenario = {
        ...value.editorItem,
        multimedia: [...value.editorItem.multimedia],
        rule: [...value.editorItem.rule]
      };

      const maxIdRule = updatedScenario.rule.reduce((prev, curr) => (prev?.id < curr?.id ? curr : prev), { id: 0 });

      const newRule: ScenarioRule = {
        id: maxIdRule.id + 1,
        ruleType: '',
        displayName: action.name,
        description: action.description,
        active: true,
        ruleTemplateReference: {
          id: action.ruleTemplateId,
          version: action.version,
          ruleBlocks: {
            ruleBlock: []
          }
        }
      };

      updatedScenario.rule.push(newRule);
      // make sure to duplicate any multimedia for this duplicated rule.
      const multimedia = [...asArray(value.editorItem.multimedia)];
      if (action.multimediaId) {
        const displayName = action.multimedia.find(m => m.id === action.multimediaId)?.name;
        const newMulti: ScenarioMultimedia = {
          isFavourite: false,
          moodleScormActivity: {
            ruleId: newRule.id,
            name: displayName,
            multimediaId: action.multimediaId
          }
        };
        multimedia.push(newMulti);
      }
      updatedScenario.multimedia = multimedia;

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(
    scenarioEditorActions.duplicateScenarioRule,
    (state: ScenarioEditorState, action: { id: string; name: string; description: string; ruleId: number; multimedia: MultimediaReference[] }) => {
      const value = cloneDeep(state.entities[action.id]);

      const duplicatedRule = value.editorItem?.rule?.find(r => r.id === action.ruleId);
      if (!duplicatedRule) {
        return state;
      }
      const updatedScenario: Scenario = {
        ...value.editorItem,
        multimedia: [...value.editorItem.multimedia],
        rule: [...value.editorItem.rule]
      };

      const maxIdRule = updatedScenario.rule.reduce((prev, curr) => (prev?.id < curr?.id ? curr : prev), { id: 0 });
      const newRule: ScenarioRule = {
        id: maxIdRule.id + 1,
        ruleType: duplicatedRule.ruleType,
        displayName: action.name,
        description: action.description,
        ruleTemplateReference: cloneDeep(duplicatedRule.ruleTemplateReference)
      };

      updatedScenario.rule.push(newRule);

      // make sure to duplicate any multimedia for this duplicated rule.
      const multimedia = [...asArray(value.editorItem.multimedia)];
      multimedia.forEach(m => {
        if (m.moodleScormActivity?.ruleId === action.ruleId) {
          const newMulti = cloneDeep(m);
          newMulti.moodleScormActivity.ruleId = newRule.id;
          newMulti.isFavourite = false;
        }
      });
      updatedScenario.multimedia = multimedia;

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, updatedScenario);
    }
  ),
  on(scenarioEditorActions.deleteScenarioRule, (state: ScenarioEditorState, action: { id: string; ruleId: number; multimedia: MultimediaReference[] }) => {
    const value = cloneDeep(state.entities[action.id]);

    const rule = value.editorItem.rule.filter(r => r.id !== action.ruleId);

    // special case of update multimedia (if they exist)
    const multimedia = [...asArray(value.editorItem.multimedia)].filter(m => m.moodleScormActivity?.ruleId !== action.ruleId);

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      multimedia,
      rule
    });
  }),
  on(scenarioEditorActions.updateScenarioRuleName, (state: ScenarioEditorState, action: { id: string; ruleId: number; name: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.rule.find(r => r?.id === action.ruleId);
    if (!original) {
      // can't update a rule that doesn't exist!
      return state;
    }

    const rules = asArray(
      value.editorItem.rule.map(r => {
        if (r.id !== action.ruleId) {
          return r;
        }
        return {
          ...r,
          displayName: action.name
        };
      })
    );

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      rule: rules
    });
  }),
  on(scenarioEditorActions.updateScenarioRuleDescription, (state: ScenarioEditorState, action: { id: string; ruleId: number; description: string }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.rule.find(r => r?.id === action.ruleId);
    if (!original) {
      // can't update a rule that doesn't exist!
      return state;
    }

    const rules = asArray(
      value.editorItem.rule.map(r => {
        if (r.id !== action.ruleId) {
          return r;
        }
        return {
          ...r,
          description: action.description
        };
      })
    );

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      rule: rules
    });
  }),
  on(
    scenarioEditorActions.updateScenarioRuleBlock,
    (state: ScenarioEditorState, action: { id: string; ruleId: number; block: RuleBlockReference; multimedia: MultimediaReference[] }) => {
      const value = cloneDeep(state.entities[action.id]);

      const original = value.editorItem.rule.find(r => r?.id === action.ruleId);
      if (!original) {
        // can't update a rule that doesn't exist!
        return state;
      }

      const rules = asArray(
        value.editorItem.rule.map(r => {
          if (r.id !== action.ruleId) {
            return r;
          }
          const blocks: RuleBlockReference[] = r.ruleTemplateReference.ruleBlocks.ruleBlock.map(b => {
            if (b.blockId === action.block.blockId) {
              return cloneDeep(action.block); // for immutability
            }
            return b;
          });
          const existinBlock = blocks.find(b => b.blockId === action.block.blockId);
          if (!existinBlock) {
            blocks.push(cloneDeep(action.block));
          }
          const newRule: ScenarioRule = {
            ...r,
            ruleTemplateReference: {
              ...r.ruleTemplateReference,
              ruleBlocks: { ruleBlock: blocks }
            }
          };
          return newRule;
        })
      );

      // special case of update multimedia (if they exist)
      const oldMultimedia = [...asArray(value.editorItem.multimedia)];
      // filter out any multimedia that reference this rule but the rule no longer references (ie, user changes multimedia in the panel)
      const changedRule = rules.find(r => r.id === action.ruleId);
      const multimedia = oldMultimedia.filter(m => isMultimediaNotOrphaned(changedRule, m));
      const newMulti = newMultimediaReferenceInRule(changedRule, action.multimedia, multimedia);
      multimedia.push(...newMulti);

      return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
        ...value.editorItem,
        multimedia,
        rule: rules
      });
    }
  ),
  on(scenarioEditorActions.updateScenarioRuleActive, (state: ScenarioEditorState, action: { id: string; ruleId: number; active: boolean }) => {
    const value = cloneDeep(state.entities[action.id]);

    const original = value.editorItem.rule.find(r => r?.id === action.ruleId);
    if (!original) {
      // can't update a rule that doesn't exist!
      return state;
    }

    const rules = asArray(
      value.editorItem.rule.map(r => {
        if (r.id !== action.ruleId) {
          return r;
        }
        return {
          ...r,
          active: action.active
        };
      })
    );

    return updateForUnsavedChanges(scenarioEditorDataAdapter, state, value, {
      ...value.editorItem,
      rule: rules
    });
  })
];
/**
 * Checks if a scenario rule no longer references an included multimedia.
 * This happens when - in scenario editor - the user selects a new multimedia in the rules panel - the old one is now orphaned
 * and should be deleted. Similar story if the clear clears their selection.
 */
function isMultimediaNotOrphaned(rule: ScenarioRule, multimedia: ScenarioMultimedia): boolean {
  if (multimedia.moodleScormActivity?.ruleId !== rule.id) { return true; }
  for (const rb of rule.ruleTemplateReference.ruleBlocks.ruleBlock) {
    for (const p of rb.properties.property) {
      if (p.name === RuleBlockPropertyNameEnum.MULTIMEDIA_NAME) {
        return p.value === multimedia.moodleScormActivity?.multimediaId;
      }
    }
  }
  return true;
}

/**
 * Finds if there are any new multimedia referenced in a rule.
 * This happens when - in scenario editor - the user selects a multimedia in the rules panel.
 */
function newMultimediaReferenceInRule(rule: ScenarioRule, multimedia: MultimediaReference[], oldMultimedia?: ScenarioMultimedia[]): ScenarioMultimedia[] {
  if (!rule) {
    return [];
  }
  const scenarioMultimedia: ScenarioMultimedia[] = [];
  if (!oldMultimedia) {
    oldMultimedia = [];
  }
  rule.ruleTemplateReference.ruleBlocks.ruleBlock.forEach(rb => {
    rb.properties.property.forEach(p => {
      if (p.name === RuleBlockPropertyNameEnum.MULTIMEDIA_NAME) {
        if (p.value) {
          // we may have cleared the selected multimedia
          // find old reference (if it exists) so we don't wipe favourites
          const oldMulti = oldMultimedia.find(mul => mul.moodleScormActivity.ruleId === rule.id && mul.moodleScormActivity.multimediaId === p.value);
          const multi = multimedia.find(m => m.id === p.value);
          if (!oldMulti) {
            const newMulti: ScenarioMultimedia = {
              isFavourite: oldMulti ? oldMulti.isFavourite : false,
              moodleScormActivity: {
                ruleId: rule.id,
                name: oldMulti ? oldMulti.moodleScormActivity.name : multi.name,
                multimediaId: oldMulti ? oldMulti.moodleScormActivity.multimediaId : multi.id
              }
            };
            scenarioMultimedia.push(newMulti);
          }
        }
      }
    });
  });
  return scenarioMultimedia;
}
