/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { createReducer } from '@ngrx/store';

import { ASSESSMENT_REDUCER_TYPES } from './reducers/assessment.reducer';
import { BASE_SCENARIO_REDUCER_TYPES } from './reducers/base-scenario.reducer';
import { HARDWARE_REDUCER_TYPES } from './reducers/hardware.reducer';
import { INTIAL_CONDITIONS_REDUCER_TYPES } from './reducers/initial-conditions.reducer';
import { MULTIMEDIA_REDUCER_TYPES } from './reducers/multimedia.reducer';
import { OBJECT_REDUCER_TYPES } from './reducers/object.reducer';
import { RULE_REDUCER_TYPES } from './reducers/rule.reducer';
import { TRAIN_REDUCER_TYPES } from './reducers/train.reducer';
import { initialScenarioEditorState } from './scenario-editor.state';

export const scenarioEditorReducer = createReducer(
  initialScenarioEditorState,
  ...BASE_SCENARIO_REDUCER_TYPES,
  ...TRAIN_REDUCER_TYPES,
  ...OBJECT_REDUCER_TYPES,
  ...MULTIMEDIA_REDUCER_TYPES,
  ...RULE_REDUCER_TYPES,
  ...HARDWARE_REDUCER_TYPES,
  ...INTIAL_CONDITIONS_REDUCER_TYPES,
  ...ASSESSMENT_REDUCER_TYPES
);
