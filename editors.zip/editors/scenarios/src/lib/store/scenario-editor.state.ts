/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { BaseEditorStoreData } from '@oksygen-sim-train-libraries/components-services/editors';

import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';

export type ScenarioEditorData = BaseEditorStoreData<Scenario>;

export interface ScenarioTrainStartPos {
  startSegmentName: string;
  startOffset: number;
  fromAlpha: boolean;
}

export type ScenarioEditorState = EntityState<ScenarioEditorData>;

export const scenarioEditorDataAdapter: EntityAdapter<ScenarioEditorData> = createEntityAdapter<ScenarioEditorData>();

export const initialScenarioEditorState: ScenarioEditorState = scenarioEditorDataAdapter.getInitialState();
