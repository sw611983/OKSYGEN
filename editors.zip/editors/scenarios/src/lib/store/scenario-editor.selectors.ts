/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/explicit-function-return-type */

import { EntityState } from '@ngrx/entity';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ScenarioEditorData, scenarioEditorDataAdapter } from './scenario-editor.state';
import { canRedo, canUndo, getEditorItem, getSavedName, getUnsavedChanges } from '@oksygen-sim-train-libraries/components-services/editors';

const scenarioEditorSelectors = scenarioEditorDataAdapter.getSelectors();

export const selectScenarioEditorState = createFeatureSelector<EntityState<ScenarioEditorData>>('scenarioEditor');

export const selectScenarioEditorEntities = createSelector(selectScenarioEditorState, scenarioEditorSelectors.selectEntities);

export const getAllScenarioEditorData = createSelector(selectScenarioEditorState, scenarioEditorSelectors.selectAll);

/**
 * Selector for observing the saved scenario name.
 * This will change when the scenario is saved.
 */
export const getSavedScenarioName = (id: string) =>
  createSelector(getAllScenarioEditorData, storeData => getSavedName(id, storeData));

/**
 * Selector for observing the unsaved changes state
 * This will change when the scenario is saved.
 */
export const getScenarioUnsavedChanges = (id: string) =>
  createSelector(getAllScenarioEditorData, storeData => getUnsavedChanges(id, storeData));

/**
 * Selector for observing the scenario under edit.
 * This will change during an editing session to reflect the user's input.
 */
export const getScenario = (id: string) =>
  createSelector(getAllScenarioEditorData, storeData => getEditorItem(id, storeData));

/**
 * Selector for observing the undo changes state
 * This will change when scenario data is changed.
 */
export const canUndoScenario = (id: string) =>
  createSelector(getAllScenarioEditorData, storeData => canUndo(id, storeData));

/**
 * Selector for observing the redo changes state
 * This will change when scenario data is changed.
 */
export const canRedoScenario = (id: string) =>
  createSelector(getAllScenarioEditorData, storeData => canRedo(id, storeData));
