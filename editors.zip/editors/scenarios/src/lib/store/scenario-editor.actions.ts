/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/explicit-function-return-type */

import { createActionGroup, props } from '@ngrx/store';

import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { LngLatCoord, Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectGeometry, ObjectProperties, TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import { ReportItem, ReportingEventItem } from '@oksygen-sim-train-libraries/components-services/assessment-criteria';
import { ParameterDefinitionValueType, PropertyUpdated } from '@oksygen-sim-train-libraries/components-services/common';
import { StoreObjectModification } from '@oksygen-sim-train-libraries/components-services/editors';
import { MultimediaReference } from '@oksygen-sim-train-libraries/components-services/multimedia';
import { ObjectTypeContainer, ObjectTypeState } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockReference } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario, ScenarioRuleVariable, TrainTypeEquipment } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { InitialConditionsTrains } from '@oksygen-sim-train-libraries/components-services/common';
import { Consist } from '@oksygen-sim-train-libraries/components-services/trains';

import { ScenarioTrainStartPos } from './scenario-editor.state';

/** Our list of possible actions one can take in the Rule Editor. */
export const scenarioEditorActions = createActionGroup({
  source: 'ScenarioEditorActionEnum',
  events: {
    'undo Scenario Edit': props<{ id: string }>(),
    'redo Scenario Edit': props<{ id: string }>(),

    'new Scenario': props<{ id: string; name: string }>(),
    'load Scenario': props<{ id: string; original: Scenario }>(),
    'load Scenario Unsafe': props<{ id: string; original: Scenario }>(),
    'save Scenario': props<{ id: string; save: Scenario }>(),

    'scenario Closed': props<{ id: string }>(),
    'set Scenario Name': props<{ id: string; name: string }>(),
    'set Scenario Description': props<{ id: string; desc: string }>(),
    'set Property': props<{ id: string; propertyName: string; propertyValue: any }>(),
    'set Subject': props<{ id: string; subject: string }>(),
    'set Selected World': props<{ id: string; trackName: string }>(),
    'set Selected Skin': props<{ id: string; skinName: string }>(),
    'set Date Time': props<{ id: string; dateTime: string }>(),
    'set Initial Environment State': props<{ id: string; property: string; value: number }>(),
    'set Assessment': props<{ id: string; assessment: boolean }>(),
    'set Initial Score': props<{ id: string; initialScore: number }>(),
    'set Target Score': props<{ id: string; targetScore: number }>(),
    'set Active Status': props<{ id: string; status: boolean }>(),

    'new Scenario Train From Consist': props<{ id: string; consist: Consist; name: string; pos?: ScenarioTrainStartPos }>(),
    'set Driver For Scenario Train':  props<{ id: string; scenarioTrainId: number; driverType: DriverType; driverName: string; driverId: string; driverVersion: string }>(),
    'update Scenario Train Name': props<{ id: string; scenarioTrainId: number; name: string }>(),
    'update Scenario Train Position': props<{ id: string; scenarioTrainId: number; segment: string; offset: number; orientation: Orientation }>(),
    'clear Scenario Train Position': props<{ id: string; scenarioTrainId: number }>(),
    'delete Scenario Train': props<{ id: string; scenarioTrainId: number }>(),

    'new Object From Type': props<{
      id: string;
      objectType: ObjectTypeContainer;
      name: string;
      lngLat: LngLatCoord;
      pos: ObjectGeometry;
      assocs?: TrackSegmentAssociation[];
    }>(),
    'new Object From Type Unsafe': props<{
      id: string;
      objectType: ObjectTypeContainer;
      name: string;
      lngLat: LngLatCoord;
      pos: ObjectGeometry;
      assocs?: TrackSegmentAssociation[];
    }>(),
    'update Object Name': props<{ id: string; objectId: number; name: string }>(),
    'update Object Position': props<{ id: string; objectId: number; lngLat: LngLatCoord; pos: ObjectGeometry; assocs?: TrackSegmentAssociation[] }>(),
    'update Object Initial State': props<{ id: string; objectId: number; state: ObjectTypeState }>(),
    'update Object Initial State Unsafe': props<{ id: string; objectId: number; state: ObjectTypeState }>(),
    'update Object Display State': props<{ id: string; objectId: number; state: ObjectTypeState; propertyUpdated: PropertyUpdated  }>(),
    'update Object Display State Unsafe': props<{ id: string; objectId: number; state: ObjectTypeState; propertyUpdated: PropertyUpdated  }>(),
    'set Scenario Object Properties': props<{ id: string; objectId: number; properties: ObjectProperties }>(),
    'delete Object': props<{ id: string; objectId: number }>(),
    // FIXME should we consolidate this with updateObjectInitialState above?
    'set Object Modification': props<{ id: string; objectName: string; propertyName: string; propertyValue: number | string | boolean }>(),
    'set Multiple Object Modifications': props<{ id: string; modifications: StoreObjectModification[] }>(),
    'remove Object Modification': props<{ id: string; objectName: string; propertyName: string }>(),

    'add Multimedia': props<{ id: string; displayName: string; multimediaId: string }>(),
    'delete Multimedia': props<{ id: string; ruleId: number }>(),
    'update Scenario Multimedia Name': props<{ id: string; ruleId: number; name: string; phantom: boolean }>(),

    'add Scenario Rule': props<{
      id: string;
      name: string;
      description: string;
      ruleTemplateId: string;
      version: string;
      multimedia: MultimediaReference[];
      multimediaId?: string;
    }>(),
    'duplicate Scenario Rule': props<{ id: string; name: string; description: string; ruleId: number; multimedia: MultimediaReference[] }>(),
    'delete Scenario Rule': props<{ id: string; ruleId: number; multimedia: MultimediaReference[] }>(),
    'update Scenario Rule Name': props<{ id: string; ruleId: number; name: string }>(),
    'update Scenario Rule Description': props<{ id: string; ruleId: number; description: string }>(),
    'update Scenario Rule Block': props<{ id: string; ruleId: number; block: RuleBlockReference; multimedia: MultimediaReference[] }>(),
    'update Scenario Rule Active': props<{ id: string; ruleId: number; active: boolean }>(),

    'update Hardware States Config': props<{ id: string; config: TrainTypeEquipment }>(),
    'update Initial Conditions Config': props<{ id: string; trainSimPropertiesAll: InitialConditionsTrains }>(),

    'add Scenario Assessment': props<{ id: string; displayName: string; assessmentCriteria: ReportItem; events: Array<ReportingEventItem> }>(),
    'delete Scenario Assessment': props<{ id: string; assessmentCriteriaId: number }>(),
    'update Scenario Assessment Name': props<{ id: string; assessmentCriteriaId: number; displayName: string }>(),
    'update Scenario Assessment Description': props<{ id: string; assessmentCriteriaId: number; description: string }>(),
    'update Scenario Assessment Assessed': props<{ id: string; assessmentCriteriaId: number; assessed: boolean }>(),
    'update Scenario Assessment Assessment Parameter': props<{
      id: string;
      assessmentCriteriaId: number;
      assessmentParameterName: string;
      value: ParameterDefinitionValueType;
    }>(),
    'update Scenario Assessment Parameter': props<{ id: string; assessmentCriteriaId: number; parameterName: string; value: ParameterDefinitionValueType }>(),
    'update Scenario Assessment Event Parameter': props<{
      id: string;
      assessmentCriteriaId: number;
      eventName: string;
      parameterName: string;
      value: ParameterDefinitionValueType;
    }>(),
    'update Scenario Rule Variable': props<{ id: string; name: string; variable: Partial<ScenarioRuleVariable> }>(),
    'add Scenario Rule Variable': props<{ id: string; variable: ScenarioRuleVariable }>(),
    'delete Scenario Rule Variable': props<{ id: string; name: string }>()
  }
});
