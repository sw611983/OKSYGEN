/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import {
  RuleBlock,
  RuleBlockReference,
  RulePropertyAllowedValues,
  RuleTemplate,
  RuleTemplateRuleBlock
} from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioRule } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { toVersionString, versionCompare, versionLatest } from '@oksygen-sim-train-libraries/components-services/versioning';
import { BasePropertyConstraint } from '../services/rule-block-property-constraints/base-property.constraint';
import { difference } from 'lodash';

export type RuleBlockConstraintFn = (block: ScenarioRuleBlockItem) => ScenarioRulePropertyItem[];
export type RuleBlockPropertyUpdatedHandlerFn = (block: ScenarioRuleBlockItem, propertyName: string, value: number|string|boolean) => void;

/**
 * Scenario rule property item. This may represent 1 or 2 actual scenario rule properties.
 */
export class ScenarioRulePropertyItem {
  // group: string;
  /** name is the unique identifier for this sim property */
  name: string;
  /**
   * type is defined list of rule block types. See ```RuleBlockPropertyTypeEnum```.
   * Each type can only exist ONCE per properties array.
   */
  type: string;
  value: string|number|boolean;
  displayName?: string;
  defaultValue?: string|number|boolean;
  /**
   * A constant list of possible values for this property.
   */
  allowedValues?: RulePropertyAllowedValues;
  units?: string;
  defaultUnits?: string;
  /** whether this property should be editable in the UI. Used when this property depends on others. */
  enabled?: boolean;
  /** an error message, usually to accompany enabled = false when there's some problem with the data. */
  errorMessage?: string;
  version?: string;

  /**
   * Creates a scenario rule item. Optionally pass through a data object containing initial values.
   *
   * @param data an object containing initial values
   */
  constructor(data?: any) {
    this.assignData(data);
  }

  /**
   * Pass in a data object with properties you want to assign to this property item.
   * This works as a PATCH - only properties you specify in data obj will be updated.
   *
   * @param data properties to be assigned
   */
  assignData(data: Partial<ScenarioRulePropertyItem>): void {
    if (!data) { return; }
    // assign properties
    if (Object.prototype.hasOwnProperty.call(data, 'name')) { this.name = data.name; }
    if (Object.prototype.hasOwnProperty.call(data, 'displayName')) { this.displayName = data.displayName; }
    if (Object.prototype.hasOwnProperty.call(data, 'type')) { this.type = data.type; }
    if (Object.prototype.hasOwnProperty.call(data, 'value')) { this.value = data.value; }
    if (Object.prototype.hasOwnProperty.call(data, 'defaultValue')) { this.defaultValue = data.defaultValue; }
    if (Object.prototype.hasOwnProperty.call(data, 'allowedValues')) { this.allowedValues = data.allowedValues; }
    if (Object.prototype.hasOwnProperty.call(data, 'units')) { this.units = data.units; }
    if (Object.prototype.hasOwnProperty.call(data, 'enabled')) { this.enabled = data.enabled; }
    if (Object.prototype.hasOwnProperty.call(data, 'errorMessage')) { this.errorMessage = data.errorMessage; }
    if (Object.prototype.hasOwnProperty.call(data, 'version')) { this.version = data.version; }
    if (Object.prototype.hasOwnProperty.call(data, 'defaultUnits')) { this.defaultUnits = data.defaultUnits; }

    // additional business logic - default name to type if name does not exist.
    if (!this.name && this.type) { this.name = this.type; }
  }

  isValid(): boolean {
    if (this.value === null || this.value === undefined || this.value === '') { return false; }
    if (this.allowedValues) {
      if (!this.allowedValues.allowedValues.find(v => v.value === this.value || v.value === `${this.value}`)) {
        return false;
      }
    }
    return true;
  }
}

export class ScenarioRuleBlockItem {

  constructor(
    public ruleBlock: RuleBlock,
    public templateBlock: RuleTemplateRuleBlock,
    public scenarioBlock: RuleBlockReference,
    public properties?: ScenarioRulePropertyItem[],
    protected ruleBlockPropertyContraints?: Map<string, BasePropertyConstraint>,
    protected unknownConstraint?: BasePropertyConstraint
  ) {}

  setProperty(name: string, value: string | number | boolean): void {
    const property = this.properties?.find(p => p.name === name);
    if (property) { property.value = value; }
    const constraint = this.findBestMatchedPropertyConstraint(name);
    return constraint.updateProperty(this, name, value);
  }

  isValid(): boolean {
    if (!this.properties) { return false; } // only happens if initialisation failed
    for (const property of this.properties) {
      if (!property.isValid()) { return false; }
    }
    return true;
  }

  private findBestMatchedPropertyConstraint(propertyName: string): BasePropertyConstraint {
    // first check if a constraint has been specifically added for this rule block
    const type = this.templateBlock.blockType;
    const constraintByType = this.ruleBlockPropertyContraints.get(type);
    if (constraintByType) {
      return constraintByType;
    }
    // if no specific constraint for this block we need to find the best match
    // the best match is the constraint for EXACTLY all properties on this block
    // if that doesn't exist, then the best match is the constraint that manages the most properties on this block
    // if no constraints handle this block then we need to resort to the unknown property handler
    let bestMatch: BasePropertyConstraint;
    let bestMatchedPropertyCount = 0;
    for (const constraint of this.ruleBlockPropertyContraints.values()) {
      const constraintProperties = constraint.managedProperties();
      if (!constraintProperties.includes(propertyName)) {
        continue;
      }

      const blockProperties = this.ruleBlock.properties.property.map(rbp => rbp.name);
      const matchedProperties = constraintProperties.filter(p => blockProperties.includes(p)).length;

      // Exact match for all properties
      if (matchedProperties === constraintProperties.length && matchedProperties === this.ruleBlock.properties.property.length) {
        bestMatch = constraint;
        break; // Exit the loop early since we found the best match
      }

      // Check for the most matched properties
      if (matchedProperties > bestMatchedPropertyCount) {
        bestMatch = constraint;
        bestMatchedPropertyCount = matchedProperties;
      }
    }
    return bestMatch ?? this.unknownConstraint;
  }

}

/**
 * A scenario rule item is a scenario rule + a bunch of relevant helpers.
 * You should not be creating these yourself - use ```ScenarioRuleFactory.createScenarioRule()```.
 */
export class ScenarioRuleItem {

  constructor(
    public scenarioRule: ScenarioRule,
    protected ruleBlocks: RuleBlock[],
    protected ruleTemplates: RuleTemplate[],
    protected ruleBlockPropertyContraints?: Map<string, BasePropertyConstraint>,
    protected unknownConstraint?: BasePropertyConstraint
  ) { }

  setScenarioRule(scenarioRule: ScenarioRule): void {
    this.scenarioRule = scenarioRule;
  }

  /**
   * Get the rule template of this rule.
   */
  getTemplate(): RuleTemplate {
    const templateId = this.scenarioRule.ruleTemplateReference.id;
    const version = this.scenarioRule.ruleTemplateReference.version;
    const template = this.ruleTemplates.find(t => t.id === templateId && toVersionString(t.version) === version);
    return template;
  }

  /**
   * Get all rule blocks associated with this rule.
   * This includes both rule blocks against the template AND rule blocks against the scenario.
   */
  getBlocks(): ScenarioRuleBlockItem[] {
    const blocks: ScenarioRuleBlockItem[] = [];
    const template = this.getTemplate();
    if (!template) { return blocks; }
    const templateBlocks = template.ruleBlocks.ruleBlock;
    const scenarioBlocks = this.scenarioRule.ruleTemplateReference.ruleBlocks.ruleBlock;
    const blockIds: number[] = []; // array of each block id
    templateBlocks.forEach(tb => {
      if (!blockIds.find(id => id === tb.id)) { blockIds.push(tb.id); }
    });
    scenarioBlocks.forEach(sb => {
      if (!blockIds.find(id => id === sb.blockId)) { blockIds.push(sb.blockId); }
    });
    // now that we have each block id of this scenario rule, get each block
    blockIds.forEach(id => {
      const block = this.getBlock(id);
      blocks.push(block);
    });
    return blocks;
  }

  getBlock(blockId: number): ScenarioRuleBlockItem {
    const scenarioBlock = this.scenarioRule.ruleTemplateReference?.ruleBlocks?.ruleBlock.find(rb => rb.blockId === blockId);
    const templateBlock = this.getTemplateBlock(blockId);
    const ruleBlock = this.getRuleBlockByName(templateBlock.blockType);
    const blockItem = new ScenarioRuleBlockItem(ruleBlock, templateBlock, scenarioBlock, undefined, this.ruleBlockPropertyContraints, this.unknownConstraint);
    const properties = this.getBlockProperties(blockItem);
    blockItem.properties = properties;
    return blockItem;
  }

  /**
   * Get a rule block as defined in a rule template.
   * Note - you probably don't want this, you're probably looking for getBlock().
   * getBlock() will give you the templateBlock, the ruleBlock itself and the scenarioRuleBlock.
   *
   * @param blockId the block id
   */
  getTemplateBlock(blockId: number): RuleTemplateRuleBlock {
    const template = this.getTemplate();
    const templateBlock = template.ruleBlocks.ruleBlock.find(b => b.id === blockId);
    return templateBlock;
  }

  /**
   * Get a rule block by a block id in your template block / scenario block.
   * Note - you probably don't want this, you're probably looking for getBlock().
   * getBlock() will give you the templateBlock, the ruleBlock itself and the scenarioRuleBlock.
   *
   * @param blockId the block id
   */
  getRuleBlockById(blockId: number): RuleBlock {
    const templateBlock = this.getTemplateBlock(blockId);
    const ruleBlock = this.ruleBlocks.find(b => b.name === templateBlock.blockType);
    return ruleBlock;
  }

  /**
   * Get a rule block by it's name (blockType in template block) in your template / scenario block.
   * Note - you probably don't want this, you're probably looking for getBlock().
   * getBlock() will give you the templateBlock, the ruleBlock itself and the scenarioRuleBlock.
   *
   * @param name the block's name
   */
  getRuleBlockByName(name: string): RuleBlock {
    const ruleBlock = this.ruleBlocks.find(b => b.name === name);
    return ruleBlock;
  }

  /**
   * Get a rule block's properties by a block id in your template block / scenario block.
   * Note - you probably don't want this, you're probably looking for getBlock().
   * getBlock() will give you the templateBlock, the ruleBlock itself and the scenarioRuleBlock.
   * And yes, getBlock() includes the properties :)
   *
   * @param blockId the block id
   */
  getBlockProperties(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const props: ScenarioRulePropertyItem[] = [];
    if (block) {
      const ruleBlockProperties = this.ruleBlockHandler(block);
      // TODO handle nulls
      if (ruleBlockProperties) {
        props.push(...ruleBlockProperties);
      }
    }
    return props;
  }

  /**
   * Returns whether this scenario rule is valid.
   */
  isValid(): boolean {
    if (!this.scenarioRule.displayName) { return false; }
    // FIXME we should save a reference to these blocks so we don't have to reconstruct each time.
    const blocks = this.getBlocks();
    for (const block of blocks) {
      const isValidBlock = block.isValid();
      if (!isValidBlock) {
        return false;
      }
    }
    return true;
  }

  /**
   * Returns whether this scenario rule uses the latest version of the referenced rule template.
   */
  isLatest(): boolean {
    const scenarioTemplates = this.ruleTemplates.filter(rt => rt.id === this.scenarioRule.ruleTemplateReference.id);
    const latest = versionLatest(scenarioTemplates.map(st => st.version));
    return versionCompare(latest, this.scenarioRule.ruleTemplateReference.version) === 0;
  }

  /**
   * Execute the rule block type handler for a specific rule block.
   * It should process the block and return a list of block properties.
   * Make sure the handler has been added to our handler list before this is called!
   * This is used because different rule types have different business logic requirements.
   * For example, environment rule blocks will have 2 properties - the env property & it's value.
   * Whereas a train rule block will need to validate train ids.
   *
   * @param type the type of property
   * @param prop the property to handle
   * @param block the properties rule block
   */
  protected ruleBlockHandler(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    const list: ScenarioRulePropertyItem[] = [];
    // properties not handled by by any of a constraints
    let unknownProperties = block.ruleBlock.properties?.property?.map(p => p.name) ?? [];
    this.ruleBlockPropertyContraints.forEach(handler => {
      const props = handler.managedProperties();
      // FIXME this algorithm is flawed - if multiple constraints handle properties with the same names
      // they will conflict and the first one to execute will run while it may not be the correct one.
      // the work around is to make sure the "more specific" constraint is added first.
       // handler should only be called if all it's properties exist AND none of those properties have already been handled
      const allPropertiesUnhandled = props.every(p => unknownProperties.includes(p));
      unknownProperties = allPropertiesUnhandled ? difference(unknownProperties, props) : unknownProperties;
      if (allPropertiesUnhandled) {
        list.push( ...handler.generatePropertyList(block) );
      }
    });
    if (this.unknownConstraint) {
      for (const prop of unknownProperties) {
        const unknownProperty = this.unknownConstraint.generateProperty(block, prop);
        list.push(unknownProperty);
      }
    }
    return list;
  }


}
