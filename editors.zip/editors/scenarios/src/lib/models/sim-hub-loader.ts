/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import {
  PhysicalHub,
  Simulator,
  SimulatorService
} from '@oksygen-sim-core-libraries/components-services/data-services';
import { ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import { CSystemSimulatorHelpersService } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

export interface SimHub {
  sim: Simulator;
  hub: PhysicalHub;
  systemNumber: number;
}

// FIXME copied from SimulatorsStationsComponent; that class should probably use this
export class SimHubLoader {
  private simulators$: Observable<Simulator[]>;
  private simHubs = new Array<SimHub>();

  private simSub: Subscription;

  public readonly simHubs$ = new BehaviorSubject<SimHub[]>([]);

  constructor(
    protected readonly imageService: ImageService,
    private systemSimsHelperService: CSystemSimulatorHelpersService,
    private simulatorService: SimulatorService
  ) {
    const supportedSimNames = this.systemSimsHelperService.getAllSupportedSimulators();

    this.simulators$ = this.simulatorService.data();
    this.simSub = this.simulators$.subscribe((sims: Simulator[]) => {
      if (sims) {
        this.simHubs = [];

        sims.forEach(sim => {
          // Only include supported sims
          if (supportedSimNames.includes(sim.name)) {
            sim.physicalHub.forEach(hub => {
              // Exclude hubs that are implementation details
              // FIXME this is rather hacky
              if (!hub.name.includes('Instructor') && !hub.name.includes('Classroom')) {
                const systemNumber = this.systemSimsHelperService.findMinimalSystem(sim.name);
                this.simHubs.push({ sim, hub, systemNumber });
              }
            });
          }
        });

        this.simHubs$.next(this.simHubs);
      }
    });
  }

  destroy(): void {
    this.simHubs$.complete();
    this.simSub?.unsubscribe();
  }

}
