/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TrainSimPropertyValues } from '@oksygen-sim-train-libraries/components-services/common';

interface SimPropertiesDialogTrain {
  scenarioTrainName: string;
  consistId: number;
}

export interface InitalConditionsDialogData {
  train?: SimPropertiesDialogTrain;
  vehicleClassName?: string;
  isDriven?: boolean;
  selectedPropertyName?: string;
  trainInitialConditions?: TrainSimPropertyValues;
}
