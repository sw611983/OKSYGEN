/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { EditorTopToolbarDefaultItemsConfig } from '@oksygen-sim-train-libraries/components-services/editors';
import { SSeConfig, SSeTopToolbarDefaultItemsConfig } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

// eslint-disable-next-line @typescript-eslint/no-empty-object-type
export interface ScenarioEditorConfig extends SSeConfig<ScenarioEditorTopToolbarDefaultItemsConfig> {
  previewEnabled?: boolean;
  assessmentEnabled?: boolean;
}

export interface ScenarioEditorTopToolbarDefaultItemsConfig extends SSeTopToolbarDefaultItemsConfig, EditorTopToolbarDefaultItemsConfig {
  path: boolean;
  camera: boolean;
  marker: boolean;
  // pointer: boolean;
  // information: boolean;
}

export class ScenarioEditorConfigTab {
  static readonly DETAIL = new ScenarioEditorConfigTab('detail');
  static readonly TRAIN = new ScenarioEditorConfigTab('train');
  static readonly ENVIROMENT = new ScenarioEditorConfigTab('environment');
  static readonly OBJECT = new ScenarioEditorConfigTab('object');
  static readonly NOTIFICATION = new ScenarioEditorConfigTab('notification');
  static readonly EVENT_TRIGGERS = new ScenarioEditorConfigTab('event triggers');
  static readonly MULTIMEDIA = new ScenarioEditorConfigTab('multimedia');
  static readonly RULE = new ScenarioEditorConfigTab('rule');
  static readonly WEATHER = new ScenarioEditorConfigTab('weather');
  static readonly MARKER = new ScenarioEditorConfigTab('marker');
  static readonly LIBRARY = new ScenarioEditorConfigTab('library');
  static readonly SIM_TRAINS_LIBRARY = new ScenarioEditorConfigTab('simTrainsLibrary');
  static readonly DRIVERS_LIBRARY = new ScenarioEditorConfigTab('driversLibrary');
  static readonly RULES_LIBRARY = new ScenarioEditorConfigTab('rulesLibrary');
  static readonly OBJECTS_LIBRARY = new ScenarioEditorConfigTab('objectsLibrary');
  static readonly MULTIMEDIA_LIBRARY = new ScenarioEditorConfigTab('multimediaLibrary');
  static readonly ASSESSMENT_CRITERIA = new ScenarioEditorConfigTab('assessmentCriteria');
  static readonly ASSESSMENT_CRITERIA_LIBRARY = new ScenarioEditorConfigTab('assessmentCriteriaLibrary');
  static readonly RULE_VARIBLES = new ScenarioEditorConfigTab('ruleVariables');

  constructor(public id: string) {}
}
