/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { cloneDeep } from 'lodash';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

import { asArray, momentToString } from '@oksygen-common-libraries/common';
import {
  OK_BUTTON,
  PlayPauseStopEnum,
  PromptDialogComponent,
  PromptDialogData,
  Sorter
} from '@oksygen-common-libraries/material/components';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import {
  convertStateToPlayPauseStopEnum,
  Health,
  isPausedOrRunning,
  ModuleState,
  PhysicalHub,
  Simulator,
  State,
  SystemStatusData
} from '@oksygen-sim-core-libraries/components-services/data-services';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { Scenario, VirtualLocationVehicle } from '@oksygen-sim-train-libraries/components-services/scenarios';
import {
  CommsModuleStateService,
  CSystemSimulatorHelpersService,
  getSelectedSystemData,
  isScenarioTrainCompatible,
  isSingleSessionSetupData,
  moduleStatusToPlayPauseStopEnum,
  ScenarioPreviewManager,
  sessionActions,
  SingleSimPreviewSetupData,
  StartSessionRejected,
  stopSessionInteractive,
  SystemStoreData,
  SystemStoreState
} from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { ScenarioTrain } from '@oksygen-sim-train-libraries/components-services/trains';

interface TableModuleState extends ModuleState {
  healthNum: number;
}

//  FIXME copied from Card Sim Hub, these similar pieces of code should be rationalised
export class SessionLauncher {
  static readonly SIM_STATE_UNINITIALISED: SystemStatusData = {
    state: State.UNKNOWN,
    health: Health.WEBSOCKET_ERROR,
    readyForSession: false,
    error: 'Not Initialised!'
  };


  // Items available for selection
  // instructors: ReadonlyArray<Instructor> = [];
  // scenarios: ReadonlyArray<Scenario> = [];
  // trainees: ReadonlyArray<Trainee | User> = [];
  trains: ReadonlyArray<ScenarioTrain> = [];
  hardware: string;
  isActive = false;

  // Widget state
  showFront = true;
  expansionOpen = false;

  selections: SingleSimPreviewSetupData;
  // timeOverridden: boolean;

  // Comms interactions
  systemHealth: 'error' | 'good' | 'degraded';
  sessionActive = new Map<number, boolean>();
  hubInSession = false;
  playPauseStopState = new Map<number, PlayPauseStopEnum>();
  hubPlayPauseStopState = PlayPauseStopEnum.STOP;

  moduleStates: Map<string, ModuleState>;
  tableModuleStates: TableModuleState[] = [];
  moduleStatesSorter: Sorter<TableModuleState>;

  moduleStatesDisplayedColumns = ['health', 'name', 'state'];

  loadingScenarios = true;
  loadingTrainees = true;

  playPauseDisabled = true;
  startButtonDisabled = true;

  /** true if the hardware is good for the session to start */
  private hardwareStatus = true;

  private sessionStarting = false;

  private subscription = new Subscription();

  private initialised = false;

  private previousState = SessionLauncher.SIM_STATE_UNINITIALISED;

  private dynamicPreview: boolean;

  constructor(
    private readonly registry: Registry,
    private readonly logger: Logging,
    private readonly userService: UserService,
    private readonly store: Store<SystemStoreState>,
    private readonly systemSimsHelperService: CSystemSimulatorHelpersService,
    private readonly commsModuleStateService: CommsModuleStateService,
    private readonly dialog: MatDialog,
    private readonly authService: AuthService,
    private readonly zone: NgZone,
    private readonly translateService: TranslateService,
    private readonly scenarioPreviewManager: ScenarioPreviewManager,
    private readonly simulator: Simulator,
    private readonly physicalHub: PhysicalHub,
    private readonly systemNumber: number
  ) {
    this.moduleStatesSorter = new Sorter<TableModuleState>();
    this.moduleStatesSorter.sortFunction = this.moduleStatesSorterFunction.bind(this);

    const editorScenario = this.registry.getObject(['editor', 'scenario'], { dynamicPreview: { defaultSessionType: 'default' }});
     this.dynamicPreview  = editorScenario.dynamicPreview.defaultSessionType.toLowerCase() === 'preview';
    this.updateModuleStates();

    this.subscription.add(
      this.commsModuleStateService
        .dataUpdated$()
        .pipe(filter(v => v === this.systemNumber))
        .subscribe(() => (this.updateModuleStates()))
    );

    this.systemSimsHelperService.getAllAssociatedSystems(this.simulator.name).forEach(systemId => {
      this.subscription.add(
        // force this to run inside the angular zone.  This is for INTOSC-10493
        // this seems to be an issue with running in cordova in particular
        this.store.select(getSelectedSystemData(this.zone, systemId)).subscribe(storeData => this.zone.run(() => this.processStoreData(systemId, storeData)))
      );
    });
  }

  destroy(): void {
    this.subscription.unsubscribe();
  }

  private updateStartButtonDisabled(): void {
    this.zone.run(() => {
      // force to run in the zone, to make sure that the start button state gets properly updated
      // this seems to be an issue with running in cordova in particular
      this.startButtonDisabled = !(!!this.selections?.scenarioTrain && this.hardwareStatus) || this.sessionStarting;
    });
  }

  updateModuleStates(): void {
    this.moduleStates = this.commsModuleStateService.getModuleStates(this.systemNumber);
    this.tableModuleStates = [];
    this.moduleStates.forEach(value => {
      const tableValue = {
      ...value,
      healthNum: this.healthToNumber(value.health)
      };

      // This must match with the check on the template, so we can sort those that show an exclamation.
      if (value.state === 'Dropped' || value.state === 'Incompatible') {
        tableValue.healthNum = 2;
      }

      this.tableModuleStates.push(tableValue);
    });
  }

  private healthToNumber(value: Health): number {
    switch (value) {
      case Health.GOOD:
        return 0;
      case Health.DEGRADED:
        return 1;
      case Health.SESSION_ERROR:
        return 3;
      case Health.SCENARIO_ERROR:
        return 3;
      case Health.FATAL_ERROR:
        return 3;
      default:
        return 3;
    }
  }

  private processStoreData(systemId: number, storeData: SystemStoreData): void {
    // TODO possibly want to use this data to populate the selections
    const newState: SystemStatusData = storeData ? storeData.session.state : SessionLauncher.SIM_STATE_UNINITIALISED;

    // FIXME doesn't take into account multiple systems, doesn't look for missing modules, etc.
    const health = newState.health;
    if (health === Health.GOOD) {
      this.systemHealth = 'good';
    } else if (health === Health.DEGRADED) {
      this.systemHealth = 'degraded';
    } else {
      this.systemHealth = 'error';
    }

    this.isActive = isPausedOrRunning(newState.state);
    this.sessionActive.set(systemId, this.isActive);

    this.playPauseStopState.set(systemId, convertStateToPlayPauseStopEnum(newState.state));

    const playPauseState = moduleStatusToPlayPauseStopEnum(systemId, storeData?.session, this.systemSimsHelperService);
    this.playPauseDisabled = playPauseState === PlayPauseStopEnum.LOADING;

    if (this.previousState.state !== State.IDLE && newState.state === State.IDLE) {
      this.updateSessionStarting(false);
    }

    this.updateHubState();

    if (this.isActive) {
      if (!storeData?.sessionSetup) {
        if (this.selections) {
          this.store.dispatch(sessionActions.updateSessionSetup({ systemNumber: this.systemNumber, sessionSetup: cloneDeep(this.selections) }));
        }
      } else {
        if (isSingleSessionSetupData(storeData.sessionSetup)) {
          if (!this.selections?.scenario && storeData.sessionSetup?.scenario) {
            this.setScenario(cloneDeep(storeData.sessionSetup.scenario));
          }

          if (!this.selections?.scenarioTrain && storeData.sessionSetup.scenarioTrain) {
            this.selectTrain(cloneDeep(storeData.sessionSetup.scenarioTrain));
          }
        }
      }
    } else if (!this.initialised && !!this.selections) {
      const selections = cloneDeep(this.selections);

      // folow the workflow and make sure all data setup is done

      if (selections.scenario) {
        this.setScenario(selections.scenario);
      }

      if (selections.scenarioTrain) {
        this.selectTrain(selections.scenarioTrain);
      }
    }

    this.previousState = newState;
    this.initialised = true;
  }

  private updateSessionStarting(value: boolean): void {
    this.sessionStarting = value;
    this.updateStartButtonDisabled();
  }

  /**
   * Examines the states of all systems and distills it into an overall state for this hub.
   */
  private updateHubState(): void {
    const activeSystem = this.getActiveSystem();
    this.hubInSession = activeSystem !== -1;
    this.hubPlayPauseStopState = this.playPauseStopState.get(activeSystem);
  }

  /**
   * Looks at the state of all systems associated with this hub and
   * returns the active system's ID, or -1 if no systems are active.
   * Comms ensures that modules can only participate in a single active system.
   */
  private getActiveSystem(): number {
    for (const e of Array.from(this.sessionActive.entries())) {
      if (e[1]) {
        return e[0];
      }
    }

    return -1;
  }

  flip(): void {
    this.showFront = !this.showFront;

    if (!this.showFront) {
      this.updateModuleStates();
    }
  }

  moduleStatesSorterFunction(c: string, a: TableModuleState, b: TableModuleState): number {
    const currentLocale = this.translateService.currentLocaleString;
    switch (c) {
      case 'health':
        return a.healthNum === b.healthNum ? 0 : a.healthNum > b.healthNum ? 1 : -1;
      case 'name':
        return a.name.localeCompare(b.name, currentLocale);
      case 'state':
        return a.state.localeCompare(b.state, currentLocale);
      default:
        return 0;
    }
  }

  // SESSION SETUP

  /**
   * Selects the given Scenario.
   *
   * @param scenario The Scenario to select.
   */
  setScenario(scenario: Scenario): void {
    // if (this.selections.scenario?.id !== scenario?.id || !scenario) {

      this.selections = {
        instructor: this.userService.instructors.find(i => i.id === this.authService.getLoggedInUser().id),
        systemNumber: this.systemNumber,
        simulator: this.simulator,
        hub: this.physicalHub,
        scenarioTrain: undefined,
        carIndex: undefined,
        location: undefined,
        startPositions: undefined
      };

      this.trains = undefined;
      this.selectTrain(undefined);

      this.selections.scenario = scenario;
      this.selections.startTime = scenario?.scenarioStartTime;

      if (scenario) {
        // this.usersScenariosService.getScenario(scenario.id).subscribe(s => {
          // this.selections.scenario = scenario; // replace with the full scenario

          this.trains = asArray(scenario.scenarioTrains.scenarioTrain).filter(value => isScenarioTrainCompatible(scenario, value, this.physicalHub), this);

          if (this.trains.length === 1) {
            this.selectTrain(this.trains[0]);
          } else if (this.trains.length > 1) {
            // FIXME Can't handle multiple sim trains yet
            this.logger.info('Can\'t handle multiple sim trains yet :(');
            return;
          }

          this.updateStartButtonDisabled();
        // });
      }
    // }
  }

  selectTrain(scenarioTrain: ScenarioTrain): void {
    this.selections.scenarioTrain = scenarioTrain;

    // Auto select the location on car 0.
    if (scenarioTrain) {
      const scenVLs = asArray(this.selections.scenario.virtualLocations.virtualLocation) as VirtualLocationVehicle[];

      for (const vl of scenVLs) {
        if (vl.vehicleIndex === 0 && vl.scenarioTrainName === this.selections.scenarioTrain.name) {
          this.selectLocation(vl);
        }
      }
    }

    this.updateStartButtonDisabled();
  }

  selectLocation(location: VirtualLocationVehicle): void {
    this.selections.location = location;

    this.updateStartButtonDisabled();
  }

  momentToString(time: moment.Moment): string {
    return momentToString(time);
  }

  // SESSION LAUNCH

  startPreview(): void {
    this.updateSessionStarting(true);

    this.selections.isScenario = true;

    this.scenarioPreviewManager.stopVision();
    this.scenarioPreviewManager.connectToComms();
    this.systemSimsHelperService.startPreview(this.systemNumber, this.simulator.id, this.physicalHub, this.selections, this.dynamicPreview)
      .catch(r => {
        const data = new PromptDialogData();
        data.title = t('Could not start a Session');
        data.content = t('An undefined error occurred.');

        switch (r) {
          case (StartSessionRejected.NO_SESSION_ID):
            data.content = t('A Session ID could not be generated. Make sure the database is running and it allows write operations.');
            break;
        }

        data.buttons = OK_BUTTON;
        PromptDialogComponent.open(this.dialog, {id: 'START_SESSION_FAILED', data},
          x => this.updateSessionStarting(false));
      });
  }

  // IN SESSION

  playPauseStopStateChange(newState: PlayPauseStopEnum): void {
    const systemNumber = this.getActiveSystem();

    if (newState === PlayPauseStopEnum.STOP) {
      stopSessionInteractive(this.registry, this.dialog, this.systemSimsHelperService, systemNumber, this.store);
    } else {
      this.store.dispatch(sessionActions.updateSessionState({ systemNumber, state: newState }));
    }
  }
}
