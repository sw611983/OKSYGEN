/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RuleBlock, RuleTemplateRuleBlock, RuleBlockReference, RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';
import {
  ScenarioRuleBlockItem,
  ScenarioRuleItem,
  ScenarioRulePropertyItem
} from './scenario-rule-item.model';
import { BasePropertyConstraint } from '../services/rule-block-property-constraints/base-property.constraint';
import { ScenarioRule } from '@oksygen-sim-train-libraries/components-services/scenarios';

class FakePropertyConstraint extends BasePropertyConstraint {
  override generatePropertyList(block: ScenarioRuleBlockItem): ScenarioRulePropertyItem[] {
    return [];
  }
  override updateProperty(block: ScenarioRuleBlockItem, propertyName: string, value: number | string | boolean): void {}
  override managedProperties(): string[] {
    return [];
  }
}

describe('scenario-rule-item model', () => {
  describe('Scenario Rule Property Item', () => {
    let scenarioRulePropertyItem: ScenarioRulePropertyItem;

    beforeEach(() => {
      scenarioRulePropertyItem = new ScenarioRulePropertyItem();
    });

    it('should create an instance', () => {
      expect(scenarioRulePropertyItem).toBeTruthy();
    });

    it('should assign data', () => {
      const data = new ScenarioRulePropertyItem({
        name: 'testName',
        type: 'testType',
        value: 'testValue',
        displayName: 'testDisplayName',
        defaultValue: 'testDefaultValue',
        allowedValues: {
          allowedValues: [
            {
              value: 'testValue',
              displayName: 'Test Value',
              name: 'name'
            }
          ],
          displayedValues: [],
          type: 'dropdown'
        },
        units: 'testUnits',
        enabled: true,
        errorMessage: 'testErrorMessage',
        version: 'testVersion'
      });
      scenarioRulePropertyItem.assignData(data);
      expect(scenarioRulePropertyItem.name).toEqual(data.name);
      expect(scenarioRulePropertyItem.type).toEqual(data.type);
      expect(scenarioRulePropertyItem.value).toEqual(data.value);
      expect(scenarioRulePropertyItem.displayName).toEqual(data.displayName);
      expect(scenarioRulePropertyItem.defaultValue).toEqual(data.defaultValue);
      expect(scenarioRulePropertyItem.allowedValues).toEqual(data.allowedValues);
      expect(scenarioRulePropertyItem.units).toEqual(data.units);
      expect(scenarioRulePropertyItem.enabled).toEqual(data.enabled);
      expect(scenarioRulePropertyItem.errorMessage).toEqual(data.errorMessage);
      expect(scenarioRulePropertyItem.version).toEqual(data.version);
    });

    it('should validate value', () => {
      scenarioRulePropertyItem.value = 'value';
      scenarioRulePropertyItem.allowedValues = {
        allowedValues: [{ value: 'value', displayName: 'Value', name: 'name' }],
        displayedValues: [],
        type: 'dropdown'
      };
      expect(scenarioRulePropertyItem.isValid()).toBeTrue();

      scenarioRulePropertyItem.value = 'invalidValue';
      expect(scenarioRulePropertyItem.isValid()).toBeFalse();
    });
    it('should assign data with constructor', () => {
      const data = { name: 'test', type: 'string', value: 'value' };
      const item = new ScenarioRulePropertyItem(data);
      expect(item.name).toEqual('test');
      expect(item.type).toEqual('string');
      expect(item.value).toEqual('value');
    });

    it('should default name to type if name does not exist', () => {
      scenarioRulePropertyItem.assignData({ type: 'string', value: 'value' });
      expect(scenarioRulePropertyItem.name).toEqual('string');
    });

    it('should validate correctly with allowed values', () => {
      scenarioRulePropertyItem.assignData({
        name: 'test',
        type: 'string',
        value: 'value',
        allowedValues: {
          allowedValues: [
            {
              value: 'value',
              displayName: 'Test Value',
              name: 'name'
            }
          ],
          displayedValues: [],
          type: 'dropdown'
        }
      });
      expect(scenarioRulePropertyItem.isValid()).toBeTruthy();
    });

    it('should invalidate correctly with disallowed values', () => {
      scenarioRulePropertyItem.assignData({
        name: 'test',
        type: 'string',
        value: 'invalid',
        allowedValues: {
          allowedValues: [
            {
              value: 'testValue',
              displayName: 'Test Value',
              name: 'name'
            }
          ],
          displayedValues: [],
          type: 'dropdown'
        }
      });
      expect(scenarioRulePropertyItem.isValid()).toBeFalsy();
    });

    it('should invalidate correctly with null, undefined, or empty string values', () => {
      scenarioRulePropertyItem.assignData({ name: 'test', type: 'string', value: null });
      expect(scenarioRulePropertyItem.isValid()).toBeFalsy();
      scenarioRulePropertyItem.assignData({ name: 'test', type: 'string', value: undefined });
      expect(scenarioRulePropertyItem.isValid()).toBeFalsy();
      scenarioRulePropertyItem.assignData({ name: 'test', type: 'string', value: '' });
      expect(scenarioRulePropertyItem.isValid()).toBeFalsy();
    });
  });
  describe('ScenarioRuleBlockItem', () => {
    let scenarioRuleBlockItem: ScenarioRuleBlockItem;
    let ruleBlock: RuleBlock;
    let templateBlock: RuleTemplateRuleBlock;
    let scenarioBlock: RuleBlockReference;
    let properties: ScenarioRulePropertyItem[];
    let ruleBlockPropertyConstraints: Map<string, BasePropertyConstraint>;
    const unknownPropertyConstraint = new FakePropertyConstraint(null, null);

    beforeEach(() => {
      ruleBlock = {
        name: 'testName',
        displayName: 'Test Display Name',
        displayDescription: 'Test Display Description',
        version: '1.0',
        icon: 'test-icon',
        category: 'constant',
        toolbarIcon: 'test-toolbar-icon',
        blockIcon: {},
        properties: { property: [] },
        inputPorts: { port: [] },
        outputPorts: { port: [] },
        blockScripts: { actionScript: [], outputScript: [] }
      };

      templateBlock = {
        id: 1,
        version: '1.0',
        displayName: 'Test Display Name',
        blockType: 'testType'
      };

      scenarioBlock = {
        blockId: 1,
        properties: { property: [] }
      };
      properties = [new ScenarioRulePropertyItem({ name: 'test', type: 'string', value: 'value' })];
      ruleBlockPropertyConstraints = new Map();
      ruleBlockPropertyConstraints.set('test', new FakePropertyConstraint(null, null));
      scenarioRuleBlockItem = new ScenarioRuleBlockItem(ruleBlock, templateBlock, scenarioBlock, properties, ruleBlockPropertyConstraints);
    });

    it('should create an instance', () => {
      expect(scenarioRuleBlockItem).toBeTruthy();
    });

    it('should return true with valid properties', () => {
      expect(scenarioRuleBlockItem.isValid()).toBeTruthy();
    });

    it('should return false with invalid properties', () => {
      properties[0].value = '';
      expect(scenarioRuleBlockItem.isValid()).toBeFalsy();
    });

    it('should return false with no properties', () => {
      const noProp = new ScenarioRuleBlockItem(
        ruleBlock, templateBlock, scenarioBlock, undefined, ruleBlockPropertyConstraints, unknownPropertyConstraint
      );
      expect(noProp.isValid()).toBeFalsy();
    });

    it('should update property', () => {
      const props = [new ScenarioRulePropertyItem({ name: 'test', type: 'string', value: 'value' })];
      const unknownPropertyC = new FakePropertyConstraint(null, null);
      const item = new ScenarioRuleBlockItem(
        ruleBlock, templateBlock, scenarioBlock, props, ruleBlockPropertyConstraints, unknownPropertyC
      );
      const spy = spyOn(unknownPropertyC, 'updateProperty');
      item.setProperty('test', 'newValue');
      expect(spy).toHaveBeenCalled();
    });
  });
  /**
   * Please save me
   * RuleBlock has 3 different types and is used in way too many places.
   */

  describe('ScenarioRuleItem', () => {
    let scenarioRuleItem: ScenarioRuleItem;
    let scenarioRule: ScenarioRule;
    let ruleBlocks: RuleBlock[];
    let ruleTemplates: RuleTemplate[];
    let ruleBlockHandlers: Map<string, BasePropertyConstraint>;
    const ruleTemplateRuleBlock: RuleTemplateRuleBlock = {
      id: 1,
      version: '1.0',
      displayName: 'Test Display Name',
      blockType: 'testType'
    };
    const ruleBlockReference: RuleBlockReference = {
      blockId: 1,
      properties: { property: [] }
    };

    beforeEach(() => {
      // Initialize your variables here
      scenarioRule = {
        id: 1,
        ruleType: 'Type1',
        displayName: 'Test Scenario Rule',
        description: 'This is a test scenario rule',
        active: true,
        ruleTemplateReference: {
          id: 'rule',
          version: '1.1.1',
          ruleBlocks: { ruleBlock: [ruleBlockReference] }
        }
      };
      ruleBlocks = [
        {
          name: 'testType',
          displayName: 'displayName',
          displayDescription: 'displayDescription',
          version: '1.1.1',
          icon: 'icon',
          category: 'constant',
          toolbarIcon: 'toolbarIcon',
          blockIcon: {},
          properties: { property: [] },
          inputPorts: { port: [] },
          outputPorts: { port: [] },
          blockScripts: { actionScript: [], outputScript: [] }
        }
      ];
      ruleTemplates = [
        {
          id: 'rule',
          displayName: 'displayName',
          history: { historyLog: [] },
          version: { major: 1, minor: 1, patch: 1 },
          displayDescription: 'displayDescription',
          ruleBlocks: { ruleBlock: [ruleTemplateRuleBlock, { ...ruleTemplateRuleBlock, id: 12 }] }
        }
      ];
      ruleBlockHandlers = new Map<string, BasePropertyConstraint>();

      scenarioRuleItem = new ScenarioRuleItem(scenarioRule, ruleBlocks, ruleTemplates, ruleBlockHandlers);
    });

    it('should create an instance', () => {
      expect(scenarioRuleItem).toBeTruthy();
    });

    it('should set scenario rule', () => {
      const newScenarioRule: ScenarioRule = {
        id: 2,
        ruleType: 'Type2',
        displayName: 'New Test Scenario Rule',
        description: 'This is a new test scenario rule',
        active: false,
        ruleTemplateReference: { id: 'rule', version: 'New Test Rule Template', ruleBlocks: { ruleBlock: [] } }
      };
      scenarioRuleItem.setScenarioRule(newScenarioRule);
      expect(scenarioRuleItem.scenarioRule).toBe(newScenarioRule);
    });

    it('should get template', () => {
      const template = scenarioRuleItem.getTemplate();
      expect(template).toEqual(ruleTemplates[0]);
    });

    it('should get blocks', () => {
      const blocks = scenarioRuleItem.getBlocks();
      expect(blocks.length).toEqual(2);
    });

    it('should get a rule block by Id', () => {
      const block = scenarioRuleItem.getRuleBlockById(1);
      expect(block).toEqual(ruleBlocks[0]);
    });

    it('should validate scenario rule', () => {
      const isValid = scenarioRuleItem.isValid();
      expect(isValid).toBeTrue();
    });

    it('should check if scenario rule uses the latest version', () => {
      const isLatest = scenarioRuleItem.isLatest();
      expect(isLatest).toBeTrue();
    });
  });
});
