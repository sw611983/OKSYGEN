/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { BasicTabNavItem, TabGroupChild } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { EditorData } from '@oksygen-sim-train-libraries/components-services/editors';

export const SCENARIOS_CARD_DATA = new EditorData(
  t('Scenarios'),
  '/editors/scenarios',
  OksygenIcon.SCENARIO,
  'scenarios'
);

export type ScenarioTabType = TabGroupChild<BasicTabNavItem>;
