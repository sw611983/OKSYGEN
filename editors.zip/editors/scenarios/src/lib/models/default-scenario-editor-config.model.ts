/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { isNil } from 'lodash';

import { ToolboxContainerTabsConfig } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { DETAILS, MULTIMEDIA, OBJECTS, TRAINS } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectsPanelEditorComponent } from '@oksygen-sim-train-libraries/components-services/editors';
import { MultimediaPanelComponent } from '@oksygen-sim-train-libraries/components-services/editors/multimedia';
import { LineViewComponent, MiniMapComponent, PlanViewComponent } from '@oksygen-sim-train-libraries/components-services/maps';
import { EnvironmentControlsComponent, ScenarioDetailPanelComponent } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

import { ScenarioRulesPanelComponent } from '../components/scenario-rules-panel/scenario-rules-panel.component';
import { TrainsPanelTrainsEditorComponent } from '../components/trains-panel-trains-editor/trains-panel-trains-editor.component';
import { ScenarioEditorConfig } from './scenario-editor-config.model';
import { AssessmentCriteriaPanelComponent } from '@oksygen-sim-train-libraries/components-services/assessment-criteria/scenario';
import { ScenarioRuleVariablesComponent } from '../components/scenario-rule-variables/scenario-rule-variables.component';

/**
 * Default config for the scenario editor.
 * Will include most tabs and all toolbar options, and use MiniMapComponent, LineViewComponent & PlanViewComponent.
 * Tabs included: details, trains, objects, multimedia, rules & environment.
 */
export function defaultScenarioEditorConfig(additionalTabs?: ToolboxContainerTabsConfig): ScenarioEditorConfig {
  const config: ScenarioEditorConfig = {
    previewEnabled: true,
    assessmentEnabled: true,
    miniView: {
      component: MiniMapComponent
    },
    lineView: {
      component: LineViewComponent
    },
    planView: {
      component: PlanViewComponent
    },
    tabs: {
      endTabs: {
        detail: {
          name: DETAILS,
          icon: OksygenIcon.INFORMATION,
          component: ScenarioDetailPanelComponent
        },
        train: {
          name: TRAINS,
          icon: OksygenIcon.TRAIN,
          component: TrainsPanelTrainsEditorComponent
        },
        object: {
          name: OBJECTS,
          icon: OksygenIcon.OBJECT,
          component: ObjectsPanelEditorComponent
        },
        multimedia: {
          name: MULTIMEDIA,
          icon: OksygenIcon.VIDEO,
          component: MultimediaPanelComponent
        },
        rule: {
          name: t('Rules'),
          icon: OksygenIcon.RULE_EDITOR,
          component: ScenarioRulesPanelComponent
        },
        environment: {
          name: t('Environment'),
          icon: OksygenIcon.WEATHER,
          component: EnvironmentControlsComponent
        },
        assessmentCriteria: {
          name: t('Assessment Criteria'),
          icon: OksygenIcon.TEST_ALT,
          component: AssessmentCriteriaPanelComponent
        },
        ruleVariables: {
          name: t('Rule Variables'),
          icon: OksygenIcon.VARIABLE,
          component: ScenarioRuleVariablesComponent
        }
      }
    },
    topToolbar: {
      defaultItems: {
        save: true,
        undo: true,
        redo: true,
        copy: true,
        map: true,
        elevation: true,
        layers: true,
        stations: true,
        path: true,
        camera: true,
        marker: true
      }
    }
  };

  if (!isNil(additionalTabs?.startTabs)) {
    config.tabs.startTabs = { ...config.tabs.startTabs, ...additionalTabs.startTabs };
  }

  if (!isNil(additionalTabs?.endTabs)) {
    config.tabs.endTabs = { ...config.tabs.endTabs, ...additionalTabs.endTabs };
  }

  return config;
}
