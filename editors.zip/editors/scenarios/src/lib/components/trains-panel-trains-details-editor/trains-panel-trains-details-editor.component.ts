/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, signal, SimpleChanges } from '@angular/core';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { LangChangeEvent, TranslateService } from '@oksygen-common-libraries/material/translate';
import { cloneDeep, isNil } from 'lodash';
import { Observable, Subscription } from 'rxjs';
import { debounceTime, filter } from 'rxjs/operators';
import { AbstractControl, UntypedFormControl, ValidationErrors } from '@angular/forms';

import { extractJSONData, takeOneTruthy, DragFeedback } from '@oksygen-common-libraries/common';
import {
  newFormControl,
  newNumericFormControl,
  newOptionalFormControl,
  quietUpdateOptions,
  AutocompleteInputType,
  InputError,
  errorStateMatcher,
  validateMandatoryString,
  UpdateOn
} from '@oksygen-common-libraries/material/components';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { FaultItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { deleteDialog, DragData, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import {
  colourForDriverType,
  Consist,
  ConsistDataService,
  DriverListItem,
  DriverListItemDriver,
  iconForDriverType,
  isDriverListItemData,
  QUICK_ACTIONS_DISABLED,
  ScenarioTrains,
  TrainCardConfig,
  TrainQuickActionConfig,
  UsefulTrain,
  UsefulVehiclePosition
} from '@oksygen-sim-train-libraries/components-services/trains';

import { UserConfig } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import {
  NetworkDefinitionManager, TrackLocationPanelSegmentOffsetInput, TrackLocationPanelTrackNameInput, TrackLocationPanelUserScaleInput,
  UserScaleUi, createUIsForNewValues, processUserScaleUpdate
} from '@oksygen-sim-train-libraries/components-services/world-definition';
import { ReachablePathFinder, ScenarioTrainItem } from '@oksygen-sim-train-libraries/components-services/maps';
import { ScenarioEditManager } from '../../services/scenario-edit.manager';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Orientation, SegOffset, UserScale, reverse } from '@oksygen-sim-core-libraries/data-types/common';
import { MatDialog } from '@angular/material/dialog';
import {
  TrainHardwareInitialStatesDialogComponent
} from '../train-hardware-initial-states-dialog/train-hardware-initial-states-dialog.component';
import { Scenario, TrainTypeEquipment } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { SimPropertyValues, InitialConditionsTrains, TrainSimPropertyValues } from '@oksygen-sim-train-libraries/components-services/common';
import { TrainHardwareEquipmentTypeData, TrainHardwareInitialStatesDialogData } from '../../models/train-hardware-initial-states.model';
import { Registry } from '@oksygen-common-libraries/pio';
import { InitalConditionsDialogComponent } from '../initial-conditions/initial-conditions-dialog/initial-conditions-dialog.component';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { InitalConditionsDialogData } from '../../models/initial-conditions.model';

@Component({
  selector: 'oksygen-trains-panel-trains-details-editor',
  templateUrl: './trains-panel-trains-details-editor.component.html',
  styleUrls: [ './trains-panel-trains-details-editor.component.scss' ]
})
export class TrainsPanelTrainsDetailsEditorComponent implements OnInit, OnChanges, OnDestroy {
  readonly DRIVER_TYPE_HUMAN = DriverType.HUMAN;

  @Input() world$!: Observable<WorldData>;
  @Input() netDef$!: Observable<NetworkDefinitionManager>;
  @Input() pathFinder$!: Observable<ReachablePathFinder>;
  @Input() scenario$: Observable<Scenario>;
  @Input() train!: UsefulTrain;
  @Input() pathToggled = false;
  @Input() selectedFault: FaultItem;
  @Input() settings: TrainQuickActionConfig = QUICK_ACTIONS_DISABLED;
  @Input() userConfig: UserConfig;
  @Input() otherScenarioTrainNames: string[] = [];
  @Input() scenarioEditManager!: ScenarioEditManager;
  @Input() driverList$: Observable<Array<DriverListItemDriver>>;

  @Output() readonly favourite:         EventEmitter<UsefulTrain> = new EventEmitter();
  @Output() readonly goToTrain:         EventEmitter<UsefulTrain> = new EventEmitter();
  @Output() readonly lockOnTrain:       EventEmitter<UsefulTrain> = new EventEmitter();
  @Output() readonly showTrain:         EventEmitter<UsefulTrain> = new EventEmitter();
  @Output() readonly pathTrain:         EventEmitter<UsefulTrain> = new EventEmitter();
  @Output() readonly changeOrientation: EventEmitter<UsefulTrain> = new EventEmitter();
  @Output() readonly deleteTrain:       EventEmitter<UsefulTrain> = new EventEmitter();
  @Output() readonly trainDetailsUpdated: EventEmitter<boolean>     = new EventEmitter();

  modifiedDisabled = signal(false);

  autocompleteInputType = AutocompleteInputType.FORM_FIELD;

  world: WorldData;
  netDef: NetworkDefinitionManager;
  pathFinder: ReachablePathFinder;
  segments: Array<number> = [];
  private readonly subscriptions = new Subscription();

  readonly nameControl = newFormControl(UpdateOn.CHANGE, c => {
    if (this.otherScenarioTrainNames?.includes(c.value)) {
      return { [this.duplicateName]: true };
    }

    return null;
  });
  readonly duplicateName = 'duplicateName';
  readonly segmentControl = newFormControl();
  /**
   * Offset form control.
   * Deliberately accepts out of bounds inputs, so the user can easily say "move the association forward 20 meters"
   * without intermediate points/connections getting in their way.
   */
  readonly trackNameControl = newFormControl();
  readonly offsetControl = newNumericFormControl();
  readonly orientationControl = newFormControl();
  readonly driverControl = newOptionalFormControl();
  userScaleControls: UserScaleUi[] = [];
  private userScaleSubs: Subscription;

  config: TrainCardConfig;
  trackLocationConfig: {
    trackName: TrackLocationPanelTrackNameInput;
    userScales: TrackLocationPanelUserScaleInput;
    segmentOffset: TrackLocationPanelSegmentOffsetInput;
  };

  // Probably should be a property of the train
  consist: Consist;

  driverTypeIcon: string;
  driverTypeColour: string;

  dragData: DragData;
  dragging = false;
  dragFeedback: DragFeedback = {allowed: false, message: ''};
  offsetError: string;
  driverList: Array<DriverListItemDriver>;

  selectedDriver: DriverListItemDriver;
  driverInputControl: UntypedFormControl;
  driverControlErrors: InputError[] = [{ type: 'missing', text: t('A driver is required.') }];
  matcher = errorStateMatcher;

  private trainTypeEquipment: TrainTypeEquipment;
  hardwareEnabled: boolean;
  userFaultEnabled: boolean;

  trainSimPropertiesAll: Map<number, SimPropertyValues> = new Map();
  initialConditionsAllTrains: InitialConditionsTrains;
  currentSelectedTrainSimPropertyValues = signal<TrainSimPropertyValues | undefined>(undefined);
  renderingFlag = false;

  scenarioTrains: ScenarioTrains;

  constructor(
    private readonly consistDataService: ConsistDataService,
    private readonly simPropertiesService: SimPropertiesService,
    private readonly translateService: TranslateService,
    private snackbar: MatSnackBar,
    public dialog: MatDialog,
    private readonly cd: ChangeDetectorRef,
    private readonly registry: Registry
  ) {
    this.hardwareEnabled = this.registry.getBoolean(['sim', 'hardwareStatesConfigurable'], false);
    this.userFaultEnabled = this.registry.getBoolean(['editor', 'scenario', 'trains', 'userFaultsEnabled'], false);
  }

  segmentName: (segmentId: number) => string = x => 'Loading...';

  ngOnInit(): void {
    this.subscriptions.add(this.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      if(this.selectedDriver){
        const translatedSelectedDriver = this.selectedDriver.name ? this.translateService.instant(this.selectedDriver.name): null;
        this.driverInputControl?.setValue(translatedSelectedDriver, quietUpdateOptions);
      }
    }));

    if(this.scenarioEditManager.enforceDriver()) {
      this.driverInputControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      const result = validateMandatoryString(control.value);
      this.emitTrainDetailsUpdated();
      return result;
      });
    } else {
      this.driverInputControl = newOptionalFormControl();
    }
    this.subscriptions.add(this.nameControl.valueChanges.subscribe(s => {
      if (s !== this.train.name) {
        this.emitTrainDetailsUpdated();
        this.scenarioEditManager.updateScenarioTrainName(this.train.id, s);
      }
    }));

    this.subscriptions.add(this.driverList$?.subscribe((driverList: Array<DriverListItemDriver>) => {
      this.driverList = driverList;
      this.updateDriverVisibility();
    }));

    [
      this.offsetControl.valueChanges.pipe(debounceTime(1000)),
     ...[this.segmentControl, this.orientationControl, this.driverControl].map(c => c.valueChanges)
    ].forEach(c => c.subscribe(s => this.publish()));

    this.subscriptions
      .add(this.world$
        .pipe(filter(w => !!w))
        .subscribe(w => {
          // FIXME this gets fired way too often, which may be causing slowdown in the train editor; see scenario-editor.component for more info
          this.world = w;
          this.segmentName = (segmentId): string => w.segmentMap.get(segmentId)?.name;
          this.segments = Array.from(w.segmentMap.values()).map(s => s.id);
        })
      );
      this.subscriptions.add(this.netDef$
        .pipe(filter(n => !!n))
        .subscribe(n => {
          this.netDef = n;
        })
      );
      this.subscriptions.add(this.pathFinder$
        .pipe(filter(p => !!p))
        .subscribe(p => {
          this.pathFinder = p;
        })
      );
      this.subscriptions.add(
        this.scenario$.subscribe(s => {
          this.trainTypeEquipment = s.trainTypeEquipment;
          setTimeout(() => {
            this.initialConditionsAllTrains = cloneDeep(s.initialConditionsTrains);
            const temp = this.initialConditionsAllTrains?.trains?.find(trainElem=> trainElem?.trainNameInScenario === this.train?.name);
            this.currentSelectedTrainSimPropertyValues.set(temp);
            this.renderingFlag = true;
          });
          this.scenarioTrains = s.scenarioTrains;

          this.cd.detectChanges();

        })
      );

    this.updateDriverVisibility();
    this.updateTrainFields();

    // const isDriven = this.train?.driverType === DriverType.HUMAN;
    // if(this.train?.driverType) {
    //   const vehiclesSimProps: Map<string, SimPropertyGroup[]> = cloneDeep(
    //     this.simPropertiesService.getAllVehicleInitialConditionSimProperties(this?.consist?.id, isDriven)
    //   );
    //   const trainSimProp: SimPropertyGroup[] = cloneDeep(
    //     this.simPropertiesService.getConsistTrainInitialConditionSimProperties(this?.consist?.id, isDriven)
    //   );
    // }
    // TODO the call to get all sim properties for the train will be added here once the DBAccess changes are available
  }

  private emitTrainDetailsUpdated(): void {
    this.trainDetailsUpdated.emit();
  }

  updateDriverVisibility(): void {
    this.driverList?.map(d => {
      d.enabled = this.scenarioEditManager.newDriverForScenarioTrainAllowed(this.train.id, d.type).allowed;
    });

    this.cd.detectChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.updateTrainFields();
    if (changes.userConfig && changes.userConfig.currentValue !== changes.userConfig.previousValue) {
      this.updateTrackLocationFields(changes.userConfig.currentValue);
    }
    if (changes.settings || changes.train) {
      this.config = {
        trainName: true,
        icons: {
          findTrain: true,
          moveTrain: true,
          path: true,
          flip: true,
          delete: true
        }
      };

      const sti: ScenarioTrainItem = {scenarioTrainId: this.train.id, consist: this.consist, driverType: this.train.driverType};
      this.dragData = {type: 'train', data: sti};
    }
  }

  updateTrainFields(): void {
    this.driverTypeIcon   = iconForDriverType  (this.train.driverType);
    this.driverTypeColour = colourForDriverType(this.train.driverType);
    this.nameControl.setValue(this.train.name, quietUpdateOptions);

    if (this.train?.driverType) {
      this.selectedDriver = this.driverList?.find(d => {
        if (this.train.driverType === DriverType.HUMAN) {
          return d.type === this.train.driverType;
        }
        return d.name === this.train.driverName;
      });
    } else {
      this.selectedDriver = null;
    }

    const pos = this.train.vehicles[0]?.position;

    setTimeout(() => {
      const translatedDriver = this.train.driverType ? this.translateService.instant(this.train.driverName) : null;
      this.driverControl.setValue(translatedDriver, quietUpdateOptions);
      const translatedSelectedDriver = this.selectedDriver.name ? this.translateService.instant(this.selectedDriver.name): null;
      this.driverInputControl?.setValue(translatedSelectedDriver, quietUpdateOptions);
    });

    if (pos) {
      this.segmentControl.setValue(pos.segmentId,     quietUpdateOptions);
      this.offsetControl .setValue(pos.segmentOffset, quietUpdateOptions);
      this.trackNameControl.setValue(pos?.trackName ?? '',   quietUpdateOptions);
      this.orientationControl.setValue(pos.segmentOrientation === Orientation.ALPHA_TO_BETA ? t('Alpha to Beta') : t('Beta to Alpha'), quietUpdateOptions);
      this.updateUserScaleControls(pos);
      this.updateTrackLocationFields(this.userConfig);
    }

    // TODO Scenario Trains should probably have the consist attached.
    this.consistDataService.data()
      .pipe(takeOneTruthy())
      .subscribe(consists => {
        this.consist = consists.find(c => c.name === this.train.description);
      });
    this.cd.markForCheck();
  }

  private updateTrackLocationFields(userConfig: UserConfig): void {
    const showTrackName = this.trackNameControl.value && !!userConfig.positionFormat.find(pf => pf === 'trackName');
    const showUserScale = !!userConfig.positionFormat.find(pf => pf === 'userScale');
    const showSegOffset = !!userConfig.positionFormat.find(pf => pf === 'segment');
    const config = {
      trackName: {
        show: showTrackName,
        trackNameControl: this.trackNameControl
      },
      userScales: {
        show: showUserScale,
        userScaleControls: this.userScaleControls
      },
      segmentOffset: {
        show: showSegOffset,
        segmentControl: this.segmentControl,
        offsetControl: this.offsetControl
      }
    };
    this.trackLocationConfig = config;
  }

  private updateUserScaleControls(pos: UsefulVehiclePosition): void {
    this.userScaleControls = createUIsForNewValues(pos.userScales ?? [], this.userScaleControls);

    this.userScaleSubs?.unsubscribe();
    this.userScaleSubs = new Subscription();
    this.userScaleControls.forEach(ui =>
      this.userScaleSubs.add(ui.offsetFC.valueChanges.subscribe(v => this.userScaleUpdated(ui.userScale, Number(v)))));
    if (this.trackLocationConfig?.userScales) {
      this.trackLocationConfig.userScales.userScaleControls = this.userScaleControls;
    }
  }

  private userScaleUpdated(original: UserScale, newOffset: number): void {
    const startPos = this.train.vehicles[0]?.position;
    if (startPos && !isNil(startPos.segmentId) && !isNil(startPos.segmentOffset) && !isNil(startPos.segmentOrientation)) {

      const path = this.pathFinder.scanPath({
        segmentId: startPos.segmentId,
        orientation: startPos.segmentOrientation
      });
      const pathSegIds = path.pathSegments.map(s => s.segment.id);

      processUserScaleUpdate(
        pathSegIds, original, newOffset, this.netDef,
        (segOffset: SegOffset) => {
          let orientation = startPos.segmentOrientation;
          const segIndex = path.indexOf(segOffset.segmentId);

          if (segIndex >= 0) {
            const newSegDirection = path.pathSegments[segIndex].direction;
            orientation = startPos.segmentOrientation === Orientation.ALPHA_TO_BETA ? newSegDirection : reverse(newSegDirection);
          }

          this.updateScenarioTrainPosition(this.train.id, segOffset.segmentId, segOffset.offset, orientation);
        },
        () => {
          // FIXME this only happens when user scale is out of range, which we should be able to handle through better data and form validation
          this.updateScenarioTrainPosition(this.train.id, startPos.segmentId, startPos.segmentOffset, startPos.segmentOrientation);
        }
      );
    }
  }

  ngOnDestroy(): void {
    this.userScaleSubs?.unsubscribe();
    this.subscriptions.unsubscribe();
  }

  publish(): void {
    const v0Pos = this.train.vehicles[0].position;

    // Ensure we're not accidentally processing a string (which sometimes comes out of autocompletes).
    const selectedSegId = Number(this.segmentControl.value);
    // segment id of 0 is considerd null (ie, if you click the "x" to reset segment selection)
    if (!selectedSegId) {
      this.offsetControl.setValue(0, {onlySelf: true, emitEvent: false});
    }
    const rawOffset = parseFloat(this.offsetControl.value);
    const selectedOffset = !Number.isNaN(rawOffset) ? rawOffset : 0;
    // Note orientationControl is read only and drivers are handled differently.
    const selectedOrientation = typeof v0Pos.segmentOrientation === 'number'
      ? v0Pos.segmentOrientation : Orientation.ALPHA_TO_BETA;

    if (selectedSegId      !== v0Pos.segmentId
    || selectedOffset      !== v0Pos.segmentOffset
    || selectedOrientation !== v0Pos.segmentOrientation) {
      this.updateScenarioTrainPosition(this.train.id, selectedSegId, selectedOffset, selectedOrientation);
    }
  }

  private updateScenarioTrainPosition(id: number, segmentId: number, offset: number, orientation: Orientation): void {
    if (!this.scenarioEditManager.updateScenarioTrainPosition(this.train.id, segmentId, offset, orientation)) {
      this.offsetError = t('Another Train is at this location.');
    }
  }

  setFavourite(): void {
    this.favourite.emit(this.train);
  }

  setLockOnTrain(): void {
    this.lockOnTrain.emit(this.train);
  }

  setShowTrainPath(): void {
    this.pathTrain.emit(this.train);
  }

  doGoToTrain(): void {
    this.goToTrain.emit(this.train);
  }

  doShowTrain(): void {
    this.showTrain.emit(this.train);
  }

  doChangeOrientation(): void {
    this.changeOrientation.emit(this.train);
  }

  doDeleteTrain(): void {
    this.deleteTrain.emit(this.train);
  }

  selectDriver(driver: DriverListItemDriver): void {
    if (driver) {
      this.setDriver(driver);
    } else {
      this.clearDriver();
    }
    this.updateDriverVisibility();
  }

  displayValue(value: DriverListItemDriver): string {
    return typeof value === 'string' ? value : value?.name;
  }

  valueEnabled(value: DriverListItemDriver): boolean {
    return value.enabled;
  }

  public onDrag(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
    ev.dataTransfer.dropEffect = 'move';
    this.dragging = true;

    const data = extractJSONData<any>(ev.dataTransfer);

    if (isDriverListItemData(data)) {
      const driver = data.driver; // this.draggedDriverItemToDriverType(data);
      const testResult = this.scenarioEditManager.newDriverForScenarioTrainAllowed(this.train.id, driver.type);
      let message: string = testResult.allowed ? t('Set Driver') : t('Cannot set Driver');

      switch (testResult.reason) {
        case 'SIM_TRAIN_LIMIT_REACHED':
          message = t('Cannot include more Simulated Trains.');
          break;
        case 'AUTO_TRAIN_LIMIT_REACHED':
          message = t('Cannot include more Controlled Trains.');
          break;
      }

      this.dragFeedback = {
        allowed: testResult.allowed,
        message
      };
    } else {
      this.dragFeedback = {
        allowed: false,
        message: t('Unknown data type!')
      };
    }
  }

  public onDragEnter(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
    this.dragging = true;
  }

  public onDragLeave(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
    this.dragging = false;
  }

  public onDrop(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
    this.dragging = false;
    const data = extractJSONData<DriverListItem>(ev.dataTransfer);

    if (isDriverListItemData(data)) {
      this.setDriver(data.driver);
    }
    else {
      this.snackbar.open(this.translateService.instant(t('Invalid Data: The item you are trying to add contains invalid information.')), t('Dismiss'));
    }
    this.updateDriverVisibility();
  }

  private setDriver(driver: DriverListItemDriver): void {
    if (!this.driverList?.some(d => d.name === driver.name)) {
      this.snackbar.open(this.translateService.instant(t('Item not found: The item you are trying to add does not exist in the library.')), t('Dismiss'));
    }
    this.selectedDriver = driver;
    // HUMANS MUST REMAIN NAMELESS - ALL HAIL OUR MACHINE OVERLORDS
    // humans are handled by setting the scenarioTrain.driverType (isSimulated) flag instead.
    const name = this.selectedDriver?.type === DriverType.HUMAN ? null : this.selectedDriver?.name;
    this.scenarioEditManager.setDriverForScenarioTrain(this.train.id, this.selectedDriver?.type, name,this.selectedDriver.id, this.selectedDriver.version);
  }

  clearDriver(): void {
    this.scenarioEditManager.setDriverForScenarioTrain(this.train.id, null, null,'','');
  }

  openHardwareInitialStatesDialog(): void {
    const dialogRef = this.dialog.open<TrainHardwareInitialStatesDialogComponent, TrainHardwareInitialStatesDialogData, TrainHardwareEquipmentTypeData[]>(
      TrainHardwareInitialStatesDialogComponent,
      {
        disableClose: true,
        minHeight: '60%',
        minWidth: '30%',
        data: {
          train: this.train,
          trainTypeEquipment: this.trainTypeEquipment
        }
      }
    );

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const config: TrainTypeEquipment = {
          scenarioTrainId: this.train.id,
          equipmentTypes: {
            equipmentType: result.map(data => ({
              displayName: data.displayName,
              equipmentState: {
                stateName: data.selectedState.stateName,
                displayName: data.selectedState.displayName
              },
              name: data.name
            }))
          }
        };
        this.scenarioEditManager.updateHardwareStatesConfig(config);
      }
    });
  }

  openInitialConditionsDialog(): void {
    this.renderingFlag = false;

    const dialogRef = this.dialog.open<InitalConditionsDialogComponent, InitalConditionsDialogData, TrainSimPropertyValues>(InitalConditionsDialogComponent, {
      disableClose: true,
      minHeight: '60%',
      minWidth: '1080px',
      data: {
        train: { consistId: this.consist?.id, scenarioTrainName: this.train.description },
        isDriven: this.train.driverType===this.DRIVER_TYPE_HUMAN ? true : false,
        trainInitialConditions: this.currentSelectedTrainSimPropertyValues()
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === null) {
        this.reset(); // reset all button clicked
      }
      else if (result) {
        result.trainNameInScenario = this?.train?.name;

        // Ensure base object and array exist
        if (!this.initialConditionsAllTrains) {
          this.initialConditionsAllTrains = { trains: [] };
        } else if (!this.initialConditionsAllTrains.trains) {
          this.initialConditionsAllTrains.trains = [];
        }

        this.updateTrainSimProps(result); // Modified the this.initialConditionsAllTrains

        this.currentSelectedTrainSimPropertyValues.set(result);
        this.scenarioEditManager.updateInitialConditionsConfig(this.initialConditionsAllTrains);
      }
      this.renderingFlag = true;
    });
  }

  private updateTrainSimProps(result: TrainSimPropertyValues): void {
    const newTrains = [...(this.initialConditionsAllTrains?.trains ?? [])];
    const index = newTrains.findIndex(train => train.trainNameInScenario === result.trainNameInScenario);

    if (index !== -1) {
      newTrains.splice(index, 1, result);
    } else {
      newTrains.push(result);
    }

    this.initialConditionsAllTrains = {
      trains: newTrains
    };
  }


  deleteInitialConditions(simPropertyValues: TrainSimPropertyValues): void {
    this.currentSelectedTrainSimPropertyValues.set(simPropertyValues);

    this.updateTrainSimProps(this.currentSelectedTrainSimPropertyValues());
    this.scenarioEditManager.updateInitialConditionsConfig(this.initialConditionsAllTrains);
  }

  reset(): void {

    const title = t('Reset All Initial Conditions');
    const content = t('Are you sure you want to reset all initial conditions? <br> This action cannot be undone.');
    const buttonText = t('Reset');
    deleteDialog(title, content, this.dialog, buttonText).subscribe(dialogResult => {
      if (dialogResult) {

        const current = this.currentSelectedTrainSimPropertyValues();
        const emptyTrain: TrainSimPropertyValues = {
          ...current,
          trainSimPropertyValues: {simPropertyValue: []},
          vehicleProps: []
        };
        this.currentSelectedTrainSimPropertyValues.set(emptyTrain);
        this.updateTrainSimProps(emptyTrain);

        this.scenarioEditManager.updateInitialConditionsConfig(this.initialConditionsAllTrains);
      }
    });
  }
}
