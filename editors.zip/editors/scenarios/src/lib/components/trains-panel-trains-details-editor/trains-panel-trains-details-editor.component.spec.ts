/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';

import { DataAccessServiceDataKey } from '@oksygen-common-libraries/data-access/testing';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { UnitsUnitPipe } from '@oksygen-sim-core-libraries/components-services/measurement-units';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { DragDropZoneHighlightComponent, IconFieldComponent } from '@oksygen-sim-train-libraries/components-services/common';
import { FaultItemComponent, FaultsPanelComponent } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import {
  configureSimTrainTestingModule,
  createTestTrainRestData,
  createTestTrainTypeRestData
} from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainTrainsModule, TrainCardComponent } from '@oksygen-sim-train-libraries/components-services/trains';

import { ScenarioEditService } from '../../services/scenario-edit.service';
import { TrainsPanelTrainsDetailsEditorComponent } from './trains-panel-trains-details-editor.component';

describe('TrainsPanelTrainsDetailsEditorComponent', () => {
  let component: TrainsPanelTrainsDetailsEditorComponent;
  let fixture: ComponentFixture<TrainsPanelTrainsDetailsEditorComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule(
      {
        imports: [OksygenSimTrainTrainsModule, IconFieldComponent],
        declarations: [
          TrainsPanelTrainsDetailsEditorComponent,
          TrainCardComponent,
          FaultsPanelComponent,
          FaultItemComponent,
          DragDropZoneHighlightComponent,
          UnitsUnitPipe
        ],
        providers: [
          {
            provide: ScenarioEditService,
            useValue: {
              updateScenarioTrainPosition: (id: number, segmentId: number, offset: number, orientation: Orientation): void => {}
            }
          }
        ]
      },
      undefined,
      new Map<DataAccessServiceDataKey, any>([
        [{ query: 'get_train_details' }, createTestTrainRestData()],
        [{ query: 'get_train_types' }, createTestTrainTypeRestData()]
      ])
    ).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainsPanelTrainsDetailsEditorComponent);
    const editService = TestBed.inject(ScenarioEditService);

    component = fixture.componentInstance;
    component.world$ = new BehaviorSubject(null);
    component.train = {
      id: 1,
      name: 'Test',
      description: 'Test',
      driverType: DriverType.HUMAN,
      driverName: DriverType.HUMAN,
      driverId:'',
      trainType: 'Test',
      vehicles: []
    };
    component.scenarioEditManager = editService.newManager('abcd');
    fixture.detectChanges();
  });

  // FIXME Fails due to No value accessor for form control with unspecified name attribute
  // caused by the autocomplete field. No idea why, don't have time to resolve ATM :(
  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
