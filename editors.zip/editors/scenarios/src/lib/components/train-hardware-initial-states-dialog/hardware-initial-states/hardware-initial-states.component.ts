/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { allFilterTypesMatch, Filter, filterMatches, SelectedFilterArray, Sorter, SorterPipe } from '@oksygen-common-libraries/material/components';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { EquipmentType } from '@oksygen-sim-train-libraries/components-services/trains';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TrainHardwareEquipmentTypeData } from '../../../models/train-hardware-initial-states.model';

export enum HardwareInitialStatesFilterType {
  NAME = 'search',
  ENABLED = 'switch_on',
  DISABLED = 'switch_off'
}

export interface HardwareInitialStatesUiState {
  filters: {
    search: string;
    selectedFilters: SelectedFilterArray<HardwareInitialStatesFilterType>;
  };
}

@Component({
  selector: 'oksygen-hardware-initial-states',
  templateUrl: './hardware-initial-states.component.html',
  styleUrls: ['./hardware-initial-states.component.scss']
})
export class HardwareInitialStatesComponent implements OnInit, OnChanges {
  readonly EMPTY_FILTERS = new SelectedFilterArray<HardwareInitialStatesFilterType>();

  @Input() equipmentType!: TrainHardwareEquipmentTypeData[];
  @Output() readonly dataChange = new EventEmitter<TrainHardwareEquipmentTypeData[]>();

  // The current state of the UI, "persistent".
  state: HardwareInitialStatesUiState;


  // The filtered rules, grouped by category.
  filteredStates: EquipmentType[] = [];

  private sorterPipe = new SorterPipe();
  sorter = new Sorter<EquipmentType>();
  displayedColumns = ['components', 'states'];
  constructor(private uiStateModelManager: UiStateModelManager) {
    this.sorter.sortFunction = (c, a, b): number => a?.displayName?.localeCompare(b?.displayName);
  }
  textToFilter = (text: string): Filter<string> => new Filter(HardwareInitialStatesFilterType.NAME, text);

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.equipmentType && changes.equipmentType.currentValue !== changes.equipmentType.previousValue) {
      this.applyFilters();
    }
  }

  ngOnInit(): void {
    this.state = this.retrieveUiState();
    this.applyFilters();
  }

  /**
   * Called when the user updates the text in the search bar.
   * @param text The text to filter the rules by.
   */
  onCurrentValueUpdate(text: string): void {
    this.state.filters.search = text;
    this.applyFilters();
  }

  /**
   * Called when the user clicks on the "Show All" button. Clears every filters.
   */
  clearFilters(): void {
    this.state.filters.search = '';
    this.state.filters.selectedFilters = new SelectedFilterArray<HardwareInitialStatesFilterType>();
    this.applyFilters();
  }
  /**
   * Called when the user clicks on the "Sort" button. Toggles the sort order internally, so we just need to apply filters again to refresh the UI.
   */
  sortToggled(): void {
    this.applyFilters();
  }

  /**
   * Apply the filters to the given blocks. First check for the selected filters, then the search bar.
   * @param blocks The blocks to filter.
   * @returns The filtered blocks, grouped by category in a Map, with category as the key.
   */
  public applyFilters(): void {
    if (!this.equipmentType) {
      return;
    }

    const filter = this.state?.filters;
    const searchText = filter?.search || null;

    let filteredStates = this.equipmentType.filter(equipmentType => {
      const names = [equipmentType.displayName];

      if (
        !allFilterTypesMatch(
          [
            { t: HardwareInitialStatesFilterType.NAME, v: names },
            { t: HardwareInitialStatesFilterType.ENABLED, v: equipmentType.enabled },
            { t: HardwareInitialStatesFilterType.DISABLED, v: !equipmentType.enabled }
          ],
          filter?.selectedFilters ?? this.EMPTY_FILTERS
        )
      ) {
        return false;
      }

      if (!filterMatches(names, searchText)) {
        return false;
      }

      return true;
    });

    filteredStates = this.sorterPipe.transform(filteredStates, this.sorter, this.sorter.refresh);

    // Deep copy (1 level deep), that way cdkVirtualFor tracking understands there's a change.
    this.filteredStates = filteredStates.map(m => ({ ...m }));
  }

  /**
   * ! This means that if you close the tab and create a new one, the state will be persisted so you'll have the same filters as before.
   * ! Might be a good thing, might not.
   * @returns The current state of the UI, persistent.
   */
  private retrieveUiState(): HardwareInitialStatesUiState {
    return this.uiStateModelManager.getStateModel<any>('TrainHardwareInitialStatesDialogComponent', () => ({
      filters: {
        search: '',
        selectedFilters: [],
        groups: []
      }
    }));
  }

  toggleChange(element: TrainHardwareEquipmentTypeData): void {
    if (!element.enabled) {
      element.selectedState = null; // Clear selection when toggle is disabled
    }
    this.updateData();
  }

  updateData(): void {
    this.filteredStates.forEach(fStates => {
      const targetItem = this.equipmentType.find(item => item.name === fStates.name);
      if (targetItem) {
        Object.assign(targetItem, fStates); // Update target item with source item properties
      }
    });
    this.dataChange.emit(this.equipmentType);
  }

  filterEnabledStates(): void {
    this.state.filters.selectedFilters.push(new Filter(HardwareInitialStatesFilterType.ENABLED, true, t('Enabled')));
    this.applyFilters();
  }

  filterDisabledStates(): void {
    this.state.filters.selectedFilters.push(new Filter(HardwareInitialStatesFilterType.DISABLED, true, t('Disabled')));
    this.applyFilters();
  }
}
