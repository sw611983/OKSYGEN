/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { EquipmentPreset, TrainTypeService } from '@oksygen-sim-train-libraries/components-services/trains';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { TrainHardwareEquipmentTypeData, TrainHardwareInitialStatesDialogData } from '../../models/train-hardware-initial-states.model';
import { isNil } from 'lodash';

@Component({
  selector: 'oksygen-train-hardware-initial-states-dialog',
  templateUrl: './train-hardware-initial-states-dialog.component.html',
  styleUrls: ['./train-hardware-initial-states-dialog.component.scss']
})
export class TrainHardwareInitialStatesDialogComponent implements OnInit, OnDestroy {
  readonly DEFAULT_PRESET: EquipmentPreset = { displayName: t('None'), equipmentConfig: {} as any, name: 'none' };

  equipmentTypes: TrainHardwareEquipmentTypeData[] = [];
  equipmentPresets: EquipmentPreset[] = [];

  isClearDisabled = true;
  isSetDisabled = true;

  private trainTypeSub: Subscription;

  selectedPreset: EquipmentPreset = this.DEFAULT_PRESET;

  constructor(
    public dialogRef: MatDialogRef<TrainHardwareInitialStatesDialogComponent, TrainHardwareEquipmentTypeData[]>,
    @Inject(MAT_DIALOG_DATA) public launchContext: TrainHardwareInitialStatesDialogData,
    private trainTypeService: TrainTypeService
  ) {
    this.equipmentPresets.push(this.DEFAULT_PRESET);
  }

  ngOnInit(): void {
    this.trainTypeSub = this.trainTypeService.data().subscribe(tt => {
      const trainTypes = Array.from(tt.values());
      if (trainTypes.length > 0) {
        const trainType = trainTypes.find(ttype => ttype.name === this.launchContext.train.trainType);
        if (trainType) {
          trainType?.equipmentType.forEach(et => {
            const selectedState =
              this.launchContext?.trainTypeEquipment?.scenarioTrainId === this.launchContext?.train?.id
                ? this.launchContext?.trainTypeEquipment?.equipmentTypes?.equipmentType?.find(tte => tte.name === et.name)?.equipmentState ?? null
                : null;
            this.equipmentTypes.push({
              displayName: et.displayName,
              equipmentState: et.equipmentState,
              name: et.name,
              enabled: !!selectedState,
              selectedState: !isNil(selectedState) ? et.equipmentState.find(equipType => equipType.stateName === selectedState.stateName) : null
            });
          });
          this.isClearDisabled = !this.equipmentTypes.some(element => element.enabled);
          trainType?.equipmentPreset.forEach(et => {
            this.equipmentPresets.push({ displayName: et.displayName, equipmentConfig: et.equipmentConfig, name: et.name });
          });
        }
      }
    });
  }

  public onSetClick(): void {
    const enabledData = this.equipmentTypes.filter(element => element.enabled && !!element.selectedState);
    this.dialogRef.close(enabledData);
  }

  public onCancelClick(): void {
    this.dialogRef.close();
  }

  public clearSelections(): void {
    this.equipmentTypes.forEach(element => {
      element.enabled = false;
      element.selectedState = null;
    });
    this.equipmentTypes = [...this.equipmentTypes];
    this.isClearDisabled = true;
    this.isSetDisabled = true;
  }

  public onDataChange(updatedData: TrainHardwareEquipmentTypeData[]): void {
    this.equipmentTypes = updatedData;
    this.updateButtonStates();
  }

  public updatePresetSelection(): void {
    this.clearSelections();
    if (this.selectedPreset.name !== this.DEFAULT_PRESET.name) {
      this.selectedPreset.equipmentConfig.forEach(ec => {
        const selectedState = this.equipmentTypes.find(et => ec.name === et.name);
        if (selectedState) {
          Object.assign(selectedState, { selectedState: ec.equipmentState, enabled: true });
          this.equipmentTypes = [...this.equipmentTypes];
        }
      });
    }
    this.updateButtonStates();
  }

  private updateButtonStates(): void {
    this.isClearDisabled = !this.equipmentTypes.some(element => element.enabled);
    this.isSetDisabled =
      this.equipmentTypes.filter(element => element.enabled).length > 0
        ? this.equipmentTypes.some(element => element.enabled && element.selectedState === null)
        : true;
  }

  ngOnDestroy(): void {
    this.trainTypeSub?.unsubscribe();
  }
}
