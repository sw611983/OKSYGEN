/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { TrainHardwareInitialStatesDialogComponent } from './train-hardware-initial-states-dialog.component';

describe('TrainHardwareInitialStatesDialogComponent', () => {
  let component: TrainHardwareInitialStatesDialogComponent;
  let fixture: ComponentFixture<TrainHardwareInitialStatesDialogComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [TrainHardwareInitialStatesDialogComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainHardwareInitialStatesDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
