/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, Inject, input, Optional, output, signal } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';
import { Observable, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { getObjectRenderInfo, ObjectLabel } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { filterTruthy } from '@oksygen-common-libraries/common';
import { defaultImages, GlobalImageStoreKey, ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import {
  IObjectTrackAtlasManager,
  isObjectDataMapContext,
  OBJECT_MAP_RENDERER_TOKEN,
  ObjectDataMapContext,
  ObjectMapRenderer
} from '@oksygen-sim-train-libraries/components-services/maps';
import { getDisplayObject, ObjectContainer, SimObject } from '@oksygen-sim-train-libraries/components-services/objects/data';

/**
 * Changing the total height of this component impacts the calculation done in FavouritesPanelComponent
 * Please verify that this calculation is still appropriate if changing this component
 */
@Component({
  selector: 'oksygen-dialog-objects-list-item',
  templateUrl: './objects-list-item.component.html',
  styleUrls: ['./objects-list-item.component.scss']
})
export class ObjectsDialogListItemComponent {
  object = input.required<ObjectContainer>();
  selectedObjectId = input.required<number>();
  objectContext = input.required<Observable<ObjectDataMapContext<any, IObjectTrackAtlasManager>>>();

  iconUri = signal<string | SafeUrl>(defaultImages.object);
  iconLabel = signal<ObjectLabel>(null);
  isObjectSelected = false;
  public readonly objectSelected = output<boolean>();

  private displayObject: SimObject;

  constructor(
    private readonly imageService: ImageService,
    @Inject(OBJECT_MAP_RENDERER_TOKEN) @Optional() protected overrideObjectRenderer?: ObjectMapRenderer
  ) {
    effect(
      onCleanup => {
        if (this.object()) {
          this.displayObject = getDisplayObject(this.object());
        }
        const contextSub = this.objectContext()
          .pipe(
            filterTruthy(),
            switchMap(m => {
              if (isObjectDataMapContext(m)) {
                this.updateIcon(this.displayObject);
                return m.objects.getObject$(this.displayObject.id);
              }

              return of(null);
            }),
            filterTruthy()
          )
          .subscribe(f => {
            // Note that we can't use this.displayObject here, as it may not have the latest state yet.
            this.updateIcon(f);
          });

        onCleanup(() => {
          contextSub?.unsubscribe();
        });
      },
      {
        allowSignalWrites: true
      }
    );
  }

  onObjectSelect(): void {
    this.objectSelected.emit(true);
    this.isObjectSelected = !this.isObjectSelected;
  }

  private updateIcon(object: SimObject): void {
    this.iconLabel.set(null);

    if (object?.objectType?.mapOverrides) {
      const overrides = getObjectRenderInfo(object, object.objectType?.defaultIcons?.big.id);
      if (overrides.label) {
        this.iconLabel.set(overrides.label);
      }
      const image = this.imageService.getGlobalImage(GlobalImageStoreKey.SMALL, `${overrides.icon}`);
      this.imageService.loadIconImageObservable(image, defaultImages.object).subscribe(uri => {
        this.iconUri.set(uri);
      });
      return;
    }

    if (this.overrideObjectRenderer && object?.objectType?.mapRenderer) {
      const renderer = this.overrideObjectRenderer.renderers.get(object.objectType.mapRenderer);

      if (renderer) {
        const overrides = renderer(object as any);
        if (overrides.label) {
          this.iconLabel.set({ text: overrides.label, colour: '#000000', yOffset: 0 });
        }

        if (overrides.icon) {
          const image = this.imageService.getGlobalImage(GlobalImageStoreKey.SMALL, `${overrides.icon}`);
          this.imageService.loadIconImageObservable(image, defaultImages.object).subscribe(uri => {
            this.iconUri.set(uri);
          });
          return;
        }
      }
    }

    const img = object.selectedIcon?.big ?? object.objectType?.defaultIcons?.big;
    this.imageService.loadIconImageObservable(img, defaultImages.object).subscribe(uri => {
      this.iconUri.set(uri);
    });
  }
}
