/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, EventEmitter, input, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { cloneDeep } from 'lodash';
import { debounceTime, Observable, Subscription } from 'rxjs';
import { first, switchMap } from 'rxjs/operators';

import { filterTruthy, takeOneTruthy } from '@oksygen-common-libraries/common';
import { newFormControl, newOptionalFormControl, UpdateOn } from '@oksygen-common-libraries/material/components';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { ZoomLevel } from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockPropertyTypeEnum, RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';
import { SessionContext, SessionContextSupplier } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

import { ScenarioEditManager } from '../../../services/scenario-edit.manager';
import { ScenarioRuleBlockItem, ScenarioRuleItem } from '../../../models/scenario-rule-item.model';
import { toSignal } from '@angular/core/rxjs-interop';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

// FIXME name / description handling copied directly from MultimediaPanelMulimediaEditorComponent.

@Component({
  selector: 'oksygen-scenario-rules-edit',
  templateUrl: './scenario-rules-edit.component.html',
  styleUrls: ['./scenario-rules-edit.component.scss']
})
export class ScenarioRulesEditComponent implements OnInit, OnDestroy {
  rule = input.required<ScenarioRuleItem>();
  @Input() otherRuleNames: string[];
  @Input() scenarioEditManager: ScenarioEditManager;
  // eslint-disable-next-line @angular-eslint/no-output-on-prefix
  @Output() readonly onBack: EventEmitter<void> = new EventEmitter();
  // eslint-disable-next-line @angular-eslint/no-output-on-prefix
  @Output() readonly onDelete: EventEmitter<void> = new EventEmitter();
  // eslint-disable-next-line @angular-eslint/no-output-on-prefix
  @Output() readonly onDuplicate: EventEmitter<void> = new EventEmitter();

  selectingFeature: any;
  isValid = false;
  isLatest = false;
  ruleExists = false;
  nameControl: UntypedFormControl;
  descriptionControl: UntypedFormControl;
  ruleTemplate: RuleTemplate;

  nameSubscription = new Subscription();
  descriptionSubscription = new Subscription();
  objectSubscription = new Subscription();

  uiRule$: Observable<ScenarioRuleItem>;
  ruleBlocks: ScenarioRuleBlockItem[];
  readonly duplicateName = 'duplicateName';
  private nameTimerHandle: any;
  private descriptionTimerHandle: any;
  private readonly formDebounceTime = 750;

  objects: ObjectContainer[] = [];

  constructor(private contextSupplier: SessionContextSupplier, private translateService: TranslateService) {
    this.nameControl = newFormControl(UpdateOn.CHANGE, c => {
      if (this.otherRuleNames?.includes(c.value)) {
        return { [this.duplicateName]: true };
      }
      return null;
    });
    this.descriptionControl = newOptionalFormControl();
    const onLangChange = toSignal(translateService.onLangChange);
    effect(() => {
      const rule = this.rule();
      onLangChange(); // triggers re-run on language change
      if (rule) {
        this.initialiseRule(rule);
      }
    });
  }

  ngOnInit(): void {
    this.nameSubscription = this.nameControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(() => {
      // the name has changed, we are going to wait 1 second before saving the change
      // if another change occurs during this time, reset the timer.
      this.clearNameTimeoutHandle();
      this.nameTimerHandle = setTimeout(() => this.updateName(), 1000);
    });
    this.descriptionSubscription = this.descriptionControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(() => {
      this.clearDescriptionTimeoutHandle();
      this.descriptionTimerHandle = setTimeout(() => this.updateDescription(), 1000);
    });
    this.objectSubscription = this.contextSupplier
    .currentContext$()
    .pipe(
      filterTruthy(),
      switchMap(m => m.objects.data()),
      filterTruthy()
    )
    .subscribe(objs => {
      this.objects = objs;
    });
  }

  ngOnDestroy(): void {
    this.nameSubscription.unsubscribe();
    if (this.nameTimerHandle) {
      // make sure we capture any name change
      this.updateName();
    }
    this.descriptionSubscription.unsubscribe();
    if (this.descriptionTimerHandle) {
      // make sure we capture any description change
      this.updateDescription();
    }
    this.objectSubscription?.unsubscribe();
  }

  initialiseRule(rule: ScenarioRuleItem): void {
    this.nameControl.setValue(rule.scenarioRule.displayName || '');
    this.descriptionControl.setValue(rule.scenarioRule.description || '');
    this.ruleBlocks = rule.getBlocks();
    this.ruleTemplate = rule.getTemplate();
    this.isLatest = rule.isLatest();
    this.ruleExists = !!this.ruleTemplate;
    this.calculateValidity();
  }

  identifyRuleBlock(index: number, ruleBlock: ScenarioRuleBlockItem): number | string {
    return `${ruleBlock.ruleBlock.name}_${ruleBlock.templateBlock.id}`;
  }

  favouriteClick(event: Event): void {
    event.stopPropagation();
  }

  duplicateClick(event: Event): void {
    event.stopPropagation();
    this.onDuplicate.emit();
    this.onBack.emit();
  }

  deleteClick(event: Event): void {
    event.stopPropagation();
    this.onDelete.emit();
  }

  changeActive(event: MatSlideToggleChange): void {
    this.scenarioEditManager.updateScenarioRuleActive(this.rule().scenarioRule.id, event.checked);
  }

  onPropertyUpdate(block: ScenarioRuleBlockItem, update: { propertyName: string; value: string | number | boolean }): void {
    const id = this.rule().scenarioRule.id;
    block.setProperty(update.propertyName, update.value);
    const blockClone = cloneDeep(block.scenarioBlock);
    this.scenarioEditManager.updateScenarioRuleBlock(id, blockClone);
  }

  updateName(): void {
    this.nameControl.updateValueAndValidity();
    if (!this.nameControl.hasError(this.duplicateName)) {
      const name: string = this.nameControl.value;
      if (name !== this.rule().scenarioRule.displayName) {
        this.scenarioEditManager.updateScenarioRuleName(this.rule().scenarioRule.id, name);
      }
    }
    this.calculateValidity();
    this.clearNameTimeoutHandle();
  }

  updateDescription(): void {
    this.descriptionControl.updateValueAndValidity();
    const description: string = this.descriptionControl.value;
    if (description !== this.rule().scenarioRule.description) {
      this.scenarioEditManager.updateScenarioRuleDescription(this.rule().scenarioRule.id, description);
    }
    this.calculateValidity();
    this.clearDescriptionTimeoutHandle();
  }

  clearNameTimeoutHandle(): void {
    if (this.nameTimerHandle) {
      clearTimeout(this.nameTimerHandle);
      this.nameTimerHandle = null;
    }
  }

  clearDescriptionTimeoutHandle(): void {
    if (this.descriptionTimerHandle) {
      clearTimeout(this.descriptionTimerHandle);
      this.descriptionTimerHandle = null;
    }
  }

  /**
   * Sets whether this block is valid or not.
   * A valid block is one that has all it's properties filled out.
   */
  calculateValidity(): void {
    if (!this.nameControl.valid || !this.descriptionControl.valid) { this.isValid = false; return; }
    for (const block of this.ruleBlocks) {
      const isValidBlock = this.isBlockValid(block);
      if (!isValidBlock) { this.isValid = false; return; }
    }
    this.isValid = true;
  }

  /**
   * Currently a block is considered valid if all it's properties are not-null.
   * This means that default values are acceptable.
   *
   * @param block the block to check
   */
  private isBlockValid(block: ScenarioRuleBlockItem): boolean {
    return block.isValid();
  }

  locateItem(item: { name: string; type: string }): void {
    if (item?.type === RuleBlockPropertyTypeEnum.TRAIN_ID) {
      this.scenarioEditManager.context.trains
        .data()
        .pipe(first())
        .subscribe(trains => {
          const locateTrain = trains.find(train => train.name === item.name);
          if (locateTrain) {
            this.locate(locateTrain?.vehicles?.[0]?.position?.lnglat?.[0]);
          }
        });
    } else if (item?.type === RuleBlockPropertyTypeEnum.FEATURE_NAME) {
      this.scenarioEditManager.context.objects
        .data()
        .pipe(first())
        .subscribe(objects => {
          const locateObject = objects.find(object => object.name === item.name);
          if (locateObject) {
            this.locate(locateObject?.location?.lnglat);
          }
        });
    }
  }

  private locate(location: LngLatCoord): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy<SessionContext>(undefined, 200), first())
      .subscribe(m => {
        m.map.mapGoto(location, ZoomLevel.STATION);
      });
  }
}
