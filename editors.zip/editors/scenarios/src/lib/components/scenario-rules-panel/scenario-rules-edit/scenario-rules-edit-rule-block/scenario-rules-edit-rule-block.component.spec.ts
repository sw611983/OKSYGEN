/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { ScenarioRulesEditRuleBlockComponent } from './scenario-rules-edit-rule-block.component';
import { DragDropZoneHighlightComponent } from '@oksygen-sim-train-libraries/components-services/common';

describe('ScenarioRulesEditRuleBlockComponent', () => {
  let component: ScenarioRulesEditRuleBlockComponent;
  let fixture: ComponentFixture<ScenarioRulesEditRuleBlockComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [ScenarioRulesEditRuleBlockComponent, DragDropZoneHighlightComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioRulesEditRuleBlockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
