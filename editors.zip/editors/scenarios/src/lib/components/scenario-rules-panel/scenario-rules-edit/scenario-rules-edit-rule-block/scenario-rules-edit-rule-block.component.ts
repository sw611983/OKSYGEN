/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { AbstractControl, UntypedFormControl, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { FloatLabelType, MatFormFieldAppearance } from '@angular/material/form-field';
import { SafeUrl } from '@angular/platform-browser';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { map, Subscription, switchMap } from 'rxjs';

import { DragFeedback, extractJSONData, takeOneTruthy } from '@oksygen-common-libraries/common';
import { AutocompleteInputType } from '@oksygen-common-libraries/material/components';
import { defaultImages, ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import { getMultimediaId, isMultimediaNameData } from '@oksygen-sim-train-libraries/components-services/multimedia';
import { getObjectName, isObjectNameData, ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockNames, RuleBlockPropertyNameEnum, RuleBlockPropertyTypeEnum } from '@oksygen-sim-train-libraries/components-services/rules';
import { ConsistDataService, getTrainId, isTrainIdData } from '@oksygen-sim-train-libraries/components-services/trains';
import { isNil } from 'lodash';
import { SessionContextSupplier } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { MatDialog } from '@angular/material/dialog';
import {
  SimPropertiesDialogComponent,
  SimPropertiesDialogData,
  SimProperty,
  SimPropertyState
} from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { ScenarioRulePropertyItem, ScenarioRuleBlockItem } from '../../../../models/scenario-rule-item.model';
import { ObjectDialogComponent } from './object-dialog/object-dialog.component';
import { ObjectDataMapContextSupplier } from '@oksygen-sim-train-libraries/components-services/maps';

/**
 * Helper class only for use here used for managing rule properties.
 */
class BlockProperty extends ScenarioRulePropertyItem {
  formControl?: UntypedFormControl;
  inputFormControl?: UntypedFormControl;
  subscription?: Subscription;
}

interface SimPropertyStateIconAssoc extends SimPropertyState {
  /** state icon to be displayed */
  icon?: string | SafeUrl;
}

// FIXME - selection list should not be filtered based on what is currently typed in

@Component({
  selector: 'oksygen-scenario-rules-edit-rule-block',
  templateUrl: './scenario-rules-edit-rule-block.component.html',
  styleUrls: ['./scenario-rules-edit-rule-block.component.scss']
})
export class ScenarioRulesEditRuleBlockComponent implements OnDestroy, OnChanges {
  /**
   * Scenario Rule block to edit.
   */
  @Input() block: ScenarioRuleBlockItem;
  @Input() objects: ObjectContainer[];

  /**
   * Emit when one of this blocks properties has been updated.
   * You almost definately don't want to use the propertyName / value here -
   * There is complex logic behind the scenes working out what the property name is.
   */
  @Output() readonly propertyUpdated: EventEmitter<{ propertyName: string; value: string | number | boolean }> = new EventEmitter();
  @Output() readonly locateRuleItem: EventEmitter<{ name: string; type: string }> = new EventEmitter();

  readonly TRAIN_ID = RuleBlockPropertyTypeEnum.TRAIN_ID;
  readonly FEATURE_NAME = RuleBlockPropertyTypeEnum.FEATURE_NAME;
  readonly FEATURE_STATE = RuleBlockPropertyTypeEnum.FEATURE_STATE;
  readonly FEATURE_ID = RuleBlockPropertyTypeEnum.FEATURE_ID;

  readonly VEHICLE_PROPERTY = RuleBlockPropertyNameEnum.VEHICLE_PROPERTY;
  readonly TRAIN_PROPERTY = RuleBlockPropertyNameEnum.TRAIN_PROPERTY;

  /** UI list of properties as supplied by block, with some component specific fields appended. */
  properties: BlockProperty[] = [];
  // styling for material inputs
  autoCompleteType = AutocompleteInputType.FORM_FIELD;
  appearance: MatFormFieldAppearance = 'outline';
  floatLabel: FloatLabelType = 'always';
  sortBy: (a: SimPropertyState, b: SimPropertyState) => number;
  dragging = false;
  dragFeedback: DragFeedback = { allowed: false, message: '' };
  subscription = new Subscription(); // master subscription
  translate: TranslateService;
  private objectBlockProperty: BlockProperty = null;
  private trainBlockProperty: BlockProperty = null;
  private multimediaBlockProperty: BlockProperty = null;
  private vehicleIndexBlockProperty: BlockProperty = null;
  selectedObj = false;
  constructor(
    translateService: TranslateService,
    private imageService: ImageService,
    private consistDataService: ConsistDataService,
    private contextSupplier: SessionContextSupplier,
    private dialog: MatDialog,
    private objContextSupplier: ObjectDataMapContextSupplier
  ) {
    this.sortBy = (a: SimPropertyState, b: SimPropertyState): number => {
      // TODO need to make our options for sorting shared across everything; see INTOSC-7244
      // Note that sensible settings for these options are very closely related to the language being used.
      const sortingOptions: Intl.CollatorOptions = { sensitivity: 'base', numeric: true };
      return a.displayName.localeCompare(b.displayName, this.translate.currentLocaleString, sortingOptions);
    };
    this.translate = translateService;
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.block && changes.block.currentValue !== changes.block.previousValue && this.objects.length > 0) {
      this.initialiseBlock(changes.block.currentValue);
    }
  }

  initialiseBlock(block: ScenarioRuleBlockItem): void {
    // add + update properties
    block.properties?.forEach(property => {
      const existingProperty = this.properties.find(cp => cp.type === property.type);
      // need to do this or every update will re-create the form control
      if (existingProperty) {
        this.updateProperty(property, existingProperty);
      } else {
        this.addProperty(property);
      }
    });
    // delete any properties (this is usually when it's name has changed)
    for (let i = this.properties.length - 1; i >= 0; i--) {
      // reverse iteration as deleting
      const property = this.properties[i];
      const propertyShouldExist = !!block.properties.find(p => p.type === property.type);
      if (!propertyShouldExist) {
        property.subscription?.unsubscribe();
        this.subscription.remove(property.subscription);
        this.properties.splice(i, 1);
      }
    }

    this.objectBlockProperty = this.properties.find(cp => cp.type === RuleBlockPropertyNameEnum.FEATURE_NAME);
    this.trainBlockProperty = this.properties.find(cp => cp.type === RuleBlockPropertyNameEnum.TRAIN_ID);
    this.multimediaBlockProperty = this.properties.find(cp => cp.type === RuleBlockPropertyNameEnum.MULTIMEDIA_NAME);
    this.vehicleIndexBlockProperty = this.properties.find(cp => cp.type === RuleBlockPropertyNameEnum.VEHICLE_INDEX);
  }

  async addProperty(property: ScenarioRulePropertyItem): Promise<BlockProperty> {
    const prop: BlockProperty = new BlockProperty(property);
    if (
      this.block.templateBlock.blockType === RuleBlockNames.FEATURE_STATE &&
      this.block.properties[0]?.value &&
      prop?.allowedValues &&
      prop.type === RuleBlockPropertyNameEnum.STATE
    ) {
      await this.updateIcon(prop.allowedValues.displayedValues);
    }
    const value = property.allowedValues?.displayedValues?.find(v => v.value === property.value) ?? property.value;
    const control = new UntypedFormControl(value);

    if (prop.allowedValues?.type !== 'dropdown') {
      // if it's not a drop down, we want the validators on the control
      control.setValidators(this.propertyValueValidator(property));
    } else {
      control.setValidators(Validators.required); // this is for simple inputs
      const inputControl = new UntypedFormControl(value);
      inputControl.setValidators(this.propertyValueValidator(property));
      prop.inputFormControl = inputControl;
      prop.inputFormControl.markAsTouched(); // we want to show error immediately if blank
      prop.inputFormControl.updateValueAndValidity({ emitEvent: false, onlySelf: true });
    }

    prop.formControl = control;
    prop.formControl.markAsTouched();

    // Wire up freeform text inputs. Autocompleting inputs are wired up in the html.
    if (!prop.allowedValues) {
      this.listenToPropertyUpdates(prop);
    }
    this.properties.push(prop);
    return prop;
  }

  updateIcon(displayedValues: SimPropertyStateIconAssoc[]): void {
    const object = this.objects.find(obj => obj.name === this.block.properties[0]?.value);

    if (object) {
      displayedValues.map(v => {
        const state = Array.from(object.states.values()).find(s => s.name === v.name);

        if (state) {
          this.imageService.loadIconImageObservable(state.icons.small, defaultImages.object).subscribe(uri => (v.icon = uri));
        }
      });
    }
  }

  updateProperty(update: ScenarioRulePropertyItem, property: BlockProperty): BlockProperty {
    const newValue = update.value != null ? update.value : update.defaultValue;
    if (typeof newValue === 'string') {
      property.value = this.translate.instant(t(newValue));
    } else {
      property.value = newValue;
    }
    property.value = newValue;
    property.name = update.name;
    property.displayName = this.translate.instant(t(update.displayName));
    if (
      this.block.templateBlock.blockType === RuleBlockNames.FEATURE_STATE &&
      this.block.properties[0]?.value &&
      update?.allowedValues &&
      update?.type === RuleBlockPropertyNameEnum.STATE
    ) {
      this.updateIcon(update.allowedValues.displayedValues);
    }
    property.allowedValues = update.allowedValues;

    if (!property.allowedValues) {
      this.listenToPropertyUpdates(property);
    } else if (property.subscription) {
      property.subscription.unsubscribe();
    }

    property.enabled = update.enabled;
    property.errorMessage = update.errorMessage;
    // Convert to the appropriate value for the form control.
    const value = property.allowedValues?.displayedValues?.find(v => v.value === property.value) ?? newValue;

    property.formControl.setValue(typeof value === 'string' ? this.translate.instant(t(value)) : value, { emitEvent: false, onlySelf: true });

    // we're setting the default value when it didn't have one, we want this value to propagate through
    if (update.value == null && !!newValue) {
      this.valueSelected(property, newValue);
    }

    if (property.allowedValues?.type !== 'dropdown') {
      property.formControl.setValidators(this.propertyValueValidator(property));
      property.formControl.updateValueAndValidity({ emitEvent: false, onlySelf: true });
    } else {
      if (!property.inputFormControl) {
        // is possible that we didn't originally create this, as we didn't know it had a dropdown allowed values
        property.inputFormControl = new UntypedFormControl(value);
      }

      property.inputFormControl.setValue(value, { emitEvent: false, onlySelf: true });
      property.inputFormControl.setValidators(this.propertyValueValidator(property));
      property.inputFormControl.updateValueAndValidity({ emitEvent: false, onlySelf: true });
    }

    return property;
  }

  /**
   * Listen to property updates of free form inputs. Will not listen if already listening.
   *
   * @param property the property to listen to
   */
  listenToPropertyUpdates(property: BlockProperty): void {
    // only listen if not listening
    if (property.subscription || property.allowedValues) {
      return;
    }
    // this feels a bit messy / brittle
    const sub = property.formControl.valueChanges.subscribe(v => {
      const existingProperty = this.properties.find(cp => cp.type === property.type);
      // property seems to be frozen - has original object state not updated "property"
      // hence, have to get updated property value to work with here.
      // if the newest version now has allowedValues, we need to unsubscribe.
      if (!existingProperty || existingProperty.allowedValues) {
        property.subscription?.unsubscribe();
        existingProperty?.subscription?.unsubscribe();
        property.subscription = undefined;
        if (existingProperty) {
          existingProperty.subscription = undefined;
        }
        return;
      }
      if (property.formControl.valid) {
        this.valueSelected(property, v);
      }
    });
    property.subscription = sub;
    this.subscription.add(sub);
  }

  /**
   * Validate user input against our list of allowed values for that property.
   *
   * @param property the property to validate against
   */
  propertyValueValidator(property: ScenarioRulePropertyItem): ValidatorFn {
    // return null = no errors, return obj = obj of error messages
    return (control: AbstractControl): ValidationErrors | null => {
      if (property.errorMessage) {
        return { hasError: property.errorMessage };
      }

      // if allowed values is set, validate against it
      const notBlank = control.value !== null && control.value !== undefined && control.value !== '';
      if (Array.isArray(property.allowedValues?.displayedValues) && property.allowedValues.displayedValues.length > 0) {
        const isAllowed = this.isValidDisplayValue(property, control.value);
        return isAllowed && notBlank ? null : { forbiddenName: { value: control.value?.value || control.value } };
      } else {
        return notBlank ? null : { missing: `property ${property.displayName} is blank` };
      }
    };
  }

  private isValidDisplayValue(property: ScenarioRulePropertyItem, value: any): boolean {
    if(value) {
      this.selectedObj = true;
    }
    return !!property?.allowedValues?.displayedValues?.find(
      p =>
        // FIXME this whole autocomplete interaction isn't quite right..
        p.value === value?.value ||
        p.value === value ||
        p.displayName === value?.value ||
        p.displayName === value ||
        (typeof value === 'number' && (p.value === value.toString() || p.displayName === value.toString()))
    );
  }

  propClicked(prop: ScenarioRulePropertyItem): void {
    console.log(`clicked ${prop.name}`);
  }

  displayValue(prop: SimPropertyState | string | number): string {
    // if prop is a primitive return it, else try displayName, else name else ''.
    return typeof prop === 'string' || typeof prop === 'number' ? `${prop}` : prop?.displayName ?? prop?.name ?? '';
  }

  valueSelected(property: BlockProperty, value: string | number | boolean): void {
    // note that name is display name, but type is the actual name (yes, this is confusing)
    this.propertyUpdated.emit({ propertyName: property.type, value });
  }

  public consume(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
  }

  public onDragEnter(ev: DragEvent): void {
    this.consume(ev);
    this.dragging = true;
  }

  public onDragLeave(ev: DragEvent): void {
    this.consume(ev);
    this.dragging = false;
  }

  public onDrag(ev: DragEvent): void {
    this.consume(ev);
    ev.dataTransfer.dropEffect = 'move';
    this.dragging = true;

    const data = extractJSONData<any>(ev.dataTransfer);
    // FIXME these handlers should be provided from elsewhere
    if (isObjectNameData(data) && !!this.objectBlockProperty) {
      this.dragFeedback = {
        allowed: true,
        message: ''
      };
    } else if (isTrainIdData(data) && !!this.trainBlockProperty) {
      this.dragFeedback = {
        allowed: true,
        message: ''
      };
    } else if (isMultimediaNameData(data) && !!this.multimediaBlockProperty) {
      this.dragFeedback = {
        allowed: true,
        message: ''
      };
    } else {
      this.dragFeedback = {
        allowed: false,
        message: ''
      };
    }
  }

  public onDrop(ev: DragEvent): void {
    this.consume(ev);
    ev.dataTransfer.dropEffect = 'move';
    this.dragging = false;
    const data = extractJSONData<any>(ev.dataTransfer);

    if (isObjectNameData(data) && !!this.objectBlockProperty) {
      const objectName = getObjectName(data);

      if (this.isValidAllowedValue(this.objectBlockProperty, objectName)) {
        this.valueSelected(this.objectBlockProperty, objectName);
      }
    } else if (isTrainIdData(data) && !!this.trainBlockProperty) {
      const trainId = getTrainId(data);

      if (this.isValidAllowedValue(this.trainBlockProperty, trainId)) {
        this.valueSelected(this.trainBlockProperty, trainId);
      }
    } else if (isMultimediaNameData(data) && !!this.multimediaBlockProperty) {
      const multimediaId = getMultimediaId(data);

      if (this.isValidAllowedValue(this.multimediaBlockProperty, multimediaId)) {
        this.valueSelected(this.multimediaBlockProperty, multimediaId);
      }
    }
  }

  private isValidAllowedValue(property: ScenarioRulePropertyItem, value: any): boolean {
    return !!property.allowedValues.allowedValues.find(
      p =>
        // FIXME this whole autocomplete interaction isn't quite right..
        p.value === value?.value || p.value === value || p.displayName === value?.value || p.displayName === value
    );
  }

  locationClicked(prop: BlockProperty): void {
    this.locateRuleItem.emit({ name: prop.formControl.value?.name, type: prop.type });
  }

  public openDialog(blockProp: BlockProperty): void {
    if (blockProp.name !== this.TRAIN_PROPERTY && blockProp.name !== this.VEHICLE_PROPERTY && blockProp.name !== this.FEATURE_NAME) {
      return;
    }

    const selectedTrainName = this.trainBlockProperty?.formControl?.value?.name;
    const selectedVehicleIndex = this.vehicleIndexBlockProperty?.value;

    if (blockProp.name === this.TRAIN_PROPERTY || blockProp.name === this.VEHICLE_PROPERTY) {
      this.selectedObj = true;
      this.subscription.add(
        this.contextSupplier
          .currentContext$()
          .pipe(
            switchMap(m =>
              m.trains.data$.pipe(
                map(trains => trains.find(tr => tr.name === selectedTrainName)),
                switchMap(train =>
                  this.consistDataService.data().pipe(
                    map(consists => consists.find(c => c.name === train.description)),
                    map(consist => ({ consist, isDriven: train.driverType === DriverType.HUMAN }))
                  )
                )
              )
            ),
            takeOneTruthy()
          )
          .subscribe(data => {
            if (data?.consist && (selectedTrainName || selectedVehicleIndex)) {
              const vehicleClassName = data?.consist?.vehicles?.find(v => v.position === selectedVehicleIndex)?.carClass?.description;
              const dialogRef = this.dialog.open<SimPropertiesDialogComponent, SimPropertiesDialogData, SimProperty>(SimPropertiesDialogComponent, {
                disableClose: true,
                minHeight: '60%',
                minWidth: '32%',
                data: {
                  train: { consistId: data?.consist?.id, scenarioTrainName: selectedTrainName },
                  vehicleClassName,
                  isDriven: data.isDriven,
                  selectedPropertyName: blockProp?.formControl?.value?.name
                }
              });
              dialogRef.afterClosed().subscribe(result => {
                if (result) {
                  if (!isNil(result?.name) && result?.name.length > 0) {
                    this.propertyUpdated.emit({ propertyName: blockProp.type, value: result.name });
                  }
                }
              });
            }
          })
      );
    } else if (blockProp.name === this.FEATURE_NAME) {
      const objectContext = this.objContextSupplier.currentContext$();
      const dialogRef = this.dialog.open<ObjectDialogComponent, any, ScenarioRulePropertyItem>(ObjectDialogComponent, {
        disableClose: true,
        minHeight: '60%',
        minWidth: '32%',
        data: {
          objectContext
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          if (!isNil(result?.name) && result?.name.length > 0) {
            this.propertyUpdated.emit({ propertyName: blockProp.type, value: result.name });
            this.selectedObj = true;
          }
        }
      });
    }
  }
}
