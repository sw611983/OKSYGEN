/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit, signal } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { SafeUrl } from '@angular/platform-browser';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { allFilterTypesMatch, Filter, filterMatches, SelectedFilterArray, Sorter, SorterPipe } from '@oksygen-common-libraries/material/components';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { defaultImages } from '@oksygen-sim-train-libraries/components-services/common';
import { ScenarioRulePropertyItem } from '../../../../../models/scenario-rule-item.model';
import { IObjectTrackAtlasManager, ObjectDataMapContext } from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectContainer, ObjectLabel, ObjectSource } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { map, Observable, Subscription, switchMap } from 'rxjs';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

type FilterType = string;

interface ObjectsListState {
  filters: ObjectsListFilter;
}

export interface ObjectsListFilter {
  sourceFilters: Map<ObjectSource, boolean>;
  typeGroupFilters: string[];
  search: string;
  selectedFilters: SelectedFilterArray<ObjectListFilterType>;
}

export interface ObjectsDialogData {
  displayedValues: ScenarioRulePropertyItem;
}

enum ObjectFilterType {
  // ```no-mat-icon``` prefix prevents the chip list from displaying mat-icons
  // Which is not very intuitive though...
  NAME = 'no-mat-icon-displayName'
}

export enum ObjectListFilterType {
  // These names are used to select the icon on chips of that type
  OBJECT_TYPE_GROUP = 'object',
  NAME = 'search',
  SOURCE = 'world',
  OBJECT_MODIFIED = 'multiple_choice'
}

const objectModifiedFilter = new Filter<ObjectListFilterType>(ObjectListFilterType.OBJECT_MODIFIED, '', t('Modified Objects'));

export interface ObjectUiState {
  filters: {
    objectText: string;
    selectedFilters: SelectedFilterArray<ObjectFilterType>;
  };
}

@Component({
  selector: 'oksygen-object-dialog',
  templateUrl: './object-dialog.component.html',
  styleUrl: './object-dialog.component.scss'
})
export class ObjectDialogComponent implements OnInit, OnDestroy {
  selectedProperty: boolean;
  isValid: boolean;
  selectedFilters = new SelectedFilterArray<FilterType>();
  state: ObjectsListState;
  private sorterPipe = new SorterPipe();
  sorter = new Sorter<ObjectContainer>();
  objects: ObjectContainer[];
  private subscription = new Subscription();
  objectTypeGroups: Array<string> = [];
  filteredObjects: ObjectContainer[];
  modifiedObjects: string[];
  readonly objectModifiedFilter = objectModifiedFilter;
  context$: Observable<ObjectDataMapContext>;
  iconUri = signal<string | SafeUrl>(defaultImages.object);
  iconLabel = signal<ObjectLabel>(null);
  chkComp = 'dialog';
  displayedValues$: Observable<ObjectContainer[]>;
  private readonly masterSubscription = new Subscription();

  objectContext: Observable<ObjectDataMapContext<any, IObjectTrackAtlasManager>>;
  selectedObject: ObjectContainer;
  _sourceFilters: Array<Filter<ObjectListFilterType>> = [
    new Filter(ObjectListFilterType.SOURCE, ObjectSource.SCENARIO.id, t('Scenario Objects')),
    new Filter(ObjectListFilterType.SOURCE, ObjectSource.TRACK.id, t('Track Objects'))
  ];
  constructor(
    public dialogRef: MatDialogRef<ObjectDialogComponent, ScenarioRulePropertyItem>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private uiStateModelManager: UiStateModelManager,
    private readonly translateService: TranslateService,
    private cdr: ChangeDetectorRef
  ) {
    this.sorter.sortFunction = (c, a, b): number => a?.name?.localeCompare(b?.name, translateService.currentLocaleString);
  }

  selectObject(object: ObjectContainer): void {
    this.selectedObject = object;
  }

  trackFeatureBy(index: number, element: ObjectContainer): any {
    return element?.id;
  }

  ngOnInit(): void {
    this.initSorter();
    this.state = this.uiStateModelManager.getStateModel<any>('ObjectDialogComponent', () => ({
      filters: {
        sourceFilters: new Map(),
        typeGroupFilters: [],
        search: '',
        selectedFilters: new SelectedFilterArray<ObjectListFilterType>()
      }
    }));
    this.objectContext = this.data.objectContext;
    const objects$ = this.objectContext?.pipe(switchMap(m => m.objects.data$.pipe(map(allObjects => allObjects.filter(obj => !obj.parentId)))));
    this.subscription.add(
      objects$.subscribe(allObjects => {
        // We only want to show top level objects here.
        this.objects = allObjects?.filter((ot: any) => (ot.placementRules?.placeable ?? true) && ot.type !== 'Container') ?? [];
        this.objectTypeGroups = [];
        this.objects?.forEach(o => {
          const group = this.objectTypeGroups.find(g => g === o.objectType.group.name);
          if (!group) {
            this.objectTypeGroups.push(o.objectType.group.name);
          }
        });
        this.objectTypeGroups.sort((a, b) => a?.localeCompare(b, this.translateService.currentLocaleString));
        this.applyFilters();
      })
    );
  }

  onObjectSelected(selected: boolean): void {
    this.selectedProperty = selected; // Enable or disable the button based on selection
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  textToFilter = (text: string): Filter<string> => new Filter(ObjectListFilterType.NAME, text);

  /**
   * Adds the given filter to the selected filters, removing any other filters of the same type.
   */
  setUniqueFilterType(filter: Filter<ObjectListFilterType>): void {
    if (filter) {
      this.state.filters.selectedFilters.replace(filter.type, filter);
      this.applyFilters();
    }
  }

  filterByTypeGroup(typeGroup: string): void {
    if (!!typeGroup && typeGroup.length > 0) {
      this.setUniqueFilterType(new Filter(ObjectListFilterType.OBJECT_TYPE_GROUP, typeGroup));
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSearchTextChange(text: string): void {
    this.state.filters.search = text;
    this.applyFilters();
  }

  onSelect(): void {
    this.dialogRef.close(this.selectedObject as unknown as ScenarioRulePropertyItem);
    this.clearFilters();
  }

  propertySelected(property: boolean): void {
    this.selectedProperty = property;
  }

  /**
   * Apply the filters to the rules.
   */
  applyFilters(): void {
    if (!this.objects || !this.state) {
      return;
    }
    const modifiedFilter = this.state.filters.selectedFilters.find(f => f === this.objectModifiedFilter);
    this.filteredObjects =
      this.objects?.filter(object => {
        const names = [object.name, object.objectType.name];

        if (
          !allFilterTypesMatch(
            [
              { t: ObjectListFilterType.OBJECT_TYPE_GROUP, v: object.objectType.group.name, strict: true },
              { t: ObjectListFilterType.NAME, v: names },
              { t: ObjectListFilterType.SOURCE, v: object.source.id },
              { t: ObjectListFilterType.OBJECT_MODIFIED, v: '' }
            ],
            this.state.filters.selectedFilters
          )
        ) {
          return false;
        }

        if (!filterMatches(names, this.state.filters.search)) {
          return false;
        }

        // if we're filtering in modified objects we need to check if the object has been modified
        if (modifiedFilter) {
          if (this.modifiedObjects && !this.modifiedObjects.find(mod => mod === object.name)) {
            return false;
          }
        }

        return true;
      }) ?? [];
    this.filteredObjects = this.sorterPipe.transform(this.filteredObjects, this.sorter, this.sorter.refresh);
  }

  clearFilters(): void {
    this.state.filters.search = '';
    this.state.filters.typeGroupFilters = [];
    this.state.filters.selectedFilters = new SelectedFilterArray<ObjectListFilterType>();
    this.state.filters.sourceFilters = new Map();
    this.applyFilters();
  }

  setModifiedObjectFilter(): void {
    const exists = this.state.filters.selectedFilters.find(f => f === this.objectModifiedFilter);
    if (exists) {
      return;
    }
    this.state.filters.selectedFilters.push(this.objectModifiedFilter);
    this.applyFilters();
  }

  private initSorter(): void {
    function getObjectSortString(sortCol: string, e: ObjectContainer): string {
      switch (sortCol) {
        case 'type':
          return e.objectType.name;
        case 'name':
        default:
          return e.name;
      }
    }

    this.sorter.sortFunction = (sortCol: string, a: ObjectContainer, b: ObjectContainer): number =>
      getObjectSortString(sortCol, a).localeCompare(getObjectSortString(sortCol, b));
  }
}
