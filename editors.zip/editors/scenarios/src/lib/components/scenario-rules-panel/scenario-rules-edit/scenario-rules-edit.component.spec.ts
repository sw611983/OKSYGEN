/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule, ScenarioEditServiceStub } from '@oksygen-sim-train-libraries/components-services/testing';
import { ScenarioRulesEditComponent } from './scenario-rules-edit.component';
import { ScenarioRulesEditRuleBlockComponent } from './scenario-rules-edit-rule-block/scenario-rules-edit-rule-block.component';
import { ScenarioEditService } from '@oksygen-sim-train-libraries/components-services/editors/scenarios';

describe('ScenarioRulesEditComponent', () => {
  let component: ScenarioRulesEditComponent;
  let fixture: ComponentFixture<ScenarioRulesEditComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      providers: [
        {
          provide: ScenarioEditService,
          useClass: ScenarioEditServiceStub
        }
      ],
      declarations: [ScenarioRulesEditComponent, ScenarioRulesEditRuleBlockComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioRulesEditComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('rule', null);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
