/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { ScenarioRuleItem } from '../../../../models/scenario-rule-item.model';

import { RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';

@Component({
  selector: 'oksygen-scenario-rules-list-item',
  templateUrl: './scenario-rules-list-item.component.html',
  styleUrls: ['./scenario-rules-list-item.component.scss']
})
export class ScenarioRulesListItemComponent implements OnChanges {

  @Input() rule: ScenarioRuleItem;
  @Output() readonly selectRule: EventEmitter<void> = new EventEmitter();
  @Output() readonly deleteRule: EventEmitter<void> = new EventEmitter();
  @Output() readonly duplicateRule: EventEmitter<void> = new EventEmitter();
  @Output() readonly activeRule: EventEmitter<boolean> = new EventEmitter();
  isValid: boolean;
  isLatest: boolean;
  ruleExists: boolean;
  ruleTemplate: RuleTemplate;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.rule && changes.rule.currentValue !== changes.rule.previousValue) {
      // FIXME this needs to compare rule names
      this.ruleTemplate = this.rule.getTemplate();
      this.isValid = this.rule.isValid();
      this.isLatest = this.rule.isLatest();
      this.ruleExists = !!this.ruleTemplate;
    }
  }

  ruleClick(): void {
    this.selectRule.emit();
  }

  favouriteClick(event: Event): void {
    event.stopPropagation();
  }

  duplicateClick(event: Event): void {
    event.stopPropagation();
    this.duplicateRule.emit();
  }

  deleteClick(event: Event): void {
    event.stopPropagation();
    this.deleteRule.emit();
  }

  activeClick(event: Event): void {
    event.stopPropagation();
  }

  changeActive(event: MatSlideToggleChange): void {
    this.activeRule.emit(event.checked);
  }
}
