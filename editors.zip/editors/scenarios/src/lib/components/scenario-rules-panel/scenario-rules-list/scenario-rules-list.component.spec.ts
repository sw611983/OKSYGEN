/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { ScenarioRulesListComponent } from './scenario-rules-list.component';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { ScenarioEditorConfigTab } from '../../../models/scenario-editor-config.model';

describe('ScenarioRulesListComponent', () => {
  let component: ScenarioRulesListComponent;
  let fixture: ComponentFixture<ScenarioRulesListComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [ScenarioRulesListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioRulesListComponent);
    component = fixture.componentInstance;
    component.scenarioEditManager = {
      getFilters: (tab: ScenarioEditorConfigTab): any[] => null,
      saveFilters(tab: ScenarioEditorConfigTab, filters: any[]): void {
      }
    } as any;
    component.uiModels = new UiStateModelManager();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
