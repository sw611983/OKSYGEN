/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ScenarioRulesListItemComponent } from './scenario-rules-list-item.component';
import { ScenarioRuleItem } from '@oksygen-sim-train-libraries/components-services/editors/scenarios';

describe('ScenarioRulesListItemComponent', () => {
  let component: ScenarioRulesListItemComponent;
  let fixture: ComponentFixture<ScenarioRulesListItemComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [ScenarioRulesListItemComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioRulesListItemComponent);
    component = fixture.componentInstance;
    component.rule = new ScenarioRuleItem(
      {displayName: 'hello', description: 'hi', id: 1, ruleTemplateReference: null}
      , [], []
    );
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
