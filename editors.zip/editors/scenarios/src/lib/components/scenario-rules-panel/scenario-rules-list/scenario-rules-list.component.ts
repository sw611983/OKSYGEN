/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { Observable, Subscription } from 'rxjs';

import { Filter, SelectedFilterArray, Sorter, TextFilterPipe } from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { ScenarioEditManager } from '../../../services/scenario-edit.manager';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { ScenarioRuleItem } from '../../../models/scenario-rule-item.model';

interface ScenarioRulesListState {
  filters: ScenarioRulesListFilter;
}

export interface ScenarioRulesListFilter {
  search: string;
  selectedFilters: SelectedFilterArray<FilterType>;
}

enum FilterType {
  // These names are used to select the icon on chips of that type
  NAME = 'search'
}

const SELECTOR = 'oksygen-scenario-rules-list';

@Component({
  selector: SELECTOR,
  templateUrl: './scenario-rules-list.component.html',
  styleUrls: ['./scenario-rules-list.component.scss']
})
export class ScenarioRulesListComponent implements OnInit, OnDestroy {
  @Input('rules') rules$: Observable<ScenarioRuleItem[]>;
  @Input() scenarioEditManager: ScenarioEditManager;
  @Input() uiModels!: UiStateModelManager;

  @Output('selectRule') readonly selectRuleEmitter = new EventEmitter<ScenarioRuleItem>();
  @Output('duplicateRule') readonly duplicatetRuleEmitter = new EventEmitter<ScenarioRuleItem>();
  @Output('deleteRule') readonly deleteRuleEmitter = new EventEmitter<ScenarioRuleItem>();
  @Output('activeRule') readonly activeRuleEmitter = new EventEmitter<{ active: boolean; rule: ScenarioRuleItem }>();

  state: ScenarioRulesListState;

  sorter = new Sorter<any>();
  rules: ScenarioRuleItem[];
  filteredRules: ScenarioRuleItem[];
  private textFilterPipe: TextFilterPipe<ScenarioRuleItem>;
  subscription: Subscription;

  constructor(private logging: Logging, private readonly translateService: TranslateService) {}

  ngOnInit(): void {
    this.state = this.uiModels.getStateModel(SELECTOR, () => ({
      filters: {
        search: '',
        selectedFilters: new SelectedFilterArray<FilterType>()
      }
    }));

    this.textFilterPipe = new TextFilterPipe(this.logging);
    this.sorter.sortFunction = (c, a, b): number =>
      a?.scenarioRule.displayName?.localeCompare(b?.scenarioRule?.displayName, this.translateService.currentLocaleString);
    this.subscription = this.rules$?.subscribe(rules => {
      this.rules = rules;
      this.applyFilters();
    });
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  selectRule(rule: ScenarioRuleItem): void {
    this.selectRuleEmitter.emit(rule);
  }

  duplicateRule(rule: ScenarioRuleItem): void {
    this.duplicatetRuleEmitter.emit(rule);
  }

  deleteRule(rule: ScenarioRuleItem): void {
    this.deleteRuleEmitter.emit(rule);
  }

  activeRule(active: boolean, rule: ScenarioRuleItem): void {
    this.activeRuleEmitter.emit({ active, rule });
  }

  toSearchableText(rule: ScenarioRuleItem): string[] {
    if (!rule) {
      return [];
    }
    const arr = [ rule.scenarioRule.displayName ];
    if (rule.scenarioRule.description) {
      arr.push(rule.scenarioRule.description);
    }
    return arr;
  }

  textToFilter = (text: string): Filter<string> => new Filter(FilterType.NAME, text);

  onCurrentValueUpdate(text: string): void {
    this.state.filters.search = text;
    this.applyFilters();
  }

  applyFilters(): void {
    if (!this.rules) { return; }

     // Combine all search values into a single string
    // The filter is used to avoid empty strings joining with a space
    // Example of an issue ['', ''] becomes ' ' instead of '' because of the join
    // ['test', ''] becomes 'test ' instead of 'test'
    // Before it was doing a join on selecter filters + ' ' + filter.search, leading to an empty space as well if search was empty
    const search = [...this.state.filters.selectedFilters.map(filter => filter.searchValue), this.state.filters.search]
    .filter(searchValue => !!searchValue)
    .join(' ');


      this.filteredRules = this.textFilterPipe
      .transform(
        this.rules, this.toSearchableText.bind(this), search, this.sorter, this.sorter.refresh
      );
  }

}
