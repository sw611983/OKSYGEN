/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { RulesPanelComponent } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioEditManager } from '../../services/scenario-edit.manager';
import { ScenarioRuleItem } from '../../models/scenario-rule-item.model';

/**
 * Scenario rules panel state as held in the ```UiStateModelManager```.
 */
export interface ScenarioRulesState {
  selectedRule: ScenarioRuleItem;
  selectedId?: string|number;
}

/**
 * The selector used for the UiStateModel for the rules panel.
 * Usage: ```uiStateModelManager.getStateModel(RULES_PANEL_SELECTOR)```
 */
export const RULES_PANEL_SELECTOR = 'oksygen-scenario-rules-panel';

@Component({
  selector: RULES_PANEL_SELECTOR,
  templateUrl: './scenario-rules-panel.component.html',
  styleUrls: ['./scenario-rules-panel.component.scss']
})
export class ScenarioRulesPanelComponent extends RulesPanelComponent implements OnInit, OnDestroy {
  @Input('rules') override rules$!: Observable<ScenarioRuleItem[]>;
  @Input() scenarioEditManager: ScenarioEditManager;
  @Input() uiModels!: UiStateModelManager;

  state: ScenarioRulesState;

  ruleSub: Subscription;
  otherRuleNames: string[] = [];
  breadcrumbChildren: ReadonlyArray<string>;
  private rules: ScenarioRuleItem[];

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.state = this.uiModels.getStateModel<ScenarioRulesState>(RULES_PANEL_SELECTOR, () => ({
      selectedRule: null
    }));

    this.ruleSub = this.rules$.subscribe(rules => {
      this.rules = rules;
      if ((this.state as any).selectedId) {
        this.state.selectedRule = rules.find(r => r.scenarioRule.id === (this.state as any).selectedId);
        delete (this.state as any).selectedId;
      }
      // make sure to update the reference to the new copy of the selected rule
      if (this.state.selectedRule) {
        const newSelectedRule = rules.find(r => r.scenarioRule.id === this.state.selectedRule.scenarioRule.id);
        this.state.selectedRule = newSelectedRule;
        this.breadcrumbChildren = [t('Details')];
        const otherRules = rules?.filter(r => r?.scenarioRule?.id !== this.state.selectedRule?.scenarioRule?.id);
        if (otherRules) {
          this.otherRuleNames = otherRules.map(r => r?.scenarioRule?.displayName);
        }
      } else {
        this.breadcrumbChildren = null;
        this.otherRuleNames = [];
      }
    });
  }

  ngOnDestroy(): void {
    this.ruleSub.unsubscribe();
  }

  selectRule(rule: ScenarioRuleItem): void {
    this.state.selectedRule = rule;
    if (this.state.selectedRule && this.rules) {
      const otherRules = this.rules.filter(r => r.scenarioRule.id !== this.state.selectedRule.scenarioRule.id);
      this.otherRuleNames = otherRules.map(r => r.scenarioRule.displayName);
      this.breadcrumbChildren = [t('Details')];
    } else {
      this.breadcrumbChildren = null;
      this.otherRuleNames = [];
    }
  }

  selectChild(): void {
    // TODO
  }

  deleteRule(rule: ScenarioRuleItem): void {
    this.scenarioEditManager.deleteScenarioRule(rule.scenarioRule.id);
    this.selectRule(null);
  }

  duplicateRule(rule: ScenarioRuleItem): void {
    const name = this.newScenarioRuleName(`${rule.scenarioRule.displayName} (Clone)`);
    const description = rule.scenarioRule.description;
    const ruleId = rule.scenarioRule.id;
    this.scenarioEditManager.duplicateScenarioRule(name, description, ruleId);
  }

  activeRule(rule: {active: boolean; rule: ScenarioRuleItem}): void {
    this.scenarioEditManager.updateScenarioRuleActive(rule.rule.scenarioRule.id, rule.active);
  }

  /**
   * Generate Scenario rule names that don't conflict.
   * Defaults to Untitled Rule.
   * If this is taken, it will then try 'name (1)', 'name (2)' etc.
   *
   * @param name the name to use (IE Untitled Rule, or Foo Rule (Clone))
   * @param count recursion count - let it use the default of 0 when you call.
   */
  private newScenarioRuleName(name?: string, count = 0): string {
    const baseName = `Untitled Rule`; // ie, Foo Rule (Clone)
    if (!name) {
      name = baseName;
    }
    if (!this.rules) {
      return name;
    }
    const displayName = count > 1 ? `${name} (${count})` : name;
    if (!this.rules.find(r => r.scenarioRule.displayName === displayName)) {
      return displayName;
    }
    // give up on depth limit of 20 - surely no one would have 20 untitled rules ??
    if (count > 20) {
      throw new Error(`Cannot duplicate rule ${name}.`);
    }
    // 1 higher than how many untitled rules there are
    return this.newScenarioRuleName(`${name}`, count + 1);
  }
}
