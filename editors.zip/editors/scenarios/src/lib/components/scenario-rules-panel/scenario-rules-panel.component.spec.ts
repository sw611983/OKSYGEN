/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule, ScenarioEditServiceStub } from '@oksygen-sim-train-libraries/components-services/testing';
import { Observable } from 'rxjs';
import { ScenarioRulesPanelComponent } from './scenario-rules-panel.component';
import { ScenarioRulesEditComponent } from './scenario-rules-edit/scenario-rules-edit.component';
import { ScenarioRulesEditRuleBlockComponent } from './scenario-rules-edit/scenario-rules-edit-rule-block/scenario-rules-edit-rule-block.component';
import { ScenarioRulesListComponent } from './scenario-rules-list/scenario-rules-list.component';
import { ScenarioRulesListItemComponent } from './scenario-rules-list/scenario-rules-list-item/scenario-rules-list-item.component';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { ScenarioEditService } from '../../services/scenario-edit.service';
import { ScenarioEditorConfigTab } from '../../models/scenario-editor-config.model';

describe('ScenarioRulesPanelComponent', () => {
  let component: ScenarioRulesPanelComponent;
  let fixture: ComponentFixture<ScenarioRulesPanelComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      providers: [
        {
          provide: ScenarioEditService,
          useClass: ScenarioEditServiceStub
        }
      ],
      declarations: [
        ScenarioRulesPanelComponent,
        ScenarioRulesEditComponent,
        ScenarioRulesEditRuleBlockComponent,
        ScenarioRulesListComponent,
        ScenarioRulesListItemComponent
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioRulesPanelComponent);
    component = fixture.componentInstance;
    component.rules$ = new Observable(obs => {obs.next([]); obs.complete(); });
    component.scenarioEditManager = {
      getFilters: (tab: ScenarioEditorConfigTab): any[] => null,
      saveFilters(tab: ScenarioEditorConfigTab, filters: any[]): void {
      }
    } as any;
    component.uiModels = new UiStateModelManager();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
