/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';

import { IconFieldComponent } from '@oksygen-sim-train-libraries/components-services/common';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { TrainsPanelTrainsEditorComponent } from './trains-panel-trains-editor.component';
import { UnitsUnitPipe } from '@oksygen-sim-core-libraries/components-services/measurement-units';
import { TrainCardComponent } from '@oksygen-sim-train-libraries/components-services/trains';
import { FaultItemComponent, FaultsPanelComponent } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { ScenarioEditService } from '../../services/scenario-edit.service';

describe('TrainsPanelTrainsEditorComponent', () => {
  let component: TrainsPanelTrainsEditorComponent;
  let fixture: ComponentFixture<TrainsPanelTrainsEditorComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [IconFieldComponent],
        declarations: [
          TrainsPanelTrainsEditorComponent,
          TrainCardComponent,
          FaultsPanelComponent,
          FaultItemComponent,
          UnitsUnitPipe
        ],
        providers: [{ provide: ScenarioEditService, useValue: {} }]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainsPanelTrainsEditorComponent);
    component = fixture.componentInstance;
    component.world$ = new BehaviorSubject(null);
    component.trains$ = new BehaviorSubject([]);
    component.selectedTrainId$ = new BehaviorSubject(null);
    component.pathTrainId$ = new BehaviorSubject(null);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
