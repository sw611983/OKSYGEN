/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormGroupDirective, NgForm, UntypedFormControl } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { Observable, Subscription } from 'rxjs';

import { filterTruthy, takeOneTruthy } from '@oksygen-common-libraries/common';
import { AutocompleteInputType } from '@oksygen-common-libraries/material/components';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { FaultItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { Orientation, toOrientation } from '@oksygen-sim-core-libraries/data-types/common';
import { DETAILS, SegmentPosition, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { TrainReachablePathFinder, ZoomLevel } from '@oksygen-sim-train-libraries/components-services/maps';
import { SessionContextSupplier } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import {
  DriverListItemDriver,
  TrainQuickActionConfig,
  UsefulTrain,
  UsefulVehiclePosition
} from '@oksygen-sim-train-libraries/components-services/trains';
import { UserConfig } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ScenarioEditManager } from '../../services/scenario-edit.manager';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';

class DriverFieldErrorStateMatcher extends ErrorStateMatcher {
  override isErrorState(control: UntypedFormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    return !control.value;
  }
}

@Component({
  selector: 'oksygen-trains-panel-trains-editor',
  templateUrl: './trains-panel-trains-editor.component.html',
  styleUrls: ['./trains-panel-trains-editor.component.scss']
})
export class TrainsPanelTrainsEditorComponent implements OnInit, OnDestroy {

  @Input() trains$!: Observable<UsefulTrain[]>;
  @Input() pathTrainId$!: Observable<number>;
  @Input() selectedTrainId$!: Observable<number>;
  @Input() uiModels!: UiStateModelManager;
  @Input() searchable!: boolean;

  @Input() world$: Observable<WorldData>;
  @Input() netDef$: Observable<NetworkDefinitionManager>;
  @Input() pathFinder$: Observable<TrainReachablePathFinder>;
  @Input() scenario$: Observable<Scenario>;

  @Input() selectedFault: FaultItem;
  @Input() settings: TrainQuickActionConfig = {
    favouriteEnabled:         false,
    findTrainEnabled:         true,
    lockOnEnabled:            false,
    changeOrientationEnabled: true,
    deleteEnabled:            true,
    pathEnabled:              true,
    selectionEnabled:         false,
    carotEnabled:             true
  };
  @Input() userConfig$: Observable<UserConfig>;
  @Input() scenarioEditManager: ScenarioEditManager;

  @Output() readonly trainSelect: EventEmitter<UsefulTrain> = new EventEmitter();
  @Output() readonly missingTrainDetails: EventEmitter<boolean> = new EventEmitter();
  @Input() driverList$: Observable<Array<DriverListItemDriver>>;

  breadcrumbChildren: ReadonlyArray<string>;

  scenarioTrains: UsefulTrain[] = [];
  autocompleteInputType = AutocompleteInputType.FORM_FIELD;

  selectedTrainId: number;
  selectedTrain: UsefulTrain;
  pathTrainId: number;
  world: WorldData;
  pathToggled = false;
  segments: Array<number> = [];

  otherScenarioTrainNames: string[] = [];

  segmentName: (segmentId: number) => string;

  private subscriptions = new Subscription();

  driverFieldErrorStateMatcher: ErrorStateMatcher = new DriverFieldErrorStateMatcher();

  constructor(
    private contextSupplier: SessionContextSupplier) {
      this.segmentName = (x): string => 'Loading...';
  }

  ngOnInit(): void {
    this.subscriptions
      .add(this.world$
        .pipe(filterTruthy())
        .subscribe(w => {
          // FIXME this gets fired way too often, which may be causing slowdown in the train editor; see scenario-editor.component for more info
          this.world = w;
          this.segmentName = (segmentId): string => w.segmentMap.get(segmentId)?.name;
          this.segments = Array.from(w.segmentMap.values()).map(s => s.id);
        })
      );
      this.subscriptions.add(this.selectedTrainId$.subscribe(id => {
          this.selectedTrainId = id;
          this.onTrainDataUpdate();
        })
      );
      this.subscriptions.add(this.trains$.subscribe(trains => {
        this.scenarioTrains = trains;
        this.updateMissingTrainDetails();
        this.onTrainDataUpdate();
      })
      );
      this.subscriptions.add(this.pathTrainId$.subscribe(pt => {
        this.pathTrainId = pt;
        this.onTrainDataUpdate();
      }));
  }

  private onTrainDataUpdate(): void {
    this.setSelectedTrain(this.scenarioTrains.find(st => st.id === this.selectedTrainId));

    if (this.selectedTrain && this.scenarioTrains) {
      this.otherScenarioTrainNames = this.scenarioTrains
        .filter(tr => tr.id !== this.selectedTrain.id)
        .map(tr => tr.name);
    }

    this.pathToggled = this.selectedTrain?.id === this.pathTrainId;
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  backClick(): void {
    this.setSelectedTrain(undefined);
  }

  setFavourite(train?: UsefulTrain): void {
  }

  setLockOnTrain(train?: UsefulTrain): void {
  }

  doGoToTrain(train?: UsefulTrain): void {
    this.contextSupplier.currentContext$().pipe(takeOneTruthy()).subscribe(m => {
      // FIXME use TrainUtilities?
      m.map?.mapGoto(train.vehicles[0].position.lnglat[0], ZoomLevel.STATION);
    });
  }

  doShowTrain(train?: UsefulTrain): void {
    this.contextSupplier.currentContext$().pipe(takeOneTruthy()).subscribe(m => {
      m.map.spotlightTrain(train.id);
    });
  }

  doShowTrainPath(train?: UsefulTrain): void {
    this.contextSupplier.currentContext$().pipe(takeOneTruthy()).subscribe(m => {
      m.map.toggleHighlightedPath(train);
    });
  }

  updateMissingTrainDetails(): void {
    // Finds if there is any train without driver type
    let driverMissing = false;
    if(this.scenarioEditManager?.enforceDriver()) {
      driverMissing = this.scenarioTrains?.filter(train => !train.driverType)?.length > 0;
    }
    const trainNameMissing = this.scenarioTrains?.filter(train => !train.name)?.length > 0;
    this.missingTrainDetails.emit(trainNameMissing || driverMissing);
  }

  doChangeOrientation(train: UsefulTrain): void {
    // Get the reference position, preferring the rear of the train.
    const pos = train.rearPosition ?? this.toSegmentPosition(train.vehicles[0].position);
    // FIXME need a "move train" API shared between editor and session runner
    // Change the direction of travel
    this.scenarioEditManager.updateScenarioTrainPosition(train.id, pos.segmentId, pos.offset, toOrientation(!pos.fromAlpha));
  }

  toSegmentPosition(position: UsefulVehiclePosition): SegmentPosition {
    return {
      segmentId: position.segmentId,
      offset: position.segmentOffset,
      fromAlpha: position.segmentOrientation === Orientation.ALPHA_TO_BETA
    };
  }

  doDeleteTrain(train: UsefulTrain): void {
    this.deselectTrain();
    this.scenarioEditManager.deleteScenarioTrain(train.id);
  }

  deselectTrain(): void {
    this.selectTrain(undefined);
  }

  selectTrain(train: UsefulTrain | undefined): void {
    this.setSelectedTrain(train);
    this.trainSelect.emit(train);
  }

  private setSelectedTrain(train: UsefulTrain | undefined): void {
    this.selectedTrain = train;
    this.updateBreadcrumbs();
  }

  private updateBreadcrumbs(): void {
    if (this.selectedTrain) {
      this.breadcrumbChildren = [DETAILS];
    } else {
      this.breadcrumbChildren = null;
    }
  }
}
