/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ComponentRef,
  effect,
  HostListener,
  Inject,
  Input,
  NgZone,
  OnDestroy,
  OnInit,
  Optional,
  signal,
  ViewChild,
  ViewContainerRef
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Data } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { isEqual, isNil, isNumber } from 'lodash';
import { GeoJSONSource } from 'maplibre-gl';
import { BehaviorSubject, combineLatest, forkJoin, iif, interval, Observable, of, Subject, Subscription } from 'rxjs';
import {
  catchError,
  distinctUntilChanged,
  filter,
  map,
  mapTo,
  pairwise,
  startWith,
  switchMap,
  take,
  takeWhile,
  throttleTime,
  timeout
} from 'rxjs/operators';

import { asArray, DragFeedback, extractJSONData, filterTruthy, shareReplayOne, SuperCalled, takeOneTruthy } from '@oksygen-common-libraries/common';
import {
  changeVisibilityDynamicVerticalToolboxContainerTab,
  DynamicComponent,
  TabEntry,
  TabService,
  ToolboxContainerComponent,
  ToolboxContainerState,
  ToolboxContainerTabsConfig,
  updateDynamicVerticalToolboxContainerTabsConfig,
  VerticalToolboxMode
} from '@oksygen-common-libraries/material/components';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DriverType, SimulatorService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { MultimediaDataItem, MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { MultimediaItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { Orientation, SegOffset, SegOffsetOriented } from '@oksygen-sim-core-libraries/data-types/common';
import { isObjectPropertiesValid, ObjectModification } from '@oksygen-sim-core-libraries/data-types/objects';
import {
  AssessmentCriteriaService,
  handleDraggedReportItemData,
  isDraggedReportItemData,
  ReportingEventItem,
  ReportItem,
  ReportItemGroup
} from '@oksygen-sim-train-libraries/components-services/assessment-criteria';
import { ScenarioReportData } from '@oksygen-sim-train-libraries/components-services/assessment-criteria/scenario';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import {
  DragData,
  GlobalImageStoreKey,
  Image,
  ImageService,
  LayerService,
  LoadingData,
  ObjectLayer,
  uniqueItemName,
  WorldData
} from '@oksygen-sim-train-libraries/components-services/common';
import { BaseEditorComponent } from '@oksygen-sim-train-libraries/components-services/editors';
import {
  createPlanViewData,
  getMapGeoJSONSource,
  LineViewMapChildData,
  MainMapChildData,
  MainMapOutputData,
  MainMapViewDynamicComponent,
  MapChildData,
  mapContextProviders,
  MapType,
  MiniMapDynamicComponent,
  OBJECT_MAP_RENDERER_TOKEN,
  ObjectMapRenderer,
  PATH_PREVIEW_SOURCE_NAME,
  PATH_SOURCE_NAME,
  PathSelectionHandler,
  PLAN_VIEW_NAME,
  PlanViewComponent,
  readMapConfig,
  SELECTIONS_SOURCE_NAME,
  TRACK_SOURCE_NAME,
  ZoomLevel
} from '@oksygen-sim-train-libraries/components-services/maps';
import {
  handleDraggedMultimediaDataItem,
  isDraggedMultimediaDataItem,
  MultimediaSourceType
} from '@oksygen-sim-train-libraries/components-services/multimedia';
import {
  isObjectContainerPropertiesValid,
  ObjectContainer,
  ObjectSource,
  ObjectTypeDataService,
  ObjManager,
  SimObject
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RobotDriverService } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import {
  handleDraggedRuleTemplate,
  isDraggedRuleTemplate,
  RuleBlockPropertyConstraintService,
  RuleBlockPropertyNameEnum,
  RuleBlockService,
  RuleTemplate,
  ruleTemplateHasMultimedia,
  RuleTemplateService
} from '@oksygen-sim-train-libraries/components-services/rules';
import {
  Scenario,
  SCENARIO_EDITOR_EXTENSIONS_TOKEN,
  ScenarioEditorExtensions,
  ScenarioMultimedia,
  ScenarioRuleVariable
} from '@oksygen-sim-train-libraries/components-services/scenarios';
import {
  CameraControlsLayerComponent,
  CommsModuleStateService,
  CSystemSimulatorHelpersService,
  EnvironmentEditorService,
  EnvironmentProperty,
  initialiseLayersOnContext,
  ScenarioContext,
  ScenarioPreviewManager,
  SessionContext,
  SessionContextSupplier,
  SessionMainView,
  SystemStoreState
} from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import {
  Consist,
  ConsistDataService,
  ConsistListItem,
  DriverListItemDriver,
  isConsistListItemData,
  UsefulTrain
} from '@oksygen-sim-train-libraries/components-services/trains';
import { UserConfig, UserConfigService } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { toVersionString } from '@oksygen-sim-train-libraries/components-services/versioning';
import { Skin, TrackDataService, WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ScenarioRuleFactory } from '../../factories/scenario-rule.factory';
import { ScenarioEditorConfig, ScenarioEditorConfigTab } from '../../models/scenario-editor-config.model';
import { SCENARIOS_CARD_DATA } from '../../models/scenario-editor-tab.model';
import { SessionLauncher } from '../../models/session-launcher';
import { SimHubLoader } from '../../models/sim-hub-loader';
import { PositioningFailureReasons, ScenarioEditManager } from '../../services/scenario-edit.manager';
import { ScenarioEditService } from '../../services/scenario-edit.service';
import { ScenarioEditorContextPublisher } from '../../services/scenario-editor-context.publisher';
import { ScenarioRuleBlockPropertyConstraintService } from '../../services/scenario-rule-block-property-constraint.service';
import { RULES_PANEL_SELECTOR } from '../scenario-rules-panel/scenario-rules-panel.component';
import { ScenarioRuleItem } from '../../models/scenario-rule-item.model';

// eslint-disable-next-line @typescript-eslint/no-empty-object-type
interface ScenarioEditorState extends ToolboxContainerState { }

// TODO: Currently is enforced to only allow one editor to be active
// When this changes, more work needs to be done to have the vision/camera context switching to work properly

const SELECTOR = 'oksygen-scenario-editor';

@Component({
  selector: SELECTOR,
  templateUrl: './scenario-editor.component.html',
  styleUrls: ['./scenario-editor.component.scss'],
  // Marks this as a base parent component to its children
  providers: [
    ScenarioEditorContextPublisher,
    { provide: SessionContextSupplier, useExisting: ScenarioEditorContextPublisher },
    ...mapContextProviders({ useExisting: ScenarioEditorContextPublisher }),
    { provide: RuleBlockPropertyConstraintService, useClass: ScenarioRuleBlockPropertyConstraintService }
  ]
})
export class ScenarioEditorComponent
  extends BaseEditorComponent<Scenario, ScenarioContext, ScenarioEditManager, ScenarioEditService>
  implements OnInit, AfterViewInit, OnDestroy {
  @Input() override config: ScenarioEditorConfig;
  public mainMap: MainMapViewDynamicComponent<MainMapChildData, MainMapOutputData>;
  public miniMap: MiniMapDynamicComponent;
  @ViewChild('miniView', { read: ViewContainerRef, static: false }) miniView: ViewContainerRef;
  @ViewChild('lineView', { read: ViewContainerRef, static: false }) lineView: ViewContainerRef;
  @ViewChild('mainView', { read: ViewContainerRef, static: false }) mainView: ViewContainerRef;

  @ViewChild(CameraControlsLayerComponent) private cameraControlsLayer: CameraControlsLayerComponent;

  @ViewChild(ToolboxContainerComponent) toolboxContainer: ToolboxContainerComponent;

  state: ScenarioEditorState;

  allTracks: Array<string>;
  userConfig: UserConfig;
  toolboxMode = VerticalToolboxMode.FIXED;

  public showMap: { show: boolean; message?: string } = { show: true };
  public followingTrain = false;
  pathSectionHandler: PathSelectionHandler;
  public selectingPath = false;
  public showingTrainPath = false;
  public pathToolDisabled = true;
  public stationsDisabled = true;
  // FIXME do we really need this variable? Could probably be replaced by the context/train manager/selected train.
  private readonly selectedTrain$: BehaviorSubject<UsefulTrain>;

  // FIXME this duplicates SessionComponent
  public mainViewType: SessionMainView;

  // TODO Can probably be replaced by context.scenario$
  scenario$ = new BehaviorSubject<Scenario>(null);
  sessionStartTime$ = new BehaviorSubject<string>(null);
  availableWorlds$ = new BehaviorSubject<Array<string>>([]);
  availableSkins$ = new BehaviorSubject<Array<Skin>>([]);
  showInPreviewDisabled$ = new BehaviorSubject<boolean>(true);
  showInPreview$ = new BehaviorSubject<boolean>(false);
  triggerFormValidation$ = new Subject<void>();

  private scenarioDetails = {
    edit: true,
    showStatus: true,
    showAssessment: true,
    worldSelectionLocked: false,
    scenario$: this.scenario$,
    savedScenarioName$: of(''),
    sessionStartTime$: this.sessionStartTime$,
    availableWorlds$: this.availableWorlds$,
    availableSkins$: this.availableSkins$,
    showInPreviewVisible: true,
    showInPreviewDisabled$: this.showInPreviewDisabled$,
    triggerFormValidation$: this.triggerFormValidation$,
    showInPreview$: this.showInPreview$
  };
  /**
   * This is separate from the Train Manager's selected train to prevent undesirable interactions.
   * For example, we want to be able to stay on the list view when switching between tabs;
   * listening directly to the manager's selection would result in going to the selected train's tab.
   */
  private trainPanelSelectedTrainIdSubject = new BehaviorSubject<number>(null);

  scenarioEditManager: ScenarioEditManager;
  scenarioPreviewManager: ScenarioPreviewManager;

  rendered$ = new BehaviorSubject<boolean>(false);

  private environmentState = new Map<EnvironmentProperty, number>();
  private environmentState$ = new BehaviorSubject<Map<EnvironmentProperty, number>>(this.environmentState);

  private environmentService: EnvironmentEditorService = {
    getEnvironmentState$: () => this.environmentState$,
    setEnvironmentState: (property: EnvironmentProperty, value: number) => this.scenarioEditManager.setInitialEnvironmentState(property, value),
    showInPreview$: () => this.scenarioPreviewManager.showEnvironmentalEffects$
  };

  // FIXME these duplicate functionality from SessionComponent
  private resizeSubject: Subject<void> = new Subject<void>();
  public resize$: Observable<void>;

  tabs: ToolboxContainerTabsConfig;

  dragging = false;
  dragFeedback: DragFeedback = { allowed: false, message: '' };
  private trains$: BehaviorSubject<Array<UsefulTrain>> = new BehaviorSubject([]);
  private multimedia$: BehaviorSubject<Array<ScenarioMultimedia>> = new BehaviorSubject([]);
  private multimediaItems: Array<ScenarioMultimedia>;
  private possibleMultimediaItems: Array<MultimediaDataItem>;
  private rules$: BehaviorSubject<Array<ScenarioRuleItem>> = new BehaviorSubject([]);
  private ruleTemplates: Array<RuleTemplate>;
  private possibleRuleTemplates: Array<RuleTemplate>;
  private assessmentCriteria$: BehaviorSubject<Array<ScenarioReportData>> = new BehaviorSubject([]);
  private ruleVariables$: BehaviorSubject<Array<ScenarioRuleVariable>> = new BehaviorSubject([]);
  private possibleAssessmentCriteriaItems: Array<ReportItemGroup> = [];
  private possibleAssessmentEventItems: Array<ReportingEventItem>;

  mainMapViewMapReady$ = new BehaviorSubject(false);

  private context: ScenarioContext;
  loadingModules: Array<LoadingData>;
  // FIXME this variable name is a bit misleading.
  loaded = false;

  private selectedTrainSubscription: Subscription;

  // private dateTimeShowInPreview = false;
  private userConfigSub: Subscription;

  private readonly PLAN_VIEW_SELECTOR = { type: MapType.PLAN, name: PLAN_VIEW_NAME };

  private detailBadgeContentSubject = new BehaviorSubject<string | number | undefined | null>(null);
  private detailBadgeContent$ = this.detailBadgeContentSubject.pipe(shareReplayOne());
  private detailBadgeHiddenSubject = new BehaviorSubject<boolean>(true);
  private detailBadgeHidden$ = this.detailBadgeHiddenSubject.pipe(shareReplayOne());

  private trainBadgeContentSubject = new BehaviorSubject<string | number | undefined | null>(null);
  private trainBadgeContent$ = this.trainBadgeContentSubject.pipe(shareReplayOne());
  private trainBadgeHiddenSubject = new BehaviorSubject<boolean>(true);
  private trainBadgeHidden$ = this.trainBadgeHiddenSubject.pipe(shareReplayOne());

  private ruleBadgeHiddenSubject = new BehaviorSubject<boolean>(true);
  private ruleBadgeHidden$ = this.ruleBadgeHiddenSubject.pipe(shareReplayOne());

  private simHubLoader: SimHubLoader;
  sessionLauncher: SessionLauncher;
  selectedTrainId = 0;
  private updatedSkin: string | null = null;
  private previousSkin: string | null = null;
  private selectedObjectSubject = new BehaviorSubject<SimObject | null>(null);
  public selectedObject$ = this.selectedObjectSubject.asObservable();
  selectedObject: SimObject;

  constructor(
    readonly logger: Logging,
    activatedRoute: ActivatedRoute,
    public readonly scenarioEditService: ScenarioEditService,
    private readonly trackDataService: TrackDataService,
    private readonly consistDataService: ConsistDataService,
    protected readonly imageService: ImageService,
    contextSupplier: ScenarioEditorContextPublisher,
    private readonly worldDefService: WorldDefinitionService,
    private readonly snackbar: MatSnackBar,
    public readonly dialog: MatDialog,
    public readonly layerService: LayerService,
    private readonly tabService: TabService,
    private readonly ruleblockHandler: RuleBlockPropertyConstraintService<any>,
    private readonly userConfigService: UserConfigService,
    private readonly registry: Registry,
    private readonly userService: UserService,
    private readonly store: Store<SystemStoreState>,
    private readonly systemSimsHelperService: CSystemSimulatorHelpersService,
    private readonly commsModuleStateService: CommsModuleStateService,
    private readonly authService: AuthService,
    private readonly translate: TranslateService,
    private readonly zone: NgZone,
    private readonly cd: ChangeDetectorRef,
    private readonly simulatorService: SimulatorService,
    private readonly ruleBlockService: RuleBlockService,
    private readonly ruleTemplateService: RuleTemplateService,
    private readonly robotDriverService: RobotDriverService,
    private readonly objectTypeService: ObjectTypeDataService,
    private readonly multimediaDataService: MultimediaDataService,
    @Inject(OBJECT_MAP_RENDERER_TOKEN) protected overrideObjectMapRenderer: ObjectMapRenderer,
    @Optional() @Inject(SCENARIO_EDITOR_EXTENSIONS_TOKEN) protected scenarioEditorExtensionsToken: ScenarioEditorExtensions,
    @Optional() private readonly assessmentCriteriaService: AssessmentCriteriaService
  ) {
    super(activatedRoute, contextSupplier, scenarioEditService);
    this.selectedTrain$ = new BehaviorSubject<UsefulTrain>(null);

    this.resize$ = this.resizeSubject.pipe(throttleTime(500, undefined, { leading: true, trailing: true }));

    effect(() => {
      const config = this.userConfigService.config();

      this.toolboxMode = config.toolboxMode;
      this.userConfig = config;
    });
  }

  ngOnInit(): void {
    this.consistDataService.reloadData();
    this.initLoading();
    this.handleMapTogglesChange();

    const driverList$ = this.robotDriverService.data().pipe(
      filterTruthy(),
      map(robotDrivers => {
        const driverList: Array<DriverListItemDriver> = [];

        driverList.push({
          type: DriverType.HUMAN,
          name: t('Human'),
          //FIXME: Currently id need to be guid
          id: '',
          version: ''
        });
        robotDrivers.forEach(rd =>
          driverList.push({
            type: DriverType.ROBOT,
            name: rd.name,
            id: rd.id,
            version: rd.version
          })
        );

        return driverList;
      })
    );
    let id: string;

    const contextFromRoute$ = this.activatedRoute.paramMap.pipe(
      switchMap(params => {
        id = params.get('id');
        this.scenarioEditManager = this.scenarioEditService.getEditManager(id);
        this.contextSupplier.setCurrentContext({ id }, 'Scenario editor');

        const getScenario = this.scenarioEditManager.getScenario.bind(this.scenarioEditManager);
        this.ruleblockHandler.initialiseConstraints(getScenario, () => this.context);
        this.scenarioDetails.savedScenarioName$ = this.scenarioEditManager.savedScenarioName$();
        // TODO see if we can simplify like so:
        // this.ruleblockHandler.initialiseHandlers(() => this.scenarioEditManager.getScenario());

        return this.contextSupplier.currentContext$();
      })
    );

    this.subscription.add(
      combineLatest([contextFromRoute$, this.activatedRoute?.data, driverList$]).subscribe(async ([context, routeData, driverList]) => {
        if (routeData && context && driverList) {
          this.context = context;
          // better to pass context than individual observables
          // risk of indiv obs is you must be careful with their lifetime!
          // an obs$ created on a component will complete() on component lifecycle end.
          // Managers can live longer (ie, nav away destroys component but not manager).
          this.scenarioPreviewManager = this.scenarioEditService.getPreviewManager(id, context);
          this.simHubLoader = new SimHubLoader(this.imageService, this.systemSimsHelperService, this.simulatorService);
          this.simHubLoader.simHubs$.subscribe(simHubs => {
            if (!simHubs || simHubs.length === 0) return;

            if (simHubs.length === 1) {
              const simHub = simHubs[0];
              this.sessionLauncher = new SessionLauncher(
                this.registry,
                this.logger,
                this.userService,
                this.store,
                this.systemSimsHelperService,
                this.commsModuleStateService,
                this.dialog,
                this.authService,
                this.zone,
                this.translate,
                this.scenarioPreviewManager,
                simHub.sim,
                simHub.hub,
                simHub.systemNumber
              );
            } else {
              throw Error('Multi-sim config not supported :(');
            }
          });

          this.subscription.add(this.scenarioPreviewManager.visionUnderControl$.subscribe(b => this.showInPreviewDisabled$.next(!b)));
          this.subscription.add(this.scenarioPreviewManager.showPreview$.subscribe(b => this.showInPreview$.next(b)));

          this.state = this.context.uiState.getStateModel<ScenarioEditorState>(SELECTOR, () => ({
            startToolbox: {
              opened: false,
              index: 0
            },
            endToolbox: {
              opened: true,
              index: 0
            }
          }));
          this.config = routeData as ScenarioEditorConfig;
          const uiModels = this.context.uiState;
          this.initialiseLayers();
          // Wire up data for the views.

          // FIXME Plugin API needed, we'll outgrow this approach very quickly
          // TODO @@@ make use of defined interfaces for initialising plugin tools
          this.updateEditorTabs(uiModels, driverList$);
          this.updateLibraryTabs(uiModels, driverList$);
        }

        this.tabs = this.config.tabs;
        this.scenarioDetails.showInPreviewVisible = this.config.previewEnabled;
        this.scenarioDetails.showAssessment = this.config.assessmentEnabled;
      })
    );

    this.subscription.add(
      this.trackDataService
        .data()
        .pipe(
          filterTruthy(),
          // Calls to this.trackDataService.getTracks() are now safe.
          switchMap(tracks => {
            this.allTracks = [];
            Array.from(tracks.values()).forEach(tr => this.allTracks.push(tr.name));
            return this.rendered$;
          }),
          filterTruthy(),
          switchMap(x => this.contextSupplier.currentContext$()),
          filterTruthy(),
          switchMap(ctx => {
            this.scenarioEditManager.setEditingContext(ctx as ScenarioContext);
            this.subscription.add(
              this.context.map?.getSelectedObject().subscribe((object: SimObject) => {
                this.scenarioPreviewManager.setFocusedObject(object);
                this.selectedObject = object;
              })
            );

            this.createPathSelectionHandler();
            this.setTrainSelectionHandler();
            this.setObjectSelectionHandler();
            this.setPointSelectionHandler();

            this.subscription.add(
              this.context.trains
                .getSelectedTrain$()
                .pipe(pairwise())
                .subscribe(([prevTrain, currTrain]) => {
                  this.selectedTrain$.next(currTrain);

                  // only open the tab if the selected train id has changed
                  // stops it opening if the scenario has changed in any way, etc
                  if (currTrain?.id !== prevTrain?.id) {
                    this.trainPanelSelectedTrainIdSubject.next(currTrain?.id);
                    this.openToolbox(ScenarioEditorConfigTab.TRAIN);
                  }
                })
            );

            this.subscription.add(
              this.context.trains
                .data()
                .pipe(filterTruthy())
                .subscribe(tr => this.trains$.next(tr))
            );

            return this.context.data$;
          }),
          filterTruthy()
        )
        .subscribe(s => {
          this.processScenarioUpdate(s);
          if (this.selectedObject?.objectType?.name === 'Point') {
            this.loaded = false;
          } else {
            this.loaded = true;
          }
        })
    );

    this.subscription.add(
      this.multimediaDataService
        .data()
        .pipe(filterTruthy(), shareReplayOne())
        .subscribe(multimedia => {
          this.possibleMultimediaItems = multimedia;
        })
    );
    this.subscription.add(
      this.ruleTemplateService
        .data()
        .pipe(filterTruthy(), shareReplayOne())
        .subscribe(ruleTemplates => {
          this.possibleRuleTemplates = ruleTemplates;
        })
    );

  }

  ngAfterViewInit(): void {
    // FIXME hack to wait until stuff all exists on the screen to render to
    setTimeout(() => {
      try {
        this.renderViews();
        this.handleSelectedTrainChange();
      } catch (error) {
        this.logger.error('error caught', error);
      }
    }, 100);
  }

  resetSelectedEndTab(tab: TabEntry): void {
    if (tab.name !== 'Objects') {
      //Deselect Object
      this.context.map?.selectObject(null);
    }
  }

  // do nothing - currently scenario editor is not configurable
  processConfig(context: SessionContext, config: Data): void { }

  getDefaultConfig(): Data {
    return null;
  }
  getEditorDataFromContext(context: SessionContext): Observable<Scenario> {
    return context.data$;
  }

  initialiseLayers(): void {
    initialiseLayersOnContext(this.contextSupplier.currentContext$(), this.layerService);
  }

  renameMultimedia(m: MultimediaItem): void {
    const rule = this.scenarioEditManager.scenario.rule.find(r => r.id === m.ruleId);
    const ruleTemplate = this.ruleTemplates?.find(rt => rt.id === rule?.ruleTemplateReference?.id);
    const phantom = ruleTemplate?.phantom;
    this.scenarioEditManager.updateScenarioMultimediaName(m.ruleId, m.name, phantom);
  }

  deleteMultimedia(m: MultimediaItem): void {
    if (this.scenarioRuleUsesMultimedia(m)) {
      this.snackbar.open(t('Cannot delete multimedia in use by a rule.'), t('OK'), { duration: 5000 });
    } else {
      this.scenarioEditManager.deleteMultimedia(m.moodleScormActivity.ruleId);
    }
  }

  private scenarioRuleUsesMultimedia(m: MultimediaItem): boolean {
    let inUse = false;
    // FIXME need to abstract moodle
    const multimediaId = m?.moodleScormActivity?.multimediaId ?? '';
    this.scenarioEditManager?.scenario?.rule?.forEach(r => {
      const ruleTemplate = this.ruleTemplates?.find(rt => rt.id === r.ruleTemplateReference?.id);
      if (!ruleTemplate?.phantom) {
        r?.ruleTemplateReference?.ruleBlocks?.ruleBlock?.forEach(rb => {
          rb?.properties?.property?.forEach(p => {
            if (p.name === RuleBlockPropertyNameEnum.MULTIMEDIA_NAME) {
              if (p.value === multimediaId) {
                inUse = true;
              }
            }
          });
        });
      }
    });
    return inUse;
  }

  disableSaveDetails(disableSave: boolean): void {

    // let badgeContent: string | number = null;
    // let badgeHidden = true;

    if (disableSave) {
      this.showDetailBadgeWarning();
      // badgeContent = '!';
      // badgeHidden = false;
    } else {
      this.hideDetailBadgeWarning();
    }

    // this.detailBadgeContentSubject.next(badgeContent);
    // this.detailBadgeHiddenSubject.next(badgeHidden);
  }

  /**
   * Updats train badge based on the provided status.
   * @param status the train badge status
   */
  updateTrainBadge(status: boolean): void {
    if (status) {
      this.showTrainBadgeWarning();
    } else {
      this.hideTrainBadgeWarning();
    }
  }

  private dateTimeShowInPreviewChanged(value: boolean): void {
    this.scenarioPreviewManager.setShowScenarioTime(value);
  }

  private environmentShowInPreviewChanged(value: boolean): void {
    this.scenarioPreviewManager.setShowEnvironmentalEffects(value);
  }

  private createPathSelectionHandler(): void {
    const atlasManager = this.context.map;
    if (atlasManager) {
      this.context.world.netDef$.pipe(takeOneTruthy()).subscribe(n => {
        // We need to wait until the component is created and the map is set up with sources.
        // TODO consider having an observable call us back when the map is ready.
        this.subscription.add(
          interval(250)
            .pipe(
              map(_ => atlasManager.getMapComponent(this.PLAN_VIEW_SELECTOR)),
              takeOneTruthy()
            )
            .subscribe(c => {
              const newSourceSupplier = (s: string) => (): GeoJSONSource => getMapGeoJSONSource(c.map, s);
              const colors = readMapConfig(this.registry).defaultStyle.colors.track;

              this.pathSectionHandler = new PathSelectionHandler(
                newSourceSupplier(TRACK_SOURCE_NAME),
                newSourceSupplier(PATH_SOURCE_NAME),
                newSourceSupplier(PATH_PREVIEW_SOURCE_NAME),
                newSourceSupplier(SELECTIONS_SOURCE_NAME),
                n,
                c,
                id => this.context.objects.getObject(id),
                settings => this.scenarioEditManager.multipleObjectChangeStateAutoOff(settings),
                colors.previewPathLineColor,
                colors.previewInvalidPathLineColor,
                this.cd
              );
            })
        );
      });
    }
  }

  private handleTrainClicked(id?: number, data?: any): void {
    this.selectTrain(id);
    this.selectedTrainId = id;
  }

  private setTrainSelectionHandler(): void {
    // TODO the following is quite specific to trains, so should be in a class that is specifically about trains.
    this.context.map?.setTrainSelectionHandler(
      { type: MapType.PLAN, name: PLAN_VIEW_NAME },
      {
        onTrainHovered: (id: number, data: any) => { },
        onTrainClicked: this.handleTrainClicked.bind(this),
        onTrainDown: (id: number, clickPoint: SegOffset, data: any) => !this.selectingPath,
        onConsistDragged: (consist: Consist, segOffset: SegOffset) => {
          if (!this.scenarioEditManager.scenario.tracknetworkName) {
            return {
              allowed: false,
              message: t('Select a world before adding content.')
            };
          }
          const testResult = this.scenarioEditManager.newScenarioTrainFromConsistAllowed(consist, segOffset);
          let message: string = testResult.allowed ? t('Add new Train') : t('Cannot add this Train');

          switch (testResult.reason) {
            case 'TOTAL_TRAIN_LIMIT_REACHED':
              message = t('Cannot add more Trains.');
              break;
            default:
              message = this.getMessageForPositioningFailure(testResult.reason);
          }

          return {
            allowed: testResult.allowed,
            message
          };
        },
        onConsistDropped: (consist: Consist, segOffset: SegOffset) => {
          if (!this.scenarioEditManager.scenario.tracknetworkName) {
            return;
          }
          const newTrainName = this.newScenarioTrainName();
          this.scenarioEditManager.newScenarioTrainFromConsist(consist, newTrainName, {
            ...segOffset,
            fromAlpha: true
          });
          const addedUsefulTrain = this.trains$?.value?.find(ut => ut?.name === newTrainName);
          this.selectTrain(addedUsefulTrain);
        },
        onScenarioTrainDragged: (id: number, segOffset: SegOffset) => this.onTrainDragged(id, segOffset, Orientation.ALPHA_TO_BETA),
        onScenarioTrainDropped: (id: number, segOffset: SegOffset) => this.onTrainDropped(id, segOffset, Orientation.ALPHA_TO_BETA),
        onUsefulTrainDragged: (id: number, segOffset: SegOffset) => this.onTrainDragged(id, segOffset),
        onUsefulTrainDropped: (id: number, segOffset: SegOffset) => this.onTrainDropped(id, segOffset)
      }
    );
  }

  private onTrainDragged(id: number, segOffset: SegOffset, orientation?: Orientation): { allowed: boolean; message: string } {
    if (!this.scenarioEditManager.scenario.tracknetworkName) {
      return {
        allowed: false,
        message: t('Select a world before adding content.')
      };
    }
    // TODO there should be some sort of common helper code/API for moving trains while editing and in a session.
    const testResult = this.scenarioEditManager.updateScenarioTrainPositionAllowed(id, segOffset.segmentId, segOffset.offset, orientation);
    let message: string = testResult.allowed ? t('Add new Train') : t('Cannot add this Train');

    message = this.getMessageForPositioningFailure(testResult.reason);

    return {
      allowed: testResult.allowed,
      message
    };
  }

  private getMessageForPositioningFailure(reason: PositioningFailureReasons): string {
    switch (reason) {
      case 'NOT_ENOUGH_ROOM':
        return t('Not enough room to place Train.');
      case 'OVERLAPS_EXISTING_TRAIN':
        return t('Another Train is in the way.');
    }
  }

  private onTrainDropped(id: number, segOffset: SegOffset | SegOffsetOriented, orientation?: Orientation): void {
    if (!this.scenarioEditManager.scenario.tracknetworkName) {
      return;
    }
    if (!orientation && 'orientation' in segOffset) {
      orientation = segOffset.orientation;
    }
    // TODO there should be some sort of common helper code/API for moving trains while editing and in a session.
    this.scenarioEditManager.updateScenarioTrainPosition(id, segOffset.segmentId, segOffset.offset, orientation);
  }

  private setObjectSelectionHandler(): void {
    // TODO the following is quite specific to objects, so should be in a class that is specifically about objects.
    this.context.map?.setObjectSelectionHandler(
      { type: MapType.PLAN, name: PLAN_VIEW_NAME },
      {
        onObjectHovered: () => { },
        onObjectClicked: id => this.onObjectClicked(id),
        onObjectDown: () => !this.selectingPath,
        onObjectDragged: id => {
          if (!this.scenarioEditManager.scenario.tracknetworkName) {
            return {
              allowed: false,
              message: t('Select a world before adding content.')
            };
          }
          const object = this.context.objects?.getObject(id);
          const allowed = object?.source.id === ObjectSource.SCENARIO.id;
          return {
            allowed,
            message: allowed ? t('Move') : t('Cannot move Track Objects.')
          };
        },
        onObjectDropped: (id, locationData) => {
          if (!this.scenarioEditManager.scenario.tracknetworkName) {
            return;
          }
          const object = this.context.objects?.getObject(id);
          // use previous track association orientation if exists, else default placement orientation otherwise alpha to beta
          const orientation = object?.trackAssociations?.length
            ? object.trackAssociations[0].orientation
            : object.objectType?.placementRules?.firstTrackAssocDefaultOrientation ?? Orientation.ALPHA_TO_BETA;
          this.scenarioEditManager.updateObjectPosition(
            object,
            locationData.lngLat,
            object?.objectType?.hasNoTrackAssociation
              ? []
              : [
                {
                  ...locationData.segOffset,
                  userScale: locationData.userScale,
                  orientation
                }
              ]
          );
        },
        onObjectTypeDragged: () => {
          if (!this.scenarioEditManager.scenario.tracknetworkName) {
            return {
              allowed: false,
              message: t('Select a world before adding content.')
            };
          }

          return {
            allowed: true,
            message: t('Add new Object.')
          };
        },
        onObjectTypeDropped: (type, locationData) => {
          if (!this.scenarioEditManager.scenario.tracknetworkName) {
            return;
          }
          let orientation = Orientation.ALPHA_TO_BETA;

          if (!isNil(type.placementRules?.firstTrackAssocDefaultOrientation)) {
            orientation = type.placementRules.firstTrackAssocDefaultOrientation;
          }

          this.scenarioEditManager.newObjectFromType(
            type,
            this.newObjectName(),
            locationData.lngLat,
            type?.hasNoTrackAssociation ? [] : [{ ...locationData.segOffset, orientation }]
          );
        },
        onTrackAssociationHovered: (id, data) => { },
        onTrackAssociationClicked: (id, data) => { },
        onTrackAssociationDown: (id, data) => !this.selectingPath,
        onTrackAssociationDragged: (id, segOffset) => ({
          allowed: false,
          message: t('Cannot move Track Association.')
        }),
        onTrackAssociationDropped: (id, segOffset) => { },
        onDragEnded: () => { }
      }
    );
  }

  private onObjectClicked(id: number): void {
    //Reset the objectDeletion subject
    this.scenarioEditManager.objectDeletion$.next(false);
    if (!this.selectingPath) {
      this.context.map.selectObject(id);
      //Deselect train
      this.context.trains?.selectTrain(null);
      this.openToolbox(ScenarioEditorConfigTab.OBJECT);
    }
  }

  private setPointSelectionHandler(): void {
    // TODO the following is quite specific to points, so should be in a class that is specifically about points.
    this.context.map?.setPointSelectionHandler(
      { type: MapType.PLAN, name: PLAN_VIEW_NAME },
      {
        onPointHovered: () => { },
        onPointClicked: id => this.onObjectClicked(id),
        onPointDown: () => true,
        onPointDragged: () => ({
          allowed: false,
          message: t('Cannot move Point.')
        })
      }
    );
  }

  override ngOnDestroy(): SuperCalled {
    this.selectedTrainSubscription?.unsubscribe();
    this.userConfigSub?.unsubscribe();

    this.selectedTrain$.complete();
    this.availableWorlds$.complete();
    this.availableSkins$.complete();
    this.trains$.complete();
    this.multimedia$.complete();
    this.rules$.complete();
    this.mainMapViewMapReady$.complete();
    this.resizeSubject.complete();
    this.sessionStartTime$.complete();
    this.rendered$.complete();
    this.environmentState$.complete();
    this.trainPanelSelectedTrainIdSubject.complete();
    this.showInPreviewDisabled$.complete();
    this.scenario$.complete();
    this.detailBadgeContentSubject.complete();
    this.detailBadgeHiddenSubject.complete();
    this.trainBadgeContentSubject.complete();
    this.trainBadgeHiddenSubject.complete();
    this.ruleBadgeHiddenSubject.complete();
    this.assessmentCriteria$.complete();
    this.ruleVariables$.complete();

    this.sessionLauncher?.destroy();
    this.simHubLoader?.destroy();
    this.triggerFormValidation$.complete();
    return super.ngOnDestroy();
  }

  initLoading(): void {
    const loading: Array<LoadingData> = [];
    this.loaded = false;

    const loaded = false;
    const context$ = this.contextSupplier.currentContext$();
    this.loadRules();
    const hasWorld$ = context$.pipe(
      switchMap(context => context?.data$ ?? of(null)),
      map((scenario: Scenario) => !!scenario?.tracknetworkName)
    );

    // if there's no world no need to try and load it
    const worldLoad$ = hasWorld$
      .pipe(switchMap(hasWorld => iif(() => hasWorld, context$.pipe(switchMap(context => context.world.world$.pipe(map(w => !isNil(w))))), of(true))))
      .pipe(startWith(false));
    const objects$ = hasWorld$
      .pipe(switchMap(hasWorld => iif(() => hasWorld, context$.pipe(switchMap(context => context.objects.data().pipe(mapTo(true)))), of(true))))
      .pipe(startWith(false));
    const trains$ = hasWorld$
      .pipe(switchMap(hasWorld => iif(() => hasWorld, context$.pipe(switchMap(context => context.trains.data().pipe(mapTo(true)))), of(true))))
      .pipe(startWith(false));
    const map$ = hasWorld$
      .pipe(
        switchMap(hasWorld =>
          iif(
            () => hasWorld,
            // world defined - need to wait for it to load as well
            context$.pipe(
              switchMap(context =>
                combineLatest([of(context), interval(1000)]).pipe(
                  map(([c, i]) => c.map.getMapComponent(this.PLAN_VIEW_SELECTOR) as any),
                  takeWhile(m => isNil(m), true),
                  filter(m => !isNil(m))
                )
              ),
              switchMap((component: PlanViewComponent) =>
                combineLatest([
                  // mapView is zoom, loading is once map is idle
                  component.mapViewReadySubject,
                  interval(1000).pipe(
                    map(n => component.loading === false),
                    takeWhile(finishedLoading => !finishedLoading, true)
                  )
                ]).pipe(map(([viewReady, idleReady]) => viewReady && idleReady))
              )
            ),
            // world not defined - don't wait for world to load
            context$.pipe(
              switchMap(context =>
                combineLatest([of(context), interval(1000)]).pipe(
                  map(([c, i]) => c.map.getMapComponent(this.PLAN_VIEW_SELECTOR) as any),
                  takeWhile(m => isNil(m), true),
                  filter(m => !isNil(m))
                )
              ),
              mapTo(true)
            )
          )
        )
      )
      .pipe(startWith(false));
    const world$ = combineLatest([worldLoad$, map$]).pipe(map(([worldReady, mapReady]) => worldReady && mapReady));

    loading.push({ icon: 'train', id: 'train', loaded, name: t('Trains'), obs: trains$ });
    loading.push({ icon: 'object', id: 'obj', loaded, name: t('Objects'), obs: objects$ });
    loading.push({ icon: 'world', id: 'world', loaded, name: t('World'), obs: world$ });
    this.loadingModules = loading;
  }

  onLoaded(): void {
    // FIXME there's a bug where this is triggered every update - this early return prevents that from causing side effects
    if (this.loaded) {
      return;
    }
    this.loaded = true;
    // if there's a simulated train lets start the map there without selecting it
    const selectedTrain = this.trains$.getValue()?.find(train => train.driverType === DriverType.HUMAN)
      ?? this.trains$.getValue()?.find(train => train.driverType === DriverType.ROBOT);
    const location = selectedTrain?.vehicles?.[0]?.position?.lnglat?.[0];
    if (location) {
      this.context.map.mapGoto(location, ZoomLevel.STATION);
    }
    this.selectTrain(selectedTrain);
  }

  renderViews(): void {
    this.renderMinimap();
    this.renderLineView();
    this.renderMainView();
    this.rendered$.next(true);
  }

  renderMinimap(): ComponentRef<MiniMapDynamicComponent> {
    const minimapData: MapChildData = Object.assign({}, this.config.miniView.data);
    minimapData.resize$ = this.resize$;
    const minimap = this.renderChild(this.miniView, this.config.miniView.component, minimapData);
    // FIXME For some reason minimap is now undefined during testing. It's not clear what change caused this, which is slightly concerning.
    this.miniMap = minimap?.instance;
    return minimap;
  }

  renderLineView(): ComponentRef<DynamicComponent<MapChildData, null>> {
    const lineData = this.generateLineViewData();
    return this.renderChild(this.lineView, this.config.lineView.component, lineData);
  }

  public filterLayers(layers: Array<ObjectLayer>): void {
    this.context?.map?.filterObjects(layers);
  }

  renderMainView(): ComponentRef<DynamicComponent<MapChildData, MainMapOutputData>> {
    const context$ = this.contextSupplier.currentContext$();
    const hasWorld$ = context$.pipe(
      switchMap(context => context?.data$ ?? of(null)),
      distinctUntilChanged((prev: Scenario, curr: Scenario) => {
        const prevObjects: Array<ObjectContainer> = prev?.world?.object;
        const currObjects: Array<ObjectContainer> = curr?.world?.object;
        const prevObjModifications: Array<ObjectModification> = prev?.world?.objectModification;
        const currObjModifications: Array<ObjectModification> = curr?.world?.objectModification;
        if (prevObjects?.length !== currObjects?.length || prevObjModifications?.length !== currObjModifications?.length) {
          return false;
        }
        for (const currentObj of currObjects) {
          const prevObj = prevObjects.find(c => c.id === currentObj.id);
          if (!isEqual(currentObj, prevObj)) {
            return false;
          }
        }
        for (const currentObjMod of currObjModifications) {
          const prevObjMod = prevObjModifications.find(c => c.name === currentObjMod.name);
          if (!isEqual(currentObjMod, prevObjMod)) {
            return false;
          }
        }
        return true;
      }),
      map((scenario: Scenario) => !!scenario?.tracknetworkName)
    );
    const worldImages$ = this.getUsedObjectImages();
    const noWorldImages$ = of([]);
    const images$ = hasWorld$.pipe(switchMap(hasWorld => iif(() => hasWorld, worldImages$, noWorldImages$)));
    const mainData = createPlanViewData(this.resize$, images$);
    const outputs: MainMapOutputData = {
      mapViewMapReady: {
        next: mapViewReady => {
          this.mainViewMapReady(mapViewReady);
        },
        complete: () => { },
        error: () => { }
      }
    };
    const mainView = this.renderChild(this.mainView, this.config.planView.component, mainData, outputs);
    this.mainMap = mainView?.instance;
    return mainView;
  }

  generateLineViewData(): LineViewMapChildData {
    const d$ = this.contextSupplier.currentContext$();
    const data: LineViewMapChildData = {
      resize$: this.resize$,
      features$: d$.pipe(
        filterTruthy(),
        switchMap(d => d.objects.data())
      ),
      trains$: d$.pipe(
        filterTruthy(),
        switchMap(d => d.trains.data())
      )
    };
    return data;
  }

  loadFeatureImages(objects$: Observable<Array<ObjectContainer>>): void {
    if (!objects$) {
      this.logger.warn(`[ScenarioEditor] no features supplied.`);
      return;
    }

    this.subscription.add(
      objects$
        .pipe(
          filterTruthy(),
          switchMap(objects => {
            const images = ObjManager.getSelectedFeatureImages(objects as any);
            return ObjManager.initFeatureImages(images);
          })
        )
        .subscribe(x => {
          // We need to subscribe so the image processing is triggered.
          // We don't need to do anything with the result.
        })
    );
  }

  // FIXME this duplicates SessionComponent
  public mainViewMapReady(ready: boolean): void {
    // FIXME Not sure we need/want to do this scenario check here.
    if (ready && this.scenario$.getValue()) {
      const planViewMap = this.mainMap.map;
      this.mainMapViewMapReady$.next(true);
      this.miniMap.setParentMap(planViewMap);

      // FIXME this doesn't account for the user changing the selected world.
      this.worldDefService.getNetworkDefinitionManager(this.scenario$.value.tracknetworkName).then(mgr => {
        this.cameraControlsLayer.setNetworkDefinitionManager(mgr);
        this.cameraControlsLayer.setMap(planViewMap);
      });
    }
  }

  // FIXME this duplicates SessionComponent
  public resizeEnd(event: any): void {
    this.resizeSubject.next(undefined);
  }

  processScenarioUpdate(scenario: Scenario): void {
    const prevScenario = this.scenario$.getValue();

    const prevTrack = prevScenario?.tracknetworkName;
    const trackChanged = prevTrack !== scenario?.tracknetworkName;
    if (scenario?.tracknetworkName) {
      this.showMapNow();
    } else {
      this.hideMapNow(t('Select a world to get started.'));
    }
    if (!scenario?.tracknetworkName || !scenario?.tracknetworkSkinName) {
      this.showDetailBadgeWarning();
    }

    this.scenario$.next(scenario);

    const tab = this.tabService.getTabGroupItem(SCENARIOS_CARD_DATA.id, scenario.id);

    if (!!tab && tab.data.name !== scenario.name) {
      tab.data.name = scenario.name;
    }

    Object.getOwnPropertyNames(scenario.environment).forEach(p => this.environmentState.set(p as EnvironmentProperty, (scenario.environment as any)[p]));
    this.environmentState$.next(this.environmentState);

    const worldSelectionLocked = this.scenarioEditService.getEditManager(scenario.id).isWorldSelectionLocked();
    this.scenarioDetails.worldSelectionLocked = worldSelectionLocked;
    this.availableWorlds$.next(worldSelectionLocked ? [scenario.tracknetworkName] : this.allTracks);

    if (trackChanged) {
      const skins = scenario.tracknetworkName ? this.trackDataService.getTracks().get(scenario.tracknetworkName).skin : [];
      this.availableSkins$.next(skins);

      this.onWorldChange(scenario);
    }

    this.multimediaItems = asArray(scenario.multimedia);
    this.multimedia$.next(this.multimediaItems);

    this.assessmentCriteria$.next(asArray(scenario.reportData));
    this.ruleVariables$.next(asArray(scenario.ruleVariables));

    // naming is a bit tongue in cheek :P
    const usefulRules = scenario.rule.map(r => ScenarioRuleFactory.createScenarioRule(r));
    this.rules$.next(usefulRules.filter(r => !r.getTemplate()?.phantom));
    this.ruleTemplates = usefulRules?.map(r => r.getTemplate());

    if (!this.scenarioEditManager?.unsavedChanges) {
      this.sessionLauncher?.setScenario(scenario);
    }
  }

  @HostListener('window:keydown.control.z', ['$event'])
  undo(event: KeyboardEvent): void {
    event.preventDefault();
    this.scenarioEditManager.undo();
  }

  @HostListener('window:keydown.control.y', ['$event'])
  redo(event: KeyboardEvent): void {
    event.preventDefault();
    this.scenarioEditManager.redo();
  }

  @HostListener('window:keydown.control.s', ['$event'])
  save(event?: KeyboardEvent): void {
    event?.preventDefault();
    this.scenarioEditManager.saveScenario();
    this.triggerFormValidation$.next(undefined);
  }

  @HostListener('window:keydown.delete', ['$event'])
  delete(event: KeyboardEvent): void {
    event?.preventDefault();
    if (this.trainPanelSelectedTrainIdSubject.getValue()) {
      this.scenarioEditManager.deleteScenarioTrain(this.trainPanelSelectedTrainIdSubject.getValue());
    }
    if (this.context.map.selectedObjectSubject.getValue()) {
      this.scenarioEditManager.objectDeletion$.next(true);
      this.scenarioEditManager.deleteObject(this.context.map.selectedObjectSubject.getValue().id);
    }
  }

  // TODO These catchalls for handling dragged objects should call into the tools that have been included in the editor.

  public onDrag(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
    ev.dataTransfer.dropEffect = 'move';
    this.dragging = true;

    const data = extractJSONData<DragData>(ev.dataTransfer);

    if (!data) return;
    if (!this.scenarioEditManager.scenario.tracknetworkName) {
      this.dragFeedback = {
        allowed: false,
        message: t('Select a world before adding content.')
      };
      return;
    }

    if (this.scenarioEditorExtensionsToken && this.scenarioEditorExtensionsToken.dragChecker(this.scenarioEditManager.getScenario(), data)) {
      this.dragFeedback = this.scenarioEditorExtensionsToken.dragFeedback(this.scenarioEditManager.getScenario(), data);
    } else if (isConsistListItemData(data)) {
      const consistListItem = data.data as ConsistListItem;

      this.consistDataService
        .data()
        .pipe(takeOneTruthy())
        .subscribe(consists => {
          // Note that we cannot use the object being dragged, because some of its contents (e.g. internal maps) get broken in transit.
          const consist = consists.find(c => c.id === consistListItem.consist.id);

          const testResult = this.scenarioEditManager.newScenarioTrainFromConsistAllowed(consist);
          let message: string = testResult.allowed ? t('Add Train') : t('Cannot add this Train');

          switch (testResult.reason) {
            case 'TOTAL_TRAIN_LIMIT_REACHED':
              message = t('Cannot add more Trains');
              break;
          }

          this.dragFeedback = {
            allowed: testResult.allowed,
            message
          };
        });
    } else if (isDraggedMultimediaDataItem(data)) {
      this.dragFeedback = handleDraggedMultimediaDataItem(data, this.multimediaItems);
    } else if (isDraggedRuleTemplate(data)) {
      this.dragFeedback = handleDraggedRuleTemplate(data, this.ruleTemplates);
    } else if (isDraggedReportItemData(data)) {
      this.dragFeedback = handleDraggedReportItemData(data);
    } else {
      this.dragFeedback = {
        allowed: false,
        message: t('Unknown data type!')
      };
    }
  }

  public onDragEnter(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
    this.dragging = true;
  }

  public onDragLeave(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
    this.dragging = false;
  }

  public onDrop(ev: DragEvent): void {
    ev.preventDefault();
    ev.stopPropagation();
    this.dragging = false;
    if (!this.scenarioEditManager.scenario.tracknetworkName) {
      return;
    }
    const data = extractJSONData<any>(ev.dataTransfer);

    if (this.scenarioEditorExtensionsToken && this.scenarioEditorExtensionsToken.dragChecker(this.scenarioEditManager.getScenario(), data)) {
      this.scenarioEditorExtensionsToken.onDrop(this.scenarioEditManager.getScenario(), data);
    } else if (isConsistListItemData(data)) {
      const consistListItem = data.data as ConsistListItem;
      this.consistDataService
        .data()
        .pipe(takeOneTruthy())
        .subscribe(consists => {
          // Note that we cannot use the object that was dragged in, because some of its contents (internal maps) get broken in transit.
          const consist = consists.find(c => c.id === consistListItem.consist.id);

          this.scenarioEditManager.newScenarioTrainFromConsist(consist, this.newScenarioTrainName());
        });

      // TODO should open to the correct subscreen as well (probably the train editor)
      this.openToolbox(ScenarioEditorConfigTab.TRAIN);
    } else if (isDraggedMultimediaDataItem(data)) {
      this.multimediaDataService.reloadData();
      const multimediaDataItem = data.data as MultimediaDataItem;
      let i = 0;
      this.multimediaDataService
        .data()
        .pipe(
          take(2),
          timeout(5000), // 5000 milliseconds = 5 seconds
          catchError(error => {
            // Handle timeout error here
            console.error('Timeout error:', error);
            return of([]); // Return an empty array as a fallback value
          })
        )
        .subscribe(multimediaItems => {
          // Skip the first value, as it's the initial value
          if (i === 0) {
            i++;
            return;
          }
          this.possibleMultimediaItems = multimediaItems;

          // Check that you can add the multimedia because it exists
          if (!this.possibleMultimediaItems.find(m => m.id === multimediaDataItem.id)) {
            this.snackbar.open(this.translate.instant(t('Item not found: The item you are trying to add does not exist in the library.')), t('Dismiss'));
            return;
          }
        });

      this.scenarioEditManager.addMultimedia(multimediaDataItem);
      this.openToolbox(ScenarioEditorConfigTab.MULTIMEDIA);
    } else if (
      isDraggedRuleTemplate(data) &&
      // FIXME we shouldn't assume the last dragged thing is the thing being dropped. There may be funky corner cases waiting to bite us.
      this.dragFeedback.allowed
    ) {
      // we reload the data in case something changed. A bit annoying since the data will be reload and displayed AFTER we check if it's allowed.
      // The thing is - These reloads take a bit of time and we don't want to wait for them to finish before we can check if it's allowed.
      // And with the way observable works, we would have to wait for a new message that might not come in case the reload does not go through.
      this.ruleTemplateService.reloadData();
      const ruleTemplate = data.data as RuleTemplate;
      let i = 0;
      this.ruleTemplateService
        .data()
        .pipe(
          take(2),
          timeout(5000), // 5000 milliseconds = 5 seconds
          catchError(error => {
            // Handle timeout error here
            console.error('Timeout error:', error);
            return of([]); // Return an empty array as a fallback value
          })
        )
        .subscribe(ruleTemplates => {
          // Skip the first value, as it's the initial value
          if (i === 0) {
            i++;
            return;
          }
          this.possibleRuleTemplates = ruleTemplates;

          // Check that you can add the rule
          if (!this.possibleRuleTemplates.find(rt => rt.id === ruleTemplate.id)) {
            this.snackbar.open(this.translate.instant(t('Item not found: The item you are trying to add does not exist in the library.')), t('Dismiss'));
            return;
          }
        });
      // =====================================
      const mmId = ruleTemplateHasMultimedia(ruleTemplate);
      this.scenarioEditManager.addScenarioRule(this.newScenarioRuleName(), '', ruleTemplate.id, toVersionString(ruleTemplate.version), mmId);
      this.openToolbox(ScenarioEditorConfigTab.RULE);
    } else if (isDraggedReportItemData(data) && this.dragFeedback.allowed) {
      this.assessmentCriteriaService.reloadData();
      const assessmentCriteriaData = data.data as ReportItem;
      forkJoin([this.assessmentCriteriaService.reportItems$.pipe(take(1)), this.assessmentCriteriaService.eventItems$.pipe(take(1))])
        .pipe(
          timeout(5000), // 5000 milliseconds = 5 seconds
          catchError(error => {
            // Handle timeout error here
            console.error('Timeout error:', error);
            return of([]); // Return an empty array as a fallback value
          })
        )
        .subscribe(([assessmentCriteriaItems, assessmentEventItems]) => {
          this.possibleAssessmentCriteriaItems = assessmentCriteriaItems;
          this.possibleAssessmentEventItems = assessmentEventItems;

          let item: ReportItem | undefined;

          this.possibleAssessmentCriteriaItems.forEach(a => {
            if (isNil(item)) {
              item = a.reportItemList.find(c => c.name === assessmentCriteriaData.name);
            }
          });

          // Check that you can add the multimedia because it exists
          if (isNil(item)) {
            this.snackbar.open(this.translate.instant(t('Item not found: The item you are trying to add does not exist in the library.')), t('Dismiss'));
            return;
          } else {
            const baseName = this.translate.instant(t('New Assessment'));
            const scenario = this.scenario$.getValue();

            this.scenarioEditManager.addScenarioAssessmentCriteria(
              isNil(scenario) ? baseName : uniqueItemName(scenario.reportData, r => r.displayName, baseName),
              assessmentCriteriaData,
              this.possibleAssessmentEventItems
            );
          }
        });
    }
  }

  /**
   * Generates Scenario rule names that don't conflict.
   * Name will be 'New Rule' by default.
   *
   * @param name this will be 'New Rule' if you don't supply it.
   */
  private newScenarioRuleName(name?: string): string {
    const baseName = this.translate.instant(t('New Rule'));
    const scenario = this.scenario$.getValue();
    if (!scenario) {
      return baseName;
    }

    return uniqueItemName(scenario.rule, r => r.displayName, baseName, name);
  }

  /**
   * Generates Scenario Train names that don't conflict.
   * Name will be 'New Train' by default.
   *
   * @param name this will be 'New Train' if you don't supply it.
   */
  private newScenarioTrainName(name?: string): string {
    const baseName = this.translate.instant(t('New Train'));
    const scenario = this.scenario$.getValue();
    if (!scenario) {
      return baseName;
    }

    return uniqueItemName(scenario.scenarioTrains.scenarioTrain, r => r.name, baseName, name);
  }

  /**
   * Generates Object names that don't conflict.
   * Name will be 'New Object' by default.
   *
   * @param name this will be 'New Object' if you don't supply it.
   */
  private newObjectName(name?: string): string {
    const baseName = this.translate.instant(t('New Object'));
    const scenario = this.scenario$.getValue();
    if (!scenario) {
      return baseName;
    }

    return uniqueItemName(scenario.world.object, r => r.name, baseName, name);
  }

  /**
   * Open our toolbox (on the right) to the specified tab index.
   *
   * @param tab the reference to the tab
   */
  openToolbox(tab: ScenarioEditorConfigTab | string, selectedId?: string | number): void {
    let tabName: string = null;

    if (typeof tab === 'string') {
      tabName = tab;
    } else {
      tabName = tab.id;
    }

    if (tabName) {
      this.toolboxContainer.openToolbox(tabName);
    }

    if (selectedId !== null && selectedId !== undefined) {
      if (tabName === 'rule') {
        const state = this.context.uiState.getStateModel(RULES_PANEL_SELECTOR, (): any => null);
        if (state) {
          state.selectedId = selectedId;
        }
      }
    }
    setTimeout(() => this.cd.markForCheck());
  }

  public selectTrain(train: UsefulTrain | number): void {
    if (isNumber(train)) {
      this.context.trains.selectTrainById(train);
      this.trainPanelSelectedTrainIdSubject.next(train);
    } else {
      this.context.trains.selectTrain(train);
      this.trainPanelSelectedTrainIdSubject.next(train?.id);
    }
    //Deselect Object
    this.context.map?.selectObject(null);
    this.openToolbox(ScenarioEditorConfigTab.TRAIN);
  }

  public findSelectedTrain(): void {
    this.selectedTrain$.pipe(takeOneTruthy(undefined, 200)).subscribe(
      selectedTrain => {
        const location = selectedTrain?.vehicles?.[0]?.position?.lnglat?.[0];
        if (location) {
          this.context.map.mapGoto(location, ZoomLevel.STATION);
        }
      },
      err => this.logger.warn(`Tried to find a train without selecting one first!`)
    );
  }

  handleSelectedTrainChange(): void {
    // No op needed for now.
  }

  handleMapTogglesChange(): void {
    this.subscription.add(
      this.contextSupplier
        .currentContext$()
        .pipe(
          filter(m => !!m),
          switchMap(m => m.map.mapTogglesSubject)
        )
        .subscribe(toggles => {
          this.followingTrain = toggles.follow;
          this.showingTrainPath = toggles.path;
        })
    );
  }

  /**
   * Following a train will goto it on the map, and then "lock" the camera to it from then on.
   */
  public followTrain(): void {
    this.findSelectedTrain();
    this.context.map.followTrain(!this.followingTrain);
    this.logger.log('Follow train toggled ' + (this.followingTrain ? 'on' : 'off'));
  }

  private handlePathChange(selectPath?: boolean): void {
    if (this.pathSectionHandler) {
      if (this.selectingPath) {
        this.context.map.setTrackSelectionHandler(this.PLAN_VIEW_SELECTOR, this.pathSectionHandler);
        this.pathSectionHandler.enable();
      } else {
        this.context.map.clearTrackSelectionHandler(this.PLAN_VIEW_SELECTOR);
        this.pathSectionHandler.disable();
      }
    }
  }

  public selectPath(): void {
    this.selectingPath = !this.selectingPath;
    this.handlePathChange();
    this.logger.log('Select path toggled ' + (this.selectingPath ? 'on' : 'off'));
  }

  public selectStation(station: ObjectContainer): void {
    // FIXME: If there are multiple boundaries, where do you want the position to be? PRDOKS-2535
    // The position right now is at the first point of the first boundary.
    const position: Array<number> = station?.boundaries?.[0]?.[0] ?? station.location.lnglat;
    this.context.map.mapGoto([position[0], position[1]], ZoomLevel.STATION);
  }

  public selectMainView(view: string): void {
    this.mainViewType = view as SessionMainView;
  }

  private showMapNow(): void {
    this.showMap = { show: true };
  }

  private hideMapNow(message?: string): void {
    this.showMap = { show: false, message };
  }

  /**
   * show a warning on the detail tab badge on the right toolbar.
   *
   * @param content (default !) what to show in the badge. Only room for 1 character.
   */
  private showDetailBadgeWarning(content = '!'): void {
    this.detailBadgeContentSubject.next(content);
    this.detailBadgeHiddenSubject.next(false);
  }

  private hideDetailBadgeWarning(): void {
    this.detailBadgeContentSubject.next(null);
    this.detailBadgeHiddenSubject.next(true);
  }

  private showTrainBadgeWarning(content = '!'): void {
    this.trainBadgeContentSubject.next(content);
    this.trainBadgeHiddenSubject.next(false);
  }

  private hideTrainBadgeWarning(): void {
    this.trainBadgeContentSubject.next(null);
    this.trainBadgeHiddenSubject.next(true);
  }

  /**
   * Get images currently used by this scenario's objects.
   */
  private getUsedObjectImages(): Observable<Array<Image>> {
    return this.contextSupplier.currentContext$().pipe(
      switchMap(context =>
        combineLatest([
          of(context).pipe(switchMap(m => m.objects?.getObjectTypes$())),
          of(context).pipe(map(m => m.objects)),
          this.imageService.getImageAddedUpdates$(true, GlobalImageStoreKey.SMALL)
        ])
      ),
      map(([objectTypes, objManager, images]) => {
        const projectImages: Array<Image> = [];
        if (this.overrideObjectMapRenderer?.images?.length) {
          this.overrideObjectMapRenderer.images.forEach(i => {
            const image = this.imageService.getGlobalImage(GlobalImageStoreKey.SMALL, `/Features/${i}`);
            if (image) {
              projectImages.push({ name: image.id, image });
            }
          });
        }
        const loadImages = objManager.consolidateObjectTypeImages(objectTypes, images, projectImages);
        return loadImages;
      })
    );
  }

  loadRules(): void {
    // TODO ScenarioEditor shouldn't directly need to init the rule handler singeleton
    const rbSub = this.ruleBlockService.data().subscribe(blocks => {
      ScenarioRuleFactory.setRuleBlocks(blocks);
    });
    const rtSub = this.ruleTemplateService.data().subscribe(templates => {
      ScenarioRuleFactory.setRuleTemplates(templates);
    });
    this.subscription.add(rbSub);
    this.subscription.add(rtSub);
  }

  startPreview(): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy())
      .subscribe(context => {
        context.data$.pipe(takeOneTruthy()).subscribe(scenario => {
          this.scenarioEditService.openPreview(scenario.id);
          this.sessionLauncher?.startPreview();
        });
      });
  }

  private onWorldChange(scenario: Scenario): void {
    const skins = scenario.tracknetworkName ? this.trackDataService.getTracks().get(scenario.tracknetworkName).skin : [];
    this.availableSkins$.next(skins);

    // If the track changed, we create a new path handler because the map might have changed
    this.createPathSelectionHandler();
    // If the track changed, we reset the path tool since it's no longer valid.
    this.selectingPath = false;
    this.handlePathChange();

    // this.showMap = !!scenario?.tracknetworkName;
    if (scenario?.tracknetworkName) {
      this.showMapNow();
      this.pathToolDisabled = false;
      this.stationsDisabled = false;
    } else {
      this.hideMapNow(t('Please select a world to continue.'));
      this.pathToolDisabled = true;
      this.stationsDisabled = true;
    }

    if (scenario?.tracknetworkName) {
      this.context.map.clear();
      // this.context.map.clearSpotlights();
      // this.context.map.selectObject(null);
      // this.context.map.clearHighlightedPath();
      // first clear world so any listeners don't show stale data while the new world is loading (which can take up to 10 seconds)
      (this.context.world.world$ as BehaviorSubject<WorldData>).next(null);
      this.cameraControlsLayer.setNetworkDefinitionManager(null);
      this.cameraControlsLayer.setMap(null);
      this.worldDefService.loadWorld(scenario?.tracknetworkName).then(w => {
        this.worldDefService.getNetworkDefinitionManager(scenario?.tracknetworkName).then(mgr => {
          this.cameraControlsLayer.setNetworkDefinitionManager(mgr);
          this.cameraControlsLayer.setMap(this.mainMap.map);
          // FIXME use of context is a bit suspect here
          (this.context.world.world$ as BehaviorSubject<WorldData>).next(w);
        });
      });
      this.renderMainView();
    }
  }

  private updateEditorTabs(uiModels: UiStateModelManager, driverList$: Observable<Array<DriverListItemDriver>>): void {
    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.DETAIL.id, {
      data: this.scenarioDetails,
      handlers: {
        initialScoreUpdated: (n: number) => this.scenarioEditManager.initialScoreUpdated(n),
        targetScoreUpdated: (n: number) => this.scenarioEditManager.targetScoreUpdated(n),
        nameUpdated: (n: string) => this.scenarioEditManager.setScenarioName(n),
        worldSelected: (w: string) => this.scenarioEditManager.setSelectedWorld(w),
        skinSelected: (s: string) => {
          if (this.updatedSkin !== s) {
            this.previousSkin = this.updatedSkin;
            this.updatedSkin = s;
            this.scenarioEditManager.setSelectedSkin(s);
          }
        },
        dateTimeSelected: (dt: string) => this.scenarioEditManager.setDateTime(dt),
        descriptionUpdated: (d: string) => this.scenarioEditManager.setScenarioDescription(d),
        subjectUpdated: (d: string) => this.scenarioEditManager.setSubject(d),
        showInPreviewChanged: (p: boolean) => this.dateTimeShowInPreviewChanged(p),
        disableSave: (d: boolean) => this.disableSaveDetails(d),
        scenarioAssessmentChanged: (a: boolean) => this.scenarioEditManager.scenarioAssessmentChanged(a),
        scenarioActivationStatusChanged: (a: boolean) => this.scenarioEditManager.scenarioActivationStatusChanged(a)
      },
      badgeContent$: this.detailBadgeContent$,
      badgeHidden$: this.detailBadgeHidden$
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.TRAIN.id, {
      data: {
        netDef$: this.context.world.netDef$,
        pathTrainId$: this.context.map.getPathTrainId$(),
        pathFinder$: this.context.pathFinder$,
        scenarioEditManager: this.scenarioEditManager,
        selectedTrainId$: this.trainPanelSelectedTrainIdSubject,
        trains$: this.context.trains.data(),
        world$: this.context.world.world$,
        userConfig$: this.userConfigService.config$(),
        driverList$: driverList$.pipe(shareReplayOne()),
        uiModels,
        scenario$: this.scenario$
      },
      handlers: {
        trainSelect: (tr: UsefulTrain) => {
          if (tr) {
            this.selectTrain(tr);
          } else {
            this.trainPanelSelectedTrainIdSubject.next(null);
          }
        },
        missingTrainDetails: (val: boolean) => this.updateTrainBadge(val)
      },
      badgeContent$: this.trainBadgeContent$,
      badgeHidden$: this.trainBadgeHidden$
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.ENVIROMENT.id, {
      data: {
        environmentService: this.environmentService,
        showInPreviewEnabled: this.config.previewEnabled,
        showInPreviewDisabled$: this.showInPreviewDisabled$,
        isEditor: true
      },
      handlers: {
        showInPreviewChanged: (p: boolean) => this.environmentShowInPreviewChanged(p)
      }
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.OBJECT.id, {
      data: {
        world$: this.context.world.world$,
        objectEditManager: this.scenarioEditManager,
        uiModels,
        objectSource: ObjectSource.SCENARIO
      },
      handlers: {
        openTab: (tabInfo: { tabName: string; detailId?: string | number }) => this.openToolbox(tabInfo.tabName, tabInfo.detailId)
      },
      badgeContent$: this.scenario$.pipe(
        map(scenario => {
          const trackObjectsLength = scenario?.world?.objectModification?.filter(om => !isObjectPropertiesValid(om.properties))?.length ?? 0;
          const scenarioObjectsLength = scenario?.world?.object?.filter(o => !isObjectContainerPropertiesValid(o, false))?.length ?? 0;
          const totalLength = trackObjectsLength + scenarioObjectsLength;
          return totalLength ? totalLength : null; // don't want to render 0
        })
      )
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.MULTIMEDIA.id, {
      data: {
        multimedia$: this.multimedia$,
        multimediaSourceType: MultimediaSourceType.SCENARIO,
        searchable: true,
        uiModels
      },
      handlers: {
        favourite: (f: any) => this.logger.trace('multimedia favourited', f),
        deleteMultimedia: (m: MultimediaItem) => this.deleteMultimedia(m),
        nameChange: (c: MultimediaItem) => this.renameMultimedia(c)
      }
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.RULE.id, {
      data: {
        rules$: this.rules$,
        scenarioEditManager: this.scenarioEditManager,
        uiModels
      },
      badgeContent$: this.rules$.pipe(
        map(rule => {
          const length = rule?.filter(r => !r.isLatest() || !r.isValid())?.length;
          this.ruleBadgeHiddenSubject.next(isNil(length) || length === 0);
          this.scenarioEditManager.updateInvalidRule(!isNil(length) && length > 0);
          return length ? length : null;
        })
      ),
      badgeHidden$: this.ruleBadgeHidden$
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.RULE_VARIBLES.id, {
      data: {
        ruleVariables$: this.ruleVariables$,
        scenarioEditManager: this.scenarioEditManager,
        uiModels
      }
    });

    if (isNil(this.assessmentCriteriaService)) {
      changeVisibilityDynamicVerticalToolboxContainerTab(this.config.tabs, ScenarioEditorConfigTab.ASSESSMENT_CRITERIA.id, false);
    } else {
      updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.ASSESSMENT_CRITERIA.id, {
        data: {
          assessmentCriteria$: this.assessmentCriteria$,
          scenarioAssessmentCriteriaEditManager: this.scenarioEditManager
        }
      });
    }
    this.cd.markForCheck();
    setTimeout(() => this.cd.markForCheck());
  }

  private updateLibraryTabs(uiModels: UiStateModelManager, driverList: Observable<Array<DriverListItemDriver>>): void {
    const expandable = signal(false);
    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.LIBRARY.id, {
      data: {
        uiModels,
        expandable
      }
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.SIM_TRAINS_LIBRARY.id, {
      data: {
        title: t('Trains'),
        icon: 'train',
        consists$: this.consistDataService.data().pipe(filterTruthy(), shareReplayOne()),
        uiModels,
        expandable
      }
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.DRIVERS_LIBRARY.id, {
      data: {
        drivers$: driverList.pipe(shareReplayOne()),
        uiModels,
        expandable
      }
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.RULES_LIBRARY.id, {
      data: {
        ruleTemplates$: this.ruleTemplateService.latestVersionData().pipe(filterTruthy(), shareReplayOne()),
        uiModels,
        expandable
      }
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.OBJECTS_LIBRARY.id, {
      data: {
        objects$: this.objectTypeService.placementTypes$({ domain: 'editor', key: 'scenario' }).pipe(filterTruthy(), shareReplayOne()),
        uiModels,
        expandable
      }
    });

    updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.MULTIMEDIA_LIBRARY.id, {
      data: {
        multimedia$: this.multimediaDataService.data().pipe(filterTruthy(), shareReplayOne()),
        uiModels,
        expandable
      }
    });

    if (isNil(this.assessmentCriteriaService)) {
      changeVisibilityDynamicVerticalToolboxContainerTab(this.config.tabs, ScenarioEditorConfigTab.ASSESSMENT_CRITERIA_LIBRARY.id, false);
    } else {
      updateDynamicVerticalToolboxContainerTabsConfig(this.config.tabs, ScenarioEditorConfigTab.ASSESSMENT_CRITERIA_LIBRARY.id, {
        data: {
          assessmentCriteriaGroupItems$: this.assessmentCriteriaService.reportItems$.pipe(filterTruthy(), shareReplayOne()),
          uiModels,
          expandable
        }
      });
    }
  }
}
