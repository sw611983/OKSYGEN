/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { Observable, of } from 'rxjs';

import { asyncData } from '@oksygen-common-libraries/common/testing';
import {
  DragDropZoneHighlightComponent,
  LoadingComponent,
  ToolbarComponent
} from '@oksygen-sim-train-libraries/components-services/common';
import {
  defaultScenarioEditorConfig,
  OksygenSimTrainScenarioEditModule,
  ScenarioEditorTopToolbarComponent,
  ScenarioEditService
} from '@oksygen-sim-train-libraries/components-services/editors/scenarios';
import { LineViewComponent, MiniMapComponent, PlanViewComponent } from '@oksygen-sim-train-libraries/components-services/maps';
import { OksygenSimTrainSessionModule } from '@oksygen-sim-train-libraries/components-services/session';
import {
  configureSimTrainTestingModule,
  SCENARIO_EDITOR_CONTEXT_PROVIDERS,
  ScenarioEditServiceStub,
  TEST_SCENARIO_ID
} from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainUserConfigurationModule } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { TrackData, TrackDataService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ScenarioEditorComponent } from './scenario-editor.component';
import { SessionLoggingConfigToken } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

describe('ScenarioEditorComponent', () => {
  let component: ScenarioEditorComponent;
  let fixture: ComponentFixture<ScenarioEditorComponent>;
  const activeRouteMap = new Map();
  activeRouteMap.set('id', TEST_SCENARIO_ID);

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainScenarioEditModule, OksygenSimTrainUserConfigurationModule, OksygenSimTrainSessionModule],
        providers: [
          ...SCENARIO_EDITOR_CONTEXT_PROVIDERS,
          {
            provide: ScenarioEditService,
            useClass: ScenarioEditServiceStub
          },
          {
            provide: TrackDataService,
            useValue: {
              reloadData(): void {},
              data: (): Observable<Map<string, TrackData>> => asyncData(null),
              getTracks: (): Map<string, TrackData> => new Map<string, TrackData>()
            }
          },
          {
            provide: ActivatedRoute,
            useValue: {
              paramMap: of(activeRouteMap),
              data: of(defaultScenarioEditorConfig())
            }
          },
          {
            provide: SessionLoggingConfigToken,
            useValue: {}
          }
        ],
        declarations: [
          ScenarioEditorComponent,
          ScenarioEditorTopToolbarComponent,
          ToolbarComponent,
          DragDropZoneHighlightComponent,
          LoadingComponent,
          LineViewComponent,
          PlanViewComponent,
          MiniMapComponent
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioEditorComponent);
    component = fixture.componentInstance;
    component.config = defaultScenarioEditorConfig();
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
