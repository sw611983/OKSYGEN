/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { XmlJsonUtil } from '@oksygen-common-libraries/data-access';
import { DataAccessServiceDataKey } from '@oksygen-common-libraries/data-access/testing';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { OksygenSimTrainScenarioModule } from '@oksygen-sim-train-libraries/components-services/scenarios';
import {
  configureSimTrainTestingModule,
  createTestScenario,
  createTestScenarioXml
} from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainScenarioEditModule } from '../../scenario-edit.module';
import { ScenarioBrowserService } from '../../services/scenario-browser.service';
import { ScenarioBrowserComponent } from './scenario-browser.component';

describe('ScenarioBrowserComponent', () => {
  const scenario = createTestScenario();
  const scenarioXml = createTestScenarioXml();

  let component: ScenarioBrowserComponent;
  let fixture: ComponentFixture<ScenarioBrowserComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainScenarioModule, OksygenSimTrainEditorsModule, OksygenSimTrainScenarioEditModule],
      providers: [ScenarioBrowserService]
    },
    undefined,
    new Map<DataAccessServiceDataKey, any>([
      [{ query: 'get_scenario_details', parameters: { id: scenario.id, scenario_id: null } }, XmlJsonUtil.convertObjectToXml(scenarioXml, 'scenario')],
      [
        { query: 'get_scenario_details', parameters: { id: null, scenario_id: scenario.scenarioId } },
        XmlJsonUtil.convertObjectToXml(scenarioXml, 'scenario')
      ],
      [{ query: 'get_scenario_list' }, XmlJsonUtil.convertObjectToXml({ scenario: [scenarioXml] }, 'scenarios')]
  ])).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // FIXME Having some problems with the File Manager which I'm not sure how to solve..
  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
