/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, NgZone, OnDestroy, OnInit, signal, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, combineLatest, forkJoin, Observable, of, Subject, Subscription } from 'rxjs';
import { catchError, filter, map, switchMap, take, takeUntil } from 'rxjs/operators';

import { Author, DRAFT_STATUS, PUBLISHED_STATUS, SelfCompletingObservable, SuperCalled, takeOneTruthy, WARNING_STATUS } from '@oksygen-common-libraries/common';
import {
  allFilterTypesMatch,
  AutocompleteInputType,
  BasicSingleInputDialogComponent,
  BasicSingleInputDialogData,
  BasicSingleInputDialogInput,
  BasicTabNavItemComponent,
  Breadcrumb,
  ButtonInfo,
  CANCEL_BUTTON,
  FileManagerTableComponent,
  FileManagerTableData,
  Filter,
  filterMatches,
  illegalNameCharacterExists,
  newFormControl,
  SelectedFilterArray,
  SideNavService,
  TabService,
  UpdateOn
} from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DriverType, Track, TrackService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import {
  BrowserFilterText,
  BrowserState,
  ConfirmResult,
  deleteDialog,
  EditorBrowserFilterIOConfig,
  EditorBrowserTableStatus,
  newName,
  notificationDialog,
  yesNoDialog
} from '@oksygen-sim-train-libraries/components-services/common';
import {
  BaseLockableBrowserTabPage,
  DetailsToolbarComponent,
  EditorLock,
  LockDatabaseService
} from '@oksygen-sim-train-libraries/components-services/editors';
import { RobotDriverService } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';
import {
  Scenario,
  ScenarioService,
  ScenarioSummaryData,
  scenarioToScenarioSummaryData
} from '@oksygen-sim-train-libraries/components-services/scenarios';
import { getSessionsWithoutTrainee } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

import { SCENARIOS_CARD_DATA, ScenarioTabType } from '../../models/scenario-editor-tab.model';
import { ScenarioBrowserService } from '../../services/scenario-browser.service';
import { ScenarioEditService } from '../../services/scenario-edit.service';
import { ScenarioEditorContextManager } from '../../services/scenario-editor-context.manager';
import { ScenarioEditorState } from '../../store/scenario-editor.state';
import { isNil } from 'lodash';

enum FilterType {
  // These names are used to select the icon on chips of that type
  SCENARIO = 'scenario',
  WORLD = 'world',
  TRAIN = 'train',
  AUTHOR = 'author'
}

interface ScenarioFilterFields extends BrowserFilterText {
  authorText: string;
  scenarioText: string;
  trainText: string;
  worldText: string;
}

// interface ScenarioBrowserState {
//   filters: {
//     authorText: string;
//     scenarioText: string;
//     trainText: string;
//     worldText: string;
//     selectedFilters: SelectedFilterArray<FilterType>;
//   };
// }

@Component({
  templateUrl: './scenario-browser.component.html',
  styleUrls: ['./scenario-browser.component.scss']
})
export class ScenarioBrowserComponent
  extends BaseLockableBrowserTabPage<Scenario, ScenarioSummaryData, ScenarioFilterFields, string>
  implements OnInit, OnDestroy
{
  readonly DEFAULT_SCENARIO_NAME: string = t('New Scenario');
  readonly BREADCRUMB: Breadcrumb = {
    text: t('Scenarios'),
    icon: 'scenario'
  };

  // selectedScenario: Scenario;
  // selectedTableData: ScenarioSummaryData;
  // selectedCount: number;
  // sorter = new Sorter<ScenarioSummaryData>();

  isBusy = false;

  @ViewChild(FileManagerTableComponent) fileManagerTable: FileManagerTableComponent<ScenarioSummaryData>;

  autoCompleteType = AutocompleteInputType.FORM_FIELD;

  worlds: Track[] = [];
  worldToDisplay: string[] = [];
  simulatedTrains: string[] = [];
  authors: Author[] = [];

  sessionStartTime$ = new BehaviorSubject<string>(null);

  override readonly selectedItem = signal<Scenario | undefined>(undefined);

  private trackSubscription: Subscription;
  private selectedScenarioSubscription: Subscription;
  private masterSubscription = new Subscription();

  // private scenarios: Scenario[];
  private activeScenarioIds: string[];
  private activeEditors = 0;

  constructor(
    public scenarioBrowserService: ScenarioBrowserService,
    sideNavService: SideNavService,
    router: Router,
    private scenarioService: ScenarioService,
    private trackService: TrackService,
    private userService: UserService,
    private dialog: MatDialog,
    private snackbar: MatSnackBar,
    private scenarioEditService: ScenarioEditService,
    tabService: TabService,
    logger: Logging,
    private registry: Registry,
    private dataService: ScenarioEditorContextManager, // DataService<any, DataManager>,
    translateService: TranslateService,
    private uiStateModelManager: UiStateModelManager,
    private ruleTemplateService: RuleTemplateService,
    lockService: LockDatabaseService,
    authService: AuthService,
    private store: Store<ScenarioEditorState>,
    private readonly zone: NgZone,
    private robotDriverService: RobotDriverService
  ) {
    super(
      {
        create: { visible: true, enabled: true },
        delete: { visible: true, enabled: true },
        duplicate: { visible: true, enabled: true },
        edit: { visible: false, enabled: false },
        open: { visible: true, enabled: true },
        search: { visible: true, enabled: true },
        refresh: { visible: true, enabled: true },
        active: { visible: true, enabled: true }
      },
      scenarioBrowserService,
      sideNavService,
      router,
      SCENARIOS_CARD_DATA,
      tabService,
      logger,
      translateService,
      lockService,
      authService,
      dialog
    );
    // super(scenarioBrowserService, sideNavService, router, SCENARIOS_CARD_DATA, tabService, logger);
    this.refreshDisabled.set(false);
    this.editDisabled.set(true);
    this.openDisabled.set(true);
    this.duplicateDisabled.set(true);
    this.deleteDisabled.set(true);
    this.publishDisabled.set(true);
    this.printDisabled.set(true);

    this.detailEditDisabled.set(false);
    this.detailDuplicateDisabled.set(true);
    this.detailDeleteDisabled.set(false);
    this.detailPrintDisabled.set(true);

    this.detailEditTooltip = DetailsToolbarComponent.DEFAULT_EDIT_TOOLTIP;
  }

  override ngOnInit(): SuperCalled {
    const superCalled = super.ngOnInit();
    this.robotDriverService.reloadData();
    this.pageOpening();
    this.loadLocks(this.registry);
    this.selectedScenarioSubscription = this.scenarioBrowserService.getSelectedScenario$().subscribe(s => {
      // FIXME This doesn't update what the table shows (and right now  it's not clear to me how to make it do so).
      // On creation the table fires the selection callback with null, killing our attempt to persist the selection :(
      this.selectedItem.set(s);
    });

    this.scenarioService.reloadData(); // force a reload of the scenarios when opening the browser
    this.masterSubscription.add(
      combineLatest([this.scenarioService.data(), this.ruleTemplateService.data(), this.lockService.getEditorLocks(this.editorName())]).subscribe(
        ([scenarios, ruleTemplates, locks]) => {
          this.locks.set(locks ?? []);
          this.updateScenarios(scenarios, locks);
        }
      )
    );

    this.masterSubscription.add(
      this.scenarioEditService.activeEditors$.subscribe(count => {
        this.activeEditors = count;
        this.selectionChanged();
        // this.detailEditDisabled = count !== 0;
        // Reproduce the behaviour of edit button of the detail panel to the toolbar edit one
        // this.editDisabled = this.detailEditDisabled;
        this.detailEditTooltip = this.detailEditDisabled ? t('Already editing another Scenario') : DetailsToolbarComponent.DEFAULT_EDIT_TOOLTIP;
      })
    );
    this.masterSubscription.add(
      this.scenarioService.getActiveScenarios().subscribe(ids => {
        this.activeScenarioIds = ids ?? [];
      })
    );

    const scenariosTab: ScenarioTabType = {
      data: {
        id: SCENARIOS_CARD_DATA.id,
        groupId: SCENARIOS_CARD_DATA.id,
        icon: OksygenIcon.FILE_MANAGER,
        routerLink: SCENARIOS_CARD_DATA.routerLink,
        name: t('Manager'),
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => of(true),
        onClose: () => {
          this.tabClosing();
          this.clearFilters();
        }
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: SCENARIOS_CARD_DATA.id,
        groupName: SCENARIOS_CARD_DATA.name,
        route: SCENARIOS_CARD_DATA.routerLink,
        // groupIcon: SCENARIOS_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [scenariosTab],
      childrenIndex: 0
    });
    return superCalled;
  }

  ngOnDestroy(): void {
    this.masterSubscription.unsubscribe();
    this.selectedScenarioSubscription?.unsubscribe();
    this.trackSubscription?.unsubscribe();
    this.sessionStartTime$?.complete();
    this.pageClosing();
    this.setSelectedTableData();
  }

  sorterFunction(c: string, a: ScenarioSummaryData, b: ScenarioSummaryData): number {
    switch (c) {
      case 'name': {
        return a.name.localeCompare(b.name, this.getCurrentLocale());
      }
      case 'world': {
        return a.world.localeCompare(b.world, this.getCurrentLocale());
      }
      case 'train': {
        return a.train.name.localeCompare(b.train.name, this.getCurrentLocale());
      }
      case 'created': {
        if (a.created.date !== null && b.created.date !== null){
          return a.created.date.isBefore(b.created.date) ? 1 : -1;
        }
        else if (a.created.date !== null && b.created.date === null){
          return 1;
        }
        else {
          return -1;
        }
      }
      case 'modified': {
        if (a.modified.date !== null && b.modified.date !== null){
          return a.modified.date.isBefore(b.modified.date) ? 1 : -1;
        }
        else if (a.modified.date !== null && b.modified.date === null){
          return 1;
        }
        else {
          return -1;
        }
      }
      case 'status': {
        return a.status.localeCompare(b.status, this.getCurrentLocale());
      }
      case 'version': {
        return a.version.localeCompare(b.version);
      }
      default: {
        return 0;
      }
    }
  }

  override editorName(): string {
    return 'scenario';
  }

  onImport(): void {
    this.import();
  }

  onExport(): void {
    this.export();
  }

  onEdit(item: Scenario): void {
    this.editClick();
  }

  onDelete(item: Scenario | Scenario[]): void {
    this.setSelectedTableData();
    this.deleteClick();
  }

  onPrint(item: Scenario | Scenario[]): void {
    this.printClick();
  }

  onDuplicate(item: Scenario): void {
    this.duplicateClick();
  }

  onCreate(): void {
    this.createNew();
  }

  onRefresh(): void {
    this.scenarioService.reloadData();
    this.loadLocks(this.registry);
  }

  override onUnlock(): void {
    this.lockService.deleteDatabaseLock(this.selectedLock.id, this.selectedLock.editor).subscribe(() => this.loadLocks(this.registry));
  }

  protected initialiseFilterConfig(): EditorBrowserFilterIOConfig<Scenario>[] {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;
    const scenarioFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: OksygenIcon.SCENARIO,
        placeholder: 'Scenarios',
        value: this.state?.filters?.scenarioText
      },
      outputs: {
        currentValue: this.onScenarioTextChange.bind(self),
        selectedValue: this.addScenarioFilter.bind(self)
      }
    };

    const authorFilter: EditorBrowserFilterIOConfig<Author> = {
      inputs: {
        icon: OksygenIcon.AUTHOR,
        placeholder: t('Author'),
        value: this.state?.filters?.authorText
      },
      outputs: {
        currentValue: this.onAuthorTextChange.bind(self),
        selectedValue: this.addAuthorFilter.bind(self)
      }
    };
    const worldFilter: EditorBrowserFilterIOConfig<Track> = {
      inputs: {
        icon: OksygenIcon.WORLD,
        placeholder: t('Worlds'),
        value: this.state?.filters?.worldText
      },
      outputs: {
        currentValue: this.onWorldTextChange.bind(self),
        selectedValue: this.addWorldFilter.bind(self)
      }
    };
    const trainFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: OksygenIcon.TRAIN,
        placeholder: t('Simulated trains'),
        value: this.state?.filters?.trainText
      },
      outputs: {
        currentValue: this.onTrainTextChange.bind(self),
        selectedValue: this.addTrainFilter.bind(self)
      }
    };
    const filterConfig: EditorBrowserFilterIOConfig<any>[] = [scenarioFilter, worldFilter, trainFilter, authorFilter];
    return filterConfig;
  }

  protected initialiseColumns(): FileManagerTableData[] {
    const columns: FileManagerTableData[] = [];
    return columns;
  }

  protected initialiseDisplayedColumns(): string[] {
    const displayedColumns: string[] = ['name', 'world', 'train', 'created', 'modified', 'status', 'version'];
    return displayedColumns;
  }

  protected toTableData(data: Scenario[], locks: EditorLock[]): ScenarioSummaryData[] {
    const summary =
      data?.map(scenario => {
        let status: EditorBrowserTableStatus = scenario.scenarioIsActive ? PUBLISHED_STATUS : DRAFT_STATUS;
        if (Array.isArray(scenario.rule)) {
          for (const rule of scenario.rule) {
            const isLatest = this.ruleTemplateService.isLatestVersion(rule.ruleTemplateReference.id, rule.ruleTemplateReference.version);
            if (!isLatest) {
              status = WARNING_STATUS;
            }
          }
        }
        const locked = !!locks?.find(lock => lock.editor === this.editorName() && lock.id === scenario.id);
        const scenarioSummary = scenarioToScenarioSummaryData(this.userService, scenario, status);
        const selectedData = this.editorService.getSelectedTableData()?.find(selected => selected?.name === scenario.name);
        scenarioSummary.locked = locked;
        scenarioSummary.fmtChecked = !!selectedData?.fmtChecked;
        scenarioSummary.fmtSelected = !!selectedData?.fmtSelected;
        return scenarioSummary;
      }) ?? [];
    return summary;
  }

  protected getItemFromTableItem(data: ScenarioSummaryData): Scenario {
    if (!data || !this.data) {
      return null;
    }
    return this.data().find(scenario => scenario.id === data.id);
  }

  override updateSort(sort: Sort): void {
    this.fileManagerTable.updateSort(sort);
  }

  displayTrack(value: Track): string {
    return value?.name;
  }

  displayTrain(value: string): string {
    return value;
  }

  displayAuthor(value: Author): string {
    return value?.name;
  }

  addScenarioFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(FilterType.SCENARIO, value));
    this.fileManagerTable.applyFilter();
  }

  onScenarioTextChange(text: string): void {
    this.state.filters.scenarioText = text;
    this.fileManagerTable.applyFilter();
  }

  onFilterChange(): void {
    this.fileManagerTable.applyFilter();
  }

  addWorldFilter(value: Track | string): void {
    const name = typeof value === 'object' ? value.name : value;
    this.state.filters.selectedFilters.replace(FilterType.WORLD, new Filter(FilterType.WORLD, name));
    this.fileManagerTable.applyFilter();
  }

  onWorldTextChange(text: Track): void {
    this.state.filters.worldText = typeof text === 'object' ? text.name : text;
    this.fileManagerTable.applyFilter();
  }

  addTrainFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(FilterType.TRAIN, value));
    this.fileManagerTable.applyFilter();
  }

  onTrainTextChange(text: string): void {
    this.state.filters.trainText = text;
    this.fileManagerTable.applyFilter();
  }

  addAuthorFilter(value: Author | string): void {
    const name = typeof value === 'object' ? value.name : value;
    this.state.filters.selectedFilters.push(new Filter(FilterType.AUTHOR, name, null));
    this.fileManagerTable.applyFilter();
  }

  onAuthorTextChange(text: Author): void {
    this.state.filters.authorText = typeof text === 'object' ? text.name : text;
    this.fileManagerTable.applyFilter();
  }

  override selectionChanged(): void {
    super.selectionChanged();
    if (this.activeEditors > 0) {
      this.editDisabled.set(true);
      this.detailEditDisabled.set(true);
    }
    if (this.selectedCount() === 1) {
      this.scenarioService.getScenario(this.selectedTableData().id).subscribe(scenario => this.scenarioBrowserService.setSelectedScenario(scenario));
    }
    const selectedValues = this.fileManagerTable?.getSelectedValues();
    selectedValues?.forEach(scenarioSummary => {
      if (scenarioSummary.scenarioIsActive) {
        this.publishDisabled.set(true);
        this.unpublishDisabled.set(false);
      } else {
        this.publishDisabled.set(false);
        this.unpublishDisabled.set(true);
      }
    });
  }

  cellClicked(value: ScenarioSummaryData): void {}

  createNew(): void {
    const existingNames = this.data().map(s => s.name);
    const name = newName(this.DEFAULT_SCENARIO_NAME, this.translateService, existingNames);
    this.scenarioEditService.newScenario(name).then(id => this.startEditing(id));
    this.setSelectedTableData();
  }

  import(): void {
    this.logger.log('import');
    // TODO: Implement
  }

  export(): void {
    this.logger.log('export');
    // TODO: Implement
  }

  override duplicateClick(): void {
    if (this.selectedItem()) {
      const existingNames = this.data().map(s => s.name);
      const duplicateName = newName(this.selectedTableData().name, this.translateService, existingNames);

      const duplicateNameError = 'duplicateName';
      const missingError = 'missing';
      const spacesError = 'spaces';
      const specialCharacterError = 'specialCharacter';

      let exists = true;
      const duplicateFormControl = newFormControl(UpdateOn.CHANGE, c => {
        if (c.value) {
          const match = this.data().find(s => s.name === c.value);

          exists = !!match;

          if (exists) {
            return { [duplicateNameError]: true };
          } else if (c.value?.trim() !== c.value) {
            return { [spacesError]: true };
          } else if (illegalNameCharacterExists(c.value)) {
            return { [specialCharacterError]: true };
          }
        } else {
          return { [missingError]: true };
        }

        return null;
      });

      duplicateFormControl.setValue(duplicateName);

      const buttons: ButtonInfo[] = [
        CANCEL_BUTTON,
        {
          color: MaterialThemePalette.PRIMARY,
          text: t('Duplicate'),
          data: true,
          disableOnError: true
        }
      ];
      const input: BasicSingleInputDialogInput = {
        appearance: 'outline',
        floatLabel: 'always',
        label: t('Name'),
        inputFormControl: duplicateFormControl,
        formControlErrors: [
          // TODO: Possibly put these two messages in a shared place (they're copied from scenario-detail-panel)
          {
            type: duplicateNameError,
            text: t('A scenario with this name already exists.')
          },
          {
            type: missingError,
            text: t('A scenario name is required.')
          },
          {
            type: spacesError,
            text: t('A scenario name cannot have leading or trailing spaces.')
          },
          {
            type: specialCharacterError,
            text: t('A scenario name cannot have the special characters " < % > * | ? :')
          }
        ]
      };
      const data = new BasicSingleInputDialogData(t('Duplicate'), buttons, input);

      BasicSingleInputDialogComponent.open(this.dialog, data, result => {
        if (result.buttonData) {
          this.isBusy = true;
          this.scenarioEditService.duplicateScenario(this.selectedItem(), result.value).subscribe(() => {
            this.isBusy = false;
          });
        }
      });
    }
    this.setSelectedTableData();
  }


 rowDoubleClicked(): void {
    const selectedValues = this.fileManagerTable?.getSelectedValues();
    if(this.activeEditors === 0 && isNil(this.selectedLock)){

      this.selectedTableData.set(selectedValues[0]);

        if(this.selectedTableData())
        {
        this.scenarioService.getScenario(this.selectedTableData().id).subscribe(scenario => {
          this.selectedItem.set(scenario);
          this.editClick(); // Move editClick() here to ensure it's executed after previous logic.
        });
        }

    }
  }


  override editClick(): void {
    const selectedItem = this.selectedItem();
    // if the scenario is in use warn the user first
    if (this.isScenarioInUse(selectedItem.id)) {
      const confirmDialog = yesNoDialog(
        t('Scenario in use'),
        t('This scenario is currently running in a session. Are you sure you wish to edit it?'),
        this.translateService,
        this.dialog,
        t('Continue')
      );
      confirmDialog.subscribe(result => {
        if (result === ConfirmResult.SAVE) {
          this.scenarioEditService.loadScenario(selectedItem);
          this.startEditing(selectedItem.id);
        }
      });
    } else {
      // not ideal - we already called getScenario() on the first click but no way to know that without refactor
      // so have to call it again to guarantee we have the full scenario details when this fires
      // otherwise we fire before the scenario has returned
      this.scenarioService.getScenario(selectedItem.id).pipe(
        takeOneTruthy()
      ).subscribe(s => {
        this.scenarioEditService.loadScenario(selectedItem);
        this.startEditing(selectedItem.id);
      });
    }
  }

  startEditing(id: string): void {
    const url = `/editors/scenarios/${id}`;
    this.router.navigateByUrl(url);
    const scenario: ScenarioTabType = {
      data: {
        groupId: SCENARIOS_CARD_DATA.id,
        icon: OksygenIcon.FILE_NEW,
        id: id.toString(),
        routerLink: url,
        name: id === this.selectedItem()?.id ? this.selectedItem()?.name : t('New Scenario'),
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => this.preCloseCheck(id),
        onClose: () => this.destroyManagers(id)
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: SCENARIOS_CARD_DATA.id,
        groupName: SCENARIOS_CARD_DATA.name,
        route: SCENARIOS_CARD_DATA.routerLink,
        groupIcon: SCENARIOS_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [scenario]
    });
    this.lockEditorItem(id);
  }

  override deleteClick(): void {
    const selection = this.fileManagerTable.getSelectedValues();
    if (!selection || selection.length === 0) {
      return;
    }
    const title = selection.length > 1 ? 'Are you sure you want to delete these scenarios?' : 'Are you sure you want to delete this scenario?';
    const content = selection.length > 1 ? selection.map(s => s.name).reduce((p, n) => `${p}<br />${n}`) : `<b>${this.selectedItem().name}</b>`;
    deleteDialog(title, content, this.dialog).subscribe(dialogResult => {
      if (dialogResult) {
        this.isBusy = true;
        const total_count = selection.length;
        let count = 0;

        selection.forEach(scenarioSummaryData => {
          this.scenarioService.getScenario(scenarioSummaryData.id).subscribe(scenario =>
            this.doDeleteScenario(scenario).subscribe(() => {
              count = count + 1;
              if (count === total_count) {
                this.scenarioService.reloadData();
                //To update the world to display list
                // this.scenarioService
                //   .data()
                //   .pipe(takeOneTruthy())
                //   .subscribe(scenarios => {
                //     this.updateScenarios(scenarios);
                //   });
                this.isBusy = false;
              }
            })
          );
        });
      }
    });
    this.setSelectedTableData();
  }

  private destroyManagers(id: string): void {
    this.dataService.destroyContext(id as any); // FIXME number / string type misuse
    this.scenarioEditService.destroyManagers(id);
    if (this.lockService.isEnabled(this.editorName())) {
      this.lockService.deleteDatabaseLock(id, this.editorName()).subscribe(() => this.loadLocks(this.registry));
    }
  }

  private doDeleteScenario(scenario: Scenario): Observable<void> {
    return this.scenarioEditService.deleteScenario(scenario).pipe(
      map(() => {
        const id = scenario.id;

        if (this.tabService.getTabGroupItem(SCENARIOS_CARD_DATA.id, id.toString())) {
          this.tabService.removeItemFromTabGroup(SCENARIOS_CARD_DATA.id, { id: id.toString() }, true);
          this.destroyManagers(id);
        }
      })
    );
  }

  override printClick(): void {
    this.logger.log('printClick', this.fileManagerTable.getSelectedValues());
    // TODO: Implement
  }

  printDetailClick(): void {
    this.logger.log('printDetailClick', this.fileManagerTable.getSelectedValues());
    // TODO: Implement
  }

  applyFilters(scenario: ScenarioSummaryData): boolean {
    const names = [scenario.name, scenario.description];
    const authors = [scenario.created?.name, scenario.modified?.name];
    const trainNames = [scenario.train?.name, scenario.train?.type];

    if (
      !allFilterTypesMatch(
        [
          { t: FilterType.SCENARIO, v: names },
          { t: FilterType.WORLD, v: scenario.world },
          { t: FilterType.TRAIN, v: [scenario.train.name, scenario.train.type] },
          { t: FilterType.AUTHOR, v: [scenario.created?.name, scenario.modified?.name] }
        ],
        this.state.filters.selectedFilters
      )
    ) {
      return false;
    }

    if (!filterMatches(names, this.state.filters.scenarioText)) {
      return false;
    }
    if (!filterMatches(trainNames, this.state.filters.trainText)) {
      return false;
    }
    if (!filterMatches(scenario.world, this.state.filters.worldText)) {
      return false;
    }
    if (!filterMatches(authors, this.state.filters.authorText)) {
      return false;
    }

    return true;
  }

  /**
   * Returns whether a scenario is in use when on the browser page.
   *
   * @param scenarioId the scenario to check
   */
  private isScenarioInUse(id: string): boolean {
    return !!this.activeScenarioIds?.find(aid => aid === id);
  }

  /**
   * Returns whether a scenario is in use and can be used even outside of the scenario browser page.
   * We subscribe again since the ngOnDestroy is called when navigating away from the browser page, the list of activeScenarioIds is not updated anymore.
   *
   * @param scenarioId the scenario to check
   * @returns an observable that emits `true` if the scenario is in use, `false` otherwise. Goes through a take(1) to avoid memory leaks.
   */
  private isScenarioInUseAsynchronous(id: string): SelfCompletingObservable<boolean> {
    return this.scenarioService.getActiveScenarios().pipe(
      take(1),
      map(ids => {
        this.activeScenarioIds = ids;
        return !!this.activeScenarioIds?.find(aid => aid === id);
      })
    );
  }

  private updateScenarios(data: Scenario[], locks: EditorLock[]): void {
    this.isBusy = true;
    this.data.set([]);
    if (!data) {
      return;
    }
    this.data.set([...data]);
    this.authors = [];
    this.simulatedTrains = [];
    this.fileManagerTable?.applyFilter();
    this.worldToDisplay = [];
    this.worlds = [];

    this.tableData().forEach(scenario => {
      const createdAuthor: Author = {
        avatar: scenario.created.avatar,
        name: scenario.created.name
      };
      const modifiedAuthor: Author = {
        avatar: scenario.modified.avatar,
        name: scenario.modified.name
      };
      if (!this.authors.find(a => a.name === createdAuthor.name)) {
        this.authors.push(createdAuthor);
      }
      if (!this.authors.find(a => a.name === modifiedAuthor.name)) {
        this.authors.push(modifiedAuthor);
      }
    });

    this.data().forEach(scenario => {
      const existingTrackName = this.worldToDisplay.find(world => world === scenario.tracknetworkName);
      if (!existingTrackName) {
        this.worldToDisplay.push(scenario.tracknetworkName);
      }
    });

    //Update worlds to display for 'Worlds' filter
    this.trackSubscription?.unsubscribe();
    this.trackSubscription = this.trackService.data().subscribe(tracks => {
      if (tracks) {
        tracks.forEach(track => {
          if (this.worldToDisplay.find(world => world === track.name)) {
            this.worlds.push(track);
          }
        });
      } else {
        this.worlds = [];
      }
    });

    this.data().forEach(scenario => {
      scenario.scenarioTrains.scenarioTrain.forEach(st => {
        if (st.driverType === DriverType.HUMAN && !this.simulatedTrains.includes(st.name)) {
          this.simulatedTrains.push(st.name);
        }
      });
    });

    this.isBusy = false;
  }

  protected initialiseState(): BrowserState<ScenarioFilterFields, string> {
    return this.uiStateModelManager.getStateModel<any>('ScenarioBrowserComponent', () => ({
      filters: {
        authorText: '',
        scenarioText: '',
        trainText: '',
        worldText: '',
        selectedFilters: new SelectedFilterArray<FilterType>()
      }
    }));
  }

  /**
   * Checks if a scenario can be closed.
   * If the scenario is in use AND has no trainee AND a preview has been requested from this scenario, it means it is a preview (at least for now).
   * So you should first stop the preview before closing the editor.
   * @param id - The ID of the scenario currently being edited (UUID).
   * @returns - An Observable that emits `true` if the scenario is not in use and has no changes, `false` otherwise.
   */
  private preCloseCheck(id: string): SelfCompletingObservable<boolean> {
    return this.store.select(getSessionsWithoutTrainee(this.zone)).pipe(
      take(1),
      switchMap(state => this.checkScenarioInUse(id, state)),
      switchMap(canClose => (canClose ? this.confirmCloseEditor(id) : of(false)))
    );
  }

  /**
   * Checks if a scenario is in use in a session.
   * @param id - The ID of the scenario to check (UUID).
   * @param state - The current state of the application (All the session without trainees).
   * @returns - An Observable that emits `true` if the scenario is in use, `false` otherwise.
   */
  private checkScenarioInUse(id: string, state: any): SelfCompletingObservable<boolean> {
    return this.isScenarioInUseAsynchronous(id).pipe(
      take(1),
      switchMap(inUse => this.checkScenarioId(inUse, id, state))
    );
  }

  /**
   * Checks if the UUID of the scenario in use matches the provided ID.
   * This is because a session is using scenarioID and not UUID so we don't have a direct match.
   * @param inUse - A boolean indicating if the scenario is in use.
   * @param id - The ID of the scenario to check.
   * @param state - The current state of the application.
   * @returns - An Observable that emits `true` if the scenario ID matches the provided ID, `false` otherwise.
   */
  private checkScenarioId(inUse: boolean, id: string, state: any): SelfCompletingObservable<boolean> {
    return this.findScenarioIdCorrespondingId(state[0]?.session?.scenarioDefinition?.data?.scenarioId).pipe(
      take(1),
      map(scenarioId => this.handleScenarioId(inUse, scenarioId, id))
    );
  }

  /**
   * Handles the scenario ID check result.
   * If the scenario is in use, the ID matches and a preview has been requested for this session
   * It opens a notification dialog telling you to first close the session.
   * Else it goes on the close the editor
   * @param inUse - A boolean indicating if the scenario is in use.
   * @param scenarioId - The ID of the scenario in use.
   * @param id - The ID of the scenario to check.
   * @returns - `false` if the scenario is in use and the ID matches, `true` otherwise.
   */
  private handleScenarioId(inUse: boolean, scenarioId: string, id: string): boolean {
    if (inUse && scenarioId === id && this.scenarioEditService.getPreviewSession().find(session => session === id)) {
      // TODO Add a Second button "Exit and End Test Scenario" that terminates the test scenario and closes the scenario editor.
      // Probably hacky since scenario editor should not have any control/link with session controls
      notificationDialog(
        t('Scenario Testing in Progress'),
        t(`Please end the 'Test Scenario' first before exiting the Scenario Editor.`),
        this.dialog
      );
      return false;
    } else {
      return true;
    }
  }

  /**
   * confirms the closing of the editor.
   * @param id - The ID of the scenario currently being edited.
   * @returns - An Observable that emits `true` if the editor can be closed, `false` otherwise.
   */
  private confirmCloseEditor(id: string): Observable<boolean> {
    return this.scenarioEditService.confirmCloseEditor(id);
  }

  /**
   * finds the scenario ID that corresponds to the provided ID.
   * @param scenarioId - The ID of the scenario to find.
   * @returns - An Observable that emits the found scenario ID.
   */
  private findScenarioIdCorrespondingId(scenarioId: number): SelfCompletingObservable<string> {
    return this.scenarioService.latestVersionData().pipe(
      take(1),
      map(scenarioData => {
        const scenario = scenarioData.find(s => s.scenarioId === scenarioId);
        // Scenario could be undefined
        return scenario?.id;
      })
    );
  }

  onPublish(item: Scenario | ScenarioSummaryData | Scenario[], isActive: boolean): void {
    const eventEnd$ = new Subject<void>();

    if (Array.isArray(item)) {
      this.isBusy = true;
      const scenarioObservables = item.map(s =>
        this.scenarioService.getScenario(s.id).pipe(
          filter(scenario => !!scenario),
          take(1),
          switchMap(scenario => this.modifyScenarioActivationStatus(scenario, isActive).pipe(take(1))),
          catchError(error => {
            this.logger.warn('Error updating scenario:', error);
            return of(null);
          })
        )
      );

      forkJoin(scenarioObservables)
        .pipe(takeUntil(eventEnd$))
        .subscribe(() => {
          this.isBusy = false;
          this.scenarioService.reloadData();
          eventEnd$.next(undefined);
          eventEnd$.complete();
        });
    } else {
      this.scenarioService
        .getScenario(item.id)
        .pipe(
          filter(scenario => !!scenario),
          take(1),
          switchMap(scenario => this.modifyScenarioActivationStatus(scenario, isActive).pipe(take(1))),
          catchError(error => {
            this.logger.warn('Error updating scenario:', error);
            return of(null);
          }),
          takeUntil(eventEnd$)
        )
        .subscribe(() => {
          this.scenarioService.reloadData();
          eventEnd$.next(undefined);
          eventEnd$.complete();
        });
    }

    this.setSelectedTableData();
  }

  private modifyScenarioActivationStatus(scenario: Scenario, isActive: boolean): SelfCompletingObservable<any> {
    scenario.scenarioIsActive = isActive;
    return this.scenarioEditService.modifyScenarioActivationStatus(scenario);
  }
}
