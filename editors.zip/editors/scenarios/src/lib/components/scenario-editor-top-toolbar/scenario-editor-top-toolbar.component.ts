/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Observable, of, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { filterTruthy } from '@oksygen-common-libraries/common';
import { Sorter } from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';
import {
  DEFAULT_LINE_PROFILES,
  LayerService,
  LineProfile,
  ObjectLayer,
  objectLayerConfig,
  ObjectLayersDialogComponent,
  ObjectLayersDialogResult
} from '@oksygen-sim-train-libraries/components-services/common';
import { EditorTopToolbarConfig } from '@oksygen-sim-train-libraries/components-services/editors';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { PreviewVisionState, ScenarioPreviewCamera } from '@oksygen-sim-train-libraries/components-services/scenarios';
import {
  getObjectLayers,
  ScenarioPreviewManager,
  SessionContextSupplier,
  SessionMainView
} from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

import { defaultScenarioEditorConfig } from '../../models/default-scenario-editor-config.model';
import { ScenarioEditorTopToolbarDefaultItemsConfig } from '../../models/scenario-editor-config.model';

class WorldPreviewTooltips {
  public static readonly NO_SKIN = t('Please select a world and an appearance to enable world preview.');
  public static readonly VISION_INACCESSIBLE = t('Another scenario edit window has control of vision.');
  public static readonly VISION_NOT_LOADED = t('Load world preview');
  public static readonly VISION_LOADING = t('World preview is loading...');
  public static readonly VISION_LOADED = '';
}

@Component({
  selector: 'oksygen-scenario-editor-top-toolbar',
  templateUrl: './scenario-editor-top-toolbar.component.html',
  styleUrls: ['./scenario-editor-top-toolbar.component.scss']
})
export class ScenarioEditorTopToolbarComponent implements OnInit, OnChanges, OnDestroy {
  @Input() config: EditorTopToolbarConfig<ScenarioEditorTopToolbarDefaultItemsConfig>;
  @Input() scenarioPreviewManager: ScenarioPreviewManager;
  @Input() lineProfiles: LineProfile[] = DEFAULT_LINE_PROFILES;
  @Input() showInPreviewDisabled$: Observable<boolean>;
  @Input() previewEnabled: boolean;

  @Input() pathToolDisabled = true;
  @Input() stationsDisabled = true;
  @Input() pathToolActive = false;
  @Input() saveDisabled = false;
  @Input() previewDisabled = false;
  @Input() canUndo$: Observable<boolean>;
  @Input() canRedo$: Observable<boolean>;

  @Output() readonly startPreview = new EventEmitter();
  @Output() readonly save = new EventEmitter();
  @Output() readonly undo = new EventEmitter();
  @Output() readonly redo = new EventEmitter();

  @Output() readonly mainView   = new EventEmitter<SessionMainView>();
  @Output() readonly layers     = new EventEmitter<ObjectLayer[]>();
  @Output() readonly station    = new EventEmitter<ObjectContainer>();
  @Output() readonly selectPath = new EventEmitter<void>();

  readonly cameraIcons = { aerial: 'view_birdseye', object: 'view_object', track: 'view_rail', train: 'view_train' };

  // a little annoying we have to do this to properly access enums in the HTML
  PreviewVisionState = PreviewVisionState;
  ScenarioPreviewCamera = ScenarioPreviewCamera;

  noneDisabled = true;
  allDisabled = false;
  stations: ObjectContainer[] = [];
  selectedStation: ObjectContainer;
  stationSorter = new Sorter<ObjectContainer>();
  cameraFocusObjectIsSet = false;
  worldPreviewTooltip: string = WorldPreviewTooltips.VISION_INACCESSIBLE;
  camera: ScenarioPreviewCamera;
  visionState = PreviewVisionState.NOT_LOADED;
  visionAvailable = false;

  private masterSubscription = new Subscription();
  private scenarioPreviewManagerSubscription = new Subscription();

  constructor(
    private logger: Logging,
    private layerService: LayerService,
    public dialog: MatDialog,
    private contextSupplier: SessionContextSupplier,
    private readonly translateService: TranslateService) {}

  ngOnInit(): void {
    this.stationSorter.sortFunction = (c, a, b): number => a.name.localeCompare(b.name, this.translateService.currentLocaleString);

    this.initialise();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // TODO: if no config is supplied, use our default config. Long term, should perhaps be provided by a service
    if (changes.config && changes.config.currentValue !== changes.config.previousValue && !changes.config.currentValue) {
      this.config = defaultScenarioEditorConfig().topToolbar;
    }

    if (changes.scenarioPreviewManager
    && changes.scenarioPreviewManager.currentValue !== changes.scenarioPreviewManager.previousValue
    ) {
      if (this.scenarioPreviewManager) {
        this.scenarioPreviewManagerSubscription.unsubscribe();
        this.scenarioPreviewManagerSubscription = new Subscription();
        // don't assume anything about our new scenario, reset everything back to initial values
        this.visionState = PreviewVisionState.NOT_LOADED;
        this.visionAvailable = false;

        this.updateWorldPreviewTooltip();

        this.scenarioPreviewManagerSubscription.add(
          this.scenarioPreviewManager.visionStartable$.subscribe(visionAccessible => {
              this.visionAvailable = visionAccessible;
              this.updateWorldPreviewTooltip();
            }
          )
        );

        this.scenarioPreviewManagerSubscription.add(
            this.scenarioPreviewManager.controllingVision$
            .pipe(
              switchMap(inControl =>
                // if we're not in control, pretend it's not loaded
                inControl ? this.scenarioPreviewManager.visionState$ : of(PreviewVisionState.NOT_LOADED)
              )
            )
            .subscribe((state: PreviewVisionState) => {
              this.visionState = state;
              this.updateWorldPreviewTooltip();
            })
        );

        this.scenarioPreviewManagerSubscription.add(
          this.scenarioPreviewManager.selectedCamera$.subscribe((camera: ScenarioPreviewCamera) => {
            this.camera = camera;
          })
        );

        this.scenarioPreviewManagerSubscription.add(
          this.scenarioPreviewManager.focusedObject$.subscribe((feature: any) => {
            this.cameraFocusObjectIsSet = !!feature;
          })
        );
      }
    }
  }

  ngOnDestroy(): void {
    this.masterSubscription.unsubscribe();
    this.scenarioPreviewManagerSubscription.unsubscribe();
  }

  private updateWorldPreviewTooltip(): void {
    if (this.visionAvailable) {
      switch (this.visionState) {
        case PreviewVisionState.NOT_LOADED:
        case PreviewVisionState.UNLOADING:
          this.worldPreviewTooltip = WorldPreviewTooltips.VISION_NOT_LOADED;
          break;
        case PreviewVisionState.LOADING:
          this.worldPreviewTooltip = WorldPreviewTooltips.VISION_LOADING;
          break;
        case PreviewVisionState.LOADED:
          this.worldPreviewTooltip = WorldPreviewTooltips.VISION_LOADED;
          break;
      }
    } /*else if (this.visionAvailable) {
      this.worldPreviewTooltip = WorldPreviewTooltips.NO_SKIN;
    }*/ else {
      this.worldPreviewTooltip = WorldPreviewTooltips.VISION_INACCESSIBLE;
    }
  }

  initialise(): void {
    const stationSub =
      // init the visible layers to show all!
      this.contextSupplier
        .currentContext$()
        .pipe(
          filterTruthy(),
          switchMap(m => m.objects.getObjectContainersOfType$('Station'))
        )
        .subscribe(stations => {
          if (stations) {
            this.stations = [];
            for (const station of stations) {
              this.stations.push(station);
            }
          }
        });
    this.masterSubscription.add(stationSub);

    // Auto select, since we don't currently offer any choices on the UI.
    this.selectView('plan');
  }

  selectView(view: SessionMainView): void {
    this.mainView.emit(view);
  }

  clearLineProfiles($event: Event): void {
    $event?.stopPropagation();
    for (const lp of this.lineProfiles) {
      lp.checked = false;
    }

    this.noneDisabled = true;
    this.allDisabled = false;
  }

  allLineProfiles($event: Event): void {
    $event?.stopPropagation();
    for (const lp of this.lineProfiles) {
      lp.checked = true;
    }

    this.noneDisabled = false;
    this.allDisabled = true;
  }

  lineProfileChanged(checked: boolean, lineProfile: LineProfile): void {
    if (lineProfile.parentId) {
      let childrenCount = 0;
      let childrenChecked = 0;
      let parent: LineProfile;

      this.lineProfiles.forEach(value => {
        if (value.id === lineProfile.parentId) {
          parent = value;
        }

        if (value.parentId === lineProfile.parentId) {
          childrenCount++;

          if (value.checked) {
            childrenChecked++;
          }
        }
      });

      if (childrenCount === childrenChecked) {
        parent.checked = true;
      } else {
        parent.checked = false;
      }
    } else if (lineProfile.children?.length > 0) {
      this.lineProfiles.forEach(value => {
        if (lineProfile.children.includes(value.id)) {
          value.checked = lineProfile.checked;
        }
      });
    }

    let allChecked = 0;
    this.lineProfiles.forEach(value => {
      if (value.checked) {
        allChecked++;
      }
    });

    if (allChecked === this.lineProfiles.length) {
      this.noneDisabled = false;
      this.allDisabled = true;
    } else if (allChecked === 0) {
      this.noneDisabled = true;
      this.allDisabled = false;
    } else {
      this.noneDisabled = false;
      this.allDisabled = false;
    }
  }

  layersClick(): void {
    const config = objectLayerConfig(getObjectLayers(this.logger, this.contextSupplier
      .currentContext$(), this.layerService));
    const dialog = this.dialog.open(ObjectLayersDialogComponent, config);
    dialog.afterClosed().subscribe((results: ObjectLayersDialogResult) => {
      // no need to unsubscribe as dialog.afterClose() completes
      if (!results?.layers) {
        return;
      } // cancel close - no layer changes
      this.layers.emit(results.layers);
    });
  }

  selectStation(station: ObjectContainer): void {
    this.selectedStation = station;
    this.station.emit(this.selectedStation);
  }

  sortStations(event: Event): void {
    this.stationSorter.toggleSort();
    event.stopPropagation();
  }

  togglePathSelection(): void {
    this.selectPath.emit();
  }

  marker(): void {
    this.logger.log('marker clicked');
  }

  pkPointer(): void {
    this.logger.log('pk pointer clicked');
  }

  selectCamera(camera: ScenarioPreviewCamera): void {
    this.scenarioPreviewManager.selectCamera(camera);
  }

  visionClick(): void {
    if (this.visionState === PreviewVisionState.NOT_LOADED) {
      this.scenarioPreviewManager.disconnectFromComms();
      this.scenarioPreviewManager.startVision();
    } else if (this.visionState === PreviewVisionState.LOADED) {
      this.scenarioPreviewManager.stopVision();
    }
  }
}
