/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ToolbarComponent } from '@oksygen-sim-train-libraries/components-services/common';
import { StationMenuComponent } from '@oksygen-sim-train-libraries/components-services/maps';
import { ScenarioPreviewManager } from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { configureSimTrainTestingModule, TEST_SCENARIO_ID } from '@oksygen-sim-train-libraries/components-services/testing';
import { ConsistDataService, TrainVisionManager } from '@oksygen-sim-train-libraries/components-services/trains';

import { defaultScenarioEditorConfig } from '../../models/default-scenario-editor-config.model';
import { OksygenSimTrainScenarioEditModule } from '../../scenario-edit.module';
import { ScenarioEditorTopToolbarComponent } from './scenario-editor-top-toolbar.component';

describe('ScenarioEditorTopToolbarComponent', () => {
  let component: ScenarioEditorTopToolbarComponent;
  let fixture: ComponentFixture<ScenarioEditorTopToolbarComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainScenarioEditModule],
      declarations: [ScenarioEditorTopToolbarComponent, ToolbarComponent, StationMenuComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioEditorTopToolbarComponent);
    component = fixture.componentInstance;
    component.config = defaultScenarioEditorConfig().topToolbar;

    const logging = TestBed.inject(Logging);

    component.scenarioPreviewManager = new ScenarioPreviewManager(
      TEST_SCENARIO_ID,
      logging,
      TestBed.inject(ConsistDataService),
      null,
      null,
      new TrainVisionManager(TestBed.inject(Registry), logging)
    );
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
