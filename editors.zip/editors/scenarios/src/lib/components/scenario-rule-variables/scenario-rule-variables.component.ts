/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, effect, input, OnInit, signal } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import {
  allFilterTypesMatch,
  Filter,
  filterMatches,
  PromptDialogComponent,
  PromptDialogData,
  SelectedFilterArray,
  Sorter,
  SorterPipe
} from '@oksygen-common-libraries/material/components';
import { MaterialButtonVariant, MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Registry } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { newName } from '@oksygen-sim-train-libraries/components-services/common';
import { RuleVariableTypes, ScenarioRuleVariable } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { isNil } from 'lodash';
import { Observable } from 'rxjs';
import { ScenarioEditManager } from '../../services/scenario-edit.manager';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';

interface RuleVariablesState {
  filters: { search: string; selectedFilters: SelectedFilterArray<RuleVariableType> };
}

export enum RuleVariableType {
  NAME = 'search'
}

@Component({
  selector: 'oksygen-scenario-rule-variables',
  templateUrl: './scenario-rule-variables.component.html',
  styleUrl: './scenario-rule-variables.component.scss'
})
export class ScenarioRuleVariablesComponent implements OnInit {
  readonly ruleVariableTypes = RuleVariableTypes;
  readonly oksygenIcon = OksygenIcon;

  ruleVariables$ = input.required<Observable<Array<ScenarioRuleVariable>>>();
  scenarioEditManager = input.required<ScenarioEditManager>();
  uiModels = input.required<UiStateModelManager>();

  variableTypes = signal<Array<string>>([]);
  variables = signal<Array<ScenarioRuleVariable>>([]);

  filteredVariables: Array<ScenarioRuleVariable> = [];

  breadcrumbChildren: ReadonlyArray<string> = [];

  selectedRuleVariable = signal<ScenarioRuleVariable | undefined>(null);

  sorter = new Sorter<ScenarioRuleVariable>();

  private sorterPipe = new SorterPipe();

  state: RuleVariablesState;

  addDisabled = true;

  otherRuleVariableNames: Array<string> = [];

  constructor(private registry: Registry, private readonly translateService: TranslateService, private readonly dialog: MatDialog) {
    this.variableTypes.set(this.registry.getObject<Array<string>>(['editor', 'scenario', 'rule', 'variableTypes'], ['number', 'boolean']));
    this.sorter.sortFunction = (c, a, b): number => a?.name?.localeCompare(b?.name);

    effect(
      onCleanup => {
        const subscription = this.ruleVariables$().subscribe(variables => {
          if (variables) {
            this.variables.set(variables);
            this.applyFilters();
            this.addDisabled = false;

            if (!isNil(this.selectedRuleVariable())) {
              this.editVariable(this.variables().find(v => v.name === this.selectedRuleVariable().name));
            }
          }
        });

        onCleanup(() => {
          subscription?.unsubscribe();
        });
      },
      { allowSignalWrites: true }
    );
  }

  ngOnInit(): void {
    this.state = this.uiModels().getStateModel('scenario-rule-variables', () => ({
      filters: {
        search: '',
        selectedFilters: new SelectedFilterArray<RuleVariableType>()
      }
    }));
  }

  textToFilter(text: string): Filter<string> {
    return new Filter('search', text);
  }

  applyFilters(): void {
    if (!this.variables()) {
      return;
    }
    this.filteredVariables =
      this.variables()?.filter(variable => {
        const names = [variable.name];

        if (!allFilterTypesMatch([{ t: 'search', v: names }], this.state.filters.selectedFilters)) {
          return false;
        }

        if (!filterMatches(names, this.state.filters.search)) {
          return false;
        }

        return true;
      }) ?? [];

    this.filteredVariables = this.sorterPipe.transform(this.filteredVariables, this.sorter, this.sorter.refresh);
  }

  onBack(): void {
    if (isNil(this.selectedRuleVariable().name) || isNil(this.selectedRuleVariable().type) || isNil(this.selectedRuleVariable().value)) {
      const promptData = new PromptDialogData();
      promptData.title = t('Incomplete Rule Variable');
      promptData.content = t('Are you sure you want to go back?');
      promptData.buttons = [
        {
          color: MaterialThemePalette.PRIMARY,
          style: MaterialButtonVariant.BUTTON,
          text: t('Cancel'),
          data: false
        },
        {
          color: MaterialThemePalette.PRIMARY,
          text: t('Back'),
          data: true
        }
      ];

      PromptDialogComponent.open(
        this.dialog,
        {
          data: promptData,
          width: '400px',
          panelClass: 'small-whitespace-dialog'
        },
        (result: boolean) => {
          if (result) {
            // Remove invalid variable
            this.scenarioEditManager().deleteScenarioRuleVariable(this.selectedRuleVariable().name);
            this.doGoBack();
          }
        }
      );
    } else {
      this.doGoBack();
    }
  }

  doGoBack(): void {
    this.selectedRuleVariable.set(undefined);
    this.updateBreadcrumbChildren();
  }

  private updateBreadcrumbChildren(): void {
    if (!isNil(this.selectedRuleVariable())) {
      this.breadcrumbChildren = [this.selectedRuleVariable().name];
    } else {
      this.breadcrumbChildren = [];
    }
  }

  onCurrentValueUpdate(search: string): void {
    this.state.filters.search = search;
    this.applyFilters();
  }

  addRuleVariable(): void {
    this.otherRuleVariableNames = this.variables().map(v => v.name);
    this.selectedRuleVariable.set({
      name: newName(t('New Rule Variable'), this.translateService, this.variables()?.map(v => v.name) ?? [], null),
      type: this.variableTypes()?.[0],
      value: null
    });
    this.scenarioEditManager().addScenarioRuleVariable(this.selectedRuleVariable());
  }

  onEdit(event: Event, variable: ScenarioRuleVariable): void {
    event.preventDefault();
    event.stopImmediatePropagation();
    this.editVariable(variable);
  }

  onDelete(event: Event, variable: ScenarioRuleVariable): void {
    event.preventDefault();
    event.stopImmediatePropagation();
    this.scenarioEditManager().deleteScenarioRuleVariable(variable.name);
  }

  private editVariable(variable: ScenarioRuleVariable): void {
    this.selectedRuleVariable.set(variable);
    this.updateBreadcrumbChildren();
  }

  onVariableNameUpdated(name: string): void {
    const oldName = this.selectedRuleVariable().name;
    this.selectedRuleVariable.set({
      ...this.selectedRuleVariable(),
      name
    });
    this.scenarioEditManager().updateScenarioRuleVariable(oldName, { name });
  }

  onDuplicate(event: Event, variable: ScenarioRuleVariable): void {
    event.preventDefault();
    event.stopImmediatePropagation();
    variable = {
      ...variable,
      name: newName(t(variable.name), this.translateService, this.variables()?.map(v => v.name) ?? [], null)
    };
    this.scenarioEditManager().addScenarioRuleVariable(variable);
    if (!isNil(this.selectedRuleVariable())) {
      this.onBack();
    }
  }
}
