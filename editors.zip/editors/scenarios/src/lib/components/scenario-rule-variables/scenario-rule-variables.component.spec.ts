/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ScenarioRuleVariablesComponent } from './scenario-rule-variables.component';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainScenarioEditModule } from '../../scenario-edit.module';
import { of } from 'rxjs';

describe('ScenarioRuleVariablesComponent', () => {
  let component: ScenarioRuleVariablesComponent;
  let fixture: ComponentFixture<ScenarioRuleVariablesComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainScenarioEditModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioRuleVariablesComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('ruleVariables$', of([]));
    fixture.componentRef.setInput('scenarioEditManager', undefined);
    fixture.componentRef.setInput('uiModels', undefined);
    fixture.detectChanges();
  });


  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
