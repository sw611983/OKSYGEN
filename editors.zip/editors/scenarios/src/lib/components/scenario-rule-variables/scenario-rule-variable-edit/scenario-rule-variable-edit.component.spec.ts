/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ScenarioRuleVariableEditComponent } from './scenario-rule-variable-edit.component';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainScenarioEditModule } from '../../../scenario-edit.module';

describe('ScenarioRuleVariableEditComponent', () => {
  let component: ScenarioRuleVariableEditComponent;
  let fixture: ComponentFixture<ScenarioRuleVariableEditComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainScenarioEditModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioRuleVariableEditComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('ruleVariable', undefined);
    fixture.componentRef.setInput('ruleVariableTypes', []);
    fixture.componentRef.setInput('otherRuleVariableNames', []);
    fixture.componentRef.setInput('scenarioEditManager', undefined);
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
