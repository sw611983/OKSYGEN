/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, computed, effect, input, OnDestroy, OnInit, output, Signal, signal } from '@angular/core';
import { AbstractControl, UntypedFormControl, ValidationErrors } from '@angular/forms';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import {
  AutocompleteInputType,
  illegalNameCharacterExists,
  InputError,
  newFormControl,
  UpdateOn,
  validateMandatoryString,
  validateUniqueString
} from '@oksygen-common-libraries/material/components';
import { RuleVariableTypes, ScenarioRuleVariable } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { capitalize, isNil, merge } from 'lodash';
import { debounceTime, Subscription } from 'rxjs';
import { ScenarioEditManager } from '../../../services/scenario-edit.manager';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';

interface RuleVariableType {
  name: string;
  matIcon: string;
}

@Component({
  selector: 'oksygen-scenario-rule-variable-edit',
  templateUrl: './scenario-rule-variable-edit.component.html',
  styleUrl: './scenario-rule-variable-edit.component.scss'
})
export class ScenarioRuleVariableEditComponent implements OnInit, OnDestroy {
  private readonly formDebounceTime = 750;
  readonly booleanTypeVariable = RuleVariableTypes.BOOLEAN;

  ruleVariable = input.required<ScenarioRuleVariable>();
  ruleVariableTypes = input.required<Array<string>>();
  otherRuleVariableNames = input.required<Array<string>>();
  scenarioEditManager = input.required<ScenarioEditManager>();

  readonly variableNameUpdated = output<string>();
  readonly onDeleteClick = output<Event>();
  readonly onDuplicateClick = output<Event>();

  autocompleteInputType = AutocompleteInputType.FORM_FIELD;

  nameControl: UntypedFormControl;
  valueControl = newFormControl();
  valueError = signal<boolean>(false);

  private subscription = new Subscription();

  variableTypes = signal<Array<RuleVariableType>>([]);

  variableTypeError = false;
  variableTypeControl = newFormControl();
  variableTypeInputControl: UntypedFormControl;
  variableTypeControlErrors: InputError[] = [{ type: 'missing', text: t('Variable type is required.') }];

  typeIcon: Signal<string> = computed(() => this.getVariableTypeIcon(this.ruleVariable().type));

  constructor() {
    effect(
      () => {
        const ruleVariable = this.ruleVariable();
        if (this.ruleVariableTypes()?.length !== this.variableTypes()?.length) {
          this.variableTypes.set([]);
          this.ruleVariableTypes().forEach(type => {
            this.variableTypes().push({
              name: type,
              matIcon: this.getVariableTypeIcon(type)
            });
          });
        }

        if (!isNil(this.nameControl) && this.nameControl.value !== ruleVariable.name) {
          this.nameControl.setValue(ruleVariable.name);
        }

        if (!isNil(this.variableTypeControl) && this.variableTypeControl.value?.name !== ruleVariable.type) {
          setTimeout(() => {
            this.variableTypeControl.setValue(this.variableTypes().find(tp => tp.name === ruleVariable.type));
          });
        }

        if (!isNil(this.valueControl) && this.valueControl.value !== ruleVariable.value) {
          if (ruleVariable.type !== RuleVariableTypes.BOOLEAN) {
            this.valueControl.setValue(ruleVariable.value);
          } else {
            this.valueError.set(false);
          }
        }
      },
      { allowSignalWrites: true }
    );
  }

  private getVariableTypeIcon(type: string): string {
    return type === RuleVariableTypes.NUMBER
      ? OksygenIcon.VARIABLE_INTEGER
      : type === RuleVariableTypes.STRING
      ? OksygenIcon.VARIABLE_STRING
      : OksygenIcon.BOOLEAN_ALT;
  }

  ngOnInit(): void {
    this.nameControl = newFormControl(UpdateOn.CHANGE, c => {
      let result = validateUniqueString(c.value, this.otherRuleVariableNames(), this.ruleVariable()?.name);

      if (!isNil(c.value)) {
        if (c.value.trim() !== c.value) {
          result = merge(result || {}, { ['spaces']: true });
        }

        if (illegalNameCharacterExists(c.value)) {
          result = merge(result || {}, { ['specialCharacter']: true });
        }
      }

      return result;
    });

    this.variableTypeInputControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;
      this.variableTypeError = false;
      result = validateMandatoryString(control.value);
      this.variableTypeError = result !== null;
      return result;
    });

    this.valueControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;
      this.valueError.set(false);
      result = validateMandatoryString(control.value);

      if (!isNil(control.value) && typeof control.value === 'string') {
        if (control.value.trim() !== control.value) {
          result = merge(result || {}, { ['spaces']: true });
        }

        if (illegalNameCharacterExists(control.value)) {
          result = merge(result || {}, { ['specialCharacter']: true });
        }
      }
      this.valueError.set(result !== null);
      return result;
    });

    this.subscription.add(
      this.nameControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(name => {
        if (name !== this.ruleVariable().name && !this.nameControl.errors) {
          this.variableNameUpdated.emit(name);
        }
      })
    );

    this.subscription.add(
      this.variableTypeControl.valueChanges.subscribe(type => {
        if (!this.variableTypeError && this.ruleVariable().type !== type.name) {
          if (type.name === RuleVariableTypes.BOOLEAN) {
            this.valueError.set(false);
          }
          this.scenarioEditManager().updateScenarioRuleVariable(this.ruleVariable().name, {
            type: type.name,
            value: type.name === RuleVariableTypes.BOOLEAN ? false : null
          });
        }
      })
    );
    this.subscription.add(
      this.valueControl.valueChanges.subscribe(value => {
        if (!this.valueError() && this.ruleVariable().value !== value) {
          this.scenarioEditManager().updateScenarioRuleVariable(this.ruleVariable().name, { value });
        }
      })
    );
  }

  onDelete(event: Event): void {
    this.onDeleteClick.emit(event);
  }

  onDuplicate(event: Event): void {
    this.onDuplicateClick.emit(event);
  }

  echo(o: any): any {
    return typeof o === 'string' ? o : capitalize(o.name);
  }

  changeActive(event: MatSlideToggleChange): void {
    this.scenarioEditManager().updateScenarioRuleVariable(this.ruleVariable().name, { value: event.checked });
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }
}
