/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectionStrategy, ChangeDetectorRef, Component, effect, input, output } from '@angular/core';
import { Filter, SelectedFilterArray } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { BrowserFilterText, BrowserState } from '@oksygen-sim-train-libraries/components-services/common';
import { TrainSimPropertyValues } from '@oksygen-sim-train-libraries/components-services/common';
import { SimProperty, SimPropertyGroup, SimPropertyTreeNode } from '@oksygen-sim-train-libraries/components-services/sim-properties';

interface SimPropertyFilterFields extends BrowserFilterText {
  simPropertyText: string;
}

type SimPropertiesState = BrowserState<SimPropertyFilterFields, string>;

enum SimPropertiesFilterType {
  // ```no-mat-icon``` prefix prevents the chip list from displaying mat-icons
  PROPERTY = 'no-mat-icon-sim_property'
}

@Component({
  selector: 'oksygen-initial-conditions-tree',
  templateUrl: './initial-conditions-tree.component.html',
  styleUrl: './initial-conditions-tree.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialConditionsTreeComponent {
  public readonly simPropertiesGroup = input.required<Array<SimPropertyGroup>>();
  public readonly displayGroupTitle = input<boolean>(false);
  public readonly selectedPropertyName = input<string>();
  public readonly isDraggable = input<boolean>(false);
  public readonly selectedPropertyVehicleIndex = input<number | undefined>();
  public readonly selectedPropertyVehicleName = input<string | undefined>();
  public readonly trainSimPropertiesAll = input<TrainSimPropertyValues>();
  public readonly selectedInitialConditions = input<TrainSimPropertyValues>();

  public readonly selectedProperty = output<{
    property: SimProperty;
    vehicleIndex: number | undefined;
    vehicleName: string | undefined;
  }>();

  oksygenToolsIcon = OksygenIcon.TOOLS;

  dataSource: Array<SimPropertyTreeNode>;
  searchQuery: string;
  filteredDataSource: SimPropertyTreeNode[] = [];

  simPropertiesGrouped: Map<string, SimPropertyTreeNode> = new Map();

  state: SimPropertiesState;

  constructor(private uiStateModelManager: UiStateModelManager, private cdr: ChangeDetectorRef) {
    this.state = this.uiStateModelManager.getStateModel<any>('InitialConditionsTreeComponent', () => ({
      filters: {
        simPropertyText: '',
        selectedFilters: new SelectedFilterArray<string>()
      }
    }));

    effect(() => {
      this.updateTree();
    });

    effect(() => {
      const selectedConditions = this.selectedInitialConditions();
      const vehicleIndex = this.selectedPropertyVehicleIndex();

      let modified = false;
      if (selectedConditions && this.filteredDataSource?.length) {
        // Handle train-level properties
        if (vehicleIndex === -1) {
          selectedConditions?.trainSimPropertyValues?.simPropertyValue?.forEach(prop => {
            if (prop.name) {
              this.markPropertyAndPropagate(this.filteredDataSource, prop.name);
              modified = true;
            }
          });
        }
        // Handle vehicle-level properties
        else if (vehicleIndex >= 0) {
          const vehicle = selectedConditions.vehicleProps?.find(elem => elem.vehicleIndex === vehicleIndex);
          vehicle?.vehicleSimPropertyValues?.simPropertyValue?.forEach(prop => {
            if (prop.name) {
              this.markPropertyAndPropagate(this.filteredDataSource, prop.name);
              modified = true;
            }
          });
        }
        if (modified) {
          this.cdr.detectChanges();
        }
      }
    });
  }

  textToFilter = (text: string): Filter<string> => new Filter(SimPropertiesFilterType.PROPERTY, text);

  childrenAccessor = (node: SimPropertyTreeNode): SimPropertyTreeNode[] => node.children ?? [];

  hasChild = (_: number, node: SimPropertyTreeNode): boolean => !!node.children && node.children.length > 0;

  private updateTree(): void {
    if (this.simPropertiesGroup()?.length > 0) {
      this.dataSource = this.groupSimPropertiesByCategory(this.simPropertiesGroup(), this.displayGroupTitle()) ?? [];
      this.applyFilters();
      this.cdr.detectChanges();
    } else {
      this.dataSource = [];
      this.applyFilters();
    }
  }

  onSearchTextChange(text: string): void {
    this.state.filters.simPropertyText = text;
    this.applyFilters();
  }

  applyFilters(): void {
    if (!this.dataSource || !this.state) {
      return;
    }

    const search = [...this.state.filters.selectedFilters.map(filter => filter.searchValue), this.state.filters.simPropertyText]
      .filter(searchValue => !!searchValue)
      .join(' ');
    this.filteredDataSource = this.filterTree(this.dataSource, search.toLowerCase());
  }

  private filterTree(data: SimPropertyTreeNode[], filterText: string): SimPropertyTreeNode[] {
    return data
      .map(node => ({ ...node })) // Create a new copy to avoid mutations
      .filter(node => {
        if (node.children) {
          node.children = this.filterTree(node.children, filterText); // Recursive filtering
        }
        return node?.displayName?.toLowerCase()?.includes(filterText) || (node.children && node.children.length > 0);
      });
  }

  onCurrentValueUpdate(search: string): void {
    this.state.filters.search = search;
  }

  propertySelected(property: SimProperty): void {
    const index = this.selectedPropertyVehicleIndex();
    const name = this.selectedPropertyVehicleName();
    // index -1 means train
    const vehicleIndex = index === -1 ? undefined : index;
    const vehicleName = index === -1 ? undefined : name;

    this.markPropertyAndPropagate(this.filteredDataSource, property.name);

    this.selectedProperty.emit({ property, vehicleIndex, vehicleName });
  }

  markNodeAndPropagate(node: SimPropertyTreeNode, targetName: string): boolean {
    let childModified = false;

    // Mark child nodes first
    if (node.children && node.children.length > 0) {
      for (const child of node.children) {
        const childWasModified = this.markNodeAndPropagate(child, targetName);
        if (childWasModified) {
          childModified = true;
        }
      }
    }

    // Check if current node matches the target name
    if (node.name === targetName) {
      node.isModified = true;
      return true; // This node is marked as modified
    }

    // If any child was modified, mark this node as well
    if (childModified) {
      node.isModified = true;
      return true;
    }

    return false; // No modification in this subtree
  }

  // Function to initiate marking from the root level
  markPropertyAndPropagate(data: SimPropertyTreeNode[], propertyName: string): void {
    data.forEach(node => {
      this.markNodeAndPropagate(node, propertyName);
    });
  }

  /**
   * Groups sim property groups into a hierarchical tree structure based on category and optionally provider.
   *
   * @param simPropertyGroups - Array of sim property groups to be organized into a tree structure.
   * @param groupByProvider - Flag indicating whether to group properties by provider or by group name.
   * @returns - Returns an array of root nodes representing the tree structure of sim properties.
   *
   * Each sim property is organized into a tree under its provider or group, then further categorized by its category.
   * Properties are added as leaf nodes under the appropriate path based on their `simPropPath`.
   */
  private groupSimPropertiesByCategory(simPropertyGroups: SimPropertyGroup[], groupByProvider: boolean): SimPropertyTreeNode[] {
    const simPropertyTree: SimPropertyTreeNode[] = [];

    // This map will hold the provider-level or group-level nodes
    const providerMap = new Map<string, SimPropertyTreeNode>();

    simPropertyGroups.forEach(group => {
      group.simProperty.forEach(property => {
        // Determine the provider-level key based on groupByProvider flag
        const providerKey = groupByProvider ? property.provider : property.category;

        // Ensure the provider or category node exists, or create it
        if (!providerMap.has(providerKey)) {
          providerMap.set(providerKey, {
            name: providerKey,
            displayName: providerKey,
            children: [],
            isModified: false
          });
        }

        const providerNode = providerMap.get(providerKey);

        // If grouping by provider, group by group name as children of the provider node
        let groupNode: SimPropertyTreeNode | undefined;
        if (groupByProvider) {
          groupNode = providerNode?.children?.find(child => child.name === group.name);

          if (!groupNode) {
            groupNode = {
              name: group.name,
              displayName: group.name,
              children: [],
              isModified: false
            };
            providerNode?.children?.push(groupNode);
          }
        }

        // Create path nodes based on the simPropPath structure
        const pathParts = property.simPropPath.split('/').filter(part => part);
        let currentNode = groupNode || providerNode;

        pathParts.forEach(part => {
          // Find or create path node
          let pathNode = currentNode.children?.find(child => child.name === part);

          if (!pathNode) {
            pathNode = {
              name: part,
              displayName: part,
              children: [],
              isModified: false
            };
            currentNode.children?.push(pathNode);
          }

          // Move to the next path level
          currentNode = pathNode;
        });

        // Add the property at the deepest level of the path
        currentNode.children?.push({
          name: property.name,
          displayName: property.displayName,
          children: [], // SimProperty items don't have further children
          isModified: false
        });
      });
    });

    // Sorts each node and its children alphabetically by displayName
    const sortTree = (nodes: SimPropertyTreeNode[]): void => {
      nodes.forEach(node => {
        if (node.children?.length) {
          node.children.sort((a, b) => a.displayName.localeCompare(b.displayName));
        }
      });
    };

    const sortedTree = Array.from(providerMap.values());
    sortTree(sortedTree);
    simPropertyTree.push(...sortedTree);
    return simPropertyTree;
  }
}
