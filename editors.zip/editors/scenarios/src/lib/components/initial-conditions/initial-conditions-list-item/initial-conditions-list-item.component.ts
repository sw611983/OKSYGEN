/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, ElementRef, Input, input, OnChanges, OnInit, output, SimpleChanges } from '@angular/core';
import { AbstractControl, FormControl, UntypedFormControl, ValidationErrors } from '@angular/forms';
import { AutocompleteInputType, newFormControl, UpdateOn, validateMandatoryString } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { SimPropertyValues, TrainSimPropertyValues } from '@oksygen-sim-train-libraries/components-services/common';
import { SimProperty, SimPropertyGroup, SimPropertyState, SimPropertyTreeNode } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { debounceTime, Observable, Subscription, switchMap } from 'rxjs';

interface SimPropertyForm extends SimProperty {
  formControl?: UntypedFormControl;
}

@Component({
  selector: 'oksygen-initial-conditions-list-item',
  templateUrl: './initial-conditions-list-item.component.html',
  styleUrls: ['./initial-conditions-list-item.component.scss']
})
export class InitialConditionsListItemComponent implements OnInit, OnChanges {
  public readonly propertyData = input.required<SimPropertyTreeNode>();
  public readonly simPropertiesGroup = input.required<Array<SimPropertyGroup>>();
  public readonly isDraggable = input<boolean>();
  public readonly selectedPropertyName = input<string>();
  public readonly trainSimPropertiesAll = input<TrainSimPropertyValues>();
  public readonly selectedInitialConditions = input<TrainSimPropertyValues>();
  public readonly selectedPropertyVehicleIndex = input<number>();

  public readonly selectedProperty = output<SimProperty>();

  oksygenToolsIcon = OksygenIcon.TOOLS;
  selectedPropertyForm: SimPropertyForm;

  panelOpenState = false;

  formField = AutocompleteInputType.FORM_FIELD;
  values: SimPropertyState[];
  selectedState: SimPropertyState = undefined;
  defaultState: SimPropertyState;
  rawControl: FormControl = newFormControl();
  private subscription = new Subscription();
  @Input() triggerFormValidation$?: Observable<void>;

  constructor(private host: ElementRef) {}

  ngOnInit(): void {
    this.subscription.add(
      this.triggerFormValidation$?.subscribe(() => {
        this.rawControl.markAsTouched();
      })
    );
    if (this.simPropertiesGroup()) {
      this.rawControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null =>
        validateMandatoryString(control.value)
      );

      this.subscription.add(
        this.rawControl.valueChanges.pipe(debounceTime(750)).subscribe(value => {
          if (this.selectedPropertyForm?.rawValue !== value) {
            this.selectedPropertyEmitter(this.selectedPropertyForm, value);
          }
        })
      );

      this.initialiseProperties();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
      if (changes?.selectedInitialConditions?.currentValue !== changes?.selectedInitialConditions?.previousValue) {
        setTimeout(() => {
          this.rawControl?.setValue(this.selectedPropertyForm?.selectedState);
        });
      }
  }

  valueSelected(value: SimPropertyState): void {
    this.selectedState = value;
    this.selectedPropertyForm.formControl.setValue(value);
    this.propertySelected();
  }

  displayWith(value: SimPropertyState): string {
    return value?.name ?? '';
  }

  propertySelected(): void {
    this.selectedPropertyForm = this.getSelectedSimProperty();
    this.selectedPropertyEmitter(this.selectedPropertyForm, this.selectedState.name);
  }

  initialiseProperties(): void {
    const simProperty = this.getSelectedSimProperty();
    this.selectedPropertyForm = simProperty;
    this.defaultState = this.selectedPropertyForm?.states?.find(state => state.name === this.selectedPropertyForm.defaultState);
    // if(this.selectedPropertyForm.name === 'Battery Voltage3') {
    //   this.selectedPropertyForm.selectedState = '76 V';
    //   this.selectedState = this.selectedPropertyForm?.states.find(s => s.name === this.selectedPropertyForm.selectedState);
    // }
    // const scenarioSimprops = this.trainSimPropertiesAll()?.get(this.selectedPropertyVehicleIndex());

    let scenarioSimprops: SimPropertyValues;
    if (this.trainSimPropertiesAll()?.vehicleProps) {
      const vehicle = this.trainSimPropertiesAll()?.vehicleProps?.find(elem => elem.vehicleIndex === this.selectedPropertyVehicleIndex());
      if (vehicle) {
        scenarioSimprops = vehicle.vehicleSimPropertyValues;
      }
    }

    // for train vehicleIndex is -1
    if (this.selectedPropertyVehicleIndex() === -1) {
      scenarioSimprops = this.trainSimPropertiesAll()?.trainSimPropertyValues;
    }

    let simPropValuesArray = [];

    if (scenarioSimprops) {
      simPropValuesArray = Array.isArray(scenarioSimprops.simPropertyValue) ? scenarioSimprops.simPropertyValue : [scenarioSimprops.simPropertyValue];

      const simPropValue = simPropValuesArray.find(s => s.name === this.selectedPropertyForm.name);
      this.selectedPropertyForm.selectedState = simPropValue?.stateName;
      this.selectedState = this.selectedPropertyForm?.states?.find(s => s.name === this.selectedPropertyForm.selectedState);
    }

    let newFormControlEnum = new UntypedFormControl();
    if (this.selectedPropertyForm.selectedState) {
      newFormControlEnum = new UntypedFormControl(this.selectedState);
    }
    this.selectedPropertyForm.formControl = newFormControlEnum;
  }

  private getSelectedSimProperty(): SimPropertyForm {
    const simProperty: SimPropertyForm = this.simPropertiesGroup()
      .flatMap(sg => sg.simProperty)
      .find(s => s.name === this.propertyData().name);

    return simProperty;
  }

  selectedPropertyEmitter(simproperty: SimPropertyForm, value: string): void {
    simproperty.selectedState = value;
    this.selectedProperty.emit(simproperty);
  }

  resetClicked(): void {
    if (this.selectedPropertyForm) {
      if (!this.defaultState) {
        // If defaultState is not coming from Backend, in that case set it to the first state
        this.defaultState = this.selectedPropertyForm?.states[0];
      }
      if(this.selectedPropertyForm.rawValue) {
        this.defaultState.raw = this.selectedPropertyForm?.rawValue;
      }
      this.selectedPropertyForm.formControl.setValue(this.defaultState);
      this.selectedPropertyEmitter(this.selectedPropertyForm, this.defaultState.name);
    }
  }
}
