/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectionStrategy, ChangeDetectorRef, Component, effect, input, OnInit, output } from '@angular/core';
import { Filter, SelectedFilterArray } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { BrowserFilterText, BrowserState } from '@oksygen-sim-train-libraries/components-services/common';
import { TrainSimPropertyValues } from '@oksygen-sim-train-libraries/components-services/common';
import { SimProperty, SimPropertyGroup, SimPropertyTreeNode } from '@oksygen-sim-train-libraries/components-services/sim-properties';

interface SimPropertyFilterFields extends BrowserFilterText {
  simPropertyText: string;
}

type SimPropertiesState = BrowserState<SimPropertyFilterFields, string>;

enum SimPropertiesFilterType {
  // ```no-mat-icon``` prefix prevents the chip list from displaying mat-icons
  PROPERTY = 'no-mat-icon-sim_property'
}

@Component({
  selector: 'oksygen-initial-conditions-list',
  templateUrl: './initial-conditions-list.component.html',
  styleUrl: './initial-conditions-list.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialConditionsListComponent implements OnInit {
  public readonly displayGroupTitle = input<boolean>(false);
  public readonly selectedPropertyName = input<string>();
  public readonly isDraggable = input<boolean>(false);
  public readonly simPropertiesGroupMap = input<Map<string, SimPropertyGroup[]>>();
  public readonly trainSimPropertiesAll = input<TrainSimPropertyValues>();
  public readonly selectedInitialConditions = input<TrainSimPropertyValues>();

  numberOfProperties = input<number>(0);

  public readonly selectedProperty = output<{
    property: SimProperty;
    vehicleIndex: number;
    vehicleName: string;
  }>();

  oksygenToolsIcon = OksygenIcon.TOOLS;
  simPropGrpTempArray: [string, SimPropertyGroup[]][] = [];

  filteredSimPropGrpTempArray: [string, SimPropertyGroup[]][] = [];

  dataSource: Array<SimPropertyTreeNode>;
  searchQuery: string;
  filteredDataSource: SimPropertyTreeNode[] = [];

  simPropertiesGrouped: Map<string, SimPropertyTreeNode> = new Map();

  state: SimPropertiesState;

  prefixIcon = OksygenIcon.LIST_ALT;
  placeHolder = 'Search for properties';

  numOfPropTrain = 0;
  numOfPropVeh: number[];

  constructor(private uiStateModelManager: UiStateModelManager, private cdr: ChangeDetectorRef) {
    this.state = this.uiStateModelManager.getStateModel<any>('InitialConditionsListComponent', () => ({
      filters: {
        simPropertyText: '',
        selectedFilters: new SelectedFilterArray<string>()
      }
    }));

    effect(() => {
      if (this.selectedInitialConditions()) {
        this.numOfPropTrain = this.selectedInitialConditions()?.trainSimPropertyValues?.simPropertyValue?.length;
        if (this.numOfPropTrain === undefined) {
          this.numOfPropTrain = 0;
        }

        const vehicleProps = this.selectedInitialConditions()?.vehicleProps ?? [];

        for (const vehicle of vehicleProps) {
          const vehicleIndex = vehicle.vehicleIndex;
          const simPropsLength = vehicle.vehicleSimPropertyValues?.simPropertyValue?.length || 0;

          this.numOfPropVeh[vehicleIndex] = simPropsLength;
        }

        this.cdr.detectChanges();
      }
    });

    effect(() => {
      if (this.simPropertiesGroupMap()) {
        this.simPropGrpTempArray = Array.from(this.simPropertiesGroupMap().entries());

        const last = this.simPropGrpTempArray.pop();
        if (last) {
          this.simPropGrpTempArray.unshift(last);
        }

        // Initialize filtered array
        this.applyFilters();
      }
    });
  }

  ngOnInit(): void {
    const arrSize = this.simPropertiesGroupMap()?.size;
    this.numOfPropVeh = [];

    for (let i = 0; i < arrSize; i++) {
      this.numOfPropVeh[i] = 0;
    }
  }

  textToFilter = (text: string): Filter<string> => new Filter(SimPropertiesFilterType.PROPERTY, text);

  childrenAccessor = (node: SimPropertyTreeNode): SimPropertyTreeNode[] => node.children ?? [];

  hasChild = (_: number, node: SimPropertyTreeNode): boolean => !!node.children && node.children.length > 0;

  onSearchTextChange(text: string): void {
    this.state.filters.simPropertyText = text;
    this.applyFilters();
  }

  applyFilters(): void {
    if (!this.simPropertiesGroupMap()) return;
    const searchText = this.state.filters.simPropertyText?.toLowerCase() ?? '';
    const resultArray: [string, SimPropertyGroup[]][] = [];
    let trainEntry: [string, SimPropertyGroup[]] | null = null;
    for (const [key, groups] of this.simPropertiesGroupMap().entries()) {
      const filteredGroups: SimPropertyGroup[] = [];
      for (const group of groups) {
        const filteredSimProps = group.simProperty.filter(prop => prop.displayName.toLowerCase().includes(searchText));
        if (filteredSimProps.length > 0) {
          filteredGroups.push({
            ...group,
            simProperty: filteredSimProps
          });
        }
      }
      if (filteredGroups.length > 0) {
        const entry: [string, SimPropertyGroup[]] = [key, filteredGroups];
        if (filteredGroups[0]?.provider === 'train') {
          trainEntry = entry;
        } else {
          resultArray.push(entry);
        }
      }
    }
    // Put train first
    this.filteredSimPropGrpTempArray = trainEntry ? [trainEntry, ...resultArray] : resultArray;
  }

  propertySelected(event: { property: SimProperty; vehicleIndex: number | undefined; vehicleName: string | undefined }): void {
    this.selectedProperty.emit({ property: event.property, vehicleIndex: event.vehicleIndex, vehicleName: event.vehicleName });
  }
}
