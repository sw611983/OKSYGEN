/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Inject, OnInit, signal } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { cloneDeep } from 'lodash';

import { SimPropertiesService, SimProperty, SimPropertyGroup } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { SimPropertyValue, TrainSimPropertyValues } from '@oksygen-sim-train-libraries/components-services/common';
import { InitalConditionsDialogData } from '../../../models/initial-conditions.model';

@Component({
  selector: 'oksygen-initial-conditions-dialog',
  templateUrl: './initial-conditions-dialog.component.html',
  styleUrls: ['./initial-conditions-dialog.component.scss']
})
export class InitalConditionsDialogComponent implements OnInit {
  selectedProperty: SimProperty;
  selectedProperties: Map<number, SimProperty[]> = new Map();
  selectedInitialConditions: TrainSimPropertyValues = undefined;
  selectedInitialConditionsSignal = signal<TrainSimPropertyValues | undefined>(undefined);

  simPropertiesGroup: Array<SimPropertyGroup>;

  simPropertiesGroupMap: Map<string, SimPropertyGroup[]> = new Map();

  displayedColumns: string[] = ['position', 'type', 'name', 'status'];

  trainSimPropMap: Map<string, SimPropertyGroup[]> = new Map();

  constructor(
    public dialogRef: MatDialogRef<InitalConditionsDialogComponent, TrainSimPropertyValues>,
    @Inject(MAT_DIALOG_DATA) public data: InitalConditionsDialogData,
    private simPropertiesService: SimPropertiesService
  ) {
    if (data?.train) {
      const allSimProperties: Map<string, SimPropertyGroup[]> = cloneDeep(
        this.simPropertiesService?.getAllVehicleInitialConditionSimProperties(data?.train?.consistId, data?.isDriven)
      );
      const trainSimProp: SimPropertyGroup[] = cloneDeep(
        this.simPropertiesService?.getConsistTrainInitialConditionSimProperties(data?.train?.consistId, data?.isDriven)
      );

      this.trainSimPropMap.set(data.train.scenarioTrainName, trainSimProp);

      if (allSimProperties) {
        // TODO
        // adding the train sim properties at the end of the map, Once dbAccess is merged refactor this as it will train and vehicle data in same response
        allSimProperties.set(data.train.scenarioTrainName, trainSimProp);
      }

      this.simPropertiesGroupMap = allSimProperties;
    }
  }

  ngOnInit(): void {
    this.selectedInitialConditions = this.data?.trainInitialConditions
      ? cloneDeep(this.data?.trainInitialConditions)
      : {
          trainId: this.data?.train?.scenarioTrainName ?? '',
          trainSimPropertyValues: { simPropertyValue: [] },
          vehicleProps: []
        };

    this.selectedInitialConditionsSignal.set(this.selectedInitialConditions);
  }

  onReset(): void {
    this.dialogRef.close(null);
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onApply(): void {
    this.dialogRef.close(this.selectedInitialConditions);
  }

  propertySelected(event: { property: SimProperty; vehicleIndex?: number; vehicleName?: string }): void {
    this.selectedProperty = event.property;

    const property = event.property;
    const vehicleIndex = event.vehicleIndex;
    const vehicleName = event.vehicleName;

    const temp: SimPropertyValue = {
      name: property.name,
      stateName: property.selectedState,
      category: property.category
    };

    let prevProps: TrainSimPropertyValues;

    if (this.selectedInitialConditions) {
      prevProps = cloneDeep(this.selectedInitialConditions); // store previous selections
    }

    // Restore previous selections
    if (prevProps) {
      // Merge train-level properties
      if (prevProps.trainSimPropertyValues?.simPropertyValue?.length) {
        const currentTrainProps = this.selectedInitialConditions.trainSimPropertyValues.simPropertyValue;
        for (const p of prevProps.trainSimPropertyValues.simPropertyValue) {
          const exists = currentTrainProps.find(cp => cp.name === p.name);
          if (!exists) {
            currentTrainProps.push(p);
          }
        }
      }

      // Merge vehicle-level properties
      if (prevProps.vehicleProps?.length) {
        for (const prevVehicle of prevProps.vehicleProps) {
          const vehicle = this.selectedInitialConditions.vehicleProps.find(v => v.vehicleIndex === prevVehicle.vehicleIndex);

          if (!vehicle) {
            this.selectedInitialConditions.vehicleProps.push(prevVehicle);
          } else {
            const currentProps = vehicle.vehicleSimPropertyValues.simPropertyValue;
            for (const vp of prevVehicle.vehicleSimPropertyValues.simPropertyValue) {
              const exists = currentProps.find(cp => cp.name === vp.name);
              if (!exists) {
                currentProps.push(vp);
              }
            }
          }
        }
      }
    }

    // Now apply the new selection
    if (vehicleIndex === undefined) {
      this.selectedInitialConditions.trainSimPropertyValues ??= { simPropertyValue: [] };
      const simProps = this.selectedInitialConditions.trainSimPropertyValues.simPropertyValue;

      const existing = simProps.find(p => p.name === temp.name);
      if (existing) {
        existing.stateName = temp.stateName;
        existing.category = temp.category;
      } else {
        simProps.push(temp);
      }
    } else {
      this.selectedInitialConditions.vehicleProps ??= [];
      let vehicle = this.selectedInitialConditions.vehicleProps.find(v => v.vehicleIndex === vehicleIndex);

      if (!vehicle) {
        vehicle = {
          vehicleIndex,
          vehicleName,
          vehicleSimPropertyValues: { simPropertyValue: [] }
        };
        this.selectedInitialConditions.vehicleProps.push(vehicle);
      }

      vehicle.vehicleSimPropertyValues.simPropertyValue = Array.isArray(vehicle.vehicleSimPropertyValues?.simPropertyValue)
        ? vehicle.vehicleSimPropertyValues.simPropertyValue
        : [vehicle.vehicleSimPropertyValues.simPropertyValue];

      const simProps = (vehicle.vehicleSimPropertyValues.simPropertyValue ??= []);

      const existing = simProps.find(p => p.name === temp.name);
      if (existing) {
        existing.stateName = temp.stateName;
        existing.category = temp.category;
      } else {
        simProps.push(temp);
      }
    }

    this.selectedInitialConditionsSignal.set(cloneDeep(this.selectedInitialConditions));
  }
}
