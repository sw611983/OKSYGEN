/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ActivatedRouteSnapshot } from '@angular/router';
import { ScenarioRouteReuseStrategy } from './scenario-route-reuse-strategy';

describe('Scenario Route Reuse Strategy', () => {
  let scenario: ScenarioRouteReuseStrategy;
  beforeEach(() => {
    scenario = new ScenarioRouteReuseStrategy();
  });

  it('should be created', () => {
    expect(scenario).toBeTruthy();
  });
  it('should get a route path', () => {
    expect(scenario.getRoutePath()).toEqual('scenarios/:id');
  });
  it('should get a store key', () => {
    const route = new ActivatedRouteSnapshot();
    route.params = { id: 1 };
    expect(scenario.getStoreKey(route)).toBeNull();
    (route as any).routeConfig = { path: 'scenarios/:id' };
    expect(scenario.getStoreKey(route)).toEqual('scenarios/1');
  });
  it('should get a store key by id', () => {
    expect(scenario.getStoreKeyById('1')).toEqual('scenarios/1');
    expect(scenario.getStoreKeyById('35')).toEqual('scenarios/35');
  });
});
