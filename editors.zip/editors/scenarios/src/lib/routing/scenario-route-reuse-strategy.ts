/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { scenarioEditorPage } from './scenario.-editor.routing';
import { AbstractRouteReuseStrategy } from '@oksygen-sim-train-libraries/components-services/routing';

/**
 * This will cache scenario routes (scenario/id).
 */
export class ScenarioRouteReuseStrategy extends AbstractRouteReuseStrategy {

  getRoutePath(): string {
      return scenarioEditorPage.path;
  }

  override getStoreKeyById(id: string): string {
    return scenarioEditorPage.path.replace(':id', `${id}`);
  }
}
