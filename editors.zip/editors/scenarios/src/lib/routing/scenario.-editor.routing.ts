/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Route } from '@angular/router';

import { RouteConfig, RoutingPage } from '@oksygen-common-libraries/material/components';

import { ScenarioBrowserComponent } from '../components/scenario-browser/scenario-browser.component';
import { ScenarioEditorComponent } from '../components/scenario-editor/scenario-editor.component';
import { defaultScenarioEditorConfig } from '../models/default-scenario-editor-config.model';

export const scenarioBrowserPage: RoutingPage = {
  path: 'scenarios',
  component: ScenarioBrowserComponent
};

export function scenarioBrowserRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  return { path: scenarioBrowserPage.path, component: scenarioBrowserPage.component, canActivate: auth };
}

export const scenarioEditorPage: RoutingPage = {
  path: 'scenarios/:id',
  component: ScenarioEditorComponent
};

export function scenarioEditorRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  const data = config?.data ?? defaultScenarioEditorConfig();
  return { path: scenarioEditorPage.path, component: scenarioEditorPage.component, canActivate: auth, data };
}
