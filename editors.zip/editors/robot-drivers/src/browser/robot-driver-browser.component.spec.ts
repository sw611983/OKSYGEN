/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainRobotDriverEditModule } from '../robot-driver.module';
import { RobotDriverBrowserComponent } from './robot-driver-browser.component';

describe('RobotDriverBrowserComponent', () => {
  let component: RobotDriverBrowserComponent;
  let fixture: ComponentFixture<RobotDriverBrowserComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [ OksygenSimTrainEditorsModule, OksygenSimTrainRobotDriverEditModule ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RobotDriverBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
