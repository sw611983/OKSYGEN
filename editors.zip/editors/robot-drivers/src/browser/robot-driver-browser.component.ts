/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ChangeDetectorRef, Component, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { cloneDeep } from 'lodash';
import moment from 'moment';
import { BehaviorSubject, map, Observable, of, Subscription, from } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { Author, generateUuid, getCreated, getLastModified, PUBLISHED_STATUS, SuperCalled, UNKNOWN } from '@oksygen-common-libraries/common';
import {
  allFilterTypesMatch,
  AutocompleteInputType,
  BasicTabNavItemComponent,
  Breadcrumb,
  CANCEL_BUTTON,
  FileManagerTableComponent,
  FileManagerTableData,
  Filter,
  filterMatches,
  PromptDialogComponent,
  PromptDialogData,
  SelectedFilterArray,
  SideNavService,
  Sorter,
  TabService
} from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { Logging } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { User, UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { BrowserFilterText, BrowserState, EditorBrowserFilterIOConfig, newName, uniqueItemName } from '@oksygen-sim-train-libraries/components-services/common';
import { BaseBrowserTabPage, DetailsToolbarComponent } from '@oksygen-sim-train-libraries/components-services/editors';
import { DriverModel, RobotDriver, RobotDriverService } from '@oksygen-sim-train-libraries/components-services/robot-drivers';

import { RobotDriverDialogComponent, RobotDriverDialogData } from '../editor/robot-driver-dialog.component';
import { ROBOT_DRIVERS_CARD_DATA, RobotDriverTableData, RobotDriverTabType } from '../models/robot-driver-table-data.model';
import { RobotDriverEditService } from '../services/robot-driver-edit/robot-driver-edit.service';
import { RobotDriverEditorService } from '../services/robot-driver-editor.service';

enum FilterType {
  // These names are used to select the icon on chips of that type
  DRIVER = 'robot',
  AUTHOR = 'author'
}
interface RobotDriverFilterFields extends BrowserFilterText {
  driverText: string;
  authorText: string;
}

//type RobotBrowserState = BrowserState<RobotDriverFilterFields, string>;
export function deleteRobotdriverPromptDialogData(robotdriverName: string[]): PromptDialogData {
  const promptData = new PromptDialogData();

  // FIXME More meaningful message please
  promptData.title =
    robotdriverName.length > 1 ? t('Are you sure you want to delete these robot drivers?') : t('Are you sure you want to delete this robot driver?');
  promptData.content = robotdriverName.length > 1 ? robotdriverName : `<b>${robotdriverName}</b>`;
  promptData.buttons = promptData.buttons = [
    {
      color: 'warn',
      text: t('Delete'),
      data: true
    },
    CANCEL_BUTTON
  ];
  return promptData;
}
@Component({
  selector: 'oksygen-robot-driver-browser',
  templateUrl: './robot-driver-browser.component.html',
  styleUrls: ['./robot-driver-browser.component.scss']
})
export class RobotDriverBrowserComponent
  extends BaseBrowserTabPage<RobotDriver, RobotDriverTableData, RobotDriverFilterFields, string>
  implements OnInit, OnDestroy
{
  readonly DEFAULT_ROBOTDRIVER_NAME: string = t('New Robot Template');
  readonly BREADCRUMB: Breadcrumb = {
    text: t('Robot Drivers'),
    icon: 'robot'
  };

  // override state: RobotBrowserState;

  @ViewChild(FileManagerTableComponent) fileManagerTable: FileManagerTableComponent<RobotDriverTableData>;

  selectedRobotDriver: RobotDriver;
  allDriverNames: string[];
  isBusy = false;

  autoCompleteType = AutocompleteInputType.FORM_FIELD;
  authors: readonly User[];

  override sorter = new Sorter<any>();
  override columns: FileManagerTableData[] = [];
  override displayedColumns: string[] = ['name', 'created', 'modified', 'status'];

  tableDrivers: RobotDriverTableData[] = [];
  drivers: RobotDriver[];
  driverModels: DriverModel[] = [];

  private subscription = new Subscription();

  constructor(
    private robotDriverService: RobotDriverService,
    private robotDriverEditorService: RobotDriverEditorService,
    private robotDriverEditService: RobotDriverEditService,
    private userService: UserService,
    public dialog: MatDialog,
    private snackbar: MatSnackBar,
    translateService: TranslateService,
    logger: Logging,
    tabService: TabService,
    sideNavService: SideNavService,
    router: Router,
    private cd: ChangeDetectorRef,
    private uiStateModelManager: UiStateModelManager
  ) {
    super(
      {
        create: { visible: true, enabled: true },
        delete: { visible: true, enabled: true },
        duplicate: { visible: true, enabled: true },
        edit:    { visible: true, enabled: true },
        open: { visible: false, enabled: false },
        search: { visible: true, enabled: true },
        refresh: { visible: true, enabled: true }
      },
      robotDriverEditorService,
      sideNavService,
      router,
      ROBOT_DRIVERS_CARD_DATA,
      tabService,
      logger,
      translateService,
      dialog
    );
    this.editDisabled.set(true);
    this.duplicateDisabled.set(true);
    this.deleteDisabled.set(true);
    this.printDisabled.set(true);
    this.refreshDisabled.set(true);

    this.detailEditDisabled.set(false);
    this.detailDuplicateDisabled.set(true);
    this.detailDeleteDisabled.set(false);
    this.detailPrintDisabled.set(true);

    this.detailEditTooltip = DetailsToolbarComponent.DEFAULT_EDIT_TOOLTIP;
  }

  override ngOnInit(): SuperCalled {
    const superCalled = super.ngOnInit();
    this.pageOpening();
    // this.filters.set(this.initialiseFilterConfig());

    this.state = this.uiStateModelManager.getStateModel<any>('RobotDriverBrowserComponent', () => ({
      filters: {
        driverText: '',
        authorText: '',
        selectedFilters: new SelectedFilterArray<string>()
      }
    }));

    const modelSubscription = this.robotDriverEditorService.getModels(true).subscribe(models => {
      this.driverModels = models;
    });

    this.robotDriverService.reloadData();
    const robotDriverSubscription = this.robotDriverService.data().subscribe((data: RobotDriver[]) => {
      this.updateRobot(data);
      this.cd.markForCheck();
    });

    this.authors = this.userService.users;

    this.subscription.add(modelSubscription);
    this.subscription.add(robotDriverSubscription);

    const robotDriverTab: RobotDriverTabType = {
      data: {
        id: ROBOT_DRIVERS_CARD_DATA.id,
        groupId: ROBOT_DRIVERS_CARD_DATA.id,
        icon: OksygenIcon.FILE_MANAGER,
        routerLink: ROBOT_DRIVERS_CARD_DATA.routerLink,
        name: t('Manager'),
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => of(true),
        onClose: () => {
          this.tabClosing();
          this.clearFilters();
        }
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: ROBOT_DRIVERS_CARD_DATA.id,
        groupName: ROBOT_DRIVERS_CARD_DATA.name,
        route: ROBOT_DRIVERS_CARD_DATA.routerLink,
        // groupIcon: ROBOT_DRIVERS_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [robotDriverTab],
      childrenIndex: 0
    });
    return superCalled;
  }
  ngOnDestroy(): void {
    this.pageClosing();
    this.setSelectedTableData();
    this.subscription.unsubscribe();
  }

  toTableData(drivers: RobotDriver[]): RobotDriverTableData[] {
    const tableDrivers =
      drivers?.map(driver => {
        const created = getCreated(driver?.history);
        // last modifed is the one with the most recent timestamp
        const modified = getLastModified(driver?.history);
        const createdName = created ? `${created.authorFirstName} ${created.authorLastName}` : UNKNOWN;
        const lastModifedName = modified ? `${modified.authorFirstName} ${modified.authorLastName}` : UNKNOWN;
        const td: RobotDriverTableData = {
          created: { avatar: null, date: created?.timestamp ? moment(created?.timestamp) : null, name: createdName },
          modified: { avatar: null, date: modified?.timestamp ? moment(modified?.timestamp) : null, name: lastModifedName },
          name: driver.name,
          status: PUBLISHED_STATUS,
          behaviours: driver.behaviours,
          model: driver.model,
          id: driver.id
        };
        const selectedData = this.editorService.getSelectedTableData()?.find(selected => selected?.name === driver.name);
        td.fmtChecked = !!selectedData?.fmtChecked;
        td.fmtSelected = !!selectedData?.fmtSelected;
        return td;
      }) ?? [];
    return tableDrivers;
  }

  sorterFunction(c: string, a: RobotDriverTableData, b: RobotDriverTableData): number {
    switch (c) {
      case 'name': {
        return a.name.localeCompare(b.name, this.getCurrentLocale());
      }
      case 'created': {
        return a.created.date.isBefore(b.created.date) ? 1 : -1;
      }
      case 'modified': {
        return a.modified.date.isBefore(b.modified.date) ? 1 : -1;
      }
      case 'status': {
        return a.status.localeCompare(b.status, this.getCurrentLocale());
      }
      default: {
        return 0;
      }
    }
  }

  import(): void {
    this.logger.log('import');
  }

  export(): void {
    this.logger.log('export');
  }

  onRefresh(): void {
    this.robotDriverService.reloadData();
  }

  override refreshClick(): void {
    this.onRefresh();
    this.setSelectedTableData();
  }

  override duplicateClick(): void {
    const existingNames = this.drivers?.map(d => d.name) ?? [];
    const oldName = existingNames.join(',');
    const name = newName(`${this.selectedRobotDriver.name}`, this.translateService, existingNames);
    const selectedDriver = this.drivers.find(dm => dm.name === this.selectedRobotDriver.name);
    const id = generateUuid();
    const driver = cloneDeep({ ...selectedDriver, name, id, version: '1', history: [] });
    const data: RobotDriverDialogData = { driver, mode: 'new', otherDriverNames: this.allDriverNames };
    const duplicateDialog = this.dialog.open<RobotDriverDialogComponent, RobotDriverDialogData, RobotDriver>(RobotDriverDialogComponent, {
      width: '980px',
      height: '870px',
      disableClose: true,
      data
    });
    duplicateDialog.afterClosed().subscribe(duplicatedDriver => {
      this.robotDriverEditService.getEditManager(this.selectedRobotDriver.id).saveRobotdriver(duplicatedDriver, oldName);
    });
    this.setSelectedTableData();
  }

  @HostListener('window:keydown.enter', ['$event'])
  override openEvent(event: KeyboardEvent): void {
    event.preventDefault();
    if (this.dialog.openDialogs.length === 0 && !this.editDisabled) {
      this.editClick();
    }
  }

  @HostListener('window:keydown.delete', ['$event'])
  override deleteEvent(event: KeyboardEvent): void {
    event.preventDefault();
    if (this.dialog.openDialogs.length === 0 && !this.deleteDisabled) {
      this.deleteClick();
    }
  }

  @HostListener('dblclick', ['$event'])
  override doubleClickEvent(event: MouseEvent): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.dialog.openDialogs.length === 0 && !this.editDisabled) {
      this.editClick();
    }
  }

  addDriverFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(FilterType.DRIVER, value));
    this.fileManagerTable.applyFilter();
  }

  onDriverTextChange(text: string): void {
    this.state.filters.driverText = text;
    this.fileManagerTable.applyFilter();
  }

  addAuthorFilter(value: Author | string): void {
    const name = typeof value === 'object' ? value.name : value;
    this.state.filters.selectedFilters.push(new Filter(FilterType.AUTHOR, name, null));
    this.fileManagerTable.applyFilter();
  }

  onAuthorTextChange(text: Author): void {
    this.state.filters.authorText = typeof text === 'object' ? text.name : text;
    this.fileManagerTable.applyFilter();
  }

  displayAuthor(value: User): string {
    return value?.username;
  }

  applyFilters(driver: RobotDriverTableData): boolean {
    const authors = [driver.created?.name, driver.modified?.name];
    if (
      !allFilterTypesMatch(
        [
          { t: FilterType.DRIVER, v: driver.name },
          { t: FilterType.AUTHOR, v: authors }
        ],
        this.state.filters.selectedFilters
      )
    ) {
      return false;
    }

    if (!filterMatches(driver.name, this.state.filters.driverText)) {
      return false;
    }

    if (!filterMatches(authors, this.state.filters.authorText)) {
      return false;
    }

    return true;
  }

  override selectionChanged(): void {
    const selectedValues = this.fileManagerTable?.getSelectedValues();
    this.selectedCount.set(selectedValues ? selectedValues.length : 0);
    if (this.selectedCount() > 0) {
      const singleSelected = selectedValues.length === 1;

      if (singleSelected) {
        this.selectedTableData.set(selectedValues[0]);
        this.selectedRobotDriver = this.drivers.find(d => d.name === this.selectedTableData.name);
        this.selectedRobotDriver = this.drivers.find(d => d.id === this.selectedTableData().id);
      }

      this.editDisabled.set(!singleSelected);
      this.duplicateDisabled.set(!singleSelected);
      this.deleteDisabled.set(false);
    } else {
      this.editDisabled.set(true);
      this.duplicateDisabled.set(true);
      this.deleteDisabled.set(true);
      this.printDisabled.set(true);
    }
  }

  cellClicked(value: RobotDriverTableData): void {}

  override updateSort(sort: Sort): void {
    this.fileManagerTable.updateSort(sort);
  }

  private updateRobot(data: RobotDriver[]): void {
    if (data) {
      const tableDrivers = this.toTableData(data);
      //const tableDrivers = this.toTableData(data);
      this.drivers = data;
      this.allDriverNames = this.drivers.map(d => d.id);
      this.tableDrivers = tableDrivers;
    }
  }

  // FIXME Use this from base class once implementation of this component is matched with other editors browser component
  protected override setSelectedTableData(): void {
    this.editorService.setSelectedTableData(this.fileManagerTable?.getSelectedValues());
  }

  onFilterChange(): void {
    this.fileManagerTable.applyFilter();
  }

  protected initialiseFilterConfig(): EditorBrowserFilterIOConfig<RobotDriver>[] {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;
    const robotDriverFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: OksygenIcon.ROBOT,
        placeholder: 'Robot drivers',
        value: this.state?.filters?.driverText
      },
      outputs: {
        currentValue: this.onDriverTextChange.bind(self),
        selectedValue: this.addDriverFilter.bind(self)
      }
    };

    const authorFilter: EditorBrowserFilterIOConfig<Author> = {
      inputs: {
        icon: OksygenIcon.AUTHOR,
        placeholder: t('Author'),
        value: this.state?.filters?.authorText
      },
      outputs: {
        currentValue: this.onAuthorTextChange.bind(self),
        selectedValue: this.addAuthorFilter.bind(self)
      }
    };
    const filterConfig: EditorBrowserFilterIOConfig<any>[] = [robotDriverFilter, authorFilter];
    return filterConfig;
  }
  onScormTextChange(text: string): void {
    this.state.filters.scormPackageText = text;
    this.fileManagerTable.applyFilter();
  }

  override onImport(): void {
    this.logger.log('import');
    // TODO: Implement
  }
  override onExport(): void {
    this.logger.log('export');
  }
  override onEdit(item: RobotDriver): void {
    this.editClick();
  }
  override onDelete(item: RobotDriver | RobotDriver[]): void {
    this.deleteClick();
  }
  override onPublish(item: RobotDriver | RobotDriver[], isActive: boolean): void {
    throw new Error('Method not implemented.');
  }
  override onPrint(item: RobotDriver | RobotDriver[]): void {
    this.logger.log('print');
  }
  override onDuplicate(item: RobotDriver): void {
    this.logger.log('duplicate');
  }
  override onCreate(): void {
    this.createNew();
  }
  protected override initialiseState(): BrowserState<RobotDriverFilterFields, string> {
    //throw new Error('Method not implemented.');
    return this.uiStateModelManager.getStateModel<any>('RobotDriverBrowserComponent', () => ({
      filters: {
        driverText: '',
        authorText: '',
        selectedFilters: new SelectedFilterArray<FilterType>()
      }
    }));
  }
  protected override initialiseColumns(): FileManagerTableData[] {
    const columns: FileManagerTableData[] = [];
    return columns;
  }
  protected override initialiseDisplayedColumns(): string[] {
    const displayedColumns: string[] = ['name', 'created', 'modified', 'status'];
    return displayedColumns;
  }
  protected override getItemFromTableItem(data: RobotDriverTableData): RobotDriver {
    if (!data || !this.data) {
      return null;
    }
    return this.data().find(robotdriver => robotdriver.id === data.id);
  }

  createNew(): void {
    const name = uniqueItemName(this.data, (item: RobotDriver) => item.name, this.DEFAULT_ROBOTDRIVER_NAME);
    const existingNames = this.drivers?.map(d => d.name) ?? [];
    const oldName = existingNames.join(',');
    this.robotDriverEditService.newRobotDriver(name).then((id: string) => {
      const driver = this.robotDriverEditorService.newDriver(existingNames);
      const data: RobotDriverDialogData = { driver, mode: 'new', otherDriverNames: this.allDriverNames };
      const createDialog = this.dialog.open<RobotDriverDialogComponent, RobotDriverDialogData, RobotDriver>(RobotDriverDialogComponent, {
        width: '980px',
        height: '870px',
        disableClose: true,
        data
      });
      createDialog.afterClosed().subscribe(result => {
        if (result) {
          this.robotDriverEditService.getEditManager(id).saveRobotdriver(result, oldName);
        }
      });
    });
    this.setSelectedTableData();
  }

  override editClick(): void {
    this.robotDriverEditService.loadRobotdriver(this.selectedRobotDriver);
    this.startEditing(this.selectedRobotDriver.id);
    this.setSelectedTableData();
  }

  private startEditing(id: string): void {
    const driver = this.drivers.find(dm => dm.id === this.selectedRobotDriver.id);
    const data: RobotDriverDialogData = {
      driver,
      mode: 'edit',
      otherDriverNames: this.allDriverNames.filter(name => name !== this.selectedTableData?.name)
    };
    const oldName = this.selectedRobotDriver.id;
    const editDialog = this.dialog.open<RobotDriverDialogComponent, RobotDriverDialogData, RobotDriver>(RobotDriverDialogComponent, {
      width: '980px',
      height: '870px',
      disableClose: true,
      data
    });

    editDialog.afterClosed().subscribe(updatedDriver => {
      if (updatedDriver) {
        this.robotDriverEditService.getEditManager(id).saveRobotdriver(updatedDriver, oldName);
      }
    });
    this.setSelectedTableData();
  }

  private destroyManagers(id: string): void {
    this.robotDriverEditService.destroyManagers(id);
  }

  private doDeleteRobotDriver(robotDriver: RobotDriver): Observable<void> {
    return this.robotDriverEditService.deleteRobotdriver(robotDriver).pipe(
      map(() => {
        const id = robotDriver.id;

        if (this.tabService.getTabGroupItem(ROBOT_DRIVERS_CARD_DATA.id, id.toString())) {
          this.tabService.removeItemFromTabGroup(ROBOT_DRIVERS_CARD_DATA.id, { id: id.toString() }, true);
          this.destroyManagers(id);
        }
      })
    );
  }

  override deleteClick(): void {
    const dialogConfig: MatDialogConfig = this.getDialogConfig();
    const selectedDrivers = this.fileManagerTable.getSelectedValues();
    if (selectedDrivers.length === 0) {
      return;
    }
    dialogConfig.data = deleteRobotdriverPromptDialogData(
      selectedDrivers.map(driver => driver.name)
    );
    PromptDialogComponent.open(this.dialog, dialogConfig, dialogResult => {
      if (dialogResult) {
        this.isBusy = true;
        from(selectedDrivers)
          .pipe(
            mergeMap(
              driverSummary => this.doDeleteRobotDriver(this.findDriverById(driverSummary.id)),
              5 // Limit concurrency
            )
          )
          .subscribe({
            complete: () => this.onDeleteComplete(),
            error: () => this.onDeleteError()
          });
      }
    });
  }

  private getDialogConfig(): MatDialogConfig {
    return {
      disableClose: true,
      minHeight: '100px',
      minWidth: '400px',
      panelClass: 'small-whitespace-dialog'
    };
  }
  private findDriverById(id: string): RobotDriver {
    return this.drivers.find(driver => driver.id === id);
  }

  private onDeleteComplete(): void {
    this.robotDriverService.reloadData();
    this.isBusy = false;
  }

  private onDeleteError(): void {
    this.isBusy = false;
  }
}
