/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { TabService } from '@oksygen-common-libraries/material/components';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { ConfirmResult, unsavedChangesDialog } from '@oksygen-sim-train-libraries/components-services/common';
import { RobotDriver, RobotDriverService } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { map, Observable, of, Subscription, switchMap, tap } from 'rxjs';
import { ROBOT_DRIVERS_CARD_DATA } from '../../models/robot-driver-table-data.model';
import { RobotDriverEditorService } from '../robot-driver-editor.service';
export type RobotDriverEditorMode = 'new' | 'edit' | 'detail';

export class RobotDriverEditManager {
  private originalRobotDriver: RobotDriver;
  robotdriver: RobotDriver;
  allRobotDriver: RobotDriver[];
  saveButtonDisabled = false;
  mode: string;

  private file: File;

  private readonly subscription = new Subscription();

  private unsavedChanges = false;

  constructor(
    public id: string,
    private authService: AuthService,
    private robotDriverEditorService: RobotDriverEditorService,
    private robotDriverService: RobotDriverService,
    private dialog: MatDialog,
    private translateService: TranslateService,
    private tabService: TabService,
    private snackbar: MatSnackBar,
    private readonly zone: NgZone
  ) {}

  destroy(): void {
    this.subscription.unsubscribe();
  }

  public newRobotDriver(name: string): void {
    this.originalRobotDriver = null;
    this.robotdriver = this.createNewRobotdriver(this.id, name);
  }

  public loadRobotdriver(robotdriver: RobotDriver): void {
    this.originalRobotDriver = robotdriver;
    this.robotdriver = robotdriver;
  }

  public getRobotdriver(): RobotDriver {
    return this.robotdriver;
  }

  public setDisplayName(name: string): void {
    name = name ?? '';

    if (this.robotdriver.name !== name) {
      this.unsavedChanges = true;
      this.robotdriver.name = name;

      const tab = this.tabService.getTabGroupItem(ROBOT_DRIVERS_CARD_DATA.id, this.id);

      if (!!tab && tab.data.name !== name) {
        tab.data.name = name;
      }
    }
  }

  public setFile(file: File): void {
    if (file == null) {
      this.unsavedChanges = true;
      this.file = null;
    } else if (this.file == null || this.file.name !== file.name || this.file.size !== file.size) {
      this.unsavedChanges = true;
      this.file = file;
    }
  }

  public confirmCloseEditor(): Observable<boolean> {
    if (!this.unsavedChanges) {
      return of(true);
    } else {
      return unsavedChangesDialog(this.robotdriver.name, this.translateService, this.dialog).pipe(
        switchMap(dialogResult => {
          switch (dialogResult) {
            case ConfirmResult.SAVE:
              return this.robotDriverService.saveRobotDriver(this.robotdriver, this.originalRobotDriver.name).pipe(
                map(response => response.success),
                tap(ok => {
                  this.saveButtonDisabled = false;
                  if (ok) {
                    this.robotDriverService.reloadData();
                  }
                })
              );
            case ConfirmResult.NO_SAVE:
              return of(true);
            default:
              return of(false);
          }
        })
      );
    }
  }

  getAllRobotDriver(): void {
    this.robotDriverService.data().subscribe((data: RobotDriver[]) => (this.allRobotDriver = data));
  }

  private createNewRobotdriver(id: string, name: string): RobotDriver {
    this.getAllRobotDriver();
    const allDriverNames = this.allRobotDriver.map((d: { name: any }) => d.name);
    const driver = this.robotDriverEditorService.newDriver(allDriverNames);
    return driver;
  }

  public saveRobotdriver(driver: RobotDriver, oldName?: string): void {
    if (!driver) {
      return;
    }
    this.robotDriverService.saveRobotDriver(driver, oldName).subscribe(success => {
      if (success) {
        this.snackbar.open(this.translateService.instant(t('Robot driver saved successfully')), '', { duration: 3000 });
      } else {
        this.snackbar.open(this.translateService.instant(t('Could not save robot driver.')), 'Dismiss');
      }
    });
  }

  public static deleteRobotdriver(robotDriverService: RobotDriverService, robotdriver: RobotDriver): SelfCompletingObservable<any> {
    return robotDriverService.deleteRobotDriver(robotdriver.name);
  }
}
