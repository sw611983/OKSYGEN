/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { Logging } from '@oksygen-common-libraries/pio';
import { RobotDriver, RobotDriverService } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { TabService } from '@oksygen-common-libraries/material/components';
import { MatSnackBar } from '@angular/material/snack-bar';
import { computeIfAbsent, generateUuid, SelfCompletingObservable, shareReplayOne } from '@oksygen-common-libraries/common';
import { RobotDriverEditManager } from './robot-driver-edit.manager';
import { RobotDriverEditorService } from '../robot-driver-editor.service';

@Injectable()
export class RobotDriverEditService implements OnDestroy {
  private editManagers: Map<string, RobotDriverEditManager> = new Map();

  private subscription = new Subscription();

  private editorsActiveSubject = new BehaviorSubject<number>(0);

  constructor(
    private authService: AuthService,
    private logger: Logging,
    private robotDriverDataService: RobotDriverService,
    private robotDriverEditorService: RobotDriverEditorService,
    private dialog: MatDialog,
    private translateService: TranslateService,
    private tabService: TabService,
    private snackbar: MatSnackBar,
    private readonly zone: NgZone
  ) {}

  ngOnDestroy(): void {
    this.editManagers.forEach(value => value.destroy());
    this.editManagers.clear();

    this.subscription.unsubscribe();
    this.editorsActiveSubject.complete();
  }

  /** Get the specified manager. Creates it if it does not already exist. */
  getEditManager(id: string): RobotDriverEditManager {
    return computeIfAbsent(this.editManagers, id, i => {
      this.editorsActiveSubject.next(this.editManagers.size + 1); // add one for this new manager

      return new RobotDriverEditManager(
        id,
        this.authService,
        this.robotDriverEditorService,
        this.robotDriverDataService,
        this.dialog,
        this.translateService,
        this.tabService,
        this.snackbar,
        this.zone
      );
    });
  }

  public newRobotDriver(name: string): Promise<string> {
    return new Promise(resolve => {
      const id = generateUuid();

      const manager = this.getEditManager(id);
      manager.newRobotDriver(name);
      resolve(id);
    });
  }

  public loadRobotdriver(robotdriver: RobotDriver): void {
    const manager = this.getEditManager(robotdriver.id);

    manager.loadRobotdriver(robotdriver);
  }

  public deleteRobotdriver(robotdriver: RobotDriver): SelfCompletingObservable<any> {
    return RobotDriverEditManager.deleteRobotdriver(this.robotDriverDataService, robotdriver);
  }

  public confirmCloseEditor(id: string): Observable<boolean> {
    const manager = this.getEditManager(id);

    return manager.confirmCloseEditor();
  }

  getActiveEditorCount(): number {
    return this.editorsActiveSubject.getValue();
  }

  get activeEditors$(): Observable<number> {
    return this.editorsActiveSubject.pipe(shareReplayOne());
  }

  /** Destroy a manager (and recursively all it's data). */
  destroyManagers(id: string): void {
    const editManager = this.editManagers.get(id);

    if (editManager) {
      editManager.destroy();
    }

    this.editManagers.delete(id);

    if (this.editManagers.size !== this.editorsActiveSubject.getValue()) {
      this.editorsActiveSubject.next(this.editManagers.size);
    }
  }
}
