/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.


import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainRobotDriverEditModule } from '../../robot-driver.module';
import { RobotDriverEditService } from './robot-driver-edit.service';
import { TestBed } from '@angular/core/testing';

describe('RobotDriverEditService', () => {
  let service: RobotDriverEditService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainRobotDriverEditModule],
      providers: [RobotDriverEditService]
    });
    service = TestBed.inject(RobotDriverEditService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
