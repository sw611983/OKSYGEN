/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { AbstractControl, UntypedFormBuilder, UntypedFormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';

import { DRAFT_STATUS, generateUuid } from '@oksygen-common-libraries/common';
import { newName } from '@oksygen-sim-train-libraries/components-services/common';
import { AbstractBrowserService } from '@oksygen-sim-train-libraries/components-services/editors';
import { DriverModel, RobotDriver, RobotDriverBehaviour, RobotDriverBehaviourService} from '@oksygen-sim-train-libraries/components-services/robot-drivers';

export type RobotDriverEditorMode = 'new' | 'edit' | 'view';

@Injectable()
export class RobotDriverEditorService extends AbstractBrowserService {
  models: DriverModel[];
  private editManagers: Map<string, RobotDriver> = new Map();
  private editorsActiveSubject = new BehaviorSubject<number>(0);

  constructor(
    private robotDriverModelService: RobotDriverBehaviourService,
    private translateService: TranslateService,
    private formBuilder: UntypedFormBuilder
  ) {
    super('RobotDriverEditorService');
  }

  getModels(forceReload = false): Observable<DriverModel[]> {
    if (forceReload || !this.models) {
      return this.robotDriverModelService.data().pipe(tap(models => (this.models = models)));
    } else {
      return of(this.models);
    }
  }

  generateForm(model?: DriverModel, driver?: RobotDriver, otherDriverNames?: string[]): UntypedFormGroup {
    const driverId = driver?.id ?? '';
    const driverName = driver?.name ?? '';
    const driverModel = driver?.model ?? '';
    const nameValidators = [Validators.required];
    const spacesValidator: ValidatorFn = (control: AbstractControl) => {
      const spacesError = control.value?.trim() !== control.value;
      const spacesErrorValidation: ValidationErrors = spacesError ? { spacesError } : null;
      return spacesErrorValidation;
    };
    nameValidators.push(spacesValidator);
    if (otherDriverNames) {
      const exsitsValidator: ValidatorFn = (control: AbstractControl) => {
        const exists = !!otherDriverNames.find(odn => odn === control.value);
        const validationError: ValidationErrors = exists ? { exists } : null;
        return validationError;
      };
      nameValidators.push(exsitsValidator);
    }

    const specialCharacterValidator: ValidatorFn = (control: AbstractControl) => {
      const specialCharacterError = /[<%>*|?:/]/.test(control.value);
      const specialCharacterErrorValidation: ValidationErrors = specialCharacterError ? { specialCharacterError } : null;
      return specialCharacterErrorValidation;
    };
    nameValidators.push(specialCharacterValidator);

    const driverFormGroup: UntypedFormGroup = this.formBuilder.group({
      id: driverId,
      name: [driverName, nameValidators],
      model: [driverModel, Validators.required],
      behaviours: this.formBuilder.array([
        this.formBuilder.group({
          name: [],
          parameters: this.formBuilder.array([
            this.formBuilder.group({
              name: ['', Validators.required],
              description: [''],
              type: [''],
              default: [''],
              constraints: [''],
              value: [''],
              unit: [''],
              unitType: [''],
              defaultDisplayUnit: [''],
              context: [[]]
            })
          ])
        })
      ])
    });
    if (model) {
      this.initialiseForm(driverFormGroup, model, driver);
    }
    return driverFormGroup;
  }

  initialiseForm(driverFormGroup: UntypedFormGroup, driverModel: DriverModel, driver: RobotDriver): void {
    driverFormGroup.removeControl('behaviours');
    driverFormGroup.addControl(
      'behaviours',
      this.formBuilder.array(
        driverModel.behaviours.map((beh: RobotDriverBehaviour) =>
          this.formBuilder.group({
            name: [beh.name],
            parameters: this.formBuilder.array(
              beh.parameters.map(param =>
                this.formBuilder.group({
                  name: [param.name, Validators.required],
                  description: [param.description],
                  type: [param.type],
                  default: [param.default],
                  unit: [param.unit],
                  unitType: [param.unitType],
                  defaultDisplayUnit: [param.defaultDisplayUnit],
                  context: [param.context],
                  constraints: [param.constraints],
                  value: [
                    param.default,
                    param.type === 'range' ? [Validators.min(param.constraints[0].value as number), Validators.max(param.constraints[1].value as number)] : []
                  ]
                })
              )
            )
          })
        )
      )
    );
    if (driver) {
      driverFormGroup.patchValue(
        {
          id: driver.id,
          name: driver.name,
          model: driver.model,
          behaviours: driver.behaviours.map((behaviour: { name: any; parameters: any }) => ({
            name: behaviour.name,
            parameters: behaviour.parameters.map((parameter: any) => ({
              name: parameter.name,
              value: parameter.value
            }))
          }))
        },
        { emitEvent: false }
      );
    }
  }

  newDriver(existingNames?: string[]): RobotDriver {
    const name = this.generateNewRobotDriverName(existingNames);
    const model = this.models.length > 0 ? this.models[0].name : ''; // FIXME race condition with init
    const id = generateUuid();
    const driver: RobotDriver = {
      id,
      name,
      model,
      version: '1',
      behaviours: [],
      history: [],
      status: DRAFT_STATUS // FIXME
    };
    return driver;
  }

  formToDriver(driverFormGroup: UntypedFormGroup): RobotDriver {
    const rawDriver = driverFormGroup.getRawValue(); // TODO not sure this is correct
    return rawDriver;
  }

  /**
   * Generate a new robot driver name, using 'New Robot Driver' as the template.
   * Warning, this may generate duplicates if drivers have not been init yet and you don't supply
   * existingNames.
   *
   * @param existingNames existing names list to check against
   */
  private generateNewRobotDriverName(existingNames?: string[]): string {
    if (!existingNames) {
      // FIXME sync get robot drivers will fail if data is not init yet!!
      const sub = this.robotDriverModelService.data().subscribe(robots => {
        existingNames = robots.map(r => r.name);
      });
      sub.unsubscribe();
    }
    return newName('New Robot Driver', this.translateService, existingNames);
  }
}
