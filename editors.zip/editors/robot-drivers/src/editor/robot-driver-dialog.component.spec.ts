/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainRobotDriverEditModule } from '../robot-driver.module';
import { RobotDriverDialogComponent } from './robot-driver-dialog.component';

describe('RobotDriverDialogComponent', () => {
  let component: RobotDriverDialogComponent;
  let fixture: ComponentFixture<RobotDriverDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainRobotDriverEditModule],
        declarations: [RobotDriverDialogComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(RobotDriverDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
