/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, input, OnDestroy, OnInit, output } from '@angular/core';
import { UntypedFormArray, UntypedFormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';

import { DRAFT_STATUS, getCreated, getLastModified, HISTORY_TYPE_CREATED, PUBLISHED_STATUS, UNKNOWN } from '@oksygen-common-libraries/common';
import { CustomDatePipe } from '@oksygen-common-libraries/material/components';
import { DriverModel, RobotDriver } from '@oksygen-sim-train-libraries/components-services/robot-drivers';

import { RobotDriverEditorMode, RobotDriverEditorService } from '../../services/robot-driver-editor.service';

@Component({
  selector: 'oksygen-robot-driver-behaviour',
  templateUrl: './robot-driver-behaviour.component.html',
  styleUrls: ['./robot-driver-behaviour.component.scss']
})
export class RobotDriverBehaviourComponent implements OnInit, OnDestroy {
  readonly PUBLISHED = PUBLISHED_STATUS; // for use in HTML
  readonly DRAFT = DRAFT_STATUS; // for use in HTML

  driver = input<RobotDriver>();
  driverModels = input<DriverModel[]>();
  mode = input<RobotDriverEditorMode>();
  otherDriverNames = input<string[]>();
  displayHeader = input<boolean>(false);
  readonly update = output<UntypedFormGroup>();
  createdName: string = UNKNOWN;
  createdAt: string = UNKNOWN;
  lastModifiedName: string = UNKNOWN;
  lastModifiedAt: string = UNKNOWN;

  driverFormGroup: UntypedFormGroup;
  modelSelectionEnabled = false; // whether to show the model selection dropdown.
  subscription = new Subscription();
  formSubscription: Subscription;
  formModelChangesSubscription: Subscription;

  currentDriver: RobotDriver;
  // FIXME should not depend on editor specific service - these functions should be moved.
  constructor(private robotDriverEditorService: RobotDriverEditorService, private datePipe: CustomDatePipe) {
    effect(() => {
      const currentDriver = this.driver(); // Get the current driver value
      const currentMode = this.mode(); // Get the current mode value

      // If driver is updated, perform necessary actions
      if (currentDriver) {
        this.findAndGenerate(currentDriver.model, this.driverModels(), currentDriver);
        this.setVersionDetails(currentDriver);
        this.setMode(currentMode); // You can call setMode here if needed for each change
      }

      // If mode is updated, perform necessary actions
      if (currentMode) {
        this.setMode(currentMode);
      }
    });
  }

  get behaviours(): UntypedFormArray {
    return this.driverFormGroup.get('behaviours') as UntypedFormArray;
  }

  parameters(behIndex: number): UntypedFormArray {
    return this.behaviours.at(behIndex).get('parameters') as UntypedFormArray;
  }

  ngOnInit(): void {
    const driverModel = this.driverModels().find((m: DriverModel) => m.name === this.driver()?.model);
    // FIXME this other names check will fail if we allow editing on the right pane
    this.driverFormGroup = this.robotDriverEditorService.generateForm(driverModel, this.driver(), this.otherDriverNames());
    this.setMode(this.mode());
    if (this.driver()) {
      this.currentDriver = this.driver();
      this.setVersionDetails(this.driver());
    }
    if (this.mode() === 'new') {
      // initial value - slight hack to only enable save immediately on new
      this.update.emit(this.driverFormGroup);
    }
    this.formModelChangesSubscription = this.driverFormGroup.get('model').valueChanges.subscribe(value => {
      const srcModel = this.driverModels().find((m: DriverModel) => m.name === value);
      if (srcModel) {
        this.robotDriverEditorService.initialiseForm(this.driverFormGroup, srcModel, this.driver());
      }
    });

    this.formSubscription = this.driverFormGroup.valueChanges.subscribe(value => {
      this.update.emit(this.driverFormGroup);
    });
  }

  findAndGenerate(modelName: string, modelsVal: any[], driverVal: RobotDriver): void {
    const model = modelsVal.find((m: any) => m.name === modelName);
    if (model) {
      this.robotDriverEditorService.initialiseForm(this.driverFormGroup, model, driverVal);
    }
  }

  setMode(mode: RobotDriverEditorMode): void {
    if (!this.driverFormGroup) {
      return;
    }
    if (mode === 'view') {
      this.driverFormGroup.disable({ emitEvent: false });
    } else {
      this.driverFormGroup.enable({ emitEvent: false });
    }
  }

  /**
   * Handles date as string and returns it in a proper format
   * ! Does not handle Unknown and simply returns it for example!
   *
   * @param date The date to convert
   * @returns The date properly formatted
   */
  convertDate(date: string): string {
    if (date === UNKNOWN) return UNKNOWN;
    return this.datePipe.transform(date);
  }

  setVersionDetails(driver: RobotDriver): void {
    const created = getCreated(driver?.history);
    const lastModifed = getLastModified(driver?.history);
    // TODO: Merge this with robot-driver.browser toTableData function
    this.createdName = created ? `${created.authorFirstName} ${created.authorLastName}` : UNKNOWN;
    this.lastModifiedName = lastModifed ? `${lastModifed.authorFirstName} ${lastModifed.authorLastName}` : UNKNOWN;
    this.createdAt = created ? this.convertDate(created.timestamp) : UNKNOWN;
    this.lastModifiedAt = lastModifed ? this.convertDate(lastModifed.timestamp) : UNKNOWN;
  }

  updateCreatedModified(driver: RobotDriver): void {
    // FIXME this is copied from robot driver browser!
    const created = driver.history.find(h => h.type === HISTORY_TYPE_CREATED);
    this.createdAt = created ? this.convertDate(created.timestamp) : UNKNOWN;
    this.lastModifiedAt = created ? this.convertDate(created.timestamp) : UNKNOWN;
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.formSubscription.unsubscribe();
    this.formModelChangesSubscription.unsubscribe();
  }
}
