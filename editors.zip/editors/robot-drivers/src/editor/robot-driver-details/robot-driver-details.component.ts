/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, input } from '@angular/core';
import { DriverModel, RobotDriver } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { RobotDriverEditorMode } from '../../services/robot-driver-editor.service';

@Component({
  selector: 'oksygen-robot-driver-details',
  templateUrl: './robot-driver-details.component.html',
  styleUrls: ['./robot-driver-details.component.scss']
})
export class RobotDriverDetailsComponent {

  driver = input<RobotDriver>();
  driverModels = input<DriverModel[]>();
  mode = input<RobotDriverEditorMode>();

  constructor() { }

}
