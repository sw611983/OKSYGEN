/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainRobotDriverEditModule } from '../../robot-driver.module';
import { RobotDriverBehaviourComponent } from '../robot-driver-behaviour/robot-driver-behaviour.component';
import { RobotDriverDetailsComponent } from './robot-driver-details.component';

describe('RobotDriverDetailsComponent', () => {
  let component: RobotDriverDetailsComponent;
  let fixture: ComponentFixture<RobotDriverDetailsComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainRobotDriverEditModule],
        declarations: [RobotDriverDetailsComponent, RobotDriverBehaviourComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(RobotDriverDetailsComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('driverModels', []);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
