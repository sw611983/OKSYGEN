/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';
import { RobotDriverEditorMode, RobotDriverEditorService } from '../services/robot-driver-editor.service';
import { UntypedFormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { ConfirmResult, unsavedChangesDialog } from '@oksygen-sim-train-libraries/components-services/common';
import { DriverModel, RobotDriver } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { CustomDatePipe } from '@oksygen-common-libraries/material/components';

export interface RobotDriverDialogData {
  mode: RobotDriverEditorMode;
  driver: RobotDriver;
  otherDriverNames?: string[];
}

@Component({
  selector: 'oksygen-robot-driver-dialog',
  templateUrl: './robot-driver-dialog.component.html',
  styleUrls: ['./robot-driver-dialog.component.scss'],
  providers: [ RobotDriverEditorService, CustomDatePipe ]
})
export class RobotDriverDialogComponent implements OnInit, OnDestroy {

  driverFormGroup: UntypedFormGroup;
  driverModels: DriverModel[];

  private modelSubscription: Subscription;

  constructor(
    public dialogRef: MatDialogRef<RobotDriverDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: RobotDriverDialogData,
    private dialog: MatDialog,
    private robotDriverEditorService: RobotDriverEditorService,
    private translateService: TranslateService
  ) { }

  ngOnInit(): void {
    this.modelSubscription = this.robotDriverEditorService.getModels().subscribe(models => {
      this.driverModels = models;
    });
  }

  ngOnDestroy(): void {
    this.modelSubscription?.unsubscribe();
  }

  cancelEditing(): void {
    if(this.driverFormGroup?.dirty) {
      const name = this.driverFormGroup.get('name');
      unsavedChangesDialog(name.value, this.translateService, this.dialog).subscribe(result => {
        if (result === ConfirmResult.SAVE) {
          this.onSubmit();
        } else if (result === ConfirmResult.NO_SAVE) {
          this.dialogRef.close();
        } else if (result === ConfirmResult.CANCEL) { /* do nothing */ }
      });
    }
    else {
      this.dialogRef.close();
    }
  }

  onDriverEdit(driver: UntypedFormGroup): void {
    this.driverFormGroup = driver;
  }

  /**
   * Close the dialog and submit the updated driver.
   * If the driver is invalid, do not close nor submit.
   */
  onSubmit(): void {
    if (this.driverFormGroup.valid) {
      const formDriver = this.robotDriverEditorService.formToDriver(this.driverFormGroup);
      const driver: RobotDriver = {
        ...this.data.driver,
        ...formDriver
      };
      this.dialogRef.close(driver);
    }
  }

}
