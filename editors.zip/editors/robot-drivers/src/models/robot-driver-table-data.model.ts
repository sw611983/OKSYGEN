/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { EditorBrowserTableData } from '@oksygen-sim-train-libraries/components-services/common';
import { RobotDriverBehaviour } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { BasicTabNavItem, TabGroupChild } from '@oksygen-common-libraries/material/components';

import { EditorData } from '@oksygen-sim-train-libraries/components-services/editors';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';


export interface RobotDriverTableData extends EditorBrowserTableData {
  id:string;
  model: string;
  behaviours: RobotDriverBehaviour[];
}

export const ROBOT_DRIVERS_CARD_DATA = new EditorData(
  t('Robot Drivers'),
  '/editors/robot-drivers',
  OksygenIcon.ROBOT,
  'robot-drivers'
);

export type RobotDriverTabType = TabGroupChild<BasicTabNavItem>;
