/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { computed, Directive, OnInit, signal } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

import { SideNavService, TabService } from '@oksygen-common-libraries/material/components';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { User } from '@oksygen-sim-core-libraries/components-services/users';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { BrowserFilterText, EditorBrowserHeaderConfig, EditorBrowserTableData } from '@oksygen-sim-train-libraries/components-services/common';

import { AbstractBrowserService } from '../services/abstract-browser.service';
import { LockDatabaseService } from '../services/lock-data.service';
import { BaseBrowserTabPage } from './base-browser-tab-page';
import { BaseData, EditorData } from './editor-data.model';
import { disabledLockConfig, EditorLock, LockConfig, LockDisplay } from './lock.model';
import { MatDialog } from '@angular/material/dialog';

// there may be a cleaner way to do the FilterFields & FilterIcons generics...
/**
 * Base class handling a lot of the common "browser" functionality.
 * ```Data``` is the raw data type (ie ```Scenario```), ```TableData``` is data exert to display (ie ```ScenarioSummaryData```).
 * ```FilterFields``` is the text values of the various filter search bars on your browser page.
 * ```FilterIcons``` are a string enum of the mat icons of each of your filter fields.
 */
@Directive()
export abstract class BaseLockableBrowserTabPage<
    Data extends BaseData,
    TableData extends EditorBrowserTableData,
    FilterFields extends BrowserFilterText,
    FilterIcons
  >
  extends BaseBrowserTabPage<Data, TableData, FilterFields, FilterIcons>
  implements OnInit
{
  selectedLock: EditorLock;
  readonly locks = signal<Array<EditorLock>>([]);
  lockConfig: LockConfig;
  lockDisplay: LockDisplay;

  override readonly tableData = computed<Array<TableData>>(() => (this.emptyTableData() ? [] : this.toTableData(this.data(), this.locks())));

  constructor(
    controlsConfig: EditorBrowserHeaderConfig,
    editorService: AbstractBrowserService,
    sideNavService: SideNavService,
    router: Router,
    data: EditorData,
    tabService: TabService,
    logger: Logging,
    translateService: TranslateService,
    protected lockService: LockDatabaseService,
    protected authService: AuthService,
    dialog: MatDialog
  ) {
    super(controlsConfig, editorService, sideNavService, router, data, tabService, logger, translateService, dialog);
  }
  abstract onUnlock(): void;
  abstract editorName(): string;

  protected abstract override toTableData(data: Data[], locks?: EditorLock[]): TableData[];

  unlockClick(): void {
    this.detailEditDisabled.set(false);
    this.onUnlock();
  }

  override selectionChanged(): void {
    const selectedValues = this.fileManagerTable?.getSelectedValues();
    const selectedCount = selectedValues ? selectedValues.length : 0;

    this.selectedTableData.set(undefined);

    if (selectedCount > 0) {
      const singleSelected = selectedValues.length === 1;

      // if detailEditDisabled is true, then we can't edit anything more
      this.editDisabled.set(!singleSelected || this.detailEditDisabled());
      this.duplicateDisabled.set(!singleSelected);
      this.deleteDisabled.set(selectedValues.find(selectedScenarios => selectedScenarios.locked === true) ? true : false);
      this.publishDisabled.set(selectedValues.find(selectedScenarios => selectedScenarios.locked === true) ? true : false);
      this.printDisabled.set(true); // TODO false;

      if (singleSelected) {
        this.selectedTableData.set(selectedValues[0]);
        this.selectedLock = this.locks().find(lock => lock.id === this.selectedItem()?.id);
        this.lockDisplay = this.getLockDisplay(this.authService.getLoggedInUser(), this.lockService.getMachineId());
        const lockHolder = this.lockDisplay?.lockHolder;

        const loggedInUser = this.authService.getLoggedInUser().firstName + ' ' + this.authService.getLoggedInUser().lastName;
        const loggedInUserLocked = this.locks().find(lock => lock.user === loggedInUser);
        if (this.selectedLock) {
          if (lockHolder === 'me' || lockHolder === 'other') {
            this.editDisabled.set(true);
            this.deleteDisabled.set(true);
            this.publishDisabled.set(true);
            this.detailEditDisabled.set(true);
            this.detailDeleteDisabled.set(true);
          } else if (loggedInUserLocked) {
            this.editDisabled.set(true);
            this.detailEditDisabled.set(true);
          } else if (!loggedInUserLocked && lockHolder === undefined) {
            this.editDisabled.set(false);
            this.detailEditDisabled.set(false);
          }
        } else {
          this.detailEditDisabled.set(false);
          this.editDisabled.set(false);
          this.detailDeleteDisabled.set(this.deleteDisabled());
        }
      } else {
        this.selectedLock = null;
      }
    } else {
      this.editDisabled.set(true);
      this.duplicateDisabled.set(true);
      this.deleteDisabled.set(true);
      this.publishDisabled.set(true);
      this.printDisabled.set(true);
      this.selectedLock = null;
    }

    this.selectedCount.set(selectedCount);
  }

  /**
   * Loads lock data if locking is enabled.
   * @param registry
   */
  protected loadLocks(registry: Registry): void {
    const lockConfig = registry?.getObject(['editor', this.editorName()], { locking: disabledLockConfig })?.locking ?? disabledLockConfig;
    this.lockConfig = lockConfig;
    if (this.lockService.isEnabled(this.editorName())) {
      this.lockService.reloadData();
    }
  }

  protected lockEditorItem(id: string): void {
    // const expiryDate = this.getLockExpiryDate();
    // const lock: EditorLock = {
    //   id,
    //   editor: this.editorName(),
    //   expiry: expiryDate?.toISOString() ?? '0',
    //   user: this.authService.getLoggedInUser()?.id,
    //   machine: this.lockService.getMachineId()
    // };
    if (this.lockService.isEnabled(this.editorName())) {
      const lock = this.lockService.createLockData(id, this.editorName());
      this.lockService.addDatabaseLock(lock).subscribe(() => this.lockService.reloadData());
    }
  }

  // /**
  //  * Returns when a lock created NOW will expire.
  //  * For example, if lock config duration is set to 60 then this will return a date of 1 minute in the future.
  //  * Returns null if there is no set duration (infinite lock).
  //  */
  // protected getLockExpiryDate(): Date {
  //   const duration = this.lockConfig.duration;
  //   if (!duration) { return null; }
  //   const durationInMs = duration * 1000;
  //   const expiryDate = new Date(Date.now() + durationInMs);
  //   return expiryDate;
  // }

  protected getLockDisplay(loggedInUser: User, machineId: string): LockDisplay {
    if (!this.selectedLock) {
      return null;
    }
    const lock: LockDisplay = {
      lockHolder: this.editorLockHolder(loggedInUser, machineId),
      lockHolderName: this.selectedLock.user,
      expiry: this.selectedLock.expiry,
      forceUnlockEnabled: this.lockConfig.forceBreak
    };
    return lock;
  }

  /**
   * Returns whether the editor is locked or not.
   * Me = this editor holds the lock, other = someone else holds the lock, unlocked = unlocked.
   */
  private editorLockHolder(loggedInUser: User, machineId: string): 'me' | 'other' | 'unlocked' {
    if (!this.selectedLock) {
      return 'unlocked';
    }
    const lockType = this.lockConfig.lockHolderType;
    if (lockType === 'user') {
      // const user = this.authService.getLoggedInUser();
      if (loggedInUser.id !== this.selectedLock.user) {
        return 'other';
      }
      return 'me';
    } else if (lockType === 'machine') {
      if (machineId !== this.selectedLock.machine) {
        return 'other';
      }
      return 'me';
    }
    return 'unlocked';
  }
}
