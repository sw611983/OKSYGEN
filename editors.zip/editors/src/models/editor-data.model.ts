/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { AppLauncherInfo } from '@oksygen-common-libraries/material/components';

/** This is the base data interface editor data should extend. We just enforce that all editor data has an id. */
export interface BaseData {
  id: string|number;
}

/** This is for data about an editor - ie scenario editor users this icon and is on this route. */
export class EditorData {
  constructor(
    public name: string,
    public routerLink: string,
    public icon: string,
    public id: string,
    public subtitle?: string
  ) {}

  toAppLauncherInfo(): AppLauncherInfo {
    return {
      title: this.name,
      subtitle: this.subtitle,
      icon:  this.icon,
      page:  this.routerLink
    };
  }
}

export interface EditorDataTab {
  name: string;
  routerLink: string;
  icon: string;
  id: string;
  closeFunction: () => void;
}
