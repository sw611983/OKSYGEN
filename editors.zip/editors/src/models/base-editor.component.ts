/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Directive, Input, OnDestroy, Signal } from '@angular/core';
import { ActivatedRoute, Data } from '@angular/router';
import { isEmpty } from 'lodash';
import { BehaviorSubject, combineLatest, Observable, Subscription } from 'rxjs';
import { switchMap, tap } from 'rxjs/operators';

import { filterTruthy, SUPER_WAS_CALLED, SuperCalled } from '@oksygen-common-libraries/common';
import { DynamicParent } from '@oksygen-common-libraries/material/components';
import { Context, ContextPublisher } from '@oksygen-sim-train-libraries/components-services/common';

import { BaseDataEditorManager } from '../services/base-data-editor.manager';
import { EditorManagementService } from '../services/editor-management.service';
import { BaseData } from './editor-data.model';

/**
 * An abstract editor component for our editors to extend.
 * This contains most of the common logic we expect editors to handle
 * as well as some hints as to the expected typings for the various required boilerplate.
 */
// directive tag required for abstract components to use @Inputs
@Directive()
// eslint-disable-next-line @angular-eslint/directive-class-suffix
export abstract class BaseEditorComponent<
  D extends BaseData,
  C extends Context,
  Manager extends BaseDataEditorManager<D, C>,
  EditorService extends EditorManagementService<any, D, C, Manager>,
> extends DynamicParent implements OnDestroy {

  @Input() config: Data | Signal<Data>;

  manager$ = new BehaviorSubject<Manager>(null);

  protected subscription = new Subscription();

  constructor(
    protected activatedRoute: ActivatedRoute,
    protected contextSupplier: ContextPublisher<any, C>,
    protected editorService: EditorService
  ) {
    super();
    this.editorService = editorService;
  }

  /**
   * This is called whenever the context or route changes.
   * Will use the route data if it exists, otherwise the Input() config.
   * If neither are provided a default will be used.
   * You should validate using a type guard the config passed in here is valid!
   *
   * @param context partialcontext used, contains the overall "state" of the editor.
   * @param config (optional) data from the angular router, provided by the routing module.
   */
  abstract processConfig(context: C, config: Data): void;
  /**
   * Return an optional default config if route & input params are not supplied.
   * If you require them to be supplied, you can return null.
   */
  abstract getDefaultConfig(): Data;

  /**
   * Returns the "main" data type of this editor. This is the thing you're storing in your store.
   * For scenario editor, this is a scenario. for user fault editor, the user fault.
   *
   * @param context the overall context of this editor
   */
  abstract getEditorDataFromContext(context: C): Observable<D>;

  /**
   * Called when the store has an update to your main data type.
   * By default this does nothing. Useful for things like updating your tab's name.
   *
   * @param data the main data you're editing (scenario in scenario editor etc)
   */
  onEditorDataUpdate(data: D): void {}

  initialiseDataManagers(): void {
    const contextFromRoute$ = this.activatedRoute.paramMap.pipe(
      switchMap(params => {
        const id = params.get('id');
        const manager = this.editorService.getEditManager(id);
        this.contextSupplier.setCurrentContext({ id }, 'Editor');
        this.manager$.next(manager);
        return this.contextSupplier.currentContext$();
      })
    );

    const routeSub = combineLatest(
      [contextFromRoute$, this.activatedRoute?.data]
    ).subscribe(async ([context, routeData]) => {
      this.manager$.getValue().setEditingContext(context);
      const dataFromRoute = isEmpty(routeData) ? null : routeData; // routeData is empty if none supplied, simplify with null
      const config = dataFromRoute || this.config || this.getDefaultConfig();
      this.processConfig(context, config);
    });
    this.subscription.add(routeSub);
    const sub = this.contextSupplier.currentContext$().pipe(
      filterTruthy(),
      switchMap(c => this.getEditorDataFromContext(c)),
      filterTruthy(),
      tap(data => this.onEditorDataUpdate(data))
    ).subscribe();
    this.subscription.add(sub);
  }

  ngOnDestroy(): SuperCalled {
    this.manager$.complete();
    this.subscription.unsubscribe();
    return SUPER_WAS_CALLED;
  }
}
