/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Router } from '@angular/router';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

import { SideNavService, SideNavTabItem, TabService } from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';

import { EditorTabNavItemComponent } from '../editor-tab-nav-item/editor-tab-nav-item.component';
import { AbstractBrowserService } from '../services/abstract-browser.service';
import { EditorData } from './editor-data.model';

/**
 * The editor browser 'screens' extend this, and this handles common functionality, including adding the tab to the side-nav
 * component. You probably want to extend ```BaseBrowserTabPage``` instead which extends this further.
 */
export abstract class AbstractEditorTabPage {
  private sideNavTabItem: SideNavTabItem;

  constructor(
    protected readonly editorService: AbstractBrowserService,
    protected readonly sideNavService: SideNavService,
    protected readonly router: Router,
    data: EditorData,
    protected readonly tabService: TabService,
    protected readonly logger: Logging,
    protected readonly translateService: TranslateService
  ) {
    this.sideNavTabItem = new SideNavTabItem(EditorTabNavItemComponent, {
      ...data,
      closeFunction: (): void => this.tabClosing()
    });
  }

  /**
   * If this is the first time opening the page, initialise the editorService and add the tab.
   * Calls the editorService pageOpening method.
   */
  protected pageOpening(): void {
    if (!this.editorService.pageActive) {
      this.editorService.initialiseEditing();
      setTimeout(() => {
        // this.sideNavService.addSideNavTabItems(this.sideNavTabItem);
        const data: EditorData = this.sideNavTabItem.data;
        if (!data) {
          this.logger.warn(`[BaseEditorTabPage] failed to create editor tab - no data supplied!`);
          return;
        }
      }, 0);
    }

    this.editorService.pageOpening();
  }

  /**
   * Calls the editorService pageClosing method
   */
  protected pageClosing(): void {
    this.editorService.pageClosing();
  }

  /**
   * Removes the tab, resets the service and redirects to the editors page,
   * if the current page is visible.
   */
  protected tabClosing(): void {
    if (this.editorService.pageVisible) {
      this.router.navigate(['/editors']);
    }
    this.editorService.resetEditing();
    this.sideNavService.removeSideNavTabItem(this.sideNavTabItem);
  }

  protected getCurrentLocale(): string {
    return this.translateService.currentLocaleString;
  }
}
