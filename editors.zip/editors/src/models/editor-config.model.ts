/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { DynamicComponent } from '@oksygen-common-libraries/material/components';
import { ComponentConfig } from '@oksygen-sim-train-libraries/components-services/common';
import {
  LineViewMapChildData,
  MainMapChildData,
  MainMapOutputData,
  MainMapViewDynamicComponent,
  MapChildData,
  MiniMapDynamicComponent
} from '@oksygen-sim-train-libraries/components-services/maps';
import { distanceFromTrackConfigSchema } from '@oksygen-sim-train-libraries/components-services/objects/data';

export interface EditorWithMapsConfig extends EditorWithMiniMapConfig, EditorWithLineMapConfig, EditorWithPlanMapConfig {}

export interface EditorWithMiniMapConfig {
  miniView: ComponentConfig<MiniMapDynamicComponent, MapChildData>;
}

export interface EditorWithLineMapConfig {
  lineView: ComponentConfig<DynamicComponent<LineViewMapChildData, null>, LineViewMapChildData>;
}

export interface EditorWithPlanMapConfig {
  planView: ComponentConfig<MainMapViewDynamicComponent<MainMapChildData, MainMapOutputData>, MainMapChildData>;
}

export interface EditorWithTopToolbarConfig<C> {
  topToolbar: EditorTopToolbarConfig<C>;
}

export interface EditorTopToolbarConfig<C> {
  defaultItems: C;
}

export interface EditorTopToolbarDefaultItemsConfig {
  save: boolean;
  undo: boolean;
  redo: boolean;
  copy: boolean;
}

const editorLockingConfigSchema: Record<string, any> = {
  type: 'object',
  properties: {
    locking: {
      type: 'object',
      properties: {
        enabled: { type: 'boolean' },
        forceBreak: { type: 'boolean' },
        duration: { type: 'number' },
        lockHolderType: { type: 'string', enum: ['machine', 'user'] }
      }
    }
  }
};

const scenarioEditorConfigSchema: Record<string, any> = {
  type: 'object',
  properties: {
    locking: editorLockingConfigSchema,
    additionalFields: { type: 'array', items: { type: 'string'}},
    dynamicPreview: {
      type: 'object',
      properties: {
        defaultSessionType: { type: 'string' }
      }
    },
    trains: {
      type: 'object',
      properties: {
        maxSimulated: { type: 'number' },
        maxAuto: { type: 'number' },
        maxTotal: { type: 'number' },
        enforceDriver: { type: 'boolean' }
      }
    },
    objects: {
      type: 'object',
      properties: {
        showProperties: { type: 'boolean' },
        placementRules: {
          type: 'object',
          properties: {
            allowedFeatureTypes: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  featureType: { type: 'string' },
                  group: { type: 'string' },
                  distanceFromTrack: distanceFromTrackConfigSchema,
                  initialOrientation: { type: 'string', enum: ['A_B', 'B_A', 'NONE'] }
                }
              }
            },
            disallowedFeatureTypes: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  featureType: { type: 'string' },
                  group: { type: 'string' }
                }
              }
             },
            otherFeatureTypes: { type: 'string', enum: ['show', 'hide'] },
            defaultPlacementRules: {
              type: 'object',
              properties: {
                initialOrientation: { type: 'string', enum: ['A_B', 'B_A', 'NONE'] },
                distanceFromTrack: distanceFromTrackConfigSchema
              }
            }
          }
        }
      }
    }
  }
};

const userFaultEditorConfigSchema: Record<string, any> = {
  type: 'object',
  properties: {
    locking: editorLockingConfigSchema,
    monitorPropertiesEnabled: { type: 'boolean'}
  }
};

const ruleEditorConfigSchema: Record<string, any> = {
  type: 'object',
  properties: {
    locking: editorLockingConfigSchema
  }
};

const worldEditorConfigSchema: Record<string, any> = {
  type: 'object',
  properties: {
    objects: {
      type: 'object',
      properties: {
        properties: { type: 'object' }
      }
    },
    zone: {
      type: 'object',
      properties: {
        properties: { type: 'object' }
      }
    }
  }
};

export const editorConfigSchema: Record<string, any> = {
  $id: 'oksygen-editor-config',
  type: 'object',
  properties: {
    editor: {
      type: 'object',
      properties: {
        scenario: scenarioEditorConfigSchema,
        userFault: userFaultEditorConfigSchema,
        rule: ruleEditorConfigSchema,
        world2dEditor: worldEditorConfigSchema
      }
    }
  }
};
