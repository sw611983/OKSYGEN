/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export interface ToolboxState {
  opened: boolean;
  index: number;
}

export interface EditorState {
  startToolbox: ToolboxState;
  endToolbox: ToolboxState;
}
