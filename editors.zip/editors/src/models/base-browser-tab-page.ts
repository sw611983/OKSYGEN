/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { computed, Directive, HostListener, OnInit, signal, viewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

import { COPY, SUPER_WAS_CALLED, SuperCalled, UNKNOWN } from '@oksygen-common-libraries/common';
import {
  FhmConfiguration,
  FileManagerTableComponent,
  FileManagerTableData,
  SideNavService,
  Sorter,
  TabService
} from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';
import {
  BrowserFilterText,
  BrowserState,
  EditorBrowserFilterIOConfig,
  EditorBrowserHeaderConfig,
  EditorBrowserTableData
} from '@oksygen-sim-train-libraries/components-services/common';

import { DetailsToolbarComponent } from '../details-toolbar/details-toolbar.component';
import { AbstractBrowserService } from '../services/abstract-browser.service';
import { AbstractEditorTabPage } from './base-editor-tab-page';
import { EditorData } from './editor-data.model';
import { isNil } from 'lodash';

// there may be a cleaner way to do the FilterFields & FilterIcons generics...
/**
 * Base class handling a lot of the common "browser" functionality.
 * ```Data``` is the raw data type (ie ```Scenario```), ```TableData``` is data exert to display (ie ```ScenarioSummaryData```).
 * ```FilterFields``` is the text values of the various filter search bars on your browser page.
 * ```FilterIcons``` are a string enum of the mat icons of each of your filter fields.
 */
@Directive()
export abstract class BaseBrowserTabPage<Data, TableData extends EditorBrowserTableData, FilterFields extends BrowserFilterText, FilterIcons>
  extends AbstractEditorTabPage
  implements OnInit
{
  readonly COPY: string = COPY;
  readonly UNKNOWN = UNKNOWN;

  /**
   * Selected table data will be null if none OR multiple are selected.
   * If you need multiple selections use ```fileManagerTable.getSelectedValues()``` or ```selectedCount```.
   * */
  readonly selectedTableData = signal<TableData | undefined>(undefined);

  readonly selectedItem = computed<Data | undefined>(() => {
    const selectedTableData = this.selectedTableData();

    if (!isNil(selectedTableData)) {
      return this.getItemFromTableItem(selectedTableData);
    }

    return undefined;
  });
  readonly selectedCount = signal<number | undefined>(undefined);
  sorter = new Sorter<TableData>();
  readonly filters = signal<Array<EditorBrowserFilterIOConfig<Data>>>([]);
  state: BrowserState<FilterFields, FilterIcons>;
  readonly data = signal<Array<Data>>([]);
  readonly emptyTableData = signal<boolean>(false);
  readonly tableData = computed<Array<TableData>>(() => (this.emptyTableData() ? [] : this.toTableData(this.data())));
  columns: Array<FileManagerTableData>;
  displayedColumns: Array<string> = [];

  set headerControlsConfig(value: EditorBrowserHeaderConfig) {
    if (!value) {
      this.fmhConfiguration = null;
      return;
    }
    this.editDisabled.set(!!value.edit?.enabled);
    this.openDisabled.set(!!value.open?.enabled);
    this.duplicateDisabled.set(!!value.duplicate?.enabled);
    this.deleteDisabled.set(!!value.delete?.enabled);
    this.publishDisabled.set(!!value.active?.enabled);
    this.printDisabled.set(!!value.print?.enabled);
    this.fmhConfiguration = new FhmConfiguration({
      importConfig: { visible: !!value.import?.visible, text: value.import?.text ?? t('Import') },
      exportConfig: { visible: !!value.export?.visible, text: value.export?.text ?? t('Export') },
      printVisible: !!value.print?.visible,
      editVisible: !!value.edit?.visible,
      openVisible: !!value.open?.visible,
      createNewConfig: { visible: !!value.create?.visible, text: value.create?.text ?? t('Create New') },
      deleteVisible: !!value.delete?.visible,
      duplicateVisible: !!value.duplicate?.visible,
      filterVisible: !!value.filter?.visible,
      searchBarVisible: !!value.search?.visible,
      refreshVisible: !!value.refresh?.visible,
      activeVisible: !!value.active?.visible
    });
  }

  fmhConfiguration: FhmConfiguration;

  readonly editDisabled = signal<boolean>(true);
  readonly openDisabled = signal<boolean>(true);
  readonly duplicateDisabled = signal<boolean>(true);
  readonly deleteDisabled = signal<boolean>(true);
  readonly publishDisabled = signal<boolean>(true);
  readonly unpublishDisabled = signal<boolean>(true);
  readonly printDisabled = signal<boolean>(true);
  readonly refreshDisabled = signal<boolean>(true);
  readonly exportDisabled = signal<boolean>(true);

  readonly detailEditDisabled = signal<boolean>(false);
  readonly detailDuplicateDisabled = signal<boolean>(false);
  readonly detailDeleteDisabled = signal<boolean>(false);
  readonly detailPrintDisabled = signal<boolean>(true);
  detailEditTooltip: string = DetailsToolbarComponent.DEFAULT_EDIT_TOOLTIP;
  propertyDialog: MatDialog;

  /**
   * When implementing this, you'll want to decorate it with ```@ViewChild(FileManagerTableComponent)```.
   * Your browser html should also have ```<oksygen-file-manager-table>``` in it.
   */
  abstract fileManagerTable: FileManagerTableComponent<TableData>;
  tableFilter = this.applyFilters.bind(this);

  readonly localSort = viewChild.required(MatSort);

  constructor(
    controlsConfig: EditorBrowserHeaderConfig,
    editorService: AbstractBrowserService,
    sideNavService: SideNavService,
    router: Router,
    data: EditorData,
    tabService: TabService,
    logger: Logging,
    translateService: TranslateService,
    parameterDialog: MatDialog
  ) {
    super(editorService, sideNavService, router, data, tabService, logger, translateService);
    this.headerControlsConfig = controlsConfig;
    this.propertyDialog = parameterDialog;
  }

  /**
   * Accepts a sort column and two elements to sort and returns a number indicating how to sort them.
   * Results should always be sorted in ascending order.
   * When sorting lists, the col parameter can be ignored.
   *
   * @param field the field name we're sorting on
   * @param a the first value to compare
   * @param b the second value to compare.
   */
  abstract sorterFunction(field: string, a: TableData, b: TableData): number; // could provide a default impl
  /** importing not currently supported. */
  abstract onImport(): void;
  /** exporting not currently supported. */
  abstract onExport(): void;
  abstract onEdit(item: Data): void;
  abstract onDelete(item: Data | Data[]): void;
  abstract onPublish(item: Data | Data[], isActive: boolean): void;
  abstract onPrint(item: Data | Data[]): void;
  abstract onDuplicate(item: Data): void;
  abstract onCreate(): void;
  abstract onRefresh(): void;

  protected abstract initialiseState(): BrowserState<FilterFields, FilterIcons>;
  /**
   * Returns the config for your search filters.
   * This is called in the constructor.
   */
  protected abstract initialiseFilterConfig(): EditorBrowserFilterIOConfig<Data>[];
  protected abstract initialiseColumns(): FileManagerTableData[];
  protected abstract initialiseDisplayedColumns(): string[];
  protected abstract applyFilters(data: TableData): boolean;
  protected abstract toTableData(data: Data[]): TableData[];
  protected abstract getItemFromTableItem(data: TableData): Data;

  /**
   * The state needs to be set but it cannot happen in the constructor due to the injection not being done yet.
   */
  ngOnInit(): SuperCalled {
    this.sorter.sortFunction = this.sorterFunction.bind(this);
    this.state = this.initialiseState();
    this.filters.set(this.initialiseFilterConfig());
    this.columns = this.initialiseColumns();
    this.displayedColumns = this.initialiseDisplayedColumns();
    return SUPER_WAS_CALLED;
  }

  /** import isn't supported at this time. */
  importClick(): void {
    this.onImport();
  }
  /** export isn't supported at this time. */
  exportClick(): void {
    this.onExport();
  }
  /** triggered when the user clicks the create new button in the file manager header. */
  createNewClick(): void {
    this.onCreate();
  }
  /** triggered when the user clicks the duplicate button in the file manager header. */
  duplicateClick(): void {
    const item = this.selectedItem();
    this.onDuplicate(item);
    this.setSelectedTableData();
  }
  @HostListener('window:keydown.enter', ['$event'])
  openEvent(event: KeyboardEvent): void {
    event.preventDefault();
    if (this.propertyDialog.openDialogs.length === 0 && !this.editDisabled) {
      this.editClick();
    }
  }

  @HostListener('window:keydown.delete', ['$event'])
  deleteEvent(event: KeyboardEvent): void {
    event.preventDefault();
    if (this.propertyDialog.openDialogs.length === 0 && !this.deleteDisabled) {
      this.deleteClick();
    }
  }

  @HostListener('dblclick', ['$event'])
  doubleClickEvent(event: MouseEvent): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.propertyDialog.openDialogs.length === 0 && !this.editDisabled) {
      this.editClick();
    }
  }
  /** triggered when the user clicks the edit button in the file manager header. Calls onEdit(item). */
  editClick(): void {
    const item = this.selectedItem();
    this.onEdit(item);
  }
  /** triggered when the user clicks the delete button in the file manager header. */
  deleteClick(): void {
    const items = this.fileManagerTable?.getSelectedValues()?.map(i => this.getItemFromTableItem(i));
    this.onDelete(items);
    this.setSelectedTableData();
  }

  /** triggered when the user clicks the active/inactive button in the file manager header. */
  publishClick(): void {
    const items = this.fileManagerTable?.getSelectedValues()?.map(i => this.getItemFromTableItem(i));
    this.onPublish(items, true);
  }

  /** triggered when the user clicks the active/inactive button in the file manager header. */
  unpublishClick(): void {
    const items = this.fileManagerTable?.getSelectedValues()?.map(i => this.getItemFromTableItem(i));
    this.onPublish(items, false);
  }

  printClick(): void {
    const items = this.fileManagerTable?.getSelectedValues()?.map(i => this.getItemFromTableItem(i));
    this.onPrint(items);
  }

  refreshClick(): void {
    this.setSelectedTableData();
    this.onRefresh();
  }

  clearFilters(): void {
    Object.keys(this.state.filters).forEach(key => {
      if (typeof this.state.filters[key as keyof typeof this.state.filters] === 'string') {
        (this.state.filters[key as keyof typeof this.state.filters] as string) = '';
      } else if (Array.isArray(this.state.filters[key as keyof typeof this.state.filters])) {
        (this.state.filters[key as keyof typeof this.state.filters] as any[]) = [];
      }
    });
  }

  selectionChanged(): void {
    const selectedValues = this.fileManagerTable?.getSelectedValues();
    const selectedCount = selectedValues ? selectedValues.length : 0;

    this.selectedTableData.set(undefined);

    if (selectedCount > 0) {
      const singleSelected = selectedValues.length === 1;

      if (singleSelected) {
        this.selectedTableData.set(selectedValues[0]);

        // if detailEditDisabled is true, then we can't edit anything more
        this.editDisabled.set(!singleSelected || this.detailEditDisabled());
        this.duplicateDisabled.set(!singleSelected);
        this.deleteDisabled.set(false);
        this.publishDisabled.set(false);
        this.printDisabled.set(true); // TODO false;
      } else {
        this.editDisabled.set(true);
        this.duplicateDisabled.set(true);
        this.deleteDisabled.set(false);
        this.publishDisabled.set(false);
        this.printDisabled.set(true);
      }
    } else {
      this.editDisabled.set(true);
      this.duplicateDisabled.set(true);
      this.deleteDisabled.set(true);
      this.publishDisabled.set(true);
      this.printDisabled.set(true);
    }

    this.selectedCount.set(selectedCount);
  }

  updateSort(sort: Sort): void {
    this.fileManagerTable.updateSort(sort);
  }

  protected setSelectedTableData(): void {
    this.editorService.setSelectedTableData(this.fileManagerTable?.getSelectedValues());
  }
}
