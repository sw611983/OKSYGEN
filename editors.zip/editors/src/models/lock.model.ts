/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/**
 * Lock editing a certain editor item so no one else can edit it.
 * For example, lock scenario "1 auto train" while you edit it so someone doesn't override your changes.
 * Must supply machine or user to be the lock holder (or both).
 */
export interface EditorLock {
  /** id of the item to be locked, ie scenario 1. */
  id: string|number;
  /** Which editor this locked item belonds to. Generally scenario, rule, robotDriver, userFault. */
  editor: string;
  /** ISO timestamp of the expiry datetime. Leave blank or set to 0 to indicate infinite (infinite) locking. */
  expiry?: string;
  /** user's id */
  user: string;
  /** (optionally) specify the machine the lock is on */
  machine?: string;
}

// TODO create a provider token

/**
 * Supported configuration for the locking of an editor.
 */
export interface LockConfig {
  /** Whether locking is enabled for the editor */
  enabled: boolean;
  /** Whether it's possible for a user to forcibly break a lock. Default false. */
  forceBreak?: boolean;
  /** how long in seconds a lock should persist for. Leave blank or set to 0 to indicate infinite (infinite) locking. */
  duration?: number;
  /** whether the lock is linked to the machine or the user. Default user */
  lockHolderType?: 'user'|'machine';
}

export interface LockDisplay {
  lockHolder: 'me'|'other'|'unlocked';
  lockHolderName?: string;
  forceUnlockEnabled?: boolean;
  expiry?: string;
}

export const disabledLockConfig: LockConfig = {
  enabled: false,
  lockHolderType: 'user'
};
