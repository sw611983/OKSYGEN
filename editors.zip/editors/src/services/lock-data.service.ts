/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { SelfCompletingObservable, asArray, generateUuid } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { AbstractDataService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Observable, zip } from 'rxjs';
import { map } from 'rxjs/operators';
import { EditorLock, disabledLockConfig } from '../models/lock.model';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';

type XmlLock = EditorLock;

@Injectable()
export class LockDatabaseService extends AbstractDataService<EditorLock[]> {

  private lockData: EditorLock[];
  private machineId: string;

  private futureDeletions: any[] = [];

  constructor(
    logging: Logging,
    registry: Registry,
    dataAccessService: DataAccessService,
    private authService: AuthService
  ) {
    super(logging, registry, dataAccessService);
    // note we do not call this.initialise which means data is not loaded automatically - a browser must manually call reloadData().
    this.machineId = generateUuid();
  }

  // TODO should use a cache eviction mechanism (e.g. comparing time of last update to latest)
  // to avoid unnecessary data transfer.
  /**
   * Request the data to be reloaded.
   * the data will be published to the data() Observable when the data is reloaded.
   */
  public reloadData(): void {
    this.getDatabaseLocks().subscribe(data => {
      if (data) {
        this.lockData = data;
        this.dataSubject.next(this.lockData);
        this.setExpiryActions();
      }
    });
  }

  isEnabled(editor: string): boolean {
    const lockConfig = this.registry.getObject(['editor', editor, 'locking'], disabledLockConfig);
    return lockConfig.enabled;
  }

  getMachineId(): string {
    return this.machineId;
  }

  getDatabaseLocks(): SelfCompletingObservable<EditorLock[]> {
    return this.dataAccessService
    .callQueryJson<{lock: XmlLock[]}>({
      query: 'get_locks',
      operation: 'getLocks',
      debugMsg: 'fetched locks'
    })
    .pipe(
      map(locks => {
        if(!locks?.lock) {return []; }
        const lockArray = asArray(locks.lock).map(xml => this.xmlToLock(xml));
        return lockArray;
      })
    );
  }

  addDatabaseLock(lock: EditorLock): SelfCompletingObservable<any> {
    return this.dataAccessService
    .callQueryJson<any>({
      query: 'add_lock',
      operation: 'addLock',
      debugMsg: 'add lock',
      parameters: { id: lock.id, editor: lock.editor, user: lock.user, machine: lock.machine, expiry: lock.expiry }
    });
  }

  deleteDatabaseLock(id: string|number, editor: string): SelfCompletingObservable<any> {
    return this.dataAccessService
    .callQueryJson<any>({
      query: 'delete_lock',
      operation: 'deleteLock',
      debugMsg: 'delete lock',
      parameters: { id, editor }
    });
  }

  getLock(id: string|number, editor: string): Observable<EditorLock> {
    return this.data().pipe(
      map(locks => locks?.find(lock => lock.id === id && lock.editor === editor))
    );
  }

  getEditorLocks(editor: string): Observable<EditorLock[]> {
    return this.data().pipe(
      map(locks => locks?.filter(lock => lock.editor === editor))
    );
  }

  createLockData(dataId: string, editor: string): EditorLock {
    const getLockExpiryDate = (): Date => {
      const lockConfig = this.registry.getObject(['editor', editor, 'locking'], disabledLockConfig);
      const duration = lockConfig.duration;
      if (!duration) { return null; }
      const durationInMs = duration * 1000;
      const expiryDate = new Date(Date.now() + durationInMs);
      return expiryDate;
    };
    const expiryDate = getLockExpiryDate();
    const user = this.authService.getLoggedInUser();
    const lock: EditorLock = {
      id: dataId,
      editor,
      expiry: expiryDate?.toISOString() ?? '0',
      user: user?.firstName+' '+user?.lastName,
      machine: this.getMachineId()
    };
    return lock;
  }

  private xmlToLock(xml: EditorLock): EditorLock {
    if (!xml) { return null; }
    xml.expiry = `${xml.expiry}`; // 0 as a number might come back rather than '0'
    return xml;
  }

  private setExpiryActions(): void {
    if (!this.lockData?.length) { return; }
    const deletions: Observable<any>[] = [];
    const futureDeletions: any[] = [];
    for (const lock of this.lockData) {
      if (!lock.expiry || lock.expiry === '0') { continue; } // no expiry, don't try to delete
      const date = new Date(lock.expiry);
      if (isNaN(date.getTime())) { continue; }
      if (date.getTime() < Date.now() ) {
        const obs = this.deleteDatabaseLock(lock.id, lock.editor);
        deletions.push(obs);
      } else {
        const diff = date.getTime() - Date.now();
        const timer = setTimeout(() => this.deleteDatabaseLock(lock.id, lock.editor).subscribe(() => this.reloadData()), diff);
        futureDeletions.push(timer);
      }
    }
    this.futureDeletions?.forEach(fd => clearTimeout(fd));
    zip(...deletions).subscribe(results => {
      this.reloadData();
    });
    this.futureDeletions = futureDeletions;
  }
}
