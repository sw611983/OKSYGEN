/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { cloneDeep } from 'lodash';

import { EditorBrowserTableData } from '@oksygen-sim-train-libraries/components-services/common';
import { Sort } from '@angular/material/sort';

/**
 * The implementing concrete services will contain the current state (most likely via the store) for that screen.
 * This is so that a user can navigate between the open tabs and not lose the current work.
 * It is responsible for the clean up when the screen is properly closed (i.e. the tab is also removed).
 */
export abstract class AbstractBrowserService {
  /**
   * Indicates whether the page is active
   */
  public pageActive: boolean;

  /**
   * Indicates whether the page is currently visible
   */
  public pageVisible: boolean;

  private selectedTableData: EditorBrowserTableData[] = [];
  private selectedSortData: Sort;

  /**
   * @param name - used for logging within this base class
   */
  constructor(private name: string) {
    this.pageActive = false;
    this.pageVisible = false;
  }

  /**
   * This is called when the page is first opened
   */
  public initialiseEditing(): void {
    this.pageActive = true;
  }

  /**
   * This is called when the page is being closed fully
   */
  public resetEditing(): void {
    this.pageActive = false;
    this.pageVisible = false;
    this.selectedTableData = [];
  }

  /**
   * Called each time the page view is opened
   */
  public pageOpening(): void {
    this.pageVisible = true;
  }

  /**
   * Called each time the page view is closed
   */
  public pageClosing(): void {
    this.pageVisible = false;
  }

  public getSelectedTableData(): EditorBrowserTableData[] {
    return this.selectedTableData;
  }

  public setSelectedTableData(value: EditorBrowserTableData[]): void {
    if (this.pageActive) {
      this.selectedTableData = cloneDeep(value);
    }
  }
  /**
   * get the sorted column details
   */
  public getSelectedSortedData(): Sort {
    return this.selectedSortData;
  }
  /**
   * set the sorted column details
   */

  public setSelectedSortedData(value: Sort): void {
    if (this.pageActive) {
      this.selectedSortData = cloneDeep(value);
    }
  }
}
