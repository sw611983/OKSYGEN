/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable, NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, combineLatest, Observable, Subscription } from 'rxjs';

import { computeIfAbsent, generateUuid, SelfCompletingObservable, shareReplayOne } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LmsService } from '@oksygen-sim-core-libraries/components-services/lms';

import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BaseDataEditorManager } from './base-data-editor.manager';
import { map, tap } from 'rxjs/operators';
import { AbstractDataService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Context } from '@oksygen-sim-train-libraries/components-services/common';
import { BaseData } from '../models/editor-data.model';

@Injectable()
export abstract class EditorManagementService<
  StoreEditorState, D extends BaseData, C extends Context, Manager extends BaseDataEditorManager<D, C>
> {

  protected editManagers: Map<string, Manager> = new Map();
  protected subscription = new Subscription();
  protected editorsActiveSubject = new BehaviorSubject<number>(0);

  constructor(
    protected dataAccessService: DataAccessService,
    protected authService: AuthService,
    protected store: Store<StoreEditorState>,
    protected registry: Registry,
    protected logger: Logging,
    protected lmsService: LmsService,
    protected dialog: MatDialog,
    protected translateService: TranslateService,
    protected snackbar: MatSnackBar,
    protected readonly zone: NgZone,
    protected dataService: AbstractDataService<D[]>
  ) {}

  abstract newManager(id: string|number): Manager;

  destroy(): void {
    this.editManagers.forEach(value => value.destroy());
    this.editManagers.clear();

    this.subscription.unsubscribe();
  }

  /** Get the specified manager. Creates it if it does not already exist. */
  getEditManager(id: string|number): Manager {
    return computeIfAbsent(this.editManagers, id, i => {
      this.editorsActiveSubject.next(this.editManagers.size + 1); // add one for this new manager

      return this.newManager(id);
    });
  }

  public newItem(name: string): Promise<string> {
    return new Promise(resolve => {
      const id = generateUuid();

      const manager = this.getEditManager(id);
      manager.newItem(name);
      resolve(id);
    });
  }

  public loadItem(item: D): void {
    const manager = this.getEditManager(item.id);
    manager.loadItem(item);
  }

  /**
   * Delete an item from where it's stored.
   * Generally this should also clean up the corresponding data manager (hence destroyManager).
   *
   * @param item delete this item
   * @param destroyManager (default true) also destroy it's data manager
   */
  public deleteItem(item: D, destroyManager = true): SelfCompletingObservable<any> {
    const manager = this.getEditManager(item.id);
    return manager.deleteItem(item, true).pipe(
      tap(detroyed => {
        if (destroyManager) {
          manager.destroy();
        }
      })
    );
  }

  public deleteItems(items: D[], destroyManagers = true): SelfCompletingObservable<any> {
    const managers: {manager: Manager; obs: SelfCompletingObservable<any>}[] = [];
    if (Array.isArray(items)) {
      for (const item of items) {
        const manager = this.getEditManager(item.id);
        managers.push({manager, obs: manager.deleteItem(item, false)});
      }
    }
    return combineLatest(managers.map(s => s.obs)).pipe(
      tap(results => {
        // false means that request failed, string means it succeeded
        // the string will be something like "deleted (1) record in 123ms"
        const allResults = results.map(r => r === false || typeof r === 'string');
        if (allResults.length === items.length) {
          this.dataService.reloadData();
          if (destroyManagers) {
            for (const sub of managers) {
              sub.manager.destroy();
            }
          }
        }
      })
    );
  }

  /**
   * This will duplicate an item with an optional new name. BEWARE - this does NOT know about ids on your data type, so you will need to set that yourself.
   */
  public duplicateItem(item: D, newName?: string): Promise<string> {
    const newId = generateUuid();
    const manager = this.getEditManager(newId);
    return manager.duplicateItem(item, newName).pipe(
      map(result => newId)
    ).toPromise();
  }

  public saveItem(item: D): SelfCompletingObservable<any> {
    const manager = this.getEditManager(item.id);
    return manager.saveItemDirect(item);
  }

  public confirmCloseEditor(id: string): Observable<boolean> {
    const manager = this.getEditManager(id);
    return manager.confirmCloseEditor();
  }

  getActiveEditorCount(): number {
    return this.editorsActiveSubject.getValue();
  }

  get activeEditors$(): Observable<number> {
    return this.editorsActiveSubject.pipe(shareReplayOne());
  }

  /** Destroy a manager (and recursively all it's data). */
  destroyManagers(id: string): void {
    const editManager = this.editManagers.get(id);

    if (editManager) {
      editManager.destroy();
    }

    this.editManagers.delete(id);

    if (this.editManagers.size !== this.editorsActiveSubject.getValue()) {
      this.editorsActiveSubject.next(this.editManagers.size);
    }
  }
}
