/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { FaultsEditorService } from './faults-editor.service';

describe('FaultsEditorService', () => {
  let service: FaultsEditorService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [ OksygenSimTrainEditorsModule ]
    });
    service = TestBed.inject(FaultsEditorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
