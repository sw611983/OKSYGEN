/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Observable, of, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { SelfCompletingObservable, SUPER_WAS_CALLED, SuperCalled } from '@oksygen-common-libraries/common';
import {
  ConfirmDataActionComponent,
  ConfirmDataActionDialogData,
  DONT_SAVE_TEXT,
  SAVE_TEXT,
  UNSAVED_CHANGES_TEXT
} from '@oksygen-common-libraries/material/components';
import { MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { BaseDataManager } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Context } from '@oksygen-sim-train-libraries/components-services/common';

enum ConfirmCloseEditorResult {
  SAVE,
  CANCEL,
  NO_SAVE
}

/**
 * The abstract base class your data editor managers should extend.
 * This is mostly in charge of the editor data, so scenarios in scenario editor for example.
 * Generally, you'll actually be storing these things in the store,
 * so it's likely that a lot of your methods here will just be forwarding events to store actions.
 */
export abstract class BaseDataEditorManager<D, C extends Context> extends BaseDataManager<D> {

  /**
   * Whether the editor has any unsaved changes. Initially false, but most user interactions should change this to true.
   */
  unsavedChanges = false;
  context: C;
  readonly subscription = new Subscription();


  constructor(protected translateService: TranslateService, protected dialog: MatDialog) { super(); }

  public destroy(): SuperCalled {
    this.context?.destroy();
    this.subscription.unsubscribe();
    return SUPER_WAS_CALLED;
  }

  /**
   * An async check to perform a the editor is closed (via the tab x button).
   * emits true when close should be fired (ie, after user clicks "yes" in "are you sure?").
   * emits false if the editor should not be closed (user clicks "cancel").
   * */
  public confirmCloseEditor(): SelfCompletingObservable<boolean> {
    if (!this.unsavedChanges) {
      return of(true);
    } else {
      const dialogRef = this.createUnsavedDialog();
      return dialogRef.afterClosed().pipe(
        switchMap(dialogResult => {
          switch (dialogResult) {
            case ConfirmCloseEditorResult.SAVE:
                // we're all good to close, so bypass the method that uses the snackbar
                // but make sure we force a reload after the save
                return this.saveItem();
            case ConfirmCloseEditorResult.NO_SAVE:
              return of(true);
            default:
              return of(false);
          }
        })
      );
    }
  }
  /**
   * Sets the context for your data manager.
   * Context is the suite of related data your data manager should know about.
   * For scenarios, this would be the scenario, trains, world, map state etc.
   *
   * @param dm the data manager
   */
  abstract setEditingContext(dm: C): void;

  /**
   * Creates a new item, generally to be solely managed by this manager.
   * Generally, this should just forward the creation to the store.
   * @param name the name of the item
   */
  abstract newItem(name: string): void;

  /**
   * Sets the currently being edited item.
   * While you can edit multiple items, only 1 will be the "active" tab.
   *
   * @param item the item to edit
   */
  abstract loadItem(item: D): void;

  // there is a strong argument that this should not happen on the manager
  // as you often delete data items externally.
  // That is, delete from the browser NOT the editor, so no need for a manager.
  // Currently, we create a manager only to call delete then destroy the manager.
  // Two reasons for this anti-pattern:
  // 1) no better place currently
  // 2) keeps all that logic together (create, modify, delete, duplicate etc)
  /**
   * Deletes an item. Optionally reload the data from the data source (baseX, comms, etc).
   * @param item the item to delete
   * @param reload (optional) whether to reload the data from the data source.
   */
  abstract deleteItem(item: D, reload?: boolean): SelfCompletingObservable<void>;

  /**
   * Duplicate an item.
   *
   * @param item the item to duplicate
   * @param newName (optional) a new name for the item
   */
  abstract duplicateItem(item: D, newName?: string): SelfCompletingObservable<void>;

  /**
   * Returns an observable containing the result.
   * True if the save succeeded, false if it failed for unknown reasons.
   */
  abstract saveItem(): SelfCompletingObservable<boolean>;

  /**
   * Save the passed in item directly to the database.
   */
  abstract saveItemDirect(item: D): SelfCompletingObservable<any>;

  /**
   * Get the current name of this item.
   */
  abstract getItemName(): string;

  /**
   * @deprecated
   */
  data(): Observable<D> {
    return this.data$;
  }

  private createUnsavedDialog(): MatDialogRef<ConfirmDataActionComponent<ConfirmCloseEditorResult>, ConfirmCloseEditorResult> {
    const data: ConfirmDataActionDialogData<ConfirmCloseEditorResult> = {
      title: UNSAVED_CHANGES_TEXT,
      content: this.translateService.instant(t('Do you want to save changes to <b>{name}</b>?'), { name: this.getItemName() }),
      primaryActionText: SAVE_TEXT,
      primaryActionResult: ConfirmCloseEditorResult.SAVE,
      cancelActionResult: ConfirmCloseEditorResult.CANCEL,
      secondaryActionText: DONT_SAVE_TEXT,
      secondaryActionColor: MaterialThemePalette.PRIMARY,
      secondaryActionResult: ConfirmCloseEditorResult.NO_SAVE
    };

    const dialogRef = this.dialog.open<
      ConfirmDataActionComponent<ConfirmCloseEditorResult>,
      ConfirmDataActionDialogData<ConfirmCloseEditorResult>,
      ConfirmCloseEditorResult
    >(
      ConfirmDataActionComponent,
      {
        disableClose: true,
        minHeight: '100px',
        minWidth: '400px',
        data
      }
    );
    return dialogRef;
  }
}
