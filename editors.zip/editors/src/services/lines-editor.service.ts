/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';

import { AbstractBrowserService } from './abstract-browser.service';

@Injectable()
export class LinesEditorService extends AbstractBrowserService {

  constructor() {
    super('LinesEditorService');
   }

  /**
   * This is called when the page is first opened
   */
  public override initialiseEditing(): void {
    super.initialiseEditing();
    // TODO: Any local initialisation for this
  }

  /**
   * This is called when the page is being closed fully
   */
  public override resetEditing(): void {
    super.resetEditing();
    // TODO: Any local clean-up for this
  }
}
