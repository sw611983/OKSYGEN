/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { TrainsEditorService } from './trains-editor.service';

describe('TrainsEditorService', () => {
  let service: TrainsEditorService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [ OksygenSimTrainEditorsModule ],
      providers: [TrainsEditorService]
    });
    service = TestBed.inject(TrainsEditorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
