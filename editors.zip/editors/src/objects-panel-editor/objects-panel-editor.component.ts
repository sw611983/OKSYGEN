/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { isNil } from 'lodash';
import { Observable, Subscription } from 'rxjs';
import { switchMap, tap } from 'rxjs/operators';

import { filterTruthy } from '@oksygen-common-libraries/common';
import { Filter } from '@oksygen-common-libraries/material/components';
import { Registry } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DETAILS, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectDataMapContext, ObjectDataMapContextSupplier } from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectListFilterType } from '@oksygen-sim-train-libraries/components-services/objects';
import {
  ObjectContainer,
  ObjectEditManager,
  ObjectPropertiesConfig,
  ObjectPropertyChange,
  ObjectQuickActionConfig,
  ObjectSource,
  ObjectStateChange,
  SimObject
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { Orientation, SegOffsetOriented } from '@oksygen-sim-core-libraries/data-types/common';

@Component({
  selector: 'oksygen-objects-panel-editor',
  templateUrl: './objects-panel-editor.component.html',
  styleUrls: ['./objects-panel-editor.component.scss']
})
export class ObjectsPanelEditorComponent implements OnInit, OnDestroy {
  objects$: Observable<Array<ObjectContainer>>;
  objectModifications$: Observable<Array<string>>; // the string is the name of the object that has been modified
  objectSelected$: Observable<ObjectContainer>;
  objectTypes: Array<string> = [];
  showProperties: boolean;
  objectIsSelected: ObjectContainer;
  objectPropertiesConfig: ObjectPropertiesConfig;

  @Input() objectEditManager: ObjectEditManager;
  @Input() world$?: Observable<WorldData>;
  @Input() uiModels!: UiStateModelManager;
  @Input() objectSource!: ObjectSource;
  @Input() uiModelKeyPrefix = 'oksygen-objects-panel-editor';
  @Input() editorType = 'scenario';
  @Input() sourceFilters: Array<Filter<ObjectListFilterType>> | undefined;

  @Input() quickActionSettings: ObjectQuickActionConfig = {
    favouriteEnabled: false,
    findEnabled: true,
    deleteEnabled: o => o?.source.id === this.objectSource.id,
    changeOrientationEnabled: o => o?.source.id === this.objectSource.id
  };

  @Output() readonly objectSelect: EventEmitter<SimObject> = new EventEmitter();
  @Output() readonly openTab: EventEmitter<{ tabName: string; detailId: string | number }> = new EventEmitter();

  world: WorldData;
  breadcrumbChildren: ReadonlyArray<string>;
  context$: Observable<ObjectDataMapContext>;

  private readonly masterSubscription = new Subscription();

  private context: ObjectDataMapContext;

  constructor(private cd: ChangeDetectorRef, private registry: Registry, private contextSupplier: ObjectDataMapContextSupplier) {}

  ngOnInit(): void {
    this.context$ = this.contextSupplier
    .currentContext$()
    .pipe(filterTruthy());
    this.masterSubscription.add(
      this.context$
        .subscribe(m => {
          this.context = m;
          this.initialiseData();
        })
    );
    if (this.world$) {
      this.masterSubscription.add(
        this.world$.pipe(filterTruthy()).subscribe(w => {
          this.world = w;
        })
      );
    }
    this.showProperties = this.registry.getBoolean(['editor', this.editorType, 'objects', 'showProperties'], false);
    this.objectPropertiesConfig = this.registry.getObject<ObjectPropertiesConfig>(['editor', this.editorType, 'objects', 'properties'], {});

    if (!isNil(this.objectEditManager)) {
      this.masterSubscription.add(
        this.objectEditManager.objectDeletion$.subscribe(deletion => {
          if (deletion) {
            if (this.objectIsSelected.source.id === this.objectSource.id) {
              this.objectIsSelected = null;
            }
          }
        })
      );
    }
  }

  ngOnDestroy(): void {
    this.onBack(null);
    this.masterSubscription?.unsubscribe();
  }

  initialiseData(): void {
    this.objectSelected$ = this.context$
      .pipe(
        switchMap(m => m.map.getSelectedObject())
      )
      .pipe(
        tap(objectSelected => {
          this.updateBreadcrumbs(objectSelected);
          setTimeout(() => this.cd.markForCheck() );
        })
      );

    this.objects$ = this.context$.pipe(
      switchMap(m => m.objects.data()),
      filterTruthy()
    );
    this.objectModifications$ = this.context$.pipe(
      switchMap(context => context.objectModifications$())
    );
  }

  onBack(object: ObjectContainer | undefined): void {
    this.objectIsSelected = object;
    this.updateBreadcrumbs(object);
    this.context?.map?.selectObject(null);
  }

  deselectObject(): void {
    this.selectObject(undefined);
    this.objectIsSelected = null;
  }

  selectObject(object?: ObjectContainer): void {
    this.objectIsSelected = object;
    this.context$.subscribe(m => m.map.selectObject(object?.id));
  }

  deleteClick(object: ObjectContainer): void {
    this.deselectObject();
    this.objectEditManager.deleteObject(object.id);
    this.context$.subscribe(m => {
        m.map.removeSpotlightObject(object.id);
      });
  }

  ruleClick(scenarioRuleId: number): void {
    this.openTab.emit({ tabName: 'rule', detailId: scenarioRuleId });
  }

  stateChange(obj: ObjectContainer, state: ObjectStateChange): void {
    // check whether it's this object or a child that's been updated
    let selectedObj: ObjectContainer = null;
    if (obj.id !== state.objectId && obj.children?.length > 0) {
      selectedObj = obj.children.find(o => o.id === state.objectId) as ObjectContainer;
    } else if (obj.id === state.objectId) {
      selectedObj = obj;
    }
    if (!selectedObj) {
      return;
    }
    // update the scenario
    this.objectEditManager.objectStateChange(selectedObj, state);
    // preview manager only takes state, and state should be the init state and it uses stateId
    // FIXME this code does nothing - what should it be doing?
    // const initState = updates.find(pu => pu.propertyName === INITIAL_STATE);
    // if (initState) {
    //   let stateId: number;
    //   selectedObj.states.forEach(s => {
    //     if (s.name === initState.newValue) { stateId = s.id; }
    //   });
    // }
  }

  propertyChange(obj: ObjectContainer, property: ObjectPropertyChange): void {
    let selectedObj: ObjectContainer = null;
    if (obj.id !== property.objectId && obj.children?.length > 0) {
      selectedObj = obj.children.find(o => o.id === property.objectId) as ObjectContainer;
    } else if (obj.id === property.objectId) {
      selectedObj = obj;
    }
    if (!selectedObj) {
      return;
    }
    this.objectEditManager.objectPropertyChange(selectedObj, property);
  }

  private updateBreadcrumbs(iconSelected?: ObjectContainer): void {
    if (iconSelected) {
      this.breadcrumbChildren = [DETAILS];
      this.objectIsSelected = iconSelected;
    } else {
      this.breadcrumbChildren = null;
    }
  }

  reverseOrientation(orientation: Orientation): Orientation {
    switch (orientation) {
      case (orientation = Orientation.ALPHA_TO_BETA):
        return Orientation.BETA_TO_ALPHA;
      case Orientation.BETA_TO_ALPHA:
        return Orientation.NONE;
      case Orientation.NONE:
        return Orientation.ALPHA_TO_BETA;
    }
  }

  updateObjectOrientation(selectedObj: ObjectContainer): void {
    let so: SegOffsetOriented;
    let index = 0;

    selectedObj.trackAssociations.forEach(track => {
      so = { segmentId: track.segmentId, offset: track.offset, orientation: this.reverseOrientation(track.orientation) };
      index = index + 1;
    });

    this.objectEditManager.updateObjectPosition(
      selectedObj,
      selectedObj.location.lnglat,
      selectedObj.trackAssociations.map((a, i) => (i === 0 ? so : a))
    );
  }
}
