/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';

import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import { PropertyUpdated } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectsListComponent } from '@oksygen-sim-train-libraries/components-services/objects';
import {
  ObjectContainer,
  ObjectEditManager,
  ObjectPropertyChange,
  ObjectStateChange,
  ObjectWorldGeometry
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import {
  configureSimTrainTestingModule,
  SCENARIO_EDITOR_CONTEXT_PROVIDERS
} from '@oksygen-sim-train-libraries/components-services/testing';

import { ObjectsPanelEditorComponent } from './objects-panel-editor.component';

describe('ObjectsPanelEditorComponent', () => {
  let component: ObjectsPanelEditorComponent;
  let fixture: ComponentFixture<ObjectsPanelEditorComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [ObjectsPanelEditorComponent, ObjectsListComponent],
      providers: SCENARIO_EDITOR_CONTEXT_PROVIDERS
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectsPanelEditorComponent);
    component = fixture.componentInstance;
    component.objectEditManager = new ObjectEditManagerStub();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

class ObjectEditManagerStub implements ObjectEditManager {
  objectDeletion$ = new BehaviorSubject<boolean>(false);

  deleteObject(id: number): void {}

  objectStateChange(obj: ObjectContainer, state: ObjectStateChange): Array<PropertyUpdated> {
    return [];
  }

  objectPropertyChange(obj: ObjectContainer, property: ObjectPropertyChange): Array<PropertyUpdated> {
    return [];
  }

  updateObjectName(id: number, name: string): void {}

  updateObjectPosition(object: ObjectContainer, pos: LngLatCoord, assocs?: Array<TrackSegmentAssociation>): void {}

  updateObjectGeometry(object: ObjectContainer, geom: ObjectWorldGeometry): void {}

  updateObjectBoundaries(id: number, boundaries: Array<Array<LngLatCoord>>): void {}
}
