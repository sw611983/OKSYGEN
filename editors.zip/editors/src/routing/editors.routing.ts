/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Route } from '@angular/router';
import { isNil } from 'lodash';

import { RouteConfig } from '@oksygen-common-libraries/material/components';

export const EDITORS_PATH = 'editors';

export function editorsRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];

  if (isNil(config?.loadChildren)) {
    throw new Error('Must specify loadChildren when using the editorsRoute function');
  }

  return {
    path: EDITORS_PATH,
    loadChildren: config.loadChildren,
    canActivate: auth
  };
}
