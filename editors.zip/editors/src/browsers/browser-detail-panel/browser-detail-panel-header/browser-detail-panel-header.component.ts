/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, computed, input, output } from '@angular/core';

import { CreatedModified, getCreatedModifiedDateTime, getCreatedModifiedName } from '@oksygen-common-libraries/common';
import { EditorBrowserTableStatus } from '@oksygen-sim-train-libraries/components-services/common';
import { Version } from '@oksygen-sim-train-libraries/components-services/versioning';

import { LockDisplay } from '../../../models/lock.model';

@Component({
  selector: 'oksygen-browser-detail-panel-header',
  templateUrl: './browser-detail-panel-header.component.html',
  styleUrls: ['./browser-detail-panel-header.component.scss']
})
export class BrowserDetailPanelHeaderComponent {
  public readonly breadcrumbs = input<boolean>(true);
  public readonly title = input.required<string>();
  public readonly mode = input.required<'new' | 'edit' | 'view'>();
  public readonly created = input<CreatedModified>();
  public readonly modified = input<CreatedModified>();
  public readonly version = input<string | number | Version>();
  public readonly status = input<EditorBrowserTableStatus>();
  public readonly lock? = input<LockDisplay>();
  public readonly showInUseAlert = input<boolean>(false);

  public readonly unlock = output<void>();

  createdName = computed(() => getCreatedModifiedName(this.created()));
  modifiedName = computed(() => getCreatedModifiedName(this.modified()));
  createdAt = computed(() => getCreatedModifiedDateTime(this.created()));
  modifiedAt = computed(() => getCreatedModifiedDateTime(this.modified()));

  constructor() {}
}
