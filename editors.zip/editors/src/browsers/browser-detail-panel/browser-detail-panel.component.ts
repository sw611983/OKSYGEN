/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, Output } from '@angular/core';

import { CreatedModified } from '@oksygen-common-libraries/common';
import { EditorBrowserTableStatus } from '@oksygen-sim-train-libraries/components-services/common';
import { Version } from '@oksygen-sim-train-libraries/components-services/versioning';
import { DetailsToolbarComponent } from '../../details-toolbar/details-toolbar.component';
import { LockDisplay } from '../../models/lock.model';

/**
 * Supports content project of a 'header' and 'content'. If no header is supplied, a basic default one is displayed.
 * This basic header can be controlled via various inputs listed below.
 * Usage: ```
 * <oksygen-browser-detail-panel [selectedCount]="someNumber" [title]="'Scenario Editor'">
 *  <div header>this element is used as the header</div>
 *  <div content>and this element is used as the main content</div>
 * </oksygen-browser-detail-panel>
 * ```
 *
 * @input selectedCount
 * @input title (typically, the name of the selected item, IE Foo Train or Bar Scenario)
 * @input itemType (the name of the type of item, ie user fault or scenario)
 * @input detailEditDisabled (default false)
 * @input detailDuplicateDisabled (default true)
 * @input detailPrintDisabled (default false)
 * @input detailEditTooltip (default true)
 * @input detailEditTooltip (default 'Edit')
 * @input lock (optional) if this editor item is locked supply the lock
 * @output duplicate emits when duplicate button clicked (can only happen when enabled)
 * @output edit emits when edit button clicked (can only happen when enabled)
 * @output delete emits when delete button clicked (can only happen when enabled)
 * @output print emits when print button clicked (can only happen when enabled)
 */
@Component({
  selector: 'oksygen-browser-detail-panel',
  templateUrl: './browser-detail-panel.component.html',
  styleUrls: ['./browser-detail-panel.component.scss']
})
export class BrowserDetailPanelComponent {

  @Input() selectedCount: number;
  @Input() title: string;
  @Input() itemType: string;
  @Input() status: EditorBrowserTableStatus = 'Unknown';
  @Input() version: string|number|Version = 'Unknown';
  @Input() detailEditDisabled = false;
  @Input() detailDuplicateDisabled = true;
  @Input() detailDeleteDisabled = false;
  @Input() detailPrintDisabled = true;
  @Input() detailEditTooltip: string = DetailsToolbarComponent.DEFAULT_EDIT_TOOLTIP;
  @Input() created: CreatedModified;
  @Input() modified: CreatedModified;
  @Input() lock?: LockDisplay;
  @Input() showInUseAlert = false;
  @Input() openShow = true;
  @Input() deleteShow = true;

  // could consider sharing a service to avoid the extra hop for these outputs
  @Output() readonly duplicate: EventEmitter<void> = new EventEmitter();
  @Output() readonly edit: EventEmitter<void> = new EventEmitter();
  @Output() readonly delete: EventEmitter<void> = new EventEmitter();
  @Output() readonly print: EventEmitter<void> = new EventEmitter();
  @Output() readonly unlock: EventEmitter<void> = new EventEmitter();

  constructor() { }
  duplicateClick(): void {
    this.duplicate.emit();
  }

  editClick(): void {
    this.edit.emit();
  }

  deleteClick(): void {
    this.delete.emit();
  }

  printClick(): void {
    this.print.emit();
  }
}
