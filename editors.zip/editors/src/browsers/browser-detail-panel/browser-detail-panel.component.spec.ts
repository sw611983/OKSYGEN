/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserConfigurationModule } from '@oksygen-sim-train-libraries/components-services/user-configuration';

import { BrowserDetailPanelComponent } from './browser-detail-panel.component';
import { VersionPipe } from '@oksygen-sim-train-libraries/components-services/versioning';

describe('BrowserDetailPanelComponent', () => {
  let component: BrowserDetailPanelComponent;
  let fixture: ComponentFixture<BrowserDetailPanelComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainTrainsModule, OksygenSimTrainUserConfigurationModule],
      declarations: [BrowserDetailPanelComponent, VersionPipe]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrowserDetailPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
