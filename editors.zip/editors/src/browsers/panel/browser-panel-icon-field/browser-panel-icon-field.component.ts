/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';


/**
 * A simple wrapper component for our oksygen-icon-field component for use in our browser panels.
 * Accepts name, icon, multiline, editable, a formControl & placeholder as inputs and outputs the new form value on change (edit).
 *
 * @input name: string
 * @input icon: string
 * @input editable: boolean (defaults false)
 * @input multiline: boolean (default false) whether to use a multiline text input
 * @input control: FormControl (optional, only supply one if you want some validation for an editable control)
 * @input placeholder: string
 * @output edit: any (the value of the form control)
 */
@Component({
  selector: 'oksygen-browser-panel-icon-field',
  templateUrl: './browser-panel-icon-field.component.html',
  styleUrls: ['./browser-panel-icon-field.component.scss']
})
export class BrowserPanelIconFieldComponent implements OnInit, OnDestroy {

  @Input() name!: string;
  @Input() icon: string;
  @Input() value: string|number;
  @Input() multiline = false;
  @Input() editable = false;
  @Input() control: FormControl;
  @Input() placeholder: string;

  @Output() readonly edit = new EventEmitter();

  private valueChangeSub: Subscription;

  constructor() { }

  ngOnInit(): void {
    if (!this.control) {
      this.control = new FormControl();
      if (this.value !== undefined && this.value !== null) {
        this.control.setValue(this.value);
      }
    }
    this.valueChangeSub = this.control.valueChanges.subscribe(val => {
      this.edit.emit(val);
    });
  }

  ngOnDestroy(): void {
    this.valueChangeSub?.unsubscribe();
  }

}
