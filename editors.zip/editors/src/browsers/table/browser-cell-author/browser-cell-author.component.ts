/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Input, OnChanges } from '@angular/core';
import { CreatedModified } from '@oksygen-common-libraries/common';
import { CustomDatePipe } from '@oksygen-common-libraries/material/components';

/**
 * Display author publish information in a table cell.
 * Designed to be used within ```oksygen-file-manager-table```, particularly for created / modified columns.
 *
 * @input author: CreatedModified
 * @input dateFormat: moment format string (default MMM D, YYYY)
 */
@Component({
  selector: 'oksygen-browser-cell-author',
  templateUrl: './browser-cell-author.component.html',
  styleUrls: ['./browser-cell-author.component.scss']
})
export class BrowserCellAuthorComponent implements OnChanges {

  @Input() author!: CreatedModified;

  formattedDate: string;

  constructor(private datePipe: CustomDatePipe) { }

  ngOnChanges(): void {
    this.formattedDate = this.generateFormattedDate(this.author?.date);
  }

  convertDate(date: any): string {
    return this.datePipe.transform(date);
  }

  private generateFormattedDate(date: moment.Moment): string {
    if (!date || !date.isValid()) { return 'Unknown'; }
    return this.convertDate(date);
  }

}
