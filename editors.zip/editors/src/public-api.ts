/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export * from './modules/editors.module';

export * from './models/base-browser-tab-page';
export * from './models/base-editor-tab-page';
export * from './models/base-editor.component';
export * from './models/base-lockable-browser-tab-page';
export * from './models/editor-data.model';
export * from './models/lock.model';
export * from './models/editor-config.model';
export * from './models/editor-state.model';

export * from './editor-tab-nav-item/editor-tab-nav-item.component';
export * from './details-toolbar/details-toolbar.component';
export * from './browsers/table/browser-cell-author/browser-cell-author.component';
export * from './browsers/browser-detail-panel/browser-detail-panel.component';
export * from './browsers/browser-detail-panel/browser-detail-panel-header/browser-detail-panel-header.component';
export * from './browsers/panel/browser-panel-icon-field/browser-panel-icon-field.component';
export * from './objects-panel-editor/objects-panel-editor.component';

export * from './routing/editors.routing';

export * from './services/abstract-browser.service';
export * from './services/base-data-editor.manager';
export * from './services/editor-management.service';
export * from './services/lock-data.service';
export * from './services/faults-editor.service';
export * from './services/lines-editor.service';
export * from './services/trains-editor.service';

export * from './store/base-editor/base-editor.reducer';
export * from './store/base-editor/base-editor.selector';
export * from './store/base-editor/base-editor.state';
export * from './store/common.model';
