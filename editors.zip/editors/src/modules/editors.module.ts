/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { registrySchemaProvider } from '@oksygen-common-libraries/pio/registry';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainObjectsModule } from '@oksygen-sim-train-libraries/components-services/objects';
import { OksygenSimTrainVersionModule } from '@oksygen-sim-train-libraries/components-services/versioning';

import {
  BrowserDetailPanelHeaderComponent
} from '../browsers/browser-detail-panel/browser-detail-panel-header/browser-detail-panel-header.component';
import { BrowserDetailPanelComponent } from '../browsers/browser-detail-panel/browser-detail-panel.component';
import { BrowserPanelIconFieldComponent } from '../browsers/panel/browser-panel-icon-field/browser-panel-icon-field.component';
import { BrowserCellAuthorComponent } from '../browsers/table/browser-cell-author/browser-cell-author.component';
import { DetailsToolbarComponent } from '../details-toolbar/details-toolbar.component';
import { EditorTabNavItemComponent } from '../editor-tab-nav-item/editor-tab-nav-item.component';
import { editorConfigSchema } from '../models/editor-config.model';
import { ObjectsPanelEditorComponent } from '../objects-panel-editor/objects-panel-editor.component';
import { FaultsEditorService } from '../services/faults-editor.service';
import { LinesEditorService } from '../services/lines-editor.service';
import { LockDatabaseService } from '../services/lock-data.service';
import { TrainsEditorService } from '../services/trains-editor.service';

const components = [
  DetailsToolbarComponent,
  BrowserDetailPanelComponent,
  BrowserDetailPanelHeaderComponent,
  BrowserCellAuthorComponent,
  BrowserPanelIconFieldComponent,
  EditorTabNavItemComponent,
  ObjectsPanelEditorComponent
];

const modules = [
  CommonModule,
  RouterModule,
  DragDropModule,
  OksygenMaterialComponentsModule,
  OksygenMaterialTranslateModule.forChild(),
  FormsModule,
  ReactiveFormsModule,
  OksygenSimCoreCommonModule,
  NgxMatDatetimePickerModule,
  NgxMatMomentModule,
  OksygenSimTrainCommonModule,
  OksygenSimTrainVersionModule,
  OksygenSimTrainObjectsModule
];

@NgModule({
  declarations: [...components],
  imports: [...modules],
  exports: [...components],
  providers: [
    FaultsEditorService,
    LinesEditorService,
    TrainsEditorService,
    LockDatabaseService,
    registrySchemaProvider(editorConfigSchema)
  ]
})
export class OksygenSimTrainEditorsModule {}
