/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { EntityAdapter } from '@ngrx/entity';
import { cloneDeep, get, isObject } from 'lodash';
import { BaseEditorState, BaseEditorStoreData, BaseEditorStoreItem } from './base-editor.state';

type AsPrimitive<T> =
  T extends string | number | boolean | null ? T :
  // eslint-disable-next-line @typescript-eslint/no-unsafe-function-type
  T extends Function ? never :
  T extends object ? { [K in keyof T]: AsPrimitive<T[K]> } :
  never;

type AsPrimitive2<T> = T extends string | number | boolean | null ? T : never;

interface FakeType extends BaseEditorStoreItem {
  foo: string;
  barry?: Date;
}
export type PartialPrimitive<T> = Partial<T> & Partial<T & AsPrimitive<T>>;
export type PartialPrimitive2<T> = { [K in keyof T]: AsPrimitive2<T[K]> } & Partial<T>;
const test = {
  id: 'asd',
  foo: 'bar',
  test: 'asd',
  bar: new Date()
};
function testfunc<T extends BaseEditorStoreItem>(
  prop: PartialPrimitive2<T>
): void {

}
testfunc<FakeType>(test);

/**
 * Update primative properties on your editor item for the store.
 * THIS ONLY SUPPORT UPDATING PRIMITIVES!
 * When you call this, ```updatedProperties``` should be either an object literal
 * (ie, the object is created inline in the params) OR
 * the object you define should be of type PartialPrimitive<D>!
 * Not doing this will stop type checking on the object due to a quirk in the TS compiler.
 *
 * @example updateSimpleProperty(state, adapter, {id: '123', name: 'foo'}) // good
 * const obj = {id: '123', nane: 'foo'}; // should error but doesn't - nane not defined
 * updateSimpleProperty(state, adapter, obj) // bad - no type checking
 * const obj2: PartialPrimitive<IdName> = {id: '123', name: 'foo'} // good
 *
 * @param state the state
 * @param adapter the data adapter
 * @param updatedProperties the properties that have been updated (INCLUDING id)
 */
export function updateSimpleProperty<D extends BaseEditorStoreItem>(
  state: BaseEditorState<D>,
  adapter: EntityAdapter<BaseEditorStoreData<D>>,
  updatedProperties: PartialPrimitive<D>
): BaseEditorState<D> {
  const value = cloneDeep(state.entities[updatedProperties.id]);
  if (!value.editorItem) { return state; }
  const propertyUpdates = Object.keys(updatedProperties);
  for (const updateKey of propertyUpdates) {
    if (updateKey === 'id') { continue; } // don't check ids for updates
    const updatedProperty = get(updatedProperties, updateKey);
    if (isObject(updatedProperty)) {
      // error may be harsh, but allowing it can lead to very diffcult to debug bugs
      throw Error(`[BaseEditorReducer] cannot primitive update ${updateKey} with value ${JSON.stringify(updatedProperty)}`);
    }
    // return original state if update doesn't change property value
    if (get(value.editorItem, updateKey) === updatedProperty) { return state; }
  }
  const updatedItem = {
    ...value.editorItem,
    ...updatedProperties
  };

  return updateForUnsavedChanges(adapter, state, value, updatedItem);
}

/**
 * Generic update for store data that takes into account unsaved changes.
 *
 * @param adapter the store adapter to update
 * @param state the state
 * @param original the original
 * @param item the editor item to update
 */
export function updateForUnsavedChanges<T extends BaseEditorStoreItem>(
  adapter: EntityAdapter<BaseEditorStoreData<T>>,
  state: BaseEditorState<T>,
  original: BaseEditorStoreData<T>,
  item: T
): BaseEditorState<T> {
  return adapter.setOne({
    ...original,
    unsavedChanges: true,
    canUndo: true,
    canRedo: false,
    editorItem: item
  }, state);
}
