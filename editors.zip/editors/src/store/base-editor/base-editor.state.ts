/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { EntityState } from '@ngrx/entity';

/**
 * Enforcing all editor items (such as a scenario or user fault) to have an id.
 */
export interface BaseEditorStoreItem {
  id: string;
}

/**
 * This is the editor item (ie a scenario or user fault) as well as some meta data.
 */
export interface BaseEditorStoreData<T extends BaseEditorStoreItem> {
  /** Unique Identifier, usually id */
  id: string;

  /**
   * The name as of last save. This is here since generally the name forms the 'filename' within the database
   */
  savedName: string;

  /**
   * true if there are unsaved changes
   */
  unsavedChanges: boolean;

  /**
   * The item being edited. This'll be a scenario, user fault, signal, etc
   */
  editorItem: T;

  /**
   * true if there are changes to undo
   */
  canUndo: boolean;

  /**
   * true if there are changes to redo
   */
  canRedo: boolean;
}

export type BaseEditorState<T extends BaseEditorStoreItem> = EntityState<BaseEditorStoreData<T>>;
