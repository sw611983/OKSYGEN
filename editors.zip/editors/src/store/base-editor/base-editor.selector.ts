/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BaseEditorStoreData, BaseEditorStoreItem } from './base-editor.state';

/**
 * Selector for observing the saved editor item name.
 * This will change when the editor item is saved.
 */
export function getSavedName<T extends BaseEditorStoreItem>(id: string, storeData: BaseEditorStoreData<T>[]): string {
  for (const userFaultEditorStoreData of storeData) {
    if (userFaultEditorStoreData.id === id) {
      return userFaultEditorStoreData.savedName;
    }
  }
  return null;
}

/**
 * Selector for observing the unsaved changes state
 * This will change when the editor item is saved.
 */
export function getUnsavedChanges<T extends BaseEditorStoreItem>(id: string, storeData: BaseEditorStoreData<T>[]): boolean {
  for (const editorData of storeData) {
    if (editorData.id === id) {
      return editorData.unsavedChanges;
    }
  }
  return false;
}

/**
 * Selector for observing the editor item being edited.
 * This will change during an editing session to reflect the user's input.
 */
export function getEditorItem<T extends BaseEditorStoreItem>(id: string, storeData: BaseEditorStoreData<T>[]): T {
  for (const editorData of storeData) {
    if (editorData.id === id) {
      return editorData.editorItem;
    }
  }
  return null;
}

export function canUndo<T extends BaseEditorStoreItem>(id: string, storeData: BaseEditorStoreData<T>[]): boolean {
  for (const editorData of storeData) {
    if (editorData.id === id) {
      return editorData.canUndo;
    }
  }
  return false;
}

export function canRedo<T extends BaseEditorStoreItem>(id: string, storeData: BaseEditorStoreData<T>[]): boolean {
  for (const editorData of storeData) {
    if (editorData.id === id) {
      return editorData.canRedo;
    }
  }
  return false;
}
