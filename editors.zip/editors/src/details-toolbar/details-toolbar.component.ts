/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

/**
 * Details Toolbar
 * Simple toolbar shared by editor file manager detail panels
 *
 * inputs:
 *
 * @param editShow - set to true to have the edit button show (defaults to true)
 * @param openShow - set to true to have the open button show (defaults to true)
 * @param deleteShow - set to true to have the delete button show (defaults to true)
 * @param publishShow - set to true to have the publish button show (defaults to true)
 * @param editDisabled - set to true to have the edit button as disabled (defaults to true)
 * @param openDisabled - set to true to have the open button as disabled (defaults to true)
 * @param duplicateDisabled - set to true to have the duplicate button as disabled (defaults to true)
 * @param deleteDisabled - set to true to have the delete button as disabled (defaults to true)
 * @param printDisabled - set to true to have the delete button as disabled (defaults to true)
 * @param publishDisabled - set to true to have the publish button as disabled (defaults to true)
 *
 * outputs:
 *
 * @emits editClick - outputs that the edit button is clicked
 * @emits openClick - outputs that the open button is clicked
 * @emits duplicateClick - outputs that the duplicate button is clicked
 * @emits deleteClick - outputs that the delete button is clicked
 * @emits printClick - outputs that the print button is clicked
 * @emits publishClick - outputs that the publish button is clicked
 */
@Component({
  selector: 'oksygen-details-toolbar',
  templateUrl: './details-toolbar.component.html',
  styleUrls: ['./details-toolbar.component.scss']
})
export class DetailsToolbarComponent {
  static readonly DEFAULT_EDIT_TOOLTIP = t('Edit');
  static readonly DEFAULT_OPEN_TOOLTIP = t('Open');
  static readonly DEFAULT_DUPLICATE_TOOLTIP = t('Duplicate');
  static readonly DEFAULT_DELETE_TOOLTIP = t('Delete');
  static readonly DEFAULT_PRINT_TOOLTIP = t('Print');
  static readonly DEFAULT_PUBLISH_TOOLTIP = t('Publish');

  @Input() editShow = true;
  @Input() duplicateShow = false;
  @Input() openShow = true;
  @Input() deleteShow = true;
  @Input() publishShow = false;

  @Input() editDisabled = true;
  @Input() openDisabled = true;
  @Input() duplicateDisabled = true;
  @Input() deleteDisabled = true;
  @Input() printDisabled = true;
  @Input() publishDisabled = true;

  @Input() editTooltip: string = DetailsToolbarComponent.DEFAULT_EDIT_TOOLTIP;
  @Input() openTooltip: string = DetailsToolbarComponent.DEFAULT_OPEN_TOOLTIP;
  @Input() duplicateTooltip: string = DetailsToolbarComponent.DEFAULT_DUPLICATE_TOOLTIP;
  @Input() deleteTooltip: string = DetailsToolbarComponent.DEFAULT_DELETE_TOOLTIP;
  @Input() printTooltip: string = DetailsToolbarComponent.DEFAULT_PRINT_TOOLTIP;
  @Input() publishTooltip: string = DetailsToolbarComponent.DEFAULT_PUBLISH_TOOLTIP;

  @Output() readonly editClick = new EventEmitter<void>();
  @Output() readonly openClick = new EventEmitter<void>();
  @Output() readonly duplicateClick = new EventEmitter<void>();
  @Output() readonly deleteClick = new EventEmitter<void>();
  @Output() readonly printClick = new EventEmitter<void>();
  @Output() readonly publishClick = new EventEmitter<void>();

  constructor() {}
}
