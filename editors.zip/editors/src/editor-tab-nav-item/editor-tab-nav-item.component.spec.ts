/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { EditorTabNavItemComponent } from './editor-tab-nav-item.component';

describe('EditorTabNavItemComponent', () => {
  let component: EditorTabNavItemComponent<any>;
  let fixture: ComponentFixture<EditorTabNavItemComponent<any>>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [EditorTabNavItemComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditorTabNavItemComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('data', {
      name: 'Test',
      routerLink: '/test',
      icon: 'exclamation_triangle'
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
