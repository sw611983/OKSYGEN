/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, input } from '@angular/core';

import { SideNavTabItemComponent } from '@oksygen-common-libraries/material/components';

import { EditorDataTab } from '../models/editor-data.model';

@Component({
  selector: 'oksygen-editor-tab-nav-item',
  templateUrl: './editor-tab-nav-item.component.html',
  styleUrls: ['./editor-tab-nav-item.component.scss']
})
export class EditorTabNavItemComponent<T extends EditorDataTab> implements SideNavTabItemComponent<T> {
  public readonly data = input<T>();

  constructor() { }
}
