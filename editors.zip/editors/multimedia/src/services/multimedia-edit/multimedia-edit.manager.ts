/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { cloneDeep } from 'lodash';
import { Observable, of, Subscription } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';

import { createHistoryRecord, generateUuid, HISTORY_TYPE_CREATED, SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { OK_BUTTON, PromptDialogComponent, PromptDialogData, TabService } from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';
import { MultimediaResponse } from '@oksygen-sim-core-libraries/components-services/lms';
import {
  MultimediaDataItem,
  MultimediaDataService,
  MultimediaLmsScormActivityItem
} from '@oksygen-sim-core-libraries/components-services/multimedia';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { ConfirmResult, uniqueItemName, unsavedChangesDialog } from '@oksygen-sim-train-libraries/components-services/common';
import { DEFAULT_MULTIMEDIA_NAME } from '@oksygen-sim-train-libraries/components-services/multimedia';

import { MULTIMEDIA_CARD_DATA } from '../../models/multimedia-editor-tab.model';

export type MultimediaEditorMode = 'new' | 'edit' | 'detail';

export class MultimediaEditManager {
  private originalMultimedia: MultimediaDataItem;
  multimedia: MultimediaDataItem;
  saveButtonDisabled = false;
  mode: string;

  private file: File;

  private readonly subscription = new Subscription();

  private unsavedChanges = false;

  constructor(
    public id: string,
    private authService: AuthService,
    private multimediaDataService: MultimediaDataService,
    private dialog: MatDialog,
    private translateService: TranslateService,
    private tabService: TabService,
    private snackbar: MatSnackBar,
    private readonly zone: NgZone
  ) {}

  destroy(): void {
    this.subscription.unsubscribe();
  }

  public newMultimediaLmsScormActivity(name: string): void {
    this.originalMultimedia = null;
    this.multimedia = this.createNewMultimedia(this.id, name);
  }

  public loadMultimedia(multimedia: MultimediaDataItem): void {
    this.originalMultimedia = multimedia;
    this.multimedia = multimedia;
  }

  public getMultimedia(): MultimediaDataItem {
    return this.multimedia;
  }

  public setDisplayName(name: string): void {
    name = name ?? '';

    if (this.multimedia.displayName !== name) {
      this.unsavedChanges = true;
      this.multimedia.displayName = name;

      const tab = this.tabService.getTabGroupItem(MULTIMEDIA_CARD_DATA.id, this.id);

      if (!!tab && tab.data.name !== name) {
        tab.data.name = name;
      }
    }
  }

  public setDescription(description: string): void {
    description = description ?? '';

    if (this.multimedia.description !== description) {
      this.unsavedChanges = true;
      this.multimedia.description = description;
    }
  }

  public setFile(file: File): void {
    if (file == null) {
      this.unsavedChanges = true;
      this.file = null;
    } else if (this.file == null || this.file.name !== file.name || this.file.size !== file.size) {
      this.unsavedChanges = true;
      this.file = file;
    }
  }

  public confirmCloseEditor(): Observable<boolean> {
    if (!this.unsavedChanges) {
      return of(true);
    } else {
      return unsavedChangesDialog(this.multimedia.displayName, this.translateService, this.dialog).pipe(
        switchMap(dialogResult => {
          switch (dialogResult) {
            case ConfirmResult.SAVE:
              return this.doSaveMultimedia(this.multimedia).pipe(
                map(response => response.success),
                tap(ok => {
                  this.saveButtonDisabled = false;
                  if (ok) {
                    this.multimediaDataService.reloadData();
                  }
                })
              );
            case ConfirmResult.NO_SAVE:
              return of(true);
            default:
              return of(false);
          }
        })
      );
    }
  }

  public saveAsMultimedia(allMultimedia: MultimediaDataItem[]): void {
    if (this.multimedia instanceof MultimediaLmsScormActivityItem) {
      const displayName = uniqueItemName(allMultimedia, (item: MultimediaDataItem) => item.displayName, DEFAULT_MULTIMEDIA_NAME, this.multimedia.displayName);

      const multimedia = this.createNewMultimedia(generateUuid(), displayName, this.multimedia.scormReference);

      this.saveMultimedia(multimedia, null);
    }
  }

  private createNewMultimedia(id: string, name: string, scormReference: string = null): MultimediaDataItem {
    const currentUser = this.authService.getLoggedInUser();
    this.mode = 'new';
    return new MultimediaLmsScormActivityItem({
      id,
      displayName: name,
      history: [createHistoryRecord(HISTORY_TYPE_CREATED, currentUser)],
      description: '',
      scormReference,
      version: 1
    });
  }

  public saveMultimedia(multimedia = this.multimedia, originalMultimedia = this.originalMultimedia): void {
    const sub = this.doSaveMultimedia(multimedia, originalMultimedia).subscribe(response => {
      this.saveButtonDisabled = false;
      this.multimediaDataService.reloadData();

      if (response.success) {
        this.zone.run(() => {
          // snackbar needs to run in zone
          this.snackbar.open(this.translateService.instant(t('Multimedia saved')), '', { duration: 3000 });
        });
      } else {
        const promptData = new PromptDialogData();
        promptData.title = t('Could not save Multimedia');

        const content: string[] = [];

        if (!!response.errors && response.errors.length > 0) {
          content.push(...response.errors);

          // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
          content.push(t('Please correct and try again, or contact an adminstrator.'));
        } else {
          // If this line doesn't make you laugh or cry (or both), you're probably a newbie to Sydac's simulators.
          content.push(t('Please contact an administrator.'));
        }

        promptData.content = content;

        promptData.buttons = OK_BUTTON;
        PromptDialogComponent.open(this.dialog, { id: 'SAVE_FAILED', data: promptData });
      }

      sub.unsubscribe();
    });
  }

  public static deleteMultimedia(logger: Logging, multimediaDataService: MultimediaDataService, multimedia: MultimediaDataItem): SelfCompletingObservable<any> {
    let result: Observable<void>;

    if (multimedia instanceof MultimediaLmsScormActivityItem) {
      result = multimediaDataService.deleteLmsScormActivity(multimedia).pipe(
        tap(response => {
          if (!response.success) {
            logger.error('Errors received trying to delete multimedia', multimedia, response.errors);
          }
        }),
        map(r => null)
      );
    } else {
      result = of();
    }

    return result;
  }

  // TODO: Update for versioning.
  private doSaveMultimedia(multimedia: MultimediaDataItem, originalMultimedia?: MultimediaDataItem): SelfCompletingObservable<MultimediaResponse> {
    this.saveButtonDisabled = true;

    let result: Observable<any>;

    if (multimedia instanceof MultimediaLmsScormActivityItem) {
      const updatedMultimedia = cloneDeep(multimedia);
      if (this.file) {
        updatedMultimedia.scormReference = this.file.name;
      }

      if (originalMultimedia) {
        updatedMultimedia.version += 1;

        result = this.multimediaDataService.updateLmsScormActivity(updatedMultimedia, this.authService.getLoggedInUser(), this.file).pipe(
          tap(v => {
            if (v) {
              this.unsavedChanges = false;
            }
          })
        );
      } else {
        result = this.multimediaDataService.addLmsScormActivity(updatedMultimedia, this.authService.getLoggedInUser(), this.file).pipe(
          tap(v => {
            if (v) {
              this.unsavedChanges = false;
            }
          })
        );
      }
    } else {
      result = of<MultimediaResponse>({ success: true });
    }

    return result;
  }
}
