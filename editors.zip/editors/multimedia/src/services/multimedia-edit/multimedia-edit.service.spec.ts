/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainMultimediaEditModule } from '../../multimedia-edit.module';
import { MultimediaEditService } from './multimedia-edit.service';

describe('MultimediaEditService', () => {
  let service: MultimediaEditService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainMultimediaEditModule]
    });
    service = TestBed.inject(MultimediaEditService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
