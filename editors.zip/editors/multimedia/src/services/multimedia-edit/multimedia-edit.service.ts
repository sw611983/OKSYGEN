/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { computeIfAbsent, generateUuid, SelfCompletingObservable, shareReplayOne } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { MultimediaDataItem, MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';

import { MultimediaEditManager } from './multimedia-edit.manager';
import { TabService } from '@oksygen-common-libraries/material/components';

@Injectable()
export class MultimediaEditService implements OnDestroy {
  private editManagers: Map<string, MultimediaEditManager> = new Map();

  private subscription = new Subscription();

  private editorsActiveSubject = new BehaviorSubject<number>(0);

  constructor(
    private authService: AuthService,
    private logger: Logging,
    private multimediaDataService: MultimediaDataService,
    private dialog: MatDialog,
    private translateService: TranslateService,
    private tabService: TabService,
    private snackbar: MatSnackBar,
    private readonly zone: NgZone
  ) {
  }

  ngOnDestroy(): void {
    this.editManagers.forEach(value => value.destroy());
    this.editManagers.clear();

    this.subscription.unsubscribe();
    this.editorsActiveSubject.complete();
  }

  /** Get the specified manager. Creates it if it does not already exist. */
  getEditManager(id: string): MultimediaEditManager {
    return computeIfAbsent(this.editManagers, id, i => {
      this.editorsActiveSubject.next(this.editManagers.size + 1); // add one for this new manager

      return new MultimediaEditManager(
        id,
        this.authService,
        this.multimediaDataService,
        this.dialog,
        this.translateService,
        this.tabService,
        this.snackbar,
        this.zone
      );
    });
  }

  public newMultimediaLmsScormActivity(name: string): Promise<string> {
    return new Promise(resolve => {
      const id = generateUuid();

      const manager = this.getEditManager(id);
      manager.newMultimediaLmsScormActivity(name);
      resolve(id);
    });
  }

  public loadMultimedia(multimedia: MultimediaDataItem): void {
    const manager = this.getEditManager(multimedia.id);

    manager.loadMultimedia(multimedia);
  }

  public deleteMultimedia(multimedia: MultimediaDataItem): SelfCompletingObservable<any> {
    return MultimediaEditManager.deleteMultimedia(this.logger, this.multimediaDataService, multimedia);
  }

  public confirmCloseEditor(id: string): Observable<boolean> {
    const manager = this.getEditManager(id);

    return manager.confirmCloseEditor();
  }

  getActiveEditorCount(): number {
    return this.editorsActiveSubject.getValue();
  }

  get activeEditors$(): Observable<number> {
    return this.editorsActiveSubject.pipe(shareReplayOne());
  }

  /** Destroy a manager (and recursively all it's data). */
  destroyManagers(id: string): void {
    const editManager = this.editManagers.get(id);

    if (editManager) {
      editManager.destroy();
    }

    this.editManagers.delete(id);

    if (this.editManagers.size !== this.editorsActiveSubject.getValue()) {
      this.editorsActiveSubject.next(this.editManagers.size);
    }
  }
}
