/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { shareReplayOne } from '@oksygen-common-libraries/common';
import { MultimediaDataItem } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { AbstractBrowserService } from '@oksygen-sim-train-libraries/components-services/editors';

/**
 * Holds the state of the scenario browser screen.
 */
@Injectable()
export class MultimediaBrowserService extends AbstractBrowserService {
  private selectedMultimedia = new BehaviorSubject<MultimediaDataItem>(null);
  private searchText = new BehaviorSubject<string>('');

  constructor() {
    super('MultimediaBrowserService');
  }

  /**
   * This is called when the page is first opened
   */
  public override initialiseEditing(): void {
    super.initialiseEditing();
  }

  public setSelectedMultimedia(multimedia: MultimediaDataItem): void {
    this.selectedMultimedia.next(multimedia);
  }

  public getSelectedMultimedia$(): Observable<MultimediaDataItem> {
    return this.selectedMultimedia.pipe(shareReplayOne());
  }

  public setSearchText(text: string): void {
    this.searchText.next(text);
  }

  public getSearchText$(): Observable<string> {
    return this.searchText.pipe(shareReplayOne());
  }
}
