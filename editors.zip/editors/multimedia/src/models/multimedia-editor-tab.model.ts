/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { BasicTabNavItem, TabGroupChild } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { MULTIMEDIA } from '@oksygen-sim-train-libraries/components-services/common';
import { EditorData } from '@oksygen-sim-train-libraries/components-services/editors';

export const MULTIMEDIA_CARD_DATA = new EditorData(MULTIMEDIA, '/editors/multimedia', OksygenIcon.MULTIMEDIA, 'multimedia');

export type MultimediaTabType = TabGroupChild<BasicTabNavItem>;
