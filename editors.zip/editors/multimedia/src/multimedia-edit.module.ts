/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule, RouteConfig, RoutingPage } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimCoreMultimediaModule } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { OksygenSimTrainMultimediaModule } from '@oksygen-sim-train-libraries/components-services/multimedia';

import { MultimediaBrowserComponent } from './browser/multimedia-browser.component';
import { MultimediaEditorComponent } from './editor/multimedia-editor.component';
import {
  MultimediaPanelMultimediaEditorComponent
} from './multimedia-panel/multimedia-panel-multimedia-editor/multimedia-panel-multimedia-editor.component';
import { MultimediaPanelComponent } from './multimedia-panel/multimedia-panel.component';
import { MultimediaBrowserService } from './services/multimedia-browser.service';
import { MultimediaEditService } from './services/multimedia-edit/multimedia-edit.service';

export const multimediaBrowserPage: RoutingPage = {
  path: 'multimedia',
  component: MultimediaBrowserComponent
};

export function multimediaBrowserRoute<T>(config?: RouteConfig<T>): Route {
  const auth = config?.auth ?? [];
  return { path: multimediaBrowserPage.path, component: multimediaBrowserPage.component, canActivate: auth };
}

const components = [
  MultimediaBrowserComponent,
  MultimediaEditorComponent,
  MultimediaPanelComponent,
  MultimediaPanelMultimediaEditorComponent
];

@NgModule({
  declarations: components,
  imports: [
    RouterModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DragDropModule,
    OksygenMaterialComponentsModule,
    OksygenSimCoreCommonModule,
    OksygenSimCoreMultimediaModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenMaterialTranslateModule.forChild(),
    OksygenSimTrainCommonModule,
    OksygenSimTrainEditorsModule,
    OksygenSimTrainMultimediaModule
  ],
  exports: components,
  providers: [ MultimediaEditService, MultimediaBrowserService ]
})
export class OksygenSimTrainMultimediaEditModule { }
