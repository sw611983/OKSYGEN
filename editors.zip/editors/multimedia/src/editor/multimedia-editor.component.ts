/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import { shareReplayOne } from '@oksygen-common-libraries/common';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { MultimediaDataItem } from '@oksygen-sim-core-libraries/components-services/multimedia';

import { MultimediaEditManager, MultimediaEditorMode } from '../services/multimedia-edit/multimedia-edit.manager';
import { MultimediaEditService } from '../services/multimedia-edit/multimedia-edit.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { multimediaDataItemToSummaryData, MultimediaSummaryData } from '@oksygen-sim-train-libraries/components-services/multimedia';

export interface MultimediaEditorDialogData {
  mode: MultimediaEditorMode;
  id: string;
}

export enum MultimediaEditorResult {
  CANCEL,
  IMPORT,
  COPY
}

@Component({
  templateUrl: './multimedia-editor.component.html',
  styleUrls: ['./multimedia-editor.component.scss']
})
export class MultimediaEditorComponent implements OnInit, OnDestroy {
  saveDisabled = false;

  private multimediaSubject = new BehaviorSubject<MultimediaDataItem>(null);

  multimedia$ = this.multimediaSubject.pipe(shareReplayOne());
  summaryData: MultimediaSummaryData;
  multimediaEditManager: MultimediaEditManager;
  alreadyExists = false;
  dialogData: MultimediaEditorDialogData;

  loaded = false;

  constructor(
    public dialogRef: MatDialogRef<MultimediaEditorComponent, MultimediaEditorResult>,
    @Inject(MAT_DIALOG_DATA) public data: MultimediaEditorDialogData,
    private multimediaEditService: MultimediaEditService,
    private userService: UserService
  ) {
    this.dialogData = data;
  }

  ngOnInit(): void {
    this.multimediaEditManager = this.multimediaEditService.getEditManager(this.data.id);

    const multimedia = this.multimediaEditManager.getMultimedia();
    this.multimediaSubject.next(multimedia);
    this.summaryData = multimediaDataItemToSummaryData(this.userService, multimedia);
    // If there's no scorm reference it means that the object is not yet saved since it is required
    this.alreadyExists = !!this.summaryData?.scorm;

    this.loaded = true;
  }

  ngOnDestroy(): void {
    this.multimediaSubject.complete();
  }

  onCancelClick(): void {
    this.dialogRef.close(MultimediaEditorResult.CANCEL);
  }

  onImportClick(): void {
    this.dialogRef.close(MultimediaEditorResult.IMPORT);
  }

  onCopyClick(): void {
    this.dialogRef.close(MultimediaEditorResult.COPY);
  }

  disableSave(disabled: boolean): void {
    this.saveDisabled = disabled;
  }
}
