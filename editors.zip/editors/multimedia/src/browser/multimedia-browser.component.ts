/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, Observable, of, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { Author, SuperCalled } from '@oksygen-common-libraries/common';
import {
  allFilterTypesMatch,
  AutocompleteInputType,
  BasicTabNavItemComponent,
  Breadcrumb,
  CANCEL_BUTTON,
  FileManagerTableComponent,
  FileManagerTableData,
  Filter,
  filterMatches,
  PromptDialogComponent,
  PromptDialogData,
  SelectedFilterArray,
  SideNavService,
  TabService
} from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { Logging } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { MultimediaDataItem, MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import {
  BrowserFilterText,
  BrowserState,
  EditorBrowserFilterIOConfig,
  uniqueItemName
} from '@oksygen-sim-train-libraries/components-services/common';
import { BaseBrowserTabPage } from '@oksygen-sim-train-libraries/components-services/editors';
import {
  DEFAULT_MULTIMEDIA_NAME,
  FILE_NOT_FOUND,
  multimediaDataItemToSummaryData,
  MultimediaSummaryData
} from '@oksygen-sim-train-libraries/components-services/multimedia';
import { ScenarioSummaryData } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { MultimediaEditorComponent, MultimediaEditorDialogData, MultimediaEditorResult } from '../editor/multimedia-editor.component';
import { MULTIMEDIA_CARD_DATA, MultimediaTabType } from '../models/multimedia-editor-tab.model';
import { MultimediaBrowserService } from '../services/multimedia-browser.service';
import { MultimediaEditService } from '../services/multimedia-edit/multimedia-edit.service';

enum FilterType {
  // These names are used to select the icon on chips of that type
  MULTIMEDIA = 'multimedia',
  SCORM_PACKAGE = 'scorm_package',
  AUTHOR = 'author'
}

interface MultimediaFilterFields extends BrowserFilterText {
  authorText: string;
  multimediaText: string;
  scormPackageText: string;
}

export function deleteMultimediaPromptDialogData(multimediaName: string[]): PromptDialogData {
  const promptData = new PromptDialogData();

  // FIXME More meaningful message please
  promptData.title = multimediaName.length > 1 ?
    t('Are you sure you want to delete these multimedias?') : t('Are you sure you want to delete this multimedia?');
  promptData.content = multimediaName.length > 1 ? multimediaName : `<b>${multimediaName}</b>`;
  promptData.buttons = promptData.buttons = [
    {
      color: 'warn',
      text: t('Delete'),
      data: true
    },
    CANCEL_BUTTON
  ];
  return promptData;
}

@Component({
  templateUrl: './multimedia-browser.component.html',
  styleUrls: ['./multimedia-browser.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MultimediaBrowserComponent
  extends BaseBrowserTabPage<MultimediaDataItem, MultimediaSummaryData, MultimediaFilterFields, string>
  implements OnInit, OnDestroy
{
  readonly FILE_NOT_FOUND = FILE_NOT_FOUND;
  readonly BREADCRUMB: Breadcrumb = {
    text: t('Multimedia'),
    icon: 'multimedia'
  };

  selectedMultimedia: MultimediaDataItem;
  selectedMultimedia$ = new BehaviorSubject<MultimediaDataItem>(null);

  isBusy = false;

  @ViewChild(FileManagerTableComponent) fileManagerTable: FileManagerTableComponent<MultimediaSummaryData>;

  autoCompleteType = AutocompleteInputType.FORM_FIELD;

  authors: Author[] = [];
  missingScormCount = 0;

  private multimediaSubscription: Subscription;
  private trackSubscription: Subscription;
  private selectedMultimediaSubscription: Subscription;
  private masterSubscription = new Subscription();

  constructor(
    public multimediaBrowserService: MultimediaBrowserService,
    private multimediaEditService: MultimediaEditService,
    sideNavService: SideNavService,
    router: Router,
    private userService: UserService,
    private dialog: MatDialog,
    tabService: TabService,
    logger: Logging,
    private multimediaDataService: MultimediaDataService,
    private uiStateModelManager: UiStateModelManager,
    translateService: TranslateService,
    private changeDetectorRef: ChangeDetectorRef
  ) {
    super(
      {
        create: { visible: true, enabled: true },
        delete: { visible: true, enabled: true },
        duplicate: { visible: false, enabled: true },
        edit: { visible: true, enabled: false },
        open: { visible: false, enabled: false },
        search: { visible: true, enabled: true },
        refresh: { visible: true, enabled: true }
      },
      multimediaBrowserService,
      sideNavService,
      router,
      MULTIMEDIA_CARD_DATA,
      tabService,
      logger,
      translateService,
      dialog
    );

    this.refreshDisabled.set(false);
    this.sorter.sortFunction = this.sorterFunction.bind(this);
  }

  override ngOnInit(): SuperCalled {
    const superCalled = super.ngOnInit();

    this.pageOpening();
    this.selectedMultimediaSubscription = this.multimediaBrowserService.getSelectedMultimedia$().subscribe(m => {
      // FIXME This doesn't update what the table shows (and right now  it's not clear to me how to make it do so).
      // On creation the table fires the selection callback with null, killing our attempt to persist the selection :(
      this.selectedMultimedia = m;
    });

    this.multimediaDataService.reloadData(); // force a reload of the scenarios when opening the browser
    this.multimediaSubscription = this.multimediaDataService.data().subscribe(data => this.updateMultimedia(data));

    const multimediaTab: MultimediaTabType = {
      data: {
        id: MULTIMEDIA_CARD_DATA.id,
        groupId: MULTIMEDIA_CARD_DATA.id,
        icon: OksygenIcon.FILE_MANAGER,
        routerLink: MULTIMEDIA_CARD_DATA.routerLink,
        name: t('Manager'),
        destroyGroupOnAllCleared: true,
        preCloseCheck: () => of(true),
        onClose: () => {
          this.tabClosing();
          this.clearFilters();
        }
      },
      component: BasicTabNavItemComponent
    };
    this.tabService.computeIfAbsent({
      config: {
        id: MULTIMEDIA_CARD_DATA.id,
        groupName: MULTIMEDIA_CARD_DATA.name,
        route: MULTIMEDIA_CARD_DATA.routerLink,
        // groupIcon: MULTIMEDIA_CARD_DATA.icon,
        navigateOnGroupClick: false,
        children: new BehaviorSubject([])
      },
      additionalChildren: [multimediaTab],
      childrenIndex: 0
    });
    return superCalled;
  }

  ngOnDestroy(): void {
    this.masterSubscription.unsubscribe();
    this.selectedMultimediaSubscription?.unsubscribe();
    this.multimediaSubscription?.unsubscribe();
    this.trackSubscription?.unsubscribe();
    this.selectedMultimedia$.complete();
    this.pageClosing();
    this.setSelectedTableData();
  }

  sorterFunction(c: string, a: MultimediaSummaryData, b: MultimediaSummaryData): number {
    switch (c) {
      case 'name': {
        return a.name.localeCompare(b.name, this.getCurrentLocale());
      }
      case 'scorm': {
        return a.scorm.localeCompare(b.scorm, this.getCurrentLocale());
      }
      case 'created': {
        return a.created.date.isBefore(b.created.date) ? 1 : -1;
      }
      case 'published': {
        return a.published.date.isBefore(b.published.date) ? 1 : -1;
      }
      case 'status': {
        return a.status.localeCompare(b.status, this.getCurrentLocale());
      }
      default: {
        return 0;
      }
    }
  }

  override updateSort(sort: Sort): void {
    this.fileManagerTable.updateSort(sort);
  }

  displayAuthor(value: Author): string {
    return value?.name;
  }

  addMultimediaFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(FilterType.MULTIMEDIA, value));
    this.fileManagerTable.applyFilter();
  }

  onMultimediaTextChange(text: string): void {
    this.state.filters.multimediaText = text;
    this.fileManagerTable.applyFilter();
  }

  addScormFilter(value: string): void {
    this.state.filters.selectedFilters.push(new Filter(FilterType.SCORM_PACKAGE, value));
    this.fileManagerTable.applyFilter();
  }

  onScormTextChange(text: string): void {
    this.state.filters.scormPackageText = text;
    this.fileManagerTable.applyFilter();
  }

  onAuthorTextChange(text: Author | string): void {
    this.state.filters.authorText = typeof text === 'object' ? `${text.name}` : text;
    this.fileManagerTable.applyFilter();
  }

  addAuthorFilter(value: Author | string): void {
    const name = typeof value === 'object' ? value.name : value;
    this.state.filters.selectedFilters.push(new Filter(FilterType.AUTHOR, name, null));
    this.fileManagerTable.applyFilter();
  }

  override selectionChanged(): void {
    super.selectionChanged();
    this.multimediaBrowserService.setSelectedMultimedia(null);
    if (this.selectedCount() === 1) {
      this.multimediaBrowserService.setSelectedMultimedia(this.data().find(m => m.id === this.selectedTableData().id));
      this.deleteDisabled.set(!!this.selectedTableData().usedByScenario);
    }
  }

  cellClicked(value: ScenarioSummaryData): void {}

  createNew(): void {
    const name = uniqueItemName(this.data, (item: MultimediaDataItem) => item.displayName, DEFAULT_MULTIMEDIA_NAME);

    this.multimediaEditService.newMultimediaLmsScormActivity(name).then(id => {
      const dialog = this.dialog.open<MultimediaEditorComponent, MultimediaEditorDialogData, MultimediaEditorResult>(MultimediaEditorComponent, {
        data: { mode: 'new', id },
        minWidth: '600px',
        disableClose: true
      });
      dialog.afterClosed().subscribe(result => {
        switch (result) {
          case MultimediaEditorResult.IMPORT:
            this.multimediaEditService.getEditManager(id).saveMultimedia();
            break;
          case MultimediaEditorResult.COPY:
            this.multimediaEditService.getEditManager(id).saveAsMultimedia(this.data());
            break;
          default:
            break;
        }
      });
      });
  }

  override editClick(): void {
    this.multimediaEditService.loadMultimedia(this.selectedMultimedia);
    this.startEditing(this.selectedMultimedia.id);
    this.setSelectedTableData();
  }

  private startEditing(id: string): void {
    const dialog = this.dialog.open<MultimediaEditorComponent, MultimediaEditorDialogData, MultimediaEditorResult>(MultimediaEditorComponent, {
      data: { mode: 'edit', id },
      disableClose: true
    });
    dialog.afterClosed().subscribe(result => {
      switch (result) {
        case MultimediaEditorResult.IMPORT:
          this.multimediaEditService.getEditManager(id).saveMultimedia();
          break;
        case MultimediaEditorResult.COPY:
          this.multimediaEditService.getEditManager(id).saveAsMultimedia(this.data());
          break;
        default:
          break;
      }
    });
  }

  override deleteClick(): void {
    const dialogConfig: MatDialogConfig = {
      disableClose: true,
      minHeight: '100px',
      minWidth: '400px',
      panelClass: 'small-whitespace-dialog'
    };

    if (this.selectedMultimedia) {
      dialogConfig.data = deleteMultimediaPromptDialogData([this.selectedMultimedia.displayName]);

      PromptDialogComponent.open(this.dialog, dialogConfig, result => {
        if (result) {
          this.doDeleteMultimedia(this.selectedMultimedia).subscribe(() => {
            this.multimediaDataService.reloadData();
            this.multimediaBrowserService.setSelectedMultimedia(null);
          });
        }
      });
    } else {
      // TODO confirm data action(ConfirmDataActionData) & prompt dialog(PromptDialogData) are very similar and should probably be consolidated in future

      const multimediaNames: string[] = [];
      this.fileManagerTable.getSelectedValues().forEach(multimedia => {
        multimediaNames.push( multimedia.name );
      });

      dialogConfig.data = deleteMultimediaPromptDialogData(multimediaNames);

      PromptDialogComponent.open(this.dialog, dialogConfig, dialogResult => {
        if (dialogResult) {
          this.isBusy = true;
          const selectedMultimedia = this.fileManagerTable.getSelectedValues();
          const totalCount = selectedMultimedia.length;
          let count = 0;

          selectedMultimedia.forEach(async multimediaSummaryData => {
            const multimedia = this.data().find(m => (m.id = multimediaSummaryData.id));
            this.doDeleteMultimedia(multimedia).subscribe(() => {
              count = count + 1;

              if (count === totalCount) {
                this.multimediaDataService.reloadData();
                this.isBusy = false;
              }
            });
          });
        }
      });
    }
    this.setSelectedTableData();
  }

  private destroyManagers(id: string): void {
    this.multimediaEditService.destroyManagers(id);
  }

  private doDeleteMultimedia(multimedia: MultimediaDataItem): Observable<void> {
    return this.multimediaEditService.deleteMultimedia(multimedia).pipe(
      map(() => {
        const id = multimedia.id;

        if (this.tabService.getTabGroupItem(MULTIMEDIA_CARD_DATA.id, id.toString())) {
          this.tabService.removeItemFromTabGroup(MULTIMEDIA_CARD_DATA.id, { id: id.toString() }, true);
          this.destroyManagers(id);
        }
      })
    );
  }

  applyFilters(multimedia: MultimediaSummaryData): boolean {
    const names = [multimedia.name];
    const scorm = [multimedia.scorm];
    const authors = [multimedia.created?.name, multimedia.lastModified?.name];

    if (
      !allFilterTypesMatch(
        [
          { t: FilterType.MULTIMEDIA, v: multimedia.name },
          { t: FilterType.SCORM_PACKAGE, v: multimedia.scorm },
          { t: FilterType.AUTHOR, v: authors }
        ],
        this.state.filters.selectedFilters
      )
    ) {
      return false;
    }

    if (!filterMatches(names, this.state.filters.multimediaText)) {
      return false;
    }

    if (!filterMatches(scorm, this.state.filters.scormPackageText)) {
      return false;
    }
    if (!filterMatches(authors, this.state.filters.authorText)) {
      return false;
    }

    return true;
  }

  private updateMultimedia(data: MultimediaDataItem[]): void {
    this.isBusy = true;
    this.missingScormCount = 0;
    this.data.set([]);
    if (!data) {
      return;
    }
    this.data.set([...data]);
    this.authors = [];

    this.tableData().forEach(multimediaSummaryData => {
      if (multimediaSummaryData) {
        const createdAuthor: Author = {
          avatar: multimediaSummaryData.created.avatar,
          name: multimediaSummaryData.created.name
        };

        const modifiedAuthor: Author = {
          avatar: multimediaSummaryData.lastModified.avatar,
          name: multimediaSummaryData.lastModified.name
        };

        if (!this.authors.find(a => a.name === createdAuthor.name)) {
          this.authors.push(createdAuthor);
        }

        if (!this.authors.find(a => a.name === modifiedAuthor.name)) {
          this.authors.push(modifiedAuthor);
        }
      }
    });

    this.isBusy = false;
    this.changeDetectorRef.markForCheck();
  }


  onImport(): void {
    this.logger.log('import');
    // TODO: Implement
  }

  onExport(): void {
    this.logger.log('export');
    // TODO: Implement
  }

  onEdit(item: MultimediaDataItem): void {
    this.editClick();
  }

  onDelete(item: MultimediaDataItem | MultimediaDataItem[]): void {
    this.deleteClick();
  }

  onPrint(item: MultimediaDataItem | MultimediaDataItem[]): void {
    this.logger.log('print');
  }

  onDuplicate(item: MultimediaDataItem): void {
    this.logger.log('duplicate');
  }

  onCreate(): void {
    this.createNew();
  }

  onRefresh(): void {
    this.multimediaDataService.reloadData();
  }

  onUnlock(): void {
    this.logger.log('unlock');
  }

  editorName(): string {
    return 'multimedia';
  }

  protected initialiseState(): BrowserState<MultimediaFilterFields, string> {
    return this.uiStateModelManager.getStateModel<any>('MultimediaBrowserComponent', () => ({
      filters: {
        authorText: '',
        multimediaText: '',
        scormPackageText: '',
        selectedFilters: new SelectedFilterArray<FilterType>()
      }
    }));
  }
  protected initialiseFilterConfig(): EditorBrowserFilterIOConfig<MultimediaDataItem>[] {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;
    const multimediaFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: 'multimedia',
        placeholder: 'Multimedia',
        value: this.state?.filters?.multimediaText
      },
      outputs: {
        currentValue: this.onMultimediaTextChange.bind(self),
        selectedValue: this.addMultimediaFilter.bind(self)
      }
    };
    const scormFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: 'scorm_package',
        placeholder: 'SCORM Package',
        value: this.state?.filters?.scormPackageText
      },
      outputs: {
        currentValue: this.onScormTextChange.bind(self),
        selectedValue: this.addScormFilter.bind(self)
      }
    };
    const authorFilter: EditorBrowserFilterIOConfig<string> = {
      inputs: {
        icon: 'scorm_package',
        placeholder: 'Author',
        value: this.state?.filters?.authorText
      },
      outputs: {
        currentValue: this.onAuthorTextChange.bind(self),
        selectedValue: this.addAuthorFilter.bind(self)
      }
    };
    const filterConfig: EditorBrowserFilterIOConfig<any>[] = [multimediaFilter, scormFilter, authorFilter];
    return filterConfig;
  }

  protected initialiseColumns(): FileManagerTableData[] {
    const columns: FileManagerTableData[] = [];
    return columns;
  }

  protected initialiseDisplayedColumns(): string[] {
    const displayedColumns: string[] = ['name', 'scorm', 'created', 'published', 'status'];
    return displayedColumns;
  }

  protected toTableData(data: MultimediaDataItem[]): MultimediaSummaryData[] {
    return (
      data?.map(multimedia => {
        if (!multimedia.inLms) {
          this.missingScormCount++;
        }
        const multimediaSummaryData = multimediaDataItemToSummaryData(this.userService, multimedia);
        const selectedData = this.editorService.getSelectedTableData()?.find(selected => selected?.name === multimedia.displayName);
        multimediaSummaryData.fmtChecked = !!selectedData?.fmtChecked;
        multimediaSummaryData.fmtSelected = !!selectedData?.fmtSelected;
        return multimediaSummaryData;
      }) ?? []
    );
  }

  protected getItemFromTableItem(data: MultimediaSummaryData): MultimediaDataItem {
    if (!data || !this.data) {
      return null;
    }
    return this.data().find(multimedia => multimedia.id === data.id);
  }

  onPublish(item: MultimediaDataItem | MultimediaDataItem[], isActive: boolean): void {
    throw new Error('Method not implemented.');
  }
}
