/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { MultimediaBrowserComponent } from './multimedia-browser.component';
import { OksygenSimTrainMultimediaEditModule } from '../multimedia-edit.module';

describe('MultimediaBrowserComponent', () => {
  let component: MultimediaBrowserComponent;
  let fixture: ComponentFixture<MultimediaBrowserComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainEditorsModule, OksygenSimTrainMultimediaEditModule],
        declarations: [MultimediaBrowserComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MultimediaBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
