/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { MultimediaPanelMultimediaEditorComponent } from './multimedia-panel-multimedia-editor.component';
import { ScenarioEditService } from '@oksygen-sim-train-libraries/components-services/editors/scenarios';

describe('MultimediaPanelMultimediaEditorComponent', () => {
  let component: MultimediaPanelMultimediaEditorComponent;
  let fixture: ComponentFixture<MultimediaPanelMultimediaEditorComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [MultimediaPanelMultimediaEditorComponent],
        providers: [{ provide: ScenarioEditService, useValue: {} }]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MultimediaPanelMultimediaEditorComponent);
    component = fixture.componentInstance;
    component.multimedia$ = of(null);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
