/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, ElementRef, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { AbstractControl, UntypedFormControl, ValidationErrors } from '@angular/forms';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Observable, Subscription } from 'rxjs';

import { filterTruthy, UNKNOWN } from '@oksygen-common-libraries/common';
import {
  AutocompleteInputType,
  errorStateMatcher,
  InputError,
  newFormControl,
  newOptionalFormControl,
  simpleChangesCheck,
  UpdateOn,
  validateUniqueString
} from '@oksygen-common-libraries/material/components';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { ZERO_MAX_UPLOAD_SIZE } from '@oksygen-sim-core-libraries/components-services/lms';
import {
  MultimediaDataItem,
  MultimediaDataService,
  MultimediaLmsScormActivityItem
} from '@oksygen-sim-core-libraries/components-services/multimedia';
import {
  FILE_NOT_FOUND,
  multimediaDataItemToSummaryData,
  MultimediaSummaryData
} from '@oksygen-sim-train-libraries/components-services/multimedia';

import { MultimediaEditManager, MultimediaEditorMode } from '../../services/multimedia-edit/multimedia-edit.manager';

@Component({
  selector: 'oksygen-multimedia-panel-multimedia-editor',
  templateUrl: './multimedia-panel-multimedia-editor.component.html',
  styleUrls: ['./multimedia-panel-multimedia-editor.component.scss']
})
export class MultimediaPanelMultimediaEditorComponent implements OnInit, OnChanges, OnDestroy {
  readonly UNKNOWN = UNKNOWN;

  @Input() multimedia$!: Observable<MultimediaDataItem>;
  @Input() summaryData: MultimediaSummaryData = null;
  @Input() data: MultimediaEditorMode = 'new';
  @Input() edit = false;
  @Input() toolbox = false;
  @Input() showProtected = false;
  @Input() details = false;
  @Input() multimediaEditManager: MultimediaEditManager;
  @Input() displayHeader = true;

  @Output() readonly disableSave = new EventEmitter<boolean>();

  @ViewChild('fileUpload') fileUploadRef: ElementRef<HTMLInputElement>;

  readonly FILE_SIZE_ERROR = t('File exceeds maximum size ({sizeStr})');
  readonly FILE_NEEDED = t('File needed');
  nameControl: UntypedFormControl;
  scormControl: UntypedFormControl;
  scormInputControl: UntypedFormControl;
  descriptionControl: UntypedFormControl;
  existingScormReferences: Array<string> = [];
  scormControlErrors: InputError[] = [{ type: 'missing', text: t('A multimedia is required.') }];

  multimedia: MultimediaDataItem;
  deleteDisabled: boolean;
  scormTooltip: string;
  scormHint: string;
  alreadyExists = false;

  matcher = errorStateMatcher;

  autocompleteInputType = AutocompleteInputType.FORM_FIELD;

  private subscription = new Subscription();
  private editSubscription = new Subscription();
  private multimediaSubscription = Subscription.EMPTY;

  private existingNames: Array<string> = [];
  private invalidName = false;
  private invalidScorm = false;
  private maxUploadSize = ZERO_MAX_UPLOAD_SIZE;
  private fileSize: number = null;

  // eslint-disable-next-line max-len
  constructor(private multimediaDataService: MultimediaDataService, private userService: UserService, private translateService: TranslateService) {
    this.nameControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;

      if (this.edit && !!this.multimedia) {
        result = validateUniqueString(control.value, this.existingNames, this.multimedia.displayName);

        this.invalidName = result !== null;
        this.doDisableSave();
      }

      return result;
    });

    this.scormControl = newOptionalFormControl();
    this.scormInputControl = newOptionalFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;
      this.scormTooltip = '';
      this.scormHint = null;
      this.alreadyExists = this.existingScormReferences.includes(control.value);

      if (!this.edit && !!this.multimedia && !this.multimedia.inLms) {
        result = { missing: true };
        this.scormTooltip = FILE_NOT_FOUND;
      } else if (this.edit && !!this.multimedia) {
        if (!!control.value && control.value.length > 0) {
          if (
            this.multimedia instanceof MultimediaLmsScormActivityItem &&
            this.alreadyExists &&
            control.value !== this.multimedia.scormReference
          ) {
            result = { exists: true };
          } else if (this.fileSize > this.maxUploadSize.size) {
            result = { fileSize: true };
          } else if (this.alreadyExists) {
            this.scormHint = t('This file already exists in the LMS');
          }
          // If there's no file size or the file does not exist it means you've just written stuff in the field. Obviously, this does not work.
          else if (!this.fileSize && !this.alreadyExists) {
            result = { missing: true };
          } else {
            this.scormHint = t('This file will be added to the LMS repository');
          }
          this.invalidScorm = result !== null;
        } else {
          this.invalidScorm = true;
          result = { missing: true};
          this.scormTooltip = this.FILE_NEEDED;
        }
        this.doDisableSave();
      }
      return result;
    });

    this.descriptionControl = newOptionalFormControl();
  }

  private doDisableSave(): void {
    this.disableSave.emit(this.invalidName || this.invalidScorm);
  }

  ngOnInit(): void {
    this.alreadyExists = !!this.summaryData?.scorm;
    this.subscription.add(
      this.multimediaDataService.data().subscribe(data => {
        if (data) {
          this.existingNames = data.map(value => value.displayName);
        } else {
          this.existingNames = [];
        }
      })
    );
    this.subscription.add(
      this.multimediaDataService.lmsMultimediaItem$().subscribe(items => {
        if (items) {
          this.existingScormReferences = items.map(value => value.name);
        } else {
          this.existingScormReferences = [];
        }
      })
    );
    this.subscription.add(
      this.multimediaDataService.maxUploadSize$().subscribe(maxUploadSize => {
        this.maxUploadSize = maxUploadSize;

        if (this.edit) {
          this.scormControlErrors = this.scormControlErrors.filter(error => error.type !== 'fileSize');
          this.scormControlErrors.push({ type: 'fileSize', text: this.translateService.instant(this.FILE_SIZE_ERROR, this.maxUploadSize) });
        }
      })
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (simpleChangesCheck(changes.edit)) {
      this.updateFormGroup();

      if (this.edit) {
        this.scormControlErrors = [
          { type: 'missing', text: FILE_NOT_FOUND },
          { type: 'need', text: this.FILE_NEEDED},
          { type: 'exists', text: t('This file already exists in the LMS') },
          { type: 'fileSize', text: this.translateService.instant(this.FILE_SIZE_ERROR, this.maxUploadSize) }
        ];
      } else {
        this.scormControlErrors = [];
      }
    }

    if (simpleChangesCheck(changes.multimedia$)) {
      this.multimediaSubscription.unsubscribe();
      this.multimediaSubscription = this.multimedia$.pipe(filterTruthy()).subscribe(m => {
        this.multimedia = m;

        if (!this.summaryData && !!this.multimedia) {
          this.summaryData = multimediaDataItemToSummaryData(this.userService, this.multimedia);
        }

        this.deleteDisabled = this.multimedia.usedByScenario ?? false;

        this.updateFormGroup();
      });
    }

    if (simpleChangesCheck(changes.multimediaEditManager)) {
      this.editSubscription.unsubscribe();
      this.editSubscription = new Subscription();

      this.editSubscription.add(
        this.nameControl.statusChanges.subscribe(() => {
          this.multimediaEditManager.setDisplayName(this.nameControl.value);
        })
      );

      this.editSubscription.add(
        this.descriptionControl.statusChanges.subscribe(() => {
          this.multimediaEditManager.setDescription(this.descriptionControl.value);
        })
      );
    }
  }

  private updateFormGroup(): void {
    if (this.multimedia) {
      this.nameControl.setValue(this.multimedia.displayName);
      this.descriptionControl.setValue(this.multimedia.description);

      if (this.multimedia instanceof MultimediaLmsScormActivityItem) {
        this.scormControl.setValue(this.multimedia.scormReference);
      }
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.multimediaSubscription.unsubscribe();
    this.editSubscription.unsubscribe();
  }

  selectScorm(value: string): void {
    // do this so it doesn't say it's existing, since we're picking from the drop-down
    if (this.multimedia instanceof MultimediaLmsScormActivityItem) {
      this.multimedia.scormReference = value;
      this.scormControl.setValue(value); // force re-validation
    }

    // if we're clearing the value, make sure we clear any set file
    if (!value) {
      this.multimediaEditManager.setFile(null);
      this.fileUploadRef.nativeElement.value = null;
      this.fileSize = null;
    }
  }

  onFileSelected(event: any): void {
    const file: File = event?.target?.files?.length === 1 ? event.target.files[0] : null;
    this.multimediaEditManager.setFile(file);
    this.fileSize = null;

    if (file) {
      this.fileSize = file.size;
      this.scormControl.setValue(file.name);
    }
  }
}
