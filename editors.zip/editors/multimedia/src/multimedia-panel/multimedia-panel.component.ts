/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { shareReplayOne } from '@oksygen-common-libraries/common';
import { MultimediaDataItem, MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { MultimediaItem, MultimediaStatus } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { ScenarioMultimedia } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { DETAILS } from '@oksygen-sim-train-libraries/components-services/common';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DetailsToolbarComponent } from '@oksygen-sim-train-libraries/components-services/editors';
import { MultimediaNameChanged, MultimediaSourceType } from '@oksygen-sim-train-libraries/components-services/multimedia';


@Component({
  selector: 'oksygen-multimedia-panel',
  templateUrl: './multimedia-panel.component.html',
  styleUrls: ['./multimedia-panel.component.scss']
})
export class MultimediaPanelComponent implements OnInit, OnDestroy {
  @Input() multimedia$!: Observable<MultimediaDataItem[] | MultimediaItem[] | ScenarioMultimedia[]>;
  @Input() multimediaSourceType: MultimediaSourceType;
  @Input() uiModels!: UiStateModelManager;
  @Input() searchable: boolean;

  @Output() readonly favourite: EventEmitter<MultimediaItem | ScenarioMultimedia> = new EventEmitter();
  @Output() readonly triggerMultimedia: EventEmitter<MultimediaItem> = new EventEmitter();
  @Output() readonly pauseMultimedia: EventEmitter<MultimediaItem> = new EventEmitter();
  @Output() readonly stopMultimedia: EventEmitter<MultimediaItem> = new EventEmitter();
  @Output() readonly resetMultimedia: EventEmitter<MultimediaItem> = new EventEmitter();
  @Output() readonly deleteMultimedia: EventEmitter<ScenarioMultimedia> = new EventEmitter();
  @Output() readonly nameChange = new EventEmitter<MultimediaNameChanged>();

  deleteTooltip: string = DetailsToolbarComponent.DEFAULT_DELETE_TOOLTIP;

  mediaItems: MultimediaItem[];
  lmsItems: MultimediaDataItem[];
  scenarioItems: ScenarioMultimedia[];

  selected: MultimediaDataItem | MultimediaItem | ScenarioMultimedia = null;

  private selectedDataItemSubject = new BehaviorSubject<MultimediaDataItem>(null);

  selectedDataItem$ = this.selectedDataItemSubject.pipe(shareReplayOne());

  breadcrumbChildren: ReadonlyArray<string>;

  toolbar = false;

  private subscription = new Subscription();

  private multimediaDataItems: MultimediaDataItem[] = [];

  constructor(private multimediaDataService: MultimediaDataService) {}

  ngOnInit(): void {
    this.subscription.add(
      this.multimedia$.subscribe(items => {
        switch (this.multimediaSourceType) {
          case MultimediaSourceType.SCENARIO:
            this.scenarioItems = [...(items as ScenarioMultimedia[])];

            if (this.selected) {
              const selected = this.selected as ScenarioMultimedia;
              // go through and update our selected item, as we might be changing the name
              for (const m of this.scenarioItems) {
                if (m.moodleScormActivity.ruleId === selected.moodleScormActivity.ruleId) {
                  this.selected = m;
                  break;
                }
              }
            }
            break;
          case MultimediaSourceType.LMS:
            this.lmsItems = [...(items as MultimediaDataItem[])];
            break;
          case MultimediaSourceType.SESSION:
            this.mediaItems = [...(items as MultimediaItem[])];

            if (this.mediaItems.some(m => m?.status === MultimediaStatus.PLAYING || m?.status === MultimediaStatus.PAUSED)) {
              this.mediaItems.forEach(m =>
                m?.status === MultimediaStatus.PLAYING || m?.status === MultimediaStatus.PAUSED ? (m.disablePlay = false) : (m.disablePlay = true)
              );
            } else {
              this.mediaItems.forEach(m => (m.disablePlay = false));
            }
            break;
          default:
            // not required for these types
            break;
        }
      })
    );

    this.subscription.add(this.multimediaDataService.data().subscribe(data => (this.multimediaDataItems = data ?? [])));
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.selectedDataItemSubject.complete();
  }

  setFavourite(multimedia?: MultimediaItem | ScenarioMultimedia): void {
    this.favourite.emit(multimedia);
  }

  doTriggerMultimedia(multimedia?: MultimediaItem): void {
    this.triggerMultimedia.emit(multimedia);
  }

  doPauseMultimedia(multimedia?: MultimediaItem): void {
    this.pauseMultimedia.emit(multimedia);
  }

  doStopMultimedia(multimedia?: MultimediaItem): void {
    this.stopMultimedia.emit(multimedia);
  }

  doResetMultimedia(multimedia?: MultimediaItem): void {
    this.resetMultimedia.emit(multimedia);
  }

  setSelected(multimedia?: MultimediaItem | ScenarioMultimedia): void {
    this.selected = multimedia;

    if (this.selected == null) {
      this.selectedDataItemSubject.next(null);
    } else {
      let value: MultimediaDataItem = null;
      switch (this.multimediaSourceType) {
        case MultimediaSourceType.SCENARIO:
          // eslint-disable-next-line no-case-declarations
          const scenarioMultimedia = this.selected as ScenarioMultimedia;

          value = this.multimediaDataItems.find(m => (m.id === scenarioMultimedia.moodleScormActivity.multimediaId));
          break;
        case MultimediaSourceType.LMS:
          value = this.selected as MultimediaDataItem;
          break;
        case MultimediaSourceType.SESSION:
          // eslint-disable-next-line no-case-declarations
          const sessionMultimedia = this.selected as MultimediaItem;

          value = this.multimediaDataItems.find(m => (m.displayName === sessionMultimedia.name));
          break;
        default:
          // not required for these types
          break;
      }

      if (!value) {
        this.selected = null;
        this.selectedDataItemSubject.next(null);
      } else {
        this.selectedDataItemSubject.next(value);
      }
}

    this.updateBreadcrumbs();
  }

  deleteClicked(multimedia?: ScenarioMultimedia): void {
    if (multimedia) {
      this.deleteMultimedia.emit(multimedia);
    }
  }

  nameChanged(change: MultimediaNameChanged): void {
    this.nameChange.emit(change);
  }

  private updateBreadcrumbs(): void {
    if (this.selected) {
      this.breadcrumbChildren = [DETAILS];
    } else {
      this.breadcrumbChildren = null;
    }
  }
}
