/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { MultimediaPanelComponent } from './multimedia-panel.component';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import {
  MultimediaDataListComponent, MultimediaDataListItemComponent, MultimediaListComponent, MultimediaListItemComponent,
  ScenarioMultimediaListComponent, ScenarioMultimediaListItemComponent
} from '@oksygen-sim-train-libraries/components-services/multimedia';

describe('MultimediaPanelComponent', () => {
  let component: MultimediaPanelComponent;
  let fixture: ComponentFixture<MultimediaPanelComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [
          MultimediaPanelComponent,
          MultimediaDataListComponent,
          MultimediaDataListItemComponent,
          MultimediaListComponent,
          MultimediaListItemComponent,
          ScenarioMultimediaListComponent,
          ScenarioMultimediaListItemComponent
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MultimediaPanelComponent);
    component = fixture.componentInstance;
    component.multimedia$ = new Observable<any[]>(sub => sub.next([]));
    component.uiModels = new UiStateModelManager();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
