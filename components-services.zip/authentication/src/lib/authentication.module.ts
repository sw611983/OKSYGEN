/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { OverlayModule } from '@angular/cdk/overlay';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AngularSplitModule } from 'angular-split';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';

import { AuthenticationComponent } from './components/authentication/authentication.component';
import { AuthService } from './services/auth.service';
import { registrySchemaProvider } from '@oksygen-common-libraries/pio/registry';
import { authConfigSchema, loginConfigSchema } from './models/login-config.model';

const components = [AuthenticationComponent];

const importExportModules = [
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  NgxMatDatetimePickerModule,
  NgxMatMomentModule,
  RouterModule,
  OksygenMaterialComponentsModule,
  AngularSplitModule,
  DragDropModule,
  ScrollingModule,
  OverlayModule
];

@NgModule({
  declarations: components,
  imports: [...importExportModules, OksygenMaterialTranslateModule.forChild()],
  exports: [...components, ...importExportModules, OksygenMaterialTranslateModule],
  providers: [AuthService, registrySchemaProvider(loginConfigSchema), registrySchemaProvider(authConfigSchema)]
})
export class OksygenSimTrainAuthenticationModule {}
