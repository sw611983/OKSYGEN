/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';

export interface LoginConfig {
  usernameRequired?: boolean;
  passwordRequired?: boolean;
}

export const DEFAULT_LOGIN_CONFIG: LoginConfig = {
  usernameRequired: false,
  passwordRequired: false
};

export const loginConfigSchema: Record<string, any> = {
  $id: 'oksygen-login-config',
  type: 'object',
  properties: {
    login: {
      type: 'object',
      properties: {
        swapImages: {
          type: 'object',
          properties: {
            enabled: { type: 'boolean' },
            interval: { type: 'number' }
          }
        },
        config: {
          type: 'object',
          properties: {
            usernameRequired: { type: 'boolean' },
            passwordRequired: { type: 'boolean' }
          }
        }
      }
    }
  }
};

export const authConfigSchema: Record<string, any> = {
  $id: 'oksygen-auth-config',
  type: 'object',
  properties: {
    auth: {
      type: 'object',
      properties: {
        config: {
          type: 'object',
          properties: {
            maxAttempts: { type: 'number' }
          }
        }
      }
    }
  }
};

export function checkLoginConfig(config: LoginConfig): LoginConfig {
  if (isNil(config.usernameRequired)) {
    config.usernameRequired = DEFAULT_LOGIN_CONFIG.usernameRequired;
  }

  if (isNil(config.passwordRequired)) {
    config.passwordRequired = DEFAULT_LOGIN_CONFIG.passwordRequired;
  }

  return config;
}
