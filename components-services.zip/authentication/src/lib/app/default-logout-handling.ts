/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { PromptDialogComponent, PromptDialogData } from '@oksygen-common-libraries/material/components';
import { MaterialButtonVariant, MaterialThemePalette } from '@oksygen-common-libraries/material/theme';

import { AuthService } from '../services/auth.service';

export function defaultLogout(dialog: MatDialog, authService: AuthService, onLogout: () => void = (): void => {}): void {
  const promptData = new PromptDialogData();
  promptData.title = t('Logout');
  promptData.content = t('Are you sure you want to logout?');
  promptData.buttons = [
    {
      color: MaterialThemePalette.PRIMARY,
      text: t('Keep me logged in'),
      data: false
    },
    {
      color: MaterialThemePalette.PRIMARY,
      style: MaterialButtonVariant.BUTTON,
      text: t('Logout'),
      data: true
    }
  ];

  const dialogRef = dialog.open(PromptDialogComponent, {
    data: promptData,
    width: '400px',
    panelClass: 'small-whitespace-dialog'
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result) {
      authService.logout();
      onLogout();
    }
  });
}
