/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { isNil, merge } from 'lodash';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { asArray, SelfCompletingObservable, shareReplayOne } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { AuthenticationService } from '@oksygen-sim-core-libraries/components-services/authentication';
import { Permission } from '@oksygen-sim-core-libraries/components-services/permissions';
import { User, UserService } from '@oksygen-sim-core-libraries/components-services/users';

export enum LoginResult {
  SUCCESS,
  FAIL,
  NO_PERSMISSION,
  TOO_MANY_ATTEMPTS,
  NOT_ACTIVE
}

/**
 * This is a wrapper for the main AuthenticationService.
 * It should be used instead of AuthenticationService directly
 * as it also keeps track of if the user is logged in, how many attempts can be made, etc
 *
 * Also to note, current implementation has max attempts for any user, not for just a particular user
 * And this information is stored insecurely in the localStorage, rather than server side
 * This is not necessarily the best practice going forwards, but is a stepping stone towards a better solution.
 */
@Injectable()
export class AuthService {
  private loggedInUser: User | null = null;

  private loggedInSubject = new BehaviorSubject<boolean>(false);
  private loggedIn$ = this.loggedInSubject.asObservable().pipe(shareReplayOne());

  private authConfig = { maxAttempts: 5 };

  constructor(
    private readonly authenticationService: AuthenticationService,
    private readonly logging: Logging,
    private readonly registry: Registry,
    private readonly userService: UserService
  ) {
    this.authConfig = this.registry.getObject(['auth', 'config'], { maxAttempts: 5 });
  }

  public isLoggedIn(): boolean {
    return !isNil(this.loggedInUser);
  }

  /**
   * Should really only be used by the app component and the authentication guard
   * Anything else shouldn't be loaded until we are logged in
   */
  public isLoggedIn$(): Observable<boolean> {
    return this.loggedIn$;
  }

  public getLoggedInUser(): User {
    return this.loggedInUser;
  }

  /**
   * Returns true of the logged in user has the passed permission
   *
   * @param permission - permission to check
   */
  public loggedInUserHasPermission(permission: Permission): boolean {
    return this.isLoggedIn() && !isNil(asArray(this.loggedInUser.permissions).find(perm => perm.id === permission.id));
  }

  /**
   * Returns true of the logged in user has any one of the passed permissions
   *
   * @param permissions - permissions to check
   */
  public loggedInUserHasAnyPermission(...permissions: Permission[]): boolean {
    let result = false;

    for (const permission of permissions) {
      result = this.loggedInUserHasPermission(permission);

      if (result) {
        break;
      }
    }

    return result;
  }

  public getLoginAttempts(): number {
    let value = localStorage.getItem('auth.loginAttempts');

    if (!value) {
      value = '0';
    }

    return parseInt(value, 10);
  }

  public getLoginMaxAttempts(): number {
    return this.authConfig.maxAttempts;
  }

  /**
   * This should return a self-completing Observable
   *
   * @param username User name
   * @param password Password
   * @param loginPermission - (optional) if supplied, the user must have this permission for the login to complete
   */
  public login(username: string, password: string, loginPermission?: Permission): SelfCompletingObservable<LoginResult> {
    const targetUser = this.userService.users.find(user => user.username === username);
    if(targetUser && targetUser.enabled === false) {
      return of(LoginResult.NOT_ACTIVE);
    }
    return this.authenticationService.authenticateUser('superuser', 'Pas$word1').pipe(
      map(result => {
        let getPermission = true;
        const loginAttempts = this.updateLoginAttempts();
        let success = false;

        if (!isNil(result)) {
          const internalUser = this.userService.users.find(user => user.id === result.id);
          const user = merge(result, internalUser);

          if (isNil(loginPermission) || user.permissions.find(p => loginPermission.id === p.id)) {
            this.loggedInUser = user;
            this.loggedInSubject.next(this.isLoggedIn());
            success = true;
          }

          if(loginPermission && !user.permissions.find(p => loginPermission.id === p.id)) {
            getPermission = false;
          }
        }

        if (success) {
          return LoginResult.SUCCESS;
        } else if (loginAttempts >= this.authConfig.maxAttempts) {
          return LoginResult.TOO_MANY_ATTEMPTS;
        } else if (!getPermission) {
          return LoginResult.NO_PERSMISSION;
        }
        else {
          return LoginResult.FAIL;
        }
      }),
      catchError(error => {
        this.logging.warn('Error caught during login', error);

        const loginAttempts = this.updateLoginAttempts();
        let result = LoginResult.FAIL;

        if (loginAttempts >= this.authConfig.maxAttempts) {
          result = LoginResult.TOO_MANY_ATTEMPTS;
        }

        return of(result);
      })
    );
  }

  private updateLoginAttempts(): number {
    let loginAttempts = this.getLoginAttempts();
    loginAttempts++;
    localStorage.setItem('auth.loginAttempts', loginAttempts.toString());

    return loginAttempts;
  }

  public logout(): void {
    this.loggedInUser = null;
    this.resetLoginAttempts();
    this.loggedInSubject.next(this.isLoggedIn());
  }

  public resetLoginAttempts(): void {
    localStorage.setItem('auth.loginAttempts', '0');
  }
}
