/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/member-ordering */

import { HttpClient } from '@angular/common/http';
import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Inject, Input, OnDestroy, OnInit, Output, signal, Signal } from '@angular/core';
import { FormControl, UntypedFormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Subscription } from 'rxjs';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import {
  newFormControl,
  newOptionalFormControl,
  PromptDialogComponent,
  PromptDialogData
} from '@oksygen-common-libraries/material/components';
import { MaterialButtonVariant, MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { OfflineService } from '@oksygen-sim-core-libraries/components-services/common';
import { Permission } from '@oksygen-sim-core-libraries/components-services/permissions';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { POWER_MANAGEMENT_TOKEN, PowerManagement } from '@oksygen-sim-train-libraries/components-services/common';

import { toSignal } from '@angular/core/rxjs-interop';
import { checkLoginConfig, DEFAULT_LOGIN_CONFIG, LoginConfig } from '../../models/login-config.model';
import { AuthService, LoginResult } from '../../services/auth.service';

@Component({
  selector: 'oksygen-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.scss']
})
export class AuthenticationComponent implements AfterViewInit, OnDestroy, OnInit {
  /**
   * The permission level required to log in
   */
  @Input() loginPermission: Permission = null;

  /**
   * The title of the application.
   */
  @Input() title: string;

  /**
   * Provide the link to the customer's logo.
   */
  @Input() customerLogoUrl: string;

  /**
   * Whether to show the shutdown button (default true).
   */
  @Input() showShutdown = true;

  /**
   * The message to show in the shutdown window
   */
   @Input() shutdownMessage = 'Are you sure you want to shutdown all systems?';

  /**
   * Cutom username input field label (default "Username").
   */
  @Input() usernameFieldLabel = 'Username';

  /**
   * Whether to use the default shutdown dialog (default true)
   */
  @Input() useDefaultShutdownDialog = true;

  /**
   * Whether to use the default shutdown dialog (default true)
   */
  @Input() useDefaultShutdownHandling = true;

  /**
   * Output that shutdown has been clicked, only emitted if useDefaultShutdownDialog is false
   */
  @Output() readonly shutdownClick = new EventEmitter<void>();

  /**
   * Output that shutdown has been clicked, only emitted if useDefaultShutdownHandling is false
   */
  @Output() readonly handleShutdown = new EventEmitter<void>();

  public images: Signal<string[]>;

  public failParams: {
    attempts: number;
    maxAttempts: number;
  } = {
    attempts: null,
    maxAttempts: null
  };

  public showLoginFailed = signal<boolean>(false);
  public showNextAttempt = signal<boolean>(false);
  public tooManyAttempts = signal<boolean>(false);
  public showNoPermission = signal<boolean>(false);
  public showNotActive = signal<boolean>(false);
  public usersLoaded = signal<boolean>(false);
  public connected = signal<boolean>(false);
  public loginDisabled = signal<boolean>(false);

  previousImageIndex = signal(0);
  imageIndex = signal(0);

  private swapImages = { enabled: false, interval: 0 };

  private swapImagesTimer: any;

  hidePassword = signal<boolean>(true);

  loginForm: UntypedFormGroup;

  private config: LoginConfig;

  private subscriptions: Subscription = new Subscription();

  constructor(
    public readonly authService: AuthService,
    private readonly router: Router,
    private readonly httpClient: HttpClient,
    private readonly registry: Registry,
    private readonly userService: UserService,
    private readonly dialog: MatDialog,
    private readonly offline: OfflineService,
    private readonly logging: Logging,
    private readonly cd: ChangeDetectorRef,
    @Inject(POWER_MANAGEMENT_TOKEN) private readonly powerManagementService: PowerManagement
  ) {
    this.swapImages = this.registry.getObject(['login', 'swapImages'], { enabled: false, interval: 0 });
    this.config = checkLoginConfig(this.registry.getObject<LoginConfig>(['login', 'config'], DEFAULT_LOGIN_CONFIG));

    let username: FormControl;
    let password: FormControl;

    if (this.config.usernameRequired) {
      username = newFormControl();
    } else {
      username = newOptionalFormControl();
    }

    if (this.config.passwordRequired) {
      password = newFormControl();
    } else {
      password = newOptionalFormControl();
    }

    this.loginForm = new UntypedFormGroup({ username, password });
    this.images = toSignal(this.httpClient.get<string[]>('./assets/images/login/images.json'));
  }

  ngOnInit(): void {
    // this.httpClient.get<string[]>('./assets/images/login/images.json').subscribe(data => {
    //   this.images = data;

    //   // if (this.swapImages.enabled) {
    //   //   data.forEach(image => {
    //   //     this.httpClient.get(`./assets/images/login/${image}`);
    //   //   });
    //   // }
    //   setTimeout(() => this.cd.markForCheck() );
    // });

    this.subscriptions.add(this.offline.isOnline$().subscribe(online => (this.connected.set(online))));

    this.subscriptions = this.userService.ready$.pipe(takeOneTruthy()).subscribe(() => {
      this.usersLoaded.set(true);
      this.userService.reloadData();
    });
    this.userService.reloadData();
  }

  ngAfterViewInit(): void {
    if (this.swapImages.enabled) {
      this.swapImagesTimer = setInterval(() => this.selectLeftImage(), this.swapImages.interval * 1000);
    }
  }

  ngOnDestroy(): void {
    clearInterval(this.swapImagesTimer);
    this.subscriptions.unsubscribe();
  }

  onLoginClick(): void {
    let usernameValid = true;
    let passwordValid = true;

    this.loginForm.updateValueAndValidity();
    this.loginForm.markAllAsTouched();

    if (this.config.usernameRequired) {
      usernameValid = !this.loginForm.hasError('required', 'username');
    }

    if (this.config.passwordRequired) {
      passwordValid = !this.loginForm.hasError('required', 'password');
    }
    if (usernameValid && passwordValid) {
      document.body.style.cursor = 'progress';
      this.loginDisabled.set(true);

      this.authService.login(this.loginForm.value.username, this.loginForm.value.password, this.loginPermission).subscribe(result => {
        document.body.style.cursor = '';

        switch (result) {
          case LoginResult.SUCCESS:
            this.authService.resetLoginAttempts();
            this.router.navigate(['/home']);
            break;
          case LoginResult.TOO_MANY_ATTEMPTS:
            this.handleFail(true);
            break;
          case LoginResult.NO_PERSMISSION:
            this.handleNoPermission(false);
            break;
          case LoginResult.NOT_ACTIVE:
            this.handleNotActive(false);
            break;
          case LoginResult.FAIL:
          default:
            this.handleFail(false);
            break;
        }
        this.cd.detectChanges();
      });
    }
  }

  doHidePassword(): void {
    if (!this.loginDisabled()) {
      this.hidePassword.set(!this.hidePassword());
    }
  }

  onShutdownClick(): void {
    if (!this.useDefaultShutdownDialog) {
      this.shutdownClick.emit();
    } else {
      const promptData = new PromptDialogData();
      promptData.title = t('Shutdown');
      promptData.content = t(this.shutdownMessage);
      promptData.buttons = [
        {
          color: MaterialThemePalette.PRIMARY,
          text: t('Cancel'),
          data: false
        },
        {
          color: MaterialThemePalette.PRIMARY,
          style: MaterialButtonVariant.BUTTON,
          text: t('Shutdown'),
          data: true
        }
      ];

      const dialogRef = this.dialog.open(PromptDialogComponent, {
        data: promptData,
        width: '400px',
        panelClass: 'small-whitespace-dialog'
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.shutdownAll();
        }
      });
    }
  }

  shutdownAll(): void {
    if (!this.useDefaultShutdownHandling) {
      this.handleShutdown.emit();
    } else {
      this.authService.resetLoginAttempts();
      this.powerManagementService.shutdownAll(true, undefined, false); // include this computer, so don't use ignored config
    }
  }

  clearLoginFailed(): void {
    this.showLoginFailed.set(false);
  }

  clearNoPermission(): void {
    this.showNoPermission.set(false);
  }

  clearNotActive(): void {
    this.showNotActive.set(false);
  }

  clearNextAttempt(): void {
    this.showNextAttempt.set(false);
  }

  private handleFail(tooManyAttempts: boolean): void {
    if(this.showNoPermission())
    {
      //Clear the other message as we just want one displayed at a time
      this.clearNoPermission();
    }

    if(this.showNotActive())
    {
      //Clear the other message as we just want one displayed at a time
      this.clearNotActive();
    }

    this.showLoginFailed.set(true);
    this.checkAttempt(tooManyAttempts);
  }

  private handleNoPermission(tooManyAttempts: boolean): void {
    if(this.showLoginFailed())
    {
      //Clear the other message as we just want one displayed at a time
      this.clearLoginFailed();
    }

    if(this.showNotActive())
    {
      //Clear the other message as we just want one displayed at a time
      this.clearNotActive();
    }

    this.showNoPermission.set(true);
    this.checkAttempt(tooManyAttempts);
  }

  private handleNotActive(tooManyAttempts: boolean): void {
    if(this.showLoginFailed())
    {
      //Clear the other message as we just want one displayed at a time
      this.clearLoginFailed();
    }

    if(this.showNoPermission())
    {
      //Clear the other message as we just want one displayed at a time
      this.clearNoPermission();
    }

    this.showNotActive.set(true);
    this.checkAttempt(tooManyAttempts);
  }

  private checkAttempt(tooManyAttempts: boolean): void {
    this.failParams = { attempts: this.authService.getLoginAttempts(), maxAttempts: this.authService.getLoginMaxAttempts() };
    this.tooManyAttempts.set(tooManyAttempts);
    this.showNextAttempt.set(this.failParams.maxAttempts - this.failParams.attempts === 1);
    this.loginDisabled.set(false);

    if (tooManyAttempts) {
      this.authService.resetLoginAttempts();
      this.shutdownAll();
    }
  }

  private selectLeftImage(): void {
    if (this.images()) {
      let index = Math.floor(Math.random() * this.images().length);

      while (index === this.imageIndex() || index === this.previousImageIndex()) {
        index = Math.floor(Math.random() * this.images().length);
      }

      this.previousImageIndex.set(this.imageIndex());
      this.imageIndex.set(index);
    }
  }
}
