/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { EditHistory } from '@oksygen-common-libraries/common';
import { RuleProperties } from './rule-properties.model';
import { fromVersionString } from '@oksygen-sim-train-libraries/components-services/versioning';
import { asArray } from '@oksygen-common-libraries/common';
import { RuleTemplate } from './rule-template.model';

// ToRuleTemplate...Xml is the JSON data structure of a rule template that will be processed INTO XML.
// That is, it's for when we're saving to the database.

// FromRuleTemplate...Xml is the JSON data structure of a rule template that we're processing FROM XML.
// That is, it's for when we're loading from the database.

export interface ToRuleTemplateBlocksXml {
  ruleBlock: ToRuleTemplateBlockXml[];
}

export interface ToRuleTemplateBlockXml {
  $: {
    id: number;
  };
  blockType: string;
  version: string;
  displayName: string;
  displayDescription: string;
  metaData?: ToRuleTemplateBlockMetaXml;
  properties?: ToRuleTemplateBlockPropertiesXml;
}

export interface ToRuleTemplateBlockMetaXml {
  x?: number;
  y?: number;
  [key: string]: any;
}

export interface ToRuleTemplateBlockPropertiesXml {
  property: ToRuleTemplateBlockPropertyXml[];
}

export interface ToRuleTemplateBlockPropertyXml {
  name: string;
  /** NOTE booleans will be in stringified '1' | '0' form */
  value?: string | number | boolean;
}

export interface ToRuleTemplateConnectionsXml {
  connection: ToRuleTemplateConnectionXml[];
}

export interface ToRuleTemplateConnectionXml {
  source: ToRuleTemplateConnectionPortXml;
  destination: ToRuleTemplateConnectionPortXml;
}

export interface ToRuleTemplateConnectionPortXml {
  blockId: number;
  port: string;
}

export interface ToRuleTemplateXml {
  $: {
    id: string;
  };
  version: string;
  displayName: string;
  displayDescription: string;
  history?: {
    historyLog: {
      $: {
        type: string;
        authorFirstName: string;
        authorLastName: string;
        id: string;
        version: string;
        timestamp: string;
      };
    }[];
  };
  ruleBlocks?: ToRuleTemplateBlocksXml;
  connections?: ToRuleTemplateConnectionsXml;
}

export interface FromRuleTemplateConnectionSourceDestination {
  blockId: number;
  port: string;
}

export interface FromRuleTemplateConnection {
  source: FromRuleTemplateConnectionSourceDestination;
  destination: FromRuleTemplateConnectionSourceDestination;
}

export interface FromRuleTemplateConnections {
  connection: FromRuleTemplateConnection[];
}

export interface FromRuleTemplateRuleBlock {
  id: number;
  blockType: string;
  version: string;
  displayName: string;
  displayDescription?: string;
  properties?: RuleProperties;
  /** This is a UI only concept - for now!! */
  metaData?: FromRuleTemplateRuleBlockMeta;
}

export interface FromRuleTemplateRuleBlockMeta {
  x?: number;
  y?: number;
  [key: string]: any;
}

export interface FromRuleTemplateRuleBlocks {
  ruleBlock: FromRuleTemplateRuleBlock[];
}

export interface FromRuleTemplate {
  id: string;
  version: string;
  displayName: string;
  displayDescription: string;
  ruleBlocks: FromRuleTemplateRuleBlocks;
  phantom?: boolean;
  history: { historyLog: FromRuleTemplateHistory[] };
  connections?: FromRuleTemplateConnections;
}

export interface FromRuleTemplates {
  ruleTemplate: FromRuleTemplate[];
}

// FIXME id & version should be moved to parent!
export interface FromRuleTemplateHistory extends EditHistory {
  id: string;
  version: string;
}

export function transformFromRuleTemplate(ruleTemplate: FromRuleTemplate): RuleTemplate {
  const rt: RuleTemplate = {
    id: ruleTemplate.id,
    displayName: ruleTemplate.displayName,
    displayDescription: ruleTemplate.displayDescription,
    history: ruleTemplate.history,
    ruleBlocks: ruleTemplate.ruleBlocks,
    version: fromVersionString(ruleTemplate.version)
  };
  if (Object.prototype.hasOwnProperty.call(ruleTemplate, 'phantom')) {
    rt.phantom = ruleTemplate.phantom;
  }
  if (Object.prototype.hasOwnProperty.call(ruleTemplate, 'connections')) {
    rt.connections = ruleTemplate.connections;
  }
  if (!rt?.ruleBlocks) {
    rt.ruleBlocks = { ruleBlock: [] };
  }
  if (!rt?.ruleBlocks?.ruleBlock) {
    rt.ruleBlocks.ruleBlock = [];
  }
  if (rt?.ruleBlocks?.ruleBlock) {
    rt.ruleBlocks.ruleBlock = asArray(rt.ruleBlocks.ruleBlock);
    rt.ruleBlocks.ruleBlock.forEach(rb => {
      // somewhat verbose way of ensuring data structure is correct (should also type check)
      if (!rb) { return; }
      if (!rb.properties) {
        rb.properties = { property: [] };
      }
      if (!rb.properties.property) {
        rb.properties.property = [];
      }
      if (rb?.properties?.property) {
        rb.properties.property = asArray(rb.properties.property);
      }
    });
  }
  if (rt?.connections?.connection) {
    rt.connections.connection = asArray(rt.connections.connection);
  }
  if (!rt.history) {
    rt.history = { historyLog: [] };
  }
  if (rt?.history?.historyLog) {
    rt.history.historyLog = asArray(rt.history.historyLog);
  }
  return rt;
}
