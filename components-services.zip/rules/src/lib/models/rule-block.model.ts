/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/**
 * A list of common rule block property types.
 * In the database, this is ```ruleblock.property.name```.
 * This is NOT an exhaustive list!!
 * This is an enum version of ```RuleBlockPropertyType``` (FIXME - there should be only 1)
 */
export enum RuleBlockPropertyNameEnum {
  TRAIN_ID = 'train_id',
  TRAIN_PROPERTY = 'train_property',
  VEHICLE_INDEX = 'vehicle_index',
  VEHICLE_PROPERTY = 'vehicle_property',
  ENVIRONMENT_PROPERTY = 'environment_property',
  STATE = 'state',
  VALUE = 'value',
  FEATURE_NAME = 'feature_name',
  PROMPT_ENABLE = 'prompt_enable',
  PROMPT_TIME = 'prompt_time',
  ELAPSED_TIME = 'elapsed_time',
  MULTIMEDIA_NAME = 'multimedia_name',
  USER_FAULT = 'user_fault',
  UNIT_CONVERSION = 'unit_conversion',
  MESSAGE = 'message',
  VARIABLE = 'variable',
  MESSAGE_TYPE = 'message_type',
  AUTO_DISMISS = 'auto_dismiss',
  DISMISS_DURATION = 'dismiss_duration',
  ASSESSMENT_CATEGORY = 'assessment_category',
  REPORT_MESSAGE = 'report_message',
  ASSESSMENT_POINTS = 'assessment_points',
  TRIGGERED_ONCE = 'triggered_once'
}

/**
 * In the database, this is ```ruleBlock.property.propertyType```.
 */
export enum RuleBlockPropertyTypeEnum {
  TRAIN_ID = 'train_id',
  VARIANT = 'variant',
  FEATURE_ID = 'feature_id',
  VEHICLE_INDEX = 'vehicle_index',
  VEHICLE_PROPERTY = 'vehicle_property',
  TIME = 'time',
  BOOLEAN = 'boolean',
  FEATURE_NAME = 'feature_name',
  FEATURE_STATE = 'feature_state',
  ENVIRONMENT_PROPERTY = 'environment_property',
  MOODLE_SCORM_ACTIVITY = 'moodle_scorm_activity',
  MESSAGE = 'message',
  NUMBER = 'number',
  STRING = 'string'
}

/**
 * In the database, this is ```ruleBlock.name```.
 */
export enum RuleBlockNames {
  ENVIRONMENT = 'environment_property_action',
  FEATURE = 'feature',
  FEATURE_STATE = 'feature_state_action',
  INSTRUCTOR_MESSAGE = 'instructor_message_action',
  TEMPORAL_EVENT = 'temporal_event_trigger',
  TRAIN_PROPERTY = 'train_property_action',
  TRAIN = 'train',
  TRAIN_SPATIAL_EVENT = 'train_spatial_event_trigger',
  VEHICLE = 'vehicle_property_action',
  MOODLE_SCORM_ACTIVITY = 'moodle_scorm_activity',
  MOODLE_SCORM_ACTIVITY_ACTION = 'moodle_scorm_activity_action',
  UNKNOWN = 'block_has_no_associated_handler',
  USER_FAULT = 'user_fault_action',
  TRAVELLED_DISTANCE = 'travelled_distance',
  TRAIN_SPEED = 'train_speed',
  GET_BOOLEAN_VARIABLE = 'get_boolean_variable',
  GET_NUMBER_VARIABLE = 'get_number_variable',
  SET_BOOLEAN_VARIABLE = 'set_boolean_variable',
  SET_NUMBER_VARIABLE = 'set_number_variable',
  ASSESSMENT_SCORE = 'assessment_decrease_score',
}

/**
 * This is the data entry type of a rule block property.
 * For example, train_id is list because you select the train from a list.
 * If you wanted the user to manually enter the train_id you could make it a number instead.
 * Data types are mostly self-explanatory, list = single selection list, multilist means you can select multiple items in the list.
 */
export type RuleBlockPropertyDataType = 'string'|'number'|'date'|'time'|'list'|'multilist'|'boolean';

export interface RuleBlockProperty {
  name: string;
  displayName: string;
  displayDescription?: string;
  propertyType: RuleBlockPropertyTypeEnum;
  defaultUnits?: string;
  defaultValue?: any;
}

export interface RuleBlockProperties {
  property: RuleBlockProperty[];
}

export interface BlockIcon {
  staticImage?: string;
  iconHandler?: string;
}

export interface Port {
  name: string;
  portType: string;
}

export interface Ports {
  port: Port[];
}

export interface Replacement {
  replacementType: string;
  replacementText: string;
  name?: string;
}

export interface Replacements {
  replacement: Replacement[];
}

export interface BaseScript {
  replacements?: Replacements;
  script: string;
}

export interface ActionScript extends BaseScript {
  name?: string;
}

export interface OutputScript extends BaseScript {
  portName: string;
}

export interface RuleScript extends BaseScript {
  name?: string;
}

export interface RuleScripts {
  ruleScript: RuleScript[];
}
export interface BlockScripts {
  actionScript: ActionScript[];
  outputScript: OutputScript[];
}

export type CategoryType = 'constant' | 'operation' | 'action' | 'selection' | 'assessment' ;

export interface RuleBlock {
  name: string;
  displayName: string;
  displayDescription: string;
  version: string;
  icon: string;
  category: CategoryType;
  toolbarIcon: string;
  blockIcon: BlockIcon;
  properties?: RuleBlockProperties;
  inputPorts?: Ports;
  outputPorts?: Ports;
  blockScripts?: BlockScripts;
}

export interface RuleBlocks {
  ruleBlock: RuleBlock[];
}

export interface RuleBlockCategory {
  name: string;
  displayName: string;
  displayDescription: string;
  colour: string;
  order: number;
}

export interface RuleBlockCategories {
  ruleBlockCategory: RuleBlockCategory[];
}

/**
 * Get a ports type + image to be used based on it's portType.
 *
 * @param port the port to check
 */
export function getPortType(port: Port): {type: string; image: string} {
  if (port.portType === 'boolean') { return {type: 'boolean', image: 'switch_on'}; }
  if (port.portType === 'feature_name') { return {type: 'feature', image: 'object'}; }
  if (port.portType === 'train_id') { return {type: 'train', image: 'train'}; }
  if (port.portType === 'number') { return {type: 'number', image: 'plus-1'}; }
  if(port.portType === 'variant') { return {type: 'variant', image: 'help'}; }
  return {type: 'unknown', image: 'help'};
}


/**
 * Get the data entry type of a rule block property.
 * A data entry type is what the user will see on the screen, ie a selection list, string textbox, datetime selector etc.
 * @param propertyType the property type to convert to it's corresponding data type
 */
export function getPropertyDataEntryType(propertyType: RuleBlockPropertyTypeEnum): RuleBlockPropertyDataType {
  if (propertyType === RuleBlockPropertyTypeEnum.BOOLEAN) { return 'boolean'; }
  if (propertyType === RuleBlockPropertyTypeEnum.VARIANT) { return 'string'; }
  if (propertyType === RuleBlockPropertyTypeEnum.NUMBER) { return 'number'; }
  if (propertyType === RuleBlockPropertyTypeEnum.TIME) { return 'time'; }
  return 'string';
}
