/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { EditHistory } from '@oksygen-common-libraries/common';
import { VersionedObject } from '@oksygen-sim-train-libraries/components-services/versioning';

import { RuleProperties } from './rule-properties.model';
import { RuleBlockNames, RuleBlockPropertyNameEnum } from './rule-block.model';

// FIXME id & version should be moved to parent!
export interface RuleTemplateHistory extends EditHistory {
  id: string;
  version: string;
}

export interface RuleTemplateConnectionSourceDestination {
  blockId: number;
  port: string;
}

export interface RuleTemplateConnection {
  source: RuleTemplateConnectionSourceDestination;
  destination: RuleTemplateConnectionSourceDestination;
}

export interface RuleTemplateConnections {
  connection: RuleTemplateConnection[];
}

export interface RuleTemplateRuleBlock {
  id: number;
  blockType: string;
  version: string;
  displayName: string;
  displayDescription?: string;
  properties?: RuleProperties;
  /** This is a UI only concept - for now!! */
  metaData?: RuleTemplateRuleBlockMeta;
}

export interface RuleTemplateRuleBlockMeta {
  x?: number;
  y?: number;
  [key: string]: any;
}

export interface RuleTemplateRuleBlocks {
  ruleBlock: RuleTemplateRuleBlock[];
}

export interface RuleTemplate extends VersionedObject {
  id: string;
  // version: string;
  displayName: string;
  displayDescription: string;
  ruleBlocks: RuleTemplateRuleBlocks;
  phantom?: boolean;
  history: { historyLog: RuleTemplateHistory[] };
  connections?: RuleTemplateConnections;
}

export interface RuleTemplates {
  ruleTemplate: RuleTemplate[];
}

/**
 * Returns the id of the multimedia if a rule template has a reference to one.
 */
export function ruleTemplateHasMultimedia(ruleTemplate: RuleTemplate): string {
  let multimediaId = '';
  ruleTemplate.ruleBlocks.ruleBlock.forEach(rb => {
    if (rb.blockType === RuleBlockNames.MOODLE_SCORM_ACTIVITY_ACTION) {
      // Reading the ID of multimedia attached to rule
      if (rb.properties && rb.properties.property) {
          rb.properties.property.forEach(prop => {
        if (prop.name === RuleBlockPropertyNameEnum.MULTIMEDIA_NAME) {
          if (typeof prop.value === 'string' || typeof prop.value === 'number' || typeof prop.value === 'boolean') {
            multimediaId = prop.value.toString();
          } else {
            multimediaId = '';
          }
        }
        });
      }
    }
  });
  return multimediaId;
}
