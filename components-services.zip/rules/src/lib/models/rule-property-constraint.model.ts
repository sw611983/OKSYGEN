/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentRef } from '@angular/core';
import { SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';
import { RuleTemplateRuleBlock } from './rule-template.model';
import { RuleBlock } from './rule-block.model';

export enum OksygenRuleBlockPropertyConstraints {
  ENVIRONMENT = 'environment_property_action',
  FEATURE = 'feature',
  FEATURE_STATE = 'feature_state_action',
  INSTRUCTOR_MESSAGE = 'instructor_message_action',
  TEMPORAL_EVENT = 'temporal_event_trigger',
  TRAIN_PROPERTY = 'train_property_action',
  TRAIN = 'train',
  TRAIN_SPATIAL_EVENT = 'train_spatial_event_trigger',
  VEHICLE = 'vehicle_property_action',
  MOODLE_SCORM_ACTIVITY = 'moodle_scorm_activity',
  MOODLE_SCORM_ACTIVITY_ACTION = 'moodle_scorm_activity_action',
  UNKNOWN = 'block_has_no_associated_handler'
}

export abstract class RuleBlockConstraint<Block, GenerateResponse, UpdateResponse> {
  /**
   * Process a rule template rule block to generate a list of of properties that apply to this constraint.
   * Should return an empty array if none of the properties on this block apply to this constraint.
   * For example, a "train property" rule block has no "environment properties", and so an environment constraint
   * should return an empty array.
   */
  abstract generatePropertyList(block: Block): GenerateResponse[];
  /**
   * Update a property. Return the list of affected properties (as the update may cascade to other properties).
   * @param block the block to update
   * @param propertyName the property on the block to update
   * @param value the new value
   */
  abstract updateProperty(block: Block, propertyName: string, value: number|string|boolean): UpdateResponse;
    /**
     * Return the list of properties this constraint should handle as a group.
     */
  abstract managedProperties(): string[];
}

/**
 * Scenario rule properties are often state based, ie "on/off" "closed/open" etc.
 * In these cases, we need to give user a dropdown of values as opposed to generic input.
 */
export class RulePropertyAllowedValues {
  /** if icon is supplied, clicking it should link to the list component */
  icon?: string;
  /** a component to render the list of options. */
  listComponent?: ComponentRef<any>; // FIXME need an abstract "base list" class
  /** any optional config to supply to the list component */
  componentData?: any; // should this have typing
  /** our actual list of allowed values. */
  allowedValues: SimPropertyState[]; // not fn or obs as this system relies on immutability
  /** our actual list of display values, this may be a filtered list of the allowed values */
  displayedValues: SimPropertyState[]; // not fn or obs as this system relies on immutability
  /**
   * A dropdown indicates a simple drop down.
   * A panel indicates the list is complex enough to warrant a full panel list.
   * Both indicates a dropdown with the option to have a panel view should be supported.
   * Note that both icon AND component MUST be supplied if type is both or panel.
   * By default, this will be dropdown.
   */
  type: 'dropdown'|'panel'|'both' = 'dropdown';

  constructor(allowedValues: SimPropertyState[], displayedValues?: SimPropertyState[]) {
    this.allowedValues = allowedValues;
    this.displayedValues = displayedValues;

    if (!displayedValues) {
      this.displayedValues = allowedValues;
    }
  }
}

export class RuleEditorRuleBlockProperty {
  [key: string]: any;

  name: string;
  /**
   * type is defined list of rule block types. See ```RuleBlockPropertyTypeEnum```.
   * Each type can only exist ONCE per properties array.
   */
  type: string;
  value: string|number|boolean;
  displayName?: string;
  defaultValue?: string|number|boolean;
  defaultUnits?: string;
  /**
   * A constant list of possible values for this property.
   */
  allowedValues?: RulePropertyAllowedValues;
  units?: string;
  /** whether this property should be editable in the UI. Used when this property depends on others. */
  enabled?: boolean;
  /** an error message, usually to accompany enabled = false when there's some problem with the data. */
  errorMessage?: string;
  version?: string;

  /**
   * Creates a scenario rule item. Optionally pass through a data object containing initial values.
   *
   * @param data an object containing initial values
   */
  constructor(data?: any) {
    this.assignData(data);
  }

  /**
   * Pass in a data object with properties you want to assign to this property item.
   * This works as a PATCH - only properties you specify in data obj will be updated.
   *
   * @param data properties to be assigned
   */
  assignData(data: Partial<RuleEditorRuleBlockProperty>): void {
    if (!data) { return; }
    // assign properties
    if (Object.prototype.hasOwnProperty.call(data, 'name')) { this.name = data.name; }
    if (Object.prototype.hasOwnProperty.call(data, 'displayName')) { this.displayName = data.displayName; }
    if (Object.prototype.hasOwnProperty.call(data, 'type')) { this.type = data.type; }
    if (Object.prototype.hasOwnProperty.call(data, 'value')) { this.value = data.value; }
    if (Object.prototype.hasOwnProperty.call(data, 'defaultValue')) { this.defaultValue = data.defaultValue; }
    if (Object.prototype.hasOwnProperty.call(data, 'allowedValues')) { this.allowedValues = data.allowedValues; }
    if (Object.prototype.hasOwnProperty.call(data, 'units')) { this.units = data.units; }
    if (Object.prototype.hasOwnProperty.call(data, 'enabled')) { this.enabled = data.enabled; }
    if (Object.prototype.hasOwnProperty.call(data, 'errorMessage')) { this.errorMessage = data.errorMessage; }
    if (Object.prototype.hasOwnProperty.call(data, 'version')) { this.version = data.version; }
    if (Object.prototype.hasOwnProperty.call(data, 'defaultUnits')) { this.defaultUnits = data.defaultUnits; }

    // additional business logic - default name to type if name does not exist.
    if (!this.name && this.type) { this.name = this.type; }
  }

  isValid(): boolean {
    if (this.value === null || this.value === undefined || this.value === '') { return false; }
    if (this.allowedValues) {
      if (!this.allowedValues.allowedValues.find(v => v.value === this.value || v.value === `${this.value}`)) {
        return false;
      }
    }
    return true;
  }
}

/** Pairs a rule template rule block with it's corresponding rule block. */
export class RuleBlockPair {
  templateBlock: RuleTemplateRuleBlock;
  ruleBlock: RuleBlock;
}
