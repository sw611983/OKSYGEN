/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RuleProperties } from './rule-properties.model';

export interface RuleBlockReference {
  blockId: number;
  properties: RuleProperties;
}

export interface RuleBlockReferences {
  ruleBlock: RuleBlockReference[];
}

export interface RuleTemplateReference {
  id: string;
  version: string;
  ruleBlocks: RuleBlockReferences;
}

export interface BaseRule {
  id: number;
  displayName: string;
  description?: string;
  ruleTemplateReference: RuleTemplateReference;
}
