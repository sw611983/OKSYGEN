/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { Logging } from '@oksygen-common-libraries/pio';
import { SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { RuleTemplateRuleBlock } from '../models/rule-template.model';
import { RuleBlockPair } from '../models/rule-property-constraint.model';
import { PropertyUpdate } from '../models/rule-properties.model';
import { BasePropertyConstraint } from './constraints/base-property.constraint';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

/**
 * Responsible for setting up our rule block property constraints.
 * A "rule block constraint" groups rule block properties together so they can be processed and validated as a group.
 * For example, the "environment property constraint" would pair the "environment name" and "environment value" properties together.
 * So if "environment name is 'Rain', then the constraint would enforce only valid 'rain' values such as 15%.
 * And if environment name is not set, the environment value cannot be set.
 */
@Injectable()
export abstract class RuleBlockPropertyConstraintService<PropertyType> {

  /** Your list of constraints to apply to rule block properties. */
  protected constraints: BasePropertyConstraint[] = [];
  /** The constraint to use when all other constraints do not apply. */
  protected unknownConstraint: BasePropertyConstraint;

  constructor(
    protected logging: Logging,
    protected simPropertyService: SimPropertiesService
  ) {}

  /**
   * Initialise your list of constraints. Typically this takes a config object which will determine
   * which constraints to use.
   * @param args this can be anything
   */
  abstract initialiseConstraints(...args: any): void;
  /**
   * This will generate a list of properties for the passed in rule template rule block.
   * @param ruleTemplateRuleBlock the rule template rule block to generate a property list for
   */
  abstract generatePropertyList(ruleTemplateRuleBlock: RuleTemplateRuleBlock): SelfCompletingObservable<PropertyType[]>;
  /**
   * Update a rule template rule block property.
   * Updating properties may cascade and update other properties, so return a list of all affected properties.
   * @param block the rule block to update
   * @param propertyName the name of the property you're updating
   * @param value the value you're updating this property to
   */
  abstract updateProperty(block: RuleBlockPair, propertyName: string, value: string|number|boolean): PropertyUpdate[];

  /**
   * This is used to add custom handling to rule blocks.
   * Note if you use a taken id it will override the existing constraint.
   * Constraints process rule blocks on a first come first serve basis
   * so if you need your constraint to be processed BEFORE the Oksygen constraints pass priority = high.
   *
   * @param constraint the constraint to add
   * @param priority (default low) if the constraint should be processed first or last compared to existing constraints
   */
  addPropertyConstraint(constraint: BasePropertyConstraint, priority: 'high'|'low' = 'low'): void {
    if (priority === 'low') {
      this.constraints.push(constraint);
    } else {
      this.constraints.unshift(constraint);
    }
  }

  /**
   * the constraint to use to process all properties not covered by any of our existing constraints.
   * @param constraint the constraint to use
   */
  setUnknownConstraint(constraint: BasePropertyConstraint): void {
    this.unknownConstraint = constraint;
  }
}
