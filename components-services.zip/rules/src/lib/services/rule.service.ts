/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UserScenarioFavouritesService } from '@oksygen-sim-core-libraries/components-services/favourites';
import { RuleItem, RulesService } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';

/**
 * This class wraps around the RulesService, and combines the rules returned with favourites
 */
@Injectable()
export class RuleService extends RulesService {
  constructor(registry: Registry, logging: Logging, private favouritesService: UserScenarioFavouritesService) {
    super(registry, logging);
  }

  /**
   * Get a stream of rules.
   * This is effectively a store - you'll get the whole rule list each time an rule is updated.
   * This observable is hot (but you'll get the latest data on subscribe, not just the next rules going forward).
   * These have been pre-mapped to an easier to use format.
   * Don't forget to unsubscribe!!
   *
   * @param systemId the system you want to get rules for
   */
  override systemRules(systemNumber: number): Observable<RuleItem[]> {
    return combineLatest([
      super.systemRules(systemNumber),
      this.favouritesService.getFavouritesManager(systemNumber)?.userScenarioFavourites$() ?? of({favourite: []})
    ]).pipe(
      map(([rules, favourites]) => {
        rules?.forEach(rule => {
          const favourite = favourites?.favourite?.find(f => (rule.id === f.ruleId));

          if (favourite) {
            rule.isFavourite = true;
          } else {
            rule.isFavourite = false;
          }
        });

        return rules;
      })
    );
  }
}
