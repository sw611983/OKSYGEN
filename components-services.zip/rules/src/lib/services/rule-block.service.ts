/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

import { asArray, ImageHandler, takeOneTruthy } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { AbstractDataService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { GlobalImageStoreKey, ImageService } from '@oksygen-sim-train-libraries/components-services/common';

import { RuleBlock, RuleBlockCategories, RuleBlockCategory, RuleBlocks } from '../models/rule-block.model';

/**
 * Starts loading rule block icons.
 * An observable is returned so that this may be used as an application initializer.
 *
 * @param ruleBlockService The rule block service.
 * @returns A observable which will return the percentage of images that have loaded.
 */
export function startLoadingRuleBlockIcons(
  ruleBlockService: RuleBlockService,
  imageService: ImageService,
  preloadBatchSize = ImageService.DEFAULT_PRELOAD_BATCH_SIZE
): Observable<number> {
  return ruleBlockService.data().pipe(
    takeOneTruthy(),
    switchMap(() => imageService.preloadImageByPath({ keys: [GlobalImageStoreKey.RULE_BLOCK], batchSize: preloadBatchSize }))
  );
}

@Injectable()
export class RuleBlockService extends AbstractDataService<RuleBlock[]> {
  private ruleBlockData: RuleBlock[];
  private ruleBlockCategories = new Set<RuleBlockCategory>();

  constructor(
    logging: Logging,
    registry: Registry,
    private imageService: ImageService,
    dataAccessService: DataAccessService
    // private ruleBlockHandler: RuleBlockHandlerService
  ) {
    super(logging, registry, dataAccessService);
    this.initialise();
    // this.ruleBlockHandler.initialiseHandlers();
  }

  // TODO should use a cache eviction mechanism (e.g. comparing time of last update to latest)
  // to avoid unnecessary data transfer.
  /**
   * Request the data to be reloaded.
   * the data will be published to the data() Observable when the data is reloaded.
   */
  public reloadData(): void {
    this.getRuleBlocks().subscribe(data => {
      if (data) {
        this.ruleBlockData = asArray(data);
        data.forEach(block => {
          if (block?.properties?.property) {
            block.properties.property = asArray(block.properties.property);
          }
        });
        this.dataSubject.next(this.ruleBlockData);
      }
    });

    this.getRuleBlockCategories().subscribe(data => {
      if (data) {
        asArray(data)?.forEach(category => {
          this.ruleBlockCategories.add(category);
        });
      }
    });
  }

  /**
   * Get a rule template by it's id. Currently this just searches our list.
   * @param name the name of the rule block.
   */
  public getRuleBlockByName(name: string): Observable<RuleBlock> {
    return this.data().pipe(
      takeOneTruthy(),
      map(ruleBlocks => ruleBlocks.find(block => block.name === name))
    );
  }

  public getRuleBlockCategoryNames(): string[] {
    return Array.from(this.ruleBlockCategories?.values())?.sort(
      (category1, category2) => category1?.order - category2?.order).map(category => category?.name?.toLocaleLowerCase()
    ) ?? [];
  }

  private getRuleBlocks(): Observable<RuleBlock[]> {
    return this.dataAccessService
      .callQueryJson<RuleBlocks>({
        query: 'get_rule_blocks',
        operation: 'getRuleBlocks',
        debugMsg: 'fetched Rule Blocks'
      })
      .pipe(
        map(ruleBlocks => {
          if (!ruleBlocks?.ruleBlock) {
            return [];
          }
          if (ruleBlocks) {
            ruleBlocks.ruleBlock = asArray((ruleBlocks as any).ruleBlock).map(r => this.transformRuleBlock(r));
          }
          this.populateRuleBlockIcons(ruleBlocks.ruleBlock);
          return ruleBlocks.ruleBlock;
        })
      );
  }

  private getRuleBlockCategories(): Observable<RuleBlockCategory[]> {
    return this.dataAccessService
      .callQueryJson<RuleBlockCategories>({
        query: 'get_rule_block_categories',
        operation: 'getRuleBlockCategories',
        debugMsg: 'fetched Rule Block Categories'
      })
      .pipe(
        map(ruleBlockCategories => {
          if (!ruleBlockCategories?.ruleBlockCategory) {
            return [];
          }
          if (ruleBlockCategories) {
            ruleBlockCategories.ruleBlockCategory = asArray((ruleBlockCategories as any).ruleBlockCategory);
          }
          return ruleBlockCategories.ruleBlockCategory;
        })
      );
  }

  private populateRuleBlockIcons(ruleBlocks: RuleBlock[]): void {
    ruleBlocks.forEach(block => {
      this.newIconHandler(block.icon, block.name);
    });
    this.imageService.preloadImageByPath({ keys: [GlobalImageStoreKey.RULE_BLOCK] }).subscribe();
  }

  private transformRuleBlock(ruleBlock: RuleBlock): RuleBlock {
    if (ruleBlock?.inputPorts?.port) {
      ruleBlock.inputPorts.port = asArray(ruleBlock.inputPorts.port);
    }
    if (ruleBlock?.outputPorts?.port) {
      ruleBlock.outputPorts.port = asArray(ruleBlock.outputPorts.port);
    }
    return ruleBlock;
  }

  private newIconHandler(path: string, name: string): ImageHandler {
    let separatorIndex = 0;

    if (path) {
      separatorIndex = path.indexOf('#');
    }

    if (separatorIndex && separatorIndex > 0) {
      return null;
    } else {
      return this.loadImage(path, name);
    }
  }

  private loadImage(fileName: string, name: string): ImageHandler {
    const path = `/rule_blocks/${fileName}`;
    const handler: ImageHandler = new ImageHandler(
      () =>
        new Promise((resolve, reject) => {
          if (!fileName) {
            reject(null);
            return;
          }
          if (typeof fileName === 'object') {
            throw new Error('filename of image must be a string.');
          }
          this.dataAccessService
            .getData({ path, type: 'GET' })
            .toPromise()
            .then(data => {
              if (data) {
                resolve(data as Blob);
              } else {
                reject(null);
              }
            })
            .catch(() => {
              this.logging.warn(`Could not load icon ${fileName}.`);
              reject(null);
            });
        }),
      path
    );

    this.imageService.addGlobalImage(GlobalImageStoreKey.RULE_BLOCK, name, handler);
    return handler;
  }
}
