/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FALSE_STR, TRUE_STR } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';

import { RuleBlock, RuleBlockProperty, RuleBlockPropertyNameEnum, RuleBlockPropertyTypeEnum } from '../../models/rule-block.model';
import { PropertyUpdate, RuleProperty } from '../../models/rule-properties.model';
import { RuleBlockConstraint, RuleBlockPair, RuleEditorRuleBlockProperty, RulePropertyAllowedValues } from '../../models/rule-property-constraint.model';
import { RuleTemplateRuleBlock } from '../../models/rule-template.model';
import { SimPropertiesService, SimProperty, SimPropertyState } from '@oksygen-sim-train-libraries/components-services/sim-properties';

/**
 * Returns the Property with the given name from the given Rule Block, if possible.
 *
 * @param ruleBlock May be null.
 * @param propName  The name of the property of interest.
 */
export function findRuleBlockProperty(ruleBlock: RuleBlock, propName: string): RuleBlockProperty {
  return ruleBlock?.properties?.property?.find(p => p.name === propName);
}

/**
 * Returns the Property with the given name from the given Rule Block, if possible.
 *
 * @param ruleBlock May be null.
 * @param propName  The name of the property of interest.
 */
export function findRuleProperty(ruleBlock: RuleTemplateRuleBlock, propName: string): RuleProperty {
  return ruleBlock?.properties?.property?.find(p => p.name === propName);
}

/**
 * Rule Blocks are tricky.
 * We must note that there are 3 types - Rule Block, Template Rule Block and Scenario Rule Block.
 * Rule Blocks are the most base level building blocks
 * and can be all kinds of things (conditions, variables, object references).
 * A Template Block is built in the rule editor, and can have multiple rule blocks.
 * A Template Block could be "at time foo (rule block 1), set the rain level (rule block 2) to bar".
 * A Scenario Block would then "implement" this template block and fill in the foo and bar.
 * So the Scenario Block would say foo time = 30 seconds, bar rain level = 50 Percent.
 * So our hypothetical scenario would then set the rain level to 50% 30 seconds in.
 * this is all done through the use of "properties".
 * A Rule Blocks property defines meta data for the Template & Scenario Blocks to use.
 * Things like it's display name, it's type, possible values (if an enum), units, etc.
 * A Template Block then may implement the rule block properties.
 * If it does not, the scenario block may implement them.
 */
export abstract class BasePropertyConstraint extends RuleBlockConstraint<RuleBlockPair, RuleEditorRuleBlockProperty, PropertyUpdate[]>  {

  constructor(
    protected simPropertyService: SimPropertiesService,
    protected logging: Logging,
    protected ruleBlocks: RuleBlock[]
  ) { super(); }

  /**
   * Process a rule template rule block to generate a list of of properties that apply to this constraint.
   * Should return an empty array if none of the properties on this block apply to this constraint.
   * For example, a "train property" rule block has no "environment properties", and so an environment constraint
   * should return an empty array.
   */
  abstract override generatePropertyList(block: RuleBlockPair): RuleEditorRuleBlockProperty[];
  /**
   * Update a property. Return the list of affected properties (as the update may cascade to other properties).
   * @param block the block to update
   * @param propertyName the property on the block to update
   * @param value the new value
   */
  abstract override updateProperty(block: RuleBlockPair, propertyName: string, value: number|string|boolean): PropertyUpdate[];

  /**
   * Return a list of blocks this constraint should apply exclusively to.
   * If the list is empty or null we assume the constraint applies to all blocks with the found properties.
   */
  appliesToBlocks(): string[] {
    return [];
  }

  /**
   * Returns whether this constraint applies to the rule block.
   * By default this just checks that all the managedProperties exist on this block.
   */
  constraintApplies(block: RuleBlockPair): boolean {
    const props = this.managedProperties();
    let allExists = true;
    for (const propName of props) {
      const property = this.getProperty(block, propName);
      if (!property) { allExists = false; }
    }
    let blockFound = true;
    const blockNames = this.appliesToBlocks();
    if (!blockNames?.length) {
      return allExists;
    }
    blockFound = !!blockNames.find(name => name === block.ruleBlock.name);
    return blockFound && allExists;
  }

  protected newBlankProperty(name: string): RuleEditorRuleBlockProperty {
    const property = new RuleEditorRuleBlockProperty({ name, enabled: true });
    return property;
  }

  /**
   * Get the ```SimProperty```s that are in this group.
   * NOTE that we only return properties that are scriptable AND have state!
   *
   * @param groupName the sim property group name
   */
  protected getSimPropertyGroup(groupName: string): SimProperty[] {
    const group = this.simPropertyService.getSimPropertyGroupSync(groupName);
    return group.simProperty.filter(prop => prop.isWritable && prop.states?.length > 0);
  }

  /**
   * Get the list of sim properties that are in this group.
   * NOTE that we only return properties that are scriptable AND have state!
   *
   * @param groupName the sim property group name
   */
  protected getSimPropertyGroupProperties(groupName: string): SimPropertyState[] {
    const properties = this.getSimPropertyGroup(groupName).map(sp => {
      const stateAssoc: SimPropertyState = {
        name: sp.name,
        displayName: sp.displayName,
        value: sp.displayName
      };
      return stateAssoc;
    });
    return properties;
  }

  protected booleanSimProperty(): SimPropertyState[] {
    const trueTranslation = this.simPropertyService.translateService.instant(TRUE_STR);
    const falseTranslation = this.simPropertyService.translateService.instant(FALSE_STR);
    const bool: SimPropertyState[] = [
      { name: trueTranslation, displayName: trueTranslation, value: true },
      { name: falseTranslation, displayName: falseTranslation, value: false }
    ];
    return bool;
  }

  protected instructorPromptMessage(): SimPropertyState[] {
    const InformationTranslation = this.simPropertyService.translateService.instant('Information');
    const ValidationTranslation = this.simPropertyService.translateService.instant('Validation');
    const WarningTranslation = this.simPropertyService.translateService.instant('Warning');
    const ErrorTranslation = this.simPropertyService.translateService.instant('Error');
    const value: SimPropertyState[] = [
      { name: InformationTranslation, displayName: InformationTranslation, value: 'Information' },
      { name: ValidationTranslation, displayName: ValidationTranslation, value: 'Validation' },
      { name: WarningTranslation, displayName: WarningTranslation, value: 'Warning' },
      { name: ErrorTranslation, displayName: ErrorTranslation, value: 'Error' }
    ];
    return value;
  }

  /**
   * Generate a scenario rule property that has a key/value property.
   * You should refer to the comment on ```BasePropertyConstraint``` for why this is necessary.
   * In short, a property can be "nested" within another property.
   * In pseudo JSON, "environmentProperty.cloudDensityPercentage = 100"
   * This is structured as key1 = "environment", value1 = "cloudDensity",
   * key2 ="cloudDensity", value2 = "100 Percent".
   * Note that key1 value1 will be referred to as the "name" property.
   * Note that key2 value2 will be referred to as the "value" property.
   * This function will parse the above data structure and produce 1-2 properties depending on the block.
   * 1 property if template was supplied (as can only override the value), 2 if not.
   *
   * @param block the block this property is on
   * @param keyname the property name of the key property
   * @param valueName the property name of the value property (this is usually just "value"), which is the default if unsupplied
   * @param keyValues (optional) list of allowed values for the value property
   */
  protected generateKeyValueProperty(
    block: RuleBlockPair,
    keyname: string,
    valueName: string = RuleBlockPropertyNameEnum.VALUE,
    allowedValues: {allowedKeyValues?: SimPropertyState[]; allowedValueValues?: SimPropertyState[]; displayedKeyValues?: SimPropertyState[]}
  ): RuleEditorRuleBlockProperty[] {
    // WARNING - this is generating properties, so DO NOT try and access block.properties!!
    // Refer to the above comments on ```RuleBlockHandler``` for a high level of what we're doing.
    // first we set the name block property
    const property = this.newBlankProperty(keyname);
    const ruleBlockProperty      = findRuleBlockProperty(block.ruleBlock, keyname);
    const ruleBlockValueProperty = findRuleBlockProperty(block.ruleBlock, valueName);
    const templateNameProperty   = findRuleProperty(block.templateBlock, keyname);
    const templateValueProp      = findRuleProperty(block.templateBlock, valueName);
    if (!ruleBlockProperty || !ruleBlockValueProperty) {
      const err = `rule block ${block.ruleBlock?.displayName}`;
      this.logging.warn(`[RuleblockHandler] ${err} key value block ${keyname} ${valueName} does not exist!`);
      return [];
    }
    let propertyName: string;
    let propertyDisplayName: string;
    let propertyValue: string | number | boolean;
    // order of value priority is rule block < template block
    // start by setting property to rule block
    // then if template is supplied, override.
    if (ruleBlockProperty) {
      propertyName = ruleBlockProperty.name;
      propertyDisplayName = ruleBlockProperty.displayName;
      propertyValue = ruleBlockProperty.defaultValue;
    }

    if (templateNameProperty) {
      propertyValue = templateNameProperty.value;
    }
    property.assignData({ name: propertyName, displayName: propertyDisplayName, value: propertyValue });
    // now we handle the value block property
    const valueProperty = this.newBlankProperty(valueName);
    const valuePropertyName = ruleBlockValueProperty.name;
    const valuePropertyDisplayName = ruleBlockValueProperty.displayName;
    let valuePropertyValue: string | number | boolean;
    if (templateValueProp) {
      valuePropertyValue = templateValueProp.value;
    } else {
      valuePropertyValue = ruleBlockValueProperty.defaultValue;
    }
    valueProperty.assignData({ name: valuePropertyName, displayName: valuePropertyDisplayName, value: valuePropertyValue });
    // now we can set the allowed values of each property (note there may be none)
    const properties = [ property, valueProperty ];
    if (allowedValues) {
      this.setAllowedValues(property, allowedValues.allowedKeyValues, allowedValues.displayedKeyValues);
      this.setAllowedValues(valueProperty, allowedValues.allowedValueValues);
    }

    // finally, we populate the list of property values from sim properties
    properties.forEach(p => {
      if (p.name && !p.allowedValues) {
        const simProp = this.simPropertyService.getSimPropertySync(p.name);
        if (simProp) {
          // if it doesn't have state, shouldn't be a dropdown
          if (simProp?.states?.length > 0) {
            p.allowedValues = new RulePropertyAllowedValues(simProp.states);
          }
        }
      }
    });
    // shouldn't be able to set value if property isn't valid (for example if it's still blank)
    if (!property.isValid()) {
      properties[1].assignData({enabled: false});
    }
    return properties;
  }

  private setAllowedValues(
    property: RuleEditorRuleBlockProperty, allowedValues: SimPropertyState[], displayedValues?: SimPropertyState[]
  ): void {
    if (allowedValues?.length > 0) {
      property.allowedValues = new RulePropertyAllowedValues(allowedValues, displayedValues);
    }
  }

  /**
   * Simple block properties are just key value.
   * This method will read through the rule, template and scenario blocks to generate
   * the appropriate property.
   *
   * @param block the block this property is on
   * @param keyname the "name" of this property
   * @param allowedValues (optional) a list of values it's allowed to have
   * @param displayedValues (optional) a list of values it's allowed to display
   */
  generateProperty(
    block: RuleBlockPair,
    keyname: string,
    allowedValues?: SimPropertyState[],
    displayedValues?: SimPropertyState[]
  ): RuleEditorRuleBlockProperty {
    // WARNING - this is generating properties, so DO NOT try and access block.properties!!
    const property = this.newBlankProperty(keyname);
    // the rule block defined in the template may supply a default
    const ruleBlockProperty = findRuleBlockProperty(block?.ruleBlock,  keyname);
    let propertyName: string;
    let propertyDisplayName: string;
    let propertyValue: string | number | boolean;
    let propertyDefault: string | number | boolean;
    let propertyType: RuleBlockPropertyTypeEnum;
    let propertyDefaultUnits: string;
    // first set everything to what's defined in the rule block
    if (ruleBlockProperty) {
      propertyName = ruleBlockProperty.name;
      propertyDisplayName = ruleBlockProperty.displayName;
      propertyDefault = ruleBlockProperty.defaultValue;
      propertyValue = ruleBlockProperty.defaultValue;
      propertyType = ruleBlockProperty.propertyType;
      propertyDefaultUnits = ruleBlockProperty.defaultUnits;
    }
    // if (!property.defaultValue) { property.defaultValue = property.value; }
    // now check the template and override with anything the template has specified
    const templateNameProperty = findRuleProperty(block?.templateBlock, keyname);
    if (templateNameProperty) {
      propertyValue = templateNameProperty.value;
    }
    // finally, we need to get our list of options (if they exist)
    if (allowedValues) {
      property.allowedValues = new RulePropertyAllowedValues(allowedValues, displayedValues);
    }
    if (property.name && !allowedValues) {
      const simProp = this.simPropertyService.getSimPropertySync(property.name);
      if (simProp) {
        property.allowedValues = new RulePropertyAllowedValues(simProp.states, displayedValues);
      }
    }

    property.assignData({
      name: propertyName,
      displayName: propertyDisplayName,
      defaultValue: propertyDefault,
      value: propertyValue,
      type: propertyType,
      defaultUnits: propertyDefaultUnits
    });

    return property;
  }

  getProperty(block: RuleBlockPair, propName: string): RuleBlockProperty {
    const ruleBlockProperty = block?.ruleBlock?.properties?.property
    .find(p => p.name === propName);
    return ruleBlockProperty;
  }

  getPropertyDefault(block: RuleBlockPair, propName: string): string | number | boolean {
    // the rule block defined in the template may supply a default
    const ruleBlockProperty = this.getProperty(block, propName);
    let propertyValue: string | number | boolean;
    if (ruleBlockProperty) {
      propertyValue = ruleBlockProperty.defaultValue;
    }
    return propertyValue;
  }

  // /**
  //  * Updates a property.
  //  * Note that if the scenario block doesn't exist, it must also be created.
  //  *
  //  * @param block the block this property is on
  //  * @param propertyName the name of the property to update
  //  * @param value the new value
  //  */
  // protected updateTemplateBlockSimple(
  //   block: RuleBlockPair,
  //   propertyName: string,
  //   value: number|string|boolean
  // ): void {
  //   this.upsertTemplateBlock(block);
  //   this.upsertTemplateBlockProperty(block, propertyName, value);
  //   return;
  // }

  // /**
  //  * If our block doesn't have the required scenario block, append it with empty properties.
  //  * Does nothing if the block already exists.
  //  *
  //  * @param block our rule block to work with
  //  */
  // protected upsertTemplateBlock(block: RuleBlockPair): RuleTemplateRuleBlock {
  //   // if (!block.templateBlock) {
  //   //   block.templateBlock = { id: block.templateBlock.id, properties: { property: [] }};
  //   // }
  //   if (!block.templateBlock.properties) {
  //     block.templateBlock.properties = { property: [] };
  //   }
  //   if (!block.templateBlock.properties.property) {
  //     block.templateBlock.properties.property = [];
  //   }
  //   return block.templateBlock;
  // }

  // /**
  //  * Upsert a scenario block property.
  //  *
  //  * @param block the block to upsert
  //  * @param name the name of the property we're updating
  //  * @param value the new value of the property
  //  */
  // protected upsertTemplateBlockProperty(
  //   block: RuleBlockPair,
  //   name: string,
  //   value: string|number|boolean
  // ): RuleProperty {
  //   this.upsertTemplateBlock(block);
  //   const property = block.templateBlock.properties.property.find(p => p.name === name);
  //   if (!property) {
  //     const newProperty: RuleProperty = {
  //       name,
  //       value
  //     };
  //     block.templateBlock.properties.property.push(newProperty);
  //     return newProperty;
  //   } else {
  //     property.value = value;
  //     return property;
  //   }
  // }

  /**
   * Returns whether the value has been "set". "" null and undefined are false, everything else (including false and 0) are true.
   * @param value a value to check - can be anything.
   */
  isNotEmpty(value: any): boolean {
    return value !== '' && value !== undefined && value !== null;
  }
}
