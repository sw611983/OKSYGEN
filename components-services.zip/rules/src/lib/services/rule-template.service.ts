/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

import { asArray, SelfCompletingObservable, takeOneTruthy } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { AbstractDataService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { RuleBlockService } from './rule-block.service';
import { RuleTemplate, RuleTemplates } from '../models/rule-template.model';
import { FromRuleTemplate, FromRuleTemplates, transformFromRuleTemplate } from '../models/rule-template-xml.model';
import { Version, versionCompare, versionLatest } from '@oksygen-sim-train-libraries/components-services/versioning';

@Injectable()
export class RuleTemplateService extends AbstractDataService<RuleTemplate[]> {

  private ruleTemplateData: RuleTemplate[] = [];
  constructor(
    logging: Logging,
    registry: Registry,
    dataAccessService: DataAccessService,
    private blockService: RuleBlockService
  ) {
    super(logging, registry, dataAccessService);
    this.initialise();
  }

  // TODO should use a cache eviction mechanism (e.g. comparing time of last update to latest)
  // to avoid unnecessary data transfer.
  // TODO this should be deprecated once we make rule editor.
  /**
   * Request the data to be reloaded.
   * the data will be published to the data() Observable when the data is reloaded.
   */
  public reloadData(): void {
    this.blockService.data().pipe(
      takeOneTruthy(),
      switchMap(blocks => this.getRuleTemplates())
    ).subscribe(data => {
      if (data) {
        this.ruleTemplateData = asArray(data.ruleTemplate);
        this.ruleTemplateData.forEach(template => {
          // The following line make sure that the display name is a string. This is because of names like '0' and '1' which are integer...
          template.displayName = template?.displayName?.toString();
          template?.ruleBlocks?.ruleBlock?.forEach(block => {
            if (block?.properties?.property) {
              block.properties.property = asArray(block.properties.property);
            }
          });
        });
        this.dataSubject.next(this.ruleTemplateData);
      }
    });
  }

  /**
   * Get a rule template by it's id. Currently this just searches our list.
   * TODO this should call a XQ that gets the specified rule template from the DB.
   *
   * @param id the id of the template.
   * @param version (option) specify a specific version you want to get - default latest
   */
  public getRuleTemplateById(id: string, version?: Version): SelfCompletingObservable<RuleTemplate> {
    return this.data().pipe(
      map(templates => templates?.filter(t => t.id === id) ),
      map(templates => {
        const versions = templates.map(template => template.version);
        const searchVersion = version ?? versionLatest(versions);
        return templates.find(template => versionCompare(template.version, searchVersion) === 0);
      })
    );
  }

  public override latestVersionData(): Observable<RuleTemplate[]> {
    return this.data().pipe(
      map(ruleTemplates => {
        const templates: RuleTemplate[] = [];
        ruleTemplates?.forEach(ruleTemplate => {
          // add new templates. If template is already added, use the one with the latest version.
          const existingTemplate = templates.find(rt => rt.id === ruleTemplate.id);
          if (!existingTemplate) {
            templates.push(ruleTemplate);
          } else {
            if(versionCompare(ruleTemplate.version, existingTemplate.version) === 1) {
              const index = templates.findIndex(rt => rt.id === ruleTemplate.id);
              templates[index] = ruleTemplate;
            }
          }
        });
        return templates;
      })
    );
  }

  /**
   * Synchronously check if the version of a rule template is the latest version.
   * @param id the id of the template to check
   * @param version the version you are using
   */
  isLatestVersion(id: string, version: Version|string): boolean {
    const scenarioTemplates = this.ruleTemplateData.filter(rt => rt.id === id);
    const latest = versionLatest(scenarioTemplates.map(st => st.version));
    return versionCompare(latest, version) === 0;
  }

  /**
   * TODO when we make rule editor, this will need to be deprecated for getRuleTemplateById(id).
   * Because once users can create their own, there could be 1000s, so can't load them all on startup.
   */
  private getRuleTemplates(): Observable<RuleTemplates> {
    return this.dataAccessService
      .callQueryJson<FromRuleTemplates>({
        query: 'get_rule_templates',
        operation: 'getRuleTemplates',
        debugMsg: 'fetched Rule Templates'
      })
      .pipe(
        map(xmlRuleTemplates => {
          const ruleTemplates: RuleTemplates = {ruleTemplate: []};
          if (xmlRuleTemplates) {
            xmlRuleTemplates.ruleTemplate = asArray(xmlRuleTemplates?.ruleTemplate);
            xmlRuleTemplates?.ruleTemplate?.forEach(rTemplates => {
              const ruleTemplate = this.transformRuleTemplate(rTemplates);
              ruleTemplates.ruleTemplate.push(ruleTemplate);
            });
          }
          return ruleTemplates;
        })
      );
  }

  private transformRuleTemplate(ruleTemplate: FromRuleTemplate): RuleTemplate {
    return transformFromRuleTemplate(ruleTemplate);
  }
}
