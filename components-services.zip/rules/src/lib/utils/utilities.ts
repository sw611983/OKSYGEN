/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { DragFeedback } from '@oksygen-common-libraries/common';
import { RuleTemplate } from '../models/rule-template.model';

export function isDraggedRuleTemplate(data: any): boolean {
  return data && data.type && data.type.toLowerCase() === 'ruletemplateitem';
}

// FIXME always returns the same result; do we need this at all?
export function handleDraggedRuleTemplate(data: any, ruleTemplates: RuleTemplate[]): DragFeedback {
  // const ruleTemplate = data.data as RuleTemplate;
  // currently want to support multiple rule templates of the same type
  const item: any = undefined; // ruleTemplates.find(m => m.id === ruleTemplate.id);

  let result: DragFeedback = {
    allowed: false,
    message: t('Rule template already exists')
  };

  if (!item) {
    result = {
      allowed: true,
      message: t('Add Rule Template')
    };
  }

  return result;
}
