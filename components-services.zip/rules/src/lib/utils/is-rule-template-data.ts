/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/**
 * Checks if the given data (possibly from a specially encoded drag action) looks like a RuleTemplate.
 *
 * @param maybeRuleData a RuleTemplate or a RuleTemplate that has been mangled for inspection during drag.
 */
 export function isRuleTemplateData(maybeRuleData: any): boolean {
  if (!maybeRuleData) {
    return false;
  }

  // Note that any tests for properties with capital letters need to also test for a similar lowercase property,
  // due to potential mangling during a drag.
  if (maybeRuleData.displayName && maybeRuleData.ruleBlocks) {
    return true;
  }

  return false;
}
