/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainVersionModule } from '@oksygen-sim-train-libraries/components-services/versioning';

import { RuleListItemComponent } from './components/rule-list-item/rule-list-item.component';
import { RuleTemplateListItemComponent } from './components/rule-template-list-item/rule-template-list-item.component';
import { RuleItemComponent } from './components/rules-panel/rule-item/rule-item.component';
import { RuleBlockService } from './services/rule-block.service';
import { RuleTemplateService } from './services/rule-template.service';
import { RuleService } from './services/rule.service';
import { SimPropertiesService } from '@oksygen-sim-train-libraries/components-services/sim-properties';

const components = [
  RuleListItemComponent,
  RuleTemplateListItemComponent,
  RuleItemComponent
  // RulesPanelComponent
];

@NgModule({
  declarations: components,
  imports: [
    RouterModule,
    CommonModule,
    DragDropModule,
    OksygenMaterialComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    // this is ugly to repeat everywhere, but it's the only way for this to be properly initialised
    OksygenMaterialTranslateModule.forChild(),
    OksygenSimTrainCommonModule,
    OksygenSimTrainVersionModule
    // OksygenSimTrainComponentsServicesModule
  ],
  exports: components,
  providers: [SimPropertiesService, RuleTemplateService, RuleBlockService, RuleService]
})
export class OksygenSimTrainRuleModule {}
