/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { MatRipple } from '@angular/material/core';
import { MAT_SLIDE_TOGGLE_DEFAULT_OPTIONS } from '@angular/material/slide-toggle';

import { UserScenarioFavouritesManager } from '@oksygen-sim-core-libraries/components-services/favourites';
import { RuleItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';

@Component({
  selector: 'oksygen-rule-item',
  templateUrl: './rule-item.component.html',
  styleUrls: ['./rule-item.component.scss'],
  providers: [{ provide: MAT_SLIDE_TOGGLE_DEFAULT_OPTIONS, useValue: { disableToggleValue: true }}]
})
export class RuleItemComponent {
  readonly TRIGGER_DELAY_MS = 250;

  @Input() rule: RuleItem;

  @Input() set triggerRipple(value: boolean) {
    if (value) {
      setTimeout(() => this.ripple.launch({}), this.TRIGGER_DELAY_MS);
    }
  }

  @Input() userScenarioFavouritesManager: UserScenarioFavouritesManager;

  @Input() disabled = false;

  @Output() readonly toggleRuleActive = new EventEmitter<void>();

  @ViewChild('ripple') ripple: MatRipple;

  constructor(public element: ElementRef) {}

  favourite(event: Event): void {
    event?.stopPropagation();
    this.userScenarioFavouritesManager.updateRule(this.rule.id);
  }
}
