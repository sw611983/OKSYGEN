/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Input } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

/**
 * Rules Panels should extend this abstract class.
 * Note this does not have an implementation itself!
 * A rules panel is designed to show information about rules, which is generally a combination of a list and details view.
 */
@Component({template: ''})
export abstract class RulesPanelComponent {
  // FIXME needs typing!!!
  /** Input list of rules of type ```Rule``` or ```ScenarioRule``` */
  @Input() rules$!: Observable<any[]>;
  /** (optional) selected rule, of type ```Rule``` or ```ScenarioRule```, to support a list & detailed view */
  @Input() selectedRule$?: BehaviorSubject<any>;
}
