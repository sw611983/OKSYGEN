/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, Output } from '@angular/core';

import { RuleItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';

/**
 * Changing the total height of this component impacks the calculation done in FavouritesPanelComponent
 * Please verify that this calculation is still appropriate if changing this component
 */
@Component({
  selector: 'oksygen-rule-list-item',
  templateUrl: './rule-list-item.component.html',
  styleUrls: ['./rule-list-item.component.scss']
})
export class RuleListItemComponent {
  @Input() rule: RuleItem;

  @Output() readonly favouriteClick: EventEmitter<RuleItem> = new EventEmitter();

  constructor() {}

  favourite(event?: Event): void {
    event?.stopPropagation();
    this.favouriteClick.emit(this.rule);
  }
}
