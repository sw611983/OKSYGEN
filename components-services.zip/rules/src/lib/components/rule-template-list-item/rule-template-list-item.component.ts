/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, effect, ElementRef, input } from '@angular/core';

import { RuleTemplate } from '../../models/rule-template.model';
import { enableDragHandlingAndHandleDragImage } from '@oksygen-sim-train-libraries/components-services/component-library';

@Component({
  selector: 'oksygen-rule-template-list-item',
  templateUrl: './rule-template-list-item.component.html',
  styleUrls: ['./rule-template-list-item.component.scss']
})
export class RuleTemplateListItemComponent {
  ruleTemplate = input.required<RuleTemplate>();

  constructor(private host: ElementRef) {
    effect(() => {
      enableDragHandlingAndHandleDragImage(this.host, 'rule_editor', { type: 'RuleTemplateItem', data: this.ruleTemplate() });
    });
  }
}
