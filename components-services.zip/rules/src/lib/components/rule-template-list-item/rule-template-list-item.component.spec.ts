/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { RuleTemplateListItemComponent } from './rule-template-list-item.component';

describe('RuleTemplateListItemComponent', () => {
  let component: RuleTemplateListItemComponent;
  let fixture: ComponentFixture<RuleTemplateListItemComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [RuleTemplateListItemComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleTemplateListItemComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('ruleTemplate', null);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
