/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { cloneDeep, isNil } from 'lodash';
import { BehaviorSubject, forkJoin, Observable, Subject } from 'rxjs';
import { distinctUntilChanged, first, map, startWith, throttleTime } from 'rxjs/operators';

import { filterTruthy, ImageHandler, SelfCompletingObservable, shareReplayOne } from '@oksygen-common-libraries/common';
import { BaseDataManager } from '@oksygen-sim-core-libraries/components-services/data-services';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { Image } from '@oksygen-sim-train-libraries/components-services/common';

import { objectTypeIconName } from '../helpers/mapbox.source';
import { ObjectTypeContainer } from '../models/object-type.model';
import { ObjectContainer, selectedObjectContainerComparator } from '../models/object.model';

export abstract class ObjManager extends BaseDataManager<Array<ObjectContainer>> {
  private static readonly OBJECT_THROTTLING = 300;

  protected objectSubject: BehaviorSubject<Array<ObjectContainer>> = new BehaviorSubject(null);
  protected objectUpdated: Subject<Array<ObjectContainer>> = new Subject();
  protected objectInserted: Subject<Array<ObjectContainer>> = new Subject();
  protected objectDeleted: Subject<Array<ObjectContainer>> = new Subject();
  protected unprocessedUpdates: Map<number | string, LngLatCoord[]> = new Map();

  constructor(protected objectTypes$: Observable<Array<ObjectTypeContainer>>) {
    super();
  }

  abstract updateObjectAuto(id: number | string, isAuto: boolean): void;
  abstract updateObjectDisplayOverrideState(id: number | string, isOverriden: boolean, state: string|number): void;
  abstract updateObjectContainerState(id: number | string, state: string | number): void;
  abstract updateObjectContainerProperty(id: number | string, propertyKey: string, propertyValue: string | number): void;

  /**
   * Loads a list of images. Returns as observable that fires once they've all loaded.
   * The observable will fire with the images that loaded successfully.
   * This could be made more generic, and needs to handle timeouts.
   *
   * @param images a list of images to load
   */
  static initFeatureImages(images: ImageHandler[]): Observable<ImageData[]> {
    return new Observable<ImageData[]>(obs => {
      if (!images?.length) {
        return;
      }
      const observables: SelfCompletingObservable<ImageData>[] = [];
      for (const image of images) {
        observables.push(image.asImageDataObservable());
      }
      forkJoin(observables).subscribe(
        allImages => {
          const loadedImages = allImages.filter(img => !isNil(img));
          obs.next(loadedImages);
          obs.complete();
        },
        error => {
          // TODO error handling
        }
      );
    });
  }

  static getSelectedFeatureImages(features: Array<ObjectContainer>): ImageHandler[] {
    const images: ImageHandler[] = [];
    if (!features) {
      return images;
    }
    // doing this the naive way to start as a POC
    for (const feature of features) {
      const img = feature?.selectedIcon?.small;
      if (img && !images.find(i => i === img)) {
        images.push(img);
      }
    }
    return images;
  }

  override destroy(): void {
    this.objectSubject.complete();
    this.objectInserted.complete();
    this.objectUpdated.complete();
    this.objectDeleted.complete();
  }

  /**
   * @deprecated
   */
  data(): Observable<Array<ObjectContainer>> {
    return this.data$;
  }

  get data$(): Observable<Array<ObjectContainer>> {
    return this.objectSubject.pipe(shareReplayOne());
  }

  /**
   * @returns all the object types as defined in the database
   */
  types$(): Observable<Array<ObjectTypeContainer>> {
    return this.objectTypes$;
  }

  /**
   * @returns an observable of the unique object types used based on the objects loaded
   */
  getObjectTypes$(): Observable<Array<ObjectTypeContainer>> {
    return this.objectSubject.pipe(
      filterTruthy(),
      // throttle the speed of incoming changes, prior to processing
      throttleTime(ObjManager.OBJECT_THROTTLING, undefined, { leading: true, trailing: true }),
      // BROKEN: as we next the same object, xlength ALWAYS === y.length
      // simple filtering so we don't update if objects have updated
      // distinctUntilChanged((x, y) => x.length === y.length),
      map(objects => {
        const types: Array<ObjectTypeContainer> = [];
        objects.forEach(object => {
          if (!types.includes(object.objectType)) {
            types.push(object.objectType);
          }
        });

        return types;
      }),
      shareReplayOne()
    );
  }

  /**
   * Subscribe to changes to an object.
   * Use the useOriginal param to specify if you want the object itself or a clone of the object.
   *
   * @param id the id of the object to subscribe to
   * @param useOriginal (optional - default true) return the original object instead of a clone
   */
  getObject$(id: string | number, useOriginal: boolean = true): Observable<ObjectContainer> {
    return this.objectSubject.pipe(
      filterTruthy(),
      map(objects => {
        const object = objects.find(feature => feature.id === id);
        if (useOriginal) {
          return object;
        }
        // FIXME this is a bandaid which should not be necessary
        // the issue is object-basex/comms.manager will process and modify the object reference
        // before we get here. This means that the next distinct check won't work
        // because it's all the same object, hence prev will always === curr.
        return object ? cloneDeep(object) : null;
      }),
      distinctUntilChanged(selectedObjectContainerComparator),
      shareReplayOne()
      // throttleTime(ObjManager.OBJECT_THROTTLING, undefined, { leading: true, trailing: true })
    );
  }

  /**
   * [DEPRECATED] Synchronously get a feature.
   * Avoid using this on new code - try and write reactive code where possible.
   *
   * @param id the id of the feature
   * @deprecated
   */
  public getObject(id: number): ObjectContainer {
    let model: ObjectContainer = null;
    const sub = this.getObject$(id)
      .pipe(first())
      .subscribe(feature => {
        model = feature;
      });
    sub.unsubscribe();
    return model;
  }

  /**
   * Subscribe to changes to an object.
   * Use the useOriginal param to specify if you want the object itself or a clone of the object.
   *
   * @param id the id of the object to subscribe to
   * @param useOriginal (optional - default true) return the original object instead of a clone
   */
  getObjectByName$(name: string, useOriginal: boolean = true): Observable<ObjectContainer> {
    return this.objectSubject.pipe(
      filterTruthy(),
      map(objects => {
        const object = objects.find(feature => feature.name === name);
        if (useOriginal) {
          return object;
        }
        // FIXME this is a bandaid which should not be necessary
        // the issue is object-basex/comms.manager will process and modify the object reference
        // before we get here. This means that the next distinct check won't work
        // because it's all the same object, hence prev will always === curr.
        return object ? cloneDeep(object) : null;
      }),
      distinctUntilChanged(selectedObjectContainerComparator),
      shareReplayOne(),
      throttleTime(ObjManager.OBJECT_THROTTLING, undefined, { leading: true, trailing: true })
    );
  }

  /**
   * [DEPRECATED] Synchronously get a feature by it's name.
   * Avoid using this on new code - try and write reactive code where possible.
   *
   * @param id the id of the feature
   * @deprecated
   */
  public getObjectByName(name: string): ObjectContainer {
    let model: ObjectContainer = null;
    const sub = this.getObjectByName$(name)
      .pipe(first())
      .subscribe(feature => {
        model = feature;
      });
    sub.unsubscribe();
    return model;
  }

  /**
   * Get all objects. If anything changes you'll get em all again!
   * Prefer getFeatureContainer$(id) if you just want 1 feature & it's relevant updates.
   * This is throttled to every 300ms.
   */
  getObjectContainersOfType$(type: string): Observable<Array<ObjectContainer>> {
    // TODO only ping an update when one of the contained object is updated!
    return this.objectSubject.pipe(
      filterTruthy(),
      map(objects => objects.filter(f => f.objectType.name === type)),
      distinctUntilChanged(),
      shareReplayOne(),
      throttleTime(ObjManager.OBJECT_THROTTLING, undefined, { leading: true, trailing: true })
    );
  }

  /**
   * A stream of updated objects.
   */
  getUpdatedObject$(): Observable<Array<ObjectContainer>> {
    return this.objectUpdated.pipe();
  }

  /**
   * A stream of deleted objects (only scenario objects can be deleted).
   */
  getDeletedObject$(): Observable<Array<ObjectContainer>> {
    return this.objectDeleted.pipe();
  }

  /**
   * A stream of inserted objects.
   * Beware using this in combineLatest - this will be re-emitted when your other observables emit.
   * @param emitInitialList (default true) whether to emit the initial list of objects when you first subscribe.
   */
  getInsertedObject$(emitInitialList = true): Observable<ObjectContainer[]> {
    if (emitInitialList) {
      return this.objectInserted.pipe(
        startWith(this.objectSubject.getValue() ?? [])
      );
    }
    return this.objectInserted.pipe();
  }

  consolidateObjectTypeImages(objectTypes: Array<ObjectTypeContainer>, images: Image[], additionalImages?: Image[]): Image[] {
    if (!images || !objectTypes) {
      return [];
    }

    const loadImages: Image[] = [];
    if (additionalImages) {
      loadImages.push(...additionalImages);
    }

    const uniquePush = (arr: Image[], val: Image): void => {
      const found = arr.find(v => v.name === val.name);
      if (!found) {
        arr.push(val);
      }
    };

    objectTypes.forEach(type => {
      const typeDefaultIconName = objectTypeIconName(type, 'S');
      let image = images.find(i => i.name === typeDefaultIconName);

      if (image) {
        uniquePush(loadImages, image);
      }

      type.states.forEach(state => {
        const stateIconName = objectTypeIconName(type, 'S', state.id);
        image = images.find(i => i.name === stateIconName);

        if (image) {
          uniquePush(loadImages, image);
        }
      });
      type.mapOverrides?.icon?.icons?.icon?.forEach(img => {
        image = images.find(i => i.name === `/Features/${img.smallIcon}`);
        if (image) {
          uniquePush(loadImages, image);
        }
      });
    });

    return loadImages;
  }
}
