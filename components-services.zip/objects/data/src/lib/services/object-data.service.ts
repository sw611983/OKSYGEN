/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { BehaviorSubject, Observable } from 'rxjs';
import { bufferTime, filter, map } from 'rxjs/operators';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ObjectMessageIds, SocketMessage, SocketService } from '@oksygen-sim-core-libraries/components-services/data-services';

import { ObjectWorldGeometry } from '../models/object.model';

// FIXME raw interfaces should be moved to a separate file, currently at risk of circular deps
export interface RawFeatures {
  features: RawFeature[];
}

export interface RawFeature {
  id: number;
  name: string;
  type: string;
  properties: RawFeatureProperties;
  trackAssociations: RawTrackAssociation[];
  geometry: ObjectWorldGeometry;
}

export interface RawTrackAssociation {
  id: number;
  segmentId?: number;
  segmentOffset?: number;
  orientation?: number;
}

export interface RawFeatureProperties {
  State?: string | number;
  'User State'?: string | number;
  'Automatic State'?: string | number;
  [property: string]: string | number;
}

// FIXME batching should be implemented for all sockets - probably should move to SocketService.
// one concern with batching is that we override previous updates to the same property
// if they happen in the same window. So if comms sends us
// { MODULE_STATE: UNLOADED }
// { MODULE_STATE: IDLE }
// at the same time, the UI will only see the IDLE update, so any processing that needs to
// happen on UNLOADED will be missed. You can avoid this by switching off batching
// but if this socket is spammy for other properties we may need more fine grained control.
/**
 * Supplies {@link RawFeature} data for Sessions running on a particular System.
 *
 * @param batchRateMs (optional) whether to batch process socket messages, and if so, how long in ms.
 */
// TODO When we're feeling fancy this should extend a generic interface so we can swap out SocketService if needed.
export class ObjectDataService extends SocketService<ObjectMessageIds, RawFeatures> {
  private rawDataSubject: BehaviorSubject<RawFeatures> = new BehaviorSubject(null);

  constructor(registry: Registry, logger: Logging, systemNumber: number, serverStatus$: Observable<boolean>, private batchRateMs?: number) {
    super(
      registry,
      logger,
      registry.getString(['featureData', 'url'], undefined, new Map<string, string>([['systemNumber', `${systemNumber}`]])),
      'ObjectDataService',
      serverStatus$
    );
  }

  /**
   * Emits {@link RawFeature}s; emits immediately on subscription.
   * TODO handle if socket never connects, ie never get second emit of features after the null.
   */
  public features$(): Observable<RawFeatures> {
    if (!this.batchRateMs) {
      return this.rawDataSubject.asObservable();
    }
    // TODO 1: do this out of zone
    // TODO 2: bufferTime() is essentially a setInterval() - replace it with a custom buffer queue
    // to avoid spam processing of nothing every interval when nothing has changed
    return this.rawDataSubject.pipe(
      bufferTime(this.batchRateMs),
      filter(updates => !!updates?.length),
      map(updates => {
        if (updates.length === 1) {
          return updates[0];
        }
        const features: RawFeature[] = [];
        for (const update of updates) {
          if (update?.features) {
            features.push(...update.features);
          }
        }
        return { features };
      })
    );
  }

  public setFeatureState(featureId: number | string, state: RawFeatureProperties): void {
    const message: SocketMessage<ObjectMessageIds, any> = {
      messageId: ObjectMessageIds.REQUEST_UPDATE_OBJECTS,
      message: { features: [{ id: featureId, properties: state }] }
    };
    this.socket$.next(message);
  }

  public setFeatureProperty(featureId: number | string, propertyKey: string, propertyValue: string|number): void {
    const propertyUpdate: any = {};
    propertyUpdate[propertyKey] = propertyValue;
    const message: SocketMessage<ObjectMessageIds, any> = {
      messageId: ObjectMessageIds.REQUEST_UPDATE_OBJECTS,
      message: { features: [{ id: featureId, properties: propertyUpdate }] }
    };
    this.socket$.next(message);
  }

  protected onOpenSocket(): void {
    if (!this.socket$) {
      return;
    }
    const message: SocketMessage<ObjectMessageIds, any> = {
      messageId: ObjectMessageIds.REQUEST_OBJECTS,
      message: { interval: 1 }
    };
    this.socket$.next(message);
  }

  protected onMessage(message: SocketMessage<ObjectMessageIds, RawFeatures>): void {
    this.rawDataSubject.next(message.message);
  }

  protected onSocketError(error: any): void {
    if (this.lastConnectionClosedClean) {
      this.logger.warn('An error occured in the feature socket: ', JSON.stringify(error));
    }
  }
}
