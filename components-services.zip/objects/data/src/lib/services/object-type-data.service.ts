/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { isNil } from 'lodash';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  computeIfAbsent,
  filterTruthy,
  ImageHandler,
  SelfCompletingObservable,
  shareReplayOne,
  SuperCalled
} from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ImageService } from '@oksygen-sim-train-libraries/components-services/common';

import { IObjectTypeDataService } from '../interfaces/object-type-data.interface';
import { DataAccessFeatureTypeDatas } from '../models/data-access-object-type-data.model';
import { ObjectTypeContainer } from '../models/object-type.model';
import { BaseObjectTypeDataService, PlacementKey } from './base-object-type-data.service';

// The following interfaces describe how data is supposed to come out of the database.
// This class will take these structures and massage them into more useful ones for the rest of the application to use.

@Injectable()
export class ObjectTypeDataService extends BaseObjectTypeDataService implements IObjectTypeDataService {
  protected objectTypes$: Observable<Array<ObjectTypeContainer>>;

  protected placementSubjects = new Map<PlacementKey, BehaviorSubject<Array<ObjectTypeContainer>>>();

  protected placementMapSubjects = new Map<PlacementKey, BehaviorSubject<Map<string, ObjectTypeContainer>>>();

  constructor(logging: Logging, registry: Registry, imageService: ImageService, protected readonly dataAccessService: DataAccessService) {
    super(logging, registry, imageService);

    this.objectTypes$ = this.typesMap$().pipe(
      filterTruthy(),
      map(mapType => Array.from(mapType.values()))
    );

    this.initialise();
  }

  protected override destroy(): SuperCalled {
    this.placementSubjects.forEach(value => value.complete());
    this.placementSubjects.clear();

    return super.destroy();
  }

  public typesMap$(): Observable<Map<string, ObjectTypeContainer>> {
    return this.dataSubject.pipe(shareReplayOne());
  }

  public types$(): Observable<Array<ObjectTypeContainer>> {
    return this.objectTypes$;
  }

  public placementTypes$(params: PlacementKey = {}): Observable<Array<ObjectTypeContainer>> {
    if (isNil(params.domain)) {
      params.domain = 'editor';
    }

    if (isNil(params.domain)) {
      params.key = 'scenario';
    }

    const placementTypesSubject = computeIfAbsent(
      this.placementSubjects,
      params,
      () => new BehaviorSubject<Array<ObjectTypeContainer>>(this.updatePlacementObjectTypes(params, this.dataSubject.getValue()))
    );

    return placementTypesSubject.pipe(shareReplayOne());
  }

  public placementTypesMap$(params: PlacementKey = {}): Observable<Map<string, ObjectTypeContainer>> {
    if (isNil(params.domain)) {
      params.domain = 'editor';
    }

    if (isNil(params.domain)) {
      params.key = 'scenario';
    }

    const placementTypesMapSubject = computeIfAbsent(this.placementMapSubjects, params, () => {
      const objectTypes = this.updatePlacementObjectTypes(params, this.dataSubject.getValue());

      const objectTypesMap = new Map<string, ObjectTypeContainer>();

      objectTypes.forEach(type => objectTypesMap.set(type.name, type));

      return new BehaviorSubject<Map<string, ObjectTypeContainer>>(objectTypesMap);
    });

    return placementTypesMapSubject.pipe(shareReplayOne());
  }

  public override reloadData(): SelfCompletingObservable<SuperCalled> {
    return super.reloadData().pipe(
      map(result => {
        this.placementSubjects.forEach((placementSubject, params) =>
          placementSubject.next(this.updatePlacementObjectTypes(params, this.dataSubject.getValue()))
        );

        this.readySubject.next(true);
        return result;
      })
    );
  }

  protected createImageHandler(fileName: string, path: string): ImageHandler {
    return new ImageHandler(
      () =>
        new Promise((resolve, reject) => {
          if (!fileName) {
            reject(null);
            return;
          }
          if (typeof fileName === 'object') {
            throw new Error('filename of image must be a string.');
          }
          this.dataAccessService
            .getData({ path, type: 'GET' })
            .toPromise()
            .then(data => {
              if (data) {
                if ((data as Blob).type === 'application/xml') {
                  this.logging.warn(`[ObjectTypeDataService] invalid object type image reference detected! Filename: ${fileName}`);
                  reject(null);
                } else {
                  resolve(data as Blob);
                }
              } else {
                reject(null);
              }
            })
            .catch(() => {
              this.logging.warn(`Could not load icon ${fileName}.`);
              reject(null);
            });
        }),
      path
    );
  }

  /**
   * Sends a request to the database to extract some data from a zip file it has and send it back.
   *
   * @param zipfile The path to and name of the zip file.
   * @param filename  The name of the file within the zip.
   */
  // TODO This may be useful enough to be promoted into a superclass.
  protected extractFromZip(zipfile: string, filename: string): Observable<any> {
    return this.dataAccessService.callQueryBinary({
      query: 'extract_from_zip',
      parameters: { zipFile: zipfile, fileName: filename }
    });
  }

  protected getObjectTypes(): SelfCompletingObservable<DataAccessFeatureTypeDatas> {
    return this.dataAccessService.callQueryJson<DataAccessFeatureTypeDatas>({
      query: 'get_feature_type_list',
      operation: 'get Feature Types',
      debugMsg: 'fetched Feature Types'
    });
  }
}
