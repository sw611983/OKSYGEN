/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ObjManager } from './obj.manager';
import { ObjManagerStub } from '@oksygen-sim-train-libraries/components-services/testing';

describe('obj manager', () => {
  let manager: ObjManager;

  beforeEach(() => {
    manager = new ObjManagerStub();
  });

  it('should be created', () => {
    expect(manager).toBeTruthy();
  });
});
