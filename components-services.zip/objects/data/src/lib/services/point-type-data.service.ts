/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { isNil } from 'lodash';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { computeIfAbsent, filterTruthy, ImageHandler, SelfCompletingObservable, shareReplayOne, SuperCalled } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ImageService } from '@oksygen-sim-train-libraries/components-services/common';

import { IPointTypeDataService } from '../interfaces/point-type-data.interface';
import { DataAccessFeatureTypeDatas } from '../models/data-access-object-type-data.model';
import { ObjectTypeContainer } from '../models/object-type.model';
import { BaseObjectTypeDataService, PlacementKey, POINT_OBJECT_TYPE_NAME } from './base-object-type-data.service';

// The following interfaces describe how data is supposed to come out of the database.
// This class will take these structures and massage them into more useful ones for the rest of the application to use.

@Injectable()
export class PointTypeDataService extends BaseObjectTypeDataService implements IPointTypeDataService {
  protected pointTypeObs: Observable<ObjectTypeContainer>;

  protected placementSubjects = new Map<PlacementKey, BehaviorSubject<ObjectTypeContainer>>();

  constructor(logging: Logging, registry: Registry, imageService: ImageService, protected readonly dataAccessService: DataAccessService) {
    super(logging, registry, imageService);

    this.pointTypeObs = this.dataSubject.pipe(
      filterTruthy(),
      map(mapType => {
        const types = Array.from(mapType.values());

        if (types.length > 0) {
          return types[0];
        }

        return undefined;
      }),
      shareReplayOne()
    );

    this.initialise();
  }

  protected override destroy(): SuperCalled {
    this.placementSubjects.forEach(value => value.complete());
    this.placementSubjects.clear();

    return super.destroy();
  }

  public pointType$(): Observable<ObjectTypeContainer> {
    return this.pointTypeObs;
  }

  /**
   * Expects ready$ to have been waited for
   */
  public pointType(): ObjectTypeContainer {
    const objects = this.dataSubject.getValue();

    let pointType: ObjectTypeContainer;

    if (objects.size > 0) {
      pointType = Array.from(objects.values()).find(this.getFirst);
    }

    return pointType;
  }

  placementPointType$(params: PlacementKey = {}): Observable<ObjectTypeContainer> {
    if (isNil(params.domain)) {
      params.domain = 'editor';
    }

    if (isNil(params.domain)) {
      params.key = 'scenario';
    }

    const placementTypesSubject = computeIfAbsent(
      this.placementSubjects,
      params,
      () => new BehaviorSubject<ObjectTypeContainer>(this.updatePlacementObjectTypes(params, this.dataSubject.getValue()).find(this.getFirst))
    );

    return placementTypesSubject.pipe(shareReplayOne());
  }

  /**
   * Expects ready$ to have been waited for
   */
  placementPointType(params: PlacementKey = {}): ObjectTypeContainer {
    if (isNil(params.domain)) {
      params.domain = 'editor';
    }

    if (isNil(params.domain)) {
      params.key = 'scenario';
    }

    const placementTypesSubject = computeIfAbsent(
      this.placementSubjects,
      params,
      () => new BehaviorSubject<ObjectTypeContainer>(this.updatePlacementObjectTypes(params, this.dataSubject.getValue()).find(this.getFirst))
    );

    return placementTypesSubject.getValue();
  }

  public override reloadData(): SelfCompletingObservable<SuperCalled> {
    return super.reloadData().pipe(
      map(result => {
        this.placementSubjects.forEach((placementSubject, params) =>
          placementSubject.next(this.updatePlacementObjectTypes(params, this.dataSubject.getValue()).find(this.getFirst))
        );

        this.readySubject.next(true);
        return result;
      })
    );
  }

  protected createImageHandler(fileName: string, path: string): ImageHandler {
    return new ImageHandler(
      () =>
        new Promise((resolve, reject) => {
          if (!fileName) {
            reject(null);
            return;
          }
          if (typeof fileName === 'object') {
            throw new Error('filename of image must be a string.');
          }
          this.dataAccessService
            .getData({ path, type: 'GET' })
            .toPromise()
            .then(data => {
              if (data) {
                resolve(data as Blob);
              } else {
                reject(null);
              }
            })
            .catch(() => {
              this.logging.warn(`Could not load icon ${fileName}.`);
              reject(null);
            });
        }),
      path
    );
  }

  /**
   * Sends a request to the database to extract some data from a zip file it has and send it back.
   *
   * @param zipfile The path to and name of the zip file.
   * @param filename  The name of the file within the zip.
   */
  // TODO This may be useful enough to be promoted into a superclass.
  protected extractFromZip(zipfile: string, filename: string): Observable<any> {
    return this.dataAccessService.callQueryBinary({
      query: 'extract_from_zip',
      parameters: { zipFile: zipfile, fileName: filename }
    });
  }

  protected getObjectTypes(): SelfCompletingObservable<DataAccessFeatureTypeDatas> {
    return this.dataAccessService.callQueryJson<DataAccessFeatureTypeDatas>({
      query: 'get_feature_type_list',
      parameters: { feature_type_name: POINT_OBJECT_TYPE_NAME },
      operation: 'get Feature Types',
      debugMsg: 'fetched Feature Types'
    });
  }

  protected getFirst(value: ObjectTypeContainer, index: number, obj: ObjectTypeContainer[]): boolean {
    return index === 0;
  }
}
