/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { cloneDeep, isEmpty, isNil, toNumber } from 'lodash';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  asArray,
  computeIfAbsent,
  ImageHandler,
  NO_IMAGE_HANDLER,
  SelfCompletingObservable,
  shareReplayOne,
  SUPER_WAS_CALLED,
  SuperCalled
} from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { GlobalImageStoreKey, ImageService, Range } from '@oksygen-sim-train-libraries/components-services/common';

import {
  DataAccessFeatureTypeData,
  DataAccessFeatureTypeDatas,
  DataAccessFeatureTypeIconData,
  DataAccessFeatureTypeStateData,
  DataAccessFeatureTypeStateProperty,
  DataAccessFeatureTypeStateTypeData
} from '../models/data-access-object-type-data.model';
import { EditorFeaturePlacementConfig, FeatureTypePlacementConfig, isDistanceFromTrackObj } from '../models/object-placement-config.model';
import {
  AUTOMATED,
  DISPLAY_STATE,
  DistanceFromTrack,
  INITIAL_STATE,
  ObjectHistory,
  ObjectIcons,
  ObjectPlacementRules,
  ObjectTypeBooleanProperty,
  ObjectTypeContainer,
  ObjectTypeContainerChild,
  ObjectTypeEnumProperty,
  ObjectTypeGroup,
  ObjectTypeHide,
  ObjectTypeNumericProperty,
  ObjectTypePlacementConfig,
  ObjectTypeState,
  ObjectTypeTextProperty,
  STATE,
  USER_STATE
} from '../models/object-type.model';

export interface PlacementKey {
  domain?: string;
  key?: string;
}

export const POINT_OBJECT_TYPE_NAME = 'Point';

@Injectable()
export abstract class BaseObjectTypeDataService {
  protected readonly PLACEMENT_DEFAULTS: ObjectTypePlacementConfig = {
    defaultPlacementRules: { distanceFromTrack: 0, initialOrientation: 'NONE' },
    featureTypes: [],
    groups: []
  };

  private featureTypeGroupsWithoutTrackAssociation: Array<string> = [];

  protected readySubject = new BehaviorSubject<boolean>(false);

  protected dataSubject = new BehaviorSubject<Map<string, ObjectTypeContainer>>(null);

  protected placementConfig: ObjectTypePlacementConfig;

  protected featureTypeToHide: Array<ObjectTypeHide> = [];

  constructor(protected readonly logging: Logging, protected readonly registry: Registry, protected readonly imageService: ImageService) {
    this.featureTypeGroupsWithoutTrackAssociation = this.registry
      .getObjectArray(['editor', 'scenario', 'objects', 'featureTypeGroupsWithoutTrackAssociation'], [])
      ?.map(f => f?.groupName);
  }

  protected destroy(): SuperCalled {
    this.dataSubject.complete();
    this.readySubject.complete();

    return SUPER_WAS_CALLED;
  }

  public get ready$(): Observable<boolean> {
    return this.readySubject.pipe(shareReplayOne());
  }

  /**
   * This should be called after the call to super in the concrete class constructor
   * This was moved so that the constructor can be completed before being initialised
   * And so that this method can be overridden as needed.
   * By default, it will call reloadData() once the registry has loaded.
   */
  protected initialise(): SuperCalled {
    this.registry.loaded().subscribe(loaded => {
      if (loaded) {
        this.placementConfig = this.registry.getObject(['objects', 'placementRules'], this.PLACEMENT_DEFAULTS);

        this.featureTypeToHide = this.registry.getObject<Array<ObjectTypeHide>>(['objects', 'featuresFilter'], []);

        this.reloadData().subscribe();
      }
    });

    return SUPER_WAS_CALLED;
  }

  // TODO should use a cache eviction mechanism (e.g. comparing version numbers)
  // to avoid unnecessary data transfer.
  /**
   * Request the data to be updated.
   * You can subscribe to the data via the ```data()``` observable.
   */
  public reloadData(): SelfCompletingObservable<SuperCalled> {
    this.readySubject.next(false);

    return this.getObjectTypes().pipe(
      map(data => {
        if (!data) {
          this.logging.warn('Could not load object types!');

          return SUPER_WAS_CALLED;
        }

        data.featureType = this.filterTypeMatches(data.featureType);

        const featureTypeData = asArray(data.featureType) as Array<DataAccessFeatureTypeData>;
        const objectTypes = new Map<string, ObjectTypeContainer>();
        const objectTypeGroups = new Map<string, ObjectTypeGroup>();

        const failedIcons = [];
        for (const ftd of featureTypeData) {
          this.enforceFTDTypes(ftd);

          const textProperties = new Map<string, ObjectTypeTextProperty>();
          const numericProperties = new Map<string, ObjectTypeNumericProperty>();
          const booleanProperties = new Map<string, ObjectTypeBooleanProperty>();
          const enumProperties = new Map<string, ObjectTypeEnumProperty>();
          const statesById = new Map<number, ObjectTypeState>();
          const statesByName = new Map<string, ObjectTypeState>();
          const stateIcons = new Map<number, ObjectIcons>();
          let mapOverrides = null;
          let defaultState = null;
          let userState = null;
          let automatedState = null;
          let displayState = null;
          let mapRenderer = null;

          const status = ftd.status;

          const history: ObjectHistory = {
            historyLog: asArray(ftd.history?.historyLog).map(item => ({
              type: item.type,
              authorFirstName: item.authorFirstName,
              authorLastName: item.authorLastName,
              timestamp: item.timestamp,
              version: toNumber(item.version)
            }))
          };
          const version = ftd.version;

          const defaultIcons: ObjectIcons = this.newTypeIcons(ftd);

          if (!defaultIcons.small && !defaultIcons.big) {
            failedIcons.push(`${ftd.name} ${ftd.id} Default Icons (Both)`);

            defaultIcons.small = NO_IMAGE_HANDLER;
            defaultIcons.big = NO_IMAGE_HANDLER;
          } else if (!defaultIcons.small) {
            failedIcons.push(`${ftd.name} ${ftd.id} Default Icons (Small)`);

            defaultIcons.small = NO_IMAGE_HANDLER;
          } else if (!defaultIcons.big) {
            failedIcons.push(`${ftd.name} ${ftd.id} Default Icons (Big)`);

            defaultIcons.big = NO_IMAGE_HANDLER;
          }

          const group = computeIfAbsent(objectTypeGroups, ftd.group, key => ({ name: key }));

          for (const ftsi of ftd.featureTypeIcon.featureTypeStateIcon) {
            if (ftsi) {
              stateIcons.set(ftsi.stateId, {
                small: this.newIconHandler(GlobalImageStoreKey.SMALL, ftsi.smallIcon),
                big: this.newIconHandler(GlobalImageStoreKey.BIG, ftsi.bigIcon)
              });
            }
          }

          for (const ftst of ftd.featureTypeStateTypes.featureTypeStateType) {
            this.enforceFTSTTypes(ftst);

            if (ftst.name === STATE) {
              for (const ftsd of ftst.featureTypeStates.featureTypeState) {
                this.enforceFTSDTypes(ftsd);

                let icons: ObjectIcons = stateIcons.get(ftsd.stateId);

                if (!icons) {
                  failedIcons.push(`${ftd.name} ${ftd.id} state ${ftsd.name} ${ftsd.stateId}`);

                  icons = {
                    small: NO_IMAGE_HANDLER,
                    big: NO_IMAGE_HANDLER
                  };
                }

                const fts: ObjectTypeState = {
                  id: ftsd.stateId,
                  name: ftsd.name,
                  userSelectable: ftsd.user_selectable,
                  icons
                };
                statesById.set(ftsd.stateId, fts);
                statesByName.set(ftsd.name, fts);

                if (ftsd.name === AUTOMATED) {
                  automatedState = fts;
                }
              }
            } else {
              throw new Error(`Encountered unsupported Feature Type State Type of ${ftst.name} on Feature Type ${ftd.name} (${ftd.id})`);
            }
          }

          for (const key of ftd.objectParameters.key) {
            if (key.enum?.option) {
              const values = asArray(key.enum.option);
              enumProperties.set(key.name, {
                name: key.name,
                description: key.description,
                defaultValue: values.find(v => v.value === key.default), // note default in db is the value NOT name
                displayed: key.displayed === 1 || key.displayed === '1',
                computed: key.computed === 1 || key.computed === '1',
                values
              });
            } else if (key.type === STATE) {
              const state = statesByName.get(key.default.toString());

              if (key.name === INITIAL_STATE) {
                defaultState = state;
              } else if (key.name === USER_STATE) {
                userState = state;
              } else if (key.name === DISPLAY_STATE) {
                displayState = state;
              } else {
                throw new Error(
                  `Unable to handle State Object Parameter ${key.name} with value ${key.default} on Feature Type ${ftd.name} (${
                    ftd.id
                  }) with states ${statesByName.keys()}`
                );
              }
            } else if (key.type === 'string') {
              textProperties.set(key.name, {
                name: key.name,
                description: key.description,
                displayName: key.displayName,
                defaultValue: key.default.toString(),
                displayed: key.displayed === 1 || key.displayed === '1',
                computed: key.computed === 1 || key.computed === '1',
                maxLength: key.max
              });
            } else if (key.type === 'double') {
              numericProperties.set(key.name, {
                name: key.name,
                description: key.description,
                displayName: key.displayName,
                defaultValue: Number(key.default), // blank default is converted to '' and Number('') => 0, so 0 is default if not supplied
                displayed: key.displayed === 1 || key.displayed === '1',
                computed: key.computed === 1 || key.computed === '1',
                min: key.min,
                max: key.max,
                units: key.units
              });
            } else if (key.type === 'boolean') {
              booleanProperties.set(key.name, {
                name: key.name,
                description: key.description,
                displayName: key.displayName,
                defaultValue: !!Number(key.default), // blank default is converted to '' and Number('') => 0, so false is default if not supplied
                displayed: key.displayed === 1 || key.displayed === '1',
                computed: key.computed === 1 || key.computed === '1'
              });
            } else if (key.type === 'object_id') {
              numericProperties.set(key.name, {
                name: key.name,
                description: key.description,
                displayName: key.displayName,
                defaultValue: null,
                displayed: key.displayed === 1 || key.displayed === '1',
                computed: key.computed === 1 || key.computed === '1'
              });
            } else {
              throw new Error(`Unable to handle ${key.type} Object Parameter ${key.name} on Feature Type ${ftd.name} (${ftd.id})`);
            }
          }
          if (ftd.featureTypeIconDisplayHandler) {
            mapOverrides = { icon: ftd.featureTypeIconDisplayHandler.truthTableIconHandler, label: ftd.featureTypeIconDisplayHandler.label };
            if (mapOverrides.icon?.icons?.icon?.length) {
              mapOverrides.icon.icons.icon.forEach(i => {
                this.newIconHandler(GlobalImageStoreKey.SMALL, i.smallIcon);
                this.newIconHandler(GlobalImageStoreKey.BIG, i.bigIcon);
              });
            }
            if (ftd.featureTypeIconDisplayHandler?.parameterDisplayProcessor?.ref) {
              mapRenderer = ftd.featureTypeIconDisplayHandler.parameterDisplayProcessor.ref;
            }
          }

          const objectType: ObjectTypeContainer = {
            // Composite Object Editor requires unique object type Id
            id: ftd?.id?.toString(),
            name: ftd.name,
            type: ftd.type,
            group,
            textProperties,
            numericProperties,
            booleanProperties,
            enumProperties,
            states: statesById,
            defaultState,
            userState,
            automatedState,
            displayState,
            defaultIcons,
            children: undefined,
            placementRules: undefined,
            status,
            history,
            version,
            mapOverrides,
            mapRenderer,
            hasNoTrackAssociation: this.featureTypeGroupsWithoutTrackAssociation.includes(ftd.group),
            isZoneRequired: ftd?.isZoneRequired
          };

          objectType.placementRules = this.getObjectTypePlacementRules(objectType, null);

          objectTypes.set(ftd.name, objectType);
        }

        if (!isEmpty(failedIcons)) {
          this.logging.warn(`missing icons for types ${failedIcons}`);
        }

        objectTypes.forEach(ft => {
          const ftd = featureTypeData.find(f => f.name === ft.name);
          // FIXME: hardcoded string!
          if (!ftd || ftd.type !== 'Container' || !ftd.featureElements?.featureElement) {
            return;
          }
          const children: ObjectTypeContainerChild[] = [];
          // sort our feature elements
          const sortedFeatureElements = ftd.featureElements.featureElement;
          for (const child of sortedFeatureElements) {
            const featureType = featureTypeData.find(f => f.name === child.featureTypeName);
            if (featureType) {
              const ftc = objectTypes.get(featureType.name);
              if (ftc) {
                const ftcc: ObjectTypeContainerChild = {
                  child: ftc,
                  name: child.name,
                  displayOrder: child.displayOrder,
                  displayIcon: undefined,
                  promoted: false,
                  showInPreview: child.showInPreview,
                  featureGeometry: child.featureGeometry.geometry,
                  featureParameters: asArray(child.featureParameters?.parameter)?.map(p => ({ name: p.name, value: p._ }))
                };
                children.push(ftcc);
              }
            }
          }
          ft.children = children;

          if (ftd.featureTypeIconDisplayHandler) {
            const promotedElements = asArray(ftd.featureTypeIconDisplayHandler.featureElementPromotion?.promotedElement) ?? [];
            promotedElements?.forEach(promotedElement => {
              if (promotedElement?.name) {
                const promotedChild = ft.children.find(child => child.name === promotedElement.name);
                if (promotedChild) {
                  promotedChild.promoted = true;
                  if (typeof promotedElement?.index === 'number') {
                    promotedChild.displayOrder = promotedElement?.index;
                    promotedChild.displayIcon = true;
                  }
                }
              }
            });
            ft.children?.sort((a, b) => {
              if (typeof a.displayIcon === 'number' && typeof b.displayIcon !== 'number') {
                return -1;
              }
              if (typeof b.displayIcon === 'number' && typeof a.displayIcon !== 'number') {
                return 1;
              }
              if (typeof a.displayIcon === 'number' && typeof b.displayIcon === 'number') {
                return a.displayOrder - b.displayOrder;
              }
              return 0;
            });
          }
        });

        this.dataSubject.next(objectTypes);

        return SUPER_WAS_CALLED;
      })
    );
  }

  protected updatePlacementObjectTypes(params: PlacementKey, allObjectTypes: Map<string, ObjectTypeContainer>): Array<ObjectTypeContainer> {
    if (isNil(allObjectTypes) || allObjectTypes.size === 0) {
      return [];
    }

    const objectTypes = cloneDeep(Array.from(allObjectTypes.values()));
    let placementConfig: EditorFeaturePlacementConfig;
    if (params.key) {
      const config = this.registry.getObject([params.domain, params.key], { objects: { placementRules: {} } });
      placementConfig = (config as any)?.objects?.placementRules;
    } else {
      const config = this.registry.getObject('objects', { objects: { placementRules: {} } });
      placementConfig = (config as any)?.placementRules;
    }

    if (!isNil(placementConfig)) {
      // objectTypes = objectTypes.filter(ft => this.isObjectTypePlaceable(ft, placementConfig));

      objectTypes.forEach(objectType => {
        objectType.placementRules = this.getObjectTypePlacementRules(objectType, placementConfig);
      });
    }

    return objectTypes;
  }

  /**
   * Corrects any properties given a different type to their interface when they were loaded.
   */
  protected enforceFTDTypes(ftd: DataAccessFeatureTypeData): void {
    if (!ftd.objectParameters) {
      ftd.objectParameters = { key: [] };
    }

    if (!ftd.featureElements) {
      ftd.featureElements = { featureElement: [] };
    }

    if (!ftd.featureElements.featureElement) {
      ftd.featureElements.featureElement = [];
    }

    ftd.featureElements.featureElement = asArray(ftd.featureElements.featureElement);
    ftd.objectParameters.key = asArray(ftd.objectParameters.key);

    for (const key of ftd.objectParameters.key) {
      key.name = key.name + '';
      key.type = key.type + '';
      key.description = !key.description ? '' : key.description + '';
      key.default = !key.default ? '' : typeof(key.default) === 'number' ? key.default : key.default + '';
    }

    if (!ftd.featureTypeIcon) {
      ftd.featureTypeIcon = { bigIcon: '', featureTypeStateIcon: [], iconCode: '', smallIcon: '' };
    }

    if (!ftd.featureTypeStateTypes) {
      ftd.featureTypeStateTypes = { featureTypeStateType: [] };
    }

    ftd.featureTypeIcon.featureTypeStateIcon = asArray(ftd.featureTypeIcon.featureTypeStateIcon);
    ftd.featureTypeStateTypes.featureTypeStateType = asArray(ftd.featureTypeStateTypes.featureTypeStateType);

    if (ftd.featureTypeIconDisplayHandler?.featureElementPromotion?.promotedElement) {
      ftd.featureTypeIconDisplayHandler.featureElementPromotion.promotedElement = asArray(
        ftd.featureTypeIconDisplayHandler.featureElementPromotion.promotedElement
      );
    }

    if (ftd.featureTypeIconDisplayHandler) {
      if (ftd.featureTypeIconDisplayHandler?.truthTableIconHandler?.icons?.icon) {
        ftd.featureTypeIconDisplayHandler.truthTableIconHandler.icons.icon = asArray(ftd.featureTypeIconDisplayHandler.truthTableIconHandler.icons.icon);
      }
      if (ftd.featureTypeIconDisplayHandler?.truthTableIconHandler?.truthTable?.case) {
        // eslint-disable-next-line max-len
        ftd.featureTypeIconDisplayHandler.truthTableIconHandler.truthTable.case = asArray(ftd.featureTypeIconDisplayHandler.truthTableIconHandler.truthTable.case);
        ftd.featureTypeIconDisplayHandler.truthTableIconHandler.truthTable.case.forEach(c => {
          if (c?.conditions) {
            c.conditions = asArray(c.conditions);
            c.conditions.forEach(cond => {
              if (cond?.propertyEquals) {
                cond.propertyEquals = asArray(cond.propertyEquals);
              }
            });
          }
        });
      }
    }
  }

  /**
   * Corrects any properties given a different type to their interface when they were loaded.
   */
  protected enforceFTSTTypes(ftst: DataAccessFeatureTypeStateTypeData): void {
    if (!ftst.featureTypeStates) {
      ftst.featureTypeStates = { featureTypeState: [] };
    }

    ftst.featureTypeStates.featureTypeState = asArray(ftst.featureTypeStates.featureTypeState);
  }

  /**
   * Corrects any properties given a different type to their interface when they were loaded.
   */
  protected enforceFTSDTypes(ftsd: DataAccessFeatureTypeStateData): void {
    ftsd.name = ftsd.name + '';

    if ((ftsd.properties as any) === '') {
      ftsd.properties = { property: new Array<DataAccessFeatureTypeStateProperty>() };
    }

    ftsd.properties.property = asArray(ftsd.properties.property);
    for (const property of ftsd.properties.property) {
      property.name = property.name + '';
      property.value = property.value + '';
    }
  }

  /**
   * Attempts to set up FeatureIcons for the given Feature Type.
   * If icons aren't explicity defined, naming conventions are used to attempt to find them.
   */
  protected newTypeIcons(featureType: DataAccessFeatureTypeData): ObjectIcons {
    const iconData: DataAccessFeatureTypeIconData = featureType.featureTypeIcon;

    //const iconPathPrefix = `Icons/${iconData.iconCode}.zip#${iconData.iconCode}`;

    let small: ImageHandler = null;
    let big: ImageHandler = null;

    if (iconData.smallIcon) {
      small = this.newIconHandler(GlobalImageStoreKey.SMALL, iconData.smallIcon);
    }
    // else if (!!iconData.iconCode) {
    //   small = this.newIconHandler(`${iconPathPrefix}-SMALL.png`, this.iconName(featureType, 'S'));
    // }

    if (iconData.bigIcon) {
      big = this.newIconHandler(GlobalImageStoreKey.BIG, iconData.bigIcon);
    }
    // else if (!!iconData.iconCode) {
    //   big = this.newIconHandler(`${iconPathPrefix}-BIG.png`, this.iconName(featureType, 'B', undefined));
    // }

    return {
      small,
      big
    };
  }

  protected newIconHandler(imageKey: GlobalImageStoreKey, path: string): ImageHandler {
    let separatorIndex = 0;

    if (path) {
      separatorIndex = path.indexOf('#');
    }

    if (separatorIndex && separatorIndex > 0) {
      // const zipFile = 'Features/' + path.substr(0, separatorIndex);
      // const fileName = path.substr(separatorIndex + 1, path.length - separatorIndex + 1);

      return null; // this.extractImageFromZip(imageKey, zipFile, fileName, name, path);
    } else {
      return this.loadImage(imageKey, path);
    }
  }

  /**
   * Sends a request to the database to extract some data from a zip file it has and send it back.
   *
   * @param zipFile The path to and name of the zip file.
   * @param fileName  The name of the file within the zip.
   * @param name a readable unique name for the icon to use as an id in our global list of images
   * @param path the path our image is being requested from
   *
   * @returns an ImageHandler that will lazily load the image if it is needed.
   */
  // TODO This may be useful enough to be promoted into a superclass.
  protected extractImageFromZip(imageKey: GlobalImageStoreKey, zipFile: string, fileName: string, name: string, path: string): ImageHandler {
    const handler = new ImageHandler(
      () =>
        new Promise((resolve, reject) => {
          if (!zipFile || !fileName) {
            reject(null);
            return;
          }
          if (typeof fileName === 'object') {
            throw new Error('filename of zip must be a string.');
          }
          if (typeof zipFile === 'object') {
            throw new Error('zipfile of zip must be a string.');
          }
          this.extractFromZip(zipFile, fileName)
            .toPromise()
            .then(data => {
              if (data) {
                resolve(data as Blob);
              } else {
                reject(null);
              }
            })
            .catch(() => {
              this.logging.warn(`Could not load icon ${fileName} from ${zipFile}.`);
              reject(null);
            });
        }),
      path
    );

    // TODO: Revisit this, as it could be adding a 'bad' handler to the name
    // this used to be before the resolve in the handler above
    this.imageService.addGlobalImage(imageKey, name, handler);

    return handler;
  }

  public loadImage(imageKey: GlobalImageStoreKey, fileName: string): ImageHandler {
    let path: string;

    if (fileName.toLowerCase().startsWith('/features/')) {
      path = fileName;
    } else {
      path = `/Features/${fileName}`;
    }

    const existingImageHandler = this.imageService.getGlobalImage(imageKey, path);
    if (existingImageHandler) {
      return existingImageHandler;
    }

    const handler: ImageHandler = this.createImageHandler(fileName, path);

    // TODO: Revisit this, as it could be adding a 'bad' handler to the name
    // this used to be before the resolve in the handler above
    this.imageService.addGlobalImage(imageKey, path, handler);

    return handler;
  }

  protected abstract createImageHandler(fileName: string, path: string): ImageHandler;

  /**
   * Sends a request to the database to extract some data from a zip file it has and send it back.
   *
   * @param zipfile The path to and name of the zip file.
   * @param filename  The name of the file within the zip.
   */
  // TODO This may be useful enough to be promoted into a superclass.
  protected abstract extractFromZip(zipfile: string, filename: string): Observable<any>;

  protected abstract getObjectTypes(): SelfCompletingObservable<DataAccessFeatureTypeDatas>;

  protected getObjectTypePlacementRules(
    objectType: ObjectTypeContainer,
    editorPlacementConfig: EditorFeaturePlacementConfig | undefined
  ): ObjectPlacementRules {
    const placeable = this.isObjectTypePlaceable(objectType, editorPlacementConfig);
    const distanceFromTrack = this.getFeatureTypeDistanceFromTrack(objectType, editorPlacementConfig);
    const initialOrientation = this.getFeatureTypeInitialOrientation(objectType, editorPlacementConfig);

    const placementRules: ObjectPlacementRules = {
      placeable,
      isHeadingImportant: initialOrientation !== Orientation.NONE,
      distanceFromTrackCentreline: distanceFromTrack,
      firstTrackAssocDefaultOrientation: initialOrientation,
      trackAssocCount: Range.exactly(1)
    };
    return placementRules;
  }

  protected isObjectTypePlaceable(objectType: ObjectTypeContainer, placementConfig: EditorFeaturePlacementConfig | undefined): boolean {
    // note reloadData has already checked registry's featuresFilter so no need to check here.
    if (!placementConfig) {
      return true;
    }
    const isDisallowedByName = placementConfig?.disallowedFeatureTypes?.find(f => f.featureType === objectType.name);
    const isDisallowedByGroup = placementConfig?.disallowedFeatureTypes?.find(f => f.group === objectType.group.name);
    const isAllowedByName = placementConfig?.allowedFeatureTypes?.find(f => f.featureType === objectType.name || f.group === objectType.group?.name);
    const isAllowedByGroup = placementConfig?.allowedFeatureTypes?.find(f => f.group === objectType.group?.name);
    const shownByDefault = !placementConfig?.otherFeatureTypes || placementConfig.otherFeatureTypes === 'show';
    // if not specified then use the default
    if (!isAllowedByGroup && !isAllowedByName && !isDisallowedByGroup && !isDisallowedByName) {
      return shownByDefault;
    }
    // if the group is disabled but the feature is enabled individually then allow it
    if (isAllowedByName && isDisallowedByGroup) {
      return true;
    }
    // if the group is enabled but the feature is disabled individually then disallow it
    if (isAllowedByGroup && isDisallowedByName) {
      return false;
    }
    // if it's allowed either by group or name then allow it
    if (isAllowedByGroup || isAllowedByGroup) {
      return true;
    }
    // if it's disabled either by group or name then disallow it
    if (isDisallowedByGroup || isDisallowedByName) {
      return false;
    }
    // if none of the above then just allow it
    return true;
  }

  protected getFeatureTypeDistanceFromTrack(
    objectType: ObjectTypeContainer,
    editorPlacementConfig: EditorFeaturePlacementConfig | undefined
  ): { x: Range; y: Range; z: Range } {
    // order of priority: (key pc = placement config, editor)
    // pc.default < pc.group < pc.featureType < editor.default < editor.group < editor.featureType

    const placementConfig: DistanceFromTrack = { x: Range.exactly(0), y: Range.exactly(0), z: Range.exactly(0) };

    // check pc.default
    const defaults = this.placementConfig?.defaultPlacementRules;

    if (defaults && Object.prototype.hasOwnProperty.call(defaults, 'distanceFromTrack')) {
      if (typeof defaults.distanceFromTrack === 'number') {
        placementConfig.x = Range.exactly(defaults.distanceFromTrack);
      } else if (Array.isArray(defaults.distanceFromTrack) && defaults.distanceFromTrack.length === 2) {
        placementConfig.x = Range.including(defaults.distanceFromTrack[0], defaults.distanceFromTrack[1]);
      } else if (isDistanceFromTrackObj(defaults.distanceFromTrack)) {
        placementConfig.x = this.distanceFromTrackTransform(defaults.distanceFromTrack.x, placementConfig.x);
        placementConfig.y = this.distanceFromTrackTransform(defaults.distanceFromTrack.y, placementConfig.y);
        placementConfig.z = this.distanceFromTrackTransform(defaults.distanceFromTrack.z, placementConfig.z);
      }
    }

    // check pc.groups
    const group = this.placementConfig?.groups?.find(grp => grp.name === objectType.group.name);

    if (group && Object.prototype.hasOwnProperty.call(group, 'distanceFromTrack')) {
      if (typeof group.distanceFromTrack === 'number') {
        placementConfig.x = Range.exactly(group.distanceFromTrack);
      } else if (Array.isArray(group.distanceFromTrack) && group.distanceFromTrack.length === 2) {
        placementConfig.x = Range.including(group.distanceFromTrack[0], group.distanceFromTrack[1]);
      } else if (isDistanceFromTrackObj(group.distanceFromTrack)) {
        placementConfig.x = this.distanceFromTrackTransform(group.distanceFromTrack.x, placementConfig.x);
        placementConfig.y = this.distanceFromTrackTransform(group.distanceFromTrack.y, placementConfig.y);
        placementConfig.z = this.distanceFromTrackTransform(group.distanceFromTrack.z, placementConfig.z);
      }
    }

    // check pc.featureType
    const pc = this.placementConfig?.featureTypes?.find(ft => ft.name === objectType.name);

    if (pc && Object.prototype.hasOwnProperty.call(pc, 'distanceFromTrack')) {
      if (typeof pc.distanceFromTrack === 'number') {
        placementConfig.x = Range.exactly(pc.distanceFromTrack);
      } else if (Array.isArray(pc.distanceFromTrack) && pc.distanceFromTrack.length === 2) {
        placementConfig.x = Range.including(pc.distanceFromTrack[0], pc.distanceFromTrack[1]);
      } else if (isDistanceFromTrackObj(pc.distanceFromTrack)) {
        placementConfig.x = this.distanceFromTrackTransform(pc.distanceFromTrack.x, placementConfig.x);
        placementConfig.y = this.distanceFromTrackTransform(pc.distanceFromTrack.y, placementConfig.y);
        placementConfig.z = this.distanceFromTrackTransform(pc.distanceFromTrack.z, placementConfig.z);
      }
    }

    // check editor.default
    const defaultSePlacementConfig = editorPlacementConfig?.defaultPlacementRules;

    if (defaultSePlacementConfig && Object.prototype.hasOwnProperty.call(defaultSePlacementConfig, 'distanceFromTrack')) {
      if (typeof defaultSePlacementConfig.distanceFromTrack === 'number') {
        placementConfig.x = Range.exactly(defaultSePlacementConfig.distanceFromTrack);
      } else if (Array.isArray(defaultSePlacementConfig.distanceFromTrack) && defaultSePlacementConfig.distanceFromTrack.length === 2) {
        placementConfig.x = Range.including(defaultSePlacementConfig.distanceFromTrack[0], defaultSePlacementConfig.distanceFromTrack[1]);
      } else if (isDistanceFromTrackObj(defaultSePlacementConfig.distanceFromTrack)) {
        placementConfig.x = this.distanceFromTrackTransform(defaultSePlacementConfig.distanceFromTrack.x, placementConfig.x);
        placementConfig.y = this.distanceFromTrackTransform(defaultSePlacementConfig.distanceFromTrack.y, placementConfig.y);
        placementConfig.z = this.distanceFromTrackTransform(defaultSePlacementConfig.distanceFromTrack.z, placementConfig.z);
      }
    }

    // check editor.featureType and editor.group
    let ftpc: FeatureTypePlacementConfig;
    for (const ft of editorPlacementConfig?.allowedFeatureTypes ?? []) {
      // there is both config for the group and config for the ft so individual feature type config takes precedence
      if (ft.featureType === objectType.name) {
        ftpc = ft;
        break;
      }
      if (ft.group === objectType.group.name) {
        ftpc = ft;
      }
    }
    if (ftpc && Object.prototype.hasOwnProperty.call(ftpc, 'distanceFromTrack')) {
      if (typeof ftpc.distanceFromTrack === 'number') {
        placementConfig.x = Range.exactly(ftpc.distanceFromTrack);
      } else if (Array.isArray(ftpc.distanceFromTrack) && ftpc.distanceFromTrack.length === 2) {
        placementConfig.x = Range.including(ftpc.distanceFromTrack[0], ftpc.distanceFromTrack[1]);
      } else if (isDistanceFromTrackObj(ftpc.distanceFromTrack)) {
        placementConfig.x = this.distanceFromTrackTransform(ftpc.distanceFromTrack.x, placementConfig.x);
        placementConfig.y = this.distanceFromTrackTransform(ftpc.distanceFromTrack.y, placementConfig.y);
        placementConfig.z = this.distanceFromTrackTransform(ftpc.distanceFromTrack.z, placementConfig.z);
      }
    }

    // a lot of code repetition in this function, could probably split it up further and share the logic with other config lookups.
    return placementConfig;
  }

  protected getFeatureTypeInitialOrientation(objectType: ObjectTypeContainer, editorPlacementConfig: EditorFeaturePlacementConfig | undefined): Orientation {
    // order of priority: (key pc = placement config, se = scenario editor)
    // pc.default < pc.group < pc.featureType < se.default < se.group < se.featureType

    // check se.featureType and se.group
    let ftpc: FeatureTypePlacementConfig;

    for (const ft of editorPlacementConfig?.allowedFeatureTypes ?? []) {
      // there is both config for the group and config for the ft so individual feature type config takes precedence
      if (ft.featureType === objectType.name) {
        ftpc = ft;
        break;
      }
      if (ft.group === objectType.group.name) {
        ftpc = ft;
      }
    }

    if (ftpc?.initialOrientation) {
      if (ftpc.initialOrientation === 'A_B') {
        return Orientation.ALPHA_TO_BETA;
      } else if (ftpc.initialOrientation === 'B_A') {
        return Orientation.BETA_TO_ALPHA;
      } else {
        return Orientation.NONE;
      }
    }

    // check se.default
    const defaultSePlacementConfig = editorPlacementConfig?.defaultPlacementRules;

    if (defaultSePlacementConfig?.initialOrientation) {
      if (defaultSePlacementConfig.initialOrientation === 'A_B') {
        return Orientation.ALPHA_TO_BETA;
      } else if (defaultSePlacementConfig.initialOrientation === 'B_A') {
        return Orientation.BETA_TO_ALPHA;
      } else {
        return Orientation.NONE;
      }
    }

    // check pc.featureType
    const pc = this.placementConfig?.featureTypes?.find(ft => ft.name === objectType.name);

    if (pc && Object.prototype.hasOwnProperty.call(pc, 'initialOrientation')) {
      if (pc.initialOrientation === 'A_B') {
        return Orientation.ALPHA_TO_BETA;
      } else if (pc.initialOrientation === 'B_A') {
        return Orientation.BETA_TO_ALPHA;
      } else {
        return Orientation.NONE;
      }
    }

    // check pc.group
    const group = this.placementConfig?.groups?.find(grp => grp.name === objectType.group.name);

    if (group && Object.prototype.hasOwnProperty.call(group, 'initialOrientation')) {
      if (group.initialOrientation === 'A_B') {
        return Orientation.ALPHA_TO_BETA;
      } else if (group.initialOrientation === 'B_A') {
        return Orientation.BETA_TO_ALPHA;
      } else {
        return Orientation.NONE;
      }
    }

    // check pc.default
    const defaults = this.placementConfig?.defaultPlacementRules;

    if (defaults && Object.prototype.hasOwnProperty.call(defaults, 'initialOrientation')) {
      if (defaults.initialOrientation === 'A_B') {
        return Orientation.ALPHA_TO_BETA;
      } else if (defaults.initialOrientation === 'B_A') {
        return Orientation.BETA_TO_ALPHA;
      } else {
        return Orientation.NONE;
      }
    }

    return Orientation.NONE;
  }

  protected filterTypeMatches(featureTypes: DataAccessFeatureTypeData[]): DataAccessFeatureTypeData[] {
    const featureTypesArray = asArray(featureTypes);

    const featureTypeToCompletelyHide = this.featureTypeToHide.filter(config => config.hide).map(config => config.featureType);

    // We want to hide the feature types that are in the registry
    // We could be using  featu...some(.. !==) but then if featureTypeToHide is empty we would hide everything because some would return false for everything
    return featureTypesArray.filter(ft => !featureTypeToCompletelyHide.some(fth => fth === ft.name));
  }

  protected distanceFromTrackTransform(value: number | number[], defaultValue: Range): Range {
    if (typeof value === 'number') {
      return Range.exactly(value);
    } else if (Array.isArray(value) && value.length === 2) {
      return Range.including(value[0], value[1]);
    }
    return defaultValue;
  }
}
