/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/dot-notation */

import { TestBed } from '@angular/core/testing';

import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { DataAccessServiceDataKey } from '@oksygen-common-libraries/data-access/testing';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ObjectTypeDataService } from './object-type-data.service';

describe('ObjectTypeDataService - Filter feature Hidden', () => {
  let service: ObjectTypeDataService;

  beforeEach(() => {
    configureSimTrainTestingModule(
      undefined,
      { data: { objects: { featuresFilter: [{ featureType: featureTypeData1.name, hide: true }] } } },
      new Map<DataAccessServiceDataKey, any>([
        [
          { query: 'get_feature_type_list' },
          {
            featureType: [featureTypeData1, featureTypeData2, featureTypeData3]
          }
        ]
      ])
    ).compileComponents();
    service = new ObjectTypeDataService(TestBed.inject(Logging), TestBed.inject(Registry), TestBed.inject(ImageService), TestBed.inject(DataAccessService));
  });

  describe('Filter feature', () => {
    it('should filter the selected feature type if they are hidden', () => {
      expect(service['filterTypeMatches']([featureTypeData1, featureTypeData2, featureTypeData3])).toEqual([featureTypeData2, featureTypeData3]);
    });
  });
});

describe('ObjectTypeDataService - Filter feature Not Hidden', () => {
  let service: ObjectTypeDataService;

  beforeEach(() => {
    configureSimTrainTestingModule(
      undefined,
      { data: { objects: { featuresFilter: [{ featureType: featureTypeData1.name, hide: false }] } } },
      new Map<DataAccessServiceDataKey, any>([
        [
          { query: 'get_feature_type_list' },
          {
            featureType: [featureTypeData1, featureTypeData2, featureTypeData3]
          }
        ]
      ])
    ).compileComponents();
    service = new ObjectTypeDataService(TestBed.inject(Logging), TestBed.inject(Registry), TestBed.inject(ImageService), TestBed.inject(DataAccessService));
  });

  it('should not filter elements that have hide set as false', () => {
    expect(service['filterTypeMatches']([featureTypeData1, featureTypeData2, featureTypeData3])).toEqual([
      featureTypeData1,
      featureTypeData2,
      featureTypeData3
    ]);
  });
});

describe('ObjectTypeDataService - Filter feature Mixed', () => {
  let service: ObjectTypeDataService;

  beforeEach(() => {
    configureSimTrainTestingModule(
      undefined,
      {
        data: {
          objects: {
            featuresFilter: [
              { featureType: featureTypeData1.name, hide: false },
              { featureType: featureTypeData2.name, hide: true }
            ]
          }
        }
      },
      new Map<DataAccessServiceDataKey, any>([
        [
          { query: 'get_feature_type_list' },
          {
            featureType: [featureTypeData1, featureTypeData2, featureTypeData3]
          }
        ]
      ])
    ).compileComponents();
    service = new ObjectTypeDataService(TestBed.inject(Logging), TestBed.inject(Registry), TestBed.inject(ImageService), TestBed.inject(DataAccessService));
  });

  it('should handle having feature hidden or not hidden', () => {
    expect(service['filterTypeMatches']([featureTypeData1, featureTypeData2, featureTypeData3])).toEqual([featureTypeData1, featureTypeData3]);
  });
});

describe('ObjectTypeDataService - Default', () => {
  let service: ObjectTypeDataService;

  beforeEach(() => {
    configureSimTrainTestingModule(
      undefined,
      undefined,
      new Map<DataAccessServiceDataKey, any>([
        [
          { query: 'get_feature_type_list' },
          {
            featureType: [featureTypeData1, featureTypeData2, featureTypeData3]
          }
        ]
      ])
    ).compileComponents();
    service = new ObjectTypeDataService(TestBed.inject(Logging), TestBed.inject(Registry), TestBed.inject(ImageService), TestBed.inject(DataAccessService));
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should not filter anything if the registry is empty', () => {
    // Empty registry
    expect(service['filterTypeMatches']([featureTypeData1, featureTypeData2, featureTypeData3])).toEqual([
      featureTypeData1,
      featureTypeData2,
      featureTypeData3
    ]);
  });
});

const featureTypeData1: any = {
  id: 1,
  name: 'Feature 1',
  group: 'Group 1',
  constantName: 'CONSTANT_1',
  type: 'Container',
  modifiable: true,
  available: true,
  user_feature: false,
  version: 1,
  featureTypeStateTypes: {}, // Replace with actual data
  objectParameters: {}, // Replace with actual data
  featureElements: {}, // Replace with actual data
  featureTypeIcon: {}, // Replace with actual data
  featureTypeIconDisplayHandler: {} // Replace with actual data
};

const featureTypeData2: any = {
  id: 2,
  name: 'Feature 2',
  group: 'Group 2',
  constantName: 'CONSTANT_2',
  type: null,
  modifiable: false,
  available: true,
  user_feature: true,
  version: 2,
  featureTypeStateTypes: {}, // Replace with actual data
  objectParameters: {}, // Replace with actual data
  featureElements: {}, // Replace with actual data
  featureTypeIcon: {}, // Replace with actual data
  featureTypeIconDisplayHandler: {} // Replace with actual data
};

const featureTypeData3: any = {
  id: 3,
  name: 'Feature 3',
  group: 'Group 3',
  constantName: 'CONSTANT_3',
  type: undefined,
  modifiable: true,
  available: false,
  user_feature: false,
  version: 3,
  featureTypeStateTypes: {}, // Replace with actual data
  objectParameters: {}, // Replace with actual data
  featureElements: {}, // Replace with actual data
  featureTypeIcon: {}, // Replace with actual data
  featureTypeIconDisplayHandler: {} // Replace with actual data
};
