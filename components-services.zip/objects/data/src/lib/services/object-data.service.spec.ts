/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TestBed } from '@angular/core/testing';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { configureSimTrainTestingModule, TEST_SYSTEM_NUMBER } from '@oksygen-sim-train-libraries/components-services/testing';

import { ObjectDataService } from './object-data.service';
import { of } from 'rxjs';

describe('ObjectDataService', () => {
  let service: ObjectDataService;

  beforeEach(() => {
    configureSimTrainTestingModule();
    service = new ObjectDataService(TestBed.inject(Registry), TestBed.inject(Logging), TEST_SYSTEM_NUMBER, of(true));
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
