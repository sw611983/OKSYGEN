/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgModule } from '@angular/core';

import { ObjectTypeDataService } from './services/object-type-data.service';
import { DISTANCE_FROM_TRACK_KEYWORD, distanceFromTrackValidator, objectPlacementConfigSchema } from './models/object-placement-config.model';
import { registryKeywordProvider, registrySchemaProvider } from '@oksygen-common-libraries/pio/registry';
import { socketSchema } from '@oksygen-sim-core-libraries/components-services/data-services';
import { FuncKeywordDefinition } from 'ajv';

const e = 'Must be set to 0, [a, b] or { x:0 | [a, b], y: 0 | [0,c], z: 0 | [d,e] } where a > 0, b > a, c > 0, d >= 0, e > d';

@NgModule({
  providers: [
    ObjectTypeDataService,
    registrySchemaProvider(socketSchema('featureData')),
    registrySchemaProvider(objectPlacementConfigSchema),
    registryKeywordProvider(
      DISTANCE_FROM_TRACK_KEYWORD,
      { schema: false, validate: distanceFromTrackValidator, errors: true, error: { message: e}} as FuncKeywordDefinition
    )
  ]
})
export class OksygenSimTrainObjectServicesModule {}
