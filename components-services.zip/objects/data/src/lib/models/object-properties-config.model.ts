/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { forOwn, isNil } from 'lodash';

export interface ObjectPropertiesConfig {
  [key: string]: ObjectTypePropertiesConfig;
}

export interface ObjectTypePropertiesConfig {
  [key: string]: ObjectTypePropertyConfig;
}

export interface ObjectTypePropertyConfig {
  placeholder?: string;
  maxCharacters?: number;
}

export function getObjectTypePropertyConfig(config: ObjectPropertiesConfig, objectTypeName: string, objectPropertyKey: string): ObjectTypePropertyConfig {
  const result: ObjectTypePropertyConfig = {
    placeholder: undefined,
    maxCharacters: undefined
  };

  let exitLoop = false;

  // try to find an exact match first
  forOwn(config, (objectTypePropertiesConfig, objectTypePropertiesConfigKey) => {
    if (!exitLoop) {
      if (objectTypePropertiesConfigKey === objectTypeName) {
        const objectTypePropertyConfig = subObjectTypePropertyConfig(objectTypePropertiesConfig, objectPropertyKey);

        result.placeholder = objectTypePropertyConfig.placeholder;
        result.maxCharacters = objectTypePropertyConfig.maxCharacters;
      }

      exitLoop = !isNil(result.placeholder) && !isNil(result.maxCharacters);
    }
  });

  // then try for regular expression match, but only overwrite if the value isn't already set
  // so order becomes important if there are multiple regex matches
  forOwn(config, (objectTypePropertiesConfig, objectTypePropertiesConfigKey) => {
    if (!exitLoop) {
      try {
        const keyRegEx = new RegExp(objectTypePropertiesConfigKey);

        if (keyRegEx.test(objectTypeName)) {
          const objectTypePropertyConfig = subObjectTypePropertyConfig(objectTypePropertiesConfig, objectPropertyKey);

          if (isNil(result.placeholder)) {
            result.placeholder = objectTypePropertyConfig.placeholder;
          }

          if (isNil(result.maxCharacters)) {
            result.maxCharacters = objectTypePropertyConfig.maxCharacters;
          }
        }
      } catch {}

      exitLoop = !isNil(result.placeholder) && !isNil(result.maxCharacters);
    }
  });

  return result;
}

function subObjectTypePropertyConfig(config: ObjectTypePropertiesConfig, objectPropertyKey: string): ObjectTypePropertyConfig {
  const result: ObjectTypePropertyConfig = {};

  let exitLoop = false;

  // try to find an exact match first
  forOwn(config, (objectTypePropertyConfig, objectTypePropertyConfigKey) => {
    if (!exitLoop) {
      if (objectTypePropertyConfigKey === objectPropertyKey) {
        result.placeholder = objectTypePropertyConfig.placeholder;
        result.maxCharacters = objectTypePropertyConfig.maxCharacters;
      }

      exitLoop = !isNil(result.placeholder) && !isNil(result.maxCharacters);
    }
  });

  // then try for regular expression match, but only overwrite if the value isn't already set
  // so order becomes important if there are multiple regex matches
  forOwn(config, (objectTypePropertyConfig, objectTypePropertyConfigKey) => {
    if (!exitLoop) {
      try {
        const keyRegEx = new RegExp(objectTypePropertyConfigKey);

        if (keyRegEx.test(objectPropertyKey)) {
          if (isNil(result.placeholder)) {
            result.placeholder = objectTypePropertyConfig.placeholder;
          }

          if (isNil(result.maxCharacters)) {
            result.maxCharacters = objectTypePropertyConfig.maxCharacters;
          }
        }
      } catch {}

      exitLoop = !isNil(result.placeholder) && !isNil(result.maxCharacters);
    }
  });

  return result;
}
