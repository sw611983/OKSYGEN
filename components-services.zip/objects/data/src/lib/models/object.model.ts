/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { SafeUrl } from '@angular/platform-browser';
import { every, isEmpty, isEqual, isNil } from 'lodash';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { Angle, LngLatCoord, Orientation, Point3D, SegOffset, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { isObjectPropertiesValid, ObjectGeometry, ObjectProperties, TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';

import { INITIAL_STATE, ObjectIcons, ObjectTypeContainer, ObjectTypeContainerChild, ObjectTypeState, USER_STATE } from './object-type.model';
import { NO_IMAGE_HANDLER } from '@oksygen-common-libraries/common';

export interface DetailedFeatureTypeState extends ObjectTypeState {
  icon: string | SafeUrl;
}

export interface ObjectWorldGeometry {
  x?: number;
  y?: number;
  z?: number;
  h?: number;
  p?: number;
  r?: number;
  velocityX?: number;
  velocityY?: number;
  velocityZ?: number;
  boundaries?: ObjectBoundary[];
}

/**
 * Converts an ```ObjectWorldGeometry``` to an ```ObjectGeometry```,
 * populating missing fields with zeros.
 */
export function toObjectGeometry(g: ObjectWorldGeometry): ObjectGeometry {
  return { x: 0, y: 0, z: 0, h: 0, p: 0, r: 0, ...g };
}

export interface ObjectBoundary {
  x: number;
  y: number;
  z: number;
  h: number;
  p: number;
  r: number;
  type: string;
  properties: ObjectBoundaryProperty;
}

export interface ObjectBoundaryProperty {
  [property: string]: string | number;
}

export class ObjectSource {
  public static TRACK = new ObjectSource('TRACK');
  public static SCENARIO = new ObjectSource('SCENARIO');
  public static SESSION = new ObjectSource('SESSION');

  constructor(public readonly id: string) {}
}

export interface SimObject {
  id: number;
  name: string;
  objectType: ObjectTypeContainer;
  source: ObjectSource;
  states: Map<number, ObjectTypeState>; // FIXME remove; this is redundant

  // FIXME I suspect "selected" is not the correct word for the following properties.
  // These are probably the current state, which may or may not have been selected by the user.
  // We will probably want to keep the state selected by the user separate from the actual state for situations like features that can be automated.
  selectedState: ObjectTypeState;
  // FIXME Probably shouldn't be here. See INTOSC-8421
  selectedIcon: ObjectIcons;
  /**
   * Flag that indicates whether our current (or "selected") state is the automated state.
   * Note that undefined means that this feature does not have an automated state.
   */
  stateAutomated: boolean | undefined;
  /**
   * Flag that indicates whether the current selected feature has vitrual state.
   * Note that undefined means that this feature does not have an virtual state.
   */
  stateVirtual: boolean | undefined;
  /**
   * Provides the option for users to define a real-world state (visible on a map)
   * and a separate state in 3D, which can be necessary for signal automation.
   */
  displayState: ObjectTypeState;

  location: ObjectWorldLocation;
  // A boundary is an array of point. You can have multiple boundaries per object.
  // Here the object X has got 2 boundaries, one on each side for example.
  // /\ /\
  // | X |
  // \/ \/
  //
  boundaries?: Array<Array<LngLatCoord>>;
  trackAssociations: Array<TrackSegmentAssociation>; // FIXME Duplicates segments on the location
  favourite?: boolean;
  properties?: ObjectProperties;

  // keep a link to the parent, so that if we decide to render them to the map
  // we have a way to redirect to the parent object for things like the object details panel
  parentId?: number;
  // quick way to identify the promoted child of a composite feature
  promotedChild?: boolean;
}

export interface ObjectContainer extends SimObject {
  children: SimObject[];
}

export interface ObjectWorldLocation {
  // to clear confusion - a feature can be associated with multiple tracks while being in only 1 lnglat position
  // think a speed sign between 2 tracks that applies to both
  lnglat: LngLatCoord;
  geometry?: ObjectWorldGeometry;
}

// so we have a single source of truth for both values
export interface ObjectStateChange {
  objectId: number;
  state: DetailedFeatureTypeState;
  autoToggled?: boolean;
  displayOverrideToggled?: boolean;
}

export interface ObjectPropertyChange {
  objectId: number;
  propertyName: string;
  propertyValue: string | number | boolean;
}

export interface ObjectPropertyUpdated {
  propertyName: string;
  propertyValue: string | number | boolean;
}

export interface ObjectLabel {
  text: string;
  yOffset: number;
  colour: string;
}

/**
 * For use in a DistinctUntilChanged
 * Compares two objects, returns true if they are equal.
 * Always returns false if the current object has children, as when a child is updated, both prev and curr change, so will not mark as changed
 *
 * TODO: If there ends up being too many composite objects, this function should be replaced with a 'dummy' last changed value on the parent object
 * That gets updated anytime a child is updated.
 *
 * @param prev Previous Object
 * @param curr Current Object
 */
export function selectedObjectContainerComparator(prev: ObjectContainer, curr: ObjectContainer): boolean {
  const eq = (!curr?.children || curr?.children?.length === 0) && isEqual(prev, curr);
  return eq;
}

/**
 * returns the Object if it is not a Composite Object, otherwise returns the promoted child with lowest index.
 *
 * @param object Object or Composite Object
 */
export function getDisplayObject(object: ObjectContainer): SimObject {
  let displayObject: SimObject = object;

  // if the object has children, find the promoted child, if there is one
  if (object.children) {
    let lowestIndex = Number.MAX_SAFE_INTEGER;
    object.children.forEach(child => {
      const childType = object.objectType.children.find(c => c.child.name === child.objectType.name);
      if (!childType) {
        return;
      }
      if (child.promotedChild && childType.displayOrder < lowestIndex) {
        displayObject = child;
        lowestIndex = childType.displayOrder;
      }
    });
  }

  return displayObject;
}

/**
 * Returns whether this object container's properties are all valid. So far, this just means not null (or undefined or '').
 * False and 0 are both valid.
 * @param object the object container to check
 * @param searchChildren whether to also search the children for invalid properties (default true)
 */
export function isObjectContainerPropertiesValid(object: ObjectContainer, searchChildren = true): boolean {
  if (!object) {
    return true;
  }

  if (searchChildren) {
    for (const child of object.children ?? []) {
      const valid = isObjectPropertiesValid(child.properties, child.objectType);
      if (!valid) {
        return false;
      }
    }
  }

  return isObjectPropertiesValid(object.properties, object.objectType);
}

export function createChildObjectFromType(
  child: ObjectTypeContainerChild,
  id: number,
  name: string,
  parentId: number,
  location: ObjectWorldLocation,
  trackAssociations: Array<TrackSegmentAssociation>,
  source: ObjectSource
): SimObject {
  const initialChildState = child.child.defaultState ?? child.child.states?.values().next(undefined)?.value;
  const initialUserState = child.child.userState ?? child.child.states?.values().next(undefined)?.value;
  const childProperties: ObjectProperties = {};

  if (initialChildState) {
    childProperties[INITIAL_STATE] = initialChildState.name;
  }
  const userState = child.child.userState ?? child.child.userState;

  if (userState) {
    childProperties[USER_STATE] = initialUserState.name;
  }

  child.child.textProperties.forEach(p => (childProperties[p.name] = p.defaultValue));
  child.child.numericProperties.forEach(p => (childProperties[p.name] = Number(p.defaultValue)));
  child.child.booleanProperties.forEach(p => (childProperties[p.name] = !!Number(p.defaultValue)));
  child.child.enumProperties.forEach(p => {
    const defaultValue = p.defaultValue?.value ?? p.values[0]?.value;
    childProperties[p.name] = defaultValue;
  });

  child.featureParameters?.forEach(p => {
    if (Object.prototype.hasOwnProperty.call(childProperties, p.name)) {
      childProperties[p.name] = p.value;
    }
  });


  const newChild: SimObject = {
    id,
    name,
    objectType: child.child,
    source,
    states: child.child.states,
    properties: childProperties,
    selectedState: initialChildState,
    selectedIcon: initialChildState?.icons,
    stateAutomated: undefined,
    stateVirtual: undefined,
    location,
    trackAssociations,
    promotedChild: child.promoted,
    parentId,
    displayState: undefined
  };

  return newChild;
}

/**
 * Returns the highest id in a given array of objects.
 * This will also search the children.
 * @param objects the objects to search
 * @param initialMax (optional) initialMax - defaults to 1.
 */
export function maxObjectId(objects: Array<ObjectContainer>, initialMax = 1): number {
  const id = objects.reduce((max, o) => {
    let localMax = o.id;
    if (o.children) {
      for (const child of o.children) {
        if (child.id > localMax) {
          localMax = child.id;
        }
      }
    }
    return localMax > max ? localMax : max;
  }, initialMax);
  return id;
}

// TODO probably want this to be made available somewhere more appropriate.
interface NetworkDefinition {
  segmentOffsetToLngLat(segmentId: number, offset: number): LngLatCoord;
  segmentOffsetToOrientedWorldPoint(segmentId: number, offset: number): { x: number; y: number; z: number; headingInRadians: number };
  segOffsetToUserScale(segOffset: SegOffset): UserScale[];
  segmentOffsetToTrackName(segmentId: number, offset: number): string;
}

export function getTrackAssocPosition(netDef: NetworkDefinition, assoc: TrackSegmentAssociation): Point3D {
  if (assoc.position === undefined) {
    updateHeadingAndPosition(netDef, assoc);
  }

  return assoc.position;
}

export function getTrackAssocLngLat(netDef: NetworkDefinition, assoc: TrackSegmentAssociation): LngLatCoord {
  if (!assoc.lnglat) {
    assoc.lnglat = netDef.segmentOffsetToLngLat(assoc.segmentId, assoc.offset);
  }

  return assoc.lnglat;
}

export function getTrackAssocTrackName(netDef: NetworkDefinition, assoc: TrackSegmentAssociation): string {
  const trackName = netDef.segmentOffsetToTrackName(assoc.segmentId, assoc.offset);
  return trackName;
}

export function getSegOffsetTrackName(netDef: NetworkDefinition, segOffset: SegOffset): string {
  const trackName = netDef.segmentOffsetToTrackName(segOffset.segmentId, segOffset.offset);
  return trackName;
}

export function getTrackAssocUserScales(netDef: NetworkDefinition, assoc: TrackSegmentAssociation, forceUpdate = false): Array<UserScale> {
  if (forceUpdate || isNil(assoc.userScale)) {
    assoc.userScale = netDef.segOffsetToUserScale(assoc);
  }

  return assoc.userScale;
}

export function getSegOffsetUserScales(netDef: NetworkDefinition, segOffset: SegOffset): Array<UserScale> {
  return netDef.segOffsetToUserScale(segOffset);
}

export function getTrackAssocHeading(netDef: NetworkDefinition, assoc: TrackSegmentAssociation): Angle {
  if (assoc.heading === undefined) {
    updateHeadingAndPosition(netDef, assoc);
  }

  return assoc.heading;
}

function updateHeadingAndPosition(netDef: NetworkDefinition, assoc: TrackSegmentAssociation): void {
  const owp = netDef.segmentOffsetToOrientedWorldPoint(assoc.segmentId, assoc.offset);
  assoc.position = owp;
  // let headingInDegrees = toDegrees(owp.headingInRadians);
  // // Consider orientation
  // headingInDegrees -= assoc.orientation === Orientation.ALPHA_TO_BETA ? 0 : 180;
  // assoc.heading = {degrees: headingInDegrees, radians: owp.headingInRadians};

  assoc.heading = Angle.ofRadians(owp.headingInRadians - (assoc.orientation === Orientation.BETA_TO_ALPHA ? Math.PI : 0));
}

// FIXME Only here as a workaround for INTOSC-8421
export function asFreezableObjectType(objectType: ObjectTypeContainer): ObjectTypeContainer {
  const freezableStates = new Map<number, ObjectTypeState>();
  objectType.states.forEach(s => freezableStates.set(s.id, cloneObjectState(s)));
  const automatedState: ObjectTypeState = freezableStates.get(objectType.automatedState?.id);
  const defaultState: ObjectTypeState = freezableStates.get(objectType.defaultState?.id);
  const displayState: ObjectTypeState = freezableStates.get(objectType.displayState?.id);
  const userState: ObjectTypeState = freezableStates.get(objectType.userState?.id);

  const children: Array<ObjectTypeContainerChild> = [];

  if (!isEmpty(objectType.children)) {
    objectType.children.forEach(containerChild => {
      children.push({
        ...containerChild,
        child: asFreezableObjectType(containerChild.child)
      });
    });
  }

  return { ...objectType, children, states: freezableStates, automatedState, defaultIcons: null, defaultState, userState, displayState };
}

export function cloneObjectState(state: ObjectTypeState): ObjectTypeState {
  return { ...state, icons: null };
}

/**
 * Returns the icon id and label that should be rendered based on the object state (and possibly properties).
 * If no conditions match then we should render the truth table default.
 * If no conditions match and there is no truth table default then we should render the state.
 * If no conditions match and there is no truth table default or state then we should render the default object type icon.
 * @param object the object to check
 * @param defaultIcon make sure this is an actual icon name not a reference!
 */
// eslint-disable-next-line max-len
export function getObjectRenderInfo(object: ObjectContainer | SimObject, defaultIcon: string): { icon: string; label?: ObjectLabel } {
  if (!object?.objectType) {
    return { icon: defaultIcon };
  }
  let icon = object.selectedState?.icons?.small?.id ?? object.objectType?.defaultIcons?.small?.id;
  if (!icon || icon === NO_IMAGE_HANDLER.id) {
    icon = defaultIcon;
  }
  if (object.objectType?.mapOverrides?.icon?.truthTable?.default?.icon) {
    const iconRef = object.objectType.mapOverrides.icon?.truthTable?.default?.icon;
    const overrideIcon = object.objectType.mapOverrides.icon.icons?.icon?.find(i => i.name === iconRef)?.smallIcon;
    icon = overrideIcon ? `/Features/${overrideIcon}` : defaultIcon;
  }
  for (const c of object?.objectType?.mapOverrides?.icon?.truthTable?.case ?? []) {
    // if all conditions in a case are met then we should render the associated icon
    const shouldOverride = every(c.conditions, cond => {
      const stateCheck = cond.stateIdEquals ? cond.stateIdEquals.value === object.selectedState.id : true;
      const propertyCheck = cond.propertyEquals
        ? every(cond.propertyEquals, prop => {
            const propValue = object.properties[prop.propertyName];
            return propValue === prop.value;
          })
        : true;
      return stateCheck && propertyCheck;
    });
    if (shouldOverride) {
      const iconRef = c.result.icon;
      const overrideIcon = object.objectType.mapOverrides.icon.icons?.icon?.find(i => i.name === iconRef)?.smallIcon;
      icon = overrideIcon ? `/Features/${overrideIcon}` : defaultIcon;
      break;
    }
  }
  const objectTypeLabel = object.objectType?.mapOverrides?.label ?? undefined;
  let labelTypeText = '';
  if (objectTypeLabel) {
    labelTypeText = objectTypeLabel.label;
    if (objectTypeLabel.propertyName) {
      const propertyValue = object.properties[objectTypeLabel.propertyName];
      labelTypeText = propertyValue ? `${propertyValue}` : '';
      const isBoolean = object.objectType?.booleanProperties.has(objectTypeLabel.propertyName);
      const enumProp = object.objectType?.enumProperties.get(objectTypeLabel.propertyName);
      if (isBoolean) {
        labelTypeText = propertyValue ? t('True') : t('False');
      }
      if (enumProp) {
        const enumVal = enumProp.values.find(v => v.value === propertyValue);
        labelTypeText = enumVal ? `${enumVal.displayName ?? enumVal.name ?? enumVal.value}` : labelTypeText; // only overwrite if we can find the enum val
      }
    }
  }
  const label: ObjectLabel | undefined = objectTypeLabel
    ? {
        colour: objectTypeLabel.colour ?? '#000000', // default black
        yOffset: objectTypeLabel.yOffset ?? 0,
        text: labelTypeText
      }
    : undefined;
  return { icon, label };
}

/**
 * Order the children so that the display order is applied everywhere we need it
 * @remark TODO: Recursion if that's needed for sorting the child's child, etc
 * @param object the object whose children need to be sorted
 * @returns Sort in place and return the same object
 */
export function sortChildrenByDisplayOrder(object: ObjectContainer): ObjectContainer {
  object.children.sort((a,b) => {
    const getOrder = (child: SimObject): number => {
      const found = object.objectType.children.find(c => c.child.id === child.objectType.id);
      return found?.displayOrder ?? Number.MAX_SAFE_INTEGER;
    };

    return getOrder(a) - getOrder(b);
  });
  return object;
}
