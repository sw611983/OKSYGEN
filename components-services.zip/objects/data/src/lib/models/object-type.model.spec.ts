/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { getObjectId, getObjectName, isObjectIdData, isObjectNameData } from './object-type.model';

describe('objects type model', () => {
  it('should check if the data looks like a reference to an object with a name', () => {
    expect(isObjectIdData({ objectId: 1 })).toBeTruthy();
    expect(isObjectIdData({ id: 1, name: 1, objectType: 'yes' })).toBeTruthy();
    expect(isObjectIdData({})).toBeFalsy();
    expect(isObjectIdData({ id: 1, name: 1 })).toBeFalsy();
  });
  it('should extract the object id from the given data', () => {
    expect(getObjectId({ objectId: 1 })).toEqual(1);
    expect(getObjectId({ id: 12, name: 1, objectType: 'yes' })).toEqual(12);
    expect(getObjectId({})).toEqual(-1);
  });
  it('should check if the data looks like a reference to an Object with an Id', () => {
    expect(isObjectNameData({ objectName: 'yes' })).toBeTruthy();
    expect(isObjectNameData({ id: 1, name: 1, objectType: 'yes' })).toBeTruthy();
    expect(isObjectNameData({})).toBeFalsy();
    expect(isObjectNameData({ data: { objectName: 'What a name!' }, type: 'object' })).toBeTruthy();
  });
  it('should extract the Object Name from the given data', () => {
    expect(getObjectName({ objectName: 'yes' })).toEqual('yes');
    expect(getObjectName({ id: 12, name: 'Tristan', objectType: 'yes' })).toEqual('Tristan');
  });
});
