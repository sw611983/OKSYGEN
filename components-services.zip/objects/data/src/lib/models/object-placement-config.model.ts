/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { hasProperty } from '@oksygen-common-libraries/common';

export interface FeaturePlacementConfig {
  defaultPlacementRules: Pick<FeatureTypePlacementConfig, 'distanceFromTrack'|'initialOrientation'>;
  groups?: any[];
  featureTypes?: any[];
}

export interface EditorFeaturePlacementConfig {
  allowedFeatureTypes: FeatureTypePlacementConfig[];
  disallowedFeatureTypes: {featureType?: string; group?: string}[];
  otherFeatureTypes: 'show'|'hide';
  defaultPlacementRules: Pick<FeatureTypePlacementConfig, 'distanceFromTrack'|'initialOrientation'>;
}

export interface DistanceFromTrackConfig {
  x?: number | [number, number];
  y?: number | [number, number];
  z?: number | [number, number];
}

export interface FeatureTypePlacementConfig {
  featureType?: string;
  group?: string;
  distanceFromTrack: number | [number, number] | DistanceFromTrackConfig;
  initialOrientation: 'A_B'|'B_A'|'NONE'|'BOTH'; // currently NONE and BOTH will map to the same thing.
}

export function isDistanceFromTrackObj(data: any): data is DistanceFromTrackConfig {
  return hasProperty(data, 'x') || hasProperty(data, 'y') || hasProperty(data, 'z');
}

// FIXME copied from editor-config.model
export const DISTANCE_FROM_TRACK_KEYWORD = 'oksygen-distance-from-track-keyword';

export function distanceFromTrackValidator(d: number | number[] | { x: number|number[]; y: number|number[]; z: number|number[] }): boolean {
  if (typeof d === 'number') {
    return d === 0;
  } else if (Array.isArray(d)) {
    return d?.length === 2 && d[0] > 0 && d[1] > d[0];
  } else if (typeof d === 'object') {
    let xValid = true; // default to true as we default if not supplied so you can leave it blank
    if (d.x) {
      if (typeof d.x === 'number') {
        xValid = d.x === 0;
      } else if (Array.isArray(d.x)) {
        xValid = d.x?.length === 2 && d.x[0] > 0 && d.x[1] > d.x[0];
      } else {
        xValid = false; // means they provided a string or boolean
      }
    }
    let yValid = true;
    if (d.y) {
      if (typeof d.y === 'number') {
        yValid = d.y === 0;
      } else if (Array.isArray(d.y)) {
        yValid = d.y?.length === 2 && d.y[0] > 0 && d.y[1] > d.y[0];
      } else {
        yValid = false; // means they provided a string or boolean
      }
    }
    let zValid = true;
    if (d.z) {
      if (typeof d.z === 'number') {
        // do nothing - z doesn't have to be 0
      } else if (Array.isArray(d.z)) {
        zValid = d.z?.length === 2 && d.z[0] >= 0 && d.z[1] > d.z[0];
      } else {
        zValid = false; // means they provided a string or boolean
      }
    }
    return xValid && yValid && zValid;
  }
  return false;
}

const distanceFromTrackNumber = { type: 'number', enum: [0] };
const distanceFromTrackArray = {
  type: 'array', uniqueItems: true, minItems: 2, additionalItems: false,
  items: [{type: 'number', minimum: 0.001}, {type: 'number', minimum: 0.001}]
};

export const distanceFromTrackConfigSchema: Record<string, any> = {
  errorMessage: 'Must be set to 0, [a, b] or { x:0 | [a, b], y: 0 | [0, c], z: 0 | [d, e] } where a > 0, b > a, c > 0, d >= 0, e > d',
  anyOf: [
    distanceFromTrackArray,
    distanceFromTrackNumber,
    {
      type: 'object', properties: {
        x: { anyOf: [distanceFromTrackNumber, distanceFromTrackArray] },
        y: { anyOf: [
          distanceFromTrackNumber,
          { type: 'array', uniqueItems: true, minItems: 2, additionalItems: false, items: [{type: 'number', enum: [0]}, {type: 'number', minimum: 0.001}] }
        ]},
        z: { anyOf: [{ type: 'number'}, { type: 'array', uniqueItems: true, minItems: 2, additionalItems: false, items: [{type: 'number'}, {type: 'number'}]}] }
      }
    }
  ]
};

const placementConfigSchema: Record<string, any> = {
  type: 'object',
  properties: {
    name: { type: 'string' },
    distanceFromTrack: distanceFromTrackConfigSchema,
    initialOrientation: { type: 'string', enum: ['A_B', 'B_A', 'NONE'] }
  }
};

export const objectPlacementConfigSchema: Record<string, any> = {
  $id: 'oksygen-object-placement-config',
  type: 'object',
  properties: {
    objects: {
      type: 'object',
      properties: {
        placementRules: {
          type: 'object',
          properties: {
            defaultPlacementRules: {
              type: 'object',
              properties: {
                distanceFromTrack: distanceFromTrackConfigSchema,
                initialOrientation: { type: 'string', enum: ['A_B', 'B_A', 'NONE'] }
              }
            },
            groups: {
              type: 'array',
              items: placementConfigSchema
            },
            featureTypes: {
              type: 'array',
              items: placementConfigSchema
            },
            featuresFilter: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  featureType: { type: 'string' },
                  group: { type: 'string' },
                  hide: { type: 'boolean' }
                }
              }
            }
          }
        }
      }
    }
  }
};
