/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ImageHandler } from '@oksygen-common-libraries/common';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectId } from '@oksygen-sim-core-libraries/data-types/objects';
import { DragData, Range } from '@oksygen-sim-train-libraries/components-services/common';
import { EditHistory } from '@oksygen-common-libraries/common';
import { ObjectTypeIconOverrides, ObjectTypeLabel } from './data-access-object-type-data.model';

/**
 * Contains ImageHandlers for all sizes that an Object Type icon can be.
 */
export interface ObjectIcons {
  small: ImageHandler;
  big: ImageHandler;
}

// TODO these may come from generated constants
/** The name of the property that describes the Initial State of an Object or Object Type.  */
export const INITIAL_STATE = 'Initial State';
/**
 * The name of the property that describes the State of an Object which was selected by the user.
 * In the case of Automated Objects, the State may be {@link AUTOMATED_STATE_VALUE},
 * which indicates the Object's state will be set by scripts.
 */
export const USER_STATE = 'User State';
/**
 * The name of the property that describes the State of an Object.
 * In the case of Automated Objects, the State may set by scripts if the {@link USER_STATE} is set to {@link AUTOMATED_STATE_VALUE}.
 */
export const STATE = 'State';
/** The name of the Automated State, which controls when the Object is updated by scripts. */
export const AUTOMATED_STATE_VALUE = 'Automated';
export const DISPLAY_STATE = 'Display State';
export const DISPLAY_STATE_OVERRIDE = 'Display Override';

export const VIRTUAL_STATE = 'Virtual';

export interface ObjectTypePlacementConfig {
  defaultPlacementRules: ObjectTypePlacementRule;
  groups: (ObjectTypePlacementRule & { name: string })[];
  featureTypes: (ObjectTypePlacementRule & { name: string })[];
}

export interface ObjectTypePlacementRule {
  distanceFromTrack: number | [number, number];
  initialOrientation: 'A_B' | 'B_A' | 'NONE' | 'BOTH'; // currently NONE and BOTH will map to the same thing.
}

export interface ObjectTypeHide {
  featureType: string;
  hide?: boolean;
}
/**
 * Describes a property that Objects of a particular Type would typically have.
 * Note that the current value of the property is per Object instance.
 */
export interface ObjectTypeProperty<T> {
  /** Note that this is a Comms property name, and is not suitable for displaying to a user. */
  name: string;
  description?: string;
  displayName?: string;
  defaultValue: T;
  displayed: boolean;
  computed: boolean;
}

export interface ObjectTypeEnumPropertyValue<T> {
  value: T;
  name: string;
  displayName?: string;
}

/**
 * Describes a property which holds a text value that Objects of a particular Type would typically have.
 * Note that the current value of the property is per Object instance.
 */
export interface ObjectTypeTextProperty extends ObjectTypeProperty<string> {
  maxLength?: number;
  placeholder?: string;
}

/**
 * Describes a property which holds a numeric value that Objects of a particular Type would typically have.
 * Note that the current value of the property is per Object instance.
 */
export interface ObjectTypeNumericProperty extends ObjectTypeProperty<number> {
  units?: string;
  min?: number;
  max?: number;
}

/**
 * Describes a property which holds a boolean value that Objects of a particular Type would typically have.
 * Note that the current value of the property is per Object instance.
 */
export type ObjectTypeBooleanProperty = ObjectTypeProperty<boolean>;

/**
 * Describes a property which holds a numeric value that Objects of a particular Type would typically have.
 * Note that the current value of the property is per Object instance.
 */
export interface ObjectTypeEnumProperty extends ObjectTypeProperty<ObjectTypeEnumPropertyValue<string | number>> {
  values: ObjectTypeEnumPropertyValue<string | number>[];
  units?: string;
}

/**
 * Describes the Group an Object Type belongs to.
 */
export interface ObjectTypeGroup {
  name: string;
}

// TODO this may come from a generated constant
export const AUTOMATED = 'Automated';

/**
 * Describes a State that an Object of a Type can be in.
 */
export interface ObjectTypeState {
  id: number;
  name: string;
  userSelectable: boolean;
  // FIXME Probably shouldn't be here. See INTOSC-8421
  icons: ObjectIcons;
}

/**
 * Describes an Object Type.
 */
export interface ObjectType {
  id?: string;
  name: string;
  group: ObjectTypeGroup;
  type: 'Container' | null | undefined;
  textProperties: Map<string, ObjectTypeTextProperty>;
  numericProperties: Map<string, ObjectTypeNumericProperty>;
  booleanProperties: Map<string, ObjectTypeBooleanProperty>;
  enumProperties: Map<string, ObjectTypeEnumProperty>;
  states: Map<number, ObjectTypeState>;
  defaultState?: ObjectTypeState;
  // FIXME this should not be here - should have an extending interface that adds this prop.
  userState?: ObjectTypeState;
  // FIXME this should not be here - should have an extending interface that adds this prop.
  selectedState?: ObjectTypeState;

  /**
   * The Automated state of this Type of Object, if it has one.
   * Objects with this state are expected to have scripts that drive their state;
   * when the Automated state is set, the actual state should always be something else.
   */
  automatedState?: ObjectTypeState;

  displayState?: ObjectTypeState;

  // FIXME Probably shouldn't be here. See INTOSC-8421
  /** Icons that illustrate the Type, but do not indicate state. */
  defaultIcons: ObjectIcons;
  /**
   * Rules for how to override how this is rendered on the map.
   */
  mapOverrides?: { icon?: ObjectTypeIconOverrides; label?: ObjectTypeLabel };

  placementRules?: ObjectPlacementRules;
  mapRenderer?: string;
  hasNoTrackAssociation?: boolean;
  isZoneRequired?: boolean;
}
export interface DistanceFromTrack {
  /** perpendicular distance from the track */
  x: Range;
  /** tangent to the track */
  y: Range;
  /** vertical distance from the track */
  z: Range;
}

export interface ObjectPlacementRules {
  placeable: boolean;
  isHeadingImportant: boolean;
  trackAssocCount?: Range;
  // TODO Add something like 'Default Direction' or similar, as sometimes the usual direction not A-B.
  /**
   * This is used for Objects being dragged on the map (and similar contexts without explicit user input).
   * At this point we have no idea what orientation the association should be in.
   */
  firstTrackAssocDefaultOrientation?: Orientation;
  /**
   * This is used for Objects being dragged on the map (and similar contexts without explicit user input).
   * At this point we have no idea what heading the object should be in.
   * CURRENTLY UNUSED.
   */
  alignHeadingWithNearestTrack?: 'With First Track Assoc' | 'Against First Track Assoc' | 'Towards Track' | 'Away from Track';
  distanceFromTrackCentreline?: DistanceFromTrack;
}

/**
 * An Object type container is an object type that also has some children Object types (which may also have children).
 */
export interface ObjectTypeContainer extends ObjectType {
  /**
   * Composite objects have child Object types.
   */
  children: ObjectTypeContainerChild[];
  history?: ObjectHistory;
  version?: number;
  status?: string;
}

export interface ObjectHistory {
  historyLog: ObjectHistoryLog[];
}

export interface ObjectHistoryLog extends EditHistory {
  version?: number;
}

export interface FeatureGeometry {
  x?: number;
  y?: number;
  z?: number;
  heading?: number;
  pitch?: number;
  roll?: number;
}

export interface FeatureParameter {
  name: string;
  value: string;
  maxLength?: number;
  placeholder?: string;
}
/**
 * Object type containers can have children. Those children can have some extra properties on a per instance basis.
 */
export interface ObjectTypeContainerChild {
  name: string;
  displayOrder?: number;
  displayIcon?: boolean;
  child: ObjectTypeContainer;
  promoted?: boolean;
  featureGeometry?: FeatureGeometry;
  featureParameters?: Array<FeatureParameter>;
  showInPreview?: boolean;
}

export const OBJECT_DATA_TYPE_NAME = 'object';
export const POINT_DATA_TYPE_NAME = 'point';

/**
 * Checks if the given data (possibly from a specially encoded drag action) looks like a reference to an Object.
 *
 * @param data a ObjectId or a ObjectId that has been mangled for inspection during drag.
 */
export function isObjectIdData(data: any): boolean {
  const maybeObjectRefData = unwrapObjectData(data);

  if (!maybeObjectRefData) {
    return false;
  }

  // Note that any tests for properties with capital letters need to also test for a similar lowercase property,
  // due to potential mangling during a drag.
  if (maybeObjectRefData.objectid || maybeObjectRefData.objectId) {
    return true;
  }

  if (maybeObjectRefData.id && maybeObjectRefData.name && (maybeObjectRefData.objecttype || maybeObjectRefData.objectType)) {
    return true;
  }

  return false;
}

/**
 * Extracts the Object ID from the given data (possibly from a specially encoded drag action),
 * which should be checked with ```isObjectIdData``` before calling this function.
 *
 * @param objectRef an object refering to an object which may have been mangled for inspection during drag.
 */
export function getObjectId(objectRef: ObjectId | any): number {
  const ref = unwrapObjectData(objectRef);
  // Note that properties may be in lowercase due to potential mangling during a drag.
  return ref.objectid ?? ref.objectId ?? ref.id ?? -1;
}

/**
 * Describes an Object by refering to its unique name.
 * Useful in situations where a string is too ambiguous.
 */
export interface ObjectName {
  objectName: string;
}

/**
 * Checks if the given data (possibly from a specially encoded drag action) looks like a reference to an Object.
 *
 * @param maybeObjectRefData a RuleTemplate or a RuleTemplate that has been mangled for inspection during drag.
 */
export function isObjectNameData(data: DragData | any): boolean {
  const maybeObjectRefData = unwrapObjectData(data);

  if (!maybeObjectRefData) {
    return false;
  }

  // Note that any tests for properties with capital letters need to also test for a similar lowercase property,
  // due to potential mangling during a drag.
  if (maybeObjectRefData.objectname || maybeObjectRefData.objectName) {
    return true;
  }

  if (maybeObjectRefData.id && maybeObjectRefData.name && (maybeObjectRefData.objecttype || maybeObjectRefData.objectType)) {
    return true;
  }

  return false;
}

/**
 * Extracts the Object name from the given data (possibly from a specially encoded drag action),
 * which should be checked with ```isObjectNameData``` before calling this function.
 *
 * @param objectRef an object refering to an object which may have been mangled for inspection during drag.
 */
export function getObjectName(objectRef: ObjectName | DragData | any): string {
  objectRef = unwrapObjectData(objectRef);

  // Note that properties may be in lowercase due to potential mangling during a drag.
  return objectRef.objectname ?? objectRef.objectName ?? objectRef.name ?? '';
}

function unwrapObjectData(objectRef: ObjectId | ObjectName | DragData | any): any {
  if (objectRef?.data) {
    return objectRef.type === OBJECT_DATA_TYPE_NAME || objectRef.type === POINT_DATA_TYPE_NAME ? objectRef.data : null;
  }
  return objectRef;
}

// MOVE???
/**
 * Describes a point in the World and orientation that an Object has been placed.
 */
export interface ObjectPointPlacement {
  lat: number;
  lng: number;
  heading: number;
}

/**
 * Describes a region in the World that an Object occupies.
 */
export interface ObjectRegionPlacement {
  coords: Array<Array<number>>;
}

export interface ObjectFilter {
  type: string;
  name: string;
}

/**
 * Checks if the given data (possibly from a specially encoded drag action) looks like an Object Type.
 * @param maybeObjectTypeData an Object Type or an Object Type that has been mangled for inspection during drag.
 */
export function isObjectTypeData(maybeObjectTypeData: any): boolean {
  if (!maybeObjectTypeData) {
    return false;
  }

  // Note that any tests for properties or values with capital letters need to also test for a similar lowercase property,
  // due to potential mangling during a drag.
  if (
    maybeObjectTypeData.name &&
    maybeObjectTypeData.group &&
    maybeObjectTypeData.states &&
    (maybeObjectTypeData.numericProperties || maybeObjectTypeData.numericproperties) &&
    (maybeObjectTypeData.textProperties || maybeObjectTypeData.textproperties)
  ) {
    return true;
  }

  return false;
}
