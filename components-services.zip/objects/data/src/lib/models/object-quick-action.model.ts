/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ObjectContainer } from './object.model';

// Note that we can't use a clever technique like *ngIf="favouriteClick.observers.length"
// because the code that can decide what functionality is available is often
// a few layers away from where this component is instantiated.
export interface ObjectQuickActionConfig {
  favouriteEnabled: boolean;
  findEnabled: boolean;
  deleteEnabled: (o: ObjectContainer) => boolean;
  changeOrientationEnabled: (o: ObjectContainer) => boolean;
}

export const QUICK_OBJECT_ACTIONS_DISABLED: ObjectQuickActionConfig = {
  favouriteEnabled: false,
  findEnabled: true,
  deleteEnabled: o => true,
  changeOrientationEnabled: o => true
};
