/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable } from 'rxjs';

import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import { PropertyUpdated } from '@oksygen-sim-train-libraries/components-services/common';

import { ObjectContainer, ObjectPropertyChange, ObjectStateChange, ObjectWorldGeometry } from './object.model';

export interface ObjectEditManager {
  objectDeletion$: Observable<boolean>;

  deleteObject(id: number): void;

  objectStateChange(obj: ObjectContainer, state: ObjectStateChange): PropertyUpdated[];

  objectPropertyChange(obj: ObjectContainer, property: ObjectPropertyChange): PropertyUpdated[];

  updateObjectName(id: number, name: string): void;

  updateObjectPosition(object: ObjectContainer, pos: LngLatCoord, assocs?: TrackSegmentAssociation[]): void;

  updateObjectGeometry(object: ObjectContainer, geom: ObjectWorldGeometry): void;

  updateObjectBoundaries(id: number, boundaries: Array<Array<LngLatCoord>>): void;
}
