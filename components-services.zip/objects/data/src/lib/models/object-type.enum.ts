/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/**
 * These are standard Object Type Names
 */
export enum ObjectTypeName {
  PLATFORM = 'Platform',
  POINT = 'Point',
  STATION = 'Station'
}

/**
 * These are standard Object Type Group Names
 */
export enum ObjectTypeGroupName {
  POINT = 'Point'
}
