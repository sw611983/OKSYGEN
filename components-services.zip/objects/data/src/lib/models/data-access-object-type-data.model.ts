/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { EditHistory } from '@oksygen-common-libraries/common';

export interface DataAccessFeatureTypeStateProperty {
  name: string;
  value: string;
}

export interface DataAccessFeatureTypeStateProperties {
  property: DataAccessFeatureTypeStateProperty[];
}

export interface DataAccessFeatureTypeStateData {
  name: string;
  stateId: number;
  user_selectable: boolean;
  properties: DataAccessFeatureTypeStateProperties;
}

export interface DataAccessFeatureTypeStateDatas {
  featureTypeState: DataAccessFeatureTypeStateData[];
}

export interface DataAccessFeatureTypeStateTypeData {
  name: string;
  featureTypeStates: DataAccessFeatureTypeStateDatas;
}

export interface DataAccessFeatureTypeStateTypeDatas {
  featureTypeStateType: DataAccessFeatureTypeStateTypeData[];
}

export interface DataAccessFeatureTypeStateIconData {
  stateId: number;
  iconCode: string;
  smallIcon: string;
  bigIcon: string;
}

export interface ObjectTypeIconOverrides {
  icons: { icon: IconOverridesIcon[] };
  truthTable: TruthTable;
}

export interface TruthTable {
  case: TruthTableCase[];
  default?: TruthTableResult;
}

export interface TruthTableCase {
  result: TruthTableResult;
  conditions: TruthTableConditions[];
}

export interface TruthTableResult {
  /** Note this is a REFERENCE to one of the icons defined in truthTableIconHandler.icons!!! Is it not an icon path itself!  */
  icon: string;
}

export interface TruthTableConditions {
  stateIdEquals: TruthTableStateIdEquals;
  propertyEquals: TruthTablePropertyEquals[];
}

export interface TruthTableStateIdEquals {
  value: number;
}

export interface TruthTablePropertyEquals {
  propertyName: string;
  value: string|number|boolean;
}

export interface IconOverridesIcon {
  name: string;
  smallIcon: string;
  bigIcon: string;
}

export interface DataAccessFeatureTypeIconData {
  iconCode: string;
  smallIcon: string;
  bigIcon: string;
  featureTypeStateIcon: DataAccessFeatureTypeStateIconData[];
}

export interface DataAccessObjectParameterKey {
  name: string;
  /** Oksygen supports 'text', 'double', 'State', 'object_id', 'boolean'. */
  type: string;
  default: number | string;
  description: string;
  displayName?: string;
  /** will be empty or 1 (1 may be encoded as either a number or string from the DB) */
  computed?: number | string;
  /** will be empty or 1 (1 may be encoded as either a number or string from the DB) */
  displayed?: number | string;
  min?: number;
  max?: number;
  units?: string;
  enum?: DataAccessObjectParameterKeyEnum;
}

interface DataAccessObjectParameterKeyEnum {
  option?: DataAccessObjectParameterKeyEnumOption[];
}

interface DataAccessObjectParameterKeyEnumOption {
  value: string | number;
  name: string;
  displayName?: string;
}

export interface DataAccessObjectParameters {
  key: DataAccessObjectParameterKey[];
}

export interface DataAccessFeatureElement {
  featureTypeName: string;
  name: string;
  showInPreview: boolean;
  displayOrder: number;
  featureTypeVersion?: number;
  featurePlacement?: any; // TODO as ignoring this field for now
  featureGeometry?: DataAccessFeatureGeometry; // TODO as ignoring this field for now
  featureParameters?: DataAccessFeatureParameters;
}

export interface DataAccessFeatureParameters {
  parameter: DataAccessFeatureParameter[];
}

export interface DataAccessFeatureElements {
  featureElement: DataAccessFeatureElement[];
}

export interface DataAccessPromotedElement {
  name: string;
  index?: number;
}

export interface DataAccessFeatureElementPromotion {
  promotedElement: Array<DataAccessPromotedElement>;
}

export interface ObjectTypeLabel {
  propertyName?: string; // supply this or label (not both) - label is linked to the property
  label?: string; // supply this or property (not both) - hardcoded label
  colour?: string; // CSS colour
  yOffset?: number; // +ve moves label DOWN, -ve moves label UP. Default (0) is in the center.
}

export interface DataAccessFeatureTypeIconDisplayHandler {
  featureElementPromotion: DataAccessFeatureElementPromotion;
  parameterDisplayProcessor?: { ref: string };
  truthTableIconHandler?: ObjectTypeIconOverrides;
  label?: ObjectTypeLabel;
}

export interface DataAccessFeatureTypeData {
  id: number | string;
  name: string;
  group: string;
  constantName: string;
  type: 'Container' | null | undefined;

  // Warning: The following properties are terribly named, and confuse EVERYBODY.
  modifiable: boolean;
  available: boolean;
  user_feature: boolean;
  isZoneRequired?: boolean;
  version: number;
  featureTypeStateTypes: DataAccessFeatureTypeStateTypeDatas;
  objectParameters: DataAccessObjectParameters;
  featureElements: DataAccessFeatureElements;
  featureTypeIcon: DataAccessFeatureTypeIconData;
  featureTypeIconDisplayHandler: DataAccessFeatureTypeIconDisplayHandler;
  status?: string;
  history?: DataAccessObjectHistory;
}

export interface DataAccessFeatureTypeDatas {
  featureType: DataAccessFeatureTypeData[];
}

export interface DataAccessObjectHistory {
  historyLog: DataAccessObjectHistoryLog[];
}

export interface DataAccessObjectHistoryLog extends EditHistory {
  version: number;
}

export interface DataAccessCoordinateFrame {
  type: string;
}

export interface DataAccessGeometry {
  x: number;
  y: number;
  z: number;
  heading: number;
  pitch: number;
  roll: number;
}

export interface DataAccessFeatureGeometry {
  coordinate_frame: DataAccessCoordinateFrame;
  geometry: DataAccessGeometry;
}

// export interface DataAccessFeatureParameters {
//   parameter: { $: { name: string; source: string }; _: string };
// }

export interface DataAccessFeatureParameter {
  name: string;
  _: string;
}
