/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ObjectQuickActionConfig, QUICK_OBJECT_ACTIONS_DISABLED } from './object-quick-action.model';

export interface ObjectsDetailsConfig {
  quickActionSettings: ObjectQuickActionConfig;
  editName: boolean;
  editPosition: boolean;
  editVirtual: boolean;
  editProperties: 'all' | 'none' | 'not-computed';
  /** disables being able to set state. */
  disabled: boolean;
  stateLocked?: boolean;
}

export const ACTIONS_DISABLED: ObjectsDetailsConfig = {
  quickActionSettings: QUICK_OBJECT_ACTIONS_DISABLED,
  editName: false,
  editPosition: false,
  editVirtual: false,
  editProperties: 'none',
  disabled: true
};
