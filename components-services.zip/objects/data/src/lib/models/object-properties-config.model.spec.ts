/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { getObjectTypePropertyConfig, ObjectPropertiesConfig } from './object-properties-config.model';

describe('getObjectTypePropertyConfig', () => {
  const config: ObjectPropertiesConfig = {
    '\\dR_(?:\\dC_|Mixed_Font_Size_)?(?:REC|SQR)_Plate_(?:White|Black)': {
      'label_\\d': {
        placeholder: 'Enter Label Text (max {maxCharacters} characters)'
      }
    },
    '\\dR_2C_(?:REC|SQR)_Plate_(?:White|Black)': {
      'label_\\d': {
        maxCharacters: 2
      }
    },
    '\\dR_3C_(?:REC|SQR)_Plate_(?:White|Black)': {
      'label_\\d': {
        maxCharacters: 3
      }
    },
    '\\dR_4C_(?:REC|SQR)_Plate_(?:White|Black)': {
      'label_\\d': {
        maxCharacters: 4
      }
    },
    '\\dR_5C_(?:REC|SQR)_Plate_(?:White|Black)': {
      'label_\\d': {
        maxCharacters: 5
      }
    },
    '\\dR_6C_(?:REC|SQR)_Plate_(?:White|Black)': {
      'label_\\d': {
        maxCharacters: 6
      }
    },
    '\\dR_9C_(?:REC|SQR)_Plate_(?:White|Black)': {
      'label_\\d': {
        maxCharacters: 9
      }
    },
    '2R_Mixed_Font_Size_(?:REC|SQR)_Plate_(?:White|Black)': {
      'label_\\d': {
        maxCharacters: 8
      }
    },
    '3R_REC_Plate_(?:White|Black)': {
      'label_\\d': {
        maxCharacters: 2
      }
    },
    'Speed_Plate_(?:White|Yellow)': {
      label_1: {
        placeholder: 'Enter Label Text (max 3 characters)',
        maxCharacters: 3
      }
    },
    'Speed_Sign_(?:White|Yellow)_(?:Left|Right)': {
      label_1: {
        placeholder: 'Enter Label Text (max 3 characters)',
        maxCharacters: 3
      }
    },
    'Track_Speed_Sign_(?:Blue|White|Yellow)': {
      label_1: {
        placeholder: 'Enter Label Text (max 3 characters)',
        maxCharacters: 3
      }
    },
    'Track_Speed_Sign_Blue': {
      label_1: {
        placeholder: 'Track Speed Sign Blue Label'
      }
    },
    'Exact Only': {
      label_1: {
        placeholder: 'Exact Only'
      }
    }
  };

  it('Test exact match and regex match', () => {
    const propertyConfig = getObjectTypePropertyConfig(config, 'Track_Speed_Sign_Blue', 'label_1');

    expect(propertyConfig).toEqual({
      placeholder: 'Track Speed Sign Blue Label',
      maxCharacters: 3
    });
  });

  it('Test exact match', () => {
    const propertyConfig = getObjectTypePropertyConfig(config, 'Exact Only', 'label_1');

    expect(propertyConfig).toEqual({
      placeholder: 'Exact Only',
      maxCharacters: undefined
    });
  });

  it('Test regex match', () => {
    const propertyConfig = getObjectTypePropertyConfig(config, 'Track_Speed_Sign_Yellow', 'label_1');

    expect(propertyConfig).toEqual({
      placeholder: 'Enter Label Text (max 3 characters)',
      maxCharacters: 3
    });
  });

  it('Test no match for property key', () => {
    const propertyConfig = getObjectTypePropertyConfig(config, 'Track_Speed_Sign_Yellow', 'label_2');

    expect(propertyConfig).toEqual({
      placeholder: undefined,
      maxCharacters: undefined
    });
  });

  it('Test no match', () => {
    const propertyConfig = getObjectTypePropertyConfig(config, 'No Match', 'label_1');

    expect(propertyConfig).toEqual({
      placeholder: undefined,
      maxCharacters: undefined
    });
  });
});
