/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgModule } from '@angular/core';

import { PointTypeDataService } from './services/point-type-data.service';

@NgModule({
  providers: [PointTypeDataService]
})
export class OksygenSimTrainPointServicesModule {}
