/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable } from 'rxjs';

import { ObjectTypeContainer } from '../models/object-type.model';
import { PlacementKey } from '../services/base-object-type-data.service';

export interface IObjectTypeDataService {
  typesMap$(): Observable<Map<string, ObjectTypeContainer>>;

  types$(): Observable<Array<ObjectTypeContainer>>;

  placementTypes$(params?: PlacementKey): Observable<Array<ObjectTypeContainer>>;
}
