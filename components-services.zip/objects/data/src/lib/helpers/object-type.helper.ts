/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import { GlobalImageStoreKey, ImageService, ImageServicePreloadConfig } from '@oksygen-sim-train-libraries/components-services/common';

import { IObjectTypeDataService } from '../interfaces/object-type-data.interface';
import { IPointTypeDataService } from '../interfaces/point-type-data.interface';

/**
 * Starts loading Object Type icons.
 * This can be useful for having these images ready prior to trying to use MapBox,
 * which currently needs icons supplied at startup.
 * Triggering this ahead of time can improve session startup time.
 * An observable is returned so that this may be used as an application initializer
 * (though beware that this might be tricky to do due to dependencies and ordering).
 * This is a simple wrapper that makes sure object types have been loaded, before triggering the preload in imageService
 *
 * @param objTypes The object types service.
 * @returns A observable which will return the percentage of images that have loaded.
 */
export function startLoadingObjectTypeIcons(
  objTypes: IObjectTypeDataService,
  imageService: ImageService,
  config?: ImageServicePreloadConfig
): Observable<number> {
  if (isNil(config)) {
    config = { keys: [GlobalImageStoreKey.SMALL] };
  }

  return objTypes.types$().pipe(
    takeOneTruthy(),
    switchMap(() => imageService.preloadImageByPath(config))
  );
}

export function startLoadingPointTypeIcons(
  pointTypes: IPointTypeDataService,
  imageService: ImageService,
  config?: ImageServicePreloadConfig
): Observable<number> {
  if (isNil(config)) {
    config = { keys: [GlobalImageStoreKey.SMALL] };
  }

  return pointTypes.pointType$().pipe(
    takeOneTruthy(),
    switchMap(() => imageService.preloadImageByPath(config))
  );
}
