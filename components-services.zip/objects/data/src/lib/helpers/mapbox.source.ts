/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FeatureCollection } from 'geojson';
import { ExpressionSpecification } from 'maplibre-gl';

import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectData } from '@oksygen-sim-core-libraries/data-types/objects';

import { ObjectType } from '../models/object-type.model';

// this has to match how the name is created in objectTypeIconName below
export const MAPBOX_LAYER_FILTER: ExpressionSpecification = ['get', 'icon'];

export function objectTypeIconName(type: ObjectType, size?: 'S' | 'B', stateId?: number): string {
  const state = type.states.get(stateId) ?? type.defaultState;

  if (!state) {
    return '';
  }

  const icon = size === 'B' ? state.icons.big : state.icons.small;

  return icon.id;
}

export function asSynopticViewRegionGeoJSON(objects: Map<number, ObjectData>): FeatureCollection {
  const features: any[] = [];

  objects.forEach((o, id) => {
    if (o.boundaries && o.boundaries.length > 0) {
      o.boundaries.forEach(b => {
        // GeoJSON expects an array containing an outer shape
        // and inner shapes which are cut out of the outer one.
        const coordinates = new Array<Array<LngLatCoord>>();
        const outer = new Array<LngLatCoord>(...b);
        // We need to repeat the first coord as per GeopJSON spec
        outer.push(b[0]);
        coordinates.push(outer);
        // We don't support inner shapes.

        features.push({
          type: 'Feature',
          id: o.id,
          properties: {
            // TODO needs to be localised
            name: o.name,
            type: o.type
          },
          geometry: {
            type: 'Polygon',
            coordinates
          }
        });
      });
    }
  });

  return {
    type: 'FeatureCollection',
    features
  };
}

export function asRegionLabelGeoJSON(objects: Map<number, ObjectData>): FeatureCollection {
  const features: any[] = [];

  objects.forEach(o => {
    if (o.boundaries && o.boundaries.length > 0) {
      features.push({
        type: 'Feature',
        id: o.id,
        properties: {
          // TODO needs to be localised
          name: o.name,
          type: o.type
        },
        geometry: {
          type: 'Point',
          coordinates: o.boundaries[0][0]
        }
      });
    }
  });

  return {
    type: 'FeatureCollection',
    features
  };
}
