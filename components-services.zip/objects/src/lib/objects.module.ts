/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainWorldDefinitionModule } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ObjectTypeListComponent } from './components/object-type-list/object-type-list.component';
import { ObjectTypeListItemComponent } from './components/object-type-list/object-type-list-item/object-type-list-item.component';
import { ObjectsDetailsPropertyComponent } from './components/objects-details/objects-details-property/objects-details-property.component';
import { ObjectsDetailsStateComponent } from './components/objects-details/objects-details-state/objects-details-state.component';
import { ObjectsDetailsTrackComponent } from './components/objects-details/objects-details-track/objects-details-track.component';
import { ObjectsDetailsComponent } from './components/objects-details/objects-details.component';
import { ObjectsListItemComponent } from './components/objects-list/objects-list-item/objects-list-item.component';
import { ObjectsListComponent } from './components/objects-list/objects-list.component';
import { ObjectsStateSelectComponent } from './components/objects-state-select/objects-state-select.component';

const components = [
  ObjectTypeListComponent,
  ObjectTypeListItemComponent,
  ObjectsDetailsPropertyComponent,
  ObjectsDetailsStateComponent,
  ObjectsDetailsTrackComponent,
  ObjectsDetailsComponent,
  ObjectsListItemComponent,
  ObjectsListComponent,
  ObjectsStateSelectComponent
];

@NgModule({
  declarations: components,
  imports: [
    RouterModule,
    CommonModule,
    DragDropModule,
    OksygenMaterialComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    // this is ugly to repeat everywhere, but it's the only way for this to be properly initialised
    OksygenMaterialTranslateModule.forChild(),
    OksygenSimTrainCommonModule,
    OksygenSimTrainWorldDefinitionModule
  ],
  exports: components
})
export class OksygenSimTrainObjectsModule {}
