/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, ElementRef, input, OnInit } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';

import { defaultImages, ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import { enableDragHandlingAndHandleDragImage } from '@oksygen-sim-train-libraries/components-services/component-library';
import { asFreezableObjectType, ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

// possibly belongs somewhere more common
/**
 * Checks if the given data (possibly from a specially encoded drag action) looks like an Object Type.
 * @param maybeObjectTypeData an Object Type or an Object Type that has been mangled for inspection during drag.
 */
export function isObjectTypeData(maybeObjectTypeData: any): boolean {
  if (!maybeObjectTypeData) {
    return false;
  }

  // Note that any tests for properties or values with capital letters need to also test for a similar lowercase property,
  // due to potential mangling during a drag.
  if (
    maybeObjectTypeData.name &&
    maybeObjectTypeData.group &&
    maybeObjectTypeData.states &&
    (maybeObjectTypeData.numericProperties || maybeObjectTypeData.numericproperties) &&
    (maybeObjectTypeData.textProperties || maybeObjectTypeData.textproperties)
  ) {
    return true;
  }

  return false;
}

@Component({
  selector: 'oksygen-object-type-list-item',
  templateUrl: './object-type-list-item.component.html',
  styleUrls: ['./object-type-list-item.component.scss']
})
export class ObjectTypeListItemComponent implements OnInit {
  objectType = input.required<ObjectTypeContainer>();

  iconUri: string | SafeUrl = defaultImages.object;
  private img: HTMLElement | null = null;

  constructor(private host: ElementRef, private imageService: ImageService) {
    effect(() => {
      this.updateIcon(this.objectType());
    });
  }

  ngOnInit(): void {
    enableDragHandlingAndHandleDragImage(this.host, 'object', asFreezableObjectType(this.objectType()));
  }

  private updateIcon(objectType: ObjectTypeContainer): void {
    const promotedChild = this.objectType()?.children?.find(c => c.promoted);
    if (promotedChild) {
      this.imageService.loadIconImageObservable(promotedChild?.child?.defaultIcons?.small, defaultImages.object)?.subscribe(uri => (this.iconUri = uri));
    } else {
      this.imageService.loadIconImageObservable(objectType?.defaultIcons?.small, defaultImages.object)?.subscribe(uri => (this.iconUri = uri));
    }
  }
}
