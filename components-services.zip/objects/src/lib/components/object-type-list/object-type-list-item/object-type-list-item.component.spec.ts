/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, fakeAsync, TestBed, tick, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule, createTestObjectType } from '@oksygen-sim-train-libraries/components-services/testing';

import { isObjectTypeData, ObjectTypeListItemComponent } from './object-type-list-item.component';
import { ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { ImageService } from '@oksygen-sim-train-libraries/components-services/common';

const objectType: ObjectTypeContainer = {
  children: [],
  name: 'Hulk',
  group: { name: 'Marvel' },
  type: 'Container',
  textProperties: new Map(),
  numericProperties: new Map(),
  booleanProperties: new Map(),
  enumProperties: new Map(),
  states: new Map(),
  defaultIcons: { small: null, big: null }
};

describe('ObjectTypeListItemComponent', () => {
  let component: ObjectTypeListItemComponent;
  let fixture: ComponentFixture<ObjectTypeListItemComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [ObjectTypeListItemComponent],
      providers: [ImageService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectTypeListItemComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('objectType', createTestObjectType());
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should check if the data looks like an object type', () => {
    fixture.detectChanges();
    expect(isObjectTypeData(null)).toBe(false);
    expect(isObjectTypeData(objectType)).toBeTruthy();
  });
  it('should update the icon on init if there are no children', fakeAsync(() => {
    // eslint-disable-next-line @typescript-eslint/dot-notation
    const spy = spyOn(component['imageService'], 'loadIconImageObservable');
    fixture.componentRef.setInput('objectType', createTestObjectType());
    tick();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  }));
  it('should update the icon on init if there are children', fakeAsync(() => {
    // eslint-disable-next-line @typescript-eslint/dot-notation
    const spy = spyOn(component['imageService'], 'loadIconImageObservable');
    const testObjectType = createTestObjectType();
    testObjectType.children = [{ name: 'Child', child: objectType, promoted: true }];
    fixture.componentRef.setInput('objectType', testObjectType);
    tick();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  }));
});
