/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, fakeAsync, TestBed, tick, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ObjectTypeListComponent } from './object-type-list.component';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { ObjectTypeListItemComponent } from './object-type-list-item/object-type-list-item.component';
import { ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

describe('ObjectTypeListComponent', () => {
  let component: ObjectTypeListComponent;
  let parentComponent: TestHostComponent;
  let fixture: ComponentFixture<TestHostComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [ObjectTypeListComponent, ObjectTypeListItemComponent, TestHostComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    const translate = TestBed.inject(TranslateService);
    translate.addLangs(['en_AU']);
    translate.currentLang = 'en_AU';
    fixture = TestBed.createComponent(TestHostComponent);
    parentComponent = fixture.componentInstance;
    parentComponent.searchable = true;
    fixture.detectChanges();
    component = parentComponent.objectTypeListComponent;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should set the search filter when typing in the input field', fakeAsync(() => {
    const event = new KeyboardEvent('keyup', {
      bubbles: true,
      cancelable: true,
      shiftKey: false
    });
    const input = fixture.debugElement.query(By.css('input')).nativeElement;
    input.value = 'test';
    input.dispatchEvent(event);
    fixture.detectChanges();
    // We have a 500ms debounce time
    tick(1000);
    expect(component.filteredObjects.length).toEqual(0);

    input.value = 'don';
    input.dispatchEvent(event);
    fixture.detectChanges();
    tick(1000);
    expect(component.filteredObjects.length).toEqual(1);
    expect(component.filteredObjects[0].name).toEqual('Donald');

    input.value = 'dis';
    input.dispatchEvent(event);
    fixture.detectChanges();
    tick(1000);
    // We should get every object in the Disney group
    expect(component.filteredObjects.length).toEqual(4);

    input.value = 'sh';
    input.dispatchEvent(event);
    fixture.detectChanges();
    tick(1000);
    expect(component.filteredObjects.length).toEqual(2); // Shrek and Shrak despite being on different groups
  }));
  it('should create groups and set the search filter when there are objects changes', () => {
    parentComponent.objectTypes = [
      {
        children: null,
        name: 'Hulk',
        group: { name: 'Marvel' },
        type: 'Container',
        textProperties: null,
        numericProperties: null,
        booleanProperties: null,
        enumProperties: null,
        states: new Map(),
        defaultIcons: null
      }
    ];
    fixture.detectChanges();
    expect(component.filteredObjects.length).toEqual(1);
    expect(component.filteredObjects[0].name).toEqual('Hulk');
    expect(component.groups[0].group).toEqual('Marvel');
  });
});

@Component({
  template: `<oksygen-object-type-list [objectTypes]="objectTypes" [searchable]="searchable" />`
})
class TestHostComponent {
  objectTypes: ObjectTypeContainer[] = [
    {
      children: null,
      name: 'Donald',
      group: { name: 'Disney' },
      type: 'Container',
      textProperties: null,
      numericProperties: null,
      booleanProperties: null,
      states: new Map(),
      defaultIcons: null,
      enumProperties: null
    },
    {
      children: null,
      name: 'Dingo',
      group: { name: 'Disney' },
      type: 'Container',
      textProperties: null,
      numericProperties: null,
      booleanProperties: null,
      states: new Map(),
      defaultIcons: null,
      enumProperties: null
    },
    {
      children: null,
      name: 'Mickey',
      group: { name: 'Disney' },
      type: 'Container',
      textProperties: null,
      numericProperties: null,
      booleanProperties: null,
      states: new Map(),
      defaultIcons: null,
      enumProperties: null
    },
    {
      children: null,
      name: 'Shrak?',
      group: { name: 'Disney' },
      type: 'Container',
      textProperties: null,
      numericProperties: null,
      booleanProperties: null,
      states: new Map(),
      defaultIcons: null,
      enumProperties: null
    },
    {
      children: null,
      name: 'Shrek',
      group: { name: 'Dreamworks' },
      type: 'Container',
      textProperties: null,
      numericProperties: null,
      booleanProperties: null,
      states: new Map(),
      defaultIcons: null,
      enumProperties: null
    }
  ];
  searchable: boolean;
  @ViewChild(ObjectTypeListComponent) objectTypeListComponent: ObjectTypeListComponent;
}
