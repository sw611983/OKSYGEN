/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, input, output } from '@angular/core';
import { isNil } from 'lodash';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { allFilterTypesMatch, Filter, filterMatches, SelectedFilterArray, Sorter, SorterPipe } from '@oksygen-common-libraries/material/components';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Logging } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

interface ObjectGroup {
  group: string;
  objects: ObjectTypeContainer[];
}

interface ObjectTypeListState {
  filters: ObjectTypeListFilter;
}

export interface ObjectTypeListFilter {
  search: string;
  selectedFilters: SelectedFilterArray<ObjectTypeListFilterType>;
}

export enum ObjectTypeListFilterType {
  // These names are used to select the icon on chips of that type
  OBJECT_TYPE_GROUP = 'object',
  NAME = 'search'
}

@Component({
  selector: 'oksygen-object-type-list',
  templateUrl: './object-type-list.component.html',
  styleUrls: ['./object-type-list.component.scss']
})
export class ObjectTypeListComponent {
  public readonly objects$ = input<Observable<Array<ObjectTypeContainer>> | undefined>(undefined);
  public readonly objectTypes = input<Array<ObjectTypeContainer> | undefined>(undefined);
  public readonly searchable = input<boolean>(false);
  public readonly uiModels = input<UiStateModelManager | undefined>(undefined);
  public readonly uiModelKey = input<string>('oksygen-object-type-list');
  public readonly sourceFilters = input<Array<Filter<ObjectTypeListFilterType>> | undefined>(undefined);
  public readonly showTitle = input<boolean>(false);
  public readonly allowTypeSelection = input<boolean>(false);
  public readonly objectTypeSelected = output<ObjectTypeContainer>();

  state: ObjectTypeListState = {
    filters: {
      search: '',
      selectedFilters: new SelectedFilterArray<ObjectTypeListFilterType>()
    }
  };

  _sourceFilters: Array<Filter<ObjectTypeListFilterType>> = [];

  activeObjectType: ObjectTypeContainer | undefined;

  groups: Array<ObjectGroup>;
  filtersSubject: BehaviorSubject<Array<string>> = new BehaviorSubject([]);
  searchTextSubject = new BehaviorSubject('');
  searchText$: Observable<string>;
  sorter = new Sorter<ObjectTypeContainer>();
  filteredObjects: Array<ObjectTypeContainer> = [];

  objectTypeGroups: Array<string> = [];

  private sorterPipe = new SorterPipe();

  _objectTypes: Array<ObjectTypeContainer> = [];

  constructor(private readonly logging: Logging, private readonly translateService: TranslateService) {
    // TODO will need localised names here
    this.sorter.sortFunction = (c, a, b): number => a?.group?.name?.localeCompare(b?.group?.name, translateService.currentLocaleString);

    effect(() => {
      const filters = this.sourceFilters();

      if (!isNil(filters)) {
        this._sourceFilters = filters.sort((a, b) => a.displayText.localeCompare(b.displayText, this.translateService.currentLocaleString));
      }
    });

    effect(() => {
      const uiModels = this.uiModels();
      const uiModelKey = this.uiModelKey();

      if (!isNil(uiModels)) {
        this.state = uiModels.getStateModel<any>(uiModelKey, () => ({
          filters: {
            typeGroupFilters: [],
            search: '',
            selectedFilters: new SelectedFilterArray<ObjectTypeListFilterType>()
          }
        }));
      } else {
        this.state = {
          filters: {
            search: '',
            selectedFilters: new SelectedFilterArray<ObjectTypeListFilterType>()
          }
        };
      }

      this.applyFilters();
    });

    effect(onCleanup => {
      const objects$ = this.objects$();
      const objectTypes = this.objectTypes();

      let objectsSubscription = Subscription.EMPTY;

      if (!isNil(objects$)) {
        objectsSubscription = this.objects$().subscribe(objects => {
          this._objectTypes = objects?.filter(ot => ot.placementRules?.placeable ?? true) ?? [];
          this.objectTypeGroups = [];

          this._objectTypes.forEach(o => {
            const group = this.objectTypeGroups.find(g => g === o.group.name);
            if (!group) {
              this.objectTypeGroups.push(o.group.name);
            }
          });

          // this.objectTypeGroups.sort((a, b) => a?.localeCompare(b, this.translateService.currentLocaleString));
          this.objectTypeGroups = this.objectTypeGroups
            .filter(item => typeof item === 'string')
            .sort((a, b) => a.localeCompare(b, this.translateService.currentLocaleString));

          this.applyFilters();
        });
      } else if (!isNil(objectTypes)) {
        this._objectTypes = objectTypes;

        this.objectTypeGroups = [];

        this._objectTypes.forEach(o => {
          const group = this.objectTypeGroups.find(g => g === o.group.name);
          if (!group) {
            this.objectTypeGroups.push(o.group.name);
          }
        });

        // this.objectTypeGroups.sort((a, b) => a?.localeCompare(b, this.translateService.currentLocaleString));
        this.objectTypeGroups = this.objectTypeGroups
          .filter(item => typeof item === 'string')
          .sort((a, b) => a.localeCompare(b, this.translateService.currentLocaleString));

        this.applyFilters();
      }

      onCleanup(() => objectsSubscription.unsubscribe());
    });
  }

  createGroups(): void {
    this.groups = [];

    if (this.filteredObjects?.length === this._objectTypes.length) {
      this.filteredObjects?.forEach(o => {
        const group = this.groups.find(g => g.group === o.group.name);
        if (!group) {
          this.groups.push({
            group: o.group.name,
            objects: [o]
          });
        } else {
          group.objects.push(o);
        }
      });
    }
  }

  clearFilters(): void {
    this.state.filters.selectedFilters = this.state.filters.selectedFilters.filter(f => f.type !== ObjectTypeListFilterType.OBJECT_TYPE_GROUP);
    this.applyFilters();
  }

  onCurrentValueUpdate(search: string): void {
    this.state.filters.search = search;

    // Note that when the user hits enter in the text box there is a moment where
    // there is no text in the box but the chip hasn't been created yet.
    // Filtering at this time may result in a glitchy looking update.
    // The following delays the refiltering to avoid this.
    // FIXME The common component should suppress the string updates in this situation
    // (at least until its internal state has become consistant).
    this.updateFiltersLater();
  }

  updateFiltersLater(): void {
    // wait for the selectedFilters to hopefully update before applying the filters
    // setTimeout(() => this.applyFilters(), 250);
    this.applyFilters();
  }

  applyFilters(): void {
    if (!this._objectTypes) {
      return;
    }

    this.filteredObjects = [];
    this.filteredObjects =
      this._objectTypes.filter(object => {
        const names = [object.name, object.group?.name];

        try {
          if (
            !allFilterTypesMatch(
              [
                { t: ObjectTypeListFilterType.OBJECT_TYPE_GROUP, v: object.group.name, strict: true },
                { t: ObjectTypeListFilterType.NAME, v: names }
              ],
              this.state.filters.selectedFilters
            )
          ) {
            return false;
          }
        } catch {
          return false;
        }

        if (!filterMatches(names, this.state.filters.search)) {
          return false;
        }

        if (
          !filterMatches(
            object.group.name,
            this.state.filters.selectedFilters.find(f => f.type === ObjectTypeListFilterType.OBJECT_TYPE_GROUP)
          )
        ) {
          return false;
        }

        return true;
      }) ?? [];

    this.filteredObjects = this.sorterPipe.transform(this.filteredObjects, this.sorter, this.sorter.refresh);
    this.createGroups();
  }

  textToFilter(text: string): Filter<string> {
    return new Filter(ObjectTypeListFilterType.NAME, text);
  }

  /**
   * Adds the given filter to the selected filters, removing any other filters of the same type.
   */
  setUniqueFilterType(filter: Filter<ObjectTypeListFilterType>): void {
    if (filter) {
      this.state.filters.selectedFilters.replace(filter.type, filter);
      this.applyFilters();
    }
  }

  filterByTypeGroup(typeGroup: string): void {
    if (!!typeGroup && typeGroup.length > 0) {
      this.setUniqueFilterType(new Filter(ObjectTypeListFilterType.OBJECT_TYPE_GROUP, typeGroup));
    }
  }

  setActiveObjectType(objectType: ObjectTypeContainer): void {
    if (this.allowTypeSelection()) {
      this.activeObjectType = objectType;
      this.objectTypeSelected.emit(objectType);
    }
  }
}
