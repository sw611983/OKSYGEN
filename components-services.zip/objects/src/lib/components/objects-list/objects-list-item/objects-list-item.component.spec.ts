/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';

import { computeIfAbsent } from '@oksygen-common-libraries/common';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectSource, ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import {
  configureSimTrainTestingModule,
  SCENARIO_EDITOR_CONTEXT_PROVIDERS,
  TEST_TRACK_NAME
} from '@oksygen-sim-train-libraries/components-services/testing';
import {
  OksygenSimTrainWorldDefinitionModule,
  WorldDefinitionService
} from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ObjectsListItemComponent } from './objects-list-item.component';

describe('ObjectsListItemComponent', () => {
  let component: ObjectsListItemComponent;
  let fixture: ComponentFixture<ObjectsListItemComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainWorldDefinitionModule.forRoot()],
      declarations: [ObjectsListItemComponent],
      providers: SCENARIO_EDITOR_CONTEXT_PROVIDERS
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectsListItemComponent);
    component = fixture.componentInstance;
    const ft: ObjectTypeContainer = {
      name: 'Test Type',
      type: null,
      textProperties: null,
      booleanProperties: null,
      numericProperties: null,
      enumProperties: null,
      group: { name: 'Test Group' },
      defaultIcons: null,
      defaultState: null,
      children: [],
      states: new Map()
    };
    component.object = {
      id: 67,
      name: 'Test',
      source: ObjectSource.TRACK,
      location: { lnglat: [5, 21] },
      boundaries: new Array<Array<LngLatCoord>>(),
      objectType: ft,
      children: [],
      selectedIcon: null,
      selectedState: null,
      stateAutomated: false,
      stateVirtual: false,
      states: new Map(),
      trackAssociations: [],
      displayState: null
    };

    const worldDefService = TestBed.inject(WorldDefinitionService);
    spyOn(worldDefService, 'loadWorld').and.returnValue(
      new Promise((resolve, reject) => {
        const subject = computeIfAbsent((worldDefService as any).worldDataSubjects, TEST_TRACK_NAME, x => new BehaviorSubject<WorldData>(null));

        resolve(subject.value);
      })
    );

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
