/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Inject, Input, OnDestroy, OnInit, Optional, Output, signal } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';
import { of, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import { getObjectRenderInfo, ObjectEditManager, ObjectLabel } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { filterTruthy, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { defaultImages, GlobalImageStoreKey, ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import {
  isObjectDataMapContext,
  OBJECT_MAP_RENDERER_TOKEN,
  ObjectDataMapContext,
  ObjectDataMapContextSupplier,
  ObjectMapRenderer,
  ZoomLevel
} from '@oksygen-sim-train-libraries/components-services/maps';
import {
  getDisplayObject,
  isObjectContainerPropertiesValid,
  ObjectContainer,
  ObjectQuickActionConfig,
  QUICK_OBJECT_ACTIONS_DISABLED,
  SimObject
} from '@oksygen-sim-train-libraries/components-services/objects/data';

/**
 * Changing the total height of this component impacts the calculation done in FavouritesPanelComponent
 * Please verify that this calculation is still appropriate if changing this component
 */
@Component({
  selector: 'oksygen-objects-list-item',
  templateUrl: './objects-list-item.component.html',
  styleUrls: ['./objects-list-item.component.scss']
})
export class ObjectsListItemComponent implements OnInit, OnDestroy {
  @Input() set object(object: ObjectContainer) {
    this._object = object;
    // set to be the object
    this.displayObject = getDisplayObject(object);
    this.isValid = isObjectContainerPropertiesValid(object);
  }

  @Input() settings: ObjectQuickActionConfig = QUICK_OBJECT_ACTIONS_DISABLED;

  @Output() readonly favouriteClick: EventEmitter<ObjectContainer> = new EventEmitter();
  @Output() readonly deleteClick: EventEmitter<ObjectContainer> = new EventEmitter();
  @Output() readonly orientationClick: EventEmitter<ObjectContainer> = new EventEmitter();

  @Input() objectEditManager: ObjectEditManager;

  trackAssociations: TrackSegmentAssociation[];

  _object: ObjectContainer;
  isValid: boolean;

  iconUri = signal<string | SafeUrl>(defaultImages.object);
  iconLabel = signal<ObjectLabel>(null);

  private displayObject: SimObject;

  private subscriptions = new Subscription();

  constructor(
    private readonly imageService: ImageService,
    private readonly logger: Logging,
    private readonly registry: Registry,
    private readonly contextSupplier: ObjectDataMapContextSupplier,
    @Inject(OBJECT_MAP_RENDERER_TOKEN) @Optional() protected overrideObjectRenderer?: ObjectMapRenderer
  ) {}

  ngOnInit(): void {
    this.subscriptions.add(
      this.contextSupplier
        .currentContext$()
        .pipe(
          filterTruthy(),
          switchMap(m => {
            if (isObjectDataMapContext(m)) {
              this.updateIcon(this.displayObject);
              return m.objects.getObject$(this.displayObject.id);
            }

            return of(null);
          }),
          filterTruthy()
        )
        .subscribe(f => {
          // Note that we can't use this.displayObject here, as it may not have the latest state yet.
          this.updateIcon(f);
        })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private updateIcon(object: SimObject): void {
    this.iconLabel.set(null);

    if (object?.objectType?.mapOverrides) {
          const overrides = getObjectRenderInfo(object, object.objectType?.defaultIcons?.big.id);
          if (overrides.label) {
            this.iconLabel.set(overrides.label);
          }
          const image = this.imageService.getGlobalImage(GlobalImageStoreKey.SMALL, `${overrides.icon}`);
          this.imageService.loadIconImageObservable(image, defaultImages.object).subscribe(uri => {
            this.iconUri.set(uri);
          });
          return;
        }

    if (this.overrideObjectRenderer && object?.objectType?.mapRenderer) {
      const renderer = this.overrideObjectRenderer.renderers.get(object.objectType.mapRenderer);

      if (renderer) {
        const overrides = renderer(object as any);
        if (overrides.label) {
          this.iconLabel.set({text: overrides.label, colour: '#000000', yOffset: 0});
        }

        if (overrides.icon) {
          const image = this.imageService.getGlobalImage(GlobalImageStoreKey.SMALL, `${overrides.icon}`);
          this.imageService.loadIconImageObservable(image, defaultImages.object).subscribe(uri => {
            this.iconUri.set(uri);
          });
          return;
        }
      }
    }

    const img = object.selectedIcon?.big ?? object.objectType?.defaultIcons?.big;
    this.imageService.loadIconImageObservable(img, defaultImages.object).subscribe(uri => {
      this.iconUri.set(uri);
    });
  }

  hoverIcon(): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy<ObjectDataMapContext>(undefined, 200))
      .subscribe(
        m => {
          m.map.spotlightObject(this._object.id);
        },
        err => this.logger.warn(`Could not hover object: ${this._object?.id}`)
      );
  }

  dehoverIcon(): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy<ObjectDataMapContext>(undefined, 200))
      .subscribe(
        m => {
          m.map.removeSpotlightObject(this._object.id);
        },
        err => this.logger.warn(`Could not de-hover object: ${this._object?.id}`)
      );
  }

  favourite(event?: Event): void {
    event?.stopPropagation();
    this.favouriteClick.emit(this._object);
  }

  delete(event?: Event): void {
    event?.stopPropagation();
    this.deleteClick.emit(this._object);
  }

  updateObjectOrientation(event?: Event): void {
    event?.stopPropagation();
    this.orientationClick.emit(this._object);
  }

  locate(event?: Event): void {
    this.logger.log(this._object.name + ' locate clicked.');
    event?.stopPropagation();
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy<ObjectDataMapContext>(undefined, 200))
      .subscribe(
        m => {
          const toggles = m.map.mapTogglesSubject.getValue();
          if (toggles.follow === true) {
            const updateToggles = { ...toggles };
            updateToggles.follow = false;
            m.map.mapTogglesSubject.next(updateToggles);
          }
          const usePromotedChild = this.registry.getBoolean(['maps', 'config', 'objects', 'usePromotedChildPosition'], false);
          const objectPositionSupplier = usePromotedChild ? this.displayObject : this._object;
          m.map.mapGoto([objectPositionSupplier.location.lnglat[0], objectPositionSupplier.location.lnglat[1]], ZoomLevel.STATION);
        },
        err => this.logger.warn(`Could not locate object: ${this._object?.id}`)
      );
  }



  toggleVisibility(visibility: string): void {
    // TODO implement visibility toggle
    this.logger.log('toggling visibility for ' + this._object.name);
  }
}
