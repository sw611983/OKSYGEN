/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ObjectsListComponent } from './objects-list.component';

describe('ObjectsListComponent', () => {
  let component: ObjectsListComponent;
  let fixture: ComponentFixture<ObjectsListComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [ObjectsListComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectsListComponent);
    component = fixture.componentInstance;
    component.objects = [];
    component.objectTypeGroups = [];
    component.uiModels = new UiStateModelManager();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
