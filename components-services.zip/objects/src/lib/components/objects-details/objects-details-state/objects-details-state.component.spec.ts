/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ObjectsStateSelectComponent } from '../../objects-state-select/objects-state-select.component';
import { ObjectsDetailsStateComponent } from './objects-details-state.component';

describe('ObjectsDetailsStateComponent', () => {
  let component: ObjectsDetailsStateComponent;
  let fixture: ComponentFixture<ObjectsDetailsStateComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [ObjectsDetailsStateComponent, ObjectsStateSelectComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectsDetailsStateComponent);
    const object$ = new Observable<any>(obs => {
      obs.next(null);
    });
    component = fixture.componentInstance;
    component.object$ = object$;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
