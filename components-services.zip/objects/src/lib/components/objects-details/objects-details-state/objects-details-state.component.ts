/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { forkJoin, Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { defaultImages, ImageService } from '@oksygen-sim-train-libraries/components-services/common';
import {
  AUTOMATED,
  DetailedFeatureTypeState,
  DISPLAY_STATE_OVERRIDE,
  ObjectStateChange,
  ObjectTypeState,
  SimObject
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { isNil } from 'lodash';

// FIXME: Update when containers can be automated

@Component({
  selector: 'oksygen-objects-details-state',
  templateUrl: './objects-details-state.component.html',
  styleUrls: ['./objects-details-state.component.scss']
})
export class ObjectsDetailsStateComponent implements OnInit, OnDestroy {
  @Input('object') object$!: Observable<SimObject>;
  @Input() isChild = false;
  @Input() disabled = false;

  // emissions contain both state and auto toggle
  @Output() readonly stateChange: EventEmitter<ObjectStateChange> = new EventEmitter();

  object: SimObject;
  states: DetailedFeatureTypeState[];

  selectedState: DetailedFeatureTypeState;

  displayState: DetailedFeatureTypeState;

  showAutoToggle: boolean;
  autoToggleValue: boolean;

  showDisplayOverrideToggle: boolean;
  displayOverrideValue: boolean;

  private subscription = new Subscription();

  constructor(private imageService: ImageService, private logger: Logging, private cd: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.subscription.add(
      this.object$.subscribe(object => {
        this.initSelected(object, this.object);
        this.initStates(object, this.object);
        this.initDisplayState(object, this.object);

        this.object = object;

        this.showAutoToggle = !isNil(object?.stateAutomated);

        if (this.showAutoToggle) {
          this.autoToggleValue = object.stateAutomated;
        }

        this.showDisplayOverrideToggle = this.displayOverrideToggle();

        if (this.showDisplayOverrideToggle) {
          this.displayOverrideValue = this.isDisplayStateOverriden();
        }
        setTimeout(() => this.cd.markForCheck() );
      })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  changeState(state: DetailedFeatureTypeState): void {
    this.stateChange.emit({ objectId: this.object.id, state, autoToggled: this.autoToggleValue });
  }

  changeAuto(isAuto: MatSlideToggleChange): void {
    this.stateChange.emit({ objectId: this.object.id, state: this.selectedState, autoToggled: isAuto.checked });
  }

  private async initSelected(object: SimObject, originalObject: SimObject): Promise<void> {
    const state = object?.selectedState ? object?.selectedState : object?.objectType?.defaultState;

    if (!state) {
      return;
    }

    // don't update the selectedstate if it hasn't changed
    if (object.id !== originalObject?.id || object.selectedState.id !== originalObject?.selectedState?.id) {
      this.toDetailedState(state).subscribe(
        detailState => {
          this.selectedState = detailState;
        },
        error => {
          this.logger.info('error updating selected state', error);
        }
      );
    }
  }

  private async initDisplayState(object: SimObject, originalObject: SimObject): Promise<void> {
    let state = object?.displayState ? object?.displayState : object?.objectType?.displayState;

    if (!state) {
      return;
    }

    // don't update the selectedstate if it hasn't changed
    if (object.id !== originalObject?.id || object?.displayState?.id !== originalObject?.displayState?.id) {
      if(isNil(state.icons)){
        state = object.states.get(state.id);
      }
      this.toDetailedState(state).subscribe(
        detailState => {
          this.displayState = detailState;
        },
        error => {
          this.logger.info('error updating selected state', error);
        }
      );
    }
  }

  private async initStates(object: SimObject, originalObject: SimObject): Promise<void> {
    if (!object) {
      this.states = [];
      return;
    }

    // don't update the states if they've not changed
    if (object.id !== originalObject?.id) {
      const stateObserables: Array<SelfCompletingObservable<DetailedFeatureTypeState>> = [];

      object.states.forEach(async state => {
        if (state?.name !== AUTOMATED) {
          stateObserables.push(this.toDetailedState(state));
        }
      });

      forkJoin(stateObserables).subscribe(states => {
        this.states = states;
      });
    }
  }

  private toDetailedState(state: ObjectTypeState): SelfCompletingObservable<DetailedFeatureTypeState> {
    return this.imageService.loadIconImageObservable(state.icons.small, defaultImages.object).pipe(map(icon => ({ icon, ...state })));
  }

  changeDisplayOverride(isDisplayOverride: MatSlideToggleChange): void {
    this.stateChange.emit({ objectId: this.object.id, state: this.displayState, displayOverrideToggled: isDisplayOverride.checked });
  }

  changeDisplayState(state: DetailedFeatureTypeState): void {
    this.stateChange.emit({ objectId: this.object.id, state, displayOverrideToggled: this.displayOverrideValue });
  }

  private isDisplayStateOverriden(): boolean {
    // Check if the `DISPLAY_STATE_OVERRIDE` property exists directly on `this.object.properties`.
    // If it exists, return true only if its value is 1.
    if (!isNil(this.object) && Object.prototype.hasOwnProperty.call(this.object?.properties, DISPLAY_STATE_OVERRIDE)) {
      return this.object.properties[DISPLAY_STATE_OVERRIDE] === 1;
    }

    // If the property is not available, fall back to the object type's `numericProperties`.
    // Check if the `numericProperties` Map has the `DISPLAY_STATE_OVERRIDE` key with a `defaultValue` of 1.
    let objectTypeOverride = this.object?.objectType?.numericProperties?.get(DISPLAY_STATE_OVERRIDE)?.defaultValue === 1;
    // Network definition currently does not support fetching properties from the object type XML
    // if they are missing from the object itself. Using default values from the XML in such cases
    // can cause ambiguity and errors during an active session.
    // Example error: "Server processing error - SetNumber failed, property 'Display Override'
    // not found in the object FeatureName".
    // To prevent such errors, we're disabling the display override toggle.
    if (objectTypeOverride) {
      this.logger.error('Display Override property is missing in the feature but exists in the feature type; toggling disabled to avoid session errors.');
      objectTypeOverride = !objectTypeOverride;
      this.showDisplayOverrideToggle = objectTypeOverride;
    }
    return objectTypeOverride;
  }

  /**
   * Check if object properties or object type numeric properties having display override property
   * @returns boolean value
   */
  private displayOverrideToggle(): boolean {
    return (
      (!isNil(this.object) && Object.prototype.hasOwnProperty.call(this.object?.properties, DISPLAY_STATE_OVERRIDE)) ||
      (!isNil(this.object?.objectType) && this.object?.objectType?.numericProperties?.has(DISPLAY_STATE_OVERRIDE))
    );
  }
}
