/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OksygenSimCoreUnitsModule } from '@oksygen-sim-core-libraries/components-services/measurement-units';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainWorldDefinitionModule } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ObjectsDetailsTrackComponent } from './objects-details-track.component';

describe('ObjectsDetailsTrackComponent', () => {
  let component: ObjectsDetailsTrackComponent;
  let fixture: ComponentFixture<ObjectsDetailsTrackComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimCoreUnitsModule, OksygenSimTrainCommonModule, OksygenSimTrainWorldDefinitionModule],
      declarations: [ObjectsDetailsTrackComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectsDetailsTrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
