/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Inject, Input, OnChanges, OnDestroy, Optional, Output, SimpleChanges } from '@angular/core';
import { Subscription } from 'rxjs';
import { filter, pairwise, startWith } from 'rxjs/operators';

import { newFormControl, newNumericFormControl, quietUpdateOptions, SnackBarWrapper, UpdateOn } from '@oksygen-common-libraries/material/components';
import {
  Angle,
  normaliseDegrees,
  Orientation,
  Point3D,
  reverse,
  SegOffset,
  SegOffsetOriented,
  UserScale,
  findDistanceFromLine2D,
  findPerpedicularPoint2D,
  LngLatCoord
} from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectGeometry, TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import { IReachablePathFinder, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import {
  getTrackAssocHeading,
  getTrackAssocPosition,
  getTrackAssocTrackName,
  getTrackAssocUserScales,
  ObjectContainer,
  ObjectWorldGeometry,
  toObjectGeometry
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { UserConfig } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import {
  createUIsForNewValues,
  NetworkDefinitionManager,
  processUserScaleUpdate,
  TrackLocationPanel3DOffsetInput,
  TrackLocationPanelSegmentOffsetInput,
  TrackLocationPanelTrackNameInput,
  TrackLocationPanelUserScaleInput,
  UserScaleUi
} from '@oksygen-sim-train-libraries/components-services/world-definition';
import { OBJECT_DETAILS_TRACK_USER_SCALE_UPDATE_TOKEN } from '../../../tokens/object.token';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Logging } from '@oksygen-common-libraries/pio';

interface TrackLocationConfig {
  trackName: TrackLocationPanelTrackNameInput;
  userScales: TrackLocationPanelUserScaleInput;
  segmentOffset: TrackLocationPanelSegmentOffsetInput;
  position3DOffset: TrackLocationPanel3DOffsetInput;
}

@Component({
  selector: 'oksygen-objects-details-track',
  templateUrl: './objects-details-track.component.html',
  styleUrls: ['./objects-details-track.component.scss']
})
export class ObjectsDetailsTrackComponent implements OnChanges, OnDestroy {
  @Input() index: number;
  @Input() isLast: boolean;
  @Input() object: ObjectContainer;
  @Input() trackAssociation: TrackSegmentAssociation;
  @Input() world: WorldData;
  @Input() netDef: NetworkDefinitionManager;
  @Input() pathFinder: IReachablePathFinder;
  @Input() editable: boolean;
  @Input() userConfig: UserConfig;

  trackLocationConfig: TrackLocationConfig;

  /** Derived from the track assoc. */
  private assocPos: Point3D;
  /** Derived from the track assoc. */
  private assocHeading: Angle;
  /** Derived from the track assoc. */
  private assocAtoB: boolean;
  private updateStrategy = UpdateOn.BLUR;

  /**
   * Emits requested updates to segment/offset.
   * This may use offsets beyond the valid range of the segment.
   * It is anticipated that code processing this will handle that case,
   * typically by either rejecting the request or moving to the next segment.
   * This has been slightly changed to not let users enter out-of-bounds offsets for UX clarity.
   */
  @Output() readonly segOffsetUpdated = new EventEmitter<{
    segment: SegOffsetOriented;
    lngLat: LngLatCoord;
  }>();
  @Output() readonly geomUpdated = new EventEmitter<ObjectWorldGeometry>();

  /** Segment form control */
  readonly segmentControl = newFormControl();

  readonly trackNameControl = newFormControl();
  /**
   * Offset form control.
   * Deliberately accepts out of bounds inputs, so the user can easily say "move the association forward 20 meters"
   * without intermediate points/connections getting in their way.
   */
  readonly offsetControl = newNumericFormControl(2, this.updateStrategy);

  /** X offset form control */
  readonly xFC = newNumericFormControl(undefined, this.updateStrategy);
  /** Y offset form control */
  readonly yFC = newNumericFormControl(undefined, this.updateStrategy);
  /** Z offset form control */
  readonly zFC = newNumericFormControl(undefined, this.updateStrategy);
  /** Heading form control */
  readonly hFC = newNumericFormControl(undefined, this.updateStrategy);
  /** Pitch form control */
  readonly pFC = newNumericFormControl(undefined, this.updateStrategy);
  /** Roll form control */
  readonly rFC = newNumericFormControl(undefined, this.updateStrategy);

  userScaleControls: UserScaleUi[] = [];
  private userScaleSubs: Subscription;
  private formControlSubs = new Subscription();

  constructor(
    @Optional() @Inject(OBJECT_DETAILS_TRACK_USER_SCALE_UPDATE_TOKEN) private readonly updateUserScales: boolean,
    protected readonly snackbar: SnackBarWrapper,
    protected translateService: TranslateService,
    private logger: Logging
  ) {
    this.formControlSubs.add(this.segmentControl.valueChanges.subscribe(v => this.updateSegOffset()));
    this.formControlSubs.add(this.offsetControl.valueChanges.pipe().subscribe(v => this.updateSegOffset()));

    // We also add a debounce time so that they can enter value.
    // Example: Range is 2 to 20, they enter 17, it starts with 1 so it snaps to 2. User unhappy!
    this.formControlSubs.add(
      this.xFC.valueChanges
        .pipe(
          startWith(undefined),
          pairwise(),
          filter(([o, n]) => n !== undefined)
        )
        .subscribe(([vOld, vNew]) => this.updateXY(vNew, this.yFC.value, vOld, this.yFC.value))
    );
    this.formControlSubs.add(
      this.yFC.valueChanges
        .pipe(
          startWith(undefined),
          pairwise(),
          filter(([o, n]) => n !== undefined)
        )
        .subscribe(([vOld, vNew]) => this.updateXY(this.xFC.value, vNew, this.xFC.value, vOld))
    );
    this.formControlSubs.add(
      this.zFC.valueChanges
        .pipe(
          startWith(undefined),
          pairwise(),
          filter(([o, n]) => n !== undefined)
        )
        .subscribe(([vOld, vNew]) => this.updateZ(vNew, vOld))
    );

    // Note that objects are naturally oriented so that they face oncoming trains,
    // which we need to reverse for the purposes of describing headings to users.
    // Also note that normal rotation direction is "backwards" for non-mathsy folks.
    this.formControlSubs.add(
      this.hFC.valueChanges.pipe().subscribe(v =>
        this.geomUpdated.emit({ ...this.object.location.geometry, h: -v + 180 + (this.trackAssociation?.heading?.degrees ?? 0) })
      )
    );
    this.formControlSubs.add(this.pFC.valueChanges.pipe(
    ).subscribe(v => this.geomUpdated.emit({ ...this.object.location.geometry, p: +v })));
    this.formControlSubs.add(this.rFC.valueChanges.pipe(
    ).subscribe(v => this.geomUpdated.emit({ ...this.object.location.geometry, r: +v })));
  }

  private updateSegOffset(): void {
    // Ensure we're not accidentally processing a string (which sometimes comes out of autocompletes).
    const selectedSegId = Number(this.segmentControl.value);

    if (!Number.isNaN(selectedSegId)) {
      const selectedOffset = parseFloat(this.offsetControl.value) ?? 0;
      // No orientationControl right now.
      const selectedOrientation = this.trackAssociation.orientation;

      this.emitSegOffset(selectedSegId, selectedOffset, selectedOrientation);
    }
  }

  private emitSegOffset(selectedSegId: number, selectedOffset: number, selectedOrientation: Orientation): void {
    if (
      selectedSegId !== this.trackAssociation.segmentId ||
      selectedOffset !== this.trackAssociation.offset ||
      selectedOrientation !== this.trackAssociation.orientation
    ) {
      const assoc: TrackSegmentAssociation = { offset: selectedOffset, orientation: selectedOrientation, segmentId: selectedSegId };
      const assocPos = getTrackAssocPosition(this.netDef, assoc);
      const assocHeading = getTrackAssocHeading(this.netDef, assoc);
      const assocAtoB = assoc.orientation === Orientation.ALPHA_TO_BETA;
      const withXOffset = findPerpedicularPoint2D(assocPos, assocHeading, this.xFC.value, assocAtoB);
      const result = findPerpedicularPoint2D(withXOffset, this.add90Degrees(assocHeading), this.yFC.value, assocAtoB);
      const latLong = this.netDef.xyTolngLatIndividual(result.x , result.y);

      this.segOffsetUpdated.emit({
        segment: {
          segmentId: selectedSegId,
          offset: selectedOffset,
          orientation: selectedOrientation
        },
        lngLat: [latLong.longitude, latLong.latitude]
      });
    }
  }

  private updateXY(x: number, y: number, oldX?: number, oldY?: number): void {
    // TODO: This really deserves some unit tests.
    const xRange = this.object?.objectType?.placementRules?.distanceFromTrackCentreline?.x;
    const yRange = this.object?.objectType?.placementRules?.distanceFromTrackCentreline?.y;
    if (xRange.min !== xRange.max && xRange.min !== 0 && (Math.abs(x) < xRange.min || Math.abs(x) > xRange.max)) {
      let newX = Math.min(Math.max(Math.abs(x), xRange.min), xRange.max);
      // This is to keep the same sign
      if (x < 0) newX = -newX;
      // If you enter -1 and the range is 2 to 20, it should snap to -2. Unless, the previous value was -2, then it goes to 2.
      // If you enter 1 and the range is 2 to 20, it should snap to 2. Unless, the previous value was 2, then it goes to -2.
      // The reason being that otherwise, you can't pass the gap using the arrow!
      // The last check with oldX*x > 0 is to make sure they are of the same sign. If you are at -2, and enter 1, it should go to 2. And not invert twice to -2.
      if (oldX && Math.abs(oldX) === xRange.min && Math.abs(x) < xRange.min && oldX * x > 0) {
        newX = -newX;
      }
      this.xFC.patchValue(newX);
      // Since we're patching it, it is going to get called again anyway
      return;
    }
    if (yRange.min !== yRange.max && yRange.min !== 0 && (Math.abs(y) < yRange.min || Math.abs(y) > yRange.max)) {
      let newY = Math.min(Math.max(Math.abs(y), yRange.min), yRange.max);
      // This is to keep the same sign
      if (y < 0) newY = -newY;
      // If you enter -1 and the range is 2 to 20, it should snap to -2. Unless, the previous value was -2, then it goes to 2.
      // If you enter 1 and the range is 2 to 20, it should snap to 2. Unless, the previous value was 2, then it goes to -2.
      // The reason being that otherwise, you can't pass the gap using the arrow!
      // The last check with oldY*y > 0 is to make sure they are of the same sign. If you are at -2, and enter 1, it should go to 2. And not invert twice to -2.
      if (oldY && Math.abs(oldY) === yRange.min && Math.abs(y) < yRange.min && oldY * y > 0) {
        newY = -newY;
      }
      this.yFC.patchValue(newY);
      // Since we're patching it, it is going to get called again anyway
      return;
    }
    const withXOffset = findPerpedicularPoint2D(this.assocPos, this.assocHeading, x, this.assocAtoB);
    const result = findPerpedicularPoint2D(withXOffset, this.add90Degrees(this.assocHeading), y, this.assocAtoB);
    this.geomUpdated.emit({
      ...this.object.location.geometry,
      ...result
    });
  }

  updateZ(z: number, oldZ?: number): void {
    let newZ = +z; // form controls may output stringified numbers
    const zRange = this.object?.objectType?.placementRules?.distanceFromTrackCentreline?.z;
    if (zRange.min !== zRange.max && (Math.abs(z) < zRange.min || Math.abs(z) > zRange.max)) {
      newZ = Math.min(Math.max(Math.abs(z), zRange.min), zRange.max);
      // This is to keep the same sign
      if (z < 0) newZ = -newZ;
      // If you enter -1 and the range is 2 to 20, it should snap to -2. Unless, the previous value was -2, then it goes to 2.
      // If you enter 1 and the range is 2 to 20, it should snap to 2. Unless, the previous value was 2, then it goes to -2.
      // The reason being that otherwise, you can't pass the gap using the arrow!
      // The last check with oldZ*z > 0 is to make sure they are of the same sign. If you are at -2, and enter 1, it should go to 2. And not invert twice to -2.
      if (oldZ && Math.abs(oldZ) === zRange.min && Math.abs(z) < zRange.min && oldZ * z > 0) {
        newZ = -newZ;
      }
      this.zFC.patchValue(newZ);
      // Since we're patching it, it is going to get called again anyway
      return;
    }
    this.geomUpdated.emit({
      ...this.object.location.geometry,
      z: newZ
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    const objectChanged = changes.object && changes.object.currentValue !== changes.object.previousValue;
    const netDefChanged = changes.netDef && changes.netDef.currentValue !== changes.netDef.previousValue;
    const trackAssociationChanged = changes.trackAssociation && changes.trackAssociation.currentValue !== changes.trackAssociation.previousValue;

    if ((objectChanged || netDefChanged || trackAssociationChanged) && this.object && this.netDef && this.trackAssociation) {
      this.segmentControl.setValue(this.trackAssociation.segmentId, quietUpdateOptions);
      this.offsetControl.setValue(this.trackAssociation.offset, quietUpdateOptions);

      this.assocPos = getTrackAssocPosition(this.netDef, this.trackAssociation);
      // comes back null if heading is none (both), in which case hide geometry
      // FIXME this will render 1 geometry per association but as disabled, which is wrong
      this.assocHeading = getTrackAssocHeading(this.netDef, this.trackAssociation);
      this.assocAtoB = this.trackAssociation.orientation === Orientation.ALPHA_TO_BETA;

      const geometry: ObjectWorldGeometry = this.object.location?.geometry;
      if (geometry) {
        this.updateGeometryControls(toObjectGeometry(geometry));
      }

      this.updateTrackNameControls();
      this.updateUserScaleControls();
    }
    this.updateTrackLocationFields(this.userConfig); // FIXME get user config
  }

  ngOnDestroy(): void {
    this.userScaleSubs?.unsubscribe();
    this.formControlSubs?.unsubscribe();
  }

  private updateGeometryControls(geometry: ObjectGeometry): void {
    if (!this.assocHeading) {
      this.resetGeometryControls();
      this.disableGeometryControls();
      return;
    }
    this.enableGeometryControls();
    // track objects don't have x or y offsets.
    const ranges = this.object?.objectType?.placementRules?.distanceFromTrackCentreline;
    if (ranges?.x?.isExact() && ranges?.x?.includes(0)) {
      this.xFC.setValue(0, quietUpdateOptions);
      this.xFC.disable(quietUpdateOptions);
      // if (!ranges.y) {
      //   this.yFC.setValue(0, quietUpdateOptions);
      //   this.yFC.disable();
      // }
    } else {
      const xDist = findDistanceFromLine2D(geometry, this.assocPos, this.assocHeading, this.assocAtoB);
      // const yDist = this.findDistanceFromLine2D(geometry, this.assocPos, this.add90Degrees(this.assocHeading), this.assocAtoB);
      // TODO unit conversions
      this.xFC.setValue(xDist, quietUpdateOptions);
      // this.yFC.setValue(yDist, quietUpdateOptions);
    }
    if (ranges?.y?.isExact() && ranges?.y?.includes(0)) {
      this.yFC.setValue(0, quietUpdateOptions);
      this.yFC.disable(quietUpdateOptions);
    } else {
      const yDist = findDistanceFromLine2D(geometry, this.assocPos, this.add90Degrees(this.assocHeading), this.assocAtoB);
      this.yFC.setValue(yDist, quietUpdateOptions);
    }
    if (ranges?.z?.isExact() && ranges?.z?.includes(0)) {
      this.zFC.setValue(0, quietUpdateOptions);
      this.zFC.disable(quietUpdateOptions);
    } else {
      this.zFC.setValue(geometry.z, quietUpdateOptions);
    }

    // Note that objects are naturally oriented so that they face oncoming trains,
    // which we need to reverse for the purposes of describing headings to users.
    // Also note that normal rotation direction is "backwards" for non-mathsy folks.
    this.hFC.setValue(-normaliseDegrees(geometry.h + 180 - this.assocHeading.degrees), quietUpdateOptions);
    this.pFC.setValue(normaliseDegrees(geometry.p), quietUpdateOptions);
    this.rFC.setValue(normaliseDegrees(geometry.r), quietUpdateOptions);
  }

  private resetGeometryControls(): void {
    this.xFC.setValue(0, quietUpdateOptions);
    this.yFC.setValue(0, quietUpdateOptions);
    this.zFC.setValue(0, quietUpdateOptions);
    this.hFC.setValue(0, quietUpdateOptions);
    this.pFC.setValue(0, quietUpdateOptions);
    this.rFC.setValue(0, quietUpdateOptions);
  }

  private disableGeometryControls(): void {
    this.xFC.disable(quietUpdateOptions);
    this.yFC.disable(quietUpdateOptions);
    this.zFC.disable(quietUpdateOptions);
    this.hFC.disable(quietUpdateOptions);
    this.pFC.disable(quietUpdateOptions);
    this.rFC.disable(quietUpdateOptions);
  }

  private enableGeometryControls(): void {
    this.xFC.enable(quietUpdateOptions);
    this.yFC.enable(quietUpdateOptions);
    this.zFC.enable(quietUpdateOptions);
    this.hFC.enable(quietUpdateOptions);
    this.pFC.enable(quietUpdateOptions);
    this.rFC.enable(quietUpdateOptions);
  }

  private add90Degrees(a: Angle): Angle {
    return Angle.ofDegrees(a.degrees + 90);
  }

  private updateTrackNameControls(): void {
    const trackName = getTrackAssocTrackName(this.netDef, this.trackAssociation);
    this.trackNameControl.setValue(trackName);
  }

  private updateUserScaleControls(): void {
    this.userScaleControls = createUIsForNewValues(getTrackAssocUserScales(this.netDef, this.trackAssociation, this.updateUserScales), this.userScaleControls, {
      offset: true
    });

    this.userScaleSubs?.unsubscribe();
    this.userScaleSubs = new Subscription();
    this.userScaleControls.forEach(ui => this.userScaleSubs.add(ui.offsetFC.valueChanges.subscribe(v => this.userScaleUpdated(ui.userScale, Number(v)))));
  }

  private userScaleUpdated(original: UserScale, newOffset: number): void {
    const path = this.pathFinder.scanPath(this.trackAssociation);
    const pathSegIds = path.pathSegments.map(s => s.segment.id);

    processUserScaleUpdate(
      pathSegIds,
      original,
      newOffset,
      this.netDef,
      (segOffset: SegOffset) => {
        let orientation = this.trackAssociation.orientation;
        const segIndex = path.indexOf(segOffset.segmentId);

        if (segIndex >= 0) {
          const newSegDirection = path.pathSegments[segIndex].direction;
          orientation = this.trackAssociation.orientation === Orientation.ALPHA_TO_BETA ? newSegDirection : reverse(newSegDirection);
        }
        this.emitSegOffset(segOffset.segmentId, segOffset.offset, orientation);
      },
      () => {
        // FIXME this only happens when user scale is out of range, which we should be able to handle through better data and form validation
        this.emitSegOffset(this.trackAssociation.segmentId, this.trackAssociation.offset, this.trackAssociation.orientation);
        this.snackbar.open(
          this.translateService.instant(
            t('PK value rejected: it either matches multiple locations on the track or does not match any location.')
          ),
          this.translateService.instant(t('Dismiss'))
        );
        this.logger.error('PK value rejected: it either matches multiple locations on the track or does not match any location.');
      },
      getTrackAssocTrackName(this.netDef, this.trackAssociation)
    );
  }

  private updateTrackLocationFields(userConfig: UserConfig): void {
    // If there's no track name, we should not be displaying it. PRDOKS-1345
    const showTrackName = this.trackNameControl.value && !!userConfig?.positionFormat.find(pf => pf === 'trackName');
    const showUserScale = !!userConfig?.positionFormat.find(pf => pf === 'userScale');
    const showSegOffset = !!userConfig?.positionFormat.find(pf => pf === 'segment');
    const show3D = !!userConfig?.positionFormat.find(pf => pf === '3d');
    const config: TrackLocationConfig = {
      trackName: {
        trackNameControl: this.trackNameControl,
        show: showTrackName,
        editable: false
      },
      userScales: {
        show: showUserScale,
        userScaleControls: this.userScaleControls
      },
      segmentOffset: {
        show: showSegOffset,
        segmentControl: this.segmentControl,
        offsetControl: this.offsetControl,
        offsetEditable: true,
        segmentEditable: false
      },
      position3DOffset: {
        show: show3D,
        editable: true,
        xFC: this.xFC,
        yFC: this.yFC,
        zFC: this.zFC,
        hFC: this.hFC,
        pFC: this.pFC,
        rFC: this.rFC,
        xOffsetLimit: this.object?.objectType?.placementRules?.distanceFromTrackCentreline?.x
      }
    };
    this.trackLocationConfig = config;
  }
}
