/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Inject, Input, OnDestroy, OnInit, Optional, Output, signal } from '@angular/core';
import { FormControl, UntypedFormControl } from '@angular/forms';
import { SafeUrl } from '@angular/platform-browser';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { isEmpty, isEqual, isNil, merge } from 'lodash';
import { BehaviorSubject, combineLatest, Observable, of, Subscription } from 'rxjs';
import { debounceTime, switchMap } from 'rxjs/operators';

import { filterTruthy, SelfCompletingObservable, takeOneTruthy } from '@oksygen-common-libraries/common';
import { illegalNameCharacterExists, UpdateOn, validateUniqueString } from '@oksygen-common-libraries/material/components';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LngLatCoord, Orientation, SegOffsetOriented } from '@oksygen-sim-core-libraries/data-types/common';
import { TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import {
  defaultImages,
  GlobalImageStoreKey,
  ImageService,
  IReachablePathFinder,
  WorldData
} from '@oksygen-sim-train-libraries/components-services/common';
import {
  isObjectDataMapContext,
  isObjectTrackAtlasManager,
  OBJECT_MAP_RENDERER_TOKEN,
  ObjectDataMapContext,
  ObjectMapRenderer,
  ZoomLevel
} from '@oksygen-sim-train-libraries/components-services/maps';
import {
  ACTIONS_DISABLED,
  DetailedFeatureTypeState,
  getDisplayObject,
  getObjectRenderInfo,
  isObjectContainerPropertiesValid,
  ObjectContainer,
  ObjectEditManager,
  ObjectLabel,
  ObjectPropertiesConfig,
  ObjectPropertyChange,
  ObjectsDetailsConfig,
  ObjectStateChange,
  ObjectWorldGeometry,
  SimObject,
  POINT_OBJECT_TYPE_NAME
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { BaseRule } from '@oksygen-sim-train-libraries/components-services/rules';
import { UserConfig, UserConfigService } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

export interface IScenarioEditManager {
  updateObjectName: (id: number, name: string) => void;
  updateObjectPosition: (object: ObjectContainer, pos: LngLatCoord, assocs?: TrackSegmentAssociation[]) => void;
  updateObjectGeometry: (object: ObjectContainer, geom: ObjectWorldGeometry) => void;
}

@Component({
  selector: 'oksygen-objects-details',
  templateUrl: './objects-details.component.html',
  styleUrls: ['./objects-details.component.scss']
})
export class ObjectsDetailsComponent implements OnInit, OnDestroy {
  private nameError = false;
  @Input() context$!: Observable<ObjectDataMapContext>;
  @Input() objectSelected$!: Observable<ObjectContainer>;
  @Input() settings: ObjectsDetailsConfig = ACTIONS_DISABLED;
  @Input() showProperties: boolean;
  @Input() objectEditManager: ObjectEditManager;
  @Input() objectPropertiesConfig: ObjectPropertiesConfig = {};

  @Output() readonly favouriteClick: EventEmitter<ObjectContainer> = new EventEmitter();
  @Output() readonly deleteClick: EventEmitter<ObjectContainer> = new EventEmitter();
  @Output() readonly stateChange: EventEmitter<ObjectStateChange> = new EventEmitter();
  @Output() readonly propertyChange: EventEmitter<ObjectPropertyChange> = new EventEmitter();
  @Output() readonly autoChange: EventEmitter<boolean> = new EventEmitter();
  @Output() readonly ruleClick: EventEmitter<number> = new EventEmitter();

  selectedObject: ObjectContainer;
  /**
   * {@link selectedObject}'s track associations.
   * We maintain a separate list to avoid destroying/recreating the position components,
   * as that will cause glitches in the UI when e.g. incrementing offsets.
   */
  trackAssociations: TrackSegmentAssociation[];
  /** the selected object or promoted child, if it is a container object */
  private displayObject: SimObject;

  nameControl: UntypedFormControl;
  readonly duplicateName = 'duplicateName';
  showVirtualToggle: boolean;
  virtualToggleValue: boolean;
  object: SimObject;

  selectedState: DetailedFeatureTypeState;

  private readonly subscriptions = new Subscription();
  imageUri = signal<SafeUrl | string>('');
  isValid: boolean;
  states: Map<number, DetailedFeatureTypeState>;
  objectChildren: BehaviorSubject<SimObject>[] = [];
  userConfig$: Observable<UserConfig>;
  world: WorldData;
  netDef: NetworkDefinitionManager;
  pathFinder: IReachablePathFinder;
  ruleLinks: BaseRule[];
  imageLabel = signal<ObjectLabel>(null);

  private otherObjectNames: Array<string> = [];
  private readonly formDebounceTime = 750;
  pointType: any;
  readonly POINT_OBJECT_TYPE_NAME = POINT_OBJECT_TYPE_NAME;
  readonly ZONE_LAYER_NAME = 'Zone';

  constructor(
    private readonly imageService: ImageService,
    private readonly logger: Logging,
    private registry: Registry,
    private userConfigService: UserConfigService,
    @Inject(OBJECT_MAP_RENDERER_TOKEN) @Optional() protected overrideObjectRenderer?: ObjectMapRenderer
  ) {
  }

  ngOnInit(): void {
      // Initialize the name control with custom validation
      this.nameControl = new FormControl(UpdateOn.BLUR, c => {
        let result = validateUniqueString(c.value, this.otherObjectNames, this.selectedObject?.name);
        if (!isNil(c.value)) {
          if (c.value.trim() !== c.value) {
            result = merge(result || {}, { ['spaces']: true });
          }
          if (illegalNameCharacterExists(c.value)) {
            result = merge(result || {}, { ['specialCharacter']: true });
          }
        }
        this.nameError = result != null;
        return result;
      });
      this.userConfig$ = this.userConfigService.config$();

    this.subscriptions.add(
      combineLatest([
        this.objectSelected$,
        this.context$.pipe(
          filterTruthy(),
          switchMap(m => m.objects.data()),
          filterTruthy()
        )
      ]).subscribe(([object, allObjects]) => {
        if (object?.children) {
          if (this.objectChildren.length !== object.children.length) {
            if (object.children.length < this.objectChildren.length) {
              const change = this.objectChildren.length - object.children.length;

              for (let i = 0; i < change; i++) {
                const subject = this.objectChildren.pop();
                subject.complete();
              }
            } else if (object.children.length > this.objectChildren.length) {
              const change = object.children.length - this.objectChildren.length;

              for (let i = 0; i < change; i++) {
                this.objectChildren.push(new BehaviorSubject<SimObject>(null));
              }
            }
          }

          for (let i = 0; i < object.children.length; i++) {
            this.objectChildren[i].next(object.children[i]);
          }
        }

        this.otherObjectNames = allObjects.filter(obj => obj.id !== object?.id).map(obj => obj.name);
        this.showVirtualToggle = object?.properties?.Virtual !== undefined ? true : object?.stateVirtual !== undefined;
        if (this.showVirtualToggle) {
          this.virtualToggleValue = (object.properties as any).Virtual;
        }
        this.onSelectedObjectChange(object);
        this.updateObjectFields();
        this.isValid = isObjectContainerPropertiesValid(object);
      })
    );
    this.subscriptions.add(
      this.nameControl.valueChanges.pipe(debounceTime(this.formDebounceTime)).subscribe(s => {
        if (s !== this.selectedObject.name && !this.otherObjectNames.includes(s) && !this.nameControl.errors) {
          this.objectEditManager?.updateObjectName(this.selectedObject.id, s);
        }
      })
    );
    this.subscriptions.add(
      this.context$
        .pipe(
          filterTruthy(),
          switchMap(m => combineLatest([m.world.world$, m.world.netDef$]))
        )
        .subscribe(([w, nd]) => {
          this.world = w;
          this.netDef = nd;
        })
    );
    this.subscriptions.add(
      this.context$
        .pipe(
          filterTruthy(),
          switchMap(context => (isObjectDataMapContext(context) ? context.pathFinder$ : of(null)))
        )
        .subscribe(p => (this.pathFinder = p))
    );
    this.subscriptions.add(
      this.context$
        .pipe(
          filterTruthy(),
          switchMap(context => (isObjectDataMapContext(context) && !isNil(context.getLinkedRules$) ? context.getLinkedRules$(this.objectSelected$) : of([])))
        )
        .subscribe(ruleLinks => {
          this.ruleLinks = ruleLinks;
        })
    );
  }

  updateObjectFields(): void {
    this.nameControl.setValue(this.selectedObject.name, { emitEvent: false });
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();

    this.objectChildren.forEach(subject => subject.complete());
  }

  onSelectedObjectChange(object: ObjectContainer): void {
    if (!object) { return; }

    this.trackAssociations = object.trackAssociations;
    this.selectedObject = object;

    // set to be the object
    const displayObject = getDisplayObject(object);

    if (!isEqual(displayObject, this.displayObject)) {
      this.initImage(displayObject).subscribe(uri => (this.imageUri.set(uri)));

      this.displayObject = displayObject;
    }

    if(this.selectedObject?.objectType?.name === POINT_OBJECT_TYPE_NAME){
      this.pointType = this.selectedObject?.properties?.Type;
    }
  }

  identifyTrackAssoc(index: number, assoc: TrackSegmentAssociation): number | string {
    return index;
  }

  /**
   * Rather than just using the object, we try and load as the object against it will be the small verison.
   */
  private initImage(object: SimObject): SelfCompletingObservable<SafeUrl | string> {
    this.imageLabel.set(null);

    if (object?.objectType?.mapOverrides) {
      const overrides = getObjectRenderInfo(object, object.objectType?.defaultIcons?.big.id);
      if (overrides.label) {
        this.imageLabel.set(overrides.label);
      }
      const image = this.imageService.getGlobalImage(GlobalImageStoreKey.SMALL, `${overrides.icon}`);
      return this.imageService.loadIconImageObservable(image, defaultImages.object);
    }

    if (this.overrideObjectRenderer && object?.objectType?.mapRenderer) {
      const renderer = this.overrideObjectRenderer.renderers.get(object.objectType.mapRenderer);

      if (renderer) {
        const overrides = renderer(object as any);

        if (overrides.label) {
          this.imageLabel.set({text: overrides.label, colour: '#000000', yOffset: 0});
        }

        if (overrides.icon) {
          const image = this.imageService.getGlobalImage(GlobalImageStoreKey.SMALL, `${overrides.icon}`);
          return this.imageService.loadIconImageObservable(image, defaultImages.object);
        }
      }
    }

    const img = object.selectedIcon?.big ?? object.objectType?.defaultIcons?.big;

    if(!this.imageService.hasGlobalImage(GlobalImageStoreKey.BIG, `${img.id}`)) {
      this.imageService.addGlobalImage(GlobalImageStoreKey.BIG, `${img.id}`, img);
    }
    const image = this.imageService.getGlobalImage(GlobalImageStoreKey.BIG, `${img.id}`);
    return this.imageService.loadIconImageObservable(image, defaultImages.object);
  }

  initDefaultState(object: ObjectContainer): void {
    const state = object.objectType.defaultState;
    object.selectedState = state;
  }

  favourite(event?: Event): void {
    event?.stopPropagation();
    this.favouriteClick.emit(this.selectedObject);
  }

  locate(): void {
    this.context$
      .pipe(takeOneTruthy<ObjectDataMapContext>(undefined, 200))
      .subscribe(
        m => {
          const toggles = m.map.mapTogglesSubject.getValue();
          if (toggles.follow === true) {
            const updateToggles = { ...toggles };
            updateToggles.follow = false;
            m.map.mapTogglesSubject.next(updateToggles);
          }
          const usePromotedChild = this.registry.getBoolean(['maps', 'config', 'objects', 'usePromotedChildPosition'], false);
          const objectPositionSupplier = usePromotedChild ? this.displayObject : this.selectedObject;
          let lngLat = objectPositionSupplier.location.lnglat;

          if (isEmpty(lngLat) && objectPositionSupplier.location.geometry?.x !== null && objectPositionSupplier.location.geometry?.y !== null) {
            const result = this.netDef.xyTolngLatIndividual(objectPositionSupplier.location.geometry.x, objectPositionSupplier.location.geometry.y);
            lngLat = [result.latitude, result.longitude];
          }

          if (!isEmpty(lngLat)) {
            m.map.mapGoto([lngLat[0], lngLat[1]], ZoomLevel.STATION);
          }
        },
        err => this.logger.warn(`Cannot locate blank object: ${this.selectedObject?.id}`)
      );
  }



  delete(event?: Event): void {
    event?.stopPropagation();
    this.deleteClick.emit(this.selectedObject);
  }

  changeVirtual(isAuto: MatSlideToggleChange): void {
    //this.stateChange.emit({ objectId: this.selectedObject.id, state: this.selectedState, autoToggled: undefined,virtualToggled: isAuto.checked });
    this.propertyChange.emit({ objectId: this.selectedObject.id, propertyName: 'Virtual', propertyValue: isAuto.checked });
  }

  toggleVisibility(visibility: string): void {
    this.logger.log(this.selectedObject.name + ' visibility set to: ' + visibility);
  }

  selectState(state: ObjectStateChange): void {
    this.stateChange.emit(state);
  }

  selectProperty(property: ObjectPropertyChange): void {
    this.propertyChange.emit(property);
  }

  hoverIcon(): void {
    this.context$
      .pipe(
        // FIXME magic number
        takeOneTruthy<ObjectDataMapContext>(undefined, 100)
      )
      .subscribe(
        m => {
          if (isObjectTrackAtlasManager(m.map)) {
            m.map.spotlightObject(this.selectedObject.id);
          }
        },
        err => this.logger.warn(`Failed to hover feature ${this.selectedObject?.id}`)
      );
  }

  dehoverIcon(): void {
    this.context$
      .pipe(
        // FIXME magic number
        takeOneTruthy<ObjectDataMapContext>(undefined, 100)
      )
      .subscribe(
        m => {
          if (isObjectTrackAtlasManager(m.map)) {
            m.map.removeSpotlightObject(this.selectedObject.id);
          }
        },
        err => this.logger.warn(`Failed to hover feature ${this.selectedObject?.id}`)
      );
  }

  ruleLinkClick(): void {
    if (this.ruleLinks?.length > 1) {
    } else if (this.ruleLinks?.length === 1) {
      this.ruleLinkNavigate(this.ruleLinks[0]);
    }
  }

  ruleLinkNavigate(rule: BaseRule): void {
    this.ruleClick.emit(rule.id);
  }

  updateObjectAssocPosition(index: number, segOffSet: {
    segment: SegOffsetOriented;
    lngLat: LngLatCoord;
  }): void {
    this.objectEditManager?.updateObjectPosition(
      this.selectedObject,
      segOffSet.lngLat,
      this.trackAssociations.map((a, i) => (i === index ? segOffSet.segment : a))
    );
  }

  reverseOrientation(orientation: Orientation): Orientation {
    switch (orientation) {
      case (orientation = Orientation.ALPHA_TO_BETA):
        return Orientation.BETA_TO_ALPHA;
      case Orientation.BETA_TO_ALPHA:
        return Orientation.NONE;
      case Orientation.NONE:
        return Orientation.ALPHA_TO_BETA;
    }
  }

  updateObjectOrientation(selectedObj: ObjectContainer): void {
    let so: SegOffsetOriented;
    let index = 0;

    selectedObj.trackAssociations.forEach(track => {
      so = { segmentId: track.segmentId, offset: track.offset, orientation: this.reverseOrientation(track.orientation) };
      index = index + 1;
    });

    this.objectEditManager.updateObjectPosition(
      this.selectedObject,
      this.selectedObject.location.lnglat,
      this.trackAssociations.map((a, i) => (i === 0 ? so : a))
    );
  }

  updateObjectGeometry(geom: ObjectWorldGeometry): void {
    this.objectEditManager.updateObjectGeometry(this.selectedObject, geom);
  }
}
