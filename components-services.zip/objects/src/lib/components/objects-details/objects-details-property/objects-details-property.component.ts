/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { AbstractControl, UntypedFormControl, ValidationErrors, Validators } from '@angular/forms';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { forOwn, isNil, merge, sortBy } from 'lodash';
import { Subscription } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

import {
  getObjectTypePropertyConfig,
  ObjectPropertiesConfig,
  ObjectPropertyChange,
  ObjectTypeEnumPropertyValue,
  ObjectTypeProperty,
  SimObject
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { simpleChangesCheck, illegalNameCharacterExists } from '@oksygen-common-libraries/material/components';

interface OtProperty extends ObjectTypeProperty<string | number | boolean> {
  type: 'text' | 'number' | 'boolean' | 'enum';
  value: string | number | boolean | ObjectTypeEnumPropertyValue<string | number>;
  values?: ObjectTypeEnumPropertyValue<string | number>[];
  units?: string;
  control: UntypedFormControl; // note booleans don't use a control
  subscription: Subscription;
  placeholder?: string;
}

const ignoredProperties = ['State', 'Initial State', 'User State', 'Automatic State'];

@Component({
  selector: 'oksygen-objects-details-property',
  templateUrl: './objects-details-property.component.html',
  styleUrls: ['./objects-details-property.component.scss']
})
export class ObjectsDetailsPropertyComponent implements OnChanges, OnDestroy {
  @Input() object!: SimObject;
  @Input() isChild = false;
  /** whether we should be able to edit all properties, no properties or only the properties that are not set to computed. */
  @Input() editable: 'all' | 'none' | 'not-computed';
  @Input() objectPropertiesConfig: ObjectPropertiesConfig = {};

  /**
   * A list of properties we never want to render.
   * By default, this is the "state helper" properties (Initial State, User State, Automatic State).
   */
  @Input() ignoreProperties: string[] = ignoredProperties;
  @Output() readonly propertyChange: EventEmitter<ObjectPropertyChange> = new EventEmitter();

  properties: OtProperty[] = [];

  constructor(private translate: TranslateService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (simpleChangesCheck(changes.object)) {
      this.object = changes.object.currentValue;
      const objectChanged = changes.object.currentValue?.id !== changes.object.previousValue?.id;
      if (objectChanged) {
        this.cleanupPropertySubscriptions();
        this.properties = [];
        this.properties = sortBy(this.updateProperties(), 'type');
      }
    }
  }

  ngOnDestroy(): void {
    this.cleanupPropertySubscriptions();
  }

  cleanupPropertySubscriptions(): void {
    this.properties?.forEach(p => p.subscription?.unsubscribe());
  }

  onBooleanUpdate(propertyName: string, value: boolean): void {
    this.propertyChange.emit({ objectId: this.object.id, propertyName, propertyValue: value });
  }

  updateProperties(): OtProperty[] {
    const properties: OtProperty[] = [];

    if (!this.object.properties) {
      return properties;
    }

    forOwn(this.object.properties, (value, key) => {
      if (this.ignoreProperties.find(p => p === key)) {
        return;
      }

      const existingProperty = this.properties.find(p => p.name === key);
      if (!existingProperty) {
        const asText = this.object.objectType.textProperties.get(key);
        const asNumber = this.object.objectType.numericProperties.get(key);
        const asBool = this.object.objectType.booleanProperties.get(key);
        const asEnum = this.object.objectType.enumProperties.get(key);

        const config = getObjectTypePropertyConfig(this.objectPropertiesConfig, this.object.objectType.name, key);
        const defaultConfig = getObjectTypePropertyConfig(this.objectPropertiesConfig, 'Default', 'Label');

        let maxCharacters: number | undefined = !isNil(config.maxCharacters)
          ? config.maxCharacters
          : !isNil(defaultConfig.maxCharacters)
          ? defaultConfig.maxCharacters
          : undefined;

        if (isNil(maxCharacters) && !isNil(asText) && typeof asText.maxLength === 'number') {
          maxCharacters = asText.maxLength;
        }

        const placeholder = !isNil(config.maxCharacters)
          ? config?.placeholder?.replace('{maxCharacters}', maxCharacters?.toString() ?? '')
          : !isNil(defaultConfig.maxCharacters)
          ? defaultConfig.placeholder?.replace('{maxCharacters}', maxCharacters?.toString() ?? '')
          : '';

        const control = new UntypedFormControl();
        const validators = [Validators.required];

        control.setValidators(validators);
        control.setValue(value, { onlySelf: true, emitEvent: false });
        control.markAsTouched();

        const subscription = control.valueChanges.pipe(debounceTime(500)).subscribe(change => {
          // don't emit the value if it's not valid
          if (control.valid) {
            const newValue = typeof change === 'object' ? change?.value : change;

            this.propertyChange.emit({ objectId: this.object.id, propertyName: key, propertyValue: newValue });
          }
        });

        // NOTE: property must be linked to a real property that exists on the object type.
        if (!isNil(asText) && asText?.displayed) {

          control.addValidators((c: AbstractControl): ValidationErrors => {
            let result = null;

            // Check if the value is a string and apply additional validation
            if (!isNil(c.value) && typeof c.value === 'string') {
              if (c.value.trim() !== c.value) {
                result = merge(result || {}, { ['spaces']: true });
              }

              if (illegalNameCharacterExists(c.value)) {
                result = merge(result || {}, { ['specialCharacter']: true });
              }
            }

            if (!isNil(maxCharacters) && c.value?.length > maxCharacters) {
              result = merge(result || {}, { maxLength: this.translate.instant(`Maximum of {num} characters`, { num: maxCharacters }) });
            }

            return result;
          });

          properties.push({ ...asText, value, type: 'text', control, subscription, placeholder });

          control.addValidators((c: AbstractControl): ValidationErrors => {
            if (!isNil(maxCharacters) && c.value?.length > maxCharacters) {
              return { maxLength: this.translate.instant(`Maximum of {num} characters`, { num: maxCharacters }) };
            }
            return null;
          });

          control.updateValueAndValidity();
        } else if (!isNil(asBool) && asBool?.displayed) {
          properties.push({
            ...asBool,
            value: !!value,
            type: 'boolean',
            control,
            subscription
          });
        } else if (!isNil(asNumber) && asNumber?.displayed) {
          properties.push({ ...asNumber, units: asNumber.units, value, type: 'number', control, subscription, placeholder });
          control.addValidators((c: AbstractControl): ValidationErrors => {
            if (typeof asNumber.min === 'number' && c.value < asNumber.min) {
              return { minErr: this.translate.instant(`Must be greater than {num}`, { num: asNumber.min }) };
            }
            if (typeof asNumber.max === 'number' && c.value > asNumber.max) {
              return { maxErr: this.translate.instant(`Must be less than {num}`, { num: asNumber.max }) };
            }
            return null;
          });

          control.updateValueAndValidity();
        } else if (asEnum && asEnum?.displayed) {
          const enumValue = asEnum.values.find(v => v?.value === value);
          control.setValue(enumValue, { onlySelf: true, emitEvent: false });

          if (this.editable === 'none' || (this.editable === 'not-computed' && asEnum.computed)) {
            control.disable();
          }
          properties.push({ ...asEnum, defaultValue: asEnum?.defaultValue?.value, value: enumValue, type: 'enum', control, subscription });
        }
      } else {
        existingProperty.control.setValue(value, { onlySelf: true, emitEvent: false });
      }
    });

    return properties;
  }
}
