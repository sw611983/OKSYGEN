/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, discardPeriodicTasks, fakeAsync, flush, waitForAsync } from '@angular/core/testing';

import { ObjectsDetailsPropertyComponent } from './objects-details-property.component';
import { configureSimTrainTestingModule, createTestObject } from '@oksygen-sim-train-libraries/components-services/testing';

// the usage of flush() and discardPeriodicTasks() is because we debounce(500) control value updates, so they're still pending when we close each test
// the above calls will clear the memory here. Could also use tick(500), but that would be brittle if we change the debounce time.

describe('ObjectsDetailsPropertyComponent', () => {
  let component: ObjectsDetailsPropertyComponent;
  let fixture: ComponentFixture<ObjectsDetailsPropertyComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [ObjectsDetailsPropertyComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectsDetailsPropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', fakeAsync(() => {
    expect(component).toBeTruthy();
    flush();
    discardPeriodicTasks();
  }));

  it('obj with no properties is processable', fakeAsync(() => {
    const obj = createTestObject();
    component.object = obj;
    fixture.detectChanges();
    const properties = component.updateProperties();
    flush();
    discardPeriodicTasks();
    expect(properties.length).toBe(0);
  }));

  it('obj with properties is processed', fakeAsync(() => {
    const obj = createTestObject();
    obj.properties = {
      testString: 'asd',
      testNumber: 456,
      testBoolean: true
    };
    obj.objectType.booleanProperties.set('testBoolean', {name: 'testBoolean', computed: false, defaultValue: true, displayed: true});
    obj.objectType.numericProperties.set('testNumber', {name: 'testNumber', computed: false, defaultValue: 123, displayed: true});
    obj.objectType.textProperties.set('testString', {name: 'testString', computed: false, defaultValue: 'asd', displayed: true});
    component.object = obj;
    fixture.detectChanges();
    const properties = component.updateProperties();
    flush();
    discardPeriodicTasks();
    expect(properties.length).toBe(3);
    expect(properties.find(p => p.name === 'testNumber')?.control?.value).toBe(456);
  }));

  it('invalid numbers are detected', fakeAsync(() => {
    const obj = createTestObject();
    obj.properties = {
      testMax: 9999,
      testValid: 5,
      testMin: -9999
    };
    obj.objectType.numericProperties.set('testMax', {name: 'testMax', computed: false, defaultValue: 123, displayed: true, max: 10});
    obj.objectType.numericProperties.set('testValid', {name: 'testValid', computed: false, defaultValue: 123, displayed: true, min: 0, max: 10});
    obj.objectType.numericProperties.set('testMin', {name: 'testMin', computed: false, defaultValue: 123, displayed: true, min: 0});
    component.object = obj;
    fixture.detectChanges();
    const properties = component.updateProperties();
    flush();
    discardPeriodicTasks();
    expect(properties.length).toBe(3);
    expect(properties.find(p => p.name === 'testMax')?.control?.valid).toBe(false);
    expect(properties.find(p => p.name === 'testValid')?.control?.valid).toBe(true);
    expect(properties.find(p => p.name === 'testMin')?.control?.valid).toBe(false);
  }));

  it('invalid strings are detected', fakeAsync(() => {
    const obj = createTestObject();
    obj.properties = {
      testMax: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
      testValid: 'asdf'
    };
    obj.objectType.textProperties.set('testMax', {name: 'testMax', computed: false, defaultValue: 'a', displayed: true, maxLength: 10});
    obj.objectType.textProperties.set('testValid', {name: 'testValid', computed: false, defaultValue: 'a', displayed: true, maxLength: 10});

    component.object = obj;
    fixture.detectChanges();
    const properties = component.updateProperties();

    flush();
    discardPeriodicTasks();
    expect(properties.length).toBe(2);
    expect(properties.find(p => p.name === 'testMax')?.control?.valid).toBe(false);
    expect(properties.find(p => p.name === 'testValid')?.control?.valid).toBe(true);
  }));

  it('ignored properties are ignored', fakeAsync(() => {
    const obj = createTestObject();
    obj.properties = {
      valid: 'aaa',
      ignored: 'asd'
    };
    component.ignoreProperties = ['ignored'];
    obj.objectType.textProperties.set('valid', {name: 'valid', computed: false, defaultValue: 'a', displayed: true, maxLength: 10});
    obj.objectType.textProperties.set('ignored', {name: 'ignored', computed: false, defaultValue: 'a', displayed: true, maxLength: 10});
    component.object = obj;
    fixture.detectChanges();
    const properties = component.updateProperties();
    flush();
    discardPeriodicTasks();
    expect(properties.length).toBe(1);
    expect(properties.find(p => p.name === 'valid')?.control?.value).toBe('aaa');
  }));

  it('only process inserts once', fakeAsync(() => {
    const obj = createTestObject();
    obj.properties = {
      testString: 'asd',
      testNumber: 456,
      testBoolean: true
    };
    obj.objectType.booleanProperties.set('testBoolean', {name: 'testBoolean', computed: false, defaultValue: true, displayed: true});
    obj.objectType.numericProperties.set('testNumber', {name: 'testNumber', computed: false, defaultValue: 123, displayed: true});
    obj.objectType.textProperties.set('testString', {name: 'testString', computed: false, defaultValue: 'asd', displayed: true});
    component.object = obj;
    fixture.detectChanges();
    component.properties = component.updateProperties();
    expect(component.properties.length).toBe(3);
    const properties2 = component.updateProperties();
    expect(properties2.length).toBe(0);
    flush();
    discardPeriodicTasks();
  }));

  it('updates are processed', fakeAsync(() => {
    const obj = createTestObject();
    obj.properties = {
      testString: 'asd',
      testNumber: 456,
      testBoolean: true
    };
    obj.objectType.booleanProperties.set('testBoolean', {name: 'testBoolean', computed: false, defaultValue: true, displayed: true});
    obj.objectType.numericProperties.set('testNumber', {name: 'testNumber', computed: false, defaultValue: 123, displayed: true});
    obj.objectType.textProperties.set('testString', {name: 'testString', computed: false, defaultValue: 'asd', displayed: true});
    obj.objectType.textProperties.set('extra', {name: 'extra', computed: false, defaultValue: 'asd', displayed: true});
    component.object = obj;
    fixture.detectChanges();
    component.properties = component.updateProperties();
    expect(component.properties.length).toBe(3);
    obj.properties.extra = 'asd';
    obj.properties.testString = 'updated value';
    const properties2 = component.updateProperties();
    expect(properties2.length).toBe(1);
    expect(properties2.find(p => p.name === 'extra').control.value).toBe('asd');
    expect(component.properties.find(p => p.name === 'testString').control.value).toBe('updated value');
    flush();
    discardPeriodicTasks();
  }));
});
