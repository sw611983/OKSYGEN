/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';

import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import {
  configureSimTrainTestingModule,
  createTestObject,
  SCENARIO_EDITOR_CONTEXT_PROVIDERS
} from '@oksygen-sim-train-libraries/components-services/testing';

import { OksygenSimTrainObjectsModule } from '../../objects.module';
import { ObjectsDetailsComponent } from './objects-details.component';

describe('ObjectsDetailsComponent', () => {
  let component: ObjectsDetailsComponent;
  let fixture: ComponentFixture<ObjectsDetailsComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainCommonModule, OksygenSimTrainObjectsModule],
      providers: SCENARIO_EDITOR_CONTEXT_PROVIDERS
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectsDetailsComponent);
    component = fixture.componentInstance;
    component.objectSelected$ = new BehaviorSubject(createTestObject());
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
