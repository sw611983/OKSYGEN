/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, Output } from '@angular/core';

import { DetailedFeatureTypeState } from '@oksygen-sim-train-libraries/components-services/objects/data';

@Component({
  selector: 'oksygen-objects-state-select',
  templateUrl: './objects-state-select.component.html',
  styleUrls: ['./objects-state-select.component.scss']
})
export class ObjectsStateSelectComponent {
  @Input() states: DetailedFeatureTypeState[] = [];

  @Input() set selectedState(selectedState: DetailedFeatureTypeState) {
    this._selectedState = selectedState;
    this.selectedStateName = this._selectedState?.name;
  }
  get selectedState(): DetailedFeatureTypeState {
    return this._selectedState;
  }

  @Input() disabled = false;

  @Output() readonly stateChange: EventEmitter<DetailedFeatureTypeState> = new EventEmitter();

  _selectedState: DetailedFeatureTypeState;
  selectedStateName: string;

  constructor() {}

  changeState(stateName: string): void {
    this.selectedStateName = stateName;
    this._selectedState = this.states.find(s => s.name === stateName);
    this.stateChange.emit(this._selectedState);
  }
}
