/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ObjectsStateSelectComponent } from './objects-state-select.component';

describe('ObjectsStateSelectComponent', () => {
  let component: ObjectsStateSelectComponent;
  let fixture: ComponentFixture<ObjectsStateSelectComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [ObjectsStateSelectComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectsStateSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
