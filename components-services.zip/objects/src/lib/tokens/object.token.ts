/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { InjectionToken } from '@angular/core';

export const OBJECT_DETAILS_TRACK_USER_SCALE_UPDATE_TOKEN = new InjectionToken<boolean>('Object Details Track User Scale Update');
