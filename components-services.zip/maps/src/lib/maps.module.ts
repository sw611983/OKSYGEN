/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenSimCoreUnitsModule } from '@oksygen-sim-core-libraries/components-services/measurement-units';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

import { LineViewComponent } from './components/line-view/line-view.component';
import { MiniMapComponent } from './components/mini-map/mini-map.component';
import { PlanViewComponent } from './components/plan-view/plan-view.component';
import { StationMenuComponent } from './components/toolbar/station-menu/station-menu.component';
import { MapIOService } from './services/map-io.service';
import { OBJECT_MAP_RENDERER_TOKEN, defaultObjectMapRendererToken } from './tokens/object-map-render.token';
import { registrySchemaProvider } from '@oksygen-common-libraries/pio/registry';
import { mapConfigSchema } from './models/map-config.model';

const components = [
  LineViewComponent, MiniMapComponent, PlanViewComponent, StationMenuComponent
];

@NgModule({
  declarations: components,
  imports: [ CommonModule, OksygenMaterialComponentsModule, OksygenSimTrainCommonModule, OksygenSimCoreUnitsModule ],
  exports: components,
  providers: [MapIOService, { provide: OBJECT_MAP_RENDERER_TOKEN, useValue: defaultObjectMapRendererToken }, registrySchemaProvider(mapConfigSchema)]
})
export class OksygenSimTrainMapsModule {}
