/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { createAction, props } from '@ngrx/store';
import { GeoJSON } from 'geojson';

import { SystemData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectFilter } from '@oksygen-sim-train-libraries/components-services/objects/data';

export enum MapDataActionEnum {
  INITIALISE_MAP_DATA = '[MapDataActionEnum] INITIALISE_MAP_DATA',
  TRACK_DATA = '[MapDataActionEnum] TRACK_DATA',
  TRACK_DATA_ERROR = '[MapDataActionEnum] TRACK_DATA_ERROR',
  ICON_FILTER = '[MapDataActionEnum] ICON_FILTER'
}


export interface TrackNameStoreProperties extends SystemData {
  trackName: string;
}

export interface TrackDataStoreProperties extends SystemData {
  trackData: GeoJSON;
}

export interface TrackDataErrorStoreProperties extends SystemData {
  trackDataError: any;
}

export interface IconFilterStoreProperties extends SystemData {
  iconFilter: ObjectFilter;
}

const initialiseMapDataAction = createAction(MapDataActionEnum.INITIALISE_MAP_DATA, props<TrackNameStoreProperties>());
const trackDataAction = createAction(MapDataActionEnum.TRACK_DATA, props<TrackDataStoreProperties>());
const trackDataErrorAction = createAction(MapDataActionEnum.TRACK_DATA_ERROR, props<TrackDataErrorStoreProperties>());
const iconFilterAction = createAction(MapDataActionEnum.ICON_FILTER, props<IconFilterStoreProperties>());

/**
 * Deprecated
 */
export const mapDataActions = {
  initialiseMapData: initialiseMapDataAction,
  setTrack: trackDataAction,
  setTrackError: trackDataErrorAction,
  setIconFilter: iconFilterAction
};
