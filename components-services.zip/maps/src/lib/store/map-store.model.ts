/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ObjectFilter } from '@oksygen-sim-train-libraries/components-services/objects/data';

/** @deprecated */
export interface MapStoreData {
  trackName: string;
  trackData: any;
  trackDataError: any;
  iconFilter: ObjectFilter;
}
