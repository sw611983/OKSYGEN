/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { MapIOManager } from '../services/map-io-manager';

export function MapIoManagerFactory(): MapIOManager {
  return new MapIOManager();
}
