/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable, Observer } from 'rxjs';

import { OutputDataModel } from '@oksygen-common-libraries/material/components';
import { Image } from '@oksygen-sim-train-libraries/components-services/common';

import { WorldContext } from '../contexts/world-context';
import { MapChildData } from './map-child.model';

export interface MainMapOutputData extends OutputDataModel {
  mapViewMapReady: Observer<boolean>;
}

export interface MainMapChildData<C extends WorldContext = WorldContext> extends MapChildData {
  // FIXME Shouldn't need this, but there's some weirdness on the SNCF deploy that we are unable to prevent. See INTOSC-8755
  enableDrag?: boolean;
  context?: C;
  boundsPaddingPercentage: number;
  images$: Observable<Image[]>;
}
