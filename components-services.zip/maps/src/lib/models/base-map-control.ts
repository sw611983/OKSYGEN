/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

// import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

export abstract class BaseMapControl {
  // abstract getFeature(systemId: number, id: number): ObjectContainer;
}
