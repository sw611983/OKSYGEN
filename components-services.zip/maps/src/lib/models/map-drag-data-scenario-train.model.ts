/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Consist, isConsistData } from '@oksygen-sim-train-libraries/components-services/trains';

export interface ScenarioTrainItem {
  scenarioTrainId: number;
  consist: Consist;
  driverType: DriverType;
}

/**
 * Checks if the given data (possibly from a specially encoded drag action) looks like a ScenarioTrainItem.
 *
 * @param maybeScenarioTrainItem a ScenarioTrainItem or a ScenarioTrainItem that has been mangled for inspection during drag.
 */
export function isScenarioTrainItem(data: {type: string; data: any}): boolean {
  if (data?.type !== 'train') {
    return false;
  }

  const maybeScenarioTrainItem = data.data;

  if (!maybeScenarioTrainItem) {
    return false;
  }

  const props = Object.getOwnPropertyNames(maybeScenarioTrainItem);

  // Note that any tests for properties or values with capital letters need to also test for a similar lowercase property,
  // due to potential mangling during a drag.
  if ((maybeScenarioTrainItem.scenarioTrainId || maybeScenarioTrainItem.scenariotrainid)
  &&  maybeScenarioTrainItem.consist
  &&  (props.includes('driverType') || props.includes('drivertype'))
  &&  isConsistData(maybeScenarioTrainItem.consist)) {
    return true;
  }

  return false;
}
