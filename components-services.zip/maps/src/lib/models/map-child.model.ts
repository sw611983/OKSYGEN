/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable } from 'rxjs';

/** The data a dynamic map component expects as input. Extend as required! */
export interface MapChildData {
  /** A unique id for this map if there could be multiple. */
  id?: string;
  /** The scenario editor contains a resizable grid, this observable will fire on resizeEnd. */
  resize$?: Observable<void>;
}
