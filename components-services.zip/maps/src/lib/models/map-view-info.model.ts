/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable } from 'rxjs';

import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';

export enum ZoomLevel {
  EVERYTHING = 1,
  REGION     = 2,
  TOWN       = 3,
  STATION    = 4,
  VEHICLE    = 5,
  PERSON     = 6
}

export function convertZoomLevel(initialValue: number, zoomLevel: ZoomLevel): number {
  let zoom = initialValue;

  switch (zoomLevel) {
    case ZoomLevel.EVERYTHING:
      zoom = 0;
      break;
    case ZoomLevel.REGION:
      zoom = 10;
      break;
    case ZoomLevel.TOWN:
      zoom = 14;
      break;
    case ZoomLevel.STATION:
      zoom = 16;
      break;
    case ZoomLevel.VEHICLE:
      zoom = 18;
      break;
    case ZoomLevel.PERSON:
      zoom = 20;
  }

  return zoom;
}

export enum MapMovementType {
  EASE,
  FLY,
  JUMP,
  PAN
}

export interface MapViewInfo {
  lngLat: LngLatCoord;
  zoom?: ZoomLevel;
  movementType?: MapMovementType;
}

/**
 * Describes when a map module is ready.
 * A module is a loading stage of the map - ie the image(s) loading or the initial zoom.
 */
export interface MapModuleReady {
  id: string;
  displayName?: string;
  ready$: Observable<boolean>;
}
