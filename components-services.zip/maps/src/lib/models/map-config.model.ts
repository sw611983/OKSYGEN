/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { merge } from 'lodash';

import { Registry } from '@oksygen-common-libraries/pio';
import { MapColor } from '../helpers/map-color.enum';

/**
 * Describes the direction object containers should stack on the map.
 * Note only vertical is currently supported.
 */
export type MapObjectContainerStackDirection =
  'horizontal'|'horizontal-reverse'
  |'vertical'|'vertical-reverse'
  |'perpendicular'
  |'diagonal-left-up'|'diagonal-left-down'|'diagonal-right-up'|'diagonal-right-down';
/**
 * Describes the configuration of the maps.
 */
export interface MapConfig {
  /** Default map styling. */
  defaultStyle: MapStyling;
  /** Styling when the map is in Show Train Path Only mode. */
  trainPathOnlyStyle: TrainPathOnlyStyling;
  objects: ObjectConfig;
}

/**
 * Describes the visual styling configuration of the maps.
 */
export interface MapStyling {
  colors: MapColors;
}

/**
 * Describes the colours used in the maps.
 */
export interface MapColors {
  track: TrackColors;
}

/**
 * Describes the colours used for rendering tracks.
 */
export interface TrackColors {
  /** Colour for regular tracks. */
  trackLineColor: string;
  /** Colour for scenery tracks. TODO: handle colouring arbitrary track types */
  sceneryTrackLineColor: string;
  /** Colour for the preview shown to the user during path selection. */
  previewPathLineColor: string;
  /** Colour for invalid preview shown to the user during path selection */
  previewInvalidPathLineColor: string;
  /** Colour for the path selected by a user. */
  selectedPathLineColor: string;
}

  /** Styling when the map is in Show Train Path Only mode. */
export interface TrainPathOnlyStyling {
  /**
   * Styling for items associated with the train's path.
   * Properties not specified here will instead be driven by the default style.
   */
  onPath: MapStyling;
  /**
   * Styling for not items associated with the train's path.
   * Properties not specified here will instead be driven by the default style.
   */
  offPath: MapStyling;
}

/**
 * Describes functional aspects of Objects in maps.
 */
export interface ObjectConfig {
  /** This is a hack to tolerate object containers with their children going the opposite direction. */
  usePromotedChildOrientation: boolean;
  /** Describes the direction object containers should stack on the map. Note only horizontal and vertical are currently supported. */
  stackDirection: MapObjectContainerStackDirection;
  showAllChildren: boolean;
  /** By default we use object container parent position - you can override this and use the promoted child position instead. */
  usePromotedChildPosition: boolean;
}

const DEFAULT_TRACK_COLORS: TrackColors = {
  trackLineColor: MapColor.TRACK_LINE,
  sceneryTrackLineColor: MapColor.SCENERY_TRACK_LINE,
  previewPathLineColor: MapColor.PREVIEW_PATH_LINE,
  previewInvalidPathLineColor: MapColor.RED,
  selectedPathLineColor: MapColor.SELECTED_PATH_LINE
};

/** A default value for the defaultStyle in {@link MapConfig} */
const DEFAULT_DEFAULT_STYLE: MapStyling = {
  colors: {track: DEFAULT_TRACK_COLORS}
};

const DEFAULT_OFF_PATH_TRACK_COLORS: TrackColors = {
  ...DEFAULT_TRACK_COLORS,
  trackLineColor: MapColor.SCENERY_TRACK_LINE,
  sceneryTrackLineColor: MapColor.SCENERY_OFF_TRACK_LINE
};

const DEFAULT_CONFIG: MapConfig = {
  defaultStyle: DEFAULT_DEFAULT_STYLE,
  trainPathOnlyStyle: {
    onPath: {...DEFAULT_DEFAULT_STYLE},
    offPath: {
      colors: {
        track: DEFAULT_OFF_PATH_TRACK_COLORS
      }
    }
  },
  objects: {
    usePromotedChildOrientation: false,
    showAllChildren: true,
    usePromotedChildPosition: false,
    stackDirection: 'horizontal'
  }
};

export function readMapConfig<T extends MapConfig>(registry: Registry): T {
  const suppliedConfig = registry.getObject<T>(['maps', 'config'], ({} as T));

  const legacyConfig = registry.getObject<LegacyTrackColors>(['track', 'colors'], ({} as LegacyTrackColors));

  const defaultTrackColours: TrackColors = {
    ...DEFAULT_TRACK_COLORS,
    ...legacyConfig
  };

  const legacyConfigAsMapConfig: MapConfig = {
    defaultStyle: {
      colors: {
        track: {
          ...defaultTrackColours
        }
      }
    },
    trainPathOnlyStyle: {
      onPath: {
        colors: {
          track: {
            ...defaultTrackColours,
            sceneryTrackLineColor: legacyConfig.sceneryOnPathTrackLineColor
          }
        }
      },
      offPath: {
        colors: {
          track: {
            ...defaultTrackColours,
            trackLineColor: legacyConfig.offPathLineColor
          }
        }
      }
    },
    objects: DEFAULT_CONFIG.objects
  };

  return merge({}, DEFAULT_CONFIG, legacyConfigAsMapConfig, suppliedConfig);
}

const colorConfigSchema: Record<string, any> = {
  type: 'object',
  properties: {
    trackLineColor: { type: 'string' },
    offPathLineColor: { type: 'string' },
    selectedPathLineColor: { type: 'string' },
    previewPathLineColor: { type: 'string' },
    previewInvalidPathLineColor: { type: 'string' },
    sceneryTrackLineColor: { type: 'string' },
    sceneryOnPathTrackLineColor: { type: 'string' }
  }
};

export const mapConfigSchema: Record<string, any> = {
  $id: 'oksygen-map-config',
  type: 'object',
  properties: {
    maps: {
      type: 'object',
      properties: {
        config: {
          type: 'object',
          properties: {
            allowLabelOverlap: {type: 'boolean' },
            defaultStyle: {
              type: 'object',
              properties: {
                colors: {
                  type: 'object',
                  properties: {
                    track: colorConfigSchema
                  }
                }
              }
            },
            trainPathOnlyStyle: {
              type: 'object',
              properties: {
                onPath: {
                  type: 'object',
                  properties: {
                    colors: {
                      type: 'object',
                      properties: {
                        track: colorConfigSchema
                      }
                    }
                  }
                },
                offPath: {
                  type: 'object',
                  properties: {
                    colors: {
                      type: 'object',
                      properties: {
                        track: colorConfigSchema
                      }
                    }
                  }
                }
              }
            },
            objects: {
              type: 'object',
              properties: {
                usePromotedChildOrientation: { type: 'boolean' },
                usePromotedChildPosition: { type: 'boolean' },
                showAllChildren: { type: 'boolean' },
                stackDirection: { type: 'string', enum: ['vertical'] }
              }
            }
          }
        }
      }
    },
    track: colorConfigSchema
  }
};

interface LegacyTrackColors {
  trackLineColor?: string;
  offPathLineColor?: string;
  selectedPathLineColor?: string;
  previewPathLineColor?: string;
  previewInvalidPathLineColor?: string;
  sceneryTrackLineColor?: string;
  sceneryOnPathTrackLineColor?: string;
}
