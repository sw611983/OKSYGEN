/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isFunction, isNil } from 'lodash';

import { BannerOption } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';

/**
 * Allows callers to set the contents of a banner.
 */
export interface BannerController {
  /**
   * Shows a banner with the given content and options.
   *
   * @param content Text or HTML content.
   * @param options The options to display.
   */
  showBanner: (config: {content?: string; options?: BannerOption[]; icon?: OksygenIcon | string; isActive?: boolean}) => void;
  /**
   * Hides the banner.
   */
  hideBanner: () => void;
}

export function isBannerController(controller: any): controller is BannerController {
  return !isNil(controller) && isFunction(controller.showBanner) && isFunction(controller.hideBanner);
}
