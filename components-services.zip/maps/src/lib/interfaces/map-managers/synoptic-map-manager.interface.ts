/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable } from 'rxjs';

import { IMapManager, isMapManager } from './map-manager.interface';

export const SYNOPTIC_MAP_MANAGER_TYPE = 'SynopticMapManager';

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 */
export interface ISynopticMapManager extends IMapManager {
  // synoptic style methods, optional as other map types won't need them
  // TODO consider other method to allow access to map specific functions
  subscribeToCorridorNames?(): Observable<string[]>;

  selectCorridor?(corridorName?: string): void;

  selectedCorridorName$?(): Observable<string>;
}

export function isSynopticMapManager(manager: any): manager is ISynopticMapManager {
  return isMapManager(manager) && manager.getManagerTypes().includes(SYNOPTIC_MAP_MANAGER_TYPE);
}
