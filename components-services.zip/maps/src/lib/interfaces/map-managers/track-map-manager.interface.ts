/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';
import { Observable } from 'rxjs';

import { IReachablePath, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { PointSelectionHandler } from '../selection-handlers/selection-point.interface';
import { TrackSelectionHandler } from '../selection-handlers/selection-track.interface';
import { IMapManager, isMapManager, MapManagerConfiguration } from './map-manager.interface';

export const TRACK_MAP_MANAGER_TYPE = 'TrackMapManager';

export interface TrackMapManagerConfiguration extends MapManagerConfiguration {
  pointType: ObjectTypeContainer;

  netDef$: Observable<NetworkDefinitionManager>;

  world$: Observable<WorldData>;

  highlightedPath$?: Observable<IReachablePath>;
}

export function isTrackMapManagerConfiguration(configuration: any): configuration is TrackMapManagerConfiguration {
  return !isNil(configuration) && !isNil(configuration.pointType) && !isNil(configuration.netDef$) && !isNil(configuration.world$);
}

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 */
export interface ITrackMapManager extends IMapManager {
  /**
   * Sets the track selection handler if no handler is currently active.
   * ```clearTrackSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  setTrackSelectionHandler(handler: TrackSelectionHandler): void;

  /**
   * Clears the track selection handler, allowing other handlers to be attached.
   */
  clearTrackSelectionHandler(): void;

  /**
   * Returns the current Track selection handler.
   */
  getTrackSelectionHandler(): TrackSelectionHandler;

  /**
   * Sets the Point selection handler if no handler is currently active.
   * ```clearPointSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  setPointSelectionHandler(handler: PointSelectionHandler): void;

  /**
   * Returns the current Point selection handler.
   */
  getPointSelectionHandler(): PointSelectionHandler;

  /**
   * Clears the Point selection handler, allowing other handlers to be attached.
   */
  clearPointSelectionHandler(): void;
}

export function isTrackMapManager(manager: any): manager is ITrackMapManager {
  return isMapManager(manager) && manager.getManagerTypes().includes(TRACK_MAP_MANAGER_TYPE);
}
