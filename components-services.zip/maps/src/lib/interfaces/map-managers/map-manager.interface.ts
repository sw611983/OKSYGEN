/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { isFunction, isNil } from 'lodash';
import { LngLat, Map } from 'maplibre-gl';
import { Observable, Subject, Subscription } from 'rxjs';

import { DragFeedback, SelfCompletingObservable, SuperCalled } from '@oksygen-common-libraries/common';
import { LngLatCoord, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData, Image, ObjectLayer } from '@oksygen-sim-train-libraries/components-services/common';

import { Sources } from '../../helpers/mapbox.source';
import { MapConfig } from '../../models/map-config.model';
import { SelectionValue } from '../../services/mapbox.layers';

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface MapManagerConfiguration {
  mapConfig: MapConfig;
}

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 */
export interface IMapManager {
  /**
   * Return the types that the manager supports, this allows for type checking before casting to a particular interface
   */
  getManagerTypes(): Array<string>;

  getStyleSources(): Sources;

  // initialisation methods
  /**
   * Attach mapbox layers to the mapbox map. Layers are used to tell mapbox HOW to render the data.
   * Note this doesn't tell mapbox what the data is, for that use attachSourcesTo().
   *
   * @param map the mapbox map to update
   */
  attachLayersTo(map: Map, elRef: ElementRef, getDragPreview: (objectRef: any) => Element): SuperCalled;

  /**
   * Attach mapbox data to the mapbox map.
   * Also attach some data listeners to update the map when things update.
   * Note this doesn't tell mapbox HOW to render this data, for that use attachLayersTo().
   *
   * @param map the map to update
   * @param parentSubscription when this unsubscribes we'll unsubscribe our map updates
   */
  attachSourcesTo(map: Map, parentSubscription: Subscription): SuperCalled;
  /**
   * Attach a list of images to the map. Returns observable of the progress.
   * Observable completes when all images are finished adding (ie, reaches 1).
   * You must subscribe to the returned obs for this to execute!
   *
   * @param map the map to attach images to
   * @param images the images to attach
   * @returns progress from [0, 1] of images added as they're added. IE, 0.5 when 2/4 images added.
   */
  attachImagesTo(map: Map, images: Array<Image>, batchSize?: number, delayBetweenBatches?: number): Observable<number>;

  mapReady$(): Observable<boolean>;

  geometrySourceUpdated$(): Observable<unknown>;

  destroy(): SuperCalled;
  clear(): SuperCalled;

  getHoverLayerName(): string;

  registerClickHandler(selectedSubject: Subject<SelectionValue>, stopPropagation: boolean): void;

  addImagesToMap(
    addDirectionalImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    addDirectionalRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    addDirectionalTwoObjectsRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
  ): void;

  initDragInputHandling(map: Map, subscription: Subscription): void;

  /**
   * Returns an observable which will supply data describing the item that is currently being dragged from the map.
   */
  getDragData$(): Observable<DragData>;

  onDrag(
    dragData: DragData,
    lngLat: LngLat,
    lngLatCoord: LngLatCoord,
    segOffset: SegOffsetOriented,
    userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback> | undefined;

  removeDragFeedback(): void;

  onDrop(dragData: DragData, lngLat: LngLat, lngLatCoord: LngLatCoord, segOffset: SegOffsetOriented, userScale: Array<UserScale>): void;

  onDragLayersUpdate(layers: Array<ObjectLayer>): void;

  updateWorldBounds(map: Map): Array<any>;
}

export function isMapManager(manager: any): manager is IMapManager {
  return !isNil(manager) && isFunction(manager.getManagerTypes);
}
