/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';
import { Map } from 'maplibre-gl';
import { Observable } from 'rxjs';

import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { ObjectsSourceManagerConfiguration } from '../../services/source-layer-managers/objects/objects-source-manager';
import { ObjectSelectionHandler } from '../selection-handlers/selection-object.interface';
import { isMapManager } from './map-manager.interface';
import { isTrackMapManagerConfiguration, ITrackMapManager, TrackMapManagerConfiguration } from './track-map-manager.interface';
import { ObjectsLayerManagerConfiguration } from '../../services/source-layer-managers/objects/objects-layer-manager';

export const OBJECT_MAP_MANAGER_TYPE = 'ObjectMapManager';

export interface ObjectTrackMapManagerConfiguration extends TrackMapManagerConfiguration, ObjectsLayerManagerConfiguration {
  objectsSourceManagerConfiguration: ObjectsSourceManagerConfiguration;

  objects$: Observable<ObjectContainer[]>;
}

export function isObjectTrackMapManagerConfiguration(configuration: any): configuration is ObjectTrackMapManagerConfiguration {
  return !isNil(configuration) && !isNil(configuration.objects$) && isTrackMapManagerConfiguration(configuration);
}

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 */
export interface IObjectTrackMapManager extends ITrackMapManager {
  /**
   * Sets the Object selection handler if no handler is currently active.
   * ```clearObjectSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  setObjectSelectionHandler(handler: ObjectSelectionHandler): void;

  /**
   * Returns the current Object selection handler.
   */
  getObjectSelectionHandler(): ObjectSelectionHandler;

  /**
   * Clears the Object selection handler, allowing other handlers to be attached.
   */
  clearObjectSelectionHandler(): void;

  getGeoJsonFeaturesFromSource(map: Map): Array<any>;
}

export function isObjectTrackMapManager(manager: any): manager is IObjectTrackMapManager {
  return isMapManager(manager) && manager.getManagerTypes().includes(OBJECT_MAP_MANAGER_TYPE);
}
