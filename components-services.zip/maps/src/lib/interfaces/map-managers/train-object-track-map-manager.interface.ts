/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { DriverSourceManagerConfiguration } from '../../services/source-layer-managers/driver/driver-source-manager';
import { TrainSelectionHandler } from '../selection-handlers/selection-train.interface';
import { isMapManager } from './map-manager.interface';
import { IObjectTrackMapManager, ObjectTrackMapManagerConfiguration } from './object-track-map-manager.interface';

export const TRAIN_MAP_MANAGER_TYPE = 'TrainMapManager';

export interface TrainObjectTrackMapManagerConfiguration extends ObjectTrackMapManagerConfiguration, DriverSourceManagerConfiguration {}

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 */
export interface ITrainObjectTrackMapManager extends IObjectTrackMapManager {
  /**
   * Sets the train selection handler if no handler is currently active.
   * ```clearTrainSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  setTrainSelectionHandler(handler: TrainSelectionHandler): void;

  getTrainSelectionHandler(): TrainSelectionHandler;

  /**
   * Clears the train selection handler, allowing other handlers to be attached.
   */
  clearTrainSelectionHandler(): void;
}

export function isTrainObjectTrackMapManager(manager: any): manager is ITrainObjectTrackMapManager {
  return isMapManager(manager) && manager.getManagerTypes().includes(TRAIN_MAP_MANAGER_TYPE);
}
