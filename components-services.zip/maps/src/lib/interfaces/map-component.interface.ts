/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';
import { Map } from 'maplibre-gl';
import { BehaviorSubject } from 'rxjs';

export enum MapViewState {
  LOADING,
  READY,
  WORLD_DATA_EMPTY
}

export interface IMapComponent {
  mapViewReadySubject: BehaviorSubject<MapViewState>;

  map: Map;

  loading: boolean;

  /**
   * Useful for making calculations on how close a click was in metres to a particular location
   *
   * @param proximityDelta distance in pixels to meature
   * @returns map distance in metres
   */
  getScaledDistance(proximityDelta: number): number;
}

export function isMapComponent(component: any): component is IMapComponent {
  return !isNil(component) && !isNil(component.mapViewReadySubject) && !isNil(component.map) && !isNil(component.loading);
}
