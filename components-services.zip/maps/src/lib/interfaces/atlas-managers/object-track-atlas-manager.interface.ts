/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { BehaviorSubject, Observable } from 'rxjs';

import { ObjectLayer } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer, ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { ObjectsSourceManagerConfiguration } from '../../services/source-layer-managers/objects/objects-source-manager';
import { ObjectSelectionHandler } from '../selection-handlers/selection-object.interface';
import { isAtlasManager, Selector } from './atlas-manager.interface';
import { ITrackAtlasManager, TrackAtlasManagerConfiguration } from './track-atlas-manager.interface';

export const OBJECT_ATLAS_MANAGER_TYPE = 'ObjectAtlasManager';

export interface ObjectTrackAtlasManagerConfiguration extends TrackAtlasManagerConfiguration {
  objectTypes$: Observable<Map<string, ObjectTypeContainer>>;

  objects$: Observable<ObjectContainer[]>;

  objectsSourceManagerConfiguration: ObjectsSourceManagerConfiguration;

  getObject$(id: string | number, useOriginal?: boolean): Observable<ObjectContainer>;

  getObject(id: number): ObjectContainer;
}


export interface IObjectTrackAtlasManager extends ITrackAtlasManager {
  spotlitObjectsSubject: BehaviorSubject<ObjectContainer[]>;
  selectedObjectSubject: BehaviorSubject<ObjectContainer>;

  objectUpdatedSubject: BehaviorSubject<ObjectContainer>;
  layerSubject: BehaviorSubject<ObjectLayer[]>;

  selectObject(objectId: number): Promise<void>;

  spotlightObject(objectId: number): Promise<void>;

  removeSpotlightObject(objectId: number): void;

  /**
   * Note this will NOT fire if the selected object changes.
   * ONLY fires when a different object is selected.
   * If you want object updates, you can subscribe to ```selectedObjectSubject``` directly.
   */
  getSelectedObject(): Observable<ObjectContainer>;

  setObjectDeselected(): void;

  filterObjects(layers: ObjectLayer[]): void;

  /**
   * Sets the object selection handler if no handler is currently active.
   * ```clearObjectSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  setObjectSelectionHandler(selector: Selector, handler: ObjectSelectionHandler): void;

  /**
   * Clears the train selection handler, allowing other handlers to be attached.
   */
  clearObjectSelectionHandler(selector: Selector): void;
}

export function isObjectTrackAtlasManager(manager: any): manager is IObjectTrackAtlasManager {
  return isAtlasManager(manager) && manager.getManagerTypes().includes(OBJECT_ATLAS_MANAGER_TYPE);
}
