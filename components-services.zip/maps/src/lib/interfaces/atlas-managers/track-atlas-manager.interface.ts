/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable } from 'rxjs';

import { WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { TrackLayerManagerConfiguration } from '../../services/source-layer-managers/track/track-layer-manager';
import { PointSelectionHandler } from '../selection-handlers/selection-point.interface';
import { TrackSelectionHandler } from '../selection-handlers/selection-track.interface';
import { IAtlasManager, isAtlasManager, Selector } from './atlas-manager.interface';

export const TRACK_ATLAS_MANAGER_TYPE = 'TrackAtlasManager';

export interface TrackAtlasManagerConfiguration extends TrackLayerManagerConfiguration {
  pointType: ObjectTypeContainer;

  netDef$: Observable<NetworkDefinitionManager>;

  world$: Observable<WorldData>;
}

export interface ITrackAtlasManager extends IAtlasManager {
  /**
   * Sets the track selection handler if no handler is currently active.
   * ```clearTrackSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  setTrackSelectionHandler(selector: Selector, handler: TrackSelectionHandler): void;

  /**
   * Clears the track selection handler, allowing other handlers to be attached.
   */
  clearTrackSelectionHandler(selector: Selector): void;

  /**
   * Sets the point selection handler if no handler is currently active.
   * ```clearPointSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  setPointSelectionHandler(selector: Selector, handler: PointSelectionHandler): void;

  /**
   * Clears the point selection handler, allowing other handlers to be attached.
   */
  clearPointSelectionHandler(selector: Selector): void;
}

export function isTrackAtlasManager(manager: any): manager is ITrackAtlasManager {
  return isAtlasManager(manager) && manager.getManagerTypes().includes(TRACK_ATLAS_MANAGER_TYPE);
}
