/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { BehaviorSubject, Observable } from 'rxjs';

import { IReachablePath, IReachablePathFinder } from '@oksygen-sim-train-libraries/components-services/common';
import { Consist, UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';

import { DriverSourceManagerConfiguration } from '../../services/source-layer-managers/driver/driver-source-manager';
import { TrainSelectionHandler } from '../selection-handlers/selection-train.interface';
import { isAtlasManager, Selector } from './atlas-manager.interface';
import { IObjectTrackAtlasManager, ObjectTrackAtlasManagerConfiguration } from './object-track-atlas-manager.interface';

export const TRAIN_ATLAS_MANAGER_TYPE = 'TrainAtlasManager';

export interface TrainObjectTrackAtlasManagerConfiguration extends ObjectTrackAtlasManagerConfiguration, DriverSourceManagerConfiguration {
  // can't extend a DragSourceHandlerConfiguration, as they contain a reference to a specific handler, and this configuration is used for all managers
  // so need to add it's data here
  consist$: Observable<Consist[]>;

  pathFinder$: Observable<IReachablePathFinder>;
}

export interface ITrainObjectTrackAtlasManager extends IObjectTrackAtlasManager {
  spotlitTrainSubject: BehaviorSubject<UsefulTrain>;

  /**
   * Indicates which path should be shown on the line view.
   * In the future this may be expanded to allow corridors to be supplied.
   */
  lineViewPathSubject: BehaviorSubject<IReachablePath>;
  /**
   * Indicates which path (and related objects) should be highlighted on the map views.
   * Typically associated with train selection.
   */
  highlightedPathSubject: BehaviorSubject<IReachablePath>;

  spotlightTrain(scenarioTrainId: number): Promise<void>;

  // FIXME We should probably make this accept the train to be followed, rather than assuming that we want to follow the selected train.
  // TODO In the long term this should be able to target anything that moves (road vehicles, pedestrians, etc).
  followTrain(follow: boolean): void;

  clearHighlightedPath(): void;

  /**
   * Toggles whether a train's path is higlighted in map views.
   * This usually means non-highlighted tracks and their objects are made less prominant.
   *
   * If a train is supplied, and different to the train currently the focus of path highlighting, the new train will be used.
   * If the currently focused train is supplied again, or nothing is supplied, highlighting is switched off.
   *
   * @param train Optional train whose path we want highlighted.
   */
  toggleHighlightedPath(train?: UsefulTrain): void;

  getPathTrain(): UsefulTrain;

  getPathTrainId$(): Observable<number>;

  /**
   * Sets the train selection handler if no handler is currently active.
   * ```clearTrainSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  setTrainSelectionHandler(selector: Selector, handler: TrainSelectionHandler): void;

  /**
   * Clears the train selection handler, allowing other handlers to be attached.
   */
  clearTrainSelectionHandler(selector: Selector): void;
}

export function isTrainObjectTrackAtlasManager(manager: any): manager is ITrainObjectTrackAtlasManager {
  return isAtlasManager(manager) && manager.getManagerTypes().includes(TRAIN_ATLAS_MANAGER_TYPE);
}
