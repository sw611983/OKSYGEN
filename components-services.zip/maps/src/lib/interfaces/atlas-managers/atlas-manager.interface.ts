/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Type } from '@angular/core';
import { isFunction, isNil } from 'lodash';
import { BehaviorSubject } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';

import { MapMovementType, MapViewInfo, ZoomLevel } from '../../models/map-view-info.model';
import { MapToggles } from '../../models/map.model';
import { BannerController } from '../banner-controller.interface';
import { IMapComponent } from '../map-component.interface';
import { IMapManager } from '../map-managers/map-manager.interface';

/** The types of maps we currently support rendering. */
export enum MapType {
  PLAN = 'plan',
  SYNOPTIC = 'synoptic',
  LINE = 'line',
  MINIMAP = 'minimap'
}

export interface Selector {
  type: MapType;
  name?: string;
}

export interface ComponentSelector {
  type: MapType | Type<IMapManager>;
  name?: string;
}

export type IAtlasMapComponent = IMapComponent | (IMapComponent & BannerController);

export interface IAtlasManager {
  mapTogglesSubject: BehaviorSubject<MapToggles>;

  /**
   * Emits requests for the main map view to move to a specific point.
   * Send requests using {@link mapGoto}.
   * Once a request is serviced, {@link clearMapGoto} should be called.
   */
  worldMapLngLatSubject: BehaviorSubject<MapViewInfo>;

  /** a map of map managers! Typically, will contain plan, synoptic, line & mini map. */
  mapManagers: Map<string, IMapManager>;

  /** a map of map components! Typically, will contain plan, synoptic, line & mini map. */
  mapComponents: Map<string, IAtlasMapComponent>;

  getManager(selector: Selector): IMapManager;

  /**
   * Register a map with our map management system.
   *
   * @param name the name / id of the map
   * @param type the type of the map
   */
  getMapManager(type: MapType | Type<IMapManager>, name?: string): IMapManager;

  /**
   * Register a map with our map management system.
   *
   * @param name the name / id of the map
   * @param type the type of the map
   */
  registerMapComponent(selector: ComponentSelector, component: IAtlasMapComponent): void;

  getMapComponent(selector: ComponentSelector): IAtlasMapComponent;

  clear(): SuperCalled;
  destroy(): SuperCalled;

  clearSpotlights(): void;

  // TODO We will probably need to update this to apply some extra smarts rather than blindly setting the position.
  // For example, we may want to specify whether this is a system generated or user genereated request, etc.
  mapGoto(lngLat: LngLatCoord, zoom?: ZoomLevel, movementType?: MapMovementType): void;

  /**
   * Clears the request made to {@link mapGoto}.
   * Should be called once the request, delivered by {@link worldMapLngLatSubject}, has been serviced.
   */
  clearMapGoto(): void;

  /**
   * Return the types that the manager supports, this allows for type checking before casting to a particular interface
   */
  getManagerTypes(): Array<string>;
}

export function isAtlasManager(manager: any): manager is IAtlasManager {
  return !isNil(manager) && isFunction(manager.getManagerTypes);
}
