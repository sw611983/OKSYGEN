/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isFunction, isNil } from 'lodash';

import { DragFeedback } from '@oksygen-common-libraries/common';
import { LngLatCoord, SegOffset, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { REJECT_INTERACTION, SelectionHandler } from './selection-handler.interface';

export interface TrackLocationData {
  lngLat: LngLatCoord;
  segOffset: SegOffset;
  userScale: Array<UserScale>;
}

// TODO figure out where this should live. Possibly here
/**
 * Describes interactions that are possible with the Object layers.
 */
export interface ObjectSelectionHandler extends SelectionHandler {
  /** Called when the user hovers over a Object. */
  onObjectHovered: (id: number, data: any) => void;

  /** Called when the user clicks a Object. */
  onObjectClicked: (id: number, data: any) => void;

  /**
   * Called when the user presses on an Object.
   *
   * @returns true if the intereaction should initiate a drag, and suppress scrolling.
   * Note that drags are handed off to HTML5 drag and drop interactions,
   * so objects implementing this method don't get any further notifications about what the user is doing.
   */
  onObjectDown: (id: number, data: any) => boolean;

  /**
   * Called when an Object is dragged somewhere on the map.
   */
  onObjectDragged: (id: number, locationData: TrackLocationData) => DragFeedback;

  /**
   * Called when an Object is dropped somewhere on the map.
   */
  onObjectDropped: (id: number, locationData: TrackLocationData) => void;

  /**
   * Called when an Object Type is dragged somewhere on the map.
   */
  onObjectTypeDragged: (type: ObjectTypeContainer, locationData: TrackLocationData) => DragFeedback;

  /**
   * Called when an Object Type is dropped somewhere on the map.
   */
  onObjectTypeDropped: (type: ObjectTypeContainer, locationData: TrackLocationData) => void;

  /**
   * Called when the user hovers over a Object's Track Association.
   *
   * **Not currently used**
   */
  onTrackAssociationHovered: (id: number, data: any) => void;

  /**
   * Called when the user clicks a Object's Track Association.
   *
   * **Not currently used**
   */
  onTrackAssociationClicked: (id: number, data: any) => void;

  /**
   * Called when the user presses on an Object's Track Association.
   *
   * **Not currently used**
   *
   * @returns true if the intereaction should initiate a drag, and suppress scrolling.
   * Note that drags are handed off to HTML5 drag and drop interactions,
   * so objects implementing this method don't get any further notifications about what the user is doing.
   */
  onTrackAssociationDown: (id: number, data: any) => boolean;

  /**
   * Called when an Object's Track Association is dragged somewhere on the map.
   *
   * **Not currently used**
   */
  onTrackAssociationDragged: (id: number, segOffset: SegOffset) => DragFeedback;

  /**
   * Called when an Object's Track Association is dropped somewhere on the map.
   *
   * **Not currently used**
   */
  onTrackAssociationDropped: (id: number, segOffset: SegOffset) => void;

  /**
   * Called when drag feedback is removed
   */
  onDragEnded: () => void;
}

/**
 * Describes interactions that are possible for the map manager with the object layers.
 * Not for general usage.
 * Most code intended to do something useful with track interactions should implement ```ObjectSelectionHandler```.
 */
export interface RawObjectSelectionHandler {
  /** Called when the user hovers over an Object. */
  onObjectHovered: (id: number, data: any) => void;

  /** Called when the user clicks an Object. */
  onObjectClicked: (id: number, data: any) => void;

  /**
   * Called when the user presses on an Object.
   *
   * @returns true if the intereaction should initiate a drag, and suppress scrolling.
   */
  onObjectDown: (id: number, data: any) => boolean;
}

export const NULL_OBJECT_SELECTION_HANDLER: ObjectSelectionHandler = {
  onObjectHovered: (id, data) => {},
  onObjectClicked: (id, data) => {},
  onObjectDown: (id, data) => false,
  onObjectDragged: (id, locationData) => REJECT_INTERACTION,
  onObjectDropped: (id, locationData) => {},
  onObjectTypeDragged: (id, locationData) => REJECT_INTERACTION,
  onObjectTypeDropped: (id, locationData) => {},
  onTrackAssociationHovered: (id, data) => {},
  onTrackAssociationClicked: (id, data) => {},
  onTrackAssociationDown: (id, data) => false,
  onTrackAssociationDragged: (id, segOffset) => REJECT_INTERACTION,
  onTrackAssociationDropped: (id, segOffset) => {},
  onDragEnded: () => {}
};

export function isObjectSelectionHandler(handler: any): handler is ObjectSelectionHandler {
  return !isNil(handler) && isFunction(handler.onObjectClicked);
}
