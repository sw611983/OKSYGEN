/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isFunction, isNil } from 'lodash';

import { DragFeedback } from '@oksygen-common-libraries/common';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';

import { REJECT_INTERACTION, SelectionHandler } from './selection-handler.interface';

/**
 * Describes interactions that are possible with the Point layers.
 */
export interface PointSelectionHandler extends SelectionHandler {
  /** Called when the user hovers over a Point. */
  onPointHovered: (id: number, data: any) => void;

  /** Called when the user clicks a Point. */
  onPointClicked: (id: number, data: any) => void;

  /**
   * Called when the user presses on an Point.
   *
   * @returns true if the interaction should initiate a drag, and suppress scrolling.
   * Note that drags are handed off to HTML5 drag and drop interactions,
   * so components implementing this method don't get any further notifications about what the user is doing.
   */
  onPointDown: (id: number, data: any) => boolean;

  /**
   * Called when a Point is dragged somewhere on the map.
   *
   * **Not currently used**
   */
  onPointDragged: (id: number, lngLat: LngLatCoord) => DragFeedback;
}

/**
 * Describes interactions that are possible for the map manager with the Points layers.
 * Not for general usage.
 * Most code intended to do something useful with track interactions should implement ```PointSelectionHandler```.
 */
export interface RawPointSelectionHandler {
  /** Called when the user hovers over an Point. */
  onPointHovered: (id: number, data: any) => void;

  /** Called when the user clicks an Point. */
  onPointClicked: (id: number, data: any) => void;

  /**
   * Called when the user presses on an Point.
   *
   * @returns true if the intereaction should initiate a drag, and suppress scrolling.
   */
  onPointDown: (id: number, data: any) => boolean;
}

export const NULL_POINT_SELECTION_HANDLER: PointSelectionHandler = {
  onPointHovered: (id, data) => {},
  onPointClicked: (id, data) => {},
  onPointDown: (id, data) => false,
  onPointDragged: (id, lngLat) => REJECT_INTERACTION
};

export function isPointSelectionHandler(handler: any): handler is PointSelectionHandler {
  return !isNil(handler) && isFunction(handler.onPointClicked);
}
