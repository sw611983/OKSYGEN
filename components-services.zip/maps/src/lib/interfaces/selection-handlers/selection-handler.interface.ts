/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { DragFeedback } from '@oksygen-common-libraries/common';

/* eslint-disable @typescript-eslint/no-empty-interface */

export const REJECT_INTERACTION: DragFeedback = { allowed: false, message: t('No Handler Set!!') };

export type SelectionHandler = object;
