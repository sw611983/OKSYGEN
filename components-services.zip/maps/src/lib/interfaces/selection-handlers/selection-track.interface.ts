/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isFunction, isNil } from 'lodash';
import { LngLat } from 'maplibre-gl';

import { DragFeedback } from '@oksygen-common-libraries/common';
import { SegOffset } from '@oksygen-sim-core-libraries/data-types/common';

import { REJECT_INTERACTION, SelectionHandler } from './selection-handler.interface';

// TODO figure out where this should live. Possibly here
/**
 * Describes interactions that are possible with the track layers.
 * Callbacks are given segment and offset for convenience
 * (unlike ```RawTrackSelectionHandler``` which deals with Lat/Long).
 */
export interface TrackSelectionHandler extends SelectionHandler {
  /** Called when the user hovers over a point on the track. */
  onTrackHovered: (point: SegOffset) => void;

  /** Called when the user clicks a point on the track. */
  onTrackClicked: (point: SegOffset) => void;

  /**
   * Called when the user presses on a point on the track.
   *
   * @returns true if the interaction should initiate a drag, and suppress scrolling.
   */
  onTrackDown: (point: SegOffset) => boolean;

  /**
   * Called after onTrackDown (if it returned true) when the user drags their mouse/finger.
   *
   * @param point The nearest point on the track, or null when far from the track.
   */
  onTrackDragged: (point: SegOffset | null) => DragFeedback;

  /**
   * Called after onTrackDragged when the user releases their mouse/finger.
   *
   * @param point The nearest point on the track, or null when far from the track.
   */
  onTrackUp: (point: SegOffset) => void;

  /** Called when the user clicks a point on the track that is currently selected. */
  onSelectedClicked: (point: SegOffset) => void;

  /**
   * Called when the user presses on a point on the track that is currently selected.
   *
   * @returns true if the intereaction should initiate a drag, and suppress scrolling.
   */
  onSelectedDown: (point: SegOffset) => boolean;

  /**
   * Called after onSelectedDown when the user drags their mouse/finger.
   *
   * @param point The nearest point on the track, or null when far from the track.
   */
  onSelectedDragged: (point: SegOffset | null) => DragFeedback;

  /**
   * Called after onSelectedDown when the user releases their mouse/finger.
   *
   * @param point The nearest point on the track, or null when far from the track.
   */
  onSelectedUp: (point: SegOffset | null) => void;
}

/**
 * Data for ```RawTrackSelectionHandler``` callback methods.
 */
export interface RawTrackSelectionData {
  /** The place that was interacted with. */
  lngLat: LngLat;
  /** The IDs of segments that are near the location. */
  segIds: number[];
}

/**
 * Handles interaction with the Mapbox Map and GeoJSON objects.
 * Not for general usage.
 * Most code intended to do something useful with track interactions should implement ```TrackSelectionHandler```.
 */
export interface RawTrackSelectionHandler {
  onTrackPointHovered: (data: RawTrackSelectionData) => void;
  onTrackPointClicked: (data: RawTrackSelectionData) => void;
  onTrackPointDown: (data: RawTrackSelectionData) => boolean;
  onTrackPointUp: (data: RawTrackSelectionData) => void;
  onSelectedPointClicked: (data: RawTrackSelectionData) => void;
  onSelectedPointDown: (data: RawTrackSelectionData) => boolean;
  onSelectedPointUp: (data: RawTrackSelectionData) => void;
}

export const NULL_TRACK_SELECTION_HANDLER: TrackSelectionHandler = {
  onTrackHovered: point => {},
  onTrackClicked: point => {},
  onTrackDown: point => false,
  onTrackDragged: point => REJECT_INTERACTION,
  onTrackUp: point => {},
  onSelectedClicked: point => {},
  onSelectedDown: point => false,
  onSelectedDragged: point => REJECT_INTERACTION,
  onSelectedUp: point => {}
};

export function isTrackSelectionHandler(handler: any): handler is TrackSelectionHandler {
  return !isNil(handler) && isFunction(handler.onTrackClicked);
}
