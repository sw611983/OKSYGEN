/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isFunction, isNil } from 'lodash';
import { LngLat } from 'maplibre-gl';

import { DragFeedback } from '@oksygen-common-libraries/common';
import { SegOffset } from '@oksygen-sim-core-libraries/data-types/common';
import { Consist } from '@oksygen-sim-train-libraries/components-services/trains';

import { REJECT_INTERACTION, SelectionHandler } from './selection-handler.interface';

// TODO figure out where this should live. Possibly here
/**
 * Describes interactions that are possible with the Train layers.
 */
export interface TrainSelectionHandler extends SelectionHandler {
  /**
   * Called when the user hovers over a Train.
   *
   * @param hoverPoint The point on the track nearest to the mouse.
   */
  onTrainHovered: (id: number, hoverPoint: SegOffset, data: any) => void;

  /**
   * Called when the user clicks a Train.
   *
   * @param clickPoint the point that was clicked.
   */
  onTrainClicked: (id: number, clickPoint: SegOffset, data: any) => void;

  /**
   * Called when the user presses on a Train.
   *
   * @param clickPoint the point that was clicked.
   * @returns true if the intereaction should initiate a drag, and suppress scrolling.
   * Note that drags are handed off to HTML5 drag and drop interactions,
   * so objects implementing this method don't get any further notifications about what the user is doing.
   */
  onTrainDown: (id: number, clickPoint: SegOffset, data: any) => boolean;

  /**
   * Called when a Consist is dragged somewhere on the map.
   *
   * @param segOffset The point on the track nearest to the mouse.
   */
  onConsistDragged: (consist: Consist, segOffset: SegOffset) => DragFeedback;

  /**
   * Called when a Consist is dropped somewhere on the map.
   *
   * @param segOffset The point on the track nearest to the mouse.
   */
  onConsistDropped: (consist: Consist, segOffset: SegOffset) => void;

  /**
   * Called when a Scenario Train is dragged somewhere on the map.
   *
   * @param segOffset The point on the track nearest to the mouse.
   */
  onScenarioTrainDragged: (id: number, segOffset: SegOffset) => DragFeedback;

  /**
   * Called when a Scenario Train is dropped somewhere on the map.
   *
   * @param segOffset The point on the track nearest to the mouse.
   */
  onScenarioTrainDropped: (id: number, segOffset: SegOffset) => void;

  /**
   * Called when a Useful Train is dragged somewhere on the map.
   *
   * @param segOffset The point on the track nearest to the mouse.
   */
  onUsefulTrainDragged: (id: number, segOffset: SegOffset) => DragFeedback;

  /**
   * Called when a Useful Train is dropped somewhere on the map.
   *
   * @param segOffset The point on the track nearest to the mouse.
   */
  onUsefulTrainDropped: (id: number, segOffset: SegOffset) => void;
}

/**
 * Describes interactions that are possible for the map manager with the Train layers.
 * Not for general usage.
 * Most code intended to do something useful with track interactions should implement ```TrainSelectionHandler```.
 */
export interface RawTrainSelectionHandler {
  /** Called when the user hovers over a Train. */
  onTrainHovered: (id: number, lngLat: LngLat, data: any) => void;

  /** Called when the user clicks a Train. */
  onTrainClicked: (id: number, lngLat: LngLat, data: any) => void;

  /**
   * Called when the user presses on a Train.
   *
   * @returns true if the intereaction should initiate a drag, and suppress scrolling.
   */
  onTrainDown: (id: number, lngLat: LngLat, data: any) => boolean;
}

export const NULL_TRAIN_SELECTION_HANDLER: TrainSelectionHandler = {
  onTrainHovered: (id, data) => {},
  onTrainClicked: (id, data) => {},
  onTrainDown: (id, clickPoint, data) => false,
  onConsistDragged: (consist, segOffset) => REJECT_INTERACTION,
  onConsistDropped: (consist, segOffset) => {},
  onScenarioTrainDragged: (id, segOffset) => REJECT_INTERACTION,
  onScenarioTrainDropped: (id, segOffset) => {},
  onUsefulTrainDragged: (id, segOffset) => REJECT_INTERACTION,
  onUsefulTrainDropped: (id, segOffset) => {}
};

export function isTrainSelectionHandler(handler: any): handler is TrainSelectionHandler {
  return !isNil(handler) && isFunction(handler.onTrainClicked);
}
