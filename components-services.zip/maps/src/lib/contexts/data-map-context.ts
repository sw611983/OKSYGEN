/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';
import { Observable } from 'rxjs';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Context, ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';

import { isMapContext, MapContext, MapContextSupplier } from './map-context';
import { IAtlasManager } from '../interfaces/atlas-managers/atlas-manager.interface';

/**
 * A {@link Context}  which supplies data for driving map components.
 */
export interface DataMapContext<T = any, A extends IAtlasManager = IAtlasManager> extends MapContext<A> {
  data$: Observable<T>;
}

/**
 * Used for dependency injection.
 * Typically provided by using an existing {@link ContextSupplier} that supplies a Context compatible with {@link DataMapContext}.
 */
export abstract class DataMapContextSupplier<C extends DataMapContext = DataMapContext> extends MapContextSupplier<C> {}

export function isDataMapContext(context: any): context is DataMapContext {
  return !isNil(context) && !isNil(context.data$) && isMapContext(context);
}
