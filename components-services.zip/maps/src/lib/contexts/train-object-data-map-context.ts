/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';
import { Observable } from 'rxjs';

import { BaseTrainManager, ITrainReachablePathFinder } from '@oksygen-sim-train-libraries/components-services/trains';

import { ITrainObjectTrackAtlasManager } from '../interfaces/atlas-managers/train-object-track-atlas-manager.interface';
import { isMapContext } from './map-context';
import { ObjectDataMapContext, ObjectDataMapContextSupplier } from './object-data-map-context';

/**
 * A {@link Context}  which supplies data for driving map components.
 */
export interface TrainObjectDataMapContext<T = any, A extends ITrainObjectTrackAtlasManager = ITrainObjectTrackAtlasManager>
  extends ObjectDataMapContext<T, A> {
  trains: BaseTrainManager;

  pathFinder$: Observable<ITrainReachablePathFinder>;
}

/**
 * Used for dependency injection.
 * Typically provided by using an existing {@link ContextSupplier} that supplies a Context compatible with {@link TrainObjectDataMapContext}.
 */
export abstract class TrainObjectDataMapContextSupplier<
  C extends TrainObjectDataMapContext = TrainObjectDataMapContext
> extends ObjectDataMapContextSupplier<C> {}

export function isTrainObjectDataMapContext(context: any): context is TrainObjectDataMapContext {
  return !isNil(context) && !isNil(context.trains) && isMapContext(context);
}
