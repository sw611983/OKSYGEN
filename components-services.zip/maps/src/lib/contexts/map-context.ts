/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';

// Included for docco linking to work
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Context, ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';

import { MapIOManager } from '../services/map-io-manager';
import { WorldContext } from './world-context';
import { IAtlasManager } from '../interfaces/atlas-managers/atlas-manager.interface';

/**
 * A {@link Context}  which supplies data for driving map components.
 */
export interface MapContext<A extends IAtlasManager = IAtlasManager> extends WorldContext<A> {
  mapIo: MapIOManager;
}

/**
 * Used for dependency injection.
 * Typically provided by using an existing {@link ContextSupplier} that supplies a Context compatible with {@link MapContext}.
 */
export abstract class MapContextSupplier<C extends MapContext = MapContext> extends ContextSupplier<C> {}

export function isMapContext(context: any): context is MapContext {
  return !isNil(context) && !isNil(context.mapIo);
}
