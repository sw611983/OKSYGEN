/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';
import { Observable } from 'rxjs';

import { IReachablePathFinder } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer, ObjManager } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { BaseRule } from '@oksygen-sim-train-libraries/components-services/rules';

import { IObjectTrackAtlasManager } from '../interfaces/atlas-managers/object-track-atlas-manager.interface';
import { DataMapContext, DataMapContextSupplier } from './data-map-context';
import { isMapContext } from './map-context';

/**
 * A {@link Context}  which supplies data for driving map components.
 */
export interface ObjectDataMapContext<T = any, A extends IObjectTrackAtlasManager = IObjectTrackAtlasManager> extends DataMapContext<T, A> {
  objects: ObjManager;

  pathFinder$: Observable<IReachablePathFinder>;

  getLinkedRules$?: (selectedObj$: Observable<ObjectContainer>) => Observable<Array<BaseRule>>;

  objectModifications$: () => Observable<string[]>;
}

/**
 * Used for dependency injection.
 * Typically provided by using an existing {@link ContextSupplier} that supplies a Context compatible with {@link ObjectDataMapContext}.
 */
export abstract class ObjectDataMapContextSupplier<C extends ObjectDataMapContext = ObjectDataMapContext> extends DataMapContextSupplier<C> {}

export function isObjectDataMapContext(context: any): context is ObjectDataMapContext {
  return !isNil(context) && !isNil(context.objects) && isMapContext(context);
}
