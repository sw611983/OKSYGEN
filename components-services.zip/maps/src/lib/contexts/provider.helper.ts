/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ExistingSansProvider, FactorySansProvider, Provider } from '@angular/core';

import { DataMapContextSupplier } from './data-map-context';
import { MapContextSupplier } from './map-context';
import { ObjectDataMapContextSupplier } from './object-data-map-context';
import { TrainObjectDataMapContextSupplier } from './train-object-data-map-context';
import { WorldContextSupplier } from './world-context';

export function mapContextProviders(provider: FactorySansProvider | ExistingSansProvider): Array<Provider> {
  return [
    { provide: WorldContextSupplier, ...provider },
    { provide: MapContextSupplier, ...provider },
    { provide: DataMapContextSupplier, ...provider },
    { provide: ObjectDataMapContextSupplier, ...provider },
    { provide: TrainObjectDataMapContextSupplier, ...provider }
  ];
}
