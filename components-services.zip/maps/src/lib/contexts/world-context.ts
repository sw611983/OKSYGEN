/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil } from 'lodash';

import { Context, ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';
import { WorldManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { IAtlasManager } from '../interfaces/atlas-managers/atlas-manager.interface';

/**
 * A {@link Context}  which supplies data for a simulated world.
 */
export interface WorldContext<A extends IAtlasManager = IAtlasManager> extends Context {
  map: A;
  world: WorldManager;
}

/**
 * Used for dependency injection.
 * Typically provided by using an existing {@link ContextSupplier} that supplies a Context compatible with {@link WorldContext}.
 */
export abstract class WorldContextSupplier<A extends IAtlasManager = IAtlasManager> extends ContextSupplier<WorldContext<A>> {}

export function isWorldContext(context: any): context is WorldContext {
  return !isNil(context) && !isNil(context.map) && !isNil(context.world);
}
