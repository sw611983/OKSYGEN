/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import {
  asRegionLabelGeoJSON, asSynopticViewRegionGeoJSON, objectTypeIconName
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { ObjectData } from '@oksygen-sim-core-libraries/data-types/objects';

const objects = new Map<number, ObjectData>();
objects.set(1, {
  id: 1,
  name: 'test',
  type: 'hey',
  location: [12, 14],
  boundaries: [[[1, 2]], [[3, 4]], [[5, 6]]],
  trackAssociations: [],
  geometry: { x: 1, y: 2, z: 3, r: 4, p: 5, h: 6 },
  properties: {}
});

describe('mapbox source', () => {
  it('should return the correct icon id', () => {
    const mockType: any = {
      states: new Map([[1, { icons: { big: { id: 'bigIcon' }, small: { id: 'smallIcon' } } }]]),
      defaultState: { icons: { big: { id: 'defaultBigIcon' }, small: { id: 'defaultSmallIcon' } } }
    };

    expect(objectTypeIconName(mockType, 'B', 1)).toBe('bigIcon');
    expect(objectTypeIconName(mockType, 'S', 1)).toBe('smallIcon');
    expect(objectTypeIconName(mockType, 'B')).toBe('defaultBigIcon');
    expect(objectTypeIconName(mockType, 'S')).toBe('defaultSmallIcon');
  });

  it('should return an empty string if state is not found', () => {
    const mockType: any = {
      states: new Map(),
      defaultState: null
    };

    expect(objectTypeIconName(mockType, 'B', 1)).toBe('');
  });
  it('should return as synoptic view RegionGeoJson', () => {
    expect(asSynopticViewRegionGeoJSON(objects)).toEqual({
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          id: 1,
          properties: {
            name: 'test',
            type: 'hey'
          },
          geometry: {
            type: 'Polygon',
            coordinates: [
              [
                [1, 2],
                [1, 2]
              ]
            ]
          }
        },
        {
          type: 'Feature',
          id: 1,
          properties: {
            name: 'test',
            type: 'hey'
          },
          geometry: {
            type: 'Polygon',
            coordinates: [
              [
                [3, 4],
                [3, 4]
              ]
            ]
          }
        },
        {
          type: 'Feature',
          id: 1,
          properties: {
            name: 'test',
            type: 'hey'
          },
          geometry: {
            type: 'Polygon',
            coordinates: [
              [
                [5, 6],
                [5, 6]
              ]
            ]
          }
        }
      ]
    });
  });

  it('should return as region label GeoJsonProperties', () => {
    expect(asRegionLabelGeoJSON(objects)).toEqual({
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          id: 1,
          properties: {
            name: 'test',
            type: 'hey'
          },
          geometry: {
            type: 'Point',
            coordinates: [1, 2]
          }
        }
      ]
    });
  });
});
