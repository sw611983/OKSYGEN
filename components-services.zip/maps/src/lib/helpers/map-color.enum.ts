/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/* eslint-disable @typescript-eslint/no-duplicate-enum-values */
export enum MapColor {
  RED = '#ff0000',
  PINK = '#ff00e5',
  INDIGO = '#4b0082',
  GREEN = '#4caf50',
  PALE_INDIGO = '#9683eC',
  PALE_PINK = '#fbc8f6',
  BLUE = '#0f0',
  YELLOW = '#fffb19',

  TRACK_LINE= '#aaaaaa',
  SCENERY_TRACK_LINE = '#dddddd',
  SCENERY_OFF_TRACK_LINE = '#eeeeee',
  PREVIEW_PATH_LINE = '#8bd',
  SELECTED_PATH_LINE = '#3887be',

  TRACK_LAYER_LINE = '#B3B3B3',

  MINI_MAP_LINE = '#3f51b5',
  MINI_MAP_FILL = '#d6d6d6',

  BACKGROUND = '#fafafa',

  DEBUG_LAYER_TEXT = '#00a',
  POINT_LAYER_HIGHLIGHT = '#def',

  POINT_LAYER_NAME_GREY = '#e0e0e0',

  SELECTIONS_LAYER_INVALID = '#e66',
  SELECTIONS_LAYER_DRAG = '#eb4',
  SELECTIONS_LAYER_OTHER = '#3887be',
  OBJECT_DRAG_LAYER_PRIMARY = '#3887be',

  PLATFORM_LAYER ='#ec0'
}
