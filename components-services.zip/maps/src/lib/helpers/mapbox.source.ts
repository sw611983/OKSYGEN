/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FeatureCollection } from 'geojson';
import { GeoJSONSource, GeoJSONSourceSpecification, Map, MapMouseEvent, MapTouchEvent, SourceSpecification } from 'maplibre-gl';

// Allows us to deal with mouse and touch input at once
export type MapInputEventData = (MapMouseEvent | MapTouchEvent) & any;

export interface Sources {
  [_: string]: SourceSpecification;
}

export function notNullGeoJSONCollection(geojson: FeatureCollection): FeatureCollection {
  return geojson ?? emptyGeoJSONCollection();
}

export function emptyGeoJSON(): GeoJSONSourceSpecification {
  return { type: 'geojson', data: emptyGeoJSONCollection() };
}

export function emptyGeoJSONCollection(): FeatureCollection {
  return { type: 'FeatureCollection', features: [] };
}

export function asSelectedGeoJSON(coordinates: Array<number>): FeatureCollection {
  return {
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        properties: {},
        geometry: {
          type: 'Point',
          coordinates
        }
      }
    ]
  };
}

export function asSpotlitGeoJSON(featureCoordinates: Array<Array<number>>, featureId?: number, featureTypeId?: number, stateId?: number): FeatureCollection {
  return {
    type: 'FeatureCollection',
    features: featureCoordinates.map(fc => ({
      type: 'Feature',
      id: featureId,
      properties: {
        type: featureTypeId,
        state: stateId,
        // TODO this should be based on the type
        minzoom: 14
      },
      geometry: {
        type: 'Point',
        coordinates: fc
      }
    }))
  };
}

export function getMapGeoJSONSource(map: Map, id: string): GeoJSONSource {
  return map.getSource(id) as GeoJSONSource;
}

export function getGeoJSONFeaturesFromSource(map: Map, sourceName: string): any[] {
  // eslint-disable-next-line no-underscore-dangle
  return (map.getSource(sourceName) as any)?._data?.features ?? [];
}
