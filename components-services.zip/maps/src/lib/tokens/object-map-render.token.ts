/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { InjectionToken } from '@angular/core';

import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

/**
 * Return whether you want to add a label to this object and / or if you want to change the icon.
 */
export interface ObjectMapRendererFnResult {
  /** This will be centered on the icon. Try not to use too many characters to avoid spilling out! Less than 8 is good. */
  label?: string; // should this be { text: string, position:'center'|'top'|'bottom' / position: [x, y] } ?
  /**
   * Remember the icon you use needs to exist on mapbox otherwise it won't render anything.
   * Example id: 'icons/PSR/PSR_Speed10-SMALL.png'
   */
  icon?: string;
}

export type ObjectMapRenderer = {
  images?: string[];
  renderers: Map<string, ObjectMapRendererFn>;
};
/**
 * Whether you want to add a label to this object on the map and / or if you want to change the icon.
 */
export type ObjectMapRendererFn = (object: ObjectContainer) => ObjectMapRendererFnResult;

/** By default no label is added and the icon is not changed. */
export const defaultObjectMapRendererToken: ObjectMapRenderer = {
  renderers: new Map(),
  images: [] // example: 'icons/extra_feature.jpg'
};

// defaultObjectMapRendererToken.renderers.set('cow', o => ({label: 'hello', icon: '/Features/icons/extra_feature.jpg'}));
// ({label: 'hello', icon: '/Features/icons/PSR/PSR_Speed10-SMALL.png'})
/**
 * Provide this token if your project wants to add custom labels to icons on the map and / or change the icon of certain features.
 */
export const OBJECT_MAP_RENDERER_TOKEN = new InjectionToken<ObjectMapRenderer>('Object Map Renderer');
