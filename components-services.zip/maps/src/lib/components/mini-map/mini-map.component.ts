/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/// - - - - - -
/// This class is based on the following code / links below:
/// https://github.com/aesqe/mapboxgl-minimap/blob/master/mapboxgl-control-minimap.js
/// https://gis.stackexchange.com/questions/2951/algorithm-for-offsetting-a-latitude-longitude-by-some-amount-of-meters

import { AfterViewInit, Component, ElementRef, Input, OnDestroy, OnInit, signal } from '@angular/core';
import { isNil } from 'lodash';
import { Map, MapOptions } from 'maplibre-gl';
import { BehaviorSubject, combineLatest, fromEvent, Observable, of, Subscription } from 'rxjs';
import { startWith, switchMap, throttleTime } from 'rxjs/operators';

import { filterTruthy, shareReplayOne } from '@oksygen-common-libraries/common';

import { WorldContext, WorldContextSupplier } from '../../contexts/world-context';
import { MapType, Selector } from '../../interfaces/atlas-managers/atlas-manager.interface';
import { isMiniMapManager, MINIMAP_VIEW_NAME } from '../../services/minimap-view/minimap-view.manager';
import { BackgroundLayerManager } from '../../services/source-layer-managers/background-layer-manager';
import { MiniMapDynamicComponent } from './mini-map-dynamic.component';

@Component({
  selector: 'oksygen-mini-map',
  templateUrl: './mini-map.component.html',
  styleUrls: ['./mini-map.component.scss']
})
export class MiniMapComponent extends MiniMapDynamicComponent implements OnInit, AfterViewInit, OnDestroy {
  private static readonly MINI_MAP_ZOOM_LEVEL = 8;

  private static readonly SELECTOR: Selector = {
    type: MapType.MINIMAP,
    name: MINIMAP_VIEW_NAME
  };

  @Input() resize$!: Observable<void>;
  @Input() set parentMap(value: Map) {
    this.setParentMap(value);
  }
  @Input() set onlyCrosshair(value: boolean) {
    this.onlyCrosshairSubject.next(value);
  }

  private event$: Observable<any> = of(null);

  public loading = signal(true);
  public htmlId: string;
  private htmlLoadingSub = Subscription.EMPTY;

  public miniMap: Map;
  private crosshairElementRef: ElementRef<HTMLDivElement>;

  private contextSub = Subscription.EMPTY;
  private subscription = Subscription.EMPTY;

  private context: WorldContext;

  private parentMapSubject = new BehaviorSubject<Map>(undefined);
  private onlyCrosshairSubject = new BehaviorSubject<boolean>(true);
  private currentContextTruthy$ = this.contextSupplier.currentContext$().pipe(filterTruthy(), shareReplayOne());

  constructor(private readonly contextSupplier: WorldContextSupplier) {
    super();
  }

  public ngOnInit(): void {
    const id = this.data?.id ?? 0;
    this.htmlId = 'miniMap-' + id.toString();
    if (this.data.resize$) {
    }

    this.contextSub = this.currentContextTruthy$.subscribe(c => {
      this.context = c;
    });
  }

  public ngAfterViewInit(): void {
    const el = document.createElement('div');
    el.className = 'crosshair';
    this.crosshairElementRef = new ElementRef(el);
    this.initialiseMap();
  }

  public ngOnDestroy(): void {
    this.miniMap?.remove();
    this.htmlLoadingSub.unsubscribe();
    this.subscription.unsubscribe();
    this.contextSub.unsubscribe();
    this.parentMapSubject.complete();
    this.onlyCrosshairSubject.complete();
  }

  private initialiseMap(): void {
    this.miniMap = new Map(this.createMapConf());

    this.subscription.unsubscribe();
    this.subscription = new Subscription();

    this.subscription.add(
      this.currentContextTruthy$.subscribe(context => {
        this.onInitialContext(context);
      })
    );
  }

  private createMapConf(): MapOptions {
    return {
      container: this.htmlId,
      interactive: false,
      style: {
        version: 8,
        sources: {},
        layers: [BackgroundLayerManager.LAYER]
      },
      center: [0, 0],
      attributionControl: false,
      zoom: MiniMapComponent.MINI_MAP_ZOOM_LEVEL
    };
  }

  private onInitialContext(context: WorldContext): void {
    this.miniMap.setStyle({
      version: 8,
      name: 'Mini Map',
      sources: context.map.getManager(MiniMapComponent.SELECTOR).getStyleSources(),
      layers: []
    });

    this.miniMap.on('style.load', evt => {
      this.initialiseMapSourceAndLayer();
    });

    this.subscription.add(
      combineLatest([
        this.onlyCrosshairSubject.pipe(shareReplayOne()),
        this.parentMapSubject.pipe(shareReplayOne()),
        this.parentMapSubject.pipe(
          shareReplayOne(),
          switchMap(() => this.event$)
        )
      ]).subscribe(([onlyCrosshair, parentMap, parentMapMove]) => {
        if (!isNil(parentMap)) {
          const mapManager = this.context.map.getManager(MiniMapComponent.SELECTOR);

          if (isMiniMapManager(mapManager)) {
            mapManager.update(onlyCrosshair, parentMap.getBounds(), parentMap.getZoom());
          }
        }
      })
    );
  }

  private initialiseMapSourceAndLayer(): void {
    const mapManager = this.context.map.getManager(MiniMapComponent.SELECTOR);
    mapManager.attachLayersTo(this.miniMap, this.crosshairElementRef, undefined);
    mapManager.attachSourcesTo(this.miniMap, this.subscription);
  }

  public setParentMap(parentMap: Map): void {
    this.event$ = fromEvent<any>(parentMap as any, 'move').pipe(throttleTime(100), startWith(null));
    this.parentMapSubject.next(parentMap);

    if (!isNil(parentMap)) {
      this.loading.set(false);
    }
  }
}
