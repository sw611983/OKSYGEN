/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Map } from 'maplibre-gl';

import { DynamicComponent } from '@oksygen-common-libraries/material/components';
import { MapChildData } from '../../models/map-child.model';

export abstract class MiniMapDynamicComponent extends DynamicComponent<MapChildData, null> {
  abstract setParentMap(parentMap: Map): void;
}
