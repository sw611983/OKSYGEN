/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { AfterViewInit, Component, ElementRef, NgZone, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { isNil } from 'lodash';
import { LngLat, LngLatBounds, Map, MapOptions, NavigationControl, ScaleControl } from 'maplibre-gl';
import { BehaviorSubject, combineLatest, fromEvent, interval, Observable, of, Subject, Subscription } from 'rxjs';
import { distinctUntilChanged, filter, first, map, pairwise, switchMap, takeWhile, tap, throttleTime } from 'rxjs/operators';

import {
  DragFeedback,
  enableDragHandling,
  extractJSONData,
  filterTruthy,
  shareReplayOne,
  SUPER_WAS_CALLED,
  SuperCalled
} from '@oksygen-common-libraries/common';
import { BannerOption } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { Logging } from '@oksygen-common-libraries/pio';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { LngLatCoord, Orientation, SegOffset, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData, LoadingData } from '@oksygen-sim-train-libraries/components-services/common';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { WorldContext, WorldContextSupplier } from '../../contexts/world-context';
import { Selector } from '../../interfaces/atlas-managers/atlas-manager.interface';
import { isTrainObjectTrackAtlasManager } from '../../interfaces/atlas-managers/train-object-track-atlas-manager.interface';
import { BannerController } from '../../interfaces/banner-controller.interface';
import { IMapComponent, MapViewState } from '../../interfaces/map-component.interface';
import { IMapManager } from '../../interfaces/map-managers/map-manager.interface';
import { MainMapChildData, MainMapOutputData } from '../../models/main-map-child-data.model';
import { convertZoomLevel, MapMovementType, ZoomLevel } from '../../models/map-view-info.model';
import { MapIOService } from '../../services/map-io.service';
import { MapBoxBounds } from '../../services/mapbox.bounds';
import { SelectionValue } from '../../services/mapbox.layers';
import { BackgroundLayerManager } from '../../services/source-layer-managers/background-layer-manager';
import { MainMapViewDynamicComponent } from '../main-map-view-dynamic.component';
import { renderAvatarImageData, renderDirectionalTwoObjectsRingImageData, renderDirectionalRingImageData, renderDragPreview } from './map-view.helpers';

type MapPos = {
  centre: LngLat;
  zoom: number;
};

const EMPTY_DRAG_FEEDBACK: DragFeedback = { allowed: true, message: '' };

// When you scroll with your wheel, we don't want to retrigger a map update, if we are already triggering it because we're following the train
// This is used for when we are following the train but it is stationary so we don't receive map update but still need to update the zoom.
const MINIMUN_DEBOUNCING_WHEEL_ZOOM = 25;

/**
 * Base class for components that display a mapbox map.
 */
@Component({ template: '' })
export abstract class AbstractMapViewComponent<D extends MainMapChildData<C>, O extends MainMapOutputData, C extends WorldContext = WorldContext>
  extends MainMapViewDynamicComponent<D, O>
  implements OnInit, OnDestroy, AfterViewInit, IMapComponent, BannerController
{
  // Avoid ID collisions on the map div.
  // FIXME this will integer overflow if enough instances of the map are created.
  static mapDivIdGen = 0;
  readonly MAP_DIV_ID = `map-${++AbstractMapViewComponent.mapDivIdGen}`;
  @ViewChild('map') mapDiv: ElementRef<HTMLDivElement>;
  public abstract name: string;
  public override map: Map;
  public mapOptions: any;

  /**
   * Indicates the map is not ready, so a spinner will be displayed.
   * Extending classes must set this to false using ```setLoadingComplete()``` at the appropriate time.
   */
  public loading = true;
  /**
   * Array of things that can be loaded in the background that we don't need to wait for.
   * IE: unimportant map layers & images.
   */
  public backgroundLoading: LoadingData[];
  mapViewReadySubject: BehaviorSubject<MapViewState> = new BehaviorSubject<MapViewState>(MapViewState.LOADING);
  protected subscription: Subscription = new Subscription();
  // TODO set this based on user selections
  private readonly DEFAULT_ZOOM = 15;

  /**
   * Stores the user's selected zoom level.
   * This is used to avoid nasty interactions between updates to zoom level and the updates to the screen position.
   * If you zoom while the screen position is being updated, it can cause Mapbox to error and lose its mouse listener,
   * leaving the map with greatly reduced functionality.
   * This seems very similar to https://github.com/mapbox/mapbox-gl-js/issues/9793 but is more to do with zooming
   * while we're doing high frequency updates.
   * See INTOSC-6968.
   *
   * 12-05-2025 That seems to have been fixed 5 years ago and seems fine from my testing.
   */
  private targetZoom = this.DEFAULT_ZOOM;
  // Track the last emission time
  private lastWorldMapLngLatSubjectEmissionTime = 0;


  protected mapBoxBounds: MapBoxBounds;

  bannerActive= false;
  bannerIcon?: OksygenIcon | string;
  bannerText: string | undefined;
  bannerOptions: Array<BannerOption> = [];
  protected context: C;

  networkDefinitionManager: NetworkDefinitionManager;

  dragging = false;
  dragFeedback = EMPTY_DRAG_FEEDBACK;
  private dragBounds: LngLatBounds;
  private dragBoundsSegments: Array<number> = [];

  /** Holds data describing things being dragged from this view. */
  private dragData: DragData;

  // Use this to publish selections to, and from this, we then publish to the individual subjects
  // simplifies the rest of the code from knowing which other subjects to publish to
  private selectedSubject = new Subject<SelectionValue>();

  protected mapManager: IMapManager;
  private routerSubscription: Subscription;
  private currentRoute: string;
  currentContextTruthy$ = this.contextSupplier
    .currentContext$()
    .pipe(filterTruthy(), shareReplayOne())
    .pipe(map(c => c as C));

  constructor(
    private host: ElementRef,
    protected logger: Logging,
    protected mapIO: MapIOService,
    protected zone: NgZone,
    private elRef: ElementRef,
    protected contextSupplier: WorldContextSupplier,
    protected userService: UserService,
    private router: Router
  ) {
    super();
    // this.outputs.set('mapViewMapReady', this.mapViewReadySubject.pipe(shareReplayOne(), distinctUntilChanged()));
    // this.loadUserIcons();
    this.routerSubscription = this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe((e: any) => {
      this.updateMapSize(e);
    });
  }

  protected abstract getSelector(): Selector;

  protected setLoadingComplete(): void {
    if (this.loading) {
      if (this.data.enableDrag ?? true) {
        enableDragHandling(
          this.host,
          () => this.dragData,
          () => this.getDragPreview(this.dragData)
        );
      }
    }

    this.loading = false;
  }

  /**
   * Get a list of loading things that we should wait for to consider this "loaded".
   * Be careful overriding this as you'll probably want to wait on the modules
   * returned by this method in MapView in addition to anything you've got.
   *
   * @example // in extending class
   * getLoadingModules(): Array<Observable<boolean>> {
   *   return [...super.getLoadingModules(), this.customLoadingModule$];
   * }
   */
  protected getLoadingModules(): Array<Observable<boolean>> {
    const loading$ = interval(1000).pipe(
      map(n => this.loading === false),
      takeWhile(loaded => !loaded, true) // complete when finshed loading
    );
    const viewReady$ = this.mapViewReadySubject.asObservable();
    return [loading$, viewReady$.pipe(map(state => state === MapViewState.READY))];
  }

  /**
   * Notify listeners (typically this is just the parent) when the map has finished loading.
   */
  protected notifyListenersOnLoaded(): void {
    const modules$ = this.getLoadingModules();
    this.subscription.add(
      combineLatest(modules$)
        .pipe(map(readyArr => readyArr.reduce((prev, curr) => !!prev && !!curr)))
        .subscribe(result => this.outputs.mapViewMapReady.next(result))
    );
  }

  /**
   * this method fires once mapbox fires it's style.load event.
   * It's a useful place to put any once off mapbox map init work.
   */
  protected onMapStyleLoad(): SuperCalled {
    this.initialiseMapEvents();
    this.loadUserIcons();

    this.mapManager.addImagesToMap(
      this.addDirectionalTrackImageToMap.bind(this),
      this.addDirectionalRingImageToMap.bind(this),
      this.addDirectionalTwoObjectsRingImageToMap.bind(this)
    );

    return SUPER_WAS_CALLED;
  }

  getDragPreview(dragData: DragData): Element {
    return renderDragPreview(dragData.data);
  }

  ngOnInit(): SuperCalled {
    if (this.data.context) {
      this.context = this.data.context;
      this.currentContextTruthy$ = of(this.data.context);
    }
    this.initialiseDataListeners();
    return SUPER_WAS_CALLED;
  }

  ngOnDestroy(): SuperCalled {
    // Cache the the current view position( only if there is a valid world)
    this.context?.world?.world$?.pipe(first())?.subscribe(w => {
      const uiStateModel = this.getUiStateModel(this.context);
      if (!!w?.name && !!uiStateModel && !!this.map) {
        uiStateModel.mapPos = {
          centre: this.map.getCenter(),
          zoom: this.map.getZoom()
        };
      }
    });

    this.mapViewReadySubject.complete();
    this.selectedSubject.complete();
    this.subscription.unsubscribe();
    this.routerSubscription.unsubscribe();
    this.map?.remove();
    return SUPER_WAS_CALLED;
  }

  public ngAfterViewInit(): SuperCalled {
    this.initialiseMap();
    return SUPER_WAS_CALLED;
  }

  updateMapSize(navEvent: NavigationEnd): void {
    this.currentRoute = navEvent?.urlAfterRedirects ?? '';
    if (this.currentRoute.includes('session/')) {
      this.map?.resize();
    }
  }

  getUiStateModel(context: C): { mapPos: MapPos } {
    const selector = this.getSelector();
    return context?.uiState.getStateModel<any>(selector.type + '$' + selector.name, () => ({ mapPos: null }));
  }

  protected onInitialContext(context: C): SuperCalled {
    const selector = this.getSelector();
    // Style need to be set before adding layers
    context.map.registerMapComponent(selector, this);
    this.map.on('style.load', event => {
      // Add realtime data on map load
      const mapManager = context.map.getManager(selector);
      mapManager.attachLayersTo(this.map, this.elRef, o => this.getDragPreview(o));
      this.onMapStyleLoad();
    });
    context.map.getManager(selector).getStyleSources();
    this.map.setStyle({
      version: 8,
      name: this.getStyleName(),
      glyphs: 'assets/fonts/{fontstack}/{range}.pbf',
      sources: context.map.getManager(selector).getStyleSources(),
      layers: []
    });

    this.map.on('zoom', () => {
      this.mapBoxBounds?.setPaddedMaxBounds(this.map, this.data.boundsPaddingPercentage);
    });
    return SUPER_WAS_CALLED;
  }

  protected abstract getStyleName(): string;

  private initialiseMap(): void {
    this.map = new Map(this.createMapConf());
    this.map.dragRotate.disable();
    this.map.touchZoomRotate.disableRotation();
    this.map.zoomTo(this.DEFAULT_ZOOM);

    // Add map controls - zoom level
    this.map.addControl(new ScaleControl({}), 'bottom-left');
    this.map.addControl(new NavigationControl({ showCompass: false }), 'bottom-left');
    this.subscription.add(
      this.currentContextTruthy$.subscribe(context => {
        this.onInitialContext(context as C);
      })
    );
  }

  /**
   * Useful for making calculations on how close a click was in metres to a particular location
   *
   * @param proximityDelta distance in pixels to meature
   * @returns map distance in metres
   */
  public getScaledDistance(proximityDelta: number): number {
    const y = this.map.getContainer().clientHeight / 2;
    const left = this.map.unproject([0, y]);
    const right = this.map.unproject([proximityDelta, y]);
    return left.distanceTo(right);
  }

  onResize(): void {
    // Ensure the left edge of the map doesn't "move", as that is disconcerting to many people.
    // TODO Consider making this behaviour a config setting.
    // The calculations here will not be needed once https://github.com/mapbox/mapbox-gl-js/issues/4269 is resolved.
    // This code was adapted from this comment on that issue: https://github.com/mapbox/mapbox-gl-js/issues/4269#issuecomment-347544695

    // We are assuming that the current NW is what the user has set.
    // It may be better to set this based on some other event, such as on mouse drag.
    const desiredNW = this.map.getBounds().getNorthWest();
    // Note that this does not change after resize
    const currentCenter = this.map.getCenter();

    // Ensure that the canvas size is synchronised with the element size.
    // Not doing so can leave you with blank areas in your map as a result of certain interactions (such as resizing the browser).
    // This call will also move the map such that the current centre point will be the centre point when it returns.
    // This positioning behaviour is tweaked by the rest of this function.
    this.map.resize();

    // Find the difference between our desired and new NW points.
    const newNW = this.map.getBounds().getNorthWest();
    const deltaNW = { x: newNW.lng - desiredNW.lng, y: newNW.lat - desiredNW.lat };

    // Shift the centre to put the desired NW point
    const newCenter = new LngLat(currentCenter.lng - deltaNW.x, currentCenter.lat - deltaNW.y);
    this.map.setCenter(newCenter);
  }

  private initialiseDataListeners(): void {
    this.notifyListenersOnLoaded();

    this.subscription.add(
      this.currentContextTruthy$?.subscribe(m => {
        this.context = m;
      })
    );

    this.subscription.add(
      this.currentContextTruthy$
        ?.pipe(
          switchMap(m => {
            const selector = this.getSelector();
            this.mapManager = m.map.getMapManager(selector.type, selector.name);
            return this.mapManager.getDragData$();
          })
        )
        .subscribe(d => {
          this.dragData = d;
        })
    );

    this.subscription.add(
      this.currentContextTruthy$
        ?.pipe(
          filterTruthy(),
          switchMap(context => context.world.world$),
          pairwise()
        )
        .subscribe(w => {
          // Clear the cached map position if there is a change in the world.
          if (w[0]?.name !== w[1]?.name) {
            this.clearMapPos(this.context);
          }
        })
    );
  }

  private createMapConf(): MapOptions {
    return {
      attributionControl: false,
      container: this.MAP_DIV_ID,
      style: {
        version: 8,
        sources: {},
        layers: [BackgroundLayerManager.LAYER]
      },
      center: [0, 0],
      maxZoom: convertZoomLevel(0, ZoomLevel.PERSON),
      minZoom: convertZoomLevel(0, ZoomLevel.EVERYTHING), // we will overwrite this later in plan view component once we know the size of the world we've loaded
      zoom: this.DEFAULT_ZOOM
    };
  }

  private initialiseMapEvents(): void {
    this.mapManager.registerClickHandler(this.selectedSubject, true);

    // Disable any locking behaviour when the user starts to drag the view
    if (isTrainObjectTrackAtlasManager(this.context.map)) {
      const trainAtlasManager = this.context.map;

      this.subscription.add(
        fromEvent<any>(this.map as any, 'dragstart').subscribe(e => {
          trainAtlasManager.followTrain(false);
        })
      );
    }

    this.map.on('drag', () => {
      this.onManualScreenMovement();
    });

    // While following something on the map, we need to prevent the user zooming into arbitrary locations,
    // because subsequent updates from the thing we're following will result in an unpleasant jerk in the map's position.
    // We also need to actually service the user input.
    // FIXME memory leak - should use Renderer2 (deals with it automatically) or removeEventListener()
    this.mapDiv.nativeElement.addEventListener(
      'wheel',
      e => {
        // Approximates the changes in zoom when you move the scroll wheel one "click".
        // The logic for determining the correct abount to zoom (in Mapbox's scroll_zoom.js) is quite complex,
        // and doesn't really add much value in this situation so we're not duplicating it here.
        const approxTypicalZoomDelta = 0.151412;

        this.handleManualZoomRequest(e, -(Math.sign(e.deltaY) * approxTypicalZoomDelta));
      },
      true
    );

    // The following detects user interacton with the on-screen controls so we know when updates to state are from the user.
    this.mapDiv.nativeElement.querySelectorAll('.mapboxgl-control-container .mapboxgl-ctrl-group button').forEach(button => {
      let delta = 0;

      if (button.classList.contains('mapboxgl-ctrl-zoom-in')) {
        delta = 1;
      } else if (button.classList.contains('mapboxgl-ctrl-zoom-out')) {
        delta = -1;
      } else {
        return;
      }
      // FIXME memory leak - should use Renderer2 (deals with it automatically) or removeEventListener()
      button.addEventListener('click', (e: Event) => this.handleManualZoomRequest(e, delta), true);
    });

    this.initHoverLayer();

    this.initDragInputHandling();
  }

  /**
   * Handles a user's zoom request, particularly the juggling required to avoid that request from causing issues while following.
   * If we are following (and therefore expecting frequent updates to state) we will prevent the event from propagating and update the target zoom level.
   * Otherwise, we allow the event to propagate normally and attempt to set the target zoom level to the resulting zoom level.
   *
   * Typically **this should be invoked from callbacks that intercept events during the capture phase**,
   * otherwise the target will have likely already acted on the event.
   */
  private handleManualZoomRequest(e: Event, zoomDelta: number): void {
    if (this.context.map.mapTogglesSubject.getValue().follow) {
      e.stopPropagation();

      this.targetZoom = this.targetZoom + zoomDelta;

      // Ensure we action the zoom request when we are not getting updates to the world position (e.g. the train is stationary).
      // If you don't debounce it, this causes multiple render and not enough time to handle the request when the train is NOT stationary!
      const currentTime = Date.now();
      const timeSinceLastEmission = currentTime - this.lastWorldMapLngLatSubjectEmissionTime;

      // This is to avoid conflict when train moving is not stationary
      if (timeSinceLastEmission >= MINIMUN_DEBOUNCING_WHEEL_ZOOM) {
        const location = { ... this.context.map.worldMapLngLatSubject.getValue() }; // Use this.context
        location.zoom = undefined; // unset the zoom level, so we use the set targetZoom in the subscriber

        // This next() call will trigger the main subscription
        this.context.map.worldMapLngLatSubject.next(location);
      }
    } else {
      this.onManualScreenMovement();
    }
  }

  /**
   * Attempt to set the target zoom level to the resulting zoom level after a user interaction directly on the map.
   * Should be called after the user has manually set the view position.
   */
  private onManualScreenMovement(): void {
    setTimeout(() => {
      this.targetZoom = this.map.getZoom();
    }, 100); // We're using that the request from the user is serviced reasonably quickly.
  }

  private initHoverLayer(): void {
    const layerName = this.mapManager?.getHoverLayerName();

    if (!isNil(layerName)) {
      this.zone?.runOutsideAngular(() => {
        // Note that using 'mouseenter' seems like it would be more performant,
        // but it allows the previous set of points to remain highlighted if the mouse moves quickly to a new set.
        this.map.on('mousemove', layerName, event => {
          event.originalEvent.preventDefault();
          this.map.getCanvas().style.cursor = 'pointer';
        });
        this.map.on('mouseleave', layerName, event => {
          this.map.getCanvas().style.cursor = '';
        });
      });
    }
  }

  protected listenToPositionDataUpdates(): void {
    this.subscription.add(
      this.mapViewReadySubject
        .pipe(
          filterTruthy(),
          switchMap(x => this.currentContextTruthy$),
          tap(c => {
            const pos = this.getUiStateModel(c).mapPos;
            if (pos) {
              this.map.setZoom(pos.zoom);
              this.map.setCenter(pos.centre);
              // Clear mapPos once it is used.
              this.clearMapPos(c);
            }
          }),
          switchMap(c => c.map.worldMapLngLatSubject.asObservable()),
          filterTruthy(),
        )
        .subscribe(pos => {
          let zoom = this.targetZoom;

          if (pos.zoom) {
            // set this as the target zoom, so that subsequent updates with no zoom set, do not change what level we want to zoom to
            zoom = convertZoomLevel(zoom, pos.zoom);
            this.targetZoom = zoom;
          }

          const options = { center: pos.lngLat, zoom, essential: true };

          switch (pos.movementType) {
            case MapMovementType.EASE:
              this.map.easeTo(options);
              break;
            case MapMovementType.JUMP:
              this.map.jumpTo(options);
              break;
            case MapMovementType.PAN:
              // Adding the options here allow you to zoom as you pan
              // In maplibre doc, you see that panTo use EaseToOptions, which extends CameraOption, which extends CenterZoomBearing.
              this.map.panTo(pos.lngLat, options);
              break;
            case MapMovementType.FLY:
            default:
              this.map.flyTo(options);
              break;
          }

          this.context.map.clearMapGoto();
          this.lastWorldMapLngLatSubjectEmissionTime = Date.now();
        })
    );
  }

  private clearMapPos(context: C): void {
    this.getUiStateModel(context).mapPos = undefined;
  }

  /**
   * Prepares icons for users.
   */
  private loadUserIcons(): void {
    // FIXME belongs elsewhere; this makes no sense in contexts such as scenario editing.
    // TODO Use session info to select a subset of users.
    this.userService.users.forEach(u => {
      u.avatarHandler
        ?.asImgElement()
        .then(i => {
          renderAvatarImageData(i, true).then(d => {
            const name = 'U' + u.id + 'S';
            if (!this.map.hasImage(name)) {
              this.map.addImage(name, d);
            }
          });
          renderAvatarImageData(i, false).then(d => {
            const name = 'U' + u.id + 'S';
            if (!this.map.hasImage(name)) {
              this.map.addImage('U' + u.id, d);
            }
          });
        })
        .catch(r => {
          // TODO This gets rejected when using BaseX and there are missing avatar images.
          // We should be able to use a placeholder image here. See FIXMEs in the UserDataService.
          this.logger.log(`No avatar image found for user ${u.firstName} ${u.lastName} ${u.id}`);
        });
    });
  }

  private addDirectionalTrackImageToMap(name: string, primaryColour: string, secondaryColour: string, bidi: boolean): void {
    if (this.map.hasImage(name)) {
      return;
    }
    this.newDirectionalTrackAssocImageData(primaryColour, secondaryColour, bidi).then(d => {
      if (!this.map.hasImage(name)) {
        this.map.addImage(name, d);
      }
    });
  }

  private addDirectionalRingImageToMap(name: string, primaryColour: string, secondaryColour: string, bidi: boolean): void {
    if (this.map.hasImage(name)) {
      return;
    }
    this.newDirectionalIconRingImageData(primaryColour, secondaryColour, bidi).then(d => {
      if (!this.map.hasImage(name)) {
        this.map.addImage(name, d);
      }
    });
  }

  private addDirectionalTwoObjectsRingImageToMap(name: string, primaryColour: string, secondaryColour: string, bidi: boolean): void {
    if (this.map.hasImage(name)) {
      return;
    }
    this.newDirectionalTwoObjectsIconRingImageData(primaryColour, secondaryColour, bidi).then(d => {
      if (!this.map.hasImage(name)) {
        this.map.addImage(name, d);
      }
  });
  }

  private async newDirectionalTrackAssocImageData(primaryColour: string, secondaryColour: string, bidi: boolean): Promise<ImageData> {
    return renderDirectionalRingImageData(primaryColour, secondaryColour, !bidi, 12);
  }

  private async newDirectionalIconRingImageData(primaryColour: string, secondaryColour: string, bidi: boolean): Promise<ImageData> {
    return renderDirectionalRingImageData(primaryColour, secondaryColour, !bidi, 60);
  }

  private async newDirectionalTwoObjectsIconRingImageData(primaryColour: string, secondaryColour: string, bidi: boolean): Promise<ImageData> {
    return renderDirectionalTwoObjectsRingImageData(primaryColour, secondaryColour, !bidi, 60);
  }

  protected listenToResize(): void {
    if (this.data.resize$) {
      this.subscription.add(this.data.resize$?.subscribe(this.onResize.bind(this)));
      // As these listeners are potentially added quite some time after this component is created,
      // we need to make sure that we handle any changes in the DOM layout that happened in the interim.
      this.onResize();
    }
  }

  public showBanner(config: {content?: string; options?: BannerOption[]; icon?: OksygenIcon | string; isActive?: boolean}): void {
    this.zone.run(() => {
      this.bannerText = config.content;
      this.bannerIcon = config.icon;
      this.bannerOptions = config.options;
      this.bannerActive = config.isActive ?? true;
    });
  }

  public hideBanner(): void {
    this.bannerActive = false;
  }

  //
  // DRAG AND DROP BEHAVIOUR
  //

  private async initDragInputHandling(): Promise<void> {
    this.mapManager?.initDragInputHandling(this.map, this.subscription);

    this.subscription.add(
      this.context.world.netDef$.pipe(filterTruthy()).subscribe(n => {
        this.networkDefinitionManager = n;
      })
    );

    const consumeEvent = tap<DragEvent>(ev => {
      // Need to do this to every event, to avoid drags being caught by parent components
      ev.preventDefault();
      ev.stopImmediatePropagation();
    });

    this.subscription.add(
      fromEvent<DragEvent>(this.mapDiv.nativeElement, 'dragenter')
        .pipe(consumeEvent)
        .subscribe(e => this.onDragEnter(e))
    );

    this.subscription.add(
      fromEvent<DragEvent>(this.mapDiv.nativeElement, 'dragover')
        .pipe(
          consumeEvent,
          // To avoid excessive expensive segment position checks
          throttleTime(100),
          // To prevent spamming the same event over and over
          distinctUntilChanged((a, b) => a.offsetX === b.offsetX && a.offsetY === b.offsetY)
        )
        .subscribe(e => this.onDrag(e))
    );

    this.subscription.add(
      fromEvent<DragEvent>(this.mapDiv.nativeElement, 'drag')
        .pipe(consumeEvent)
        .subscribe(e => {})
    );

    this.subscription.add(
      fromEvent<DragEvent>(this.mapDiv.nativeElement, 'dragstart')
        .pipe(consumeEvent)
        .subscribe(e => {})
    );

    this.subscription.add(
      fromEvent<DragEvent>(this.mapDiv.nativeElement, 'dragend')
        .pipe(consumeEvent)
        .subscribe(e => {})
    );

    this.subscription.add(
      fromEvent<DragEvent>(this.mapDiv.nativeElement, 'dragleave')
        .pipe(consumeEvent)
        .subscribe(e => this.onDragLeave(e))
    );

    this.subscription.add(
      fromEvent<DragEvent>(this.mapDiv.nativeElement, 'drop')
        .pipe(consumeEvent)
        .subscribe(e => this.onDrop(e))
    );
  }

  private onDragEnter(ev: DragEvent): void {
    this.dragging = true;
  }

  private onDrag(ev: DragEvent): void {
    ev.dataTransfer.dropEffect = 'move';
    const data = extractJSONData<DragData>(ev.dataTransfer);
    if (!data) { return; }
    this.dragging = true;
    const b = this.map.getBounds();

    if (
      !this.dragBounds ||
      this.dragBounds.getNorth() !== b.getNorth() ||
      this.dragBounds.getSouth() !== b.getSouth() ||
      this.dragBounds.getEast() !== b.getEast() ||
      this.dragBounds.getWest() !== b.getWest()
    ) {
      this.dragBounds = b;
      this.dragBoundsSegments = this.networkDefinitionManager.segmentsInBoundingBox({
        minX: b.getWest(),
        maxX: b.getEast(),
        minY: b.getSouth(),
        maxY: b.getNorth()
      });
    }

    const lngLat = this.map.unproject([ev.offsetX, ev.offsetY]);
    const lngLatCoord: LngLatCoord = [lngLat.lng, lngLat.lat];
    const segOffset = this.findSegOffset(lngLatCoord);
    const userScale = this.findUserScale(segOffset);

    let dragHandled = false;

    this.dragFeedback = EMPTY_DRAG_FEEDBACK;

    if (!segOffset) {
      this.dragFeedback = {
        allowed: false,
        message: t('Cannot determine the track position')
      };

      dragHandled = true;
    }

    const dragObservable = this.mapManager.onDrag(data, lngLat, lngLatCoord, segOffset, userScale);

    if (!isNil(dragObservable)) {
      dragObservable.subscribe(feedback => {
        if (!isNil(feedback)) {
          this.dragFeedback = feedback;
        }
      });

      dragHandled = true;
    }

    if (!dragHandled) {
      this.logger.log('Unknown data type!', data);
      this.dragFeedback = {
        allowed: false,
        message: t('Unknown data type!')
      };
    }
  }

  private onDragLeave(ev: DragEvent): void {
    this.dragging = false;
    this.mapManager?.removeDragFeedback();
  }

  private onDrop(ev: DragEvent): void {
    this.dragging = false;
    this.mapManager?.removeDragFeedback();

    const data = extractJSONData<DragData>(ev.dataTransfer);
    const lngLat = this.map.unproject([ev.offsetX, ev.offsetY]);
    const lngLatCoord: LngLatCoord = [lngLat.lng, lngLat.lat];
    const segOffset = this.findSegOffset(lngLatCoord);
    const userScale = this.findUserScale(segOffset);

    this.mapManager?.onDrop(data, lngLat, lngLatCoord, segOffset, userScale);
  }

  findSegOffset(lngLat: LngLatCoord): SegOffsetOriented {
    return {
      ...this.networkDefinitionManager.lngLatToSegmentOffset(
        lngLat,
        // TODO  May be able to get this from the MapIOManager e.g.
        // this.mapIo.getVisibleSegments()
        this.dragBoundsSegments
      ),
      orientation: Orientation.ALPHA_TO_BETA
    };
  }

  findUserScale(segOffset: SegOffset): UserScale[] {
    return this.networkDefinitionManager.segOffsetToUserScale(segOffset);
  }
}
