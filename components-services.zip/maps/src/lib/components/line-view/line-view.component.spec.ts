/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { configureSimTrainTestingModule, prepareMapServicesForTesting } from '@oksygen-sim-train-libraries/components-services/testing';

import { LineViewComponent, LineViewMapChildData } from './line-view.component';
import { WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

describe('LineViewComponent', () => {
  let component: LineViewComponent;
  let fixture: ComponentFixture<LineViewComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [LineViewComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(LineViewComponent);
    component = fixture.componentInstance;
    const data: LineViewMapChildData = {
      features$: new Observable(obs => {
        obs.next([]);
        obs.complete();
      }),
      // mapManager: new MapManager(null, null, null, null, null, null, null, null),
      resize$: new Observable(obs => {
        obs.next(null);
        obs.complete();
      }),
      trains$: new Observable(obs => {
        obs.next([]);
        obs.complete();
      })
    };
    component.data = data;
    const mapControlService: any = null; // TestBed.inject(MapControlService);
    const worldDefService = TestBed.inject(WorldDefinitionService);
    prepareMapServicesForTesting(mapControlService, worldDefService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
