/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, OnDestroy, OnInit } from '@angular/core';
import { asyncScheduler, Observable, of, Subscription } from 'rxjs';
import { switchMap, tap, throttleTime } from 'rxjs/operators';

import { computeIfAbsent } from '@oksygen-common-libraries/common';
import { DynamicComponent } from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { IReachablePath } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';

import { MapContext, MapContextSupplier } from '../../contexts/map-context';
import { isObjectDataMapContext } from '../../contexts/object-data-map-context';
import { isTrainObjectDataMapContext } from '../../contexts/train-object-data-map-context';
import { MapType } from '../../interfaces/atlas-managers/atlas-manager.interface';
import { isTrainObjectTrackAtlasManager } from '../../interfaces/atlas-managers/train-object-track-atlas-manager.interface';
import { MapChildData } from '../../models/map-child.model';
import { LINE_VIEW_NAME } from '../../services/line-view/line-view.manager';

/**
 * Holds rendering info about the path for the html template.
 */
interface PathRenderingInfo {
  /** Length in meters. */
  length: number;
  /**
   * Indicates whether the ends of the path connect such that a train following it would
   * traverse the same segments in the same direction over and over again.
   * This definition does not include a path that has a single "U turn" which changes the direction of travel.
   * In future we may include additional information to indicate whether
   * it is only a subset of the path that loops on itself (i.e. a P-shaped path).
   */
  circular: boolean;
}

/**
 * Holds info about a segment on the path.
 * Note that it is possible for a segment to appear multiple times (e.g. a P-shaped path).
 */
interface SegmentInfo {
  id: number;
  /** Length in meters. */
  length: number;
  /** The instances of this segment on the path. */
  instances: SegmentInstanceInfo[];
}

/**
 * Holds info about an instance of a segment on the path.
 */
interface SegmentInstanceInfo {
  /** Direction from alpha to beta as shown on the line view. */
  isLeftToRight: boolean;
  /** The offset along the path which corresponds to the alpha end of this segment. */
  alphaEndPathOffset: number;
}

/**
 * Holds rendering info about a label for the html template.
 */
interface LabelRenderingInfo {
  text: string;
  /** A percentage (along the path) which is applied to the 'left' property in the label's style. */
  style_left: number;
}

/**
 * Holds rendering info about the spotlight for the html template.
 */
interface SpotlightRenderingInfo {
  /**
   * A percentage (along the path) which is applied to the 'left' property in the spotlight's style.
   * Note that setting this to null before processing the spotlight target's position will force the spotlight to jump rather than animate.
   */
  style_left: number;
}

/**
 * Holds rendering info about a train for the html template.
 */
interface TrainRenderingInfo {
  name: string;
  /** Indicates whether the train is selected. */
  selected: boolean;
  /** Indicates whether the train is driven by a robot. */
  robot: boolean;
  /** Indicates whether the train is driven by a human. */
  human: boolean;
  /**
   * For each occurance of the segment that this train is on, this contains
   * a percentage (along the path) which is applied to the 'left' property in the train indicator's style.
   * Almost always a single element; should never be more than two.
   */
  style_left: number[];
}

/**
 * Helper for managing the animation of the spotlight's position.
 */
class SpotlightPositionAnimator {
  private readonly SPOTLIGHT_MOVE_ANIM_DURATION = 100;
  private spotlightAnimationId: number;
  private spotlightFirstFrameTime: number;

  constructor(private parent: LineViewComponent) {}

  /**
   * Starts an animation to move the spotlight (by updating its ```style_left``` property)
   * from the given initial position to the given target position.
   *
   * @param initialStyleLeft the starting value to use for the spotlight.
   * @param targetStyleLeft the value that the spotlight will be if the animation ends without interruption.
   */
  start(initialStyleLeft: number, targetStyleLeft: number): boolean {
    const delta = initialStyleLeft == null ? 0 : targetStyleLeft - initialStyleLeft;

    if (delta && Math.abs(delta) > 0.2) {
      // Ensure previously queued callbacks don't interfere.
      stop();

      const animate = (t: any): void => {
        const elapsed = Date.now() - this.spotlightFirstFrameTime;
        const animFraction = Math.min(elapsed / this.SPOTLIGHT_MOVE_ANIM_DURATION, 1);

        this.parent.spotlight = {style_left: initialStyleLeft + delta * animFraction};

        if (!this.parent.spotlightExpired && Math.abs(this.parent.spotlight.style_left - targetStyleLeft) > 0.2) {
          this.spotlightAnimationId = requestAnimationFrame(animate);
        }
      };

      if (!this.parent.spotlightExpired) {
        this.spotlightFirstFrameTime = Date.now();
        this.spotlightAnimationId = requestAnimationFrame(animate);
      }

      return true;
    }

    return false;
  }

  /**
   * Stops the animation.
   * There are no guaarantees about what the position of the spotlight will be at this point.
   */
  stop(): void {
    cancelAnimationFrame(this.spotlightAnimationId);
  }
}

export interface LineViewMapChildData extends MapChildData {
  features$: Observable<ObjectContainer[]>;
  trains$: Observable<UsefulTrain[]>;
}

/**
 * Renders a path through the train network in one dimension.
 * If you use this component dynamically, it's corresponding MapChildData datatype is LineViewMapChildData.
 */
@Component({
  selector: 'oksygen-line-view',
  templateUrl: './line-view.component.html',
  styleUrls: ['./line-view.component.scss']
})
export class LineViewComponent extends DynamicComponent<LineViewMapChildData, null> implements OnInit, OnDestroy {
  private readonly SPOTLIGHT_DURATION = 6000;

  private currentContext: MapContext;

  // Stored to simplify pipe logic
  private reachablePath: IReachablePath;
  private spotlitTrainId: number;

  // Internal state
  private dataSub: Subscription;
  private segmentsOnPath = new Map<number, SegmentInfo>();
  private spotlightUpdateTime: number;
  spotlightExpired: boolean;
  private spotlightPosAnim: SpotlightPositionAnimator;
  private stationWarningLogged = false;

  // Rendering data
  path: PathRenderingInfo;
  labels: Map<number, LabelRenderingInfo> = new Map();
  trains: Map<number, TrainRenderingInfo> = new Map();
  // Note that once the spotlight element is added it is not removed.
  // This is because of the way we manage animations;
  // we want to keep animation timing for appearing and disappearing encapsulated in the CSS,
  // so once the fade out is triggered, we have to leave the element live to allow the fade to occur.
  spotlight: SpotlightRenderingInfo;

  constructor(
    private contextSupplier: MapContextSupplier,
    private logger: Logging) {
    super();
  }

  ngOnInit(): void {
    this.spotlightPosAnim = new SpotlightPositionAnimator(this);

    // The following builds a chain of observables and processing callbacks.
    // Note that using filterTruthy() or filter(x => !!x) blows up the typing for some reason,
    // so we have to be careful of nullish values.
    // TODO handle corridor selection
    this.dataSub = this.contextSupplier.currentContext$().pipe(
      switchMap(context => {
        this.currentContext = context;

        if (context && isTrainObjectTrackAtlasManager(this.currentContext.map)) {

        const lineView = this.currentContext.map.getMapManager(MapType.LINE, LINE_VIEW_NAME);
        lineView.attachSourcesTo(null, this.dataSub);
        return this.currentContext.map.lineViewPathSubject.asObservable();
        } else {
          return of(null);
        }
      }),
      tap(path => {
        this.reachablePath = path;
        this.processPath(path);
      }),
      switchMap(x => isObjectDataMapContext(this.currentContext) ? this.currentContext.objects.data() : of([])),
      tap(objects => this.processObjects(objects)),
      switchMap(x => isTrainObjectTrackAtlasManager(this.currentContext?.map) ? this.currentContext.map.spotlitTrainSubject.asObservable() : of(null)),
      tap(spotlitTrain => this.processTrainSpotlight(spotlitTrain)),
      switchMap(x => isTrainObjectDataMapContext(this.currentContext) ? this.currentContext.trains.data() : of([])),
      throttleTime(500, asyncScheduler, {leading: true, trailing: true})
    )?.subscribe(trains => this.processTrains(trains));
  }

  ngOnDestroy(): void {
    this.dataSub?.unsubscribe();
  }

  /**
   * Processes a path (usually the path that the selected train is on) and prepares it for display in the view.
   *
   * @param path A path of connected segments.
   */
  private processPath(path: IReachablePath): void {
    this.segmentsOnPath.clear();
    this.labels.clear();

    // Clear all of this data, it's likely not to make much sense anymore (and it should be reconstructed shortly anyway).
    this.spotlightPosAnim.stop();
    this.spotlight = null;
    this.spotlitTrainId = null;
    this.trains.clear();

    if (!path) {
      this.path = undefined;
      return;
    }

    this.path = {length: path.pathLength, circular: path.circular};
    let prevLength = 0;

    for (const ps of path.pathSegments) {
      const segLength = ps.segment.length;
      const isLeftToRight = ps.isFromAlpha();

      const segInfo = computeIfAbsent(this.segmentsOnPath, ps.segment.id, id => ({id, length: segLength, instances: []}));
      segInfo.instances.push({
        isLeftToRight,
        alphaEndPathOffset: prevLength + (isLeftToRight ? 0 : segLength)
      });

      prevLength += segLength;
    }
  }

  /**
   * Finds Stations that appear on our path, and adds labels for them.
   *
   * @param featureContainers Features, possibly containing stations.
   */
  private processObjects(featureContainers: ObjectContainer[]): void {
    this.labels.clear();

    if (!featureContainers || !this.reachablePath) {
      return;
    }

    const segmentStations = new Map<number, Array<ObjectContainer>>();

    let stationAssocWarningLogged = this.stationWarningLogged;

    featureContainers.forEach(c => {
      // FIXME Use a constant for the feature types.
      if (c.objectType.name === 'Station') {
        if (!this.stationWarningLogged && c.trackAssociations.length === 0) {
          this.logger.warn(`"${c.name}" (${c.id}) is a Station without a track association, so it will not appear on the Line View.`);
          stationAssocWarningLogged = true;
        }

        c.trackAssociations.forEach(assoc => {
          if (this.segmentsOnPath.has(assoc.segmentId)) {
            computeIfAbsent(segmentStations, assoc.segmentId, k => [])
              .push(c);
          }
        });
      }
    });

    this.stationWarningLogged = stationAssocWarningLogged;

    let lid = 0;
    let totalLength = 0;

    for (const ps of this.reachablePath.pathSegments) {
      const stations = computeIfAbsent(segmentStations, ps.segment.id, k => [] as Array<ObjectContainer>);

      for (const s of stations) {
        for (const assoc of s.trackAssociations) {
          if (assoc.segmentId === ps.segment.id) {
            const offset = ps.isFromAlpha() ? assoc.offset : ps.segment.length - assoc.offset;
            this.labels.set(lid++, this.newLabelInfo(s.name, totalLength + offset));
          }
        }
      }

      totalLength += ps.segment.length;
    }
  }

  private newLabelInfo(text: string, offset: number): LabelRenderingInfo {
    return {text, style_left: 100 * offset / this.path.length};
  }

  /**
   * Updates the train spotlight ID and clears the spotlight if the new trains's ID is different.
   * Note that the spotlight position is updated in ```processTrains```.
   *
   * @param trains The spotlit train.
   */
  private processTrainSpotlight(train: UsefulTrain): void {
     if (!train) {
      // Just let the spotlight fade away naturally.
      return;
    }

    const stid = train?.id;

    // Force the spotlight to jump to the new destination rather than animating it.
    if (this.spotlightExpired) {
      this.spotlight = {style_left: null};
    }

    this.spotlitTrainId = stid;

    this.restartSpotlightTimer();
  }

  private restartSpotlightTimer(): void {
    this.spotlightUpdateTime = Date.now();
    this.spotlightExpired = false;

    setTimeout(() => {
      const elapsed = Date.now() - this.spotlightUpdateTime;
      this.spotlightExpired = elapsed > this.SPOTLIGHT_DURATION;
    }, this.SPOTLIGHT_DURATION + 50);
  }

  /**
   * Determines which trains are on the path and prepares redering data for them.
   *
   * @param trains The trains in the simulation.
   */
  private processTrains(trains: UsefulTrain[]): void {
    this.trains.clear();

    trains?.forEach(t => {
      let onPath = false;
      const pos = Array.isArray(t.vehicles) && t.vehicles.length > 0 ? t.vehicles[0].position : undefined;

      if (pos) {
        const segInfo = this.segmentsOnPath.get(pos.segmentId);

        if (segInfo) {
          onPath = true;
          this.trains.set(t.id, {
            selected: t.selected,
            name: t.name,
            robot: t.driverType === DriverType.ROBOT,
            human: t.driverType === DriverType.HUMAN,
            style_left: this.toStyleLeftValues(segInfo, pos.segmentOffset)
          });
        }
      }

      if (t.id === this.spotlitTrainId) {
        if (onPath) {
          const targetStyleLeft = this.trains.get(t.id).style_left[0];
          const spotStyleLeft = this.spotlight?.style_left;

          // If we already have a position for the spotlight, we need to animate it to its new position.
          // Otherwise, just snap to the new position.
          if (!this.spotlightPosAnim.start(spotStyleLeft, targetStyleLeft)) {
            this.spotlight = {style_left: targetStyleLeft};
          }
        } else {
          this.spotlight = null;
        }
      }
    });
  }

  private toStyleLeftValues(info: SegmentInfo, segOffset: number): number[] {
    return info.instances.map(instanceInfo => {
      const pathOffset = instanceInfo.alphaEndPathOffset + (instanceInfo.isLeftToRight ? segOffset : -segOffset);
      return 100 * pathOffset / this.path.length;
    });
  }
}
