/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { BannerComponent } from '@oksygen-common-libraries/material/components';
import { DragDropZoneHighlightComponent } from '@oksygen-sim-train-libraries/components-services/common';
import { MainMapChildData, MapContext } from '@oksygen-sim-train-libraries/components-services/maps';
import { configureSimTrainTestingModule, prepareMapServicesForTesting } from '@oksygen-sim-train-libraries/components-services/testing';
import { WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { PlanViewComponent } from './plan-view.component';

// FIXME Disabled due to intermittent failures deep within Mapbox. See INTOSC-7267
xdescribe('PlanViewComponent', () => {
  let component: PlanViewComponent;
  let fixture: ComponentFixture<PlanViewComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [BannerComponent],
      declarations: [PlanViewComponent, DragDropZoneHighlightComponent],
      providers: []
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanViewComponent);
    component = fixture.componentInstance;
    const data: MainMapChildData<MapContext> = {
      boundsPaddingPercentage: 1,
      images$: new Observable(obs => {
        obs.next([]);
        obs.complete();
      }),
      resize$: new Observable(obs => {
        obs.next(null);
        obs.complete();
      })
    };
    component.data = data;
    const mapControlService: any = null;
    const worldDefService = TestBed.inject(WorldDefinitionService);
    prepareMapServicesForTesting(mapControlService, worldDefService);

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
