/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectorRef, Component, ElementRef, NgZone, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { isEmpty, isNil } from 'lodash';
import { LngLatBounds } from 'maplibre-gl';
import { combineLatest, Observable, of } from 'rxjs';
import { delay, distinctUntilChanged, filter, startWith, switchMap, tap } from 'rxjs/operators';

import { filterTruthy, SuperCalled } from '@oksygen-common-libraries/common';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Logging } from '@oksygen-common-libraries/pio';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { Image, LoadingData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectTypeDataService, ObjectTypeName } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { MapContext, MapContextSupplier } from '../../contexts/map-context';
import { isObjectDataMapContext } from '../../contexts/object-data-map-context';
import { asSelectedGeoJSON, asSpotlitGeoJSON, getGeoJSONFeaturesFromSource, getMapGeoJSONSource } from '../../helpers/mapbox.source';
import { MapType, Selector } from '../../interfaces/atlas-managers/atlas-manager.interface';
import { isObjectTrackAtlasManager } from '../../interfaces/atlas-managers/object-track-atlas-manager.interface';
import { MapViewState } from '../../interfaces/map-component.interface';
import { isObjectTrackMapManager } from '../../interfaces/map-managers/object-track-map-manager.interface';
import { MainMapChildData, MainMapOutputData } from '../../models/main-map-child-data.model';
import { convertZoomLevel, ZoomLevel } from '../../models/map-view-info.model';
import { MapIOService } from '../../services/map-io.service';
import { MapBoxBounds } from '../../services/mapbox.bounds';
import { SELECTED_SOURCE_NAME } from '../../services/mapbox.layers';
import { PLAN_VIEW_NAME } from '../../services/plan-view/plan-view-object.manager';
import { OBJECTS_LAYER_NAME } from '../../services/source-layer-managers/objects/objects-layer-manager';
import { SPOTLIGHT_SOURCE_NAME } from '../../services/source-layer-managers/spotlight-layer-manager';
import { TRACK_SOURCE_NAME } from '../../services/source-layer-managers/track/track-source-manager';
import { AbstractMapViewComponent } from '../map-view/map-view.component';
import { getZoomForBounds } from '../map-view/map-view.helpers';

/**
 * Creates a new {@link MainMapChildData} based on the inputs.
 */
export function createPlanViewData(resize$: Observable<void>, images$: Observable<Image[]>, context?: MapContext): MainMapChildData {
  const data: MainMapChildData = {
    boundsPaddingPercentage: 0.65, // FIXME hardcoded
    resize$,
    images$,
    context
  };
  return data;
}

@Component({
  selector: 'oksygen-plan-view',
  templateUrl: '../map-view/map-view.component.html',
  styleUrls: ['../map-view/map-view.component.scss']
})
export class PlanViewComponent extends AbstractMapViewComponent<MainMapChildData<MapContext>, MainMapOutputData, MapContext> implements OnDestroy {
  override data: MainMapChildData<MapContext>;

  name = PLAN_VIEW_NAME;

  /** The bounds that was last used for determining the minimum zoom level. */
  private minZoomBounds: LngLatBounds;

  constructor(
    host: ElementRef,
    logger: Logging,
    mapIO: MapIOService,
    zone: NgZone,
    elRef: ElementRef,
    contextSupplier: MapContextSupplier,
    userService: UserService,
    router: Router,
    private cd: ChangeDetectorRef,
    private objectTypeDataService: ObjectTypeDataService,
    private translateService: TranslateService
  ) {
    super(host, logger, mapIO, zone, elRef, contextSupplier, userService, router);
  }

  override ngOnDestroy(): SuperCalled {
    this.context?.mapIo?.unbindMapEvents(this.MAP_DIV_ID);
    return super.ngOnDestroy();
  }

  protected getSelector(): Selector {
    return {
      type: MapType.PLAN,
      name: PLAN_VIEW_NAME
    };
  }

  protected override getLoadingModules(): Array<Observable<boolean>> {
    const defaultModules$ = super.getLoadingModules();
    return [...defaultModules$ /*, this.mapReadySubject.asObservable()*/];
  }

  protected override onMapStyleLoad(): SuperCalled {
    const imageLoadingModule: LoadingData = {
      icon: OksygenIcon.TEMPLATE,
      id: 'images',
      loaded: false, // don't need it
      name: '',
      obs: null // don't need it
    };
    this.backgroundLoading = [imageLoadingModule];
    const imagesPerBatch = 50;
    const delayBetweenBatchesMs = 150;
    this.subscription.add(
      this.data.images$
        .pipe(
          switchMap(images => this.mapManager.attachImagesTo(this.map, images, imagesPerBatch, delayBetweenBatchesMs)),
          tap(progress => {
            if (progress >= 1) {
              this.backgroundLoading = null;
            } else {
              const roundedProgress = Math.round((progress + Number.EPSILON) * 100); // EPSILON usage is to handle those weird floating point cases
              const translatedText = this.translateService.instant(t(`Loading images {progress}%`), { progress: roundedProgress });
              imageLoadingModule.name = translatedText;
            }
            this.cd.markForCheck();
          })
        )
        .subscribe()
    );

    this.loadWorldData();

    return super.onMapStyleLoad();
  }

  private loadWorldData(): void {
    this.subscription.add(
      this.objectTypeDataService
        .types$()
        .pipe(filterTruthy())
        .subscribe(d => {
          this.onObjectTypesLoaded();
        })
    );
  }

  private listenToSelectedDataUpdates(): void {
    this.subscription.add(
      this.currentContextTruthy$
        .pipe(
          switchMap(m => {
            if (isObjectTrackAtlasManager(m.map)) {
              return m.map.getSelectedObject();
            }

            return of(null);
          })
        )
        ?.subscribe(object => {
          const source = getMapGeoJSONSource(this.map, SELECTED_SOURCE_NAME);
          if (!source) {
            return;
          }
          if (isNil(object) || object.objectType.name === ObjectTypeName.POINT) {
            source.setData(asSelectedGeoJSON([]));
          } else {
            const selectedObjectGeoJson = asSelectedGeoJSON(object.location.lnglat);
            source.setData(selectedObjectGeoJson);
          }
        })
    );
  }

  private listenToSpotlitDataUpdates(): void {
    this.subscription.add(
      this.currentContextTruthy$
        .pipe(
          switchMap(m => {
            if (isObjectTrackAtlasManager(m.map)) {
              return m.map.spotlitObjectsSubject;
            }

            return of([]);
          })
        )
        ?.subscribe(objects => {
          if (!objects) {
            return;
          }
          const coords = objects.map(object => object.location.lnglat);
          const objectId = objects.length > 0 ? objects[0].id : undefined;
          const objectTypeId = objects.length > 0 && objects[0].objectType ? objects[0].objectType.id : undefined;
          const stateId = objects.length > 0 && objects[0].selectedState ? objects[0].selectedState.id : undefined;
          const spotlitObjectGeoJson = asSpotlitGeoJSON(coords, objectId, objectTypeId, stateId);
          getMapGeoJSONSource(this.map, SPOTLIGHT_SOURCE_NAME)?.setData(spotlitObjectGeoJson);
          this.map.setPaintProperty(OBJECTS_LAYER_NAME, 'icon-opacity', objects.length > 0 ? 0.4 : 1);
        })
    );
  }

  protected onObjectTypesLoaded(): void {
    const selector = this.getSelector();

    // Put ourselves in loading mode if the track changes.
    // This is fairly specific to the scenario editor, which is the only time we expect worlds to be switched.
    this.subscription.add(
      this.currentContextTruthy$
        .pipe(
          switchMap(ctx => ctx.world.world$),
          distinctUntilChanged((prev, curr) => prev?.name === curr?.name)
        )
        .subscribe(w => (this.loading = true))
    );

    this.subscription.add(
      combineLatest(
        this.currentContextTruthy$,
        this.currentContextTruthy$.pipe(switchMap(ctx => (isObjectDataMapContext(ctx) ? ctx.objects.data() : of(null)))),
        this.currentContextTruthy$.pipe(
          switchMap(ctx => ctx.map.getMapManager(selector.type, selector.name).geometrySourceUpdated$().pipe(startWith(undefined)))
        ),
        this.currentContextTruthy$.pipe( switchMap(ctx => ctx.world.world$), delay(500) )
      ).subscribe(([context, objects, x, world]) => {
        if (!isNil(world)) {
          if (isNil(world.segmentPolylines) || isEmpty(world.segmentPolylines)) {
            this.mapViewReadySubject.next(MapViewState.WORLD_DATA_EMPTY);
          }
        }

        const trackGeojson = getGeoJSONFeaturesFromSource(this.map, TRACK_SOURCE_NAME);
        const allGeoJSONObjects: Array<any> = [];

        if (isObjectTrackMapManager(this.mapManager)) {
          allGeoJSONObjects.push(...this.mapManager.getGeoJsonFeaturesFromSource(this.map));
        }

        if (!allGeoJSONObjects.length) {
          return;
        }

        this.mapBoxBounds = new MapBoxBounds(allGeoJSONObjects);

        // Now that we're starting to get data, we can get out of our loading state.
        if (trackGeojson.length > 0) {
          this.setMinZoom();
        }
      })
    );

    this.subscription.add(
      this.currentContextTruthy$
        .pipe(
          tap(m => m.map.getManager(selector).attachSourcesTo(this.map, this.subscription)),
          switchMap(m => combineLatest([of(m.mapIo), m.world.netDef$])),
          filter(([m, n]) => !!m && !!n)
        )
        .subscribe(([mapIo, netDef]) => mapIo.bindMapEvents(this.map, this.MAP_DIV_ID, netDef))
    );

    this.initListeners();
  }

  /**
   * Init all our app listeners. Ie, listen to vehicle updates, feature filters, point data etc.
   */
  private initListeners(): void {
    this.listenToSelectedDataUpdates();
    this.listenToPositionDataUpdates();
    this.listenToSpotlitDataUpdates();
    this.listenToResize();
  }

  private updateWorldBounds(): void {
    const objects: any[] = this.mapManager.updateWorldBounds(this.map);
    this.mapBoxBounds = objects?.length ? new MapBoxBounds(objects) : null;
  }

  /**
   * Sets the minimum zoom for the map, so the simulated world's area can fit in the view without lots of unnecessary padding.
   * Assumes the viewport size of the map is not going to change drastically over its lifetime.
   * Does nothing if it looks like we've already set an appropriate minimum zoom.
   * This will also set an initial (zoomed out) map position. This will get overwritten by the train position which is listening for this event to fire.
   *
   * **Warning**: the current implementation of this method:
   * * puts the map in the loading state until the operation is complete
   * * fires mapViewReadySubject when done
   */
  private setMinZoom(): void {
    // This convoluted nonsense helps us figure out how to limit our zoom level so the world isn't too small.
    // Unfortunately there doesn't seem to be a more straightforward way of leveraging the code in _cameraForBoxAndBearing in camera.js

    // Make sure we have an idea about how big the world is.
    this.updateWorldBounds();
    const currentWorldBounds = this.mapBoxBounds?.worldBounds;

    // Ensure that we're not updating this unnecessarily.
    if ((currentWorldBounds && !this.minZoomBounds) || !this.boundsMatch(currentWorldBounds, this.minZoomBounds)) {
      this.minZoomBounds = currentWorldBounds;
      // add some padding so there's some white space at the far extents
      const zoomPadding = 0.1;
      const zoomThatFitsWholeMap = getZoomForBounds(currentWorldBounds, this.map) - zoomPadding;
      // if map is tiny for some reason bound it to vehicle zoom level (18). IE if the map is just a single feature. Also make sure >= 0.
      const zoom = Math.max( Math.min( zoomThatFitsWholeMap, convertZoomLevel(0, ZoomLevel.VEHICLE) ), 0);
      this.map.setMinZoom(zoom);
      this.map.fitBounds(currentWorldBounds, {padding: 10, animate: false});
      this.setLoadingComplete();
      this.mapViewReadySubject.next(MapViewState.READY);
    }
  }

  private boundsMatch(b1: LngLatBounds, b2: LngLatBounds): boolean {
    return b1.getNorth() === b2.getNorth() && b1.getSouth() === b2.getSouth() && b1.getEast() === b2.getEast() && b1.getWest() === b2.getWest();
  }

  protected getStyleName(): string {
    return 'Plan View';
  }
}
