/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Feature, FeatureCollection, GeoJsonProperties } from 'geojson';
import { GeoJSONSource } from 'maplibre-gl';

import { DragFeedback } from '@oksygen-common-libraries/common';
import { BannerOption, BannerOptionType } from '@oksygen-common-libraries/material/components';
import { MaterialButtonVariant } from '@oksygen-common-libraries/material/theme';
import { isSegmentSceneryTrack, LngLatCoord, SegOffset } from '@oksygen-sim-core-libraries/data-types/common';
import { Path, PathEnd, PointState } from '@oksygen-sim-train-libraries/components-services/common';
import { SimObject } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { IAtlasMapComponent } from '../../interfaces/atlas-managers/atlas-manager.interface';
import { BannerController, isBannerController } from '../../interfaces/banner-controller.interface';
import { TrackSelectionHandler } from '../../interfaces/selection-handlers/selection-track.interface';
import { PATH_PREVIEW_SOURCE_NAME } from '../../services/source-layer-managers/track/track-path-layer-manager';
import { ChangeDetectorRef } from '@angular/core';

export interface MultipleInitialObjectStates {
  initialStates: { object: SimObject; stateName: string }[];
}

const DRAG_OK: DragFeedback = {
  allowed: true,
  message: ''
};

/**
 * Allows users to select a path through the track network.
 *
 * Interactions are loosely based on Google Maps. Users may:
 * * Click track to select a start point (must be done before other interactions are allowed)
 * * Click track to select an end point (converting the previous end point into a waypoint)
 * * Drag from within the path to create a waypoint
 * * Drag selected points to new locations
 * * Clear selected points by clicking them
 */
// There are some limitations in this class preventing single segment path selection.
// Eventually this will probably be required.
// The main complexity here is that we can't use the start/end segments as waypoints,
// so the automatic conversion of the end to a waypoint is more difficult than it otherwise would be.
// There's also a bit of undo history associated with end point selection, which also increases the complexity.
export class PathSelectionHandler implements TrackSelectionHandler {
  type: 'track';

  // Selected path info
  private startFromAlpha = false;
  private endFromAlpha = false;
  private innerPathSegIds: number[] = [];

  // Generated path info (includes previews)
  private pathValid = false;

  // Selections
  public start: SegOffset;
  /**
   * Stores selected waypoints.
   * We deliberately do not store multiple points per segment as this would be essentially redundant and make this class even more complicated.
   */
  private waypoints: Map<number, SegOffset> = new Map();
  public end: SegOffset;
  /**
   * Facilitates easily undoing the (often accidental) selection of a path-breaking end.
   * Without this, the user will be fighting against the "previous end automatically becomes a new waypoint" behaviour
   * whenever they add an end point in the wrong spot.
   *
   * If this proves inadequate, a full undo/redo stack will need to be maintained.
   */
  private previousEnd: SegOffset;
  /**
   * The point the user is hovering over, if any.
   * This point is treated as the end point during preview path renders.
   */
  private hoverPoint: SegOffset;

  // Dragging
  private draggedWaypointSegmentId: number;
  private draggedWaypointIsStart: boolean;
  private draggedWaypointIsEnd: boolean;
  private draggedWaypointUpdatedPos: SegOffset;

  // Banner Handling
  // I'm not sure this is necessary, this is just an interface for typescript to only have the "right" methods available.
  private bannerController: BannerController;

  private lockedPoints: SimObject[] = [];


  constructor(
    private getTrackSource: () => GeoJSONSource,
    private getPathSource: () => GeoJSONSource,
    private getPathPreviewSource: () => GeoJSONSource,
    private getSelectionsSource: () => GeoJSONSource,
    private network: NetworkDefinitionManager,
    private mapComponent: IAtlasMapComponent,
    private getObject: (id: number) => SimObject,
    private setPoints: (s: MultipleInitialObjectStates) => void,
    private pathPreviewColor: string,
    private invalidPathPreviewColor: string,
    private readonly cd: ChangeDetectorRef
  ) {
    if (isBannerController(mapComponent)) {
      this.bannerController = mapComponent;
    }
  }

  public enable(): void {
    // Called to initialise the output, particularly the banner.
    this.regeneratePath();
  }

  // Utils

  /**
   * @returns true if the point is within the selected path.
   */
  isPointWithinPath(point: SegOffset): boolean {
    // Simple test for waypoints
    let pointWithinPath = this.innerPathSegIds.includes(point.segmentId);

    // Extra checks for the start/end segment
    if (!pointWithinPath) {
      if (point.segmentId === this.start.segmentId) {
        pointWithinPath = this.startFromAlpha ? point.offset > this.start.offset : point.offset < this.start.offset;
      } else if (point.segmentId === this.end.segmentId) {
        pointWithinPath = this.endFromAlpha ? point.offset > this.end.offset : point.offset < this.end.offset;
      }
    }

    return pointWithinPath;
  }

  // User Interaction handlers

  onTrackHovered(point: SegOffset): void {
    this.hoverPoint = point;

    this.regeneratePath(true);
  }

  onTrackClicked(point: SegOffset): void {
    // If the track selected is a scenery track, we want to block the addition of the waypoint.
    // This is because we can't select a path through scenery tracks.
    if (isSegmentSceneryTrack(point.segmentId, this.network.worldData.segmentMap)) {
      return;
    }

    // When clicking on the track, we want to set the start point and then set the end point.
    // If there was already an end point, it becomes a waypoint.
    // Additional waypoints are added via drag interactions.

    // For proximity tests
    const delta = 20;

    // If we haven't set the start point, or we're clicking on its segment,
    // set the start point.
    if (!this.start || this.start.segmentId === point.segmentId) {
      this.start = point;
    }
    // If we haven't set the end point, or we're clicking on its segment,
    // set the end point.
    else if (!this.end || this.end.segmentId === point.segmentId) {
      // Only count "big" moves as undoable updates
      if (this.end && Math.abs(point.offset - this.end.offset) > delta) {
        this.previousEnd = this.end;
      }

      this.end = point;
    }
    // If we're clicking outside of the current path
    // retain the end as a waypoint and set this point as the new end.
    else if (!this.innerPathSegIds.includes(point.segmentId) && this.end.segmentId !== point.segmentId) {
      // Prevent adding an endpoint where we've got a waypoint.
      // We do this because we'll get a track clicked callback immediately before a selection clicked callback,
      // and setting the endpoint to where a waypoint is going to be removed is really user hostile.
      if (!this.waypoints.has(point.segmentId) || Math.abs(point.offset - this.waypoints.get(point.segmentId).offset) > delta) {
        this.addWaypoint(this.end);
        this.removeWaypoint(point);
        this.previousEnd = this.end;
        this.end = point;
      }
    }

    this.regeneratePath();
    this.updateWidgets();
  }

  onTrackDown(point: SegOffset): boolean {
    // Bail if we haven't got minimal path selection data.
    if (!this.start || !this.end) {
      return false;
    }

    // Allow waypoints to be created by dragging from anywhere within the path.
    // Ignore dragging that starts outside of the currently selected path.
    if (this.isPointWithinPath(point)) {
      this.startDrag(point);
      return true;
    }

    return false;
  }

  onTrackDragged(point: SegOffset): DragFeedback {
    this.onDrag(point);
    this.regeneratePath(true);
    return DRAG_OK;
  }

  onTrackUp(point: SegOffset): void {
    this.finaliseDrag(point);
  }

  onSelectedClicked(point: SegOffset): void {
    if (this.end && this.end.segmentId === point.segmentId) {
      // Avoid having no end when waypoints are around.
      // Restore the previous end point, if one is known.
      if (this.previousEnd || this.waypoints.size === 0) {
        this.end = this.previousEnd;
        this.removeWaypoint(this.end);
      }
      this.previousEnd = undefined;
    }
    // Remove waypoints before the start
    else if (this.waypoints.size > 0) {
      this.removeWaypoint(point);
    } else if (this.start) {
      if (this.start.segmentId === point.segmentId) {
        this.start = undefined;
      }
    }

    this.regeneratePath();
    this.updateWidgets();
  }

  onSelectedDown(point: SegOffset): boolean {
    this.startDrag(point);
    // Always allow dragging of selected points
    return true;
  }

  onSelectedDragged(point: SegOffset): DragFeedback {
    this.onDrag(point);
    return DRAG_OK;
  }

  onSelectedUp(point: SegOffset): void {
    this.finaliseDrag(point);
  }

  // Path selection updaters

  /**
   * Adds a waypoint and updates widgets.
   * Does not trigger path regeneration.
   */
  private addWaypoint(point: SegOffset): void {
    if (point) {
      this.waypoints.set(point.segmentId, point);
      this.updateWidgets();
    }
  }

  /**
   * Removes a waypoint and updates widgets.
   * Does not trigger path regeneration.
   */
  removeWaypoint(point: SegOffset): void {
    if (point) {
      this.waypoints.delete(point.segmentId);
      this.updateWidgets();
    }
  }

  /**
   * Common drag initiation handler.
   *
   * @param point The point being dragged. This may be an existing waypoint or an arbitrary point on the path (which will become a waypoint).
   */
  private startDrag(point: SegOffset): void {
    this.draggedWaypointSegmentId = point.segmentId;
    this.draggedWaypointIsStart = point.segmentId === this.start?.segmentId;
    this.draggedWaypointIsEnd = point.segmentId === this.end?.segmentId;
  }

  /**
   * Common drag handler.
   */
  private onDrag(point: SegOffset): void {
    if (point) {
      // You cannot drag a point on a scenery track.
      if (isSegmentSceneryTrack(point.segmentId, this.network.worldData.segmentMap)) {
        return;
      }

      if (this.draggedWaypointIsStart) {
        // Prevent dragging onto the same segment as the end
        if (this.end?.segmentId !== point.segmentId) {
          this.start = point;
        }
      } else if (this.draggedWaypointIsEnd) {
        // Prevent dragging onto the same segment as the start
        if (this.start.segmentId !== point.segmentId) {
          this.end = point;
        }
      } else {
        // Dragging internal waypoints onto the start/end segments is a bit tricky to handle.
        // Ignore until we decide what we want to happen here.
        if (point.segmentId === this.start.segmentId || point.segmentId === this.end.segmentId) {
          return;
        }
        this.draggedWaypointUpdatedPos = point;
      }

      this.regeneratePath(true);
      this.updateWidgets();
    }
  }

  /**
   * Common drag completion handler.
   */
  private finaliseDrag(point: SegOffset): void {
    this.onDrag(point);

    // Check if we moved the waypoint from its starting segment.
    // If so, delete the original waypoint.
    if (this.draggedWaypointSegmentId && this.draggedWaypointUpdatedPos && this.draggedWaypointUpdatedPos.segmentId !== this.draggedWaypointSegmentId) {
      this.waypoints.delete(this.draggedWaypointSegmentId);
    }

    if (!this.draggedWaypointIsStart && !this.draggedWaypointIsEnd) {
      // Note that this will stomp on any existing wayoints on this segment; that's fine (see the docco of this.waypoints).
      this.addWaypoint(this.draggedWaypointUpdatedPos);
    } else {
      // Nuke any redundant waypoints
      this.removeWaypoint(this.start);
      this.removeWaypoint(this.end);
    }

    this.draggedWaypointSegmentId = undefined;
    this.draggedWaypointUpdatedPos = undefined;
    this.draggedWaypointIsStart = false;
    this.draggedWaypointIsEnd = false;

    this.regeneratePath();
    this.updateWidgets();
  }

  /**
   * Updates the path displayed to the user on the map.
   *
   * @param preview Indicates if this method should generate a path for previewing a potential selection.
   */
  private regeneratePath(preview = false): void {
    const activeWaypointSegIds = new Array<number>();

    this.waypoints.forEach((p, segId, m) => {
      // Exclude the old position of the waypoint being dragged (if any)
      if (!preview || segId !== this.draggedWaypointSegmentId) {
        activeWaypointSegIds.push(segId);
      }
    });

    let endPoint = this.end;

    if (preview) {
      // Include the the waypoint being dragged (if any).
      // Note that this will not contain start/end position; these are updated instantly.
      if (this.draggedWaypointUpdatedPos) {
        activeWaypointSegIds.push(this.draggedWaypointUpdatedPos.segmentId);
      }
      // Otherwise show the user what the path would look like if the hovered point were to be added.
      else if (!this.draggedWaypointIsEnd && !this.draggedWaypointIsStart && this.hoverPoint) {
        if (this.end && this.hoverPoint.segmentId !== this.end.segmentId) {
          activeWaypointSegIds.push(this.end.segmentId);
        }
        if (isSegmentSceneryTrack(this.hoverPoint.segmentId, this.network.worldData.segmentMap) || this.lockedPoints.length > 0) {
          this.mapComponent.map.setPaintProperty(PATH_PREVIEW_SOURCE_NAME, 'line-color', this.invalidPathPreviewColor);
        } else {
          this.mapComponent.map.setPaintProperty(PATH_PREVIEW_SOURCE_NAME, 'line-color', this.pathPreviewColor);
        }

        endPoint = this.hoverPoint;
      }
    }

    // PATH DRAWING
    const pathSource = preview ? this.getPathPreviewSource() : this.getPathSource();
    const trackSource = this.getTrackSource();

    // Purge cached info, which will be populated based on the path generated using the current state.
    if (!preview) {
      this.innerPathSegIds = [];
    }

    const features: any[] = [];

    let path: Path;
    let lockedPointsHtml = '';
    if (this.start && endPoint) {
      // Handle the simple case of start and end on a single segment.
      if (activeWaypointSegIds.length === 0 && this.start.segmentId === endPoint.segmentId) {
        features.push(
          this.polylineToGeoJSONFeature(
            this.start.segmentId,
            this.network.createSegmentPolylineFragment(this.start.segmentId, this.start.offset, endPoint.offset)
          )
        );
      } else {
        const newPath = this.network.findPath(this.segOffsetToPathEnd(this.start), activeWaypointSegIds, this.segOffsetToPathEnd(endPoint));
        path = newPath;
        this.pathValid = !!newPath?.hasPath;

        if (this.pathValid) {
          const newPathSegIds: number[] = newPath.innerSegments.map(s => s.segmentId);

          features.push(this.pathEndToGeoJSONFeature(newPath.start, !newPath.start.fromAlpha));
          features.push(this.pathEndToGeoJSONFeature(newPath.end, newPath.end.fromAlpha));

          //eslint-disable-next-line no-underscore-dangle
          ((trackSource as any)._data.features as Feature[]).forEach((f, i, a) => {
            if (newPathSegIds.includes(f.properties.segmentId)) {
              features.push(f);
            }
          });

          this.lockedPoints = [];
          path.pointSettings.forEach(ps => {
            const stateName =
              ps.pointState.value === PointState.MAIN_LINE ? 'Main Line' : ps.pointState.value === PointState.BRANCH_LINE ? 'Branch Line' : undefined;
            const pointSetting = this.getObject(ps.id);
            if (pointSetting.properties?.Locked && stateName !== pointSetting.selectedState.name) {
              this.lockedPoints.push(pointSetting);
            }
          });

          if (this.lockedPoints.length > 0) {
            this.mapComponent.map.setPaintProperty(PATH_PREVIEW_SOURCE_NAME, 'line-color', this.invalidPathPreviewColor);

            lockedPointsHtml +=
              '<div style="border-radius: 4px; border: 1px solid var(--warning-border-color);' +
              'background: var(--warning-background-color); color: var(--warning-color); padding: 10px;">';

            lockedPointsHtml += '<div style="align-items: center; display: flex;"><span class="material-icons">exclamation_triangle_alt</span>';
            lockedPointsHtml += '<span style ="padding-left: 5px"> Cannot set path due to Points with locked states: </span></div>';
            lockedPointsHtml += '<div style=" padding-left: 33px; ; padding-top: 10px"><b>';

            for (let i = 0; i < this.lockedPoints.length && i < 30; i++) {
              lockedPointsHtml += `${this.lockedPoints[i].name},`;
            }

            if (this.lockedPoints.length > 30) {
              lockedPointsHtml += '...';
            }

            lockedPointsHtml = lockedPointsHtml.slice(0, -1);
            lockedPointsHtml += '</b></div></div>';
          } else {
            lockedPointsHtml = '';
            this.mapComponent.map.setPaintProperty(PATH_PREVIEW_SOURCE_NAME, 'line-color', this.pathPreviewColor);
          }
          // Cache important info about our current selection.
          if (!preview) {
            this.startFromAlpha = newPath.start.fromAlpha;
            this.endFromAlpha = newPath.end.fromAlpha;
            this.innerPathSegIds = newPathSegIds;
          }
        }
      }
    }

    // Update banner feedback.
    if (!preview) {
      if (!this.start) {
        this.bannerController.showBanner({ content: t('Select a Start position for your Path.') });
      } else if (!this.end) {
        this.bannerController.showBanner({ content: t('Select a Destination position for your Path.') });
      } else if (features.length > 0) {
        // This used to also say:
        // "Select a position to set a new Destination. Drag the Path to change the lines it uses."
        // but the banner would then often get obscured by the toolbox.
        // Might be worth putting this prompt somewhere if possible, or reinstating it if we change how the laoyout interacts.
        const bannerOptions: BannerOption[] = [
          { type: BannerOptionType.TEXT, text: t('A Path is selected.') },
          { type: BannerOptionType.BUTTON, text: t('Clear selections'), style: MaterialButtonVariant.BUTTON, callback: (): void => this.clear() },
          {
            type: BannerOptionType.BUTTON,
            text: t('Set points'),
            disabled: this.lockedPoints.length > 0,
            callback: (): void => {
              const pointsSettings: MultipleInitialObjectStates = { initialStates: [] };

              path.pointSettings.forEach(ps => {
                const stateName =
                  ps.pointState.value === PointState.MAIN_LINE ? 'Main Line' : ps.pointState.value === PointState.BRANCH_LINE ? 'Branch Line' : undefined;
                if (stateName) {
                  pointsSettings.initialStates.push({ object: this.getObject(ps.id), stateName });
                }
              });

              this.setPoints(pointsSettings);
            }
          }
        ];

        if  (this.lockedPoints.length > 0) {
          bannerOptions.push({ type: BannerOptionType.LINE_BREAK });
          bannerOptions.push({ type: BannerOptionType.TEXT, html: lockedPointsHtml });
        }

        this.bannerController.showBanner({
          options: bannerOptions
        });
      } else {
        this.bannerController.showBanner({
          content: t('Cannot find a path through the given points.'),
          options: [{ type: BannerOptionType.BUTTON, text: t('Clear selections'), callback: (): void => this.clear() }]
        });
      }
    }

    pathSource.setData({
      type: 'FeatureCollection',
      features
    });
    setTimeout(() => this.cd.markForCheck(), 1);
  }

  private segOffsetToPathEnd(so: SegOffset): PathEnd {
    return {
      ...so,
      // Unused, but declared in the wasm code :(
      fromAlpha: true
    };
  }

  /**
   * Generates a GeoJSON object for the portion of a segment that is on the given path.
   *
   * @param end indicates segment/offset of interest.
   * @param includeAlpha Whether the line should include the alpha end of the segment.
   */
  private pathEndToGeoJSONFeature(end: PathEnd, includeAlpha: boolean): GeoJsonProperties {
    // Figure out the offsets to generate the desired polyline.
    const alphaOffset = includeAlpha ? 0 : end.offset;
    const betaOffset = includeAlpha ? end.offset : this.network.worldData.segmentMap.get(end.segmentId).length;

    return this.polylineToGeoJSONFeature(end.segmentId, this.network.createSegmentPolylineFragment(end.segmentId, alphaOffset, betaOffset));
  }

  /**
   * Creates a GeoJSON object for part of a segment.
   *
   * @param segmentId ID of the segment that this is part of.
   * @param polyline The polyline that covers part of the segment.
   */
  private polylineToGeoJSONFeature(segmentId: number, polyline: LngLatCoord[]): GeoJsonProperties {
    return {
      type: 'Feature',
      id: 'path',
      properties: {
        segmentId
      },
      geometry: {
        type: 'MultiLineString',
        coordinates: [polyline]
      }
    };
  }

  /**
   * Updates the widgets showing the selected start, end and waypoints on the map.
   */
  updateWidgets(): void {
    const selectonsSource = this.getSelectionsSource();
    const features: any[] = [];

    // Note that the selected points are added in a particular order to ensure approriate z-ordering in the view.

    this.waypoints.forEach((p, segId, m) => {
      if (this.draggedWaypointSegmentId !== segId) {
        features.push(this.segOffsetToGeoJSONFeature(p, 'waypoint', this.pathValid, false));
      }
    });

    if (this.end) {
      features.push(this.segOffsetToGeoJSONFeature(this.end, 'end', this.pathValid, this.draggedWaypointIsEnd));
    }

    if (this.start) {
      features.push(this.segOffsetToGeoJSONFeature(this.start, 'start', this.pathValid || !this.end, this.draggedWaypointIsStart));
    }

    if (this.draggedWaypointUpdatedPos) {
      features.push(this.segOffsetToGeoJSONFeature(this.draggedWaypointUpdatedPos, 'waypoint', this.pathValid, true));
    }

    const data: FeatureCollection = {
      type: 'FeatureCollection',
      features
    };

    selectonsSource.setData(data);
  }

  /**
   * Creates a GeoJSON feature for a selected point.
   *
   * @param segmentOffset The selected point.
   * @param type The type of point.
   * @param isValid Whether the path is valid.
   * @param isDrag Whether this point is being dragged.
   */
  private segOffsetToGeoJSONFeature(segmentOffset: SegOffset, type: 'start' | 'waypoint' | 'end', isValid: boolean, isDrag: boolean): GeoJsonProperties {
    return {
      type: 'Feature',
      id: -1,
      properties: {
        isStart: type === 'start',
        isWaypoint: type === 'waypoint',
        isEnd: type === 'end',
        isValid,
        isDrag,
        segmentId: segmentOffset.segmentId
      },
      geometry: {
        type: 'Point',
        coordinates: this.network.segmentOffsetToLngLat(segmentOffset.segmentId, segmentOffset.offset)
      }
    };
  }

  /**
   * Clears all selections.
   */
  public clear(): void {
    this.start = null;
    this.end = null;
    this.waypoints.clear();
    this.regeneratePath(true);
    this.regeneratePath(false);
    this.updateWidgets();
  }

  /**
   * Clears selections and removes visual feedback in preparation for the selection mode to change.
   * If this isn't done, stale feedback may remain visible, which is highy undesirable.
   */
  public disable(): void {
    this.clear();
    this.bannerController.hideBanner();
  }
}
