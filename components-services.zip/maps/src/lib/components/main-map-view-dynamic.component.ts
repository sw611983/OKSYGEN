/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Map } from 'maplibre-gl';

import { DynamicComponent, OutputDataModel } from '@oksygen-common-libraries/material/components';

import { MainMapChildData } from '../models/main-map-child-data.model';

export abstract class MainMapViewDynamicComponent<D extends MainMapChildData, O extends OutputDataModel> extends DynamicComponent<D, O> {
  public map: Map;
}
