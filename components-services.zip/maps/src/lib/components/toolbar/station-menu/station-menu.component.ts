/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectionStrategy, Component, ElementRef, EventEmitter, Input, OnDestroy, Output, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Subscription } from 'rxjs';

import { Sorter } from '@oksygen-common-libraries/material/components';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

@Component({
  selector: 'oksygen-station-menu',
  templateUrl: './station-menu.component.html',
  styleUrls: ['./station-menu.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StationMenuComponent implements OnDestroy {
  // Used for auto focusing
  @ViewChild('stationSearch') stationSearchField: ElementRef;

  @Input() stations: ObjectContainer[];
  @Input() stationsDisabled = false;
  @Output() readonly station: EventEmitter<ObjectContainer> = new EventEmitter<ObjectContainer>();
  selectedStation: ObjectContainer;
  stationSorter = new Sorter<ObjectContainer>();
  private masterSubscription: Subscription = new Subscription();


  constructor(
    public dialog: MatDialog,
    private readonly translateService: TranslateService
  ) {
    this.stationSorter.sortFunction = (c, a, b): number => a.name.localeCompare(b.name, this.translateService.currentLocaleString);
  }

  ngOnDestroy(): void {
    this.masterSubscription?.unsubscribe();
  }

  selectStation(station: ObjectContainer): void {
    this.selectedStation = station;
    this.station.emit(this.selectedStation);
  }

  sortStations(event: Event): void {
    this.stationSorter.toggleSort();
    event.stopPropagation();
  }

  stationSearchableText(station: ObjectContainer): string[] {
    return [station.name.toString()];
  }

  focusOnStationSearch(): void {
    this.stationSearchField.nativeElement.focus();
  }

}
