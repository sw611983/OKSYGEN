/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { without } from 'lodash';

import { Orientation, PointInfo, Segment, SegmentConnection, SegOriented } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectId } from '@oksygen-sim-core-libraries/data-types/objects';
import {
  IReachablePath,
  ReachablePath,
  ReachablePathFinderBase,
  ReachablePathSegment
} from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer, ObjectType } from '@oksygen-sim-train-libraries/components-services/objects/data';

/**
 * Determines "reachable" paths through a track network,
 * which are paths for which points are set (or traversable) and
 * are created by scanning from some starting location(s) (typically a train's ends).
 *
 * Paths are flagged as circular if the two "ends" of the path connect.
 * Currently there is no information provided about circles within the path (i.e. P-shaped paths),
 * apart from the loop flag being set.
 * In that case, once the train is entirely within the inner circle
 * the next path refresh will generate a circular path without the run-in segment(s),
 * since those will no longer be reachable.
 *
 * Paths are ordered in the direction of travel.
 * The segment at [0] is either behind the train or where the last car is,
 * and the segment at [pathSegments.length] is either in front of the train or where the lead car is.
 */
export class ReachablePathFinder extends ReachablePathFinderBase {

  constructor(private readonly pointsType: ObjectType, private readonly getObject: (id: number) => ObjectContainer) {
    super();
    if (!pointsType) throw Error('Points type is required!');
    if (!getObject) throw Error('getObject is required!');
  }

  /**
   * Determines the path for the given train,
   * which is a collection of reachable segments extending from either end of the train
   * (and the segments it occupies).
   *
   * The lead and rear cars should be coupled;
   * any disconnected cars should be ignored for the purposes of path generation.
   * Car positions should be given in terms of bogies at the extremeties of the set of connected cars;
   * using the position of the "front" of a car can give incorrect results with spring points
   * and other corner cases.
   *
   * Note that if you require a "live" path, this method should be called when:
   * * the lead or rear cars' bogies change segments
   * * the default direction of the train changes (i.e. the lead and rear cars swap)
   * * any of the pathChangePoints change state
   */
  scanPath(segOriented: SegOriented): Readonly<IReachablePath> {
    const position = this.toSegOffsetOriented(segOriented);

    if (!position) throw Error('Need a starting position!');

    const newPath = new ReachablePath();

    if (position) {
      // Add all segments in front of the lead car
      this.addReachableSegments(
        newPath,
        newPath.pathSegments,
        newPath.pathChangePoints,
        newPath.pathObjects,
        this.worldData.segmentMap.get(position.segmentId),
        true,
        null,
        position.orientation === Orientation.ALPHA_TO_BETA,
        true
      );

      // Check if the path is circular
      // Note that being circular is a particular form of looping
      // which is distinct from the path simply traversing the same segment twice.
      if (newPath.loop && newPath.pathSegments.length > 0) {
        const first = newPath.pathSegments[0];
        const last = newPath.pathSegments[newPath.pathSegments.length - 1];

        const c = this.getActiveConnectionFrom(last.segment, !last.isFromAlpha());

        if (c && c.toSegmentId === first.segment.id && c.toAlpha === first.isFromAlpha()) {
          newPath.circular = true;
        }
      }

      // Now that we've figured out what's on the path and in what order,
      // we can do any additional housekeeping to prepare it for consumption.

      newPath.pathLength = this.lengthOf(newPath.pathSegments);

      // Rebalance circular paths to have some trailing segments, which helps avoid jumpy updates in the linear view
      if (newPath.circular) {
        let upcomingPathLength = 0;
        const upcomingPathLengthLimit = (newPath.pathLength * 2) / 3;
        let leadCarSegIndex = null;
        let leftmostSegmentIndex = null;

        // Loop through the path (up to) twice to:
        // 1: find the segment that the lead car is on
        // 2: figure out the index of the segemtn we want to appear on the left of the view
        while (leftmostSegmentIndex === null) {
          for (let i = 0; i < newPath.pathSegments.length; ++i) {
            const ps = newPath.pathSegments[i];

            // Corner case:
            // If we encounter the lead car's path segment a second time, we need to stop looking.
            if (i === leadCarSegIndex) {
              leftmostSegmentIndex = leadCarSegIndex;
              break;
            }

            if (leadCarSegIndex === null) {
              // Check if this is path segment with the car on it.
              // Note that the segment ID is not enough, as we may traverse the same segment in the other direction on this path.
              if (ps.segment.id === position.segmentId && ps.direction === position.orientation) {
                leadCarSegIndex = i;
              }
            }

            // Sum the lengths of the segments ahead of the train (including the segment the lead car is on)
            if (leadCarSegIndex !== null) {
              upcomingPathLength += ps.segment.length;
            }

            // Once we reach the maximum length, we want the current segment to be the rightmost in the view.
            // Therefore, the segment that follows it should be the leftmost.
            // Setting this will break out of these processing loops.
            if (upcomingPathLength > upcomingPathLengthLimit) {
              leftmostSegmentIndex = i + 1;

              // In case the leftmost segment is in fact at index 0...
              if (leftmostSegmentIndex >= newPath.pathSegments.length) {
                leftmostSegmentIndex = 0;
              }

              break;
            }
          }
        }

        if (leftmostSegmentIndex > 0) {
          // Rotate the path to put the item at leftmostSegmentIndex into index 0.
          const removed = newPath.pathSegments.splice(leftmostSegmentIndex, newPath.pathSegments.length - leftmostSegmentIndex);
          newPath.pathSegments.push(...removed);
        }
      }
    }

    newPath.pathSegments.forEach(ps => newPath.pathSegmentMap.set(ps.segment.id, ps.segment));

    newPath.nonPathSegments = without(Array.from(this.worldData.segmentMap.keys()), ...newPath.pathSegments.map((ps, i, a) => ps.segment.id)).map(s =>
      this.worldData.segmentMap.get(s)
    );

    return Object.freeze(newPath);
  }

  /**
   * Helper function to recursively find segments and points we can see.
   *
   * @param segments A set of segments we can see.
   * @param changePoints A set of points which may result in a change to
   *    the path if the point's state changes.
   * @param refSegment The start segment.
   * @param includeRefSegment Flag indicating if we should add the refSegment to the segments.
   * @param abortSegment A ReachablePathSegment that will terminate the search. Encountering this does not trigger any loop detection.
   * The refSegment is not compared to the abortSegment at the start of the search.
   * @param alphaToBeta Direction of interest.
   * @param upcoming true if we're looking at upcoming segments, false for trailing segments
   */
  protected addReachableSegments(
    newPath: ReachablePath,
    segments: Array<ReachablePathSegment>,
    changePoints: Map<number, PointInfo>,
    objects: Map<number, Array<ObjectId>>,
    refSegment: Segment,
    includeRefSegment: boolean,
    abortSegment: ReachablePathSegment,
    alphaToBeta: boolean,
    upcoming: boolean
  ): void {
    if (refSegment) {
      if (includeRefSegment) {
        segments.splice(upcoming ? segments.length : 0, 0, new ReachablePathSegment(refSegment, this.toOrientation(alphaToBeta)));

        if (this.pathContainsSegmentPrivate(segments, refSegment.id)) {
          newPath.loop = true;
        }
      }

      // find all segments that we can get to from this one
      const fromAlpha: SegmentConnection = this.getActiveConnectionFrom(refSegment, true);
      const fromBeta: SegmentConnection = this.getActiveConnectionFrom(refSegment, false);

      let nextSegment: Segment;

      if (alphaToBeta) {
        if (fromBeta) {
          nextSegment = this.worldData.segmentMap.get(fromBeta.toSegmentId);
        }
      } else {
        if (fromAlpha) {
          nextSegment = this.worldData.segmentMap.get(fromAlpha.toSegmentId);
        }
      }

      if (nextSegment) {
        this.addReachableSegments2(newPath, segments, changePoints, objects, nextSegment, refSegment, abortSegment, upcoming);
      }

      // this.addFeaturesOnSegmentInDirection(features, startSegment, alphaToBeta);
      this.addChangePoints(changePoints, refSegment);
    }
  }

  /**
   * Helper function to recursively find segments and points we can see.
   *
   * @param segments A set of segments we can see.
   * @param changePoints A set of points which may result in a change to
   *    the path if the point's state changes.
   * @param currentSegment The segment to look at.
   * @param prevSegment The segment we came from.
   * @param abortSegment A ReachablePathSegment that will terminate the search. Encountering this does not trigger any loop detection.
   * @param upcoming true if we're looking at upcoming segments, false for trailing segments
   */
  protected addReachableSegments2(
    newPath: ReachablePath,
    segments: Array<ReachablePathSegment>,
    changePoints: Map<number, PointInfo>,
    objects: Map<number, Array<ObjectId>>,
    currentSegment: Segment,
    prevSegment: Segment,
    abortSegment: ReachablePathSegment,
    upcoming: boolean
  ): void {
    if (currentSegment) {
      if (this.pathContainsSegmentPrivate(segments, currentSegment.id)) {
        newPath.loop = true;
      }

      // find all segments that we can get to from this one
      const fromAlpha: SegmentConnection = this.getActiveConnectionFrom(currentSegment, true);
      const fromBeta: SegmentConnection = this.getActiveConnectionFrom(currentSegment, false);

      // The direction and next connection will be determined based on where we came from
      let alphaToBeta = false;
      let nextConnection: SegmentConnection;

      // Determine the direction of travel on this segment and prepare to add it to the path.
      let newPS: ReachablePathSegment;
      let index: number;

      // We have slightly different logic for looking at upcoming or trailing track
      if (upcoming) {
        alphaToBeta = this.connectsToPrev(currentSegment, true, prevSegment);
        nextConnection = alphaToBeta ? fromBeta : fromAlpha;
        newPS = new ReachablePathSegment(currentSegment, this.toOrientation(alphaToBeta));
        index = segments.length;
      } else {
        alphaToBeta = this.connectsToPrev(currentSegment, false, prevSegment);
        nextConnection = alphaToBeta ? fromAlpha : fromBeta;
        newPS = new ReachablePathSegment(currentSegment, this.toOrientation(alphaToBeta));
        index = 0;
      }

      if (newPS.equals(abortSegment)) {
        return;
      }

      // Check for any duplicate ReachablePathSegments and stop recursing if we find one.
      if (!this.pathContainsReachablePathSegment(segments, newPS)) {
        segments.splice(index, 0, newPS);

        // this.addFeaturesOnSegmentInDirection(features, currentSegment, alphaToBeta);
        this.addChangePoints(changePoints, currentSegment);

        if (nextConnection) {
          const nextSegment = this.worldData.segmentMap.get(nextConnection.toSegmentId);
          this.addReachableSegments2(newPath, segments, changePoints, objects, nextSegment, currentSegment, abortSegment, upcoming);
        }
      }
    }
  }

  protected getActiveConnectionFrom(segment: Segment, fromAlpha: boolean): SegmentConnection {
    // Check for permanent connections first, as they are straightforward
    for (const c of Array.from(segment.connections.values())) {
      if (c.fromSegmentId === segment.id && c.fromAlpha === fromAlpha) {
        if (c.alwaysActive) {
          return c;
        }
      }
    }

    // Find connections that are activated by points
    for (const pid of Array.from(segment.pointIds.values())) {
      // TODO subscribe and drive updates from callbacks
      const model = this.getObject(pid);
      if (!model) {
        continue;
      }
      const state = this.pointsType.states.get(model.selectedState.id);
      if (!state) {
        continue;
      }
      const conns = this.worldData.pointMap.get(pid).stateActiveConnections.get(state.name);
      if (conns) {
        for (const c of conns) {
          if (c.fromSegmentId === segment.id && c.fromAlpha === fromAlpha) {
            return c;
          }
        }
      }
    }

    return null;
  }
}
