/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Feature, FeatureCollection } from 'geojson';
import { Observable, Subscription } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { SynopticCorridor, WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { AbstractTrackSourceManager } from '../source-layer-managers/track/track-source-manager';
import { SourceManagerConfiguration } from '../mapbox.layers';

export interface SynopticTrackSourceManagerConfiguration extends SourceManagerConfiguration {
  worldName: string;
  selectedCorridorName$: Observable<string>;
}

/**
 * Manages Mapbox Sources for rendering tracks.
 */
export class SynopticTrackSourceManager extends AbstractTrackSourceManager<SynopticTrackSourceManagerConfiguration> {
  private corridorSubscription: Subscription;

  constructor(private synopticDefinitionService: WorldDefinitionService, configuration: SynopticTrackSourceManagerConfiguration) {
    super(configuration);

    this.corridorSubscription = this.configuration.selectedCorridorName$.subscribe(cn => {
      if (cn) {
        this.synopticDefinitionService.getSynopticCorridor(this.configuration.worldName, cn).then(corridor => {
          this.geoJSONSource.next(this.formatAsGeoJson(corridor));
        });
      }
    });
  }

  /**
   * Format the segment data in the corridor as GeoJson.
   * Roughly a copy of AbstractTrackSourceManager.createTrackGeoJSON, but using the different
   * datatypes from the SynopticViewData.
   *
   * @param synopticCorridor
   */
  private formatAsGeoJson(synopticCorridor: SynopticCorridor): FeatureCollection {
    const features = new Array<Feature>();

    for (const segment of Array.from(synopticCorridor.segments.values())) {
      const segId = segment.segmentId;

      features.push({
        type: 'Feature',
        id: 'track_network',
        properties: {
          segmentId: segId,
          onPath: true,
          isScenery: false,
          debugText: segId
        },
        geometry: {
          type: 'MultiLineString',
          coordinates: [segment.polyline]
        }
      });
    }

    return {
      type: 'FeatureCollection',
      features
    };
  }

  override destroy(): SuperCalled {
    this.corridorSubscription.unsubscribe();

    return super.destroy();
  }
}
