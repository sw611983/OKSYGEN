/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import Point from '@mapbox/point-geometry';
import turfBbox from '@turf/bbox';
import { featureCollection } from '@turf/helpers';
import { Feature, GeoJsonProperties, Geometry } from 'geojson';
import { LngLat, LngLatBounds, Map, PointLike } from 'maplibre-gl';

const MIN_LNG = 0;
const MIN_LAT = 1;
const MAX_LNG = 2;
const MAX_LAT = 3;

export class MapBoxBounds {
  public worldBounds: LngLatBounds;
  public offset: PointLike;

  constructor(features: Array<Feature<Geometry, GeoJsonProperties>>) {
    const turfFeatureCollection = featureCollection(features);
    const bbox = turfBbox(turfFeatureCollection);

    this.worldBounds = new LngLatBounds(new LngLat(bbox[MIN_LNG], bbox[MIN_LAT]), new LngLat(bbox[MAX_LNG], bbox[MAX_LAT]));

    const centre = this.worldBounds.getCenter();
    this.offset = new Point(centre.lng, centre.lat);
  }

  /**
   * Calculates a percentage of the width and length of the current view bounds,
   * and pads the map's maximum bounds by this percentage.
   *
   * @param map Mapbox
   * @param percentage the percentage of padding to add, based on current bounds size
   */
  public setPaddedMaxBounds(map: Map, percentage: number): void {
    const viewBounds = map.getBounds();

    // FIXME this padding is probably not going to work when you cross the +/-180 longitude.
    // This may be a hazard at high zoom levels, even if we don't have worlds crossing this longitude,
    // but note that we typically move our tracks/worlds close to longitude 0, reducing this hazard.
    const lngPadding = (viewBounds.getEast() - viewBounds.getWest()) * percentage;
    const latPadding = (viewBounds.getNorth() - viewBounds.getSouth()) * percentage;

    const bounds = new LngLatBounds(
      new LngLat(Math.max(this.worldBounds.getWest() - lngPadding, -180), Math.max(this.worldBounds.getSouth() - latPadding, -90)),
      new LngLat(Math.min(this.worldBounds.getEast() + lngPadding, 180), Math.min(this.worldBounds.getNorth() + latPadding, 90))
    );

    map.setMaxBounds(bounds);
  }
}
