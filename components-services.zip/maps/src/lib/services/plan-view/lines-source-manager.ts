/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Feature, FeatureCollection } from 'geojson';
import { isEqual, isNil } from 'lodash';
import { combineLatest, Observable, of, Subscription } from 'rxjs';
import { distinctUntilChanged, map, switchMap, tap } from 'rxjs/operators';

import { filterTruthy, SuperCalled } from '@oksygen-common-libraries/common';
import { isSegmentSceneryTrack, LngLatCoord, Segment, SegmentConnection } from '@oksygen-sim-core-libraries/data-types/common';
import { IReachablePath, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer, ObjectTypeName } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { MapColor } from '../../helpers/map-color.enum';
import { emptyGeoJSONCollection } from '../../helpers/mapbox.source';
import { SourceManager, SourceManagerConfiguration } from '../mapbox.layers';
import { LINES_SOURCE_NAME } from '../source-layer-managers/lines-layer-manager';

export interface PlanLinesSourceManagerConfiguration extends SourceManagerConfiguration {
  world$: Observable<WorldData>;

  objects$: Observable<ObjectContainer[]>;

  netDef$: Observable<NetworkDefinitionManager>;

  highlightedPath$?: Observable<IReachablePath>;
}

/**
 * Manages Mapbox Sources for rendering informative lines in the world, such as platforms.
 */
export class PlanLinesSourceManager extends SourceManager<PlanLinesSourceManagerConfiguration> {
  dataSub: Subscription;
  worldSub: Subscription;

  constructor(configuration: PlanLinesSourceManagerConfiguration) {
    super(LINES_SOURCE_NAME, configuration);

    this.worldSub = this.configuration.world$?.pipe().subscribe(w => {
      if (!w) {
        this.geoJSONSource.next(emptyGeoJSONCollection());
        return;
      }
      // Only observe interesting object types.
      const obj$ = this.configuration.objects$.pipe(
        map(objs => objs?.filter(o => o.objectType.name === ObjectTypeName.PLATFORM) ?? []),
        distinctUntilChanged(
          (prevF, currF) =>
            // Test whether any of the interesting objects have changed and
            // return *false* if so, because distinctUntilChanged's API is what you might expect from a "filterWhileUnchanged"
            !currF.some(
              cf =>
                !isEqual(
                  cf,
                  prevF.find(f => f.id === cf.id)
                )
            )
        )
      );

      // regenerate the GeoJSON when interesting things change
      this.dataSub?.unsubscribe();
      this.dataSub = combineLatest([obj$, this.configuration.netDef$.pipe(filterTruthy())])
        .pipe(
          tap(([f, n]) => this.geoJSONSource.next(this.createPlatformGeoJSON(w, n, f))),
          switchMap(x => this.configuration.highlightedPath$ ?? of(null))
        )
        .subscribe(path => {
          const props: FeatureCollection = this.geoJSONSource.getValue();

          props.features.forEach(f => {
            f.properties.trainPathOnlyEnabled = !isNil(path);
            f.properties.onPath = !isNil(path) && path.pathSegmentMap.has(f.properties.segmentId);
            f.properties.isScenery = isSegmentSceneryTrack(f.properties.segmentId, w.segmentMap);
          });

          this.geoJSONSource.next(props);
        });
    });
  }

  protected createPlatformGeoJSON(world: WorldData, netDef: NetworkDefinitionManager, objects: ObjectContainer[]): FeatureCollection {
    if (world?.name !== netDef?.worldData?.name) {
      return emptyGeoJSONCollection();
    }

    /**
     * To know which segment is on the left, we can take take a point with an offset of 1 on a segment and see if it is on the left of the other.
     * Basically the current segment becomes two (or more !) segments (A and B). By taking pointA on segmentA
     * we can see if pointA is to the left of segment B. If it is, then segmentA is on the left of segmentB.
     *
     * @param segments the segments in which to find the left or right most one
     * @param onLeft whether we're looking for the left or right most segment
     * @param offset where is the point we'll use to determine whether a segment is on the left or right
     * @returns the left or right most segment. Null if the list of segments is empty.
     */
    function leftestOrRightestSegment(segments: Segment[], onLeft: boolean, offsetFromZero = true): Segment {
      if (segments.length === 0) return undefined;
      if (segments.length === 1) return segments[0];
      let result: Segment = segments[0];
      const initialOffset = offsetFromZero ? 1 : result.length - 1;
      let pointOnResult = netDef.segmentOffsetToLngLat(result.id, initialOffset);
      for (let i = 1; i < segments.length; i++) {
        const currentSegment = segments[i];
        const offset = offsetFromZero ? 1 : currentSegment.length - 1;
        const toTheLeft = !netDef.isOnLeft(pointOnResult, currentSegment.id, offset);
        // if (toTheLeft !== onLeft) {
        if ((toTheLeft && onLeft) || (!toTheLeft && !onLeft)) {
          result = currentSegment;
          pointOnResult = netDef.segmentOffsetToLngLat(currentSegment.id, offset);
        }
      }
      return result;
    }

    /**
     * Find the connected segments before or after the given segment.
     *
     * @param segment The segment to find the connected segments of
     * @param condition  A function that returns true if the connection is the one we're looking for. It can be the connections before, after or both.
     * @returns The connected segments that match the condition.
     */
    function findConnectedSegments(segment: Segment, condition: (c: SegmentConnection) => boolean): Segment[] {
      const connectedSegments: Segment[] = [];
      segment.connections.forEach(c => {
        if (c.fromSegmentId === segment.id && condition(c)) {
          connectedSegments.push(world.segmentMap.get(c.toSegmentId));
        }
      });
      return connectedSegments;
    }

    /*
     * 1. Find the connections to other segments
     * 2. Find the correct segment to display on (same side as the current platform on the current segment)
     * 3. Find the offset on the other segment
     * 4. Create a parallel line on the other segment
     * 5. Repeat until there are no more segments
     */

    /**
     * Process the previous segment
     * @param segment  The segment to process
     * @param offset  The offset on the segment to process
     * @param displacement  The displacement of the parallel line
     * @param onLeft  Whether the parallel line is on the left or right of the segment
     * @param lines  The list of lines to add to. This is mutated by the function.
     */
    function processPreviousSegment(segment: Segment, offset: number, displacement: number, onLeft: boolean, lines: LngLatCoord[][]): void {
      if (offset < 0) {
        const lengthOnPreviousSegment = -offset;
        const segmentsBefore = findConnectedSegments(segment, c => c.fromAlpha);
        const previousSegment = leftestOrRightestSegment(segmentsBefore, onLeft, false);
        if (previousSegment) {
          lines.push(
            netDef.createParallelPolylineFragment(
              previousSegment.id,
              Math.max(previousSegment.length - lengthOnPreviousSegment, 0),
              previousSegment.length,
              displacement,
              onLeft
            )
          );
          // Recursive call with adjusted offset
          processPreviousSegment(previousSegment, previousSegment.length - lengthOnPreviousSegment, displacement, onLeft, lines);
        }
      }
    }
    /**
     *
     * @param segment  The segment to process
     * @param offset  The offset on the segment to process
     * @param displacement  The displacement of the parallel line
     * @param onLeft  Whether the parallel line is on the left or right of the segment
     * @param lines  The list of lines to add to. This is mutated by the function.
     */
    function processNextSegment(segment: Segment, offset: number, displacement: number, onLeft: boolean, lines: LngLatCoord[][]): void {
      const segLength = segment.length;
      if (offset > segLength) {
        const lengthOnNextSegment = offset - segLength;
        const segmentsAfter = findConnectedSegments(segment, c => !c.fromAlpha);
        const nextSegment = leftestOrRightestSegment(segmentsAfter, !onLeft);
        if (nextSegment) {
          lines.push(netDef.createParallelPolylineFragment(nextSegment.id, 0, Math.min(lengthOnNextSegment, nextSegment.length), displacement, onLeft));
          // Recursive call with adjusted offset
          processNextSegment(nextSegment, lengthOnNextSegment, displacement, onLeft, lines);
        }
      }
    }

    const features = new Array<Feature>();

    objects?.forEach(o => {
      const id = o.id;
      if (o.objectType.name === ObjectTypeName.PLATFORM) {
        // Sanity check
        if (!o.location.lnglat) {
          return;
        }

        const lines: LngLatCoord[][] = [];
        const assoc = o.trackAssociations[0];

        const length = +o.properties?.Length;

        // TODO Possibly we want to create a displacement property to make this dynamic.
        const displacement = 2;

        const segId = assoc.segmentId;
        const segOffset = assoc.offset;
        const segment = world.segmentMap.get(segId);
        const segLength = segment.length;
        const onLeft = netDef.isOnLeft(o.location.lnglat, segId, segOffset);

        /**
         * If the platform is too long for the segment, we need to display it on another segment as well.
         * We might have a platform so long that it spans on multiple segments.
         */
        let startOffset = segOffset - length / 2;
        let endOffset = segOffset + length / 2;
        // The platform might be starting on a previous segment or ending on a next one.
        // Note that this will not stop even if it "crosses" another segment.
        processPreviousSegment(segment, startOffset, displacement, onLeft, lines);
        processNextSegment(segment, endOffset, displacement, onLeft, lines);

        if (startOffset < 0) startOffset = 0;
        if (endOffset > segLength) endOffset = segLength;

        lines.push(netDef.createParallelPolylineFragment(segId, startOffset, endOffset, displacement, onLeft));

        features.push({
          type: 'Feature',
          id: 'platform ' + id,
          properties: {
            lineColor: MapColor.PLATFORM_LAYER,
            lineWidth: 5,
            segmentId: assoc.segmentId,
            onPath: true,
            debugText: id
          },
          geometry: {
            type: 'MultiLineString',
            coordinates: lines
          }
        });
      }
    });

    return {
      type: 'FeatureCollection',
      features
    };
  }

  override destroy(): SuperCalled {
    this.worldSub?.unsubscribe();
    this.dataSub?.unsubscribe();

    return super.destroy();
  }
}
