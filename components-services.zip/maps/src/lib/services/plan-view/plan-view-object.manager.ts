/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { isNil } from 'lodash';
import { Map } from 'maplibre-gl';
import { Observable, Subscription } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { batchPromiseCascade, Image } from '@oksygen-sim-train-libraries/components-services/common';

import { getMapGeoJSONSource, notNullGeoJSONCollection } from '../../helpers/mapbox.source';
import { ObjectTrackAtlasManagerConfiguration } from '../../interfaces/atlas-managers/object-track-atlas-manager.interface';
import { ObjectsTrackMapManager } from '../map-managers/objects-track-map.manager';
import { BackgroundLayerManager } from '../source-layer-managers/background-layer-manager';
import { DebugLayerManager } from '../source-layer-managers/debug-layer-manager';
import { LabelLayerManager } from '../source-layer-managers/label/label-layer-manager';
import { LABELS_SOURCE_NAME } from '../source-layer-managers/label/label-source-manager';
import { LinesLayerManager } from '../source-layer-managers/lines-layer-manager';
import { ObjectDragLayerManager } from '../source-layer-managers/objects/object-drag-layer-manager';
import { OBJECTS_LAYER_NAME, ObjectsLayerManager } from '../source-layer-managers/objects/objects-layer-manager';
import { OBJECTS_SOURCE_NAME } from '../source-layer-managers/objects/objects-source-manager';
import { RegionLayerManager } from '../source-layer-managers/region/region-layer-manager';
import { REGIONS_SOURCE_NAME } from '../source-layer-managers/region/region-source-manager';
import { SpotlightLayerManager } from '../source-layer-managers/spotlight-layer-manager';
import { PointsLayerManager } from '../source-layer-managers/track/points-layer-manager';
import { TrackLayerManager } from '../source-layer-managers/track/track-layer-manager';
import { TrackPathLayerManager } from '../source-layer-managers/track/track-path-layer-manager';
import { TRACK_SOURCE_NAME } from '../source-layer-managers/track/track-source-manager';
import { PlanLinesSourceManager } from './lines-source-manager';
import { PlanTrackSourceManager } from './track-source-manager';

export const PLAN_VIEW_NAME = 'plan';

// this code is duplicated in PlanViewTrainManager as it needs to extend a different parent
export class PlanViewObjectMapManager<C extends ObjectTrackAtlasManagerConfiguration = ObjectTrackAtlasManagerConfiguration> extends ObjectsTrackMapManager<C> {
  protected linesSourceManager: PlanLinesSourceManager;

  constructor(logging: Logging, registry: Registry, zone: NgZone, configuration: C) {
    super(logging, registry, zone, configuration);
  }

  public override addLayerManagers(): void {
    this.objectTypesSources = [LABELS_SOURCE_NAME, REGIONS_SOURCE_NAME, OBJECTS_SOURCE_NAME, TRACK_SOURCE_NAME];
    this.worldBoundsSources = [OBJECTS_SOURCE_NAME, LABELS_SOURCE_NAME, REGIONS_SOURCE_NAME, TRACK_SOURCE_NAME];

    this.layerManagers = [
      new BackgroundLayerManager(),
      new TrackLayerManager(this.configuration, this.zone),
      new PointsLayerManager(this.configuration, this.zone),
      new RegionLayerManager(),
      new LinesLayerManager(),
      new ObjectsLayerManager(this.configuration, this.zone),
      new TrackPathLayerManager(this.configuration),
      new LabelLayerManager(this.registry),
      new SpotlightLayerManager(),
      new DebugLayerManager()
    ];

    this.dragLayerManagers = [new ObjectDragLayerManager()];
  }

  /**
   * Attaches sources to the map and wires them up to get updates from the data managers.
   *
   * @param map the map to update
   * @param parentSubscription when this unsubscribes we'll unsubscribe our map updates
   */
  public override attachSourcesTo(map: Map, parentSubscription: Subscription): SuperCalled {
    parentSubscription.add(
      this.linesSourceManager.asObservable().subscribe(t => {
        getMapGeoJSONSource(map, this.linesSourceManager.sourceName)?.setData(notNullGeoJSONCollection(t));
        // Shows platform feature IDs
        // this.getMapGeoJSONSource(map, DEBUG_SOURCE_NAME).setData(t);
      })
    );

    return super.attachSourcesTo(map, parentSubscription);
  }

  public attachImagesTo(map: Map, images: Image[], batchSize = 500, delayBetweenBatches = 5): Observable<number> {
    return batchPromiseCascade(
      images
        .filter(i => !map.hasImage(i.name))
        .map(
          image => () =>
            new Promise<void>((resolve, reject) => {
              image.image
                .asImageData()
                .then(imageData => {
                  if (!map.hasImage(image.name)) {
                    map.addImage(image.name, imageData);
                  }
                  resolve();
                })
                .catch(err => {
                  this.logging.log(`failed to load state icon with new system (${image.name})`);
                  reject(err);
                });
            })
        ),
      batchSize,
      delayBetweenBatches
    );
  }

  protected override createSources(): SuperCalled {
    if (isNil(this.linesSourceManager)) {
      this.linesSourceManager = new PlanLinesSourceManager(this.configuration);
    }

    return super.createSources();
  }

  public override createTrackSourceManager(): PlanTrackSourceManager {
    return new PlanTrackSourceManager(this.configuration);
  }

  public override getHoverLayerName(): string | undefined {
    return OBJECTS_LAYER_NAME;
  }

  public override destroy(): SuperCalled {
    this.trackSourceManager?.destroy();
    this.linesSourceManager?.destroy();

    return super.destroy();
  }
}
