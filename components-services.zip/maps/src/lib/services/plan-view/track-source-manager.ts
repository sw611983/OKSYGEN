/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FeatureCollection } from 'geojson';
import { isNil } from 'lodash';
import { Observable, Subscription } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { isSegmentSceneryTrack } from '@oksygen-sim-core-libraries/data-types/common';
import { IReachablePath, WorldData } from '@oksygen-sim-train-libraries/components-services/common';

import { emptyGeoJSONCollection } from '../../helpers/mapbox.source';
import { SourceManagerConfiguration } from '../mapbox.layers';
import { AbstractTrackSourceManager } from '../source-layer-managers/track/track-source-manager';

export interface PlanTrackSourceManagerConfiguration extends SourceManagerConfiguration {
  world$: Observable<WorldData>;

  highlightedPath$?: Observable<IReachablePath>;
}

/**
 * Manages Mapbox Sources for rendering tracks.
 */
export class PlanTrackSourceManager extends AbstractTrackSourceManager<PlanTrackSourceManagerConfiguration> {
  private pathSub = Subscription.EMPTY;
  private worldSub = Subscription.EMPTY;

  constructor(configuration: PlanTrackSourceManagerConfiguration) {
    super(configuration);

    this.worldSub = this.configuration.world$?.pipe().subscribe(w => {
      if (isNil(w)) {
        this.geoJSONSource.next(emptyGeoJSONCollection());
        return;
      }

      this.geoJSONSource.next(this.createTrackGeoJSON(w.segmentPolylines));

      if (!isNil(this.configuration.highlightedPath$)) {
        this.pathSub = this.configuration.highlightedPath$.subscribe(path => {
          const props: FeatureCollection = this.geoJSONSource.getValue();
          const pathEnabled = !isNil(path);
          props.features.forEach((f: any) => {
            f.properties.trainPathOnlyEnabled = pathEnabled;
            f.properties.onPath = pathEnabled && path.pathSegmentMap.has(f.properties.segmentId);
            f.properties.isScenery = isSegmentSceneryTrack(f.properties.segmentId, w.segmentMap);
          });
          this.geoJSONSource.next(props);
        });
      }
    });
  }

  override destroy(): SuperCalled {
    this.worldSub.unsubscribe();
    this.pathSub.unsubscribe();

    return super.destroy();
  }
}
