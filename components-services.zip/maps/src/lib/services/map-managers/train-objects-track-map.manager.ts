/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { isNil } from 'lodash';
import { GeoJSONSource, LngLat, Map } from 'maplibre-gl';
import { Subscription } from 'rxjs';

import { DragFeedback, SelfCompletingObservable, SuperCalled } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LngLatCoord, SegOffset, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData } from '@oksygen-sim-train-libraries/components-services/common';
import { UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { getMapGeoJSONSource, notNullGeoJSONCollection } from '../../helpers/mapbox.source';
import {
  ITrainObjectTrackMapManager,
  TRAIN_MAP_MANAGER_TYPE,
  TrainObjectTrackMapManagerConfiguration
} from '../../interfaces/map-managers/train-object-track-map-manager.interface';
import {
  NULL_TRAIN_SELECTION_HANDLER,
  RawTrainSelectionHandler,
  TrainSelectionHandler
} from '../../interfaces/selection-handlers/selection-train.interface';
import { DriverSourceManager } from '../source-layer-managers/driver/driver-source-manager';
import { TrainDragSourceManager } from '../source-layer-managers/trains/train-drag-source-manager';
import { TRAINS_LAYER_NAME } from '../source-layer-managers/trains/trains-layer-manager';
import { TrainsSourceManager } from '../source-layer-managers/trains/trains-source-manager';
import { ObjectsTrackMapManager } from './objects-track-map.manager';

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 */
export abstract class TrainObjectsTrackMapManager<C extends TrainObjectTrackMapManagerConfiguration = TrainObjectTrackMapManagerConfiguration>
  extends ObjectsTrackMapManager<C>
  implements ITrainObjectTrackMapManager
{
  protected trainSourceManager: TrainsSourceManager;
  protected trainDragSourceManager: TrainDragSourceManager;
  protected driverSourceManager?: DriverSourceManager;

  protected readonly NULL_TRAIN_SELECTION_HANDLER: TrainSelectionHandler = NULL_TRAIN_SELECTION_HANDLER;
  protected trainSelectionHandler: TrainSelectionHandler = this.NULL_TRAIN_SELECTION_HANDLER;

  constructor(logging: Logging, registry: Registry, zone: NgZone, configuration: C) {
    super(logging, registry, zone, configuration);
  }

  public override getManagerTypes(): Array<string> {
    return [...super.getManagerTypes(), TRAIN_MAP_MANAGER_TYPE];
  }

  public override getSources(): Array<string> {
    const sources = super.getSources();

    if (!isNil(this.trainSourceManager)) {
      sources.push(this.trainSourceManager.sourceName);
    }

    if (!isNil(this.trainDragSourceManager)) {
      sources.push(this.trainDragSourceManager.sourceName);
    }

    if (!isNil(this.driverSourceManager)) {
      sources.push(this.driverSourceManager.sourceName);
    }

    return sources;
  }

  /**
   * Sets the train selection handler if no handler is currently active.
   * ```clearTrainSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public setTrainSelectionHandler(handler: TrainSelectionHandler): void {
    if (this.trainSelectionHandler === this.NULL_TRAIN_SELECTION_HANDLER) {
      this.trainSelectionHandler = handler;
    }
  }

  public getTrainSelectionHandler(): TrainSelectionHandler {
    return this.trainSelectionHandler;
  }

  /**
   * Clears the train selection handler, allowing other handlers to be attached.
   */
  public clearTrainSelectionHandler(): void {
    this.trainSelectionHandler = this.NULL_TRAIN_SELECTION_HANDLER;
  }

  protected override setUpInputHandlers(): void {
    this.subscriptions.add(
      this.configuration.netDef$.subscribe(network => {
        // awful hack - there's a race condition when you switch worlds when creating a new scenario
        // where this is called before the map is set which is a cannot ref prop of undefined error
        // the settimeout makes it more likely (but doesn't guarantee) that the map is set first
        setTimeout(() => {
          this.addObjectInputHandler();
          this.addPointInputHandler();
          this.addTrackInputHandler(network);
          this.addTrainInputHandler(network);
        }, 2000);
      })
    );
  }

  /**
   * Attaches sources to the map and wires them up to get updates from the data managers.
   *
   * @param map the map to update
   * @param parentSubscription when this unsubscribes we'll unsubscribe our map updates
   */
  public override attachSourcesTo(map: Map, parentSubscription: Subscription): SuperCalled {
    if (!isNil(this.driverSourceManager)) {
      parentSubscription.add(
        this.driverSourceManager.asObservable().subscribe(t => {
          getMapGeoJSONSource(map, this.driverSourceManager.sourceName)?.setData(notNullGeoJSONCollection(t));
          // Shows User IDs
          // this.getMapGeoJSONSource(map, DEBUG_SOURCE_NAME).setData(t);
        })
      );
    }

    if (!isNil(this.trainSourceManager)) {
      parentSubscription.add(
        this.trainSourceManager.asObservable().subscribe(vehicles => {
          this.zone?.runOutsideAngular(() => {
            getMapGeoJSONSource(map, this.trainSourceManager.sourceName)?.setData(notNullGeoJSONCollection(vehicles));
          });
        })
      );
    }

    return super.attachSourcesTo(map, parentSubscription);
  }

  protected addTrainInputHandler(network: NetworkDefinitionManager): void {
    const findSegOffsetOfTrain = (lngLat: LngLat, train: UsefulTrain): SegOffset => {
      const segments = train.vehicles.reduce((p, c) => {
        const segId = c.position.segmentId;
        if (segId && !p.includes(segId)) {
          p.push(segId);
        }

        return p;
      }, []);
      return network.lngLatToSegmentOffset([lngLat.lng, lngLat.lat], segments);
    };

    const rawTrainHandler: RawTrainSelectionHandler = {
      onTrainHovered: (id: number, lngLat: LngLat, data: any) => this.trainSelectionHandler.onTrainHovered(id, findSegOffsetOfTrain(lngLat, data), data),
      onTrainClicked: (id: number, lngLat: LngLat, data: any) => this.trainSelectionHandler.onTrainClicked(id, findSegOffsetOfTrain(lngLat, data), data),
      onTrainDown: (id: number, lngLat: LngLat, data: any): boolean => {
        const segOffset = findSegOffsetOfTrain(lngLat, data);
        const enabled = this.trainSelectionHandler.onTrainDown(id, segOffset, data);
        if (enabled) {
          this.dragData$.next({ type: 'train', start: { lngLat, segOffset }, data });
        }
        return enabled;
      }
    };

    this.layerManagers.find(layerManager => layerManager.layerName === TRAINS_LAYER_NAME)?.setInputHandler(rawTrainHandler);
  }

  protected override createSources(): SuperCalled {
    if (isNil(this.trainSourceManager)) {
      this.trainSourceManager = new TrainsSourceManager(this.logging, this.zone, {
        data$: this.configuration.trains$
      });
    }

    if (isNil(this.trainDragSourceManager)) {
      this.trainDragSourceManager = new TrainDragSourceManager({ ...(this.configuration as any), handler: this.trainSelectionHandler });
    }

    if (isNil(this.driverSourceManager)) {
      this.driverSourceManager = new DriverSourceManager(this.configuration);
    }

    return super.createSources();
  }

  public override destroy(): SuperCalled {
    this.trainSourceManager?.destroy();
    this.trainDragSourceManager?.destroy();
    this.driverSourceManager?.destroy();
    this.trainSelectionHandler = NULL_TRAIN_SELECTION_HANDLER;

    return super.destroy();
  }

  public override initDragInputHandling(map: Map, subscription: Subscription): void {
    super.initDragInputHandling(map, subscription);

    subscription.add(
      this.trainDragSourceManager.asObservable().subscribe(objects => {
        (map.getSource(this.trainDragSourceManager.sourceName) as GeoJSONSource)?.setData(notNullGeoJSONCollection(objects));
      })
    );
  }

  public override onDrag(
    dragData: DragData,
    lngLat: LngLat,
    lngLatCoord: LngLatCoord,
    segOffset: SegOffsetOriented,
    userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback> | undefined {
    let dragObservable = super.onDrag(dragData, lngLat, lngLatCoord, segOffset, userScale);

    if (isNil(dragObservable) && this.trainDragSourceManager.supportsDrag(dragData)) {
      dragObservable = this.trainDragSourceManager.onDrag(dragData, lngLat, lngLatCoord, segOffset, userScale);
    }

    return dragObservable;
  }

  public override removeDragFeedback(): void {
    super.removeDragFeedback();

    this.trainDragSourceManager.removeFeedback();
  }

  public override onDrop(dragData: DragData, lngLat: LngLat, lngLatCoord: LngLatCoord, segOffset: SegOffsetOriented, userScale: UserScale[]): void {
    super.onDrop(dragData, lngLat, lngLatCoord, segOffset, userScale);

    if (this.trainDragSourceManager.supportsDrag(dragData)) {
      this.trainDragSourceManager.onDrop(dragData, lngLat, lngLatCoord, segOffset, userScale);
    }
  }
}
