/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { isNil } from 'lodash';
import { GeoJSONSource, LngLat, Map } from 'maplibre-gl';
import { asyncScheduler, Subscription } from 'rxjs';
import { throttleTime } from 'rxjs/operators';

import { DragFeedback, SelfCompletingObservable, SuperCalled } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LngLatCoord, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData } from '@oksygen-sim-train-libraries/components-services/common';
import { OBJECT_DATA_TYPE_NAME } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { getGeoJSONFeaturesFromSource, getMapGeoJSONSource, notNullGeoJSONCollection } from '../../helpers/mapbox.source';
import {
  IObjectTrackMapManager,
  OBJECT_MAP_MANAGER_TYPE,
  ObjectTrackMapManagerConfiguration
} from '../../interfaces/map-managers/object-track-map-manager.interface';
import {
  NULL_OBJECT_SELECTION_HANDLER,
  ObjectSelectionHandler,
  RawObjectSelectionHandler
} from '../../interfaces/selection-handlers/selection-object.interface';
import { TrackSelectionHandler } from '../../interfaces/selection-handlers/selection-track.interface';
import { ObjectDragSourceManager } from '../source-layer-managers/objects/object-drag-source-manager';
import { OBJECTS_LAYER_NAME } from '../source-layer-managers/objects/objects-layer-manager';
import {
  OBJECTS_SELECTED_SOURCE_NAME, OBJECTS_SELECTED_TA_LINE_SOURCE_NAME, OBJECTS_SELECTED_TA_SOURCE_NAME, ObjectsSourceManager
} from '../source-layer-managers/objects/objects-source-manager';
import { PATH_PREVIEW_SOURCE_NAME, PATH_SOURCE_NAME } from '../source-layer-managers/track/track-path-layer-manager';
import { TrackMapManager } from './track-map.manager';

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 */
export abstract class ObjectsTrackMapManager<C extends ObjectTrackMapManagerConfiguration = ObjectTrackMapManagerConfiguration>
  extends TrackMapManager<C>
  implements IObjectTrackMapManager
{
  protected objectsSourceManager: ObjectsSourceManager;

  protected objectDragSourceManager: ObjectDragSourceManager;

  protected readonly NULL_OBJECT_SELECTION_HANDLER: ObjectSelectionHandler = NULL_OBJECT_SELECTION_HANDLER;
  protected objectSelectionHandler: ObjectSelectionHandler = this.NULL_OBJECT_SELECTION_HANDLER;

  constructor(logging: Logging, registry: Registry, zone: NgZone, configuration: C) {
    super(logging, registry, zone, configuration);
  }

  public override getManagerTypes(): Array<string> {
    return [...super.getManagerTypes(), OBJECT_MAP_MANAGER_TYPE];
  }

  public override getSources(): Array<string> {
    const sources = super.getSources();

    if (!isNil(this.objectsSourceManager)) {
      sources.push(this.objectsSourceManager.sourceName);
    }

    if (!isNil(this.objectDragSourceManager)) {
      sources.push(this.objectDragSourceManager.sourceName);
    }

    sources.push(PATH_SOURCE_NAME, PATH_PREVIEW_SOURCE_NAME);
    sources.push(OBJECTS_SELECTED_SOURCE_NAME, OBJECTS_SELECTED_TA_SOURCE_NAME, OBJECTS_SELECTED_TA_LINE_SOURCE_NAME);

    return sources;
  }

  /**
   * Sets the Object selection handler if no handler is currently active.
   * ```clearObjectSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public setObjectSelectionHandler(handler: ObjectSelectionHandler): void {
    if (this.objectSelectionHandler === this.NULL_OBJECT_SELECTION_HANDLER) {
      this.objectSelectionHandler = handler;
    }
  }

  /**
   * Returns the current Object selection handler.
   */
  public getObjectSelectionHandler(): ObjectSelectionHandler {
    return this.objectSelectionHandler;
  }

  /**
   * Clears the Object selection handler, allowing other handlers to be attached.
   */
  public clearObjectSelectionHandler(): void {
    this.objectSelectionHandler = this.NULL_OBJECT_SELECTION_HANDLER;
  }

  protected override setUpInputHandlers(): void {
    this.subscriptions.add(
      this.configuration.netDef$.subscribe(network => {
        this.addObjectInputHandler();
        this.addPointInputHandler();
        this.addTrackInputHandler(network);
      })
    );
  }

  /**
   * Attaches sources to the map and wires them up to get updates from the data managers.
   *
   * @param map the map to update
   * @param parentSubscription when this unsubscribes we'll unsubscribe our map updates
   */
  public override attachSourcesTo(map: Map, parentSubscription: Subscription): SuperCalled {
    if (!isNil(this.objectsSourceManager)) {
      parentSubscription.add(
        this.objectsSourceManager
          .asObservable()
          .pipe(throttleTime(500, asyncScheduler, { leading: true, trailing: true }))
          .subscribe(t => {
            getMapGeoJSONSource(map, this.objectsSourceManager.sourceName)?.setData(notNullGeoJSONCollection(t));
            // Shows object IDs
            // this.getMapGeoJSONSource(map, DEBUG_SOURCE_NAME).setData(t);
            this.geometrySourceUpdated.next(undefined);
          })
      );

      this.objectsSourceManager.subscribe();

      this.objectsSourceManager.selectedObjectGeoJSON().subscribe(geoJson => {
        getMapGeoJSONSource(map, OBJECTS_SELECTED_SOURCE_NAME)?.setData(notNullGeoJSONCollection(geoJson.objects));
        getMapGeoJSONSource(map, OBJECTS_SELECTED_TA_SOURCE_NAME)?.setData(notNullGeoJSONCollection(geoJson.trackAssociations));
        getMapGeoJSONSource(map, OBJECTS_SELECTED_TA_LINE_SOURCE_NAME)?.setData(notNullGeoJSONCollection(geoJson.trackAssociationLines));
      });
    }

    return super.attachSourcesTo(map, parentSubscription);
  }

  protected addObjectInputHandler(): void {
    const rawObjectHandler: RawObjectSelectionHandler = {
      onObjectHovered: (id: number, data: any) => {
        this.objectSelectionHandler.onObjectHovered(id, data);
      },
      onObjectClicked: (id: number, data: any) => this.objectSelectionHandler.onObjectClicked(id, data),
      onObjectDown: (id: number, data: any): boolean => {
        const enabled = this.objectSelectionHandler.onObjectDown(id, data);
        if (enabled) {
          this.dragData$.next({ type: OBJECT_DATA_TYPE_NAME, data: JSON.parse(data) });
        }
        return enabled;
      }
    };

    this.layerManagers.find(layerManager => layerManager.layerName === OBJECTS_LAYER_NAME)?.setInputHandler(rawObjectHandler);
  }

  /**
   * Sets the track selection handler if no handler is currently active.
   * ```clearTrackSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public override setTrackSelectionHandler(handler: TrackSelectionHandler): void {
    if (this.trackSelectionHandler === this.NULL_TRACK_SELECTION_HANDLER) {
      this.trackSelectionHandler = handler;
      this.trackDragSourceManager.updateConfiguration({ handler: this.trackSelectionHandler });
    }
  }

  protected override createSources(): SuperCalled {
    if (isNil(this.objectsSourceManager)) {
      this.objectsSourceManager = new ObjectsSourceManager(
        this.logging,
        this.layerManagers,
        this.dragLayerManagers,
        this.configuration.objectsSourceManagerConfiguration
      );
    }

    if (isNil(this.objectDragSourceManager)) {
      this.objectDragSourceManager = new ObjectDragSourceManager({ ...(this.configuration as any), handler: this.objectSelectionHandler });
    }

    return super.createSources();
  }

  public override clear(): SuperCalled {
    return super.clear();
  }

  public override destroy(): SuperCalled {
    this.objectsSourceManager?.destroy();
    this.objectsSourceManager = undefined;

    this.objectDragSourceManager?.destroy();
    this.objectDragSourceManager = undefined;

    this.objectSelectionHandler = NULL_OBJECT_SELECTION_HANDLER;
    this.subscriptions.unsubscribe();

    return super.destroy();
  }

  public override initDragInputHandling(map: Map, subscription: Subscription): void {
    super.initDragInputHandling(map, subscription);

    subscription.add(
      this.objectDragSourceManager.asObservable().subscribe(objects => {
        (map.getSource(this.objectDragSourceManager.sourceName) as GeoJSONSource)?.setData(notNullGeoJSONCollection(objects));
      })
    );
  }

  public override onDrag(
    dragData: DragData,
    lngLat: LngLat,
    lngLatCoord: LngLatCoord,
    segOffset: SegOffsetOriented,
    userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback> | undefined {
    let dragObservable = super.onDrag(dragData, lngLat, lngLatCoord, segOffset, userScale);

    if (isNil(dragObservable) && this.objectDragSourceManager.supportsDrag(dragData)) {
      dragObservable = this.objectDragSourceManager.onDrag(dragData, lngLat, lngLatCoord, segOffset, userScale);
    }

    return dragObservable;
  }

  public override removeDragFeedback(): void {
    super.removeDragFeedback();

    this.objectDragSourceManager.removeFeedback();
  }

  public override onDrop(dragData: DragData, lngLat: LngLat, lngLatCoord: LngLatCoord, segOffset: SegOffsetOriented, userScale: UserScale[]): void {
    super.onDrop(dragData, lngLat, lngLatCoord, segOffset, userScale);

    if (this.objectDragSourceManager.supportsDrag(dragData)) {
      this.objectDragSourceManager.onDrop(dragData, lngLat, lngLatCoord, segOffset, userScale);
    }
  }

  public getGeoJsonFeaturesFromSource(map: Map): Array<any> {
    const allGeoJSONObjects: Array<any> = [];

    this.objectTypesSources.forEach(sourceName => allGeoJSONObjects.push(...getGeoJSONFeaturesFromSource(map, sourceName)));

    return allGeoJSONObjects;
  }
}
