/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { isNil } from 'lodash';
import { GeoJSONSource, LngLat, Map } from 'maplibre-gl';
import { asyncScheduler, Subscription } from 'rxjs';
import { throttleTime } from 'rxjs/operators';

import { DragFeedback, SelfCompletingObservable, SuperCalled } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LngLatCoord, SegOffset, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectTypeContainer, POINT_DATA_TYPE_NAME } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { getMapGeoJSONSource, notNullGeoJSONCollection } from '../../helpers/mapbox.source';
import { isObjectTrackMapManagerConfiguration } from '../../interfaces/map-managers/object-track-map-manager.interface';
import {
  ITrackMapManager,
  TRACK_MAP_MANAGER_TYPE,
  TrackMapManagerConfiguration
} from '../../interfaces/map-managers/track-map-manager.interface';
import {
  NULL_POINT_SELECTION_HANDLER,
  PointSelectionHandler,
  RawPointSelectionHandler
} from '../../interfaces/selection-handlers/selection-point.interface';
import {
  NULL_TRACK_SELECTION_HANDLER,
  RawTrackSelectionData,
  RawTrackSelectionHandler,
  TrackSelectionHandler
} from '../../interfaces/selection-handlers/selection-track.interface';
import { SELECTED_SOURCE_NAME } from '../mapbox.layers';
import { DEBUG_SOURCE_NAME } from '../source-layer-managers/debug-layer-manager';
import { LabelSourceManager } from '../source-layer-managers/label/label-source-manager';
import { LINES_SOURCE_NAME } from '../source-layer-managers/lines-layer-manager';
import { RegionSourceManager } from '../source-layer-managers/region/region-source-manager';
import { SPOTLIGHT_SOURCE_NAME } from '../source-layer-managers/spotlight-layer-manager';
import { POINTS_HOTSPOT_LAYER_NAME } from '../source-layer-managers/track/points-layer-manager';
import { PointsSourceManager } from '../source-layer-managers/track/points-source-manager';
import { TrackDragSourceManager } from '../source-layer-managers/track/track-drag-source-manager';
import { TRACK_LAYER_NAME } from '../source-layer-managers/track/track-layer-manager';
import { AbstractTrackSourceManager } from '../source-layer-managers/track/track-source-manager';
import { MapManager } from './map.manager';

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 * @param layerManagers Note that order here is important, as it dictates the rendering order.
 */
export abstract class TrackMapManager<
    C extends TrackMapManagerConfiguration = TrackMapManagerConfiguration,
    TM extends AbstractTrackSourceManager = AbstractTrackSourceManager
  >
  extends MapManager<C>
  implements ITrackMapManager
{
  protected trackSourceManager: TM;
  protected pointsSourceManager: PointsSourceManager;
  protected trackDragSourceManager: TrackDragSourceManager;

  pointsType: ObjectTypeContainer;

  protected readonly NULL_TRACK_SELECTION_HANDLER: TrackSelectionHandler = NULL_TRACK_SELECTION_HANDLER;
  protected trackSelectionHandler: TrackSelectionHandler = this.NULL_TRACK_SELECTION_HANDLER;

  protected readonly NULL_POINT_SELECTION_HANDLER: PointSelectionHandler = NULL_POINT_SELECTION_HANDLER;
  protected pointSelectionHandler: PointSelectionHandler = this.NULL_POINT_SELECTION_HANDLER;

  constructor(logging: Logging, registry: Registry, zone: NgZone, configuration: C) {
    super(logging, registry, zone, configuration);
  }

  // initialisation methods

  /**
   * Attach mapbox data to the mapbox map.
   * Also attach some data listeners to update the map when things update.
   * Note this doesn't tell mapbox HOW to render this data, for that use attachLayersTo().
   *
   * @param map the map to update
   * @param parentSubscription when this unsubscribes we'll unsubscribe our map updates
   */
  public override attachSourcesTo(map: Map, parentSubscription: Subscription): SuperCalled {
    if (!isNil(this.trackSourceManager)) {
      parentSubscription.add(
        this.trackSourceManager.asObservable().subscribe(t => {
          getMapGeoJSONSource(map, this.trackSourceManager.sourceName)?.setData(notNullGeoJSONCollection(t));
          // Shows segment IDs
          // this.getMapGeoJSONSource(map, DEBUG_SOURCE_NAME).setData(t);
          this.geometrySourceUpdated.next(null);
        })
      );
    }

    if (!isNil(this.pointsSourceManager)) {
      parentSubscription.add(
        this.pointsSourceManager
          .asObservable()
          .pipe(throttleTime(500, asyncScheduler, { leading: true, trailing: true }))
          .subscribe(p => {
            getMapGeoJSONSource(map, this.pointsSourceManager.sourceName)?.setData(notNullGeoJSONCollection(p));
          })
      );
    }

    this.otherSourceManagers.forEach(sourceManager => {
      parentSubscription.add(
        sourceManager
          .asObservable()
          .pipe(throttleTime(500, asyncScheduler, { leading: true, trailing: true }))
          .subscribe(p => {
            getMapGeoJSONSource(map, sourceManager.sourceName)?.setData(notNullGeoJSONCollection(p));
          })
      );
    });

    return super.attachSourcesTo(map, parentSubscription);
  }

  public override getManagerTypes(): Array<string> {
    return [...super.getManagerTypes(), TRACK_MAP_MANAGER_TYPE];
  }

  protected override getSources(): Array<string> {
    const sources = super.getSources();

    sources.push(SPOTLIGHT_SOURCE_NAME, SELECTED_SOURCE_NAME, DEBUG_SOURCE_NAME, LINES_SOURCE_NAME);

    this.otherSourceManagers.forEach(sourceManager => sources.push(...sourceManager.sourceNames));

    if (!isNil(this.pointsSourceManager)) {
      sources.push(...this.pointsSourceManager.sourceNames);
    }

    if (!isNil(this.trackSourceManager)) {
      sources.push(...this.trackSourceManager.sourceNames);
    }

    return sources;
  }

  /**
   * Sets the track selection handler if no handler is currently active.
   * ```clearTrackSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public setTrackSelectionHandler(handler: TrackSelectionHandler): void {
    if (this.trackSelectionHandler === this.NULL_TRACK_SELECTION_HANDLER) {
      this.trackSelectionHandler = handler;
      this.trackDragSourceManager.updateConfiguration({ handler: this.trackSelectionHandler });
    }
  }

  /**
   * Clears the track selection handler, allowing other handlers to be attached.
   */
  public clearTrackSelectionHandler(): void {
    this.trackSelectionHandler = this.NULL_TRACK_SELECTION_HANDLER;
  }

  /**
   * Returns the current Track selection handler.
   */
  public getTrackSelectionHandler(): TrackSelectionHandler {
    return this.trackSelectionHandler;
  }

  /**
   * Sets the Point selection handler if no handler is currently active.
   * ```clearPointSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public setPointSelectionHandler(handler: PointSelectionHandler): void {
    if (this.pointSelectionHandler === this.NULL_POINT_SELECTION_HANDLER) {
      this.pointSelectionHandler = handler;
    }
  }

  /**
   * Returns the current Point selection handler.
   */
  public getPointSelectionHandler(): PointSelectionHandler {
    return this.pointSelectionHandler;
  }

  /**
   * Clears the Point selection handler, allowing other handlers to be attached.
   */
  public clearPointSelectionHandler(): void {
    this.pointSelectionHandler = this.NULL_POINT_SELECTION_HANDLER;
  }

  /** Note that order here is important, as it dictates the click priority. */
  protected setUpInputHandlers(): void {
    this.subscriptions.add(
      this.configuration.netDef$.subscribe(network => {
        this.addPointInputHandler();
        this.addTrackInputHandler(network);
      })
    );
  }

  protected addTrackInputHandler(network: NetworkDefinitionManager): void {
    const findSegOffsetOfTrack = (data: RawTrackSelectionData): SegOffset => network.lngLatToSegmentOffset([data.lngLat.lng, data.lngLat.lat], data.segIds);

    const rawTrackHandler: RawTrackSelectionHandler & any = {
      converter: findSegOffsetOfTrack,
      onTrackPointHovered: (data: RawTrackSelectionData) => this.trackSelectionHandler.onTrackHovered(findSegOffsetOfTrack(data)),
      onTrackPointClicked: (data: RawTrackSelectionData) => this.trackSelectionHandler.onTrackClicked(findSegOffsetOfTrack(data)),
      onTrackPointDown: (data: RawTrackSelectionData): boolean => {
        const enabled = this.trackSelectionHandler.onTrackDown(findSegOffsetOfTrack(data));
        if (enabled) {
          this.dragData$.next({ type: 'track', data });
        }
        return enabled;
      },
      onTrackPointUp: (data: RawTrackSelectionData) => this.trackSelectionHandler.onTrackUp(findSegOffsetOfTrack(data)),
      onSelectedPointClicked: (data: RawTrackSelectionData) => this.trackSelectionHandler.onSelectedClicked(findSegOffsetOfTrack(data)),
      onSelectedPointDown: (data: RawTrackSelectionData): boolean => {
        const enabled = this.trackSelectionHandler.onSelectedDown(findSegOffsetOfTrack(data));
        if (enabled) {
          this.dragData$.next({ type: 'selectedtrack', data });
        }
        return enabled;
      },
      onSelectedPointUp: (data: RawTrackSelectionData) => this.trackSelectionHandler.onSelectedUp(findSegOffsetOfTrack(data))
    };

    this.layerManagers.find(layerManager => layerManager.layerName === TRACK_LAYER_NAME)?.setInputHandler(rawTrackHandler);
  }

  protected addPointInputHandler(): void {
    const rawPointHandler: RawPointSelectionHandler = {
      onPointHovered: (id: number, data: any) => {
        this.pointSelectionHandler.onPointHovered(id, data);
      },
      onPointClicked: (id: number, data: any) => this.pointSelectionHandler.onPointClicked(id, data),
      onPointDown: (id: number, data: any): boolean => {
        const enabled = this.pointSelectionHandler.onPointDown(id, data);
        if (enabled) {
          this.dragData$.next({ type: POINT_DATA_TYPE_NAME, data: JSON.parse(data) });
        }
        return enabled;
      }
    };

    this.layerManagers.find(layerManager => layerManager.layerName === POINTS_HOTSPOT_LAYER_NAME)?.setInputHandler(rawPointHandler);
  }

  protected override createSources(): SuperCalled {
    this.trackSourceManager = this.createTrackSourceManager();

    if (isNil(this.trackDragSourceManager)) {
      this.trackDragSourceManager = new TrackDragSourceManager({ handler: this.trackSelectionHandler });
    }

    if (isObjectTrackMapManagerConfiguration(this.configuration)) {
      this.otherSourceManagers.push(new LabelSourceManager(this.logging, { data$: this.configuration.objects$ }));

      if (isNil(this.pointsSourceManager)) {
        this.pointsSourceManager = new PointsSourceManager(this.logging, this.configuration);

        this.otherSourceManagers.push(new RegionSourceManager(this.logging, { data$: this.configuration.objects$ }));
      }
    }

    return super.createSources();
  }

  public override initDragInputHandling(map: Map, subscription: Subscription): void {
    super.initDragInputHandling(map, subscription);

    subscription.add(
      this.trackDragSourceManager.asObservable().subscribe(objects => {
        (map.getSource(this.trackDragSourceManager.sourceName) as GeoJSONSource)?.setData(notNullGeoJSONCollection(objects));
      })
    );
  }

  public override onDrag(
    dragData: DragData,
    lngLat: LngLat,
    lngLatCoord: LngLatCoord,
    segOffset: SegOffsetOriented,
    userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback> | undefined {
    let dragObservable = super.onDrag(dragData, lngLat, lngLatCoord, segOffset, userScale);

    if (isNil(dragObservable) && this.trackDragSourceManager.supportsDrag(dragData)) {
      dragObservable = this.trackDragSourceManager.onDrag(dragData, lngLat, lngLatCoord, segOffset, userScale);
    }

    return dragObservable;
  }

  public override removeDragFeedback(): void {
    super.removeDragFeedback();

    this.trackDragSourceManager.removeFeedback();
  }

  public override onDrop(dragData: DragData, lngLat: LngLat, lngLatCoord: LngLatCoord, segOffset: SegOffsetOriented, userScale: UserScale[]): void {
    super.onDrop(dragData, lngLat, lngLatCoord, segOffset, userScale);

    if (this.trackDragSourceManager.supportsDrag(dragData)) {
      this.trackDragSourceManager.onDrop(dragData, lngLat, lngLatCoord, segOffset, userScale);
    }
  }

  protected createTrackSourceManager(): TM {
    return undefined;
  }

  public override destroy(): SuperCalled {
    this.pointsSourceManager?.destroy();
    this.pointsSourceManager = undefined;

    this.trackSourceManager?.destroy();
    this.trackSourceManager = undefined;

    this.trackDragSourceManager?.destroy();
    this.trackDragSourceManager = undefined;

    this.trackSelectionHandler = NULL_TRACK_SELECTION_HANDLER;
    this.pointSelectionHandler = NULL_POINT_SELECTION_HANDLER;

    return super.destroy();
  }
}
