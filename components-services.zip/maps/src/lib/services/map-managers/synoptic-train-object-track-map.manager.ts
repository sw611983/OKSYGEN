/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable, of } from 'rxjs';

import { ISynopticMapManager, SYNOPTIC_MAP_MANAGER_TYPE } from '../../interfaces/map-managers/synoptic-map-manager.interface';
import { TrainObjectsTrackMapManager } from './train-objects-track-map.manager';

/**
 * Manages the state unique to this specific map. For example, a synoptic map has corridors.
 * this is the abstract base class for you to implement with any map specific functionality.
 */
export abstract class SynopticTrainObjectsTrackMapManager extends TrainObjectsTrackMapManager implements ISynopticMapManager {
  public override getManagerTypes(): Array<string> {
    return [...super.getManagerTypes(), SYNOPTIC_MAP_MANAGER_TYPE];
  }

  // synoptic style methods, optional as other map types won't need them
  // TODO consider other method to allow access to map specific functions
  public subscribeToCorridorNames?(): Observable<string[]> {
    return of([]);
  }

  public selectCorridor?(corridorName?: string): void {}

  public selectedCorridorName$?(): Observable<string> {
    return of(null);
  }
}
