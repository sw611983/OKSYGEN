/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef, NgZone } from '@angular/core';
import { isNil } from 'lodash';
import { LngLat, Map } from 'maplibre-gl';
import { BehaviorSubject, Observable, Subject, Subscription } from 'rxjs';

import { DragFeedback, SelfCompletingObservable, SUPER_WAS_CALLED, SuperCalled } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LngLatCoord, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData, Image, ObjectLayer } from '@oksygen-sim-train-libraries/components-services/common';

import { emptyGeoJSON, getGeoJSONFeaturesFromSource, Sources } from '../../helpers/mapbox.source';
import { IMapManager, MapManagerConfiguration } from '../../interfaces/map-managers/map-manager.interface';
import { DragLayerManager, LayerManager, SelectionValue, SourceManager } from '../../services/mapbox.layers';

export abstract class MapManager<C extends MapManagerConfiguration = MapManagerConfiguration> implements IMapManager {
  protected otherSourceManagers: Array<SourceManager> = [];

  protected mapReadySubject = new BehaviorSubject(false);
  protected dragData$ = new BehaviorSubject<DragData>(null);

  /**
   * A subject that fires updates when a source which affects world geometry is updated.
   */
  protected geometrySourceUpdated = new Subject<unknown>();

  protected sources: Sources;

  protected objectTypesSources: Array<string> = [];

  /** Note that order here is important, as it dictates the rendering order. */
  protected layerManagers: Array<LayerManager> = [];
  protected dragLayerManagers: Array<DragLayerManager> = [];

  protected worldBoundsSources: Array<string> = [];

  protected subscriptions = new Subscription();

  protected sourceManagersCreated = false;

  constructor(
    protected readonly logging: Logging,
    protected readonly registry: Registry,
    protected readonly zone: NgZone,
    protected readonly configuration: C
  ) {
    this.addLayerManagers();
  }

  clear(): SuperCalled {
    this.mapReadySubject.next(false);
    this.layerManagers?.forEach(lm => lm.clear());
    return SUPER_WAS_CALLED;
  }

  public destroy(): SuperCalled {
    this.mapReadySubject.complete();
    this.dragData$.complete();

    this.otherSourceManagers.forEach(sourceManager => sourceManager.destroy());
    this.otherSourceManagers = [];

    this.subscriptions.unsubscribe();

    this.geometrySourceUpdated.complete();

    return SUPER_WAS_CALLED;
  }

  public addLayerManagers(): void {}

  public getStyleSources(): Sources {
    if (!this.sources) {
      this.sources = {};

      this.getSources().forEach(source => (this.sources[source] = emptyGeoJSON()));
    }

    return this.sources;
  }

  /**
   * Return the types that the manager supports, this allows for type checking before casting to a particular interface
   */
  public getManagerTypes(): Array<string> {
    return [];
  }

  /**
   * Returns a list of source names, used by IAtlasManager.getStyleSources
   */
  protected getSources(): Array<string> {
    if (!this.sourceManagersCreated) {
      this.createSources();
    }

    return [];
  }

  protected createSources(): SuperCalled {
    this.sourceManagersCreated = true;

    return SUPER_WAS_CALLED;
  }

  public mapReady$(): Observable<boolean> {
    return this.mapReadySubject.asObservable(); // possibly should share
  }

  public geometrySourceUpdated$(): Observable<unknown> {
    return this.geometrySourceUpdated.asObservable();
  }

  /**
   * Attach mapbox layers to the mapbox map. Layers are used to tell mapbox HOW to render the data.
   * Note this doesn't tell mapbox what the data is, for that use attachSourcesTo().
   *
   * @param map the mapbox map to update
   */
  public attachLayersTo(map: Map, elRef: ElementRef, getDragPreview: (objectRef: any) => Element): SuperCalled {
    this.layerManagers.forEach(layerManager => {
      layerManager.attachLayerTo(map, elRef, getDragPreview);
    });

    this.setUpInputHandlers();

    return SUPER_WAS_CALLED;
  }

  /** Note that order here is important, as it dictates the click priority. */
  protected abstract setUpInputHandlers(): void;

  /**
   * Attach mapbox data to the mapbox map.
   * Also attach some data listeners to update the map when things update.
   * Note this doesn't tell mapbox HOW to render this data, for that use attachLayersTo().
   *
   * @param map the map to update
   * @param parentSubscription when this unsubscribes we'll unsubscribe our map updates
   */
  public attachSourcesTo(map: Map, parentSubscription: Subscription): SuperCalled {
    return SUPER_WAS_CALLED;
  }

  /**
   * Attach a list of images to the map. Returns observable of the progress.
   * Observable completes when all images are finished adding (ie, reaches 1).
   * You must subscribe to the returned obs for this to execute!
   *
   * @param map the map to attach images to
   * @param images the images to attach
   * @returns progress from [0, 1] of images added as they're added. IE, 0.5 when 2/4 images added.
   */
  public abstract attachImagesTo(map: Map, images: Array<Image>, batchSize?: number, delayBetweenBatches?: number): Observable<number>;

  public getHoverLayerName(): string | undefined {
    return undefined;
  }

  public registerClickHandler(selectedSubject: Subject<SelectionValue>, stopPropagation: boolean): void {
    this.dragLayerManagers?.forEach(layerManager => layerManager.registerClickHandler(selectedSubject, stopPropagation));
  }

  public addImagesToMap(
    addDirectionalImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    addDirectionalRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    addDirectionalTwoObjectsRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void
  ): void {
    this.layerManagers.forEach(layerManager =>
      layerManager.addImagesToMap(addDirectionalImageToMap, addDirectionalRingImageToMap, addDirectionalTwoObjectsRingImageToMap)
    );

    this.dragLayerManagers.forEach(layerManager =>
      layerManager.addImagesToMap(addDirectionalImageToMap, addDirectionalRingImageToMap, addDirectionalTwoObjectsRingImageToMap)
    );
  }

  public initDragInputHandling(map: Map, subscription: Subscription): void {
    this.dragLayerManagers?.forEach(layerManager => layerManager.attachLayerTo(map));
  }

  /**
   * Returns an observable which will supply data describing the item that is currently being dragged from the map.
   */
  public getDragData$(): Observable<DragData> {
    return this.dragData$.asObservable();
  }

  public onDrag(
    _dragData: DragData,
    _lngLat: LngLat,
    _lngLatCoord: LngLatCoord,
    _segOffset: SegOffsetOriented,
    _userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback> | undefined {
    return undefined;
  }

  public removeDragFeedback(): void {}

  public onDrop(_dragData: DragData, _lngLat: LngLat, _lngLatCoord: LngLatCoord, _segOffset: SegOffsetOriented, _userScale: UserScale[]): void {}

  public onDragLayersUpdate(layers: ObjectLayer[]): void {
    this.dragLayerManagers.forEach(layerManager => layerManager.onLayersUpdate(layers));
  }

  public updateWorldBounds(map: Map): Array<any> {
    const objects: any[] = [];

    this.worldBoundsSources.forEach(sourceName => objects.push(...getGeoJSONFeaturesFromSource(map, sourceName)));

    return objects;
  }

  protected mapHasSource(map: Map, id: string): boolean {
    return !isNil(map.getSource(id));
  }
}
