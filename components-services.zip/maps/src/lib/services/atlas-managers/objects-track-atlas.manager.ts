/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone, Type } from '@angular/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';

import { shareReplayOne, SuperCalled } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ObjectLayer } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer, ObjectTypeName, selectedObjectContainerComparator } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { MapType, Selector } from '../../interfaces/atlas-managers/atlas-manager.interface';
import {
  IObjectTrackAtlasManager,
  OBJECT_ATLAS_MANAGER_TYPE,
  ObjectTrackAtlasManagerConfiguration
} from '../../interfaces/atlas-managers/object-track-atlas-manager.interface';
import { IMapManager } from '../../interfaces/map-managers/map-manager.interface';
import { isObjectTrackMapManager, ObjectTrackMapManagerConfiguration } from '../../interfaces/map-managers/object-track-map-manager.interface';
import { ObjectSelectionHandler } from '../../interfaces/selection-handlers/selection-object.interface';
import { LineViewManager } from '../line-view/line-view.manager';
import { MinimapViewManager } from '../minimap-view/minimap-view.manager';
import { PlanViewObjectMapManager } from '../plan-view/plan-view-object.manager';
import { TrackAtlasManager } from './track-atlas.manager';

/**
 * Manages a related group of maps. Here, a "map" is (generally mapbox) map to be rendered on the screen.
 * Examples of maps are line view, plan view and synoptic view on Operator Station's in session screen.
 * Holds both shared map state (ie position, selected train)
 * as well as references to each map manager.
 */
export class ObjectsTrackAtlasManager<
    C extends ObjectTrackAtlasManagerConfiguration = ObjectTrackAtlasManagerConfiguration,
    MC extends ObjectTrackMapManagerConfiguration = ObjectTrackMapManagerConfiguration
  >
  extends TrackAtlasManager<C, MC>
  implements IObjectTrackAtlasManager
{
  readonly spotlitObjectsSubject: BehaviorSubject<ObjectContainer[]> = new BehaviorSubject([]);
  readonly selectedObjectSubject: BehaviorSubject<ObjectContainer> = new BehaviorSubject(null);

  readonly objectUpdatedSubject: BehaviorSubject<ObjectContainer> = new BehaviorSubject(null);
  readonly layerSubject: BehaviorSubject<ObjectLayer[]> = new BehaviorSubject([]);

  private selectedObjectSubscription = Subscription.EMPTY;
  public objectDeselected = false;

  constructor(configuration: C, logging: Logging, registry: Registry, zone: NgZone) {
    super(configuration, logging, registry, zone);

    this.selectedObjectSubject = new BehaviorSubject(null);
    this.spotlitObjectsSubject = new BehaviorSubject([]);
    this.objectUpdatedSubject = new BehaviorSubject(null);
    this.layerSubject = new BehaviorSubject(null);

    this.configuration.objectsSourceManagerConfiguration.setLayers(this.layerSubject.pipe(shareReplayOne()));
    this.configuration.objectsSourceManagerConfiguration.setSelectedObject(this.selectedObjectSubject.pipe(shareReplayOne()));
  }

  override getManagerTypes(): Array<string> {
    return [...super.getManagerTypes(), OBJECT_ATLAS_MANAGER_TYPE];
  }

  protected override getManagerType(type: MapType): Type<IMapManager> {
    let managerType: Type<IMapManager>;
    switch (type) {
      case MapType.PLAN:
        managerType = PlanViewObjectMapManager;
        break;
      case MapType.MINIMAP:
        managerType = MinimapViewManager;
        break;
      case MapType.LINE:
        managerType = LineViewManager;
        break;
      default:
        throw new Error('Map type must either be a known type or a component.');
    }

    return managerType;
  }

  override clear(): SuperCalled {
    this.selectObject(null);
    this.objectUpdatedSubject.next(null);
    return super.clear();
  }

  override destroy(): SuperCalled {
    this.selectedObjectSubject.complete();
    this.spotlitObjectsSubject.complete();
    this.objectUpdatedSubject.complete();
    this.selectedObjectSubscription.unsubscribe();

    return super.destroy();
  }

  async selectObject(objectId: number): Promise<void> {
    if (!objectId) {
      this.selectedObjectSubject.next(null);
    }

    if (this.selectedObjectSubscription) {
      this.selectedObjectSubscription.unsubscribe();
      this.selectedObjectSubscription = null;
    }

    this.selectedObjectSubscription = this.configuration.getObject$(objectId, false).subscribe(async object => {
      if (!object) {
        return;
      }

      if (this.objectDeselected) {
        return;
      }

      this.selectedObjectSubject.next(object);
    });
  }

  setObjectDeselected(): void {
    this.objectDeselected = false;
  }

  async spotlightObject(objectId: number): Promise<void> {
    if (!objectId) {
      return;
    }
    const sub = this.configuration.getObject$(objectId).subscribe(async object => {
      if (!object) {
        return;
      }
      if (object?.objectType?.name === ObjectTypeName.POINT) {
        return;
      }
      this.spotlitObjectsSubject.value.push(object);
      this.spotlitObjectsSubject.next(this.spotlitObjectsSubject.value);
    });
    sub?.unsubscribe();
  }

  removeSpotlightObject(objectId: number): void {
    const objects = this.spotlitObjectsSubject.value.filter(m => m.id !== objectId);
    this.spotlitObjectsSubject.next(objects);
  }

  override clearSpotlights(): void {
    super.clearSpotlights();

    this.spotlitObjectsSubject.value.length = 0; // clear array
    this.spotlitObjectsSubject.next(this.spotlitObjectsSubject.value);
  }

  /**
   * Note this will NOT fire if the selected object changes.
   * ONLY fires when a different object is selected.
   * If you want object updates, you can subscribe to ```selectedObjectSubject``` directly.
   */
  getSelectedObject(): Observable<ObjectContainer> {
    return this.selectedObjectSubject.pipe(distinctUntilChanged(selectedObjectContainerComparator));
  }

  filterObjects(layers: ObjectLayer[]): void {
    this.layerSubject.next(layers);
  }

  /**
   * Sets the object selection handler if no handler is currently active.
   * ```clearObjectSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public setObjectSelectionHandler(selector: Selector, handler: ObjectSelectionHandler): void {
    const manager = this.getMapManager(selector.type, selector.name);

    if (isObjectTrackMapManager(manager)) {
      manager.setObjectSelectionHandler(handler);
    }
  }

  /**
   * Clears the train selection handler, allowing other handlers to be attached.
   */
  public clearObjectSelectionHandler(selector: Selector): void {
    const manager = this.getMapManager(selector.type, selector.name);

    if (isObjectTrackMapManager(manager)) {
      manager.clearObjectSelectionHandler();
    }
  }
}
