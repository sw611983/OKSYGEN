/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone, Type } from '@angular/core';
import { isEqual, isNil } from 'lodash';
import { BehaviorSubject, Observable, of, Subscription } from 'rxjs';
import { map, pairwise, switchMap } from 'rxjs/operators';

import { filterTruthy, shareReplayOne, SuperCalled } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';

import { MapType, Selector } from '../../interfaces/atlas-managers/atlas-manager.interface';
import {
  TRAIN_ATLAS_MANAGER_TYPE,
  TrainObjectTrackAtlasManagerConfiguration,
  ITrainObjectTrackAtlasManager
} from '../../interfaces/atlas-managers/train-object-track-atlas-manager.interface';
import { IMapManager } from '../../interfaces/map-managers/map-manager.interface';
import { isTrainObjectTrackMapManager, TrainObjectTrackMapManagerConfiguration } from '../../interfaces/map-managers/train-object-track-map-manager.interface';
import { TrainSelectionHandler } from '../../interfaces/selection-handlers/selection-train.interface';
import { LineViewManager } from '../line-view/line-view.manager';
import { MinimapViewManager } from '../minimap-view/minimap-view.manager';
import { PlanViewTrainMapManager } from '../plan-view/plan-view-train.manager';
import { ObjectsTrackAtlasManager } from './objects-track-atlas.manager';
import { IReachablePath } from '@oksygen-sim-train-libraries/components-services/common';
import { MapMovementType } from '../../models/map-view-info.model';

/**
 * Manages a related group of maps. Here, a "map" is (generally mapbox) map to be rendered on the screen.
 * Examples of maps are line view, plan view and synoptic view on Operator Station's in session screen.
 * Holds both shared map state (ie position, selected train)
 * as well as references to each map manager.
 */
export class TrainObjectsTrackAtlasManager<
    C extends TrainObjectTrackAtlasManagerConfiguration = TrainObjectTrackAtlasManagerConfiguration,
    MC extends TrainObjectTrackMapManagerConfiguration = TrainObjectTrackMapManagerConfiguration
  >
  extends ObjectsTrackAtlasManager<C, MC>
  implements ITrainObjectTrackAtlasManager
{
  readonly spotlitTrainSubject: BehaviorSubject<UsefulTrain> = new BehaviorSubject(null);

  /**
   * Indicates which path should be shown on the line view.
   * In the future this may be expanded to allow corridors to be supplied.
   */
  public lineViewPathSubject: BehaviorSubject<IReachablePath> = new BehaviorSubject(null);

  /**
   * Indicates which path (and related objects) should be highlighted on the map views.
   * Typically associated with train selection.
   */
  public highlightedPathSubject: BehaviorSubject<IReachablePath> = new BehaviorSubject(null);

  /** Holds the train that was last passed to updatePath(). */
  private highlightedPathTrain: UsefulTrain;
  private highlightedPathTrainDataSub: Subscription;
  /**
   * Will have the train id that the path is selected for,
   * or -1 if no train is selected or the path is toggled off.
   */
  private pathTrainIdSubject: BehaviorSubject<number> = new BehaviorSubject(null);

  constructor(configuration: C, logging: Logging, registry: Registry, zone: NgZone) {
    super(configuration, logging, registry, zone);

    const highlightedPath$ = this.highlightedPathSubject.pipe(shareReplayOne());

    this.mapManagerConfiguration = { ...configuration, highlightedPath$ } as any;

    this.configuration.objectsSourceManagerConfiguration.setHighlightedPath(highlightedPath$);

    this.spotlitTrainSubject = new BehaviorSubject(null);
    this.pathTrainIdSubject = new BehaviorSubject(null);

    // FIXME use TrainUtilities?
    this.subscription.add(
      this.mapTogglesSubject
        .pipe(
          switchMap(t => (t.follow && !isNil(this.configuration.selectedTrain$) ? this.configuration.selectedTrain$ : of(null))),
          pairwise()
        )
        .subscribe(([prevTrain, train]) => {
          // use the previous and current train to know if this is the first attempt to go to the train
          const location = train?.vehicles?.[0]?.position?.lnglat?.[0];
          if (location) {
            this.mapGoto(location, undefined, MapMovementType.PAN);
          }
        })
    );

    if (!isNil(this.configuration.selectedTrain$)) {
      this.subscription.add(
        this.configuration.selectedTrain$.subscribe(train => {
          if (train?.path) {
            const prevPath = this.lineViewPathSubject.getValue();
            if (!isEqual(train.path, prevPath)) {
              this.lineViewPathSubject.next(train.path);
            }
          }
        })
      );
    }
  }

  override getManagerTypes(): Array<string> {
    return [...super.getManagerTypes(), TRAIN_ATLAS_MANAGER_TYPE];
  }

  protected override getManagerType(type: MapType): Type<IMapManager> {
    let managerType: Type<IMapManager>;
    switch (type) {
      case MapType.PLAN:
        managerType = PlanViewTrainMapManager;
        break;
      case MapType.MINIMAP:
        managerType = MinimapViewManager;
        break;
      case MapType.LINE:
        managerType = LineViewManager;
        break;
      default:
        throw new Error('Map type must either be a known type or a component.');
    }

    return managerType;
  }

  override clear(): SuperCalled {
    this.lineViewPathSubject.next(null);
    this.clearHighlightedPath();
    return super.clear();
  }

  override destroy(): SuperCalled {
    this.lineViewPathSubject?.complete();
    this.highlightedPathSubject?.complete();
    this.pathTrainIdSubject?.complete();
    this.highlightedPathTrainDataSub?.unsubscribe();

    this.configuration.objectsSourceManagerConfiguration.destroy();

    return super.destroy();
  }

  async spotlightTrain(scenarioTrainId: number): Promise<void> {
    if (!scenarioTrainId) {
      return;
    }
    const sub = this.configuration.trains$.subscribe(async trains => {
      this.spotlitTrainSubject.next(trains?.find(t => t.id === scenarioTrainId));
      this.spotlitTrainSubject.next(null);
    });
    sub?.unsubscribe();
  }

  override clearSpotlights(): void {
    super.clearSpotlights();

    this.spotlitTrainSubject.next(null);
  }

  // FIXME We should probably make this accept the train to be followed, rather than assuming that we want to follow the selected train.
  // TODO In the long term this should be able to target anything that moves (road vehicles, pedestrians, etc).
  followTrain(follow: boolean): void {
    // TODO consider doing this RXJS style rather than imperitive
    const toggles = this.mapTogglesSubject.getValue();

    if (toggles.follow !== follow) {
      const updateToggles = { ...toggles };
      updateToggles.follow = follow;
      this.mapTogglesSubject.next(updateToggles);
    }
  }

  public clearHighlightedPath(): void {
    this.pathTrainIdSubject.next(null);
    this.highlightedPathTrain = null;
    this.highlightedPathSubject.next(null);
  }

  /**
   * Toggles whether a train's path is higlighted in map views.
   * This usually means non-highlighted tracks and their objects are made less prominant.
   *
   * If a train is supplied, and different to the train currently the focus of path highlighting, the new train will be used.
   * If the currently focused train is supplied again, or nothing is supplied, highlighting is switched off.
   *
   * @param train Optional train whose path we want highlighted.
   */
  public toggleHighlightedPath(train?: UsefulTrain): void {
    // If we get the same train we toggle it off.
    const isSameTrain = this.highlightedPathTrain?.id === train?.id;
    this.highlightedPathTrain = isSameTrain ? null : train;

    // Manage the path toggle state and publish updates to the pathTrain

    // TODO consider doing this RXJS style rather than imperitive
    const toggles = { ...this.mapTogglesSubject.getValue() };

    // If it's a new train we show the path if the train is valid, otherwise we toggle.
    toggles.path = !isNil(this.highlightedPathTrain);

    this.pathTrainIdSubject.next(this.highlightedPathTrain?.id ?? -1);
    this.mapTogglesSubject.next(toggles);

    // Manage updates to the train position

    this.highlightedPathTrainDataSub?.unsubscribe();

    if (this.highlightedPathTrain) {
      this.highlightedPathTrainDataSub = this.configuration.trains$
        .pipe(
          filterTruthy(),
          map(trains => trains.find(t => t.id === train.id)),
          filterTruthy()
        )
        .subscribe(t => {
          this.highlightedPathTrain = t;
          const newPath = t.path;
          const oldPath = this.highlightedPathSubject.getValue();

          if (!isEqual(newPath, oldPath)) {
            this.highlightedPathSubject.next(newPath);
          }
        });
    } else {
      this.highlightedPathSubject.next(undefined);
    }
  }

  getPathTrain(): UsefulTrain {
    return this.highlightedPathTrain;
  }

  getPathTrainId$(): Observable<number> {
    return this.pathTrainIdSubject.pipe(shareReplayOne());
  }

  /**
   * Sets the train selection handler if no handler is currently active.
   * ```clearTrainSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public setTrainSelectionHandler(selector: Selector, handler: TrainSelectionHandler): void {
    const manager = this.getMapManager(selector.type, selector.name);

    if (isTrainObjectTrackMapManager(manager)) {
      manager.setTrainSelectionHandler(handler);
    }
  }

  /**
   * Clears the train selection handler, allowing other handlers to be attached.
   */
  public clearTrainSelectionHandler(selector: Selector): void {
    const manager = this.getMapManager(selector.type, selector.name);

    if (isTrainObjectTrackMapManager(manager)) {
      manager.clearTrainSelectionHandler();
    }
  }
}
