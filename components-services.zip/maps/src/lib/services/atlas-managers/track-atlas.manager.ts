/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone, Type } from '@angular/core';
import { GeoJSONSourceSpecification } from 'maplibre-gl';
import { BehaviorSubject, interval, of, Subscription } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

import {
  computeIfAbsent,
  SelfCompletingObservable,
  selfCompletingObservable,
  shareReplayOne,
  SUPER_WAS_CALLED,
  SuperCalled
} from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';

import { AbstractMapViewComponent } from '../../components/map-view/map-view.component';
import { ComponentSelector, IAtlasMapComponent, MapType, Selector } from '../../interfaces/atlas-managers/atlas-manager.interface';
import {
  ITrackAtlasManager,
  TRACK_ATLAS_MANAGER_TYPE,
  TrackAtlasManagerConfiguration
} from '../../interfaces/atlas-managers/track-atlas-manager.interface';
import { MapViewState } from '../../interfaces/map-component.interface';
import { IMapManager } from '../../interfaces/map-managers/map-manager.interface';
import { isTrackMapManager, TrackMapManagerConfiguration } from '../../interfaces/map-managers/track-map-manager.interface';
import { PointSelectionHandler } from '../../interfaces/selection-handlers/selection-point.interface';
import { TrackSelectionHandler } from '../../interfaces/selection-handlers/selection-track.interface';
import { MapMovementType, MapViewInfo, ZoomLevel } from '../../models/map-view-info.model';
import { MapToggles } from '../../models/map.model';

export function getMapComponentWhenReady(atlasManager: ITrackAtlasManager, selector: ComponentSelector): SelfCompletingObservable<IAtlasMapComponent> {
  return selfCompletingObservable(
    interval(250).pipe(
      switchMap(_ => atlasManager.getMapComponent(selector)?.mapViewReadySubject.pipe(shareReplayOne()) ?? of(undefined)),
      map(mapState => {
        if (mapState === MapViewState.READY) {
          return atlasManager.getMapComponent(selector);
        }

        return undefined;
      })
    )
  );
}

/**
 * Manages a related group of maps. Here, a "map" is (generally mapbox) map to be rendered on the screen.
 * Examples of maps are line view, plan view and synoptic view on Operator Station's in session screen.
 * Holds both shared map state (ie position, selected train)
 * as well as references to each map manager.
 */
export class TrackAtlasManager<C extends TrackAtlasManagerConfiguration, MC extends TrackMapManagerConfiguration> implements ITrackAtlasManager {
  readonly typeIdSeparator = '_';
  readonly mapTogglesSubject = new BehaviorSubject<MapToggles>({ follow: false, path: true });

  /**
   * Emits requests for the main map view to move to a specific point.
   * Send requests using {@link mapGoto}.
   * Once a request is serviced, {@link clearMapGoto} should be called.
   */
  readonly worldMapLngLatSubject: BehaviorSubject<MapViewInfo> = new BehaviorSubject(null);
  /** a map of map managers! Typically, will contain plan, synoptic, line & mini map. */
  mapManagers: Map<string, IMapManager> = new Map();
  /** a map of map components! Typically, will contain plan, synoptic, line & mini map. */
  mapComponents: Map<string, AbstractMapViewComponent<any, any>> = new Map();

  protected subscription = new Subscription();

  protected mapManagerConfiguration: MC;

  constructor(
    protected readonly configuration: C,
    protected readonly logging: Logging,
    protected readonly registry: Registry,
    protected readonly zone: NgZone
  ) {
    this.mapTogglesSubject = new BehaviorSubject<MapToggles>({ follow: false, path: true });
    this.worldMapLngLatSubject = new BehaviorSubject(null);

    this.mapManagerConfiguration = { ...configuration } as any;
  }

  getManagerTypes(): Array<string> {
    return [TRACK_ATLAS_MANAGER_TYPE];
  }

  getManager(selector: Selector): IMapManager {
    return this.getMapManager(selector.type, selector.name);
  }

  /**
   * Register a map with our map management system.
   *
   * @param name the name / id of the map
   * @param type the type of the map
   */
  getMapManager(type: MapType | Type<IMapManager>, name?: string): IMapManager {
    const key = this.toMapKey(name, type);

    return computeIfAbsent(this.mapManagers, key, id => this.createNewMapManager(type));
  }

  protected createNewMapManager(type: MapType | Type<IMapManager>): IMapManager {
    let managerType: Type<IMapManager>;
    if (typeof type === 'string') {
      managerType = this.getManagerType(type);
    } else {
      managerType = type;
    }

    return new managerType(this.logging, this.registry, this.zone, this.mapManagerConfiguration);
  }

  protected getManagerType(type: MapType): Type<IMapManager> {
    throw new Error('Map type must either be a known type or a component.');
  }

  /**
   * Register a map with our map management system.
   *
   * @param name the name / id of the map
   * @param type the type of the map
   */
  registerMapComponent(selector: ComponentSelector, component: AbstractMapViewComponent<any, any>): void {
    const key = this.toMapKey(selector.name, selector.type);

    this.mapComponents.set(key, component);
  }

  getMapComponent(selector: ComponentSelector): AbstractMapViewComponent<any, any> {
    return this.mapComponents.get(this.toMapKey(selector.name, selector.type));
  }

  protected toMapKey(name: string, type: string | Type<IMapManager>): string {
    return name ? `${type}${this.typeIdSeparator}${name}` : `${type}`;
  }

  clear(): SuperCalled {
    this.mapManagers.forEach(m => m.clear());
    this.mapComponents.clear();
    this.clearSpotlights();
    return SUPER_WAS_CALLED;
  }

  destroy(): SuperCalled {
    this.mapManagers.forEach(m => m.destroy());
    this.mapManagers.clear();
    this.mapTogglesSubject.complete();
    this.worldMapLngLatSubject.complete();
    this.subscription.unsubscribe();

    return SUPER_WAS_CALLED;
  }

  protected emptyGeoJSON(): GeoJSONSourceSpecification {
    return { type: 'geojson', data: null };
  }

  clearSpotlights(): void {}

  // TODO We will probably need to update this to apply some extra smarts rather than blindly setting the position.
  // For example, we may want to specify whether this is a system generated or user genereated request, etc.
  mapGoto(lngLat: LngLatCoord, zoom?: ZoomLevel, movementType = MapMovementType.FLY): void {
    if (!lngLat || lngLat.length !== 2 || !lngLat[0] || !lngLat[1]) {
      this.logging.warn(`Ignoring invalid location supplied to mapGoto: ${lngLat}`);
      return;
    }

    this.worldMapLngLatSubject.next({ lngLat, zoom, movementType });
  }

  /**
   * Clears the request made to {@link mapGoto}.
   * Should be called once the request, delivered by {@link worldMapLngLatSubject}, has been serviced.
   */
  clearMapGoto(): void {
    this.worldMapLngLatSubject.next(null);
  }

  /**
   * Sets the track selection handler if no handler is currently active.
   * ```clearTrackSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public setTrackSelectionHandler(selector: Selector, handler: TrackSelectionHandler): void {
    if (selector && selector.type) {
      const manager = this.getMapManager(selector.type, selector.name);
      if (isTrackMapManager(manager)) {
        manager.setTrackSelectionHandler(handler);
      }
    }
  }

  /**
   * Clears the track selection handler, allowing other handlers to be attached.
   */
  public clearTrackSelectionHandler(selector: Selector): void {
    const manager = this.getMapManager(selector.type, selector?.name);

    if (isTrackMapManager(manager)) {
      manager.clearTrackSelectionHandler();
    }
  }

  /**
   * Sets the point selection handler if no handler is currently active.
   * ```clearPointSelectionHandler``` needs to be called once the selection is complete to allow other selection handlers to be attached.
   *
   * @param handler The new handler.
   */
  public setPointSelectionHandler(selector: Selector, handler: PointSelectionHandler): void {
    const manager = this.getMapManager(selector.type, selector.name);

    if (isTrackMapManager(manager)) {
      manager.setPointSelectionHandler(handler);
    }
  }

  /**
   * Clears the point selection handler, allowing other handlers to be attached.
   */
  public clearPointSelectionHandler(selector: Selector): void {
    const manager = this.getMapManager(selector.type, selector.name);

    if (isTrackMapManager(manager)) {
      manager.clearPointSelectionHandler();
    }
  }
}
