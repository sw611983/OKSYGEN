/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef, NgZone } from '@angular/core';
import Point from '@mapbox/point-geometry';
import { CircleLayerSpecification, ExpressionSpecification, LineLayerSpecification, LngLat, Map, MapGeoJSONFeature } from 'maplibre-gl';
import { Subject } from 'rxjs';

import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';

import { MapColor } from '../../../helpers/map-color.enum';
import { MapInputEventData } from '../../../helpers/mapbox.source';
import { RawTrainSelectionHandler } from '../../../interfaces/selection-handlers/selection-train.interface';
import { LayerManager, SelectionType, SelectionValue } from '../../mapbox.layers';
import { TRAINS_SOURCE_NAME } from './trains-source-manager';

export const TRAINS_LAYER_NAME = 'vehicles';

export class TrainsLayerManager extends LayerManager {
  private static readonly FRONT_LAYER_NAME = 'front';
  private static readonly CONNECTED_VEHICLES_LAYER_NAME = 'connectedVehicles';
  public static readonly TRAIN_HOVER_LAYER_NAME = 'trainHover';
  private static readonly OUTLINE_CUTOUT_LAYER_NAME = 'trainHaloInner';
  private static readonly OUTLINE_LAYER_NAME = 'trainHaloOuter';
  private static readonly TRAIN_HAS_DRIVER: ExpressionSpecification = ['==', ['get', 'hasDriver'], true];
  private static readonly TRAIN_IS_AI: ExpressionSpecification = ['==', ['get', 'isAi'], true];
  private static readonly TRAIN_IS_USER: ExpressionSpecification = ['==', ['get', 'isAi'], false];
  private static readonly TRAIN_SELECTED: ExpressionSpecification = ['==', ['get', 'selected'], true];
  private static readonly DRIVERLESS_TRAIN_COLOUR = ThemeColorHex.GREY_600; // color-grey-600
  private static readonly AI_TRAIN_COLOUR = ThemeColorHex.ACCENT; //  red (color-accent)
  private static readonly SIM_TRAIN_COLOUR = ThemeColorHex.PRIMARY; // blue (color-primary)
  static readonly VEHICLE_COLOUR_EXP: ExpressionSpecification = [
    'case',
    TrainsLayerManager.TRAIN_HAS_DRIVER,
    ['case', TrainsLayerManager.TRAIN_IS_USER, TrainsLayerManager.SIM_TRAIN_COLOUR, TrainsLayerManager.AI_TRAIN_COLOUR],
    TrainsLayerManager.DRIVERLESS_TRAIN_COLOUR
  ];
  private static readonly TRAIN_HOVER_LINE_WIDTH_EXP: ExpressionSpecification = [
    'interpolate',
    ['linear'],
    ['zoom'],
    // set the max zoom level to apply thin line style, and the width of that line
    12,
    20,
    // set the min zoom level to apply thick line style, and the width of that line
    20,
    20
  ];
  static readonly TRAIN_USER_HALO_INNER_LINE_WIDTH_EXP: ExpressionSpecification = [
    'interpolate',
    ['linear'],
    ['zoom'],
    // set the max zoom level to apply thin line style, and the width of that line
    12,
    8,
    // set the min zoom level to apply thick line style, and the width of that line
    20,
    12
  ];
  static readonly TRAIN_USER_HALO_OUTER_LINE_WIDTH_EXP: ExpressionSpecification = [
    'interpolate',
    ['linear'],
    ['zoom'],
    // set the max zoom level to apply thin line style, and the width of that line
    12,
    13,
    // set the min zoom level to apply thick line style, and the width of that line
    20,
    15
  ];
  static readonly FILTER_USE_FRONT_DATA_EXP: ExpressionSpecification = ['get', 'isFront'];
  static readonly FILTER_USE_INDIVIDUAL_VEHICLE_DATA_EXP: ExpressionSpecification = ['!', ['get', 'isConnected']];
  static readonly FILTER_USE_WHOLE_TRAIN_DATA_EXP: ExpressionSpecification = ['get', 'isConnected'];

  private hoveredTrainId: number;

  private map: Map;
  // FIXME dragData should be format {type: 'foo', data: dataObj}
  private dragData: any;
  private rawInputHandler: RawTrainSelectionHandler;

  constructor(zone: NgZone) {
    super(TRAINS_LAYER_NAME, undefined, zone);
  }

  public override clear(): void {
    this.map = null;
    this.rawInputHandler = null;
    this.hoveredTrainId = null;
  }

  public attachLayerTo(map: Map, _elRef: ElementRef, _getDragPreview: (objectRef: any) => Element): void {
    if (this.map) {
      throw new Error(`Can't attach to multiple maps!`);
    }

    if (!map) {
      throw new Error(`Can't attach to null maps!`);
    }

    this.map = map;

    if (this.mapHasSource(map, TRAINS_SOURCE_NAME)) {
      const userHighlightColour = ThemeColorHex.PRIMARY_LIGHT;
      const aiHighlightColour = ThemeColorHex.ACCENT_100;
      const selectedColour = MapColor.YELLOW;
      const haloInnerColor = ThemeColorHex.WHITE;
      const type = 'line';
      const connectedLineWidth = 4;
      const zoomedInVehicleLineWidth = 8;
      const vehicleWidthExp: ExpressionSpecification = [
        'interpolate',
        ['linear'],
        ['zoom'],
        // set the max zoom level to apply thin line style, and the width of that line
        12,
        connectedLineWidth,
        // set the min zoom level to apply thick line style, and the width of that line
        20,
        8
      ];
      const dotZoomedInStroke = 1.75;
      const dotZoomedOutStroke = 1;
      const frontDotStrokeExp: ExpressionSpecification = [
        'interpolate',
        ['linear'],
        ['zoom'],
        // set the max zoom level to apply thin line style, and the width of that line
        12,
        dotZoomedOutStroke,
        // set the min zoom level to apply thick line style, and the width of that line
        20,
        dotZoomedInStroke
      ];
      const frontDotRadiusExp: ExpressionSpecification = [
        'interpolate',
        ['linear'],
        ['zoom'],
        // set the max zoom level to apply thin line style, and the width of that line
        12,
        (connectedLineWidth - dotZoomedOutStroke) / 2 - 0.1, // The dot looks just slightly larger than the line without this adjustment.
        // set the min zoom level to apply thick line style, and the width of that line
        20,
        (zoomedInVehicleLineWidth - dotZoomedInStroke) / 2 - 0.1 // The dot looks just slightly larger than the line without this adjustment.
      ];

      const frontLayer: CircleLayerSpecification = {
        id: TrainsLayerManager.FRONT_LAYER_NAME,
        type: 'circle',
        source: TRAINS_SOURCE_NAME,
        paint: {
          'circle-radius': frontDotRadiusExp,
          'circle-color': ThemeColorHex.GREY_200,
          'circle-stroke-width': frontDotStrokeExp,
          'circle-stroke-color': TrainsLayerManager.VEHICLE_COLOUR_EXP
        },
        filter: TrainsLayerManager.FILTER_USE_FRONT_DATA_EXP
      };

      const vehicleLayer: LineLayerSpecification = {
        id: TRAINS_LAYER_NAME,
        type,
        source: TRAINS_SOURCE_NAME,
        minzoom: 14,
        paint: {
          'line-width': vehicleWidthExp,
          'line-color': TrainsLayerManager.VEHICLE_COLOUR_EXP
        },
        filter: TrainsLayerManager.FILTER_USE_INDIVIDUAL_VEHICLE_DATA_EXP
      };

      const connectedVehiclesLayer: LineLayerSpecification = {
        id: TrainsLayerManager.CONNECTED_VEHICLES_LAYER_NAME,
        type,
        source: TRAINS_SOURCE_NAME,
        minzoom: 1,
        maxzoom: 14.5,
        paint: {
          'line-width': connectedLineWidth,
          'line-color': TrainsLayerManager.VEHICLE_COLOUR_EXP
        },
        layout: {
          'line-cap': 'round'
        },
        filter: TrainsLayerManager.FILTER_USE_WHOLE_TRAIN_DATA_EXP
      };

      const hoverLayer: LineLayerSpecification = {
        id: TrainsLayerManager.TRAIN_HOVER_LAYER_NAME,
        type,
        source: TRAINS_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': TrainsLayerManager.TRAIN_HOVER_LINE_WIDTH_EXP,
          // Note that any opacity other than 1 or 0 on this layer looks pretty trash due to https://github.com/mapbox/mapbox-gl-js/issues/4090
          'line-opacity': ['case', TrainsLayerManager.IS_HOVER, 1, TrainsLayerManager.TRAIN_SELECTED, 1, 0],
          'line-color': [
            'case',
            TrainsLayerManager.TRAIN_SELECTED,
            selectedColour, // if train is AI colour is ai
            TrainsLayerManager.TRAIN_IS_AI,
            aiHighlightColour, // if train is AI colour is ai
            userHighlightColour // else user colour
          ]
        },
        layout: {
          // this is a bit of a hack - our "train" is a series of thick vehicles, so extend the ends and it overlaps
          'line-cap': 'round'
        },
        filter: TrainsLayerManager.FILTER_USE_WHOLE_TRAIN_DATA_EXP
      };

      const connectedVehiclesOutlineCutout: LineLayerSpecification = {
        id: TrainsLayerManager.OUTLINE_CUTOUT_LAYER_NAME,
        type,
        source: TRAINS_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': TrainsLayerManager.TRAIN_USER_HALO_INNER_LINE_WIDTH_EXP,
          // Note that any opacity other than 1 or 0 on this layer looks pretty trash due to https://github.com/mapbox/mapbox-gl-js/issues/4090
          'line-opacity': 1,
          'line-color': haloInnerColor
        },
        layout: {
          'line-cap': 'round'
        },
        filter: TrainsLayerManager.FILTER_USE_WHOLE_TRAIN_DATA_EXP
      };

      const connectedVehiclesOutline: LineLayerSpecification = {
        id: TrainsLayerManager.OUTLINE_LAYER_NAME,
        type,
        source: TRAINS_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': TrainsLayerManager.TRAIN_USER_HALO_OUTER_LINE_WIDTH_EXP,
          // Note that any opacity other than 1 or 0 on this layer looks pretty trash due to https://github.com/mapbox/mapbox-gl-js/issues/4090
          'line-opacity': 1,
          'line-color': TrainsLayerManager.VEHICLE_COLOUR_EXP
        },
        layout: {
          'line-cap': 'round'
        },
        filter: TrainsLayerManager.FILTER_USE_WHOLE_TRAIN_DATA_EXP
      };

      map.addLayer(hoverLayer); // bottom layer
      map.addLayer(connectedVehiclesOutline);
      map.addLayer(connectedVehiclesOutlineCutout);
      map.addLayer(connectedVehiclesLayer);
      map.addLayer(vehicleLayer);
      map.addLayer(frontLayer); // top layer
    }

    // Note that using 'mouseenter' seems like it would be more performant,
    // but it allows the previous set of points to remain highlighted if the mouse moves quickly to a new set.
    this.zone?.runOutsideAngular(() => {
      map.on('mousemove', TrainsLayerManager.TRAIN_HOVER_LAYER_NAME, e => {
        this.zone?.runOutsideAngular(() => {
          if (!e.originalEvent.defaultPrevented) {
            map.getCanvas().style.cursor = 'pointer';
            if (e?.features?.length > 0) {
              this.updateHover(map, Number(e.features[0].id));
            }
          }
        });
      });
    });
    map.on('mouseleave', TrainsLayerManager.TRAIN_HOVER_LAYER_NAME, e => {
      this.zone?.runOutsideAngular(() => {
        map.getCanvas().style.cursor = '';
        this.updateHover(map, null);
      });
    });
  }

  private updateHover(map: Map, newId: number | null): void {
    if (this.hoveredTrainId) {
      this.setTrainHoverState(map, this.hoveredTrainId, false);
    }

    if (newId) {
      this.hoveredTrainId = newId;
      this.setTrainHoverState(map, this.hoveredTrainId, true);
    }
  }

  private setTrainHoverState(map: Map, trainId: number, hover: boolean): void {
    const source = TRAINS_SOURCE_NAME;

    // todo this is currently vehicleId!!!
    map.setFeatureState({ source, id: trainId }, { hover });
  }

  public override registerClickHandler(selectedSubject: Subject<SelectionValue>, stopPropagation: boolean): void {
    this.map.on('click', TrainsLayerManager.TRAIN_HOVER_LAYER_NAME, event => {
      if (event?.features?.length > 0 && !event.originalEvent.defaultPrevented) {
        // TODO handle multiple entities being clicked on at once...
        if (stopPropagation) {
          event.originalEvent.preventDefault();
        }
        selectedSubject.next({ type: SelectionType.TRAIN, id: event.features[0].properties.trainId });
      }
    });
  }

  /**
   * Sets a handler for handling "raw" callbacks from listeners on the Mapbox map.
   *
   * @param rawHandler Contains the callbacks that handle updates.
   */
  override setInputHandler(rawHandler: RawTrainSelectionHandler): void {
    if (!rawHandler) {
      rawHandler = {
        onTrainHovered: (id: number, data: any): void => {},
        onTrainClicked: (id: number, data: any): void => {},
        onTrainDown: (id: number, data: any): boolean => false
      };
    }

    const firstCall = !this.rawInputHandler;

    this.rawInputHandler = rawHandler;

    // Don't set extra listeners.
    if (!firstCall) {
      return;
    }

    // Handling interaction with the trains

    const onTrainHover = (e: MapInputEventData): void => {
      this.zone?.runOutsideAngular(() => {
        this.interactWithTrain(this.rawInputHandler.onTrainHovered, this.map, e, [TrainsLayerManager.TRAIN_HOVER_LAYER_NAME]);
      });
    };
    this.map.on('mousemove', TrainsLayerManager.TRAIN_HOVER_LAYER_NAME, onTrainHover);

    this.map.on('click', TrainsLayerManager.TRAIN_HOVER_LAYER_NAME, e => {
      this.interactWithTrain(this.rawInputHandler.onTrainClicked, this.map, e, [TrainsLayerManager.TRAIN_HOVER_LAYER_NAME]);
    });

    const onTrainDown = (e: MapInputEventData): void => {
      if (this.interactWithTrain(this.rawInputHandler.onTrainDown, this.map, e, [TrainsLayerManager.TRAIN_HOVER_LAYER_NAME])) {
        // Prevent the default map drag behavior.
        // Allows the HTML5 drag interaction to begin.
        e.preventDefault();
      }
    };

    this.map.on('mousedown', TrainsLayerManager.TRAIN_HOVER_LAYER_NAME, e => {
      this.map.getCanvas().style.cursor = 'grab';
      onTrainDown(e);
    });

    this.map.on('touchstart', TrainsLayerManager.TRAIN_HOVER_LAYER_NAME, e => {
      if (e.points.length !== 1) return;
      onTrainDown(e);
    });
  }

  // TODO very similar to code in ObjectsLayerManager. Commonise?
  /**
   * Does some quick sanity checks before initiating an interaction with the clicked location.
   *
   * @param callback invoked when a geojson feature (in this typically means tracks or selection markers) is near the clicked location.
   *   May return a boolean to indicate whether the interaction should proceed (typically only applicable for the start of a drag.)
   * @param alwaysFire indicates whether we should invoke the callback when there are no features near the point.
   *
   * @returns a boolean indicating whether the interaction should proceed.
   */
  private interactWithTrain(
    callback: (id: number, lngLat: LngLat, data: any) => void | boolean,
    map: Map,
    e: any,
    layers: string[],
    alwaysFire = false
  ): boolean {
    const featuresNearClick = e.point ? this.getFeaturesFuzzy(map, e.point, layers) : [];

    if (alwaysFire || featuresNearClick?.length > 0) {
      this.dragData = featuresNearClick?.[0]?.properties?.dragData ?? this.dragData;
      return !!callback(featuresNearClick[0].properties.trainId as number, e.lngLat, JSON.parse(this.dragData));
    }

    return false;
  }

  // TODO very similar to code in ObjectsLayerManager. Commonise?
  private getFeaturesFuzzy(map: Map, point: Point, layers: string[]): MapGeoJSONFeature[] {
    // Consider npx reactangle area around clicked point
    const n = 0;
    return map.queryRenderedFeatures(
      [
        [point.x - n, point.y - n],
        [point.x + n, point.y + n]
      ],
      {
        layers
      }
    );
  }
}
