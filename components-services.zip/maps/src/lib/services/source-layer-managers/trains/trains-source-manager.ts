/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { Feature, FeatureCollection } from 'geojson';
import { Observable, Subscription } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { LngLatCoord, LngLatPolyline } from '@oksygen-sim-core-libraries/data-types/common';
import { UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';

import { SourceManager, SourceManagerConfiguration } from '../../mapbox.layers';
import { omit } from 'lodash';

export const TRAINS_SOURCE_NAME = 'vehicles';

export interface TrainsSourceManagerConfiguration extends SourceManagerConfiguration {
  data$: Observable<UsefulTrain[]>;
}

export class TrainsSourceManager extends SourceManager<TrainsSourceManagerConfiguration> {
  private trainSub: Subscription;

  constructor(
    protected logger: Logging,
    protected zone: NgZone,
    configuration: TrainsSourceManagerConfiguration
  ) {
    super(TRAINS_SOURCE_NAME, configuration);
    this.trainSub = this.configuration.data$?.subscribe(trains => {
        if (!trains) { return; }
        this.zone?.runOutsideAngular(() => {
          this.updateTrains(trains);
        });
      }, err => {
        this.logger.log('an error occured ', JSON.stringify(err));
      }, () => {
        this.logger.log('sub completed');
      }
      );
  }

  override destroy(): SuperCalled {
    this.trainSub?.unsubscribe();

    return super.destroy();
  }

  updateTrains(trains: UsefulTrain[]): void {
    this.geoJSONSource.next(this.asVehiclesGeoJSON(trains));
  }

  public asVehiclesGeoJSON(trains: UsefulTrain[]): FeatureCollection {
    const features: Feature[] = [];
    trains.forEach(train => this.addTrainFeatures(features, train));

    return {
      type: 'FeatureCollection',
      features
    };
  }

  private addTrainFeatures(features: Feature[], train: UsefulTrain): void {
    const vehicleCoords = new Array<LngLatPolyline>();
    const connectedCoords = new Array<LngLatCoord>();

    train.vehicles.forEach(co => {
      const vehicleLngLat = co.position.lnglat;
      if (vehicleLngLat.length > 0) {
        vehicleCoords.push(vehicleLngLat);
        vehicleLngLat.forEach(ll => connectedCoords.push(ll));
      }
    });

    const safeTrain = omit(train, ['path']); // path is an object that may not serialize
    const commonProperties = {
      trainId: train.id,
      hasDriver: !!train.driverType,
      isAi: train.driverType === DriverType.ROBOT,
      selected: train.selected,
      // FIXME dragData should be format {type: 'foo', data: dataObj}
      dragData: safeTrain
    };

    if (connectedCoords.length > 1) {

      //Addition of logs related to the random bug PRDOKS-2382
      this.logger.log('Add train to the map with properties : trainId', commonProperties.trainId, ' hasDriver ', commonProperties.hasDriver,
        'isAi ', commonProperties.isAi, 'selected ', commonProperties.selected);

      // Front
      features.push({
        type: 'Feature',
        id: train.id + 'front',
        properties: {
          isFront: true,
          ...commonProperties
        },
        geometry: {
          type: 'Point',
          coordinates: connectedCoords[0]
        }
      });

      // Individual vehicles
      if (vehicleCoords.length > 0) {
        features.push({
          type: 'Feature',
          id: train.id + 'vehicles',
          properties: {
            isConnected: false,
            ...commonProperties
          },
          geometry: {
            type: 'MultiLineString',
            coordinates: vehicleCoords
          }
        });
      }

      // Connected vehicles (such as trains)
      features.push({
        type: 'Feature',
        id: train.id,
        properties: {
          isConnected: true,
          ...commonProperties
        },
        geometry: {
          type: 'MultiLineString',
          coordinates: [connectedCoords]
        }
      });
    }
  }
}
