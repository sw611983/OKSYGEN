/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { FeatureCollection } from 'geojson';
import { LngLat } from 'maplibre-gl';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  DragFeedback,
  selfCompletingObservable,
  SelfCompletingObservable,
  SuperCalled,
  takeOneTruthy
} from '@oksygen-common-libraries/common';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import {
  LngLatCoord,
  LngLatPolyline,
  Orientation,
  SegOffset,
  SegOffsetOriented,
  UserScale
} from '@oksygen-sim-core-libraries/data-types/common';
import { DragData, SegmentPosition } from '@oksygen-sim-train-libraries/components-services/common';
import {
  Consist,
  consistLength,
  ConsistListItem,
  isConsistListItemData,
  ITrainReachablePath,
  ITrainReachablePathFinder,
  TRAIN_TOO_LONG,
  UsefulTrain
} from '@oksygen-sim-train-libraries/components-services/trains';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { emptyGeoJSONCollection } from '../../../helpers/mapbox.source';
import { TrainSelectionHandler } from '../../../interfaces/selection-handlers/selection-train.interface';
import { isScenarioTrainItem, ScenarioTrainItem } from '../../../models/map-drag-data-scenario-train.model';
import { DragSourceManager, DragSourceManagerConfiguration } from '../../mapbox.layers';

const CANT_PLACE_TRAIN: DragFeedback = {
  allowed: false,
  message: t('Train cannot be placed at this location') as string
};

export const TRAIN_DRAG_SOURCE_NAME = 'draggedVehicles';

export interface TrainDragSourceManagerConfiguration extends DragSourceManagerConfiguration<TrainSelectionHandler> {
  netDef$: Observable<NetworkDefinitionManager>;

  consist$: Observable<Consist[]>;

  pathFinder$: Observable<ITrainReachablePathFinder>;
}

interface PathInfo {
  path: ITrainReachablePath;
  startSegId: number;
  pathSegmentIndex: number;
}

/**
 * Manages the GeoJSON source for displaying a train being dragged on the map.
 */
export class TrainDragSourceManager extends DragSourceManager<TrainDragSourceManagerConfiguration> {
  private pathInfo: PathInfo;
  private oldPaths: PathInfo[] = [];

  private netDef: NetworkDefinitionManager;

  private pathFinder: ITrainReachablePathFinder;

  private netDefSubscription = Subscription.EMPTY;

  private pathFinderSubscription = Subscription.EMPTY;

  constructor(configuration: TrainDragSourceManagerConfiguration) {
    super(TRAIN_DRAG_SOURCE_NAME, configuration);

    this.netDefSubscription = this.configuration.netDef$.subscribe(netDef => (this.netDef = netDef));
    this.pathFinderSubscription = this.configuration.pathFinder$.subscribe(pathFinder => (this.pathFinder = pathFinder));
  }

  override destroy(): SuperCalled {
    this.netDefSubscription.unsubscribe();
    this.pathFinderSubscription.unsubscribe();

    return super.destroy();
  }

  public supportsDrag(data: DragData): boolean {
    return isScenarioTrainItem(data) || this.isUsefulTrainWithPosition(data) || isConsistListItemData(data);
  }

  public onDrag(
    dragData: DragData,
    _lngLat: LngLat,
    _lngLatCoord: LngLatCoord,
    segOffset: SegOffsetOriented,
    _userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback | null> {
    if (isScenarioTrainItem(dragData)) {
      const scenarioTrainItem = dragData.data;

      const driverType =
        scenarioTrainItem.driverType ??
        // Handle drag encoded contents
        scenarioTrainItem.drivertype === DriverType.HUMAN.toLowerCase()
          ? DriverType.HUMAN
          : scenarioTrainItem.drivertype === DriverType.ROBOT.toLowerCase()
          ? DriverType.ROBOT
          : null;

      return this.processConsistForDrag(
        c => c.id === scenarioTrainItem.consist.id,
        c => this.updateMovementFeedback(c, segOffset, null, driverType),
        so => this.configuration.handler.onScenarioTrainDragged(scenarioTrainItem.scenarioTrainId, so),
        () => this.removeFeedback()
      );
    } else if (this.isUsefulTrainWithPosition(dragData)) {
      const usefulTrain = dragData.data;

      // Handle drag encoded contents
      const driverType = usefulTrain.driverType
        ? usefulTrain.driverType
        : usefulTrain.drivertype === DriverType.HUMAN.toLowerCase()
        ? DriverType.HUMAN
        : usefulTrain.drivertype === DriverType.ROBOT.toLowerCase()
        ? DriverType.ROBOT
        : null;

      return this.processConsistForDrag(
        c => c.name.toLowerCase() === usefulTrain.description.toLowerCase(),
        c => this.updateMovementFeedback(c, this.findDropOffset(dragData, usefulTrain, segOffset), usefulTrain, driverType),
        so => this.configuration.handler.onUsefulTrainDragged(usefulTrain.id, so),
        () => this.removeFeedback(false)
      );
    } else if (isConsistListItemData(dragData)) {
      const consistListItem = dragData.data as ConsistListItem;

      return this.processConsistForDrag(
        c => c.id === consistListItem.consist.id,
        c => this.updatePlacementFeedback(c, segOffset),
        (so, c) => this.configuration.handler.onConsistDragged(c, so),
        () => this.removeFeedback()
      );
    }

    return selfCompletingObservable(null);
  }

  public onDrop(dragData: DragData, _lngLat: LngLat, _lngLatCoord: LngLatCoord, segOffset: SegOffsetOriented, _userScale: UserScale[]): void {
    if (isScenarioTrainItem(dragData)) {
      const scenarioTrainItem = dragData.data as ScenarioTrainItem;
      this.processConsistForDrop(
        c => c.id === scenarioTrainItem.consist.id,
        segOffset,
        so => this.configuration.handler.onScenarioTrainDropped(scenarioTrainItem.scenarioTrainId, so)
      );
    } else if (this.isUsefulTrainWithPosition(dragData)) {
      const usefulTrain = dragData.data;
      this.processConsistForDrop(
        c => c.name.toLowerCase() === usefulTrain.description.toLowerCase(),
        this.findDropOffset(dragData, usefulTrain, segOffset),
        so => this.configuration.handler.onUsefulTrainDropped(usefulTrain.id, so)
      );
    } else if (isConsistListItemData(dragData)) {
      const consistListItem = dragData.data as ConsistListItem;

      this.processConsistForDrop(
        c => c.id === consistListItem.consist.id,
        segOffset,
        (so, c) => this.configuration.handler.onConsistDropped(c, so)
      );
    }
  }

  /**
   * Checks if the given data (possibly from a specially encoded drag action) looks like a UsefulTrain.
   *
   * @param maybeUsefulTrain a UsefulTrain or a UsefulTrain that has been mangled for inspection during drag.
   */
  private isUsefulTrainWithPosition(dragData: DragData): boolean {
    if (dragData?.type !== 'train') {
      return false;
    }

    const maybeUsefulTrain = dragData.data;
    if (!maybeUsefulTrain) {
      return false;
    }

    // Note that any tests for properties or values with capital letters need to also test for a similar lowercase property,
    // due to potential mangling during a drag.
    if (
      maybeUsefulTrain.id &&
      maybeUsefulTrain.name &&
      maybeUsefulTrain.description &&
      (maybeUsefulTrain.traintype || maybeUsefulTrain.trainType) &&
      maybeUsefulTrain.vehicles?.[0]?.position
    ) {
      const posProps = Object.getOwnPropertyNames(maybeUsefulTrain.vehicles[0].position);

      if (
        (posProps.includes('segmentid') || posProps.includes('segmentId')) &&
        (posProps.includes('segmentoffset') || posProps.includes('segmentOffset')) &&
        (posProps.includes('segmentorientation') || posProps.includes('segmentOrientation'))
      ) {
        return true;
      }
    }

    return false;
  }

  private processConsistForDrag(
    consistPredicate: (c: Consist) => boolean,
    updateFeedback: (c: Consist) => SegOffsetOriented | null,
    dragResult: (s?: SegOffset, c?: Consist) => { allowed: boolean; message: string },
    onDisallowedDrag: () => void
  ): SelfCompletingObservable<DragFeedback | null> {
    return this.configuration.consist$.pipe(
      takeOneTruthy(),
      map(consists => {
        // Note that we cannot use the object being dragged, because some of its contents (e.g. internal maps) get broken in transit.
        const consist = consists.find(consistPredicate);
        const correctedOffset = updateFeedback(consist);
        let result = CANT_PLACE_TRAIN;

        if (correctedOffset) {
          result = dragResult(correctedOffset, consist);
        }

        if (!result.allowed) onDisallowedDrag();

        return result;
      })
    );
  }

  private processConsistForDrop(
    consistPredicate: (c: Consist) => boolean,
    segOffset: SegOffsetOriented | null,
    handleDrop: (s: SegOffset, c?: Consist) => void
  ): void {
    this.configuration.consist$.pipe(takeOneTruthy()).subscribe(consists => {
      // Note that we cannot use the object being dropped, because some of its contents (e.g. internal maps) get broken in transit.
      const consist = consists.find(consistPredicate);
      const correctedOffset = this.updatePlacementFeedback(consist, segOffset);
      // FIXME not great that we enable and disable like this...
      this.removeFeedback();
      if (correctedOffset) {
        handleDrop(correctedOffset, consist);
      }
    });
  }

  /**
   * This function calculates the true offset of the front of the lead vehicle of the train.
   * The provided segOffset is of an arbitrary place on the train the user clicked on
   * so we need to calculate the distance between that position and the front to work out
   * the true front of train position (which is what we return).
   * There can be segment transitions (including orientation changes) between the front and click positions
   * so these need to be taken into account as well.
   */
  private findDropOffset(dragData: DragData, usefulTrain: any, segOffset: SegOffsetOriented): SegOffsetOriented {
    let result = { ...segOffset };
    const dragStartSegOffset = dragData?.start?.segOffset;

    // Adjust the offset of where the train is being dragged to based on the difference between the train's starting point and the point that was clicked.
    if (dragStartSegOffset) {
      const trainPos = usefulTrain.vehicles?.[0]?.position;

      if (trainPos) {
        // Handle drag encoded contents
        const trainSegmentId = trainPos.segmentId ?? trainPos.segmentid;
        const trainOffset = trainPos.segmentOffset ?? trainPos.segmentoffset;
        const trainOrientation = trainPos.segmentOrientation ?? trainPos.segmentorientation;

        // FIXME cope with segment transitions
        if (dragStartSegOffset.segmentId === trainSegmentId) {
          // using the drag manager's pathInfo is a bit dodgy but we need to retain state
          // might need to rethink the processing structure which is way more convoluted than necessary.
          if (this.pathInfo?.path) {
            const startPathSegment = this.pathInfo.path.pathSegments.find(x => x.segment.id === dragStartSegOffset.segmentId);
            const currentPathSegment = this.pathInfo.path.pathSegments.find(x => x.segment.id === segOffset.segmentId);
            let displacement = 0;
            if (!startPathSegment || !currentPathSegment) {
              displacement = trainOffset - dragStartSegOffset.offset;
              result = {
                segmentId: segOffset.segmentId,
                offset: segOffset.offset + displacement,
                orientation: trainOrientation
              };
            } else {
              if (startPathSegment.isFromAlpha() === currentPathSegment.isFromAlpha()) {
                displacement = trainOffset - dragStartSegOffset.offset;
              } else {
                displacement = dragStartSegOffset.offset - trainOffset;
              }
              result = this.pathInfo.path.toValidSegOffsetOriented({
                segmentId: segOffset.segmentId,
                offset: segOffset.offset + displacement,
                orientation: currentPathSegment.direction
              });
            }
          } else {
            const displacement = trainOffset - dragStartSegOffset.offset;
            result = {
              segmentId: segOffset.segmentId,
              offset: segOffset.offset + displacement,
              orientation: trainOrientation
            };
          }
        }
      }
    }
    return result;
  }

  /**
   * Updates the managed source to render the given train.
   * Typically this would be called while the user is dragging a train on the map.
   *
   * @param consist The consist to render.
   * @param segOffset The track position to place its front.
   * @returns An updated ```SegOffset``` if the train could not fit on the track at the given offset,
   *   but could fit if moved along the path.
   */
  private updatePlacementFeedback(consist: Consist, segOffset: SegOffsetOriented): SegOffsetOriented {
    const placeConsist = this.asVehiclesGeoJSON(consist, segOffset, null, null);
    this.geoJSONSource.next(placeConsist.feature);
    return placeConsist.correctedSegOffset;
  }

  /**
   * Updates the managed source to render the given train.
   * Typically this would be called while the user is dragging a train on the map.
   *
   * @param consist The consist to render.
   * @param segOffset The track position to place its front.
   * @returns An updated ```SegOffset``` if the train could not fit on the track at the given offset,
   *   but could fit if moved along the path, or null if it cannot be placed.
   */
  private updateMovementFeedback(consist: Consist, segOffset: SegOffsetOriented, train: UsefulTrain, driverType: DriverType): SegOffsetOriented | null {
    const placeConsist = this.asVehiclesGeoJSON(consist, segOffset, train, driverType);
    this.geoJSONSource.next(placeConsist.feature);
    return placeConsist.correctedSegOffset;
  }

  /**
   * Updates the managed source to render nothing.
   * Typically this would be called when the user has ended a drag interaction.
   */
  public removeFeedback(destroyHistory = true): void {
    this.pathInfo = null;
    this.geoJSONSource.next(emptyGeoJSONCollection());

    if (destroyHistory) {
      this.oldPaths = [];
    }
  }

  private asVehiclesGeoJSON(
    consist: Consist,
    segOffset: SegOffsetOriented,
    train: UsefulTrain | null,
    driverType: DriverType | null
  ): { feature: FeatureCollection; correctedSegOffset: SegOffsetOriented | null } {
    const features = [];
    const trainLength = consistLength(consist);
    const fromAlpha = segOffset.orientation === Orientation.ALPHA_TO_BETA;

    const commonProperties = {
      trainId: consist.id,
      hasDriver: !!driverType,
      isAi: driverType === DriverType.ROBOT,
      selected: false
    };

    if (train) {
      const coordinates = new Array<LngLatCoord>();

      train.vehicles.forEach(v => v.position.lnglat.forEach(ll => coordinates.push(ll)));

      features.push({
        type: 'Feature',
        id: 'source train',
        properties: {
          isSource: true,
          ...commonProperties
        },
        geometry: {
          type: 'MultiLineString',
          coordinates: [coordinates]
        }
      });
    }

    // Make sure we don't repeatedly scan the same path
    // if (!this.pathInfo || this.pathInfo.startSegId !== segOffset.segmentId) {
    if (!this.pathInfo || !this.pathInfo.path.pathSegments.find(ps => ps.segment.id === segOffset.segmentId)) {
      const pathInfo = this.oldPaths?.find(op => op.path.pathSegments.find(ps => ps.segment.id === segOffset.segmentId));
      if (pathInfo) {
        this.pathInfo = pathInfo;
      } else {
        if (this.pathInfo) {
          this.oldPaths.push(this.pathInfo);
        }

        const path = this.pathFinder.scanTrainPath(trainLength, segOffset);
        this.pathInfo = {
          path,
          startSegId: segOffset.segmentId,
          pathSegmentIndex: path.indexOf(segOffset.segmentId)
        };
      }
    }

    const segIndex = this.pathInfo.path.indexOf(segOffset.segmentId);
    const offset = segOffset.offset;

    const consistPlacements = this.pathInfo.path.placeConsistOnPath(consist, segIndex, offset, fromAlpha);

    if (consistPlacements === TRAIN_TOO_LONG) {
      return {
        feature: emptyGeoJSONCollection(),
        correctedSegOffset: null
      };
    }

    const vehicleCoords = new Array<LngLatPolyline>();
    const connectedCoords = new Array<LngLatCoord>();

    consistPlacements.vehiclePositions.forEach(sp => {
      const llp = this.toLngLatPolyline([sp.front, sp.rear]);
      vehicleCoords.push(llp);
      llp.forEach(ll => connectedCoords.push(ll));
    });

    // Individual vehicles
    features.push({
      type: 'Feature',
      id: 'dragged vehicles',
      properties: {
        isConnected: false,
        ...commonProperties
      },
      geometry: {
        type: 'MultiLineString',
        coordinates: vehicleCoords
      }
    });

    // Connected vehicles (such as trains)
    features.push({
      type: 'Feature',
      id: 'dragged consist',
      properties: {
        isConnected: true,
        ...commonProperties
      },
      geometry: {
        type: 'MultiLineString',
        coordinates: [connectedCoords]
      }
    });

    const frontOfConsist = consistPlacements.vehiclePositions[0].front;
    return {
      feature: {
        type: 'FeatureCollection',
        features
      } as any,
      correctedSegOffset: {
        ...frontOfConsist,
        orientation: frontOfConsist.fromAlpha ? Orientation.ALPHA_TO_BETA : Orientation.BETA_TO_ALPHA
      }
    };
  }

  private toLngLatPolyline(segPoses: SegmentPosition[]): LngLatPolyline {
    return segPoses.map((pos, index) =>
      this.netDef.segOffsetToLngLat({
        ...pos,
        // FIXME This is a hack to ensure there is a gap between the cars. There should be a better way to do this...
        offset: pos.offset + (index > 0 ? 2 : 0) * (pos.fromAlpha ? 1 : -1)
      })
    );
  }
}
