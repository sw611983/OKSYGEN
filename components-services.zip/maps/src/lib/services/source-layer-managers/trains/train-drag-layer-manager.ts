/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ExpressionSpecification, LineLayerSpecification, Map } from 'maplibre-gl';

import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';

import { DragLayerManager } from '../../mapbox.layers';
import { TRAIN_DRAG_SOURCE_NAME } from './train-drag-source-manager';
import { TrainsLayerManager } from './trains-layer-manager';

export const TRAIN_DRAG_LAYER_NAME = 'dndVehicles';

/**
 * Sets up layers for displaying a train being dragged on the map.
 */
export class TrainDragLayerManager extends DragLayerManager {
  private static readonly CONNECTED_VEHICLES_LAYER_NAME = 'dndConnectedVehicles';
  private static readonly SHADOW_LAYER_NAME = 'dndTrainShadow';
  private static readonly OUTLINE_CUTOUT_LAYER_NAME = 'dndTrainHaloInner';
  private static readonly OUTLINE_LAYER_NAME = 'dndTrainHaloOuter';
  private static readonly SOURCE_TRAIN_LAYER_NAME = 'dndSourceTrain';
  private static readonly FILTER_SOURCE_TRAIN_EXP: ExpressionSpecification = ['get', 'isSource'];
  private static readonly TRAIN_SHADOW_LINE_WIDTH_EXP: ExpressionSpecification = [
    'interpolate',
    ['linear'],
    ['zoom'],
    // set the max zoom level to apply thin line style, and the width of that line
    12,
    20,
    // set the min zoom level to apply thick line style, and the width of that line
    20,
    20
  ];

  constructor() {
    super(TRAIN_DRAG_LAYER_NAME);
  }

  public attachLayerTo(map: Map): void {
    if (this.mapHasSource(map, TRAIN_DRAG_SOURCE_NAME)) {
      const shadowColour = ThemeColorHex.BLACK; // black
      const shadowOffset = 4;
      const floatOffset = -2;
      const haloInnerColor = ThemeColorHex.WHITE; // white
      const type = 'line';
      const connectedLineWidth = 4;
      const zoomedInVehicleLineWidth = 8;
      const vehicleWidthExp: ExpressionSpecification = [
        'interpolate',
        ['linear'],
        ['zoom'],
        // set the max zoom level to apply thin line style, and the width of that line
        12,
        connectedLineWidth,
        // set the min zoom level to apply thick line style, and the width of that line
        20,
        zoomedInVehicleLineWidth
      ];

      const vehicleLayer: LineLayerSpecification = {
        id: TRAIN_DRAG_LAYER_NAME,
        type,
        source: TRAIN_DRAG_SOURCE_NAME,
        minzoom: 14,
        paint: {
          'line-width': vehicleWidthExp,
          'line-color': TrainsLayerManager.VEHICLE_COLOUR_EXP,
          'line-offset': floatOffset
        },
        filter: TrainsLayerManager.FILTER_USE_INDIVIDUAL_VEHICLE_DATA_EXP
      };

      const connectedVehiclesLayer: LineLayerSpecification = {
        id: TrainDragLayerManager.CONNECTED_VEHICLES_LAYER_NAME,
        type,
        source: TRAIN_DRAG_SOURCE_NAME,
        minzoom: 1,
        maxzoom: 14.5,
        paint: {
          'line-width': connectedLineWidth,
          'line-color': TrainsLayerManager.VEHICLE_COLOUR_EXP,
          'line-offset': floatOffset
        },
        layout: {
          'line-cap': 'round'
        },
        filter: TrainsLayerManager.FILTER_USE_WHOLE_TRAIN_DATA_EXP
      };

      const connectedVehiclesOutlineCutout: LineLayerSpecification = {
        id: TrainDragLayerManager.OUTLINE_CUTOUT_LAYER_NAME,
        type,
        source: TRAIN_DRAG_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': TrainsLayerManager.TRAIN_USER_HALO_INNER_LINE_WIDTH_EXP,
          // Note that any opacity other than 1 or 0 on this layer looks pretty trash due to https://github.com/mapbox/mapbox-gl-js/issues/4090
          'line-opacity': 1,
          'line-color': haloInnerColor,
          'line-offset': floatOffset
        },
        layout: {
          'line-cap': 'round'
        },
        filter: TrainsLayerManager.FILTER_USE_WHOLE_TRAIN_DATA_EXP
      };

      const shadowLayer: LineLayerSpecification = {
        id: TrainDragLayerManager.SHADOW_LAYER_NAME,
        type,
        source: TRAIN_DRAG_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': TrainDragLayerManager.TRAIN_SHADOW_LINE_WIDTH_EXP,
          'line-opacity': 0.2,
          'line-color': shadowColour,
          'line-offset': shadowOffset,
          'line-blur': 3
        },
        layout: {
          'line-cap': 'round'
        },
        filter: TrainsLayerManager.FILTER_USE_WHOLE_TRAIN_DATA_EXP
      };

      const connectedVehiclesOutline: LineLayerSpecification = {
        id: TrainDragLayerManager.OUTLINE_LAYER_NAME,
        type,
        source: TRAIN_DRAG_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': TrainsLayerManager.TRAIN_USER_HALO_OUTER_LINE_WIDTH_EXP,
          // Note that any opacity other than 1 or 0 on this layer looks pretty trash due to https://github.com/mapbox/mapbox-gl-js/issues/4090
          'line-opacity': 1,
          'line-color': TrainsLayerManager.VEHICLE_COLOUR_EXP,
          'line-offset': floatOffset
        },
        layout: {
          'line-cap': 'round'
        },
        filter: TrainsLayerManager.FILTER_USE_WHOLE_TRAIN_DATA_EXP
      };

      const sourceTrain: LineLayerSpecification = {
        id: TrainDragLayerManager.SOURCE_TRAIN_LAYER_NAME,
        type,
        source: TRAIN_DRAG_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': TrainsLayerManager.TRAIN_USER_HALO_OUTER_LINE_WIDTH_EXP,
          'line-opacity': 0.5,
          'line-color': ThemeColorHex.WHITE
        },
        layout: {
          'line-cap': 'round'
        },
        filter: TrainDragLayerManager.FILTER_SOURCE_TRAIN_EXP
      };

      map.addLayer(sourceTrain); // bottom layer
      map.addLayer(shadowLayer);
      map.addLayer(connectedVehiclesOutline);
      map.addLayer(connectedVehiclesOutlineCutout);
      map.addLayer(connectedVehiclesLayer);
      map.addLayer(vehicleLayer); // top layer
    }
  }
}
