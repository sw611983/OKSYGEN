/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { Map } from 'maplibre-gl';

import { LayerManager } from '../mapbox.layers';

export const LINES_LAYER_NAME = 'lines';
export const LINES_SOURCE_NAME = 'lines';

export class LinesLayerManager extends LayerManager {
  constructor() {
    super(LINES_LAYER_NAME);
  }

  public override clear(): void {}

  public attachLayerTo(map: Map, _elRef: ElementRef<any>, _getDragPreview: (objectRef: any) => Element): void {
    if (this.mapHasSource(map, LINES_SOURCE_NAME)) {
      map.addLayer({
        id: LINES_LAYER_NAME,
        type: 'line',
        source: LINES_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': ['get', 'lineWidth'],
          'line-color': ['get', 'lineColor']
        }
      });
    }
  }
}
