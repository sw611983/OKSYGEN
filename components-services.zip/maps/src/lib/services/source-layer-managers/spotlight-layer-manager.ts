/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { Map } from 'maplibre-gl';

import { LayerManager } from '../mapbox.layers';

export const SPOTLIGHT_LAYER_NAME = 'spotlight';
export const SPOTLIGHT_SOURCE_NAME = 'spotlight';

export class SpotlightLayerManager extends LayerManager {
  constructor() {
    super(SPOTLIGHT_LAYER_NAME);
  }

  public override clear(): void {}

  public attachLayerTo(map: Map, _elRef: ElementRef<any>, _getDragPreview: (objectRef: any) => Element): void {
    if (this.mapHasSource(map, SPOTLIGHT_SOURCE_NAME)) {
      map.addLayer({
        id: SPOTLIGHT_LAYER_NAME,
        type: 'symbol',
        source: SPOTLIGHT_SOURCE_NAME,
        minzoom: 14,
        layout: {
          'icon-image': ['concat', 'FT', ['get', 'type'], 'S', ['get', 'state']],
          'icon-size': [
            'interpolate',
            ['linear'],
            ['zoom'],
            // set the max zoom level to show small icons, and that icon size
            16,
            0.5,
            // set the min zoom level to show big icons, and that icon size
            18,
            1
          ],
          'icon-allow-overlap': true
        },
        filter: ['>=', ['zoom'], ['get', 'minzoom']]
      });
    }
  }
}
