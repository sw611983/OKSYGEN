/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Feature, FeatureCollection } from 'geojson';
import { truncate } from '@turf/truncate';
import { findKey, isNil } from 'lodash';
import { BehaviorSubject, combineLatest, Observable, of, Subscription } from 'rxjs';

import { filterTruthy, shareReplayOne } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { TrackSegmentAssociation } from '@oksygen-sim-core-libraries/data-types/objects';
import { IReachablePath, ObjectLayer, ObjectLayerType, UpdatedInserted } from '@oksygen-sim-train-libraries/components-services/common';
import {
  VIRTUAL_STATE,
  DISPLAY_STATE_OVERRIDE,
  getDisplayObject,
  getTrackAssocHeading,
  getTrackAssocLngLat,
  getTrackAssocPosition,
  ObjectContainer,
  getObjectRenderInfo
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { emptyGeoJSONCollection } from '../../../helpers/mapbox.source';
import { MapConfig } from '../../../models/map-config.model';
import { ObjectMapRenderer } from '../../../tokens/object-map-render.token';
import { ObjectsSourceManagerConfiguration } from './objects-source-manager';
import { distinctUntilChanged, map, switchMap, tap } from 'rxjs/operators';
import { ObjectsLayerManager } from './objects-layer-manager';

// Because no one can agree on which way is up and what direction is positive rotation :(
export function toMapHeading(heading: number): number {
  return -heading + 90;
}

export class DefaultObjectsSourceManagerConfiguration<T = any> implements ObjectsSourceManagerConfiguration {
  public static readonly DEFAULT_FEATURE_MIN_ZOOM = 14;

  protected subscription = Subscription.EMPTY;

  protected dataHasChangedSubject = new BehaviorSubject<boolean>(false);
  protected triggerUpdateSubject = new BehaviorSubject<boolean>(false);

  protected netDef?: NetworkDefinitionManager;
  protected objectsMap?: Map<number, ObjectContainer> = new Map();
  // [object container id, featureGeoJSON index]
  protected geoJsonMap?: Map<number, number> = new Map();
  protected path?: IReachablePath;
  protected layers?: ObjectLayer[];
  protected data?: T;

  protected highlightedPath$: Observable<IReachablePath> = of(undefined);

  public selectedObject$?: Observable<ObjectContainer>;
  public selectedObjectGeoJson$?: Observable<{
    objects: FeatureCollection;
    trackAssociations: FeatureCollection;
    trackAssociationLines: FeatureCollection;
  }>;

  public layer$: Observable<ObjectLayer[]> = of([]);

  protected triggerObjects: string[] = [];
  protected featureGeoJSON: FeatureCollection = emptyGeoJSONCollection();

  private stackSpacing = 5;
  private trackDistanceThreshold = 0.5;

  constructor(
    protected readonly mapConfig: MapConfig,
    protected readonly logger: Logging,
    protected readonly netDef$: Observable<NetworkDefinitionManager>,
    protected readonly objects$: Observable<UpdatedInserted<ObjectContainer>>,
    protected readonly data$?: Observable<T>,
    protected readonly overrideObjectRenderer?: ObjectMapRenderer,
    protected readonly featureMinZoom: number = DefaultObjectsSourceManagerConfiguration.DEFAULT_FEATURE_MIN_ZOOM
  ) {}

  setHighlightedPath(highlightedPath$: Observable<IReachablePath>): void {
    this.highlightedPath$ = highlightedPath$;
  }

  setSelectedObject(selectedObject$: Observable<ObjectContainer>): void {
    this.selectedObject$ = selectedObject$;
    this.selectedObjectGeoJson$ = this.selectedObject$.pipe(
      map(obj => this.asSelectedFeatureGeoJSON(obj)),
      shareReplayOne()
    );
  }

  setLayers(layer$: Observable<ObjectLayer[]>): void {
    this.layer$ = layer$;
  }

  subscribe(): void {
    this.subscription = combineLatest([this.netDef$, this.highlightedPath$, this.layer$, this.data$ ?? of(null)]).subscribe(
      ([netDef, path, layers, data]) => {
        const oldPath = this.path;
        this.netDef = netDef;
        this.path = path;
        this.layers = layers;
        this.data = data;

        this.triggerObjects = this.getTriggerObjects(data);
        // this.featureGeoJSON = this.asFeatureGeoJSON();
        if (path !== oldPath) {
          this.featureGeoJSON.features.forEach(f => {
            const obj = this.objectsMap.get(f.properties.id);
            f.properties.onPath = this.objectOnPath(obj, this.path);
          });
        }

        this.dataHasChangedSubject.next(!netDef);
        this.triggerUpdateSubject.next(true);
      },
      err => this.logger.error('An error occured in DefaultObjectsSourceManagerConfiguration', JSON.stringify(err))
    );

    // we need to reset our objects when netDef changes track
    const netDef$ = this.netDef$.pipe(
      filterTruthy(),
      distinctUntilChanged((a, b) => a?.worldData?.name === b?.worldData?.name),
      tap(netDef => {
        this.objectsMap.clear();
        this.featureGeoJSON = emptyGeoJSONCollection();
      })
    );

    const objSub = netDef$.pipe(
      // filterTruthy(),
      switchMap(netDef => this.objects$)
    ).subscribe(objects => {
      objects?.inserted?.forEach(insObj => {
        this.objectsMap.set(insObj.id, insObj);
      });
      objects?.updated?.forEach(upObj => {
        this.objectsMap.set(upObj.id, upObj);
      });
      objects?.deleted?.forEach(delObj => {
        this.objectsMap.delete(delObj.id);
      });
      this.featureGeoJSON = this.asFeatureGeoJSON(objects);
      this.dataHasChangedSubject.next(!objects || (!objects?.inserted && !objects?.updated));
    });
    this.subscription.add(objSub);
  }

  unsubscribe(): void {
    this.subscription.unsubscribe();

    this.triggerObjects = [];
    this.featureGeoJSON = emptyGeoJSONCollection();
  }

  destroy(): void {
    this.subscription.unsubscribe();

    this.dataHasChangedSubject.complete();
    this.triggerUpdateSubject.complete();
  }

  dataHasChanged$(): Observable<boolean> {
    return this.dataHasChangedSubject.pipe(shareReplayOne());
  }

  triggerUpdate$(): Observable<boolean> {
    return this.triggerUpdateSubject.pipe(shareReplayOne());
  }

  getTriggerObjects(data: T): Array<string> {
    return this.triggerObjects;
  }

  getSelectedObject(): Observable<ObjectContainer> {
    return this.selectedObject$;
  }

  getUpdatedGeoJson(): FeatureCollection {
    return this.featureGeoJSON;
  }

  protected asFeatureGeoJSON(upserts?: UpdatedInserted<ObjectContainer>): FeatureCollection {
    /**
     * This is quite a complicated function.
     * We iterate through all features (including feature container parents and children) and determine how to render them.
     * Parents themselves are NOT rendered.
     * Children are rendered in a vertical stack above or below the parent depending on if the first child is above or below
     * the track association (to avoid covering the track association).
     * Children are only rendered when the user is zoomed in.
     */
    const processObject = (o: ObjectContainer): Feature|null => {
      const objectType = o.objectType;
      // Skip unknown feature types.
      if (!objectType || objectType.name === 'Point' || objectType.name === 'Platform' || !this.isValidObject(o)) { return null; }
        let obj = o;
        // we want to use the first child's position if this is a secondary child
        if (o.parentId) {
          obj = this.objectsMap.get(obj.parentId);
        }
        const positionSupplier = this.mapConfig.objects.usePromotedChildPosition ? getDisplayObject(obj) : obj;
        const commonProperties = {
          id: o.id,
          name: parent.name,
          type: objectType.name,
          typeName: objectType.name,
          debugText: o.id
        };
        const feature = this.individualObjectAsGeoJson(o, positionSupplier as ObjectContainer, commonProperties);
        if (feature) {
          // precision is number of decimal places. 3 = 110m, 4 = 11m, 5 = 1.1m, 6 = 11cm, 7 = 1.1cm, 8 = 1.1mm
          truncate(feature as any, {mutate: true, precision: 8});
        }
        return feature;
    };

    upserts.inserted.forEach(o => {
      const insertedGeojson = processObject(o);
      if (!insertedGeojson) { return; }
      this.featureGeoJSON.features.push(insertedGeojson);
      this.geoJsonMap.set(o.id, this.featureGeoJSON.features.length - 1);
    });
    upserts.updated.forEach(o => {
      const updatedGeojson = processObject(o);
      if (!updatedGeojson) { return; }
      const index = this.geoJsonMap.get(o.id);
      if (index !== undefined) {
        this.featureGeoJSON.features[index] = updatedGeojson;
      } else {
        this.featureGeoJSON.features.push(updatedGeojson);
        this.geoJsonMap.set(o.id, this.featureGeoJSON.features.length - 1);
      }
    });
    upserts.deleted?.forEach(o => {
      const index = this.geoJsonMap.get(o.id);
      if (index !== undefined) {
        this.geoJsonMap.delete(o.id);
        this.featureGeoJSON.features.splice(index, 1);
        // removing the object messes with our map of index references so we need to regenerate it
        this.geoJsonMap.forEach((geojsonIndex, objectId) => {
          if (geojsonIndex > index) {
            this.geoJsonMap.set(objectId, geojsonIndex - 1);
          }
        });
      }
    });

    return this.featureGeoJSON;
  }

  protected asSelectedFeatureGeoJSON(object: ObjectContainer): {
    objects: FeatureCollection;
    trackAssociations: FeatureCollection;
    trackAssociationLines: FeatureCollection;
  } {
    /**
     * This is quite a complicated function.
     * We take the selected object, which may or may not have children.
     * If it has children we render the children (NOT this object) in a vertical stack.
     * We also want to render this object (NOT the children)'s track association(s).
     */
    const features: any[] = [];
    const trackAssociations: any[] = [];
    const trackAssociationLines: any[] = [];
    if (!object?.objectType || object.objectType.name === 'Point') {
      return {
        objects: { type: 'FeatureCollection', features },
        trackAssociationLines: { type: 'FeatureCollection', features: trackAssociationLines },
        trackAssociations: { type: 'FeatureCollection', features: trackAssociations }
       };
    }
    const objectType = object.objectType;
    const positionSupplier = this.mapConfig.objects.usePromotedChildPosition ? getDisplayObject(object) : object;

    const commonProperties = {
      id: object.id,
      name: parent.name,
      type: objectType.name,
      typeName: objectType.name,
      debugText: object.id
    };
    // get the feature's geoJSON
    const objects = object.children?.length ? object.children : [ object ];
    objects.forEach(obj => {
      const feature = this.individualObjectAsGeoJson(obj as ObjectContainer, positionSupplier as ObjectContainer, commonProperties);
      if (feature) {
        features.push(feature);
      }
    });

    // now render the track association with a line between the object and TAs position
    const pos = positionSupplier.location.lnglat;
    positionSupplier.trackAssociations.forEach(a => {
      const assocLL = getTrackAssocLngLat(this.netDef, a);
      trackAssociations.push({
        type: 'Feature',
        id: 'auto assoc',
        properties: {
          ...commonProperties,
          orientation: toMapHeading(getTrackAssocHeading(this.netDef, a).degrees),
        },
        geometry: {
          type: 'Point',
          coordinates: assocLL
        }
      });


      trackAssociationLines.push({
        type: 'Feature',
        id: 'auto assoc line',
        properties: {
          ...commonProperties
        },
        geometry: {
          type: 'MultiLineString',
          coordinates: [[assocLL, pos]]
        }
      });
    });

    return {
      objects: { type: 'FeatureCollection', features },
      trackAssociationLines: { type: 'FeatureCollection', features: trackAssociationLines },
      trackAssociations: { type: 'FeatureCollection', features: trackAssociations }
    };
  }

  protected isValidObject(o: ObjectContainer): boolean {
    // has a valid location
    let valid = !!o.location.lnglat;

    // is not a composite feature - we will display the children
    valid = valid && (!o.children || o.children.length === 0);

    return valid;
  }

  protected isTriggerObject(o: ObjectContainer): boolean {
    return !!this.triggerObjects.find(to => to === o.name);
  }

  protected isPromotedChild(o: ObjectContainer): boolean {
    return o.parentId && o.promotedChild;
  }

  protected getObjectLayer(feature: ObjectContainer, layers: ObjectLayer[]): string {
    const layer = this.findObjectLayer(feature, layers);
    // FIXME magic string that's even worse because it's gotta match a string coming from the db!
    return layer ? layer.name : 'Unallocated';
  }

  protected calculateFeatureContainerSpacing(
    parent: ObjectContainer,
    child: ObjectContainer
  ): {
    isFirstChild: boolean;
    translate: number[];
    containerSize: number[];
    firstChildSize: number[];
    hidden: boolean;
    firstChild: ObjectContainer;
  } {
    // we want to render feature containers in a vertical stack rather than directly on top of each other
    // so we need to calculate based on each child icon size how far to move each child from the parents position
    // We always want the first child to be on the top.
    // the stack may go upwards or downwards, so first child may either have a y translate of 0 or total size.
    let isFirstChild = true;
    let firstChild = child;
    let hidden = false;
    let totalContainerHeight = this.stackSpacing * 4; // add some padding for the top and bottom
    let maxWidth = 0;
    let yTranslate = 0; // how far to move this child - ie if the 3rd child and each child is 40px, then move 3 x 40px
    let alternateYTranslate = 0;
    let firstChildSize = [60, 60];
    if (parent.id === child.id) {
      return { translate: [0, yTranslate], isFirstChild, hidden, containerSize: firstChildSize, firstChildSize, firstChild: child };
    }
    const cTypeName = findKey(parent.properties, val => val === child.id);
    const childType = parent.objectType.children.find(cType => cType.name === cTypeName);
    // const childType = parent.objectType.children.find(cType => cType.child.name === child.objectType.name);
    const childIndex = childType?.displayOrder ?? -1;
    let lowestChildIndex = childIndex;
    if (!childType?.displayIcon) {
      hidden = true;
    }
    // this has already been sorted on display order in ObjectTypeDataService
    for (const c of parent.children) {
      const cTypeNameLoop = findKey(parent.properties, val => val === c.id);
      const ct = parent.objectType.children.find(cType => cType.name === cTypeNameLoop);
      // const ct = parent.objectType.children.find(cType => cType.child.name === c.objectType.name);
      if (!ct?.displayIcon) {
        continue;
      }
      // eslint-disable-next-line @typescript-eslint/dot-notation
      const width = c.selectedIcon?.small?.['imageData']?.width ?? ObjectsLayerManager.DEFAULT_OBJECT_ICON_SIZE;
      // eslint-disable-next-line @typescript-eslint/dot-notation
      const height = c.selectedIcon?.small?.['imageData']?.height ?? ObjectsLayerManager.DEFAULT_OBJECT_ICON_SIZE;
      if (!width || !height) {
        continue;
      }
      if (width > maxWidth) {
        maxWidth = width;
      }
      if (ct.displayOrder <= childIndex) {
        if (c.name !== child.name) {
          yTranslate += height + this.stackSpacing;
          isFirstChild = false;
          if (ct.displayOrder <= lowestChildIndex) {
            firstChild = c as ObjectContainer;
            lowestChildIndex = ct.displayOrder;
          }
        }
        firstChildSize = [width, height];
      } else {
        alternateYTranslate += height + this.stackSpacing;
      }
      totalContainerHeight += height + this.stackSpacing;
    }

    const a = getTrackAssocPosition(this.netDef, parent.trackAssociations[0]);
    const isFarFromTrack = Math.abs(a?.x - parent.location?.geometry.x) > this.trackDistanceThreshold;
    const belowTrack = a?.x > parent.location?.geometry.x;
    yTranslate = isFarFromTrack && belowTrack ? yTranslate : alternateYTranslate;

    const xTranslate = 2;
    return {
      containerSize: [60, Math.ceil(totalContainerHeight / 10)],
      firstChildSize,
      hidden,
      isFirstChild,
      firstChild,
      translate: [xTranslate, -yTranslate]
    };
  }

  protected findObjectLayer(feature: ObjectContainer, layers: ObjectLayer[]): ObjectLayer {
    let featureLayer: ObjectLayer = null;
    layers?.forEach(layer => {
      if (featureLayer) {
        return;
      }
      if (layer.subLayers?.length > 0) {
        // FIXME handle cycles
        featureLayer = this.findObjectLayer(feature, layer.subLayers);
      }
      // FIXME handle other layer sub-types
      if (layer.type === ObjectLayerType.FEATURE_TYPE_LAYER_TYPE && layer.id === feature.objectType.name) {
        featureLayer = layer;
      }
    });
    return featureLayer;
  }

  /**
   * Determines whether the supplied object is on this path.
   * If path is not supplied, return true.
   *
   * @param object the object to check
   * @param path the path
   */
  protected objectOnPath(object: ObjectContainer, path?: IReachablePath): boolean {
    if (isNil(path)) {
      return true;
    }

    for (const assoc of this.findPathReferenceTrackAssociations(object)) {
      const pathSegment = path.pathSegments.find(ps => ps.segment.id === assoc.segmentId);
      if (pathSegment && (pathSegment.direction === assoc.orientation || assoc.orientation === Orientation.NONE)) {
        return true;
      }
    }

    return false;
  }

  protected findPathReferenceTrackAssociations(object: ObjectContainer): TrackSegmentAssociation[] {
    // Because some projects made object containers with their children going the opposite direction...
    if (this.mapConfig.objects.usePromotedChildOrientation) {
      const refObject = getDisplayObject(object); // object.children?.find(f => f.promotedChild);

      if (refObject) {
        return refObject.trackAssociations;
      }
    }

    // Hopefully the vast majority of projects can simply use the parent:
    return object.trackAssociations;
  }

  private individualObjectAsGeoJson(
    obj: ObjectContainer, positionSupplier: ObjectContainer, commonProperties: Record<string, any> = {}
  ): Feature|null {
    const displayStateObjectSpacing = 30;
    let containerType: 'standalone' | 'first-child' | 'secondary-child' | 'hidden' = 'standalone';
    let containerSize: number[] = [60, 60];
    let containerFirstChildSize: number[] = [60, 60];
    let translate: number[] = [0, 0];
    const displayStateIcontranslate: number[] = [60, 60];
    let isDisplayStateOverriden: boolean;
    const displayStateTranslate: number[] = [displayStateObjectSpacing, 0];
    const selectedDisplayStateOffset: number[] = [displayStateObjectSpacing, displayStateObjectSpacing];
    const selectedFirstOffset: number[] = [0, 0];
    let isVirtual: boolean;
    let parent = obj;
    const isDisplayState =
      Object.prototype.hasOwnProperty.call(obj.properties, DISPLAY_STATE_OVERRIDE) && (obj.properties as any)[DISPLAY_STATE_OVERRIDE] === 1;
    // first handle if this is a child object
    if (obj.parentId) {
      parent = this.objectsMap.get(obj.parentId);
      const spacing = this.calculateFeatureContainerSpacing(parent, obj as ObjectContainer);
      if (spacing.hidden) { return null; }
      containerType = spacing.isFirstChild ? 'first-child' : 'secondary-child';
      containerSize = spacing.containerSize;
      containerFirstChildSize = spacing.firstChildSize;
      translate = spacing.translate;
      // half the size of the first element + the top and bottom spacing + the line width * 2
      let offsetY = containerFirstChildSize[1] / 2 + this.stackSpacing * 2 + 4;
      if (spacing.isFirstChild) {
        isDisplayStateOverriden = parent.children.some(
          c => Object.prototype.hasOwnProperty.call(c.properties, DISPLAY_STATE_OVERRIDE) && (c.properties as any)[DISPLAY_STATE_OVERRIDE] === 1
        );
        // Icon alignment
        displayStateIcontranslate[1] = containerSize[1] + this.stackSpacing * 5;
        //for virtual signals
        isVirtual = parent.children.some(
          c => Object.prototype.hasOwnProperty.call(c.properties, VIRTUAL_STATE)
          && ((c.properties as any)[VIRTUAL_STATE] === 1 || (c.properties as any)[VIRTUAL_STATE] === true)
        );
      }
      if (isDisplayStateOverriden) {
        // Added some more top and bottom spacing to align display state background with container
        containerSize[1] += 3;
        offsetY = containerFirstChildSize[1] / 2 + this.stackSpacing * 5 + 4;
      }
      selectedFirstOffset[1] = offsetY;
    } else {
      isDisplayStateOverriden = isDisplayState;
      // for virtual signals
      isVirtual = Object.prototype.hasOwnProperty.call(obj.properties, VIRTUAL_STATE)
      && ((obj.properties as any)[VIRTUAL_STATE] === 1 || (obj.properties as any)[VIRTUAL_STATE] === true);
    }
    if (isDisplayState) {
      if (containerType === 'standalone') {
        // eslint-disable-next-line @typescript-eslint/dot-notation
        const imgWidth = obj.selectedIcon?.small?.['imageData']?.width ?? ObjectsLayerManager.DEFAULT_OBJECT_ICON_SIZE;
        const maxWidth = imgWidth && imgWidth > displayStateObjectSpacing ? imgWidth + 5 : displayStateObjectSpacing;
        selectedFirstOffset[0] = maxWidth / 2;
        displayStateTranslate[0] = maxWidth;
        // Icon alignment
        displayStateIcontranslate[0] = maxWidth + 5;
        displayStateIcontranslate[1] += 15;
      } else {
        displayStateTranslate[0] = displayStateObjectSpacing / 2 + containerFirstChildSize[0] / 2 + this.stackSpacing * 2 + 4;
        displayStateTranslate[1] = translate[1];
        selectedDisplayStateOffset[0] += containerFirstChildSize[0] / 2 - 8;
        selectedDisplayStateOffset[1] += displayStateTranslate[1] + this.stackSpacing * 2 + 2;
      }
    }

    const objMapRenderInfo = getObjectRenderInfo(obj, ObjectsLayerManager.DEFAULT_OBJECT_ICON_NAME);
    // generate the geoJSON for the feature
    const feature: Feature = {
      type: 'Feature',
      id: parent.id,
      properties: {
        ...commonProperties,
        // heading, // not rendering heading right now - BEWARE icon-rotate conflicts with icon-offset in the layer (objects-layer-manager).
        // TODO this should be based on the type
        minzoom: this.featureMinZoom,
        isTrigger: this.isTriggerObject(parent),
        isVirtual,
        layer: this.getObjectLayer(parent, this.layers),
        icon: objMapRenderInfo.icon,
        isBidirectional: undefined,
        isDisplayState,
        displayStateIcon: obj.displayState?.icons?.small?.id ?? '',
        onPath: this.objectOnPath(positionSupplier, this.path),
        translate,
        displayStateTranslate,
        containerType,
        isIcon: true,
        selected: true,
        selectedSize: 6, // default a 60x60 circle - this becomes a rounded rectangle when there are children
        selectedFirstOffset,
        selectedDisplayStateOffset,
        isDisplayStateOverriden,
        stackDirection: 'up',
        displayStateIcontranslate,
        // FIXME dragData should be format {type: 'foo', data: dataObj}
        dragData: { name: parent.name, objectId: parent.id, objectName: parent.name }
      },
      geometry: {
        type: 'Point',
        coordinates: positionSupplier.location.lnglat
      }
    };

    // if it's a child we need to add an offset as we show each child in a stack
    if (containerType === 'first-child' || containerType === 'secondary-child') {
      // feature.properties.icon = obj?.selectedIcon?.small?.id ?? ObjectsLayerManager.DEFAULT_OBJECT_ICON_NAME;
      const firstAssoc = positionSupplier.trackAssociations[0];
      const a = getTrackAssocPosition(this.netDef, firstAssoc);
      const isFar = Math.abs(a?.x - positionSupplier.location?.geometry.x) > this.trackDistanceThreshold;
      const shouldFlip = a?.x > positionSupplier.location?.geometry.x; // flip means stack downwards
      if (containerType === 'first-child') {
        feature.properties.selectedSize = containerSize[1]; // vertical, for now
        // half the size of the first element + the top and bottom spacing + the line width * 2
        feature.properties.selectedFirstOffset = selectedFirstOffset; // vertical, for now
      }
      if (containerType === 'secondary-child') {
        // only show child feature when reasonably close to avoid clutter
        feature.properties.minzoom = 17;
      }
      if (isFar && shouldFlip) {
        feature.properties.selectedFirstOffset[1] *= -1;
        feature.properties.translate[1] *= -1;
        feature.properties.stackDirection = 'down';
      }
    }
    // if it's the first child or standalone we want to handle the orientation rendering
    if (containerType === 'first-child' || containerType === 'standalone') {
      if (positionSupplier.trackAssociations?.length === 1) {
        const firstAssoc = positionSupplier.trackAssociations[0];
        const a = getTrackAssocPosition(this.netDef, firstAssoc);
        // x is perpendicular offset from the track - we only want to show the orientation icon if the track association is covered by the icon
        const isClose = Math.abs(a?.x - positionSupplier.location?.geometry.x) < this.trackDistanceThreshold;
        if (a?.x && positionSupplier.location?.geometry?.x && isClose) {
          const isBidirectional = firstAssoc.orientation === Orientation.NONE;
          feature.properties.isBidirectional = isBidirectional;
          const orientation = toMapHeading(getTrackAssocHeading(this.netDef, firstAssoc).degrees);
          if (orientation) {
            feature.properties.orientation = orientation;
          }
        }
      }
    }
    if (objMapRenderInfo.label) {
      feature.properties.label = objMapRenderInfo.label.text;
      feature.properties.labelColour = objMapRenderInfo.label.colour;
      // text-offset property is in em, which is the ratio as compared to the font size.
      const labelFontSize = 15; // font size our label layer uses
      const iconSizeToCenter = containerType === 'standalone' || containerType === 'first-child' ? 0 : 15; // FIXME magic number
      const yOffsetAsEm = (translate[1] + iconSizeToCenter + objMapRenderInfo.label.yOffset) / labelFontSize;
      feature.properties.labelOffset = [0, yOffsetAsEm];
    }
    // override the rendering logic if this object type has a custom renderer
    if (this.overrideObjectRenderer?.renderers && obj.objectType.mapRenderer) {
      const renderer = this.overrideObjectRenderer.renderers.get(obj.objectType.mapRenderer);
      if (renderer) {
        const overrides = renderer(obj as ObjectContainer);
        if (overrides.label) {
          feature.properties.label = overrides.label;
        }
        if (overrides.icon) {
          feature.properties.icon = overrides.icon;
        }
      }
    }
    return feature;
  }
}
