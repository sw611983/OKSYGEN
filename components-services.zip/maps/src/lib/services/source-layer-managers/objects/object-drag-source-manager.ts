/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FeatureCollection } from 'geojson';
import { isNil } from 'lodash';
import { LngLat } from 'maplibre-gl';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  DragFeedback,
  selfCompletingObservable,
  SelfCompletingObservable,
  SuperCalled,
  takeOneTruthy
} from '@oksygen-common-libraries/common';
import { LngLatCoord, Orientation, SegOffset, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData } from '@oksygen-sim-train-libraries/components-services/common';
import {
  getObjectId,
  getTrackAssocHeading,
  isObjectIdData,
  isObjectTypeData,
  ObjectContainer,
  ObjectType,
  ObjectTypeContainer
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { emptyGeoJSONCollection } from '../../../helpers/mapbox.source';
import { ObjectSelectionHandler } from '../../../interfaces/selection-handlers/selection-object.interface';
import { DragSourceManager, DragSourceManagerConfiguration } from '../../mapbox.layers';
import { toMapHeading } from './default-objects-source-manager-configuration';

export const OBJECT_DRAG_SOURCE_MANAGER_NAME = 'draggedObjects';

export interface ObjectDragSourceManagerConfiguration extends DragSourceManagerConfiguration<ObjectSelectionHandler> {
  netDef$: Observable<NetworkDefinitionManager>;

  objectTypes$: Observable<Map<string, ObjectTypeContainer>>;

  objects$: Observable<ObjectContainer[]>;
}

/**
 * Manages the GeoJSON source for displaying an Object being dragged on the map.
 */
export class ObjectDragSourceManager extends DragSourceManager<ObjectDragSourceManagerConfiguration> {
  protected netDef: NetworkDefinitionManager;

  protected netDefSubscription = Subscription.EMPTY;

  constructor(configuration: ObjectDragSourceManagerConfiguration) {
    super(OBJECT_DRAG_SOURCE_MANAGER_NAME, configuration);

    this.netDefSubscription = this.configuration.netDef$.subscribe(netDef => (this.netDef = netDef));
  }

  override destroy(): SuperCalled {
    this.netDefSubscription.unsubscribe();

    return super.destroy();
  }

  public supportsDrag(data: DragData): boolean {
    return isObjectIdData(data) || isObjectTypeData(data);
  }

  public onDrag(
    dragData: DragData,
    _lngLat: LngLat,
    lngLatCoord: LngLatCoord,
    segOffset: SegOffsetOriented,
    userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback | null> {
    if (isObjectIdData(dragData)) {
      return this.configuration.objects$.pipe(
        takeOneTruthy(),
        map(objects => {
          const objectId = getObjectId(dragData);
          const object = objects.find(o => o.id === objectId);
          if (object) {
            const result = this.configuration.handler.onObjectDragged(objectId, { lngLat: lngLatCoord, segOffset, userScale });

            if (result.allowed) {
              this.updateFeedback(this.netDef, object.objectType, lngLatCoord, segOffset);
            }

            return result;
          }

          return null;
        })
      );
    } else if (isObjectTypeData(dragData)) {
      const objectType: ObjectType = dragData as any;

      return this.configuration.objectTypes$.pipe(
        takeOneTruthy(),
        map(types => {
          let type: ObjectTypeContainer = types.get(objectType.name);

          if (isNil(type)) {
            // could not find via a simple get, so try to adjust case to match
            types.forEach((ot, key) => {
              if ((isNil(type) && key === objectType.name) || key.toLowerCase() === objectType.name.toLowerCase()) {
                type = ot;
              }
            });
          }

          if (!isNil(type)) {
            // Ensure icons are ready here.
            type.defaultIcons.small.asBlob();

            const result = this.configuration.handler.onObjectTypeDragged(type, { lngLat: lngLatCoord, segOffset, userScale });
            const valid = result.allowed;

            if (valid) {
              this.updateFeedback(this.netDef, type, lngLatCoord, segOffset);
            }

            return result;
          }

          return null;
        })
      );
    }

    return selfCompletingObservable(null);
  }

  public onDrop(dragData: DragData, _lngLat: LngLat, lngLatCoord: LngLatCoord, segOffset: SegOffsetOriented, userScale: UserScale[]): void {
    if (isObjectIdData(dragData)) {
      this.configuration.objects$.pipe(takeOneTruthy()).subscribe(objects => {
        const objectId = getObjectId(dragData);
        const object = objects.find(o => o.id === objectId);
        if (object) {
          this.configuration.handler.onObjectDropped(objectId, { lngLat: lngLatCoord, segOffset, userScale });
        }
      });
    } else if (isObjectTypeData(dragData)) {
      const object: ObjectType = dragData as any;
      this.configuration.objectTypes$.pipe(takeOneTruthy()).subscribe(types => {
        const type = types.get(object.name);
        if (type) {
          this.configuration.handler.onObjectTypeDropped(type, { lngLat: lngLatCoord, segOffset, userScale });
        }
      });
    }
  }

  /**
   * Updates the managed source to render the given object.
   * Typically this would be called while the user is dragging an object on the map.
   * @param type The type of object to render.
   * @param lngLat The position of the object.
   * @param nearestSegOffset The track position closest to the object.
   */
  protected updateFeedback(netDef: NetworkDefinitionManager, type: ObjectTypeContainer, lngLat: LngLatCoord, nearestSegOffset: SegOffset): void {
    this.geoJSONSource.next(this.asObjectGeoJSON(netDef, type, lngLat, nearestSegOffset));
  }

  /**
   * Updates the managed source to render nothing.
   * Typically this would be called when the user has ended a drag interaction.
   */
  public removeFeedback(): void {
    this.geoJSONSource.next(emptyGeoJSONCollection());
  }

  protected asObjectGeoJSON(
    netDef: NetworkDefinitionManager,
    objectType: ObjectTypeContainer,
    pos: LngLatCoord,
    nearestSegOffset: SegOffset
  ): FeatureCollection {
    const features: any[] = [];

    let draggedType = objectType;
    if (objectType.children) {
      draggedType = objectType.children.find(c => c.promoted)?.child ?? objectType;
    }

    const commonProperties = {
      type: draggedType.name,
      typeName: draggedType.name,
      debugText: draggedType.name
    };

    const nearestTrackLL = nearestSegOffset ? netDef.segOffsetToLngLat(nearestSegOffset) : null;

    features.push({
      type: 'Feature',
      id: 'dragged object',
      properties: {
        ...commonProperties,
        state: draggedType.defaultState?.id,
        isIcon: true
      },
      geometry: {
        type: 'Point',
        coordinates: pos
      }
    });

    // TODO feature types should have a way of requesting this behaviour
    // Highlights the nearest bit of track
    if (nearestTrackLL) {
      // FIXME should (some of) this logic be moved somewhere more common? Range work looks generic
      const posXY = netDef.lngLatToXYIndividual(pos[0], pos[1]);
      const nearestTrackXY = netDef.lngLatToXYIndividual(nearestTrackLL[0], nearestTrackLL[1]);

      // we only care about the x offset when dragging because the y offset will always be 0'd.
      const range = objectType?.placementRules?.distanceFromTrackCentreline?.x;
      const isFixedDistFromTrack = range?.isExact();
      // Don't look like an error if the user has little chance of hitting the correct distance.
      let isInRange = isFixedDistFromTrack;
      let dist = -1;

      if (!isInRange) {
        // x offset is actually the hypotenuse - see https://adl-atlassian.simu.lan/confluence/x/cCSjCw
        dist = Math.sqrt(Math.pow(nearestTrackXY.x - posXY.x, 2) + Math.pow(nearestTrackXY.y - posXY.y, 2));
        isInRange = range ? range.includes(dist) : true;
      }

      const isBidirectional = objectType?.placementRules?.firstTrackAssocDefaultOrientation === Orientation.NONE;

      features.push({
        type: 'Feature',
        id: 'auto assoc',
        properties: {
          ...commonProperties,
          heading: isBidirectional
            ? undefined
            : toMapHeading(
                getTrackAssocHeading(netDef, {
                  ...nearestSegOffset,
                  orientation: Orientation.ALPHA_TO_BETA
                }).degrees
              ),
          isBidirectional,
          isInRange,
          isAssoc: !objectType?.hasNoTrackAssociation
        },
        geometry: {
          type: 'Point',
          coordinates: nearestTrackLL
        }
      });

      features.push({
        type: 'Feature',
        id: 'auto assoc dist',
        properties: {
          ...commonProperties,
          isInRange,
          dist: dist > 0 ? Number(dist).toFixed(2) + 'm' : undefined // FIXME need unit conversion here
        },
        geometry: {
          type: 'Point',
          coordinates: [(pos[0] + nearestTrackLL[0]) / 2, (pos[1] + nearestTrackLL[1]) / 2]
        }
      });

      features.push({
        type: 'Feature',
        id: 'auto assoc line',
        properties: {
          ...commonProperties,
          isInRange,
          isFixedDistFromTrack,
          isAssocLine: !objectType?.hasNoTrackAssociation
        },
        geometry: {
          type: 'MultiLineString',
          coordinates: [[nearestTrackLL, pos]]
        }
      });
    }

    return {
      type: 'FeatureCollection',
      features
    };
  }
}
