/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FeatureCollection } from 'geojson';
import { isNil } from 'lodash';
import { combineLatest, Observable, Subscription } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { IReachablePath, ObjectLayer } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { emptyGeoJSONCollection } from '../../../helpers/mapbox.source';
import { DragLayerManager, LayerManager, SourceManager, SourceManagerConfiguration } from '../../mapbox.layers';

export const OBJECTS_SOURCE_NAME = 'objects';
export const OBJECTS_SELECTED_SOURCE_NAME = 'objects_selected';
export const OBJECTS_SELECTED_TA_SOURCE_NAME = 'objects_selected_ta';
export const OBJECTS_SELECTED_TA_LINE_SOURCE_NAME = 'objects_selected_ta_line';

export interface ObjectsSourceManagerConfiguration extends SourceManagerConfiguration {
  layer$: Observable<ObjectLayer[]>;

  selectedObject$?: Observable<ObjectContainer>;
  selectedObjectGeoJson$?: Observable<{
    objects: FeatureCollection;
    trackAssociations: FeatureCollection;
    trackAssociationLines: FeatureCollection;
  }>;

  dataHasChanged$(): Observable<boolean>;

  triggerUpdate$(): Observable<boolean>;

  getUpdatedGeoJson(): FeatureCollection;

  subscribe(): void;

  unsubscribe(): void;

  destroy(): void;

  setHighlightedPath(highlightedPath$: Observable<IReachablePath>): void;

  setSelectedObject(selectedObject$: Observable<ObjectContainer>): void;

  setLayers(layer$: Observable<ObjectLayer[]>): void;
}

export class ObjectsSourceManager extends SourceManager<ObjectsSourceManagerConfiguration> {
  private selectedObjectId = -1;
  private subscription: Subscription = new Subscription();

  constructor(
    logger: Logging,
    layerManagers: Array<LayerManager>,
    dragLayerManagers: Array<DragLayerManager>,
    configuration?: ObjectsSourceManagerConfiguration
  ) {
    super(OBJECTS_SOURCE_NAME, configuration);

    this.subscription.add(
      combineLatest([this.configuration.dataHasChanged$(), this.configuration.triggerUpdate$(), this.configuration.layer$]).subscribe(
        ([hasChanged, triggerUpdate, layers]) => {
          if (hasChanged) {
            this.geoJSONSource.next(emptyGeoJSONCollection());
            return;
          }

          this.geoJSONSource.next(this.configuration.getUpdatedGeoJson());

          if (!isNil(layers)) {
            layerManagers.forEach(layerManager => layerManager.onLayersUpdate(layers));
            dragLayerManagers.forEach(layerManager => layerManager.onLayersUpdate(layers));
          }
        },
        err => logger.error('An error occured in ObjectsSourceManager', JSON.stringify(err))
      )
    );
  }

  public subscribe(): void {
    this.configuration.subscribe();
  }

  public selectedObjectGeoJSON(): Observable<{
    objects: FeatureCollection;
    trackAssociations: FeatureCollection;
    trackAssociationLines: FeatureCollection;
  }> {
    return this.configuration.selectedObjectGeoJson$;
  }

  override destroy(): SuperCalled {
    this.subscription.unsubscribe();
    this.configuration.unsubscribe();

    return super.destroy();
  }
}
