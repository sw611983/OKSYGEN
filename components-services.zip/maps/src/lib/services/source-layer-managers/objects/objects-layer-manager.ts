/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef, NgZone } from '@angular/core';
import Point from '@mapbox/point-geometry';
import { cloneDeep, isNil } from 'lodash';
import {
  CircleLayerSpecification,
  ExpressionSpecification,
  LineLayerSpecification,
  LngLatLike,
  Map,
  MapGeoJSONFeature,
  Popup,
  PopupOptions,
  SymbolLayerSpecification
} from 'maplibre-gl';

import { enableDragHandling } from '@oksygen-common-libraries/common';
import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';
import { defaultImages, ObjectLayer } from '@oksygen-sim-train-libraries/components-services/common';
import {
  getDisplayObject,
  MAPBOX_LAYER_FILTER,
  ObjectContainer,
  ObjectTypeName
} from '@oksygen-sim-train-libraries/components-services/objects/data';

import {
  // eslint-disable-next-line max-len
  renderDirectionalRingImageData, renderInsideBidiDirectionalRingImageData, renderInsideDirectionalRingImageData, renderRectangleImageData, renderRectangleSideObjectImageData
} from '../../../components/map-view/map-view.helpers';
import { MapColor } from '../../../helpers/map-color.enum';
import { MapInputEventData } from '../../../helpers/mapbox.source';
import { RawObjectSelectionHandler } from '../../../interfaces/selection-handlers/selection-object.interface';
import { LayerManager, LayerManagerConfiguration } from '../../mapbox.layers';
import {
  OBJECTS_SELECTED_SOURCE_NAME,
  OBJECTS_SELECTED_TA_LINE_SOURCE_NAME,
  OBJECTS_SELECTED_TA_SOURCE_NAME,
  OBJECTS_SOURCE_NAME
} from './objects-source-manager';

export const OBJECTS_LAYER_NAME = 'objects';
export const OBJECTS_DISPLAY_SATE_LAYER_NAME = 'objects display state';
export const OBJECTS_LABEL_LAYER_NAME = 'objects label';

export const NOT_A_POINT: ExpressionSpecification = ['!=', ['get', 'typeName'], ObjectTypeName.POINT];
export const ZOOM_LEVEL_IS_SUFFICIENT: ExpressionSpecification = ['>=', ['zoom'], ['get', 'minzoom']];
export const IS_ON_PATH: ExpressionSpecification = ['==', ['get', 'onPath'], true];
// NOTE: set in defaultObjectsSourceManagerConfiguration.updateSelectedObjectProperties()
export const IS_SELECTED: ExpressionSpecification = ['==', ['get', 'selected'], true];
export const IS_NOT_SELECTED: ExpressionSpecification = ['==', ['get', 'selected'], false];
export const IS_RENDERABLE: ExpressionSpecification = ['all', ZOOM_LEVEL_IS_SUFFICIENT, NOT_A_POINT, IS_ON_PATH, IS_NOT_SELECTED];
export const IS_DISPLAY_STATE_RENDERABLE: ExpressionSpecification = ['all', ZOOM_LEVEL_IS_SUFFICIENT, NOT_A_POINT, IS_ON_PATH];
export const HAS_ORIENTATION: ExpressionSpecification = ['has', 'orientation'];
export const IS_BIDIRECTIONAL: ExpressionSpecification = ['==', ['get', 'isBidirectional'], true];
export const IS_NOT_BIDIRECTIONAL: ExpressionSpecification = ['==', ['get', 'isBidirectional'], false];
export const ICON_SCALE: ExpressionSpecification = [
  'interpolate',
  ['linear'],
  ['zoom'],
  // set the max zoom level to show small icons, and that icon size
  16,
  0.5,
  // set the min zoom level to show big icons, and that icon size
  18,
  1
];

export const ICON_SCALE_SMALL: ExpressionSpecification = [
  'interpolate',
  ['linear'],
  ['zoom'],
  // set the max zoom level to show small icons, and that icon size
  16,
  0.4,
  // set the min zoom level to show big icons, and that icon size
  18,
  0.6
];

export const IS_ICON: ExpressionSpecification = ['get', 'isIcon'];

export interface ObjectsLayerManagerConfiguration extends LayerManagerConfiguration {
  getObject(id: number): ObjectContainer;
}

// TODO consider making this an IconLayerManager, as we may want all icons on a single layer (objects, markers, trigger incdicators, etc.)
export class ObjectsLayerManager extends LayerManager<ObjectsLayerManagerConfiguration> {
  public static readonly SELECTED_OBJECTS_LAYER_NAME = 'selected objects';
  public static readonly SELECTED_OBJECTS_LABEL_LAYER_NAME = 'selected objects label';
  public static readonly SELECTED_OBJECTS_CIRCLE_LAYER_NAME = 'selected objects circle';
  public static readonly SELECTED_DISPLAY_STATE_OBJECTS_CIRCLE_LAYER_NAME = 'selected display state objects circle';
  public static readonly SELECTED_OBJECTS_ARROW_LAYER_NAME = 'selected objects arrow';
  public static readonly SELECTED_OBJECTS_DISPLAY_STATE_LAYER_NAME = 'selected objects display state';
  public static readonly ASSOCS_LAYER_NAME = 'object assocs';
  private static readonly ASSOCS_LINE_LAYER_NAME = 'object assoc lines';
  private static readonly SELECTED_ASSOC_LAYER_NAME = 'object assoc selected';
  private static readonly SELECTED_ASSOC_BIDI_LAYER_NAME = 'object assoc bidi selected';
  public static readonly IS_TRIGGER_LAYER_NAME = 'object trigger';
  public static readonly IS_VIRTUAL_LAYER_NAME = 'object virtual';
  public static readonly IS_TRIGGER_LAYER_BACKGROUND_NAME = 'object trigger background';
  public static readonly DISPLAY_STATE_ICON_LAYER_NAME = 'object display state icon';
  public static readonly DISPLAY_STATE_ICON_BACKGROUND_LAYER_NAME = 'object display state icon background';

  public static readonly SELECTED_ICON_CIRCLE_DIRECTIONAL_NAME = '_selected_icon_di_circle';
  public static readonly SELECTED_ICON_CIRCLE_BIDIRECTIONAL_NAME = '_selected_icon_bidi_circle';
  public static readonly SELECTED_ICON_RECTANGLE_BIDIRECTIONAL_NAME = '_selected_icon_bidi_rectangle';
  public static readonly SELECTED_ASSOC_ICON_ARROW_NAME = '_selected_assoc_icon_arrow';
  public static readonly SELECTED_ASSOC_ICON_BIDI_ARROW_NAME = '_selected_assoc_bidi_icon_arrow';
  public static readonly ASSOC_ICON_DIRECTIONAL_NAME = '_assoc_di';
  public static readonly ASSOC_ICON_BIDIRECTIONAL_NAME = '_assoc_bidi';
  public static readonly IS_TRIGGER_ICON_NAME = '_object_is_trigger';
  public static readonly DEFAULT_OBJECT_ICON_NAME = 'default_object_icon';
  public static readonly DEFAULT_OBJECT_ICON_SIZE = 30;
  public static readonly IS_VIRTUAL_ICON_NAME = '_object_is_virtual';
  public static readonly SELECTED_ICON_TWO_OBJECTS_CIRCLE_DIRECTIONAL_NAME = '_selected_two_objects_icon_di_circle';
  public static readonly SELECTED_ICON_TWO_OBJECTS_CIRCLE_BIDIRECTIONAL_NAME = '_selected_two_objects_icon_bidi_circle';
  public static readonly SELECTED_ICON_RECTANGLE_SIDE_OBJECT_NAME = '_selected_icon_Side_object_rectangle';
  public static readonly SELECTED_DISPLAY_STATE_ICON_BACKGROUND_NAME = '_selected_display_sate_icon_background_circle';
  public static readonly DISPLAY_STATE_ICON_NAME = '_object_display_state_overridden';

  static readonly SELECTED_COLOUR = MapColor.PINK;
  static readonly SELECTED_COLOUR_FADED = MapColor.PALE_PINK;
  static readonly ARROW_COLOUR = ThemeColorHex.BLACK;
  static readonly TRIGGER_COLOUR = ThemeColorHex.BLACK;
  static readonly VIRTUAL_COLOUR = ThemeColorHex.BLACK;
  static readonly TRIGGER_COLOUR_FADED = ThemeColorHex.BLACK;

  static readonly IS_ASSOC: ExpressionSpecification = ['get', 'isAssoc'];
  static readonly IS_BIDIRECTIONAL: ExpressionSpecification = ['==', ['get', 'isBidirectional'], true];
  static readonly IS_ASSOC_LINE: ExpressionSpecification = ['get', 'isAssocLine'];
  static readonly IS_TRIGGER: ExpressionSpecification = ['get', 'isTrigger'];
  static readonly IS_VIRTUAL: ExpressionSpecification = ['get', 'isVirtual'];
  static readonly IS_DISPLAY_STATE: ExpressionSpecification = ['==', ['get', 'isDisplayState'], true];
  static readonly DISPLAY_STATE_STANDALONE_CONTAINER: ExpressionSpecification = [
    'case',
    ObjectsLayerManager.IS_DISPLAY_STATE,
    [
      'case',
      ['has', 'heading'],
      ObjectsLayerManager.SELECTED_ICON_TWO_OBJECTS_CIRCLE_DIRECTIONAL_NAME,
      ObjectsLayerManager.SELECTED_ICON_TWO_OBJECTS_CIRCLE_BIDIRECTIONAL_NAME
    ],
    [
      'case',
      ['has', 'heading'],
      ObjectsLayerManager.SELECTED_ICON_CIRCLE_DIRECTIONAL_NAME,
      ObjectsLayerManager.SELECTED_ICON_CIRCLE_BIDIRECTIONAL_NAME
    ]
  ];

  static readonly ASSOC_LAYER_LAYOUT = {
    'icon-image': [
      'case',
      ObjectsLayerManager.IS_BIDIRECTIONAL,
      ObjectsLayerManager.ASSOC_ICON_BIDIRECTIONAL_NAME,
      // ObjectsLayerManager.ASSOC_ICON_DIRECTIONAL_NAME
      ObjectsLayerManager.SELECTED_ASSOC_ICON_ARROW_NAME
    ] as ExpressionSpecification,
    'icon-size': 1,
    'icon-rotate': ['get', 'orientation'] as ExpressionSpecification,
    'icon-allow-overlap': true
  };

  static readonly ASSOC_LINE_PAINT = {
    'line-width': 2,
    'line-color': MapColor.PINK
  };

  protected hoveredObjectId: number;

  protected map: Map;
  // FIXME dragData should be format {type: 'foo', data: dataObj}
  protected dragData: any;
  protected rawInputHandler: RawObjectSelectionHandler;

  protected elRef: ElementRef;
  protected getDragPreview: (objectRef: any) => Element;
  protected popup: Popup | undefined;

  constructor(configuration: ObjectsLayerManagerConfiguration, zone: NgZone) {
    super(OBJECTS_LAYER_NAME, configuration, zone);
  }

  public override clear(): void {
    this.map = null;
    this.rawInputHandler = null;
  }

  public attachLayerTo(map: Map, elRef: ElementRef, getDragPreview: (objectRef: any) => Element): void {
    if (this.map) {
      throw new Error(`Can't attach to multiple maps!`);
    }

    if (!map) {
      throw new Error(`Can't attach to null maps!`);
    }

    this.map = map;
    this.elRef = elRef;
    this.getDragPreview = getDragPreview;

    if (this.mapHasSource(map, OBJECTS_SOURCE_NAME)) {
      const assocLineLayer: LineLayerSpecification = {
        id: ObjectsLayerManager.ASSOCS_LINE_LAYER_NAME,
        type: 'line',
        source: OBJECTS_SELECTED_TA_LINE_SOURCE_NAME,
        paint: ObjectsLayerManager.ASSOC_LINE_PAINT
      };

      const assocLayer: SymbolLayerSpecification = {
        id: ObjectsLayerManager.ASSOCS_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SELECTED_TA_SOURCE_NAME,
        layout: ObjectsLayerManager.ASSOC_LAYER_LAYOUT
      };

      // this is the purple rounded renctangle / circle you see behind the object when you click on it on the map
      const selectedLayer: SymbolLayerSpecification = {
        id: ObjectsLayerManager.SELECTED_OBJECTS_CIRCLE_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SELECTED_SOURCE_NAME,
        layout: {
          'icon-image': [
            'case',
            ['==', ['get', 'containerType'], 'standalone'],
            ObjectsLayerManager.DISPLAY_STATE_STANDALONE_CONTAINER,
            ['concat', ObjectsLayerManager.SELECTED_ICON_RECTANGLE_BIDIRECTIONAL_NAME, '_', ['get', 'selectedSize']]
          ],
          'icon-size': 1,
          'icon-anchor': ['case', ['==', ['get', 'containerType'], 'standalone'], 'center', ['==', ['get', 'stackDirection'], 'up'], 'bottom', 'top'],
          'icon-offset': ['get', 'selectedFirstOffset'],
          'icon-allow-overlap': true
        }
      };

      const selectedDisplayStateLayer: SymbolLayerSpecification = {
        id: ObjectsLayerManager.SELECTED_DISPLAY_STATE_OBJECTS_CIRCLE_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SELECTED_SOURCE_NAME,
        layout: {
          'icon-image': ObjectsLayerManager.SELECTED_ICON_RECTANGLE_SIDE_OBJECT_NAME,
          'icon-size': 1,
          'icon-anchor': ['case', ['==', ['get', 'containerType'], 'standalone'], 'center', ['==', ['get', 'stackDirection'], 'up'], 'bottom', 'top'],
          'icon-offset': ['get', 'selectedDisplayStateOffset'],
          'icon-allow-overlap': true
        },
        filter: ['all', ObjectsLayerManager.IS_DISPLAY_STATE, ['!=', ['get', 'containerType'], 'standalone']]
      };

      // if the track assoc is covered by the icon show the assoc on top of the icon
      const selectedAssocLayer: SymbolLayerSpecification = {
        id: ObjectsLayerManager.SELECTED_ASSOC_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SELECTED_SOURCE_NAME,
        layout: {
          'icon-image': ObjectsLayerManager.SELECTED_ASSOC_ICON_ARROW_NAME,
          'icon-size': 1,
          'icon-rotate': ['get', 'orientation'],
          'icon-allow-overlap': true
        },
        paint: {
          // FIXME - hardcoded by necessity but not ideal because the correct value varies based on first child height
          // problem is icon-translate doesn't support data-driven-styling so you can't assign it to a variable
          // can't use icon-offset because it is applied AFTER icon-rotate so it goes in the wrong direction
          // the solution would be to use icon-offset but use trig to determine the correct offset based on height + the rotation
          'icon-translate': [0, 30]
        },
        filter: ['all', IS_NOT_BIDIRECTIONAL]
      };

      // if the track assoc is covered by the icon show the assoc on top of the icon
      const selectedAssocLayerBidi: SymbolLayerSpecification = {
        id: ObjectsLayerManager.SELECTED_ASSOC_BIDI_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SELECTED_SOURCE_NAME,
        layout: {
          'icon-image': ObjectsLayerManager.SELECTED_ASSOC_ICON_BIDI_ARROW_NAME,
          'icon-size': 1,
          'icon-rotate': ['get', 'orientation'],
          'icon-allow-overlap': true
        },
        paint: {
          // FIXME - hardcoded by necessity but not ideal because the correct value varies based on first child height
          // problem is icon-translate doesn't support data-driven-styling so you can't assign it to a variable
          // can't use icon-offset because it is applied AFTER icon-rotate so it goes in the wrong direction
          // the solution would be to use icon-offset but use trig to determine the correct offset based on height + the rotation
          'icon-translate': [0, 30]
        },
        filter: ['all', IS_BIDIRECTIONAL]
      };

      // const triggerIconScale = 1;
      const isTriggerLayer: SymbolLayerSpecification = {
        id: ObjectsLayerManager.IS_TRIGGER_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SOURCE_NAME,
        minzoom: 14,
        layout: {
          'icon-image': ObjectsLayerManager.IS_TRIGGER_ICON_NAME,
          'icon-size': ICON_SCALE_SMALL,
          // 'icon-offset': ['interpolate', ['zoom'],
          // 16, ['literal', [0, 40]],
          // 18, ['literal', [0, 55]]
          // ],
          'icon-allow-overlap': true
        },
        paint: {
          'icon-color': ObjectsLayerManager.TRIGGER_COLOUR,
          // 'icon-halo-color': ThemeColorHex.WHITE,
          // 'icon-halo-width': 2,
          // 'icon-halo-blur': 10,
          'icon-translate': ['interpolate', ['linear'], ['zoom'], 16, ['literal', [5, 15]], 18, ['literal', [5, 35]]] as any
          // 'icon-translate': ['interpolate',['linear'],['zoom'],
          //   10, ['literal', [0, 0]],
          //   14, ['literal', [0, 15]],
          //   22, ['literal', [0, 40]]
          // ]
        },
        filter: ['all', ObjectsLayerManager.IS_TRIGGER, ZOOM_LEVEL_IS_SUFFICIENT, IS_ON_PATH]
      };

      const isVirtualLayer: SymbolLayerSpecification = {
        id: ObjectsLayerManager.IS_VIRTUAL_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SOURCE_NAME,
        minzoom: 14,
        layout: {
          'icon-image': ObjectsLayerManager.IS_VIRTUAL_ICON_NAME,
          'icon-size': ICON_SCALE,
          // 'icon-offset': ['interpolate', ['zoom'],
          // 16, ['literal', [0, 40]],
          // 18, ['literal', [0, 55]]
          // ],
          'icon-allow-overlap': true
        },
        paint: {
          'icon-color': ObjectsLayerManager.VIRTUAL_COLOUR,
          'icon-halo-color': ThemeColorHex.WHITE,
          'icon-halo-width': 2.5,
          'icon-halo-blur': 15,
          'icon-translate': ['interpolate', ['linear'], ['zoom'], 16, ['literal', [15, 5]], 18, ['literal', [35, 5]]]
          // // 'icon-translate': ['interpolate',['linear'],['zoom'],
          //   10, ['literal', [0, 0]],
          //   14, ['literal', [0, 15]],
          //   22, ['literal', [0, 40]]
          // ]
        },
        filter: ['all', ObjectsLayerManager.IS_VIRTUAL, ZOOM_LEVEL_IS_SUFFICIENT, IS_ON_PATH]
      };

      const triggerBackgroundLayer: CircleLayerSpecification = {
        id: ObjectsLayerManager.IS_TRIGGER_LAYER_BACKGROUND_NAME,
        type: 'circle',
        source: OBJECTS_SOURCE_NAME,
        minzoom: 14,
        paint: {
          'circle-color': ThemeColorHex.WHITE,
          'circle-opacity': 0.6,
          // the more zoomed in bigger we need to be
          'circle-radius': ['interpolate', ['linear'], ['zoom'], 16, 10, 18, 16],
          'circle-translate': ['interpolate', ['linear'], ['zoom'], 16, ['literal', [5, 15]], 18, ['literal', [5, 35]]] as any
        },
        filter: ['all', ObjectsLayerManager.IS_TRIGGER, ZOOM_LEVEL_IS_SUFFICIENT, IS_ON_PATH]
      };

      const objectLabelLayerFactory: (id: string, source: string, filter: any, minZoom: number, iconSize: any) => SymbolLayerSpecification = (
        id,
        source,
        filter,
        minzoom,
        iconSize
      ) => ({
        id,
        type: 'symbol',
        source,
        minzoom,
        layout: {
          'text-field': ['format', ['get', 'label'], { 'font-scale': 0.65, 'text-color': ['get', 'labelColour'] }],
          'text-font': ['KlokanTech Noto Sans Regular'],
          'text-allow-overlap': true,
          'text-offset': ['get', 'labelOffset']
        },
        paint: {
          'text-halo-width': 4,
          'text-halo-color': ThemeColorHex.WHITE
        },
        filter: ['all', IS_ICON, filter]
      });

      const objectLayerFactory: (id: string, source: string, filter: any, minZoom: number, iconSize: any) => SymbolLayerSpecification = (
        id,
        source,
        filter,
        minzoom,
        iconSize
      ) => ({
        id,
        type: 'symbol',
        source,
        minzoom,
        layout: {
          'icon-image': MAPBOX_LAYER_FILTER,
          'icon-size': iconSize,
          'icon-allow-overlap': true,
          // 'icon-offset': ['get', 'translate'],
          'icon-offset': [
            'step',
            ['zoom'],
            ['literal', [0, 0]],
            17, ['get', 'translate']
          ],
          // 'icon-offset': [
          //   'case',
          //   ['>=', ['zoom'], 17],
          //   ['literal', [0, 0]],
          //   ['get', 'translate']
          // ],
          'symbol-sort-key': [
            'case',
            ['==', ['get', 'isTrigger'], true],
            //['==', ['get', 'isVirtual'], true],
            1, // we want to render objects with triggers on top
            0
          ]
        },
        filter: ['all', IS_ICON, filter]
      });

      const selectedObjectLayerFactory: (id: string, source: string, filter: any, minZoom: number, iconSize: any) => SymbolLayerSpecification = (
        id,
        source,
        filter,
        minzoom,
        iconSize
      ) => ({
        id,
        type: 'symbol',
        source,
        minzoom,
        layout: {
          'icon-image': MAPBOX_LAYER_FILTER,
          'icon-size': iconSize,
          'icon-allow-overlap': true,
          'icon-offset': ['get', 'translate'],
          'symbol-sort-key': [
            'case',
            ['==', ['get', 'isTrigger'], true],
            //['==', ['get', 'isVirtual'], true],
            1, // we want to render objects with triggers on top
            0
          ]
        },
        filter: ['all', IS_ICON, filter]
      });

      const objectDisplayStateLayerFactory: (id: string, source: string, filter: any, minZoom: number, iconSize: any) => SymbolLayerSpecification = (
        id,
        source,
        filter,
        minzoom,
        iconSize
      ) => ({
        id,
        type: 'symbol',
        source,
        minzoom,
        layout: {
          'icon-image': ['get', 'displayStateIcon'],
          'icon-size': iconSize,
          'icon-allow-overlap': true,
          'icon-offset': ['get', 'displayStateTranslate'],
          'symbol-sort-key': [
            'case',
            ['==', ['get', 'isTrigger'], true],
            1, // we want to render objects with triggers on top
            0
          ]
        },
        paint: {
          'icon-opacity': 0.5
        },
        filter: ['all', IS_ICON, ObjectsLayerManager.IS_DISPLAY_STATE, filter]
      });

      const displayStateIconLayer: SymbolLayerSpecification = {
        id: ObjectsLayerManager.DISPLAY_STATE_ICON_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SOURCE_NAME,
        minzoom: 18,
        layout: {
          'icon-image': ObjectsLayerManager.DISPLAY_STATE_ICON_NAME,
          'icon-size': ICON_SCALE_SMALL,
          'icon-allow-overlap': true,
          'icon-offset': ['get', 'displayStateIcontranslate']
        },
        paint: {
          'icon-color': ThemeColorHex.BLACK
        },
        filter: ['all', ['==', ['get', 'isDisplayStateOverriden'], true]]
      };

      const displayStateIconBackgroundLayer: SymbolLayerSpecification = {
        id: ObjectsLayerManager.DISPLAY_STATE_ICON_BACKGROUND_LAYER_NAME,
        type: 'symbol',
        source: OBJECTS_SOURCE_NAME,
        minzoom: 18,
        layout: {
          'icon-image': ObjectsLayerManager.SELECTED_DISPLAY_STATE_ICON_BACKGROUND_NAME,
          'icon-size': ICON_SCALE_SMALL,
          'icon-allow-overlap': true,
          'icon-offset': ['get', 'displayStateIcontranslate']
        },
        paint: {
          'icon-opacity': 0.5
        },
        filter: ['all', ['==', ['get', 'isDisplayStateOverriden'], true]]
      };

      // bottom layer
      map.addLayer(objectLayerFactory(OBJECTS_LAYER_NAME, OBJECTS_SOURCE_NAME, IS_RENDERABLE, 14, ICON_SCALE));
      map.addLayer(objectDisplayStateLayerFactory(OBJECTS_DISPLAY_SATE_LAYER_NAME, OBJECTS_SOURCE_NAME, IS_DISPLAY_STATE_RENDERABLE, 14, ICON_SCALE));
      map.addLayer(objectLabelLayerFactory(OBJECTS_LABEL_LAYER_NAME, OBJECTS_SOURCE_NAME, IS_RENDERABLE, 14, ICON_SCALE));
      map.addLayer(displayStateIconBackgroundLayer);
      map.addLayer(displayStateIconLayer);
      // All layers above this only show info about the selected object
      map.addLayer(assocLineLayer);
      map.addLayer(assocLayer);
      // map.addLayer(selectedArrowLayer);
      map.addLayer(selectedLayer);
      map.addLayer(selectedDisplayStateLayer);
      map.addLayer(selectedObjectLayerFactory(ObjectsLayerManager.SELECTED_OBJECTS_LAYER_NAME, OBJECTS_SELECTED_SOURCE_NAME, IS_SELECTED, 0, 1));
      map.addLayer(
        objectDisplayStateLayerFactory(ObjectsLayerManager.SELECTED_OBJECTS_DISPLAY_STATE_LAYER_NAME, OBJECTS_SELECTED_SOURCE_NAME, IS_SELECTED, 0, 1)
      );
      map.addLayer(objectLabelLayerFactory(ObjectsLayerManager.SELECTED_OBJECTS_LABEL_LAYER_NAME, OBJECTS_SELECTED_SOURCE_NAME, IS_SELECTED, 0, 1));
      map.addLayer(selectedAssocLayer);
      map.addLayer(selectedAssocLayerBidi);
      map.addLayer(triggerBackgroundLayer);
      map.addLayer(isTriggerLayer);
      map.addLayer(isVirtualLayer);
      // top layer
    }

    // Note that using 'mouseenter' seems like it would be more performant,
    // but it allows the previous feature to remain highlighted if the mouse moves quickly to a new set.
    map.on('mousemove', OBJECTS_LAYER_NAME, e => {
      this.zone?.runOutsideAngular(() => {
        if (!e.originalEvent.defaultPrevented) {
          map.getCanvas().style.cursor = 'pointer';
          if (e?.features?.length > 0) {
            this.updateHover(map, Number(e.features[0].id));
          }
        }
      });
    });
    map.on('mouseleave', OBJECTS_LAYER_NAME, e => {
      this.zone?.runOutsideAngular(() => {
        map.getCanvas().style.cursor = '';
        this.updateHover(map, null);
      });
    });
  }

  public override addImagesToMap(
    addDirectionalImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    addDirectionalRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    addDirectionalTwoObjectsRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void
  ): void {
    addDirectionalImageToMap(
      ObjectsLayerManager.ASSOC_ICON_DIRECTIONAL_NAME,
      ObjectsLayerManager.SELECTED_COLOUR,
      ObjectsLayerManager.SELECTED_COLOUR_FADED,
      false
    );
    addDirectionalImageToMap(
      ObjectsLayerManager.ASSOC_ICON_BIDIRECTIONAL_NAME,
      ObjectsLayerManager.SELECTED_COLOUR,
      ObjectsLayerManager.SELECTED_COLOUR_FADED,
      true
    );
    addDirectionalRingImageToMap(
      ObjectsLayerManager.SELECTED_ICON_CIRCLE_DIRECTIONAL_NAME,
      ObjectsLayerManager.SELECTED_COLOUR,
      ObjectsLayerManager.SELECTED_COLOUR_FADED,
      false
    );
    addDirectionalRingImageToMap(
      ObjectsLayerManager.SELECTED_ICON_CIRCLE_BIDIRECTIONAL_NAME,
      ObjectsLayerManager.SELECTED_COLOUR,
      ObjectsLayerManager.SELECTED_COLOUR_FADED,
      true
    );
    addDirectionalTwoObjectsRingImageToMap(
      ObjectsLayerManager.SELECTED_ICON_TWO_OBJECTS_CIRCLE_DIRECTIONAL_NAME,
      ObjectsLayerManager.SELECTED_COLOUR,
      ObjectsLayerManager.SELECTED_COLOUR_FADED,
      false
    );
    addDirectionalTwoObjectsRingImageToMap(
      ObjectsLayerManager.SELECTED_ICON_TWO_OBJECTS_CIRCLE_BIDIRECTIONAL_NAME,
      ObjectsLayerManager.SELECTED_COLOUR,
      ObjectsLayerManager.SELECTED_COLOUR_FADED,
      true
    );

    const default_object = new Image();
    default_object.src = 'assets/images/object_placeholder.svg';
    default_object.width = 30;
    default_object.height = 30;

    // add an image for objects associated with a rule template (ie, a rule template that triggers at an object location)
    const trigger_image = new Image();
    trigger_image.src = 'assets/images/rule_editor.svg';
    trigger_image.width = 24;
    trigger_image.height = 24;

    // add an image for objects associated with a rule template (ie, a rule template that triggers at an object location)
    const eye_image = new Image();
    eye_image.src = 'assets/images/eye_slash.svg';
    eye_image.width = 24;
    eye_image.height = 24;

    const display_state_override = new Image();
    display_state_override.src = 'assets/images/status.svg';
    display_state_override.width = 24;
    display_state_override.height = 24;

    setTimeout(() => {
      if (!this.map.hasImage(ObjectsLayerManager.DEFAULT_OBJECT_ICON_NAME)) {
        this.map.addImage(ObjectsLayerManager.DEFAULT_OBJECT_ICON_NAME, default_object, { sdf: false }); // sdf allows us to change the colour
      }
      if (!this.map.hasImage(ObjectsLayerManager.IS_TRIGGER_ICON_NAME)) {
        this.map.addImage(ObjectsLayerManager.IS_TRIGGER_ICON_NAME, trigger_image, { sdf: true });
      }
      // support feature containers with combined icon size of 1000px (which is around 20 children)
      if (!this.map.hasImage(ObjectsLayerManager.IS_VIRTUAL_ICON_NAME)) {
        this.map.addImage(ObjectsLayerManager.IS_VIRTUAL_ICON_NAME, eye_image, { sdf: true });
      }
      // support feature containers with combined icon size of 1000px (which is around 20 children)
      if (!this.map.hasImage(ObjectsLayerManager.DISPLAY_STATE_ICON_NAME)) {
        this.map.addImage(ObjectsLayerManager.DISPLAY_STATE_ICON_NAME, display_state_override, { sdf: true });
      }

      const size = 10;
      for (let i = 1; i <= 100; i++) {
        const rectangle = renderRectangleImageData(ObjectsLayerManager.SELECTED_COLOUR_FADED, ObjectsLayerManager.SELECTED_COLOUR, 60, i * size);
        const name = `${ObjectsLayerManager.SELECTED_ICON_RECTANGLE_BIDIRECTIONAL_NAME}_${i}`;
        if (!this.map.hasImage(name)) {
          this.map.addImage(name, rectangle);
        }
      }

      if (!this.map.hasImage(ObjectsLayerManager.SELECTED_ASSOC_ICON_ARROW_NAME)) {
        const assocArrow = renderInsideDirectionalRingImageData(
          ObjectsLayerManager.SELECTED_COLOUR_FADED,
          ObjectsLayerManager.SELECTED_COLOUR,
          ObjectsLayerManager.ARROW_COLOUR,
          20
        );
        this.map.addImage(ObjectsLayerManager.SELECTED_ASSOC_ICON_ARROW_NAME, assocArrow);
      }
      if (!this.map.hasImage(ObjectsLayerManager.SELECTED_ASSOC_ICON_BIDI_ARROW_NAME)) {
        const assocArrowBidi = renderInsideBidiDirectionalRingImageData(
          ObjectsLayerManager.SELECTED_COLOUR_FADED,
          ObjectsLayerManager.SELECTED_COLOUR,
          ObjectsLayerManager.ARROW_COLOUR,
          20
        );
        this.map.addImage(ObjectsLayerManager.SELECTED_ASSOC_ICON_BIDI_ARROW_NAME, assocArrowBidi);
      }
      if (!this.map.hasImage(ObjectsLayerManager.SELECTED_ICON_RECTANGLE_SIDE_OBJECT_NAME)) {
        const rectangleSideObject = renderRectangleSideObjectImageData(
          ObjectsLayerManager.SELECTED_COLOUR_FADED,
          ObjectsLayerManager.SELECTED_COLOUR,
          55
        );
        this.map.addImage(ObjectsLayerManager.SELECTED_ICON_RECTANGLE_SIDE_OBJECT_NAME, rectangleSideObject);
      }
      if (!this.map.hasImage(ObjectsLayerManager.SELECTED_DISPLAY_STATE_ICON_BACKGROUND_NAME)) {
        const displayIconBackground = renderDirectionalRingImageData(
          ThemeColorHex.WHITE,
          ThemeColorHex.WHITE,
          false,
          48
        );
        this.map.addImage(ObjectsLayerManager.SELECTED_DISPLAY_STATE_ICON_BACKGROUND_NAME, displayIconBackground);
      }
    });
  }

  public override onLayersUpdate(layerArray: Array<ObjectLayer>): void {
    let filters: ExpressionSpecification;
    // this will throw an error (cannot read property filter of undefined) if the sources haven't been added yet.
    // this happens when we get a layer update AFTER map has been created but BEFORE the sources get added
    try {
      filters = cloneDeep(this.map.getFilter(OBJECTS_LAYER_NAME) as ExpressionSpecification);
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (err) {}
    if (!filters) {
      return;
    }
    // FIXME magic number - 4 is the how many default filters we have for features...
    // FIXME magic number 2 is the position of our 'all' array which we append layers to
    filters[LayerManager.ALL_FILTERS_INDEX] = (filters[LayerManager.ALL_FILTERS_INDEX] as Array<any>).slice(0, LayerManager.DEFAULT_FILTERS_COUNT);
    const layerFilters: any[] = ['any'];
    // featureFilters = featureFilters.slice(0, 4); // remove all non-default filters
    for (const layer of layerArray) {
      if (layer.checked) {
        // TODO modify filters
        layerFilters.push(['==', ['get', 'layer'], layer.name]);
        // TODO do this recursively
        this.processSubLayers(layer, layerFilters);
      }
    }
    //LayerFilter needs to be applied even if the length is 1
    //And length = 0 not possible as we initialised
    //if (layerFilters.length > 1) {
    (filters[LayerManager.ALL_FILTERS_INDEX] as Array<any>).push(layerFilters);
    //}

    this.map.setFilter(OBJECTS_LAYER_NAME, filters);
    // TODO need to do other layers (ie background, trains etc)
  }

  protected processSubLayers(layer: ObjectLayer, layerFilters: any[]): void {
    if (layer.subLayers) {
      for (const subLayer of layer.subLayers) {
        if (subLayer.checked) {
          layerFilters.push(['==', ['get', 'layer'], subLayer.name]);
          this.processSubLayers(subLayer, layerFilters);
        }
      }
    }
  }

  protected updateHover(map: Map, newId: number | null): void {
    if (this.hoveredObjectId) {
      this.setObjectHoverState(map, this.hoveredObjectId, false);
    }

    if (newId) {
      this.hoveredObjectId = newId;
      this.setObjectHoverState(map, this.hoveredObjectId, true);
    }
  }

  protected setObjectHoverState(map: Map, trainId: number, hover: boolean): void {
    const source = OBJECTS_SOURCE_NAME;

    // todo this is currently vehicleId!!!
    map.setFeatureState({ source, id: trainId }, { hover });
  }

  /**
   * Sets a handler for handling "raw" callbacks from listeners on the Mapbox map.
   *
   * @param rawHandler Contains the callbacks that handle updates.
   */
  override setInputHandler(rawHandler: RawObjectSelectionHandler): void {
    if (!rawHandler) {
      rawHandler = {
        onObjectHovered: (id, data): void => {},
        onObjectClicked: (id, data): void => {},
        onObjectDown: (id, data): boolean => false
      };
    }

    const firstCall = !this.rawInputHandler;

    this.rawInputHandler = rawHandler;

    // Don't set extra listeners.
    if (!firstCall) {
      return;
    }

    // Handling interaction with the trains

    const onObjectHover = (e: MapInputEventData): void => {
      this.zone?.runOutsideAngular(() => {
        this.interactWithObject(this.rawInputHandler.onObjectHovered, this.map, e, [OBJECTS_LAYER_NAME]);
      });
    };

    this.map.on('mousemove', OBJECTS_LAYER_NAME, onObjectHover);

    this.onClick(true);

    const onObjectDown = (e: MapInputEventData): void => {
      if (this.interactWithObject(this.rawInputHandler.onObjectDown, this.map, e, [OBJECTS_LAYER_NAME])) {
        // Prevent the default map drag behavior.
        // Allows the HTML5 drag interaction to begin.
        e.preventDefault();
      }
    };

    this.map.on('mousedown', OBJECTS_LAYER_NAME, e => {
      this.map.getCanvas().style.cursor = 'grab';
      onObjectDown(e);
    });

    this.map.on('touchstart', OBJECTS_LAYER_NAME, e => {
      if (e.points.length !== 1) return;
      onObjectDown(e);
    });
  }

  // TODO very similar to code in TrainsLayerManager. Commonise?
  /**
   * Does some quick sanity checks before initiating an interaction with the clicked location.
   *
   * @param callback invoked when a geojson feature (in this typically means tracks or selection markers) is near the clicked location.
   *   May return a boolean to indicate whether the interaction should proceed (typically only applicable for the start of a drag.)
   * @param alwaysFire indicates whether we should invoke the callback when there are no features near the point.
   *
   * @returns a boolean indicating whether the interaction should proceed.
   */
  protected interactWithObject(callback: (id: number, data: any) => void | boolean, map: Map, e: any, layers: string[], alwaysFire = false): boolean {
    const featuresNearClick = e.point ? this.getFeaturesFuzzy(map, e.point, layers) : [];

    if (alwaysFire || featuresNearClick?.length > 0) {
      this.dragData = featuresNearClick?.[0]?.properties?.dragData ?? this.dragData;
      return !!callback(featuresNearClick[0].id as number, this.dragData);
    }

    return false;
  }

  // TODO very similar to code in TrainsLayerManager. Commonise?
  protected getFeaturesFuzzy(map: Map, point: Point, layers: string[]): MapGeoJSONFeature[] {
    // Consider npx reactangle area around clicked point
    const n = 0;
    return map.queryRenderedFeatures(
      [
        [point.x - n, point.y - n],
        [point.x + n, point.y + n]
      ],
      {
        layers
      }
    );
  }

  protected onClick(stopPropagation: boolean): void {
    this.map.on('click', OBJECTS_LAYER_NAME, event => {
      if (event?.features?.length > 0 && !event.originalEvent.defaultPrevented) {
        if (stopPropagation) {
          event.originalEvent.preventDefault();
        }
        if (this.zone) {
          this.zone.run(() => this.displayFeatureDisambiguationPopup(event.features, event.lngLat));
        } else {
          this.displayFeatureDisambiguationPopup(event.features, event.lngLat);
        }
      }
    });
  }

  private displayFeatureDisambiguationPopup(features: GeoJSON.Feature[], lnglat: LngLatLike): void {
    if (features.length > 1) {
      this.generateMapboxFeatureClusterSelectionPopupHtml(features).then(html => {
        const popupOptions: PopupOptions = {
          closeOnClick: true,
          closeButton: false,
          closeOnMove: true,
          anchor: 'center',
          className: 'mapbox-popup-container'
        };
        this.removePopup();
        this.popup = new Popup(popupOptions).setLngLat(lnglat).setHTML(html);
        this.popup.addTo(this.map);
        features.forEach(feature => {
          const featureEle = this.elRef.nativeElement.querySelector(`#mapbox_popup_feature_${feature.id}`);

          if (featureEle) {
            const objectRef = feature.properties.dragData;

            // FIXME memory leak - should use Renderer2 (deals with it automatically) or removeEventListener()
            featureEle?.addEventListener('click', this.selectObject.bind(this, feature.id as number, feature.properties.dragData));

            enableDragHandling(
              featureEle,
              () => objectRef,
              () => this.getDragPreview(objectRef)
            );
          }
        });
      });
    } else {
      this.selectObject(features[0].id as number, features[0].properties.dragData);
    }
  }

  protected selectObject(id: number, data: any): void {
    if (id) {
      this.rawInputHandler.onObjectClicked(id, data);
    }

    this.removePopup();
  }

  protected removePopup(): void {
    if (!isNil(this.popup)) {
      this.popup.remove();
      this.popup = undefined;
    }
  }

  private async generateMapboxFeatureClusterSelectionPopupHtml(features: GeoJSON.Feature[]): Promise<string> {
    let html = ``;
    for (const feature of features) {
      const object = this.configuration.getObject(feature.properties.id);
      const displayObject = getDisplayObject(object); // if children, get promoted child
      let image = '';
      try {
        image = await displayObject?.selectedState?.icons?.small?.asUri();
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
      } catch (e) {
        image = defaultImages.object;
      }
      html += `
        <section id="mapbox_popup_feature_${feature.id}">
          <img src="${image}">
        </section>
      `;
    }
    return html;
  }
}
