/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ExpressionSpecification, LineLayerSpecification, Map, SymbolLayerSpecification } from 'maplibre-gl';

import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';

import { MapColor } from '../../../helpers/map-color.enum';
import { DragLayerManager } from '../../mapbox.layers';
import { OBJECT_DRAG_SOURCE_MANAGER_NAME } from './object-drag-source-manager';
import { IS_ICON, ObjectsLayerManager } from './objects-layer-manager';

export const OBJECT_DRAG_LAYER_NAME = 'dndObject';

/**
 * Sets up layers for displaying an Object being dragged on the map.
 */
export class ObjectDragLayerManager extends DragLayerManager {
  private static readonly ASSOCS_LAYER_NAME = 'dndObjectAssoc';
  private static readonly ASSOC_DIST_LAYER_NAME = 'dndObjectAssocDist';
  private static readonly ASSOCS_LINE_LAYER_NAME = 'dndObjectAssocLine';
  private static readonly SNAP_LINE_LAYER_NAME = 'dndObjectSnapLine';

  public static readonly NEAREST_TRACK_ICON_DIRECTIONAL_NAME = '_near_track_di';
  public static readonly NEAREST_TRACK_ICON_BIDIRECTIONAL_NAME = '_near_track_bidi';
  public static readonly NEAREST_TRACK_INVALID_ICON_DIRECTIONAL_NAME = '_near_track_invalid_di';
  public static readonly NEAREST_TRACK_INVALID_ICON_BIDIRECTIONAL_NAME = '_near_track_invalid_bidi';

  static readonly IS_IN_RANGE: ExpressionSpecification = ['get', 'isInRange'];
  static readonly IS_DIST: ExpressionSpecification = ['has', 'dist'];
  static readonly IS_FIXED_DISTANCE: ExpressionSpecification = ['get', 'isFixedDistFromTrack'];

  constructor() {
    super(OBJECT_DRAG_LAYER_NAME);
  }

  public attachLayerTo(map: Map): void {
    if (this.mapHasSource(map, OBJECT_DRAG_SOURCE_MANAGER_NAME)) {
      const ASSOC_LINE_COLOUR: ExpressionSpecification = [
        'case', ['==', ObjectDragLayerManager.IS_IN_RANGE, true], MapColor.OBJECT_DRAG_LAYER_PRIMARY, MapColor.RED
      ];

      const assocLineLayer: LineLayerSpecification = {
        id: ObjectDragLayerManager.ASSOCS_LINE_LAYER_NAME,
        type: 'line',
        source: OBJECT_DRAG_SOURCE_MANAGER_NAME,
        paint: {
          ...ObjectsLayerManager.ASSOC_LINE_PAINT,
          'line-color': ASSOC_LINE_COLOUR
        },
        filter: ['all', ObjectsLayerManager.IS_ASSOC_LINE, ['!=', ObjectDragLayerManager.IS_FIXED_DISTANCE, true]]
      };
      // We seem to be unable to use expressions in line dash arrays :(
      const assocLineLayer2: LineLayerSpecification = {
        id: ObjectDragLayerManager.SNAP_LINE_LAYER_NAME,
        type: 'line',
        source: OBJECT_DRAG_SOURCE_MANAGER_NAME,
        paint: {
          ...ObjectsLayerManager.ASSOC_LINE_PAINT,
          'line-dasharray': [1, 1],
          'line-color': ASSOC_LINE_COLOUR
        },
        filter: ['all', ObjectsLayerManager.IS_ASSOC_LINE, ObjectDragLayerManager.IS_FIXED_DISTANCE]
      };

      const OUT_OF_RANGE_ICON_IMAGE: ExpressionSpecification = [
        'case',
        ObjectsLayerManager.IS_BIDIRECTIONAL,
        ObjectDragLayerManager.NEAREST_TRACK_INVALID_ICON_BIDIRECTIONAL_NAME,
        ObjectDragLayerManager.NEAREST_TRACK_INVALID_ICON_DIRECTIONAL_NAME
      ];

      const ICON_IMAGE: ExpressionSpecification = [
        'case',
        ObjectsLayerManager.IS_BIDIRECTIONAL,
        ObjectDragLayerManager.NEAREST_TRACK_ICON_BIDIRECTIONAL_NAME,
        ObjectDragLayerManager.NEAREST_TRACK_ICON_DIRECTIONAL_NAME
      ];

      const assocLayer: SymbolLayerSpecification = {
        id: ObjectDragLayerManager.ASSOCS_LAYER_NAME,
        type: 'symbol',
        source: OBJECT_DRAG_SOURCE_MANAGER_NAME,
        layout: {
          ...ObjectsLayerManager.ASSOC_LAYER_LAYOUT,
          'icon-image': ['case', ObjectDragLayerManager.IS_IN_RANGE, ICON_IMAGE, OUT_OF_RANGE_ICON_IMAGE]
        },
        filter: ObjectsLayerManager.IS_ASSOC
      };

      // TODO can we only show this on move?
      const objectLayer: SymbolLayerSpecification = {
        id: OBJECT_DRAG_LAYER_NAME,
        type: 'symbol',
        source: OBJECT_DRAG_SOURCE_MANAGER_NAME,
        paint: {
          'icon-opacity': 1 // note this doesn't work >:(
        },
        layout: {
          'icon-image': ['concat', 'FT', ['get', 'type'], 'S', ['get', 'state']],
          'icon-size': [
            'interpolate',
            ['linear'],
            ['zoom'],
            // set the max zoom level to show small icons, and that icon size
            16,
            0.5,
            // set the min zoom level to show big icons, and that icon size
            18,
            1
          ],
          'icon-allow-overlap': true
        },
        filter: IS_ICON
      };

      const distLayer: SymbolLayerSpecification = {
        id: ObjectDragLayerManager.ASSOC_DIST_LAYER_NAME,
        type: 'symbol',
        source: OBJECT_DRAG_SOURCE_MANAGER_NAME,
        layout: {
          'text-field': [
            'format',
            ['get', 'dist'],
            {
              'font-scale': 0.65,
              'text-color': ['case', ObjectDragLayerManager.IS_IN_RANGE, ThemeColorHex.BLACK, MapColor.RED]
            }
          ],
          'text-font': ['KlokanTech Noto Sans Regular']
        },
        paint: {
          'text-halo-width': 4,
          'text-halo-color': ThemeColorHex.WHITE
        },
        filter: ObjectDragLayerManager.IS_DIST
      };

      map.addLayer(assocLineLayer); // bottom layer
      map.addLayer(assocLineLayer2);
      map.addLayer(assocLayer);
      map.addLayer(objectLayer);
      map.addLayer(distLayer); // top layer
    }
  }

  public override addImagesToMap(
    addDirectionalImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    _addDirectionalRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void
  ): void {
    addDirectionalImageToMap(ObjectDragLayerManager.NEAREST_TRACK_ICON_DIRECTIONAL_NAME, MapColor.OBJECT_DRAG_LAYER_PRIMARY, ThemeColorHex.WHITE, false);
    addDirectionalImageToMap(ObjectDragLayerManager.NEAREST_TRACK_ICON_BIDIRECTIONAL_NAME, MapColor.OBJECT_DRAG_LAYER_PRIMARY, ThemeColorHex.WHITE, true);
    addDirectionalImageToMap(ObjectDragLayerManager.NEAREST_TRACK_INVALID_ICON_DIRECTIONAL_NAME, MapColor.RED, ThemeColorHex.WHITE, false);
    addDirectionalImageToMap(ObjectDragLayerManager.NEAREST_TRACK_INVALID_ICON_BIDIRECTIONAL_NAME, MapColor.RED, ThemeColorHex.WHITE, true);
  }
}
