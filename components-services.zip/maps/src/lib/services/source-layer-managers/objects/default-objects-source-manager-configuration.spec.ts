/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { LoggingStub } from '@oksygen-common-libraries/pio/testing';
import { Angle, LngLatCoord, Orientation, Point3D } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { createTestObject, createTestObjectContainer, NetworkDefinitionManagerStub } from '@oksygen-sim-train-libraries/components-services/testing';
import { DefaultObjectsSourceManagerConfiguration } from './default-objects-source-manager-configuration';
import { MapConfig } from '@oksygen-sim-train-libraries/components-services/maps';
import { of } from 'rxjs';

function createMapConfig(): MapConfig {
  const colours = {
    track: {
      previewInvalidPathLineColor: 'fff', previewPathLineColor: 'fff', sceneryTrackLineColor: 'fff', selectedPathLineColor: 'fff', trackLineColor: 'fff'
    }
  };
  return {
    objects: { usePromotedChildOrientation: true,usePromotedChildPosition: false, showAllChildren: true, stackDirection: 'vertical' },
    defaultStyle: {colors: colours },
    trainPathOnlyStyle: {offPath: { colors: colours}, onPath: { colors: colours }}
  };
}

function assignPosition(obj: ObjectContainer, lnglat: LngLatCoord): void {
  obj.location.lnglat = lnglat;
  obj.location.geometry = {x: 0, y: 0, z: 0};
  obj.trackAssociations.push({
    orientation: Orientation.ALPHA_TO_BETA,
    offset: 50,
    segmentId: 1,
    lnglat,
    heading: Angle.ofDegrees(0),
    position: { x: 0, y: 0, z: 0 }
  });
}

function objWithChildren(obj: ObjectContainer): ObjectContainer[] {
  if (!obj.children?.length) { return [obj]; }
  return [obj, ...obj.children as any];
}

describe('default objects source manager configuration', () => {
  const mapConfig = createMapConfig();
  const logging = new LoggingStub();
  const netDefObj = {
    segmentOffsetToOrientedWorldPoint: (): Point3D => ({x: 0, y: 0, z: 0})
  };
  const netDef = new NetworkDefinitionManagerStub(netDefObj);
  beforeEach(() => {});
  xit('renders a simple object', done => {
    const obj = createTestObject();
    assignPosition(obj, [1, 2]);
    const locationProcessor = new DefaultObjectsSourceManagerConfiguration(mapConfig, logging, of(netDef), of({inserted: [obj], updated: []}), null);
    locationProcessor.subscribe();
    locationProcessor.dataHasChanged$().subscribe(changed => {
      const geoJson = locationProcessor.getUpdatedGeoJson();
      expect(geoJson.features.length).toBe(1); // object, assoc, assoc line
      expect((geoJson.features[0].geometry as any).coordinates).toEqual([1, 2]);
      expect(geoJson.features[0].properties.translate).toEqual([0, 0]); // only containers get translated
      expect(geoJson.features[0].properties.containerType).toBe('standalone');
      locationProcessor.destroy();
      done();
    });
  });

  xit('renders an object container', done => {
    const obj = createTestObjectContainer(1);
    const objs = objWithChildren(obj);
    objs.forEach(o => assignPosition(o, [1, 2]));
    const locationProcessor = new DefaultObjectsSourceManagerConfiguration(mapConfig, logging, of(netDef), of({inserted: objs, updated: []}), null);
    locationProcessor.subscribe();
    locationProcessor.dataHasChanged$().subscribe(changed => {
      const geoJson = locationProcessor.getUpdatedGeoJson();
      expect(geoJson.features.length).toBe(1); // we're only rendering the child
      expect((geoJson.features[0].geometry as any).coordinates).toEqual([1, 2]);
      expect(geoJson.features[0].properties.containerType).toBe('first-child');
      expect(geoJson.features[0].properties.translate).toEqual([2, -0]); // only containers get translated
      locationProcessor.destroy();
      done();
    });
  });

  xit('renders an big object container and spaces the children', done => {
    // create 4 children but hide 1
    const obj = createTestObjectContainer(4);
    obj.children[0].selectedIcon = {small: {imageData: {width: 10, height: 10}}} as any;
    obj.children[1].selectedIcon = {small: {imageData: {width: 20, height: 20}}} as any;
    obj.children[2].selectedIcon = {small: {imageData: {width: 40, height: 40}}} as any;
    obj.objectType.children[3].promoted = false;
    obj.objectType.children[3].displayOrder = undefined;
    obj.objectType.children[3].displayIcon = false;
    const objs = objWithChildren(obj);
    objs.forEach(o => assignPosition(o, [1, 2]));
    const locationProcessor = new DefaultObjectsSourceManagerConfiguration(mapConfig, logging, of(netDef), of({inserted: objs, updated: []}), null);
    locationProcessor.subscribe();
    locationProcessor.dataHasChanged$().subscribe(changed => {
      const geoJson = locationProcessor.getUpdatedGeoJson();
      expect(geoJson.features.length).toBe(3); // render 3/4 children
      expect((geoJson.features[0].geometry as any).coordinates).toEqual([1, 2]);
      expect(geoJson.features[0].properties.containerType).toBe('first-child');
      expect(geoJson.features[0].properties.translate).toEqual([2, -70]);
      expect(geoJson.features[1].properties.containerType).toBe('secondary-child');
      expect(geoJson.features[1].properties.translate).toEqual([2, -45]);
      locationProcessor.destroy();
      done();
    });
  });
});
