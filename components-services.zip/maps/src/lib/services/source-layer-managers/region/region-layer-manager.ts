/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { Map } from 'maplibre-gl';

import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';

import { LayerManager } from '../../mapbox.layers';
import { REGIONS_SOURCE_NAME } from './region-source-manager';

export const REGIONS_LAYER_NAME = 'regions';

export class RegionLayerManager extends LayerManager {
  constructor() {
    super(REGIONS_LAYER_NAME);
  }

  public override clear(): void {}

  public attachLayerTo(map: Map, _elRef: ElementRef<any>, _getDragPreview: (objectRef: any) => Element): void {
    if (this.mapHasSource(map, REGIONS_SOURCE_NAME)) {
      map.addLayer({
        id: REGIONS_LAYER_NAME,
        type: 'fill',
        source: REGIONS_SOURCE_NAME,
        paint: {
          'fill-color': ThemeColorHex.PRIMARY,
          'fill-opacity': 0.2
        }
      });
    }
  }
}
