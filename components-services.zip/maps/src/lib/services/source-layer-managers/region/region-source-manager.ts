/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Feature, FeatureCollection } from 'geojson';
import { Observable, Subscription } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectContainer, ObjectTypeContainer, ObjectTypeName } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { emptyGeoJSONCollection } from '../../../helpers/mapbox.source';
import { SourceManager, SourceManagerConfiguration } from '../../mapbox.layers';

export const REGIONS_SOURCE_NAME = 'regions';

export interface RegionSourceManagerConfiguration extends SourceManagerConfiguration {
  data$: Observable<ObjectContainer[]>;
}

export class RegionSourceManager extends SourceManager<RegionSourceManagerConfiguration> {
  private subscription = new Subscription();

  constructor(private logger: Logging, configuration: RegionSourceManagerConfiguration) {
    super(REGIONS_SOURCE_NAME, configuration);

    this.subscription.add(
      this.configuration.data$.subscribe(
        objects => {
          if (!objects) {
            this.geoJSONSource.next(emptyGeoJSONCollection());
            return;
          }
          this.geoJSONSource.next(this.asPlanViewRegionGeoJSON(objects));
        },
        err => this.logger.error('An error occured in LabelSourceManager', JSON.stringify(err))
      )
    );
  }

  override destroy(): SuperCalled {
    this.subscription.unsubscribe();

    return super.destroy();
  }

  private asPlanViewRegionGeoJSON(objects: ObjectContainer[]): FeatureCollection {
    const features:  Array<Feature<any, {name: string; type: string}>> = [];
    const unknownTypes: string[] = [];
    objects?.forEach((o, id) => {
      const objectType = o.objectType;

      // Skip unknown feature types.
      if (objectType) {
        // Skip stations; they are made prominent via their labels and the rendering of their Platforms
        // if (o.objectType.name === ObjectTypeName.STATION) {
        //   return;
        // }

        if (o.boundaries && o.boundaries.length > 0) {
          // TODO: Consolidate with mapbox.source.ts
          // We flatten the returned array
          features.push(...this.addBoundariesToFeature(o, objectType));
        }
      } else {
        if (!unknownTypes.find(type => type === o.objectType.name)) {
          unknownTypes.push(o.objectType.name);
        }
      }
    });

    if (unknownTypes.length > 0) {
      // this.logger.log(`Unknown region types encountered: ${unknownTypes}`);
    }

    return {
      type: 'FeatureCollection',
      features
    };
  }

  /**
   * Converts object boundaries to GeoJSON Polygon features and return an array to be added to the features array.
   *
   * @param o the object that holds the boundaries.
   * @param objectType The type information of the passed object.
   * @returns an array of GeoJSON Polygon features.
   */
  private addBoundariesToFeature(objectContainer: ObjectContainer, objectType: ObjectTypeContainer): Array<Feature<any, {name: string; type: string}>> {
    const features: Array<Feature<any, {name: string; type: string}>> = [];
    objectContainer.boundaries.forEach(b => {
      // If there's no boundary define, no need to add boundaries to the feature
      if(b.length === 0) {
        return;
      }
      // GeoJSON expects an array containing an outer shape
      // and inner shapes which are cut out of the outer one.
      const coordinates = new Array<Array<LngLatCoord>>();
      const outer = new Array<LngLatCoord>(...b);
      // We need to repeat the first coord as per GeopJSON spec
      outer.push(b[0]);
      coordinates.push(outer);
      // We don't support inner shapes.
      features.push({
        type: 'Feature',
        id: objectContainer.id,
        properties: {
          // TODO needs to be localised
          name: objectContainer.name,
          type: objectType?.name
        },
        geometry: {
          type: 'Polygon',
          coordinates
        }
      });
    });
    return features;
  }
}
