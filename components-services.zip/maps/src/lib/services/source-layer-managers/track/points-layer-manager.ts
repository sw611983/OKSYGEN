/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef, NgZone } from '@angular/core';
import { ExpressionSpecification, Map, MapGeoJSONFeature } from 'maplibre-gl';
import Point from '@mapbox/point-geometry';

import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';
import { ObjectTypeName } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { MapColor } from '../../../helpers/map-color.enum';
import { RawPointSelectionHandler } from '../../../interfaces/selection-handlers/selection-point.interface';
import { MapConfig } from '../../../models/map-config.model';
import { LayerManager, LayerManagerConfiguration } from '../../mapbox.layers';
import { OBJECTS_SOURCE_NAME } from '../objects/objects-source-manager';
import { POINTS_SOURCE_NAME, PointsSourceManager } from './points-source-manager';
import { TrackLayerManager } from './track-layer-manager';
import { MapInputEventData } from '../../../helpers/mapbox.source';

export const POINTS_HOTSPOT_LAYER_NAME = 'pointsHotspots';

export interface PointsLayerManagerConfiguration extends LayerManagerConfiguration {
  mapConfig: MapConfig;
}

/**
 * Manages points layers for use in a Mapbox map.
 */
export class PointsLayerManager extends LayerManager<PointsLayerManagerConfiguration> {
  private static readonly DASHES_LAYER_NAME = 'pointsDashes';
  private static readonly HOTSPOT_LAYER_NAME = POINTS_HOTSPOT_LAYER_NAME;
  private static readonly LINE_LAYER_NAME = 'pointsLines';
  private static readonly WIDGET_LAYER_NAME = 'pointsWidgets';

  private static readonly IS_SET: ExpressionSpecification = ['==', ['get', 'type'], 'set'];
  private static readonly NOT_SET: ExpressionSpecification = ['!=', ['get', 'type'], 'set'];
  private static readonly IS_SAFE: ExpressionSpecification = ['==', ['get', 'type'], 'safe'];
  private static readonly IS_DANGER: ExpressionSpecification = ['==', ['get', 'type'], 'danger'];
  private static readonly NOT_ON_PATH: ExpressionSpecification = ['!=', ['get', 'type'], 'onPath'];
  protected static readonly IS_SELECTED: ExpressionSpecification = ['==', ['get', 'selected'], true];
  protected static readonly IS_SELECTED_OR_HOVER: ExpressionSpecification = [
    'case',
    PointsLayerManager.IS_HOVER,
    true,
    PointsLayerManager.IS_SELECTED,
    true,
    false
  ];

  private hoveredPointsId: number;
  // FIXME dragData should be format {type: 'foo', data: dataObj}
  private dragData: any;
  private rawInputHandler: RawPointSelectionHandler;
  private map: Map;

  constructor(configuration: PointsLayerManagerConfiguration, zone: NgZone) {
    super(POINTS_HOTSPOT_LAYER_NAME, configuration, zone);
  }

  public override clear(): void {
    this.map = null;
    this.rawInputHandler = null;
    this.hoveredPointsId = null;
  }

  attachLayerTo(map: Map, _elRef: ElementRef, _getDragPreview: (objectRef: any) => Element): void {
    const type = 'line';
    const minzoom = 14;

    // TODO move into MapConfig
    const primaryColour = ThemeColorHex.PRIMARY;
    const highlightColour = MapColor.POINT_LAYER_HIGHLIGHT;
    // const selectedColour = MapColor.PINK;

    if (this.map) {
      throw new Error(`Can't attach to multiple maps!`);
    }

    if (!map) {
      throw new Error(`Can't attach to null maps!`);
    }

    this.map = map;

    if (this.mapHasSource(map, POINTS_SOURCE_NAME)) {
      const trackLineColor = this.configuration.mapConfig.trainPathOnlyStyle.offPath.colors.track.trackLineColor;

      // Layer of points on top of tracks that add a blue effect when a track is selected
      map.addLayer({
        id: PointsLayerManager.HOTSPOT_LAYER_NAME,
        source: POINTS_SOURCE_NAME,
        minzoom,
        type,
        paint: {
          'line-width': TrackLayerManager.TRACK_HOTSPOT_LINE_WIDTH_EXP,
          // Note that any opacity other than 1 or 0 on this layer looks pretty trash due to https://github.com/mapbox/mapbox-gl-js/issues/4090
          'line-opacity': ['case', PointsLayerManager.IS_SELECTED, 1, 0],
          'line-color': highlightColour
        },
        layout: {
          'line-cap': 'butt'
        }
      });

      // Note that this layer is painting "negative" colours on top of the track layer to produce a dashed line effect.
      map.addLayer({
        id: PointsLayerManager.DASHES_LAYER_NAME,
        source: POINTS_SOURCE_NAME,
        type,
        minzoom,
        paint: {
          'line-width': ['case', PointsLayerManager.IS_SELECTED, 4, 2],
          'line-dasharray': ['step', ['zoom'], ['literal', [5, 1]], 18, ['literal', [2, 2]], 20, ['literal', [3, 5]]],
          'line-color': [
            'case',
            // PointsLayerManager.IS_SELECTED,
            // selectedColour,
            PointsLayerManager.IS_SELECTED_OR_HOVER,
            primaryColour,
            PointsLayerManager.IS_DANGER,
            ThemeColorHex.WHITE,
            PointsLayerManager.IS_SAFE,
            MapColor.POINT_LAYER_NAME_GREY, // Lighter than the track colour, darker than the danger colour
            MapColor.RED
          ]
        },
        filter: PointsLayerManager.NOT_SET
      });

      // This layer paints solid lines for the segments that are traversible
      map.addLayer({
        id: PointsLayerManager.LINE_LAYER_NAME,
        source: POINTS_SOURCE_NAME,
        type,
        minzoom,
        paint: {
          'line-width': ['case', PointsLayerManager.IS_SELECTED, 4, 2],
          // TODO this should take into account train path only mode.
          'line-color': [
            'case',
            // PointsLayerManager.IS_SELECTED,
            // selectedColour,
            PointsLayerManager.IS_SELECTED_OR_HOVER,
            ['case', PointsLayerManager.IS_SET, primaryColour, PointsLayerManager.IS_SAFE, trackLineColor, highlightColour],
            trackLineColor
          ],
          'line-opacity': [
            'case',
            PointsLayerManager.IS_SELECTED_OR_HOVER,
            ['case', PointsLayerManager.NOT_SET, 0, 1],
            PointsLayerManager.NOT_ON_PATH,
            ['case', PointsLayerManager.IS_SET, 0.35, 0],
            PointsLayerManager.IS_SET,
            1,
            0
          ]
        }
      });

      // This layer paints widgets to make the existence of the points more obvious.
      map.addLayer({
        id: PointsLayerManager.WIDGET_LAYER_NAME,
        type: 'circle',
        source: OBJECTS_SOURCE_NAME,
        minzoom: 14,
        paint: {
          'circle-radius': TrackLayerManager.TRACK_LINE_WIDTH_EXP,
          'circle-color': trackLineColor,
          'circle-opacity': 1,
          'circle-stroke-width': TrackLayerManager.TRACK_LINE_WIDTH_EXP,
          'circle-stroke-color': primaryColour
        },
        filter: ['==', ['get', 'typeName'], ObjectTypeName.POINT]
      });
    }

    map.on('mouseleave', PointsLayerManager.HOTSPOT_LAYER_NAME, e => {
      map.getCanvas().style.cursor = '';
      this.updateHover(map, null);
    });
  }

  override setInputHandler(rawHandler: RawPointSelectionHandler): void {
    if (!rawHandler) {
      rawHandler = {
        onPointHovered: (id, data): void => {},
        onPointClicked: (id, data): void => {},
        onPointDown: (id, data): boolean => false
      };
    }

    const firstCall = !this.rawInputHandler;

    this.rawInputHandler = rawHandler;

    if (!firstCall) {
      return;
    }
    this.zone?.runOutsideAngular(() => {
      this.map.on('mousemove', PointsLayerManager.HOTSPOT_LAYER_NAME, (e: MapInputEventData): void => {
        this.map.getCanvas().style.cursor = 'pointer';

        if (e?.features?.length > 0) {
          this.updateHover(this.map, Number(e.features[0].properties.objectId));
          this.interactWithPoint(this.rawInputHandler.onPointHovered, this.map, e, [PointsLayerManager.HOTSPOT_LAYER_NAME]);

          const hoveredFeatures = this.map.queryRenderedFeatures(e.point, {
            layers: [PointsLayerManager.HOTSPOT_LAYER_NAME]
          });
          // Change cursor style when a selected point is hovered
          if (
            this.map.getFeatureState({
              source: POINTS_SOURCE_NAME,
              id: PointsSourceManager.toGeoJSONFeatureId(hoveredFeatures[0].properties.objectId, 'set')
            }).selected
          ) {
            this.map.getCanvas().style.cursor = 'grab';
          }
        }
      });
    });

    this.map.on('click', PointsLayerManager.HOTSPOT_LAYER_NAME, (e: MapInputEventData) => {
      // we call preventDefault on the original event in objects-layer-manager
      // but the mapbox still continues on the list of events to process and we end up here
      // so let's not process this if defaultPrevented is true (see PRDOKS-69)
      if (!e.originalEvent.defaultPrevented) {
        this.map.getCanvas().style.cursor = 'grab';
        // const selectedFeatures = this.map.queryRenderedFeatures(e.point, {
        //   layers: [PointsLayerManager.HOTSPOT_LAYER_NAME]
        // });
        this.interactWithPoint(this.rawInputHandler.onPointClicked, this.map, e, [PointsLayerManager.HOTSPOT_LAYER_NAME]);
      }
    });

    this.map.on('mousedown', PointsLayerManager.HOTSPOT_LAYER_NAME, (e: MapInputEventData) => {
      this.map.getCanvas().style.cursor = 'grab';
      if (this.interactWithPoint(this.rawInputHandler.onPointDown, this.map, e, [PointsLayerManager.HOTSPOT_LAYER_NAME])) {
        // Prevent the default map drag behavior.
        // Allows the HTML5 drag interaction to begin.
        e.preventDefault();
      }
    });
  }

  private updateHover(map: Map, newId: number | null): void {
    if (this.hoveredPointsId) {
      this.setPointsHoverState(map, this.hoveredPointsId, false);
    }
    if (newId) {
      this.hoveredPointsId = newId;
      this.setPointsHoverState(map, this.hoveredPointsId, true);
    }
  }

  private setPointsHoverState(map: Map, pointsId: number, hover: boolean): void {
    const source = POINTS_SOURCE_NAME;
    // Note that points are made up of multiple features in the GeoJSON
    map.setFeatureState({ source, id: PointsSourceManager.toGeoJSONFeatureId(pointsId, 'set') }, { hover });
    map.setFeatureState({ source, id: PointsSourceManager.toGeoJSONFeatureId(pointsId, 'safe') }, { hover });
    map.setFeatureState({ source, id: PointsSourceManager.toGeoJSONFeatureId(pointsId, 'danger') }, { hover });
  }

  private interactWithPoint(callback: (id: number, data: any) => void | boolean, map: Map, e: any, layers: string[], alwaysFire = false): boolean {
    const featuresNearClick = e.point ? this.getFeaturesFuzzy(map, e.point, layers) : [];

    if (alwaysFire || featuresNearClick?.length > 0) {
      // FIXME dragData should be format {type: 'foo', data: dataObj}
      this.dragData = featuresNearClick?.[0]?.properties?.dragData ?? this.dragData;
      return !!callback((featuresNearClick[0]?.properties?.objectId ?? 0) as number, this.dragData);
    }

    return false;
  }

  private getFeaturesFuzzy(map: Map, point: Point, layers: string[]): MapGeoJSONFeature[] {
    // Consider npx reactangle area around clicked point
    const n = 0;
    return map.queryRenderedFeatures(
      [
        [point.x - n, point.y - n],
        [point.x + n, point.y + n]
      ],
      {
        layers
      }
    );
  }
}
