/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Feature, FeatureCollection } from 'geojson';
import { isNil } from 'lodash';
import { combineLatest, Observable, Subscription } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { PointInfo, PointSegmentState } from '@oksygen-sim-core-libraries/data-types/common';
import { IReachablePath, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer, ObjectTypeContainer, ObjectTypeName } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { emptyGeoJSONCollection } from '../../../helpers/mapbox.source';
import { SourceManager, SourceManagerConfiguration } from '../../mapbox.layers';

/**
 * Describes the status of a segment that a set of points connects.
 */
type pointSegmentStatus = 'set' | 'safe' | 'danger' | 'hidden';

export const POINTS_SOURCE_NAME = 'points';

export interface PointsSourceManagerConfiguration extends SourceManagerConfiguration {
  world$: Observable<WorldData>;

  pointType: ObjectTypeContainer;

  objects$: Observable<ObjectContainer[]>;

  highlightedPath$?: Observable<IReachablePath>;

  objectsSourceManagerConfiguration?: { selectedObject$?: Observable<ObjectContainer> };
}

/**
 * Manages Mapbox Sources for rendering points.
 */
export class PointsSourceManager extends SourceManager<PointsSourceManagerConfiguration> {
  private pointInfo: Map<number, PointInfo>;

  private path: IReachablePath;
  private selectedPoint: ObjectContainer;

  /**
   * We suppress a bunch of updates while we set up state listeners,
   * because we produce source data for all features at once.
   * Without this, we would do the same thing thousands of times at startup.
   */
  private initialCallbackSuppressionCount: number;
  private worldSub = Subscription.EMPTY;
  private pathSub = Subscription.EMPTY;
  private selectedPointSub = Subscription.EMPTY;

  constructor(private logger: Logging, configuration: PointsSourceManagerConfiguration) {
    super(POINTS_SOURCE_NAME, configuration);

    // TODO should probably also wait for the object manager to be ready
    this.worldSub = combineLatest([this.configuration.world$, this.configuration.objects$]).subscribe(([w, o]) => {
      if (isNil(w) || isNil(o)) {
        this.geoJSONSource.next(emptyGeoJSONCollection());
        return;
      }
      this.pointInfo = w.pointMap;

      const points = o.filter(point => point.objectType.name === ObjectTypeName.POINT);

      this.updatePointsGeoJSON(points);

      if (!isNil(this.configuration.highlightedPath$)) {
        this.pathSub?.unsubscribe();
        this.pathSub = this.configuration.highlightedPath$.subscribe(path => {
          this.path = path;
          this.updatePointsGeoJSON(points);
        });
      }

      if (!isNil(this.configuration.objectsSourceManagerConfiguration?.selectedObject$)) {
        this.selectedPointSub?.unsubscribe();
        this.selectedPointSub = this.configuration.objectsSourceManagerConfiguration.selectedObject$.subscribe(point => {
          this.selectedPoint = point;
          this.updatePointsGeoJSON(points);
        });
      }
    });
  }

  /**
   * Returns the ID to use in a GeoJSON Feature that represents
   * the segments with a given status on a particular set of points.
   */
  public static toGeoJSONFeatureId(pointsId: number, status: pointSegmentStatus): number {
    let typeId: number;

    switch (status) {
      case 'set':
        typeId = 1;
        break;
      case 'safe':
        typeId = 2;
        break;
      case 'danger':
        typeId = 3;
        break;
    }
    return pointsId * 10 + typeId;
  }

  override destroy(): SuperCalled {
    this.worldSub.unsubscribe();
    this.pathSub.unsubscribe();
    this.selectedPointSub?.unsubscribe();

    return super.destroy();
  }

  private updatePointsGeoJSON(points: ObjectContainer[]): void {
    if (this.initialCallbackSuppressionCount > 0) {
      --this.initialCallbackSuppressionCount;
    } else {
      this.geoJSONSource.next(this.createPointsGeoJSON(points));
    }
  }

  private createPointsGeoJSON(points: ObjectContainer[]): FeatureCollection {
    const dangerSegments = new Array<Feature>();
    const safeSegments = new Array<Feature>();
    const setSegments = new Array<Feature>();

    const errors: string[] = [];

    points.forEach(p => {
      const point = this.pointInfo.get(p.id);
      if (!point) {
        errors.push(`Error: no PointInfo found with ID ${p.id}`);
        return;
      }
      const state = this.configuration.pointType.states.get(p.selectedState?.id);
      const featureName = p.name;
      const segStates = point.statePointSegmentsMap.get(state?.name);

      if (segStates) {
        segStates.forEach((segState, segEnd) => {
          let segmentCollection: Array<Feature>;
          let type: pointSegmentStatus;

          switch (segState) {
            case PointSegmentState.SET:
              type = 'set';
              segmentCollection = setSegments;
              break;
            case PointSegmentState.SAFE:
              type = 'safe';
              segmentCollection = safeSegments;
              break;
            case PointSegmentState.DANGER:
              type = 'danger';
              segmentCollection = dangerSegments;
              break;
          }

          this.addToSegmentCollection(segmentCollection, point, type, featureName, segEnd, this.path);
        });
      } else {
        // Mark all segments as dangerous if we don't have any connectivity info.

        // It doesn't matter which valid state we start with, all states will have info on all segments.
        // FIXME magic string
        const fallbacksegStates = point.statePointSegmentsMap.get('Main Line');
        fallbacksegStates.forEach((segState, segEnd) => {
          this.addToSegmentCollection(dangerSegments, point, 'danger', featureName, segEnd, this.path);
        });
      }
    });

    if (errors.length > 0) {
      this.logger.log(errors.join(`\n`));
    }

    return {
      type: 'FeatureCollection',
      features: [...dangerSegments, ...safeSegments, ...setSegments]
    };
  }

  private addToSegmentCollection(
    segmentCollection: Array<Feature>,
    point: PointInfo,
    type: pointSegmentStatus,
    name: string,
    segEnd: string,
    path: IReachablePath
  ): void {
    const onPath = !path || path.pathContainsSegment(Number(segEnd.slice(0, segEnd.length - 1)));
    const selected = point.id === this.selectedPoint?.id;

    segmentCollection.push({
      type: 'Feature',
      id: PointsSourceManager.toGeoJSONFeatureId(point.id, type),
      properties: {
        featureId: point.id, // deprecated
        objectId: point.id,
        type,
        onPath,
        selected,
        // FIXME dragData should be format {type: 'foo', data: dataObj}
        dragData: { name, objectId: point.id, objectName: name }
      },
      geometry: {
        type: 'MultiLineString',
        coordinates: [point.segmentEndPolylines.get(segEnd)]
      }
    });
  }
}
