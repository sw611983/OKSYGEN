/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Feature, GeoJsonProperties } from 'geojson';
import { BehaviorSubject } from 'rxjs';
import { truncate } from '@turf/truncate';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { SegmentLngLatPolylines } from '@oksygen-sim-core-libraries/data-types/common';

import { BaseSourceManager, SourceManagerConfiguration } from '../../mapbox.layers';

export const TRACK_SOURCE_NAME = 'track';
export const SELECTIONS_SOURCE_NAME = 'selections';

/**
 * Manages Mapbox Sources for rendering tracks.
 */
export abstract class AbstractTrackSourceManager<C extends SourceManagerConfiguration = SourceManagerConfiguration> extends BaseSourceManager<C> {
  protected pathSelectionGeoJSONSource = new BehaviorSubject<GeoJsonProperties>(null);

  constructor(configuration: C, public readonly sourceName = TRACK_SOURCE_NAME, otherSourceNames = [SELECTIONS_SOURCE_NAME]) {
    super([sourceName, ...otherSourceNames], configuration);
  }

  protected createTrackGeoJSON(segmentPolylines: SegmentLngLatPolylines): any {
    const features = new Array<Feature>();

    segmentPolylines.forEach((line, segId, m) => {
      features.push({
        type: 'Feature',
        id: segId,
        properties: {
          segmentId: segId,
          trainPathOnlyEnabled: false,
          onPath: false,
          isScenery: false,
          debugText: segId
        },
        geometry: {
          type: 'MultiLineString',
          coordinates: [line]
        }
      });
    });
    const geojson = {
      type: 'FeatureCollection',
      features
    };
    // precision is number of decimal places. 3 = 110m, 4 = 11m, 5 = 1.1m, 6 = 11cm, 7 = 1.1cm, 8 = 1.1mm
    truncate(geojson as any, {mutate: true, precision: 8});
    return geojson;
  }

  public override destroy(): SuperCalled {
    this.pathSelectionGeoJSONSource.complete();

    return super.destroy();
  }
}
