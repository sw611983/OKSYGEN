/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { LngLat } from 'maplibre-gl';

import { DragFeedback, selfCompletingObservable, SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { LngLatCoord, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData } from '@oksygen-sim-train-libraries/components-services/common';

import { TrackSelectionHandler } from '../../../interfaces/selection-handlers/selection-track.interface';
import { DragSourceManager, DragSourceManagerConfiguration, SourceManagerConfiguration } from '../../mapbox.layers';

const SELECTED_TRACK = 'selectedtrack';
const TRACK = 'track';

export type TrackDragSourceManagerConfiguration = DragSourceManagerConfiguration<TrackSelectionHandler>;

export class TrackDragSourceManager extends DragSourceManager<TrackDragSourceManagerConfiguration> {
  constructor(configuration: TrackDragSourceManagerConfiguration) {
    super('', configuration);
  }

  protected createDefaultConfiguration(): SourceManagerConfiguration {
    return {};
  }

  public supportsDrag(data: DragData): boolean {
    return data?.type === SELECTED_TRACK || data?.type === TRACK;
  }

  public onDrag(
    dragData: DragData,
    _lngLat: LngLat,
    _lngLatCoord: LngLatCoord,
    segOffset: SegOffsetOriented,
    _userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback> {
    if (dragData?.type === SELECTED_TRACK) {
      return selfCompletingObservable(this.configuration.handler.onSelectedDragged(segOffset));
    } else if (dragData?.type === TRACK) {
      return selfCompletingObservable(this.configuration.handler.onTrackDragged(segOffset));
    }

    return selfCompletingObservable(null);
  }

  public onDrop(dragData: DragData, _lngLat: LngLat, _lngLatCoord: LngLatCoord, segOffset: SegOffsetOriented, _userScale: UserScale[]): void {
    if (dragData?.type === SELECTED_TRACK) {
      this.configuration.handler.onSelectedUp(segOffset);
    } else if (dragData?.type === TRACK) {
      this.configuration.handler.onTrackUp(segOffset);
    }
  }

  public removeFeedback(): void {}
}
