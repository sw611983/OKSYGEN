/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { ExpressionSpecification, Map } from 'maplibre-gl';

import { LayerManager } from '../../mapbox.layers';
import { TrackLayerManagerConfiguration } from '../track/track-layer-manager';

export const PATH_SOURCE_NAME = 'path';
export const PATH_PREVIEW_SOURCE_NAME = 'path-preview';

export const PATH_LAYER_NAME = 'path';
export const PATH_PREVIEW_LAYER_NAME = 'path-preview';

/**
 * An expression for controlling the line-widths of "hotspot lines" for track-like elements on the map
 * (such as points or track circuits).
 */
const PATH_LINE_WIDTH_EXP: ExpressionSpecification = [
  'interpolate',
  ['linear'],
  ['zoom'],
  // set the max zoom level to apply thin line style, and the width of that line
  12,
  4,
  // set the min zoom level to apply thick line style, and the width of that line
  20,
  6
];

/**
 * Manages a train layer for use in a Mapbox map.
 */
export class TrackPathLayerManager extends LayerManager<TrackLayerManagerConfiguration> {
  constructor(configuration: TrackLayerManagerConfiguration) {
    super(PATH_LAYER_NAME, configuration);
  }

  public override clear(): void {}

  attachLayerTo(map: Map, _elRef: ElementRef, _getDragPreview: (objectRef: any) => Element): void {
    if (!map) {
      throw new Error(`Can't attach to null maps!`);
    }

    if (this.mapHasSource(map, PATH_SOURCE_NAME)) {
      map.addLayer({
        id: PATH_LAYER_NAME,
        type: 'line',
        source: PATH_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': PATH_LINE_WIDTH_EXP,
          'line-color': this.configuration.mapConfig.defaultStyle.colors.track.selectedPathLineColor // TODO apply train path only styles...
        }
      });
    }

    if (this.mapHasSource(map, PATH_PREVIEW_SOURCE_NAME)) {
      map.addLayer({
        id: PATH_PREVIEW_LAYER_NAME,
        type: 'line',
        source: PATH_PREVIEW_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': PATH_LINE_WIDTH_EXP,
          'line-color': this.configuration.mapConfig.defaultStyle.colors.track.previewPathLineColor // TODO apply train path only styles...
        }
      });
    }
  }
}
