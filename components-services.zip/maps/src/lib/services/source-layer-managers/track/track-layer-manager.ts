/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef, NgZone } from '@angular/core';
import { ExpressionSpecification, Map, MapGeoJSONFeature } from 'maplibre-gl';
import Point from '@mapbox/point-geometry';


import { MapColor } from '../../../helpers/map-color.enum';
import { MapInputEventData } from '../../../helpers/mapbox.source';
import { RawTrackSelectionData, RawTrackSelectionHandler } from '../../../interfaces/selection-handlers/selection-track.interface';
import { MapConfig } from '../../../models/map-config.model';
import { LayerManager, LayerManagerConfiguration } from '../../mapbox.layers';
import { SELECTIONS_SOURCE_NAME, TRACK_SOURCE_NAME } from './track-source-manager';

export const TRACK_LAYER_NAME = 'track';

export interface TrackLayerManagerConfiguration extends LayerManagerConfiguration {
  mapConfig: MapConfig;
}

/**
 * Manages a track layer for use in a Mapbox map.
 */
export class TrackLayerManager extends LayerManager<TrackLayerManagerConfiguration> {
  private static readonly SELECTIONS_LAYER_NAME = 'selections';

  /**
   * An expression for controlling the line-widths of track-like elements on the map
   * (such as points or track circuits).
   */
  public static readonly TRACK_LINE_WIDTH_EXP: ExpressionSpecification = [
    'interpolate',
    ['linear'],
    ['zoom'],
    // set the max zoom level to apply thin line style, and the width of that line
    16,
    1,
    // set the min zoom level to apply thick line style, and the width of that line
    18,
    2
  ];

  /**
   * An expression for controlling the line-widths of "hotspot lines" for track-like elements on the map
   * (such as points or track circuits).
   */
  public static readonly TRACK_HOTSPOT_LINE_WIDTH_EXP: ExpressionSpecification = [
    'interpolate',
    ['linear'],
    ['zoom'],
    // set the max zoom level to apply thin line style, and the width of that line
    12,
    15,
    // set the min zoom level to apply thick line style, and the width of that line
    20,
    20
  ];

  private map: Map = undefined;

  private rawInputHandler: RawTrackSelectionHandler;

  constructor(configuration: TrackLayerManagerConfiguration, zone: NgZone) {
    super(TRACK_LAYER_NAME, configuration, zone);
  }

  public override clear(): void {
    this.map = null;
    this.rawInputHandler = null;
  }

  attachLayerTo(map: Map, _elRef: ElementRef, _getDragPreview: (objectRef: any) => Element): void {
    if (this.map) {
      throw new Error(`Can't attach to multiple maps!`);
    }

    if (!map) {
      throw new Error(`Can't attach to null maps!`);
    }

    this.map = map;

    if (this.mapHasSource(map, TRACK_SOURCE_NAME)) {
      map.addLayer({
        id: TRACK_LAYER_NAME,
        type: 'line',
        source: TRACK_SOURCE_NAME,
        minzoom: 1,
        paint: {
          'line-width': TrackLayerManager.TRACK_LINE_WIDTH_EXP,
          // Use the trainPathOnlyEnabled, onPath and isScenery properties to determine which colour to use.
          'line-color': [
            'case',
            // Train path only mode
            ['get', 'trainPathOnlyEnabled'],
            [
              'case',
              ['all', ['get', 'onPath'], ['get', 'isScenery']],
              this.configuration.mapConfig.trainPathOnlyStyle.onPath.colors.track.sceneryTrackLineColor,
              ['==', ['get', 'isScenery'], true],
              this.configuration.mapConfig.trainPathOnlyStyle.offPath.colors.track.sceneryTrackLineColor,
              ['==', ['get', 'onPath'], true],
              this.configuration.mapConfig.trainPathOnlyStyle.onPath.colors.track.trackLineColor,
              this.configuration.mapConfig.trainPathOnlyStyle.offPath.colors.track.trackLineColor
            ],
            // Default mode (onPath doesn't matter in this case)
            [
              'case',
              ['==', ['get', 'isScenery'], true],
              this.configuration.mapConfig.defaultStyle.colors.track.sceneryTrackLineColor,
              this.configuration.mapConfig.defaultStyle.colors.track.trackLineColor
            ]
          ]
        }
      });
    }

    if (this.mapHasSource(map, SELECTIONS_SOURCE_NAME)) {
      map.addLayer({
        id: TrackLayerManager.SELECTIONS_LAYER_NAME,
        type: 'circle',
        source: SELECTIONS_SOURCE_NAME,
        minzoom: 1,
        // Renders Start, Waypoint and End widgets.
        // The Start and End are larger than waypoints.
        // The Start and Waypoints are unfilled circles, while the End is filled.
        // Colours are chosen based on whether the path is valid or the selected point is being dragged.
        paint: {
          'circle-radius': ['case', ['==', ['get', 'isStart'], true], 6, ['==', ['get', 'isEnd'], true], 0, 4],
          'circle-stroke-width': ['case', ['==', ['get', 'isStart'], true], 4, ['==', ['get', 'isEnd'], true], 10, 3],
          'circle-color': MapColor.SCENERY_OFF_TRACK_LINE,
          'circle-stroke-color': [
            'case',
            ['==', ['get', 'isValid'], false],
            MapColor.SELECTIONS_LAYER_INVALID,
            ['==', ['get', 'isDrag'], true],
            MapColor.SELECTIONS_LAYER_DRAG,
            MapColor.SELECTIONS_LAYER_OTHER
          ]
        }
      });
    }
  }

  /**
   * Sets a handler for handling "raw" callbacks from listeners on the Mapbox map.
   * These are lower level than TrackSelectionHandler, which most code would prefer to use.
   *
   * @param rawHandler Contains the callbacks that handle updates.
   */
  override setInputHandler(rawHandler: RawTrackSelectionHandler): void {
    if (!rawHandler) {
      rawHandler = {
        onTrackPointHovered: (data: RawTrackSelectionData): void => {},
        onTrackPointClicked: (data: RawTrackSelectionData): void => {},
        onTrackPointDown: (data: RawTrackSelectionData): boolean => false,
        onTrackPointUp: (data: RawTrackSelectionData): void => {},
        onSelectedPointClicked: (data: RawTrackSelectionData): void => {},
        onSelectedPointDown: (data: RawTrackSelectionData): boolean => false,
        onSelectedPointUp: (data: RawTrackSelectionData): void => {}
      };
    }

    const firstCall = !this.rawInputHandler;

    this.rawInputHandler = rawHandler;

    // Don't set extra listeners.
    if (!firstCall) {
      return;
    }

    // Handling interaction with the track

    const onTrackHover = (e: MapInputEventData): void => {
      this.zone?.runOutsideAngular(() => {
        this.interactWithPoint(this.rawInputHandler.onTrackPointHovered, this.map, e, [TRACK_LAYER_NAME]);
      });
    };
    this.map.on('mousemove', onTrackHover.bind(this));

    this.map.on('click', e => {
      this.interactWithPoint(this.rawInputHandler.onTrackPointClicked, this.map, e, [TRACK_LAYER_NAME]);
    });

    const onTrackDown = (e: MapInputEventData): void => {
      if (this.interactWithPoint(this.rawInputHandler.onTrackPointDown, this.map, e, [TRACK_LAYER_NAME])) {
        // Prevent the default map drag behavior.
        // Allows the HTML5 drag interaction to begin.
        e.preventDefault();
      }
    };

    this.map.on('mousedown', e => {
      this.map.getCanvas().style.cursor = 'grab';

      onTrackDown(e);
    });

    this.map.on('touchstart', e => {
      if (e.points.length !== 1) return;

      onTrackDown(e);
    });

    // Handling interactions with existing selection points

    this.map.on('click', TrackLayerManager.SELECTIONS_LAYER_NAME, e => {
      this.interactWithPoint(this.rawInputHandler.onSelectedPointClicked, this.map, e, [TRACK_LAYER_NAME]);
    });

    const onSelectionDown = (e: MapInputEventData): void => {
      if (this.interactWithPoint(this.rawInputHandler.onSelectedPointDown, this.map, e, [TrackLayerManager.SELECTIONS_LAYER_NAME])) {
        // Prevent the default map drag behavior.
        // Allows the HTML5 drag interaction to begin.
        e.preventDefault();
      }
    };

    this.map.on('mouseenter', TrackLayerManager.SELECTIONS_LAYER_NAME, () => {
      this.map.getCanvas().style.cursor = 'move';
    });

    this.map.on('mouseleave', TrackLayerManager.SELECTIONS_LAYER_NAME, () => {
      this.map.getCanvas().style.cursor = '';
    });

    this.map.on('mousedown', TrackLayerManager.SELECTIONS_LAYER_NAME, e => {
      this.map.getCanvas().style.cursor = 'grab';

      onSelectionDown(e);
    });

    this.map.on('touchstart', TrackLayerManager.SELECTIONS_LAYER_NAME, e => {
      if (e.points.length !== 1) return;

      onSelectionDown(e);
    });
  }

  /**
   * Does some quick sanity checks before initiating an interaction with the clicked location.
   *
   * @param callback invoked when a geojson feature (in this typically means tracks or selection markers) is near the clicked location.
   *   May return a boolean to indicate whether the interaction should proceed (typically only applicable for the start of a drag.)
   * @param alwaysFire indicates whether we should invoke the callback when there are no features near the point.
   *
   * @returns a boolean indicating whether the interaction should proceed.
   */
  private interactWithPoint(callback: (data: RawTrackSelectionData) => void | boolean, map: Map, e: any, layers: string[], alwaysFire = false): boolean {
    const featuresNearClick = this.getFeaturesFuzzy(map, e.point, layers);

    if (alwaysFire || featuresNearClick?.length > 0) {
      return !!callback({
        lngLat: e.lngLat,
        segIds: featuresNearClick.map(f => f.properties.segmentId as number)
      });
    }

    return false;
  }

  private getFeaturesFuzzy(map: Map, point: Point, layers: string[]): MapGeoJSONFeature[] {
    // Consider npx reactangle area around clicked point
    const n = 5;
    return map.queryRenderedFeatures(
      [
        [point.x - n, point.y - n],
        [point.x + n, point.y + n]
      ],
      {
        layers
      }
    );
  }
}
