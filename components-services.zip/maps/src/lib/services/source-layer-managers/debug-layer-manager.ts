/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { Map } from 'maplibre-gl';

import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';

import { MapColor } from '../../helpers/map-color.enum';
import { LayerManager } from '../mapbox.layers';

export const DEBUG_LAYER_NAME = 'debugLabels';
export const DEBUG_SOURCE_NAME = 'debugLabels';

export class DebugLayerManager extends LayerManager {
  constructor() {
    super(DEBUG_LAYER_NAME);
  }

  public override clear(): void {}

  public attachLayerTo(map: Map, _elRef: ElementRef<any>, _getDragPreview: (objectRef: any) => Element): void {
    if (this.mapHasSource(map, DEBUG_SOURCE_NAME)) {
      map.addLayer({
        id: DEBUG_LAYER_NAME,
        type: 'symbol',
        source: DEBUG_SOURCE_NAME,
        layout: {
          'text-field': ['format', ['get', 'debugText'], { 'font-scale': 0.65, 'text-color': MapColor.DEBUG_LAYER_TEXT }],
          'text-font': ['KlokanTech Noto Sans Regular']
        },
        paint: {
          'text-halo-width': 4,
          'text-halo-color': ThemeColorHex.WHITE
        }
      });
    }
  }
}
