/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { Map } from 'maplibre-gl';

import { LayerManager } from '../../mapbox.layers';
import { LABELS_SOURCE_NAME } from './label-source-manager';
import { Registry } from '@oksygen-common-libraries/pio';

export const LABELS_LAYER_NAME = 'labels';

export class LabelLayerManager extends LayerManager {
  constructor(protected readonly registry: Registry) {
    super(LABELS_LAYER_NAME);
  }

  public override clear(): void {}

  public attachLayerTo(map: Map, _elRef: ElementRef<any>, _getDragPreview: (objectRef: any) => Element): void {
    const allowLabelOverlap = this.registry.getBoolean(['maps', 'config', 'allowLabelOverlap'], true);

    // For an example of the label offset, see https://maplibre.org/maplibre-gl-js/docs/examples/variable-offset-label-placement/
    // For the actual documentation, see https://maplibre.org/maplibre-style-spec/layers/#text-variable-anchor-offset
    // 
    // For a quick explanation of what happens without the below code or with label offset at 0: 
    // Maplibre tries to place a label at the center of a feature. If it collides with another label, only one label will be displayed.
    // 
    // Here's an example of what was added, If you have { "text-variable-anchor-offset": ["top", [0, 4], "left", [3,0], "bottom", [1, 1]] } 
    // The array is alternating enum and point. Note that we take the anchor and shift it with positive values being right and down.
    // Maplibre will first try the "top" anchor, to place the label under the feature. Quoting: "When the renderer chooses the top anchor,
    // [0, 4] will be used for text-offset; the text will be shifted down by 4 ems."
    // If that collides with another label, it will then try to place the label to the left position. If it collides, then the bottom.
    // 
    // There's no backtracking so once Maplibre placed a label, that label will not be moved, even if moving it would allow more labels to be displayed,
    // like one on left and one on right.
    // ! Once a label is placed, for example at the left, if you zoom in, it will stay on the left, until it disappears.
    // There's no reevaluation of the position of the label as long as it does not disappear.
    const labelOffset = this.registry.getNumber(['maps', 'config', 'labelOffset'], 0);
    let labelOffsetArray: (string | [number, number])[] = [];
    labelOffsetArray = [
      'center',
      [0, 0],
      'top',
      [0, labelOffset],
      'bottom',
      [0, -labelOffset],
      'right',
      [-labelOffset, 0],
      'left',
      [labelOffset, 0],
      'top-right',
      [-labelOffset, labelOffset],
      'top-left',
      [labelOffset, labelOffset],
      'bottom-right',
      [-labelOffset, -labelOffset],
      'bottom-left',
      [labelOffset, -labelOffset]
    ];
    // this is to avoid checking position that are the same. SO if the label offset is 0,
    // we simply check for the center position instead of making more useless checks.
    if (labelOffset === 0) labelOffsetArray = ['center', [0, 0]];
    if (this.mapHasSource(map, LABELS_SOURCE_NAME)) {
      map.addLayer({
        id: LABELS_LAYER_NAME,
        type: 'symbol',
        source: LABELS_SOURCE_NAME,
        layout: {
          'text-field': ['format', ['get', 'text'], { 'font-scale': ['get', 'fontScale'], 'text-color': ['get', 'textColor'] }],
          // Text size could be set through a mechanism such as the following.
          // Note that feature data (fetched using ['get', 'myFieldName']) don't seem to be able to be used as zoom levels in these expressions,
          // which is why we have these awkward textSizeZ variables here rather than minZoom/minZoomTextSize style pairs.
          // 'text-size': [
          //   'interpolate', ['linear'], ['zoom'],
          //    0, ['get', 'textSizeZ0'],
          //   14, ['get', 'textSizeZ14'],
          //   23, ['get', 'textSizeZ23']
          // ],
          'text-font': ['KlokanTech Noto Sans Regular'],
          'text-offset': [0, 0],
          'text-anchor': 'center',
          'text-allow-overlap': allowLabelOverlap,
          // Since the first label will not move, you need to move the other label far enough away to avoid overlap.
          'text-variable-anchor-offset': labelOffsetArray,
          'text-justify': 'auto'
        },
        paint: {
          'text-halo-width': ['get', 'textHaloWidth'],
          'text-halo-color': ['get', 'textHaloColor']
        },
        filter: ['all', ['>', ['zoom'], ['get', 'minZoom']], ['<', ['zoom'], ['get', 'maxZoom']]]
      });
    }
  }
}
