/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FeatureCollection } from 'geojson';
import { Observable, Subscription } from 'rxjs';

import { SuperCalled } from '@oksygen-common-libraries/common';
import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';
import { Logging } from '@oksygen-common-libraries/pio';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { MapColor } from '../../../helpers/map-color.enum';
import { emptyGeoJSONCollection } from '../../../helpers/mapbox.source';
import { SourceManager, SourceManagerConfiguration } from '../../mapbox.layers';

export const LABELS_SOURCE_NAME = 'labels';

type LabelConfig = {
  getText: (o: ObjectContainer) => string;
  fontScale: number;
  textColor: string;
  textHaloWidth: number;
  textHaloColor: string;
  minZoom: number;
  maxZoom: number;
};

export interface LabelSourceManagerConfiguration extends SourceManagerConfiguration {
  data$: Observable<ObjectContainer[]>;
}

export class LabelSourceManager extends SourceManager<LabelSourceManagerConfiguration> {
  private subscription = new Subscription();

  constructor(private logger: Logging, configuration: LabelSourceManagerConfiguration) {
    super(LABELS_SOURCE_NAME, configuration);

    this.subscription.add(
      this.configuration.data$.subscribe(
        features => {
          if (!features) {
            this.geoJSONSource.next(emptyGeoJSONCollection());
            return;
          }
          this.geoJSONSource.next(this.asPlanViewLabelsGeoJSON(features));
        },
        err => this.logger.error('An error occured in LabelSourceManager', JSON.stringify(err))
      )
    );
  }

  override destroy(): SuperCalled {
    this.subscription.unsubscribe();

    return super.destroy();
  }

  private asPlanViewLabelsGeoJSON(objects: ObjectContainer[]): FeatureCollection {
    const featureTypeLabelConfigs = new Map<string, LabelConfig>();

    // TODO These should come from config
    featureTypeLabelConfigs.set('Station', {
      getText: o => o.name,
      fontScale: 1.2,
      textColor: ThemeColorHex.BLACK,
      textHaloWidth: 2,
      textHaloColor: ThemeColorHex.WHITE,
      minZoom: 1,
      maxZoom: 23
    });
    featureTypeLabelConfigs.set('Platform', {
      getText: o =>
        o?.properties?.Label?.toLocaleString() ??
        // As a fallback assume the naming convention is "$stationName $platformNumber"
        o.name.substring(o.name.trim().lastIndexOf(' ') + 1),
      fontScale: 0.9,
      textColor: ThemeColorHex.BLACK,
      textHaloWidth: 6,
      textHaloColor: MapColor.PLATFORM_LAYER,
      minZoom: 15,
      maxZoom: 23
    });

    const features: any[] = [];
    const unknownLabels = []; // labels that are missing coordinates that we therefore cannot render
    objects?.forEach(o => {
      const ft = o.objectType;
      const config = featureTypeLabelConfigs.get(ft.name);

      if (config) {
        let coordinates: LngLatCoord;

        if (o.location.lnglat) {
          coordinates = o.location.lnglat;
        } else if (o.boundaries && o.boundaries.length > 0 && o.boundaries[0].length > 0 ) {
          // TODO: Figure out if we really want the coordinate to be the first point of the first boundary
          coordinates = o.boundaries[0][0];
        } else {
          unknownLabels.push(`${o.name}`);
          return;
        }

        features.push({
          type: 'Feature',
          id: o.id,
          properties: {
            text: config.getText(o),
            fontScale: config.fontScale,
            minZoom: config.minZoom,
            maxZoom: config.maxZoom,
            textColor: config.textColor,
            textHaloWidth: config.textHaloWidth,
            textHaloColor: config.textHaloColor,
            type: ft?.name
          },
          geometry: {
            type: 'Point',
            coordinates
          }
        });
      }
    });
    if (unknownLabels.length > 0) {
      // this.logger.warn(`The following labels are missing coordinates and will not be rendered: ${unknownLabels}`);
    }

    return {
      type: 'FeatureCollection',
      features
    };
  }
}
