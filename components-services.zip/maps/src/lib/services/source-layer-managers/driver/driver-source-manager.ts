/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Feature } from 'geojson';
import { combineLatest, Observable, of, Subscription } from 'rxjs';

import { computeIfAbsent, SuperCalled } from '@oksygen-common-libraries/common';
import { HubState } from '@oksygen-sim-train-libraries/components-services/hubs';
import { UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';

import { SourceManager, SourceManagerConfiguration } from '../../mapbox.layers';

export const DRIVER_SOURCE_NAME = 'drivers';

export interface DriverSourceManagerConfiguration extends SourceManagerConfiguration {
  allHubState$: Observable<Array<HubState>>;

  allHubUsers$: Observable<Map<number, Array<number>>>;

  trains$: Observable<Array<UsefulTrain>>;

  selectedTrain$: Observable<UsefulTrain>;
}

/**
 * Manages Mapbox Sources for rendering driver avatars.
 */
export class DriverSourceManager extends SourceManager<DriverSourceManagerConfiguration> {
  private dataSub: Subscription;

  constructor(configuration: DriverSourceManagerConfiguration) {
    super(DRIVER_SOURCE_NAME, configuration);

    this.dataSub = combineLatest([
      this.configuration.allHubState$ ?? of([]),
      this.configuration.allHubUsers$ ?? of(new Map<number, Array<number>>()),
      this.configuration.trains$,
      this.configuration.selectedTrain$
    ])
      .pipe()
      .subscribe(([hubStates, hubUsers, trains, train]) => {
        /** Maps Train IDs to associated Hubs. */
        const trainHubs = new Map<number, Array<{ hubId: number; vehicleIndex: number }>>();

        hubStates?.forEach(h => computeIfAbsent(trainHubs, h.scenarioTrainId, x => []).push({ hubId: h.hubId, vehicleIndex: h.vehicleIndex }));

        this.updateSource(trains, trainHubs, hubUsers, train?.id);
      });
  }

  override destroy(): SuperCalled {
    this.dataSub?.unsubscribe();

    return super.destroy();
  }

  /**
   * Publishes the source.
   */
  private updateSource(
    trains: Array<UsefulTrain>,
    trainHubs: Map<number, Array<{ hubId: number; vehicleIndex: number }>>,
    hubUsers: Map<number, Array<number>>,
    selectedScenarioTrainId?: number
  ): void {
    const features = new Array<Feature>();

    trains?.forEach(t => {
      trainHubs.get(t.id)?.forEach(hubAssoc => {
        hubUsers.get(hubAssoc.hubId)?.forEach(userId => {
          const pos = t.vehicles[hubAssoc.vehicleIndex]?.position?.lnglat;

          if (userId && pos) {
            features.push({
              type: 'Feature',
              id: 'track_network', // FIXME should be unique per feature. Use hubId?
              properties: {
                userId,
                selected: selectedScenarioTrainId === t.id,
                debugText: userId
              },
              geometry: {
                type: 'MultiLineString',
                coordinates: [pos]
              }
            });
          }
        });
      });
    });

    this.geoJSONSource.next({
      type: 'FeatureCollection',
      features
    });
  }
}
