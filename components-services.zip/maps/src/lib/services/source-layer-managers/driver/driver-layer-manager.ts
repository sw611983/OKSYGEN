/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { Map } from 'maplibre-gl';

import { LayerManager } from '../../mapbox.layers';
import { DRIVER_SOURCE_NAME } from './driver-source-manager';

export const DRIVER_LAYER_NAME = 'drivers';

export class DriverLayerManager extends LayerManager {
  constructor() {
    super(DRIVER_LAYER_NAME);
  }

  public override clear(): void {}

  public attachLayerTo(map: Map, _elRef: ElementRef<any>, _getDragPreview: (objectRef: any) => Element): void {
    if (this.mapHasSource(map, DRIVER_SOURCE_NAME)) {
      map.addLayer({
        id: DRIVER_LAYER_NAME,
        type: 'symbol',
        source: DRIVER_SOURCE_NAME,
        minzoom: 1,
        layout: {
          'icon-image': ['concat', 'U', ['get', 'userId']],
          // The following will load an alternative icon when the train is selected. It's not clear what this should look like right now.
          // 'icon-image': ['concat', 'U', ['get', 'userId'], ['case', ['get', 'selected'], 'S', '']],
          'icon-size': [
            'interpolate',
            ['linear'],
            ['zoom'],
            // set the max zoom level to show small icons, and that icon size
            16,
            0.5,
            // set the min zoom level to show big icons, and that icon size
            18,
            1
          ],
          'icon-allow-overlap': true
        }
      });
    }
  }
}
