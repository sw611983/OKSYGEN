/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Map as MapLibre } from 'maplibre-gl';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { asArray } from '@oksygen-common-libraries/common';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

/**
 * Publishes IO info from map components.
 * This allows collation of map component state and dissemination of interactions
 * so callers can know about what is happining on map views without being directly bound to them.
 *
 * Currently the scope of this is quite narrow, but in the future it could supply things like:
 * * Mouse over notifications
 * * IDs of "Things" that are visible
 * * Map view locations
 * * IDs of visible map views
 */
export class MapIOManager {
  private mapBoundsUpdateSubscription = new Map<string, Subscription>();
  private visibleSegments = new Map<string, number[]>();
  private visibleSegmentsSubject: BehaviorSubject<number[]>;

  constructor() {
    this.visibleSegmentsSubject = new BehaviorSubject([]);
  }

  destroy(): void {
    this.visibleSegmentsSubject.complete();
    this.mapBoundsUpdateSubscription.forEach((v, k, m) => v.unsubscribe());
  }

  /**
   * Wires up feedback from the map for propagation to the wider application.
   */
  public bindMapEvents(map: MapLibre, mapId: string, ndm: NetworkDefinitionManager): void {
    // Throttle map bounds updated events - we only want to recalculate this every second
    // const MAP_BOUNDS_UPDATE_INTERVAL = 500;

    // this.mapBoundsUpdateSubscription.set(
    //   mapId,
    //   fromEvent<any>(map as any, 'move')
    //     .pipe(throttleTime(MAP_BOUNDS_UPDATE_INTERVAL, asyncScheduler, { leading: true, trailing: true }))
    //     .subscribe(x => {
    //       const b = map.getBounds();
    //       const bounds = {
    //         minX: b.getWest(),
    //         maxX: b.getEast(),
    //         minY: b.getSouth(),
    //         maxY: b.getNorth()
    //       };

    //       this.setVisibleSegments(mapId, ndm.segmentsInBoundingBox(bounds));
    //     })
    // );
  }

  /**
   * Wires up feedback from the map for propagation to the wider application.
   */
  public unbindMapEvents(mapId: string): void {
    this.mapBoundsUpdateSubscription.get(mapId)?.unsubscribe();
    this.mapBoundsUpdateSubscription.delete(mapId);
  }

  private setVisibleSegments(mapId: string, visibleSegments: number[]): void {
    visibleSegments = asArray(visibleSegments);
    this.visibleSegments.set(mapId, visibleSegments);

    const unique = new Set<number>();
    const itr = this.visibleSegments.values();
    let result = itr.next(undefined);

    while (!result.done) {
      result.value.forEach((sid: any) => unique.add(sid));
      result = itr.next(undefined);
    }

    this.visibleSegmentsSubject.next(Array.from(unique));
  }

  /**
   * Returns the IDs of all segments that are currently visible across all map components.
   */
  public getVisibleSegments$(): Observable<number[]> {
    return this.visibleSegmentsSubject.asObservable();
  }
}
