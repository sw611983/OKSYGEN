/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef, NgZone } from '@angular/core';
import { FeatureCollection } from 'geojson';
import { forOwn, isNil, set } from 'lodash';
import { ExpressionSpecification, GeoJSONSource, LngLat, Map } from 'maplibre-gl';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

import { DragFeedback, SelfCompletingObservable, SUPER_WAS_CALLED, SuperCalled } from '@oksygen-common-libraries/common';
import { LngLatCoord, SegOffsetOriented, UserScale } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData, ObjectLayer } from '@oksygen-sim-train-libraries/components-services/common';

import { emptyGeoJSONCollection } from '../helpers/mapbox.source';
import { SelectionHandler } from '../interfaces/selection-handlers/selection-handler.interface';

export enum SelectionType {
  TRAIN
}

export interface SelectionValue {
  type: SelectionType;
  id: number;
}

export const SELECTED_SOURCE_NAME = 'selected';

// eslint-disable-next-line @typescript-eslint/no-empty-interface, @typescript-eslint/no-empty-object-type
export interface LayerManagerConfiguration {}

export abstract class LayerManager<C extends LayerManagerConfiguration = LayerManagerConfiguration> {
  protected static readonly DEFAULT_FILTERS_COUNT = 4;
  protected static readonly ALL_FILTERS_INDEX = 2;

  protected static readonly IS_HOVER: ExpressionSpecification = ['boolean', ['feature-state', 'hover'], false];

  constructor(public readonly layerName: string, protected readonly configuration?: C, protected readonly zone?: NgZone) {}

  public abstract clear(): void;
  /**
   * Attachs our layers to the map. This should be implemented in your extending class.
   * We may want to add a "skin" parameter if we want to offer different look n' feel options.
   *
   * @param map the map to add your layers to
   */
  public abstract attachLayerTo(map: Map, elRef: ElementRef, getDragPreview: (objectRef: any) => Element): void;

  public addImagesToMap(
    addDirectionalImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    addDirectionalRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void,
    addDirectionalTwoObjectsRingImageToMap: (name: string, primaryColour: string, secondaryColour: string, bidi: boolean) => void
  ): void {}

  public registerClickHandler(selectedSubject: Subject<SelectionValue>, stopPropagation: boolean): void {}

  public onLayersUpdate(layerArray: Array<ObjectLayer>): void {}

  public setInputHandler(rawHandler: any): void {}

  protected mapHasSource(map: Map, id: string): boolean {
    return !isNil(map.getSource(id));
  }
}

export abstract class DragLayerManager<C extends LayerManagerConfiguration = LayerManagerConfiguration> extends LayerManager<C> {
  public abstract override attachLayerTo(map: Map): void;
  public clear(): void {}
}

// eslint-disable-next-line @typescript-eslint/no-empty-interface, @typescript-eslint/no-empty-object-type
export interface SourceManagerConfiguration {}

export abstract class BaseSourceManager<C extends SourceManagerConfiguration = SourceManagerConfiguration> {
  protected geoJSONSource = new BehaviorSubject<FeatureCollection>(emptyGeoJSONCollection());

  protected readonly configuration: C | undefined;

  constructor(public readonly sourceNames: Array<string>, configuration?: C) {
    this.configuration = configuration;
  }

  public updateConfiguration(update: Partial<C>): void {
    forOwn(update, (value, key) => {
      set(this.configuration, key, value);
    });
  }

  /**
   * Returns our geoJSON observable.
   */
  public asObservable(): Observable<FeatureCollection> {
    return this.geoJSONSource.asObservable();
  }

  /**
   * This is our destructor. You should implement it and clean up after yourself.
   * So much mess - a dangling pointer here, an observable subscription there...
   */
  public destroy(): SuperCalled {
    this.geoJSONSource.complete();

    return SUPER_WAS_CALLED;
  }

  protected getMapGeoJSONSource(map: Map, id: string): GeoJSONSource {
    return map.getSource(id) as GeoJSONSource;
  }

  protected mapHasSource(map: Map, id: string): boolean {
    return !isNil(map.getSource(id));
  }
}

export abstract class SourceManager<C extends SourceManagerConfiguration = SourceManagerConfiguration> extends BaseSourceManager<C> {
  constructor(public readonly sourceName: string, configuration?: C) {
    super([sourceName], configuration);
  }

  /**
   * Doesn't do all that much at the moment.. Consider adding another param to pass through extra functionality
   */
  public pointerHoverLayer(layerName: string, map: Map): void {
    map.on('mouseenter', layerName, event => {
      map.getCanvas().style.cursor = 'pointer';
    });
    map.on('mouseleave', layerName, event => {
      map.getCanvas().style.cursor = '';
    });
  }
}

export interface DragSourceManagerConfiguration<H extends SelectionHandler = SelectionHandler> extends SourceManagerConfiguration {
  handler: H;
}

export abstract class DragSourceManager<C extends SourceManagerConfiguration = SourceManagerConfiguration> extends SourceManager<C> {
  constructor(sourceName: string, configuration?: C) {
    super(sourceName, configuration);
  }

  public abstract supportsDrag(data: DragData): boolean;

  public abstract onDrag(
    dragData: DragData,
    lngLat: LngLat,
    lngLatCoord: LngLatCoord,
    segOffset: SegOffsetOriented,
    userScale: UserScale[]
  ): SelfCompletingObservable<DragFeedback>;

  public abstract onDrop(dragData: DragData, lngLat: LngLat, lngLatCoord: LngLatCoord, segOffset: SegOffsetOriented, userScale: UserScale[]): void;

  public abstract removeFeedback(): void;
}
