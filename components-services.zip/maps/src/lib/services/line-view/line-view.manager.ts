/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Map } from 'maplibre-gl';
import { Observable, of, Subscription } from 'rxjs';

import { SUPER_WAS_CALLED, SuperCalled } from '@oksygen-common-libraries/common';
import { Image } from '@oksygen-sim-train-libraries/components-services/common';

import { ObjectsTrackMapManager } from '../map-managers/objects-track-map.manager';

export const LINE_VIEW_NAME = 'line';

export class LineViewManager extends ObjectsTrackMapManager {

  public override attachSourcesTo(map: Map, parentSubscription: Subscription): SuperCalled {
    // there is no map on the line view
    return SUPER_WAS_CALLED;
  }

  public override attachLayersTo(map: Map): SuperCalled {
    // there is no map on the line view
    return SUPER_WAS_CALLED;
  }

  public attachImagesTo(map: Map, images: Image[]): Observable<number> {
    return of(1);
  }
}
