/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isNil, isNumber, without } from 'lodash';

import {
  Orientation,
  Segment,
  SegOffset,
  SegOffsetOriented,
  SegOriented,
  toOrientation
} from '@oksygen-sim-core-libraries/data-types/common';
import { Range, ReachablePathSegment, SegmentPosition } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectContainer, ObjectType } from '@oksygen-sim-train-libraries/components-services/objects/data';
import {
  Consist,
  consistLength,
  ConsistPlacementInfo,
  ITrainReachablePath,
  ITrainReachablePathFinder,
  TRAIN_TOO_LONG,
  TrainReachablePath,
  TrainTooLong
} from '@oksygen-sim-train-libraries/components-services/trains';

import { ReachablePathFinder } from './reachable-path-finder';

/**
 * Concrete implementation of path finding.
 *
 * This is needed so we can have private methods in this class and use ```Readonly<ReachablePath>``` objects.
 */
class TrainReachablePathImpl extends TrainReachablePath implements ITrainReachablePath {
  constructor() {
    super();
  }

  placeConsistOnPath(
    consist: Consist,
    segIndexOrSegmentOrOffset: number | Segment | SegOffset | SegOffsetOriented,
    offset?: number,
    fromAlpha?: boolean
  ): ConsistPlacementInfo | TrainTooLong {
    // FIXME can be an arg
    const trainLength = consistLength(consist);

    if (this.pathLength < trainLength) {
      // Bail if we can't fit the train on the path.
      return TRAIN_TOO_LONG;
    }

    // Convert segOrIndexOrOffset into something useful
    let segIndex;

    if (isNumber(segIndexOrSegmentOrOffset)) {
      // Handle path index
      segIndex = segIndexOrSegmentOrOffset;
    } else {
      const soo = segIndexOrSegmentOrOffset as SegOffsetOriented;

      if (soo.offset !== undefined) {
        // Handle SegOffset/Oriented
        segIndex = this.indexOf(soo.segmentId);
        offset = soo.offset;
        fromAlpha = soo.orientation === undefined ? true : soo.orientation === Orientation.ALPHA_TO_BETA;
      } else {
        // Handle Segment
        segIndex = this.indexOf((segIndexOrSegmentOrOffset as Segment).id);
      }
    }

    return this.doPlaceConsistOnPath(consist, trainLength, segIndex, offset, fromAlpha);
  }

  /**
   * Determines the placement of a train's cars given a description of where to place them.
   * If the given {@link SegOffset} won't allow the entire train to fit on the track this method attempts to find one which will.
   * Reterned values will be based on the a {@link SegOffset} that fits the whole train.
   *
   * @param consist Describes the makeup of a train.
   * @param startSegIndex The index of the starting segment in the previously scanned path.
   * @param startOffset The offset on the given segment.
   * If the offset is beyond the given segment we attempt to find the equivalent segment/offset on this path.
   * @param startFromAlpha The direction of travel.
   * @returns an array of elements representing vehicles, where the vehicles are described as frontmost and rearmost position pairs
   *   and the {@link SegOffset} of the front of the train.
   */
  private doPlaceConsistOnPath(
    consist: Consist,
    trainLength: number,
    startSegIndex: number,
    startOffset: number,
    startFromAlpha: boolean
  ): ConsistPlacementInfo | TrainTooLong {
    const vehiclePositions = new Array<{ front: SegmentPosition; rear: SegmentPosition }>();
    const segmentOccupancy = new Array<{
      segmentId: number;
      offsetRange: Range;
    }>();

    const startSeg = this.pathSegments[startSegIndex];
    const startSegLength = startSeg.segment.length;

    if (this.pathLength < trainLength) {
      return TRAIN_TOO_LONG;
    }

    // If the starting offset is not valid for this segment, adjust and start again.
    if (startOffset < 0 || startOffset > startSegLength) {
      const validStartOffset = this.toValidSegOffsetOriented({
        segmentId: startSeg.segment.id,
        offset: startOffset,
        orientation: startSeg.direction
      });

      return this.doPlaceConsistOnPath(
        consist,
        trainLength,
        this.indexOf(validStartOffset.segmentId),
        validStartOffset.offset,
        validStartOffset.orientation === Orientation.ALPHA_TO_BETA
      );
    }

    // Find the segment/offset for the rear of the train.
    // This method will automatically prevent falling off the end of the track.
    const end = this.toValidSegOffsetOriented({
      segmentId: startSeg.segment.id,
      offset: startOffset + trainLength * (startFromAlpha ? -1 : 1),
      orientation: toOrientation(startFromAlpha)
    });

    // Move forwards from the end. This will ensure the front is pushed forward if the end couldn't fit.
    const front = this.toValidSegOffsetOriented({
      ...end,
      offset: end.offset + trainLength * (end.orientation === Orientation.ALPHA_TO_BETA ? 1 : -1)
    });

    let vehicleFront = front;
    let startOffsetOnSegment = front;
    let finalOffsetOnSegment = front;

    for (const v of consist.vehicles) {
      const vehicleLength = v.carClass.length;
      const vehicleRear = this.toValidSegOffsetOriented({
        ...vehicleFront,
        offset: vehicleFront.offset + vehicleLength * (vehicleFront.orientation === Orientation.ALPHA_TO_BETA ? -1 : 1)
      });

      if (vehicleRear.segmentId !== startOffsetOnSegment.segmentId) {
        const segmentId = startOffsetOnSegment.segmentId;
        segmentOccupancy.push({
          segmentId,
          offsetRange:
            startOffsetOnSegment.orientation === Orientation.ALPHA_TO_BETA
              ? Range.including(0, startOffsetOnSegment.offset)
              : Range.including(startOffsetOnSegment.offset, this.pathSegments[this.indexOf(segmentId)].segment.length)
        });

        startOffsetOnSegment =
          vehicleRear.orientation === Orientation.ALPHA_TO_BETA
            ? { ...vehicleRear, offset: this.pathSegments[this.indexOf(vehicleRear.segmentId)].segment.length }
            : { ...vehicleRear, offset: 0 };
      }

      // PRDOKS-1205 - Seems like we have a float precision issue on the BE making the segment not be of the right length.
      // Instead of doing some weird things, simply truncate to send 3 digits
      vehiclePositions.push({
        front: { ...vehicleFront, offset: Math.floor(vehicleFront.offset * 1e3) / 1e3, fromAlpha: vehicleFront.orientation === Orientation.ALPHA_TO_BETA },
        rear: { ...vehicleRear, offset: Math.floor(vehicleRear.offset * 1e3) / 1e3, fromAlpha: vehicleRear.orientation === Orientation.ALPHA_TO_BETA }
      });

      // For looping
      vehicleFront = vehicleRear;

      // For post loop processing
      finalOffsetOnSegment = vehicleRear;
    }

    segmentOccupancy.push({
      segmentId: startOffsetOnSegment.segmentId,
      offsetRange: Range.including(startOffsetOnSegment.offset, finalOffsetOnSegment.offset)
    });

    return {
      vehiclePositions,
      segmentOccupancy
    };
  }
}

/**
 * Determines "reachable" paths through a track network,
 * which are paths for which points are set (or traversable) and
 * are created by scanning from some starting location(s) (typically a train's ends).
 *
 * Paths are flagged as circular if the two "ends" of the path connect.
 * Currently there is no information provided about circles within the path (i.e. P-shaped paths),
 * apart from the loop flag being set.
 * In that case, once the train is entirely within the inner circle
 * the next path refresh will generate a circular path without the run-in segment(s),
 * since those will no longer be reachable.
 *
 * Paths are ordered in the direction of travel.
 * The segment at [0] is either behind the train or where the last car is,
 * and the segment at [pathSegments.length] is either in front of the train or where the lead car is.
 */
export class TrainReachablePathFinder extends ReachablePathFinder implements ITrainReachablePathFinder {

  constructor(pointsType: ObjectType, getObject: (id: number) => ObjectContainer) {
    super(pointsType, getObject);
  }

  /**
   * Determines the path for the given train,
   * which is a collection of reachable segments extending from either end of the train
   * (and the segments it occupies).
   *
   * The lead and rear cars should be coupled;
   * any disconnected cars should be ignored for the purposes of path generation.
   * Car positions should be given in terms of bogies at the extremeties of the set of connected cars;
   * using the position of the "front" of a car can give incorrect results with spring points
   * and other corner cases.
   *
   * Note that if you require a "live" path, this method should be called when:
   * * the lead or rear cars' bogies change segments
   * * the default direction of the train changes (i.e. the lead and rear cars swap)
   * * any of the pathChangePoints change state
   */
  override scanPath(startSeg: SegOriented): Readonly<TrainReachablePath> {
    return this.doScanTrainPath(startSeg);
  }

  /**
   * Determines the path for the given train,
   * which is a collection of reachable segments extending from either end of the train
   * (and the segments it occupies).
   *
   * The lead and rear cars should be coupled;
   * any disconnected cars should be ignored for the purposes of path generation.
   * Car positions should be given in terms of bogies at the extremeties of the set of connected cars;
   * using the position of the "front" of a car can give incorrect results with spring points
   * and other corner cases.
   *
   * Note that if you require a "live" path, this method should be called when:
   * * the lead or rear cars' bogies change segments
   * * the default direction of the train changes (i.e. the lead and rear cars swap)
   * * any of the pathChangePoints change state
   */
  scanTrainPath(
    trainLength: number,
    leadCarPos: SegmentPosition | SegOffsetOriented,
    rearCarPos?: SegmentPosition | SegOffsetOriented
  ): Readonly<TrainReachablePath>;

  scanTrainPath(
    trainLengthOrStartSeg: number | SegOriented,
    leadCarPos?: SegmentPosition | SegOffsetOriented,
    rearCarPos?: SegmentPosition | SegOffsetOriented
  ): Readonly<TrainReachablePath> {
    return this.doScanTrainPath(trainLengthOrStartSeg, leadCarPos, rearCarPos);
  }

  private doScanTrainPath(
    trainLengthOrStartSeg: number | SegOriented,
    leadCarPos?: SegmentPosition | SegOffsetOriented,
    rearCarPos?: SegmentPosition | SegOffsetOriented
  ): Readonly<TrainReachablePath> {
    let trainLength = 0;

    if (isNumber(trainLengthOrStartSeg)) {
      trainLength = trainLengthOrStartSeg;
      leadCarPos = this.toSegPos(leadCarPos);
    } else {
      leadCarPos = this.toSegPos(trainLengthOrStartSeg);
    }

    if (!leadCarPos) throw Error('Need a starting position!');

    rearCarPos = rearCarPos ? this.toSegPos(rearCarPos) : leadCarPos;

    const newPath = new TrainReachablePathImpl();

    if (leadCarPos) {
      // Add all segments in front of the lead car
      this.addReachableSegments(
        newPath,
        newPath.pathSegments,
        newPath.pathChangePoints,
        newPath.pathObjects,
        this.worldData.segmentMap.get(leadCarPos.segmentId),
        true,
        null,
        leadCarPos.fromAlpha,
        true
      );

      const pathSegmentsInFront = newPath.pathSegments.length;

      // Add all segments in behind of the rear car
      this.addReachableSegments(
        newPath,
        newPath.pathSegments,
        newPath.pathChangePoints,
        newPath.pathObjects,
        this.worldData.segmentMap.get(rearCarPos.segmentId),
        leadCarPos.segmentId !== rearCarPos.segmentId,
        null,
        !rearCarPos.fromAlpha,
        false
      );

      // Check if the path is circular
      // Note that being circular is a particular form of looping
      // which is distinct from the path simply traversing the same segment twice.
      if (newPath.loop && newPath.pathSegments.length > 0) {
        const first = newPath.pathSegments[0];
        const last = newPath.pathSegments[newPath.pathSegments.length - 1];

        const c = this.getActiveConnectionFrom(last.segment, !last.isFromAlpha());

        if (c && c.toSegmentId === first.segment.id && c.toAlpha === first.isFromAlpha()) {
          newPath.circular = true;
        }
      }

      // Finally, we need to make sure that all segments between the front and the rear are included.

      // If the path is circular we can be certain that we've already included them.
      if (!newPath.circular) {
        // We expect there's nothing too whacky on this path, like points being set in the wrong direction.
        const internalPathSegs = new Array<ReachablePathSegment>();

        const pathSegmentsInRear = newPath.pathSegments.length - pathSegmentsInFront;
        const leadPathSegment = newPath.pathSegments[pathSegmentsInRear];
        if (!leadPathSegment) {
          return null;
        } // TODO Stan

        // This check is assuming that there's no way to have the lead and rear cars
        // on the same segment going in different directions.
        if (rearCarPos.segmentId !== leadPathSegment.segment.id) {
          // Find all segments in front of the rear car, until we encounter a segment we've seen before.
          this.addReachableSegments(
            newPath,
            internalPathSegs,
            newPath.pathChangePoints,
            newPath.pathObjects,
            this.worldData.segmentMap.get(rearCarPos.segmentId),
            false,
            leadPathSegment,
            rearCarPos.fromAlpha,
            true
          );

          // An easy sanity check that things seem sensible
          if (this.lengthOf(internalPathSegs) < trainLength) {
            // Insert the internal segments between the ones in front and the ones behind
            newPath.pathSegments.splice(pathSegmentsInRear, 0, ...internalPathSegs);
          }
        }
      }

      // Now that we've figured out what's on the path and in what order,
      // we can do any additional housekeeping to prepare it for consumption.

      newPath.pathLength = this.lengthOf(newPath.pathSegments);

      // Rebalance circular paths to have some trailing segments, which helps avoid jumpy updates in the linear view
      if (newPath.circular) {
        let upcomingPathLength = 0;
        const upcomingPathLengthLimit = (newPath.pathLength * 2) / 3;
        let leadCarSegIndex = null;
        let leftmostSegmentIndex = null;

        // Loop through the path (up to) twice to:
        // 1: find the segment that the lead car is on
        // 2: figure out the index of the segemtn we want to appear on the left of the view
        while (leftmostSegmentIndex === null) {
          for (let i = 0; i < newPath.pathSegments.length; ++i) {
            const ps = newPath.pathSegments[i];

            // Corner case:
            // If we encounter the lead car's path segment a second time, we need to stop looking.
            if (i === leadCarSegIndex) {
              leftmostSegmentIndex = leadCarSegIndex;
              break;
            }

            if (leadCarSegIndex === null) {
              // Check if this is path segment with the car on it.
              // Note that the segment ID is not enough, as we may traverse the same segment in the other direction on this path.
              if (ps.segment.id === leadCarPos.segmentId && (ps.direction === Orientation.ALPHA_TO_BETA) === leadCarPos.fromAlpha) {
                leadCarSegIndex = i;
              }
            }

            // Sum the lengths of the segments ahead of the train (including the segment the lead car is on)
            if (leadCarSegIndex !== null) {
              upcomingPathLength += ps.segment.length;
            }

            // Once we reach the maximum length, we want the current segment to be the rightmost in the view.
            // Therefore, the segment that follows it should be the leftmost.
            // Setting this will break out of these processing loops.
            if (upcomingPathLength > upcomingPathLengthLimit) {
              leftmostSegmentIndex = i + 1;

              // In case the leftmost segment is in fact at index 0...
              if (leftmostSegmentIndex >= newPath.pathSegments.length) {
                leftmostSegmentIndex = 0;
              }

              break;
            }
          }
        }

        if (leftmostSegmentIndex > 0) {
          // Rotate the path to put the item at leftmostSegmentIndex into index 0.
          const removed = newPath.pathSegments.splice(leftmostSegmentIndex, newPath.pathSegments.length - leftmostSegmentIndex);
          newPath.pathSegments.push(...removed);
        }
      }
    }

    newPath.pathSegments.forEach(ps => newPath.pathSegmentMap.set(ps.segment.id, ps.segment));

    newPath.nonPathSegments = without(Array.from(this.worldData.segmentMap.keys()), ...newPath.pathSegments.map((ps, i, a) => ps.segment.id)).map(s =>
      this.worldData.segmentMap.get(s)
    );

    return Object.freeze(newPath);
  }

  private toSegPos(maybeSSO: SegOriented | SegOffsetOriented | SegmentPosition): SegmentPosition {
    const orientation = (maybeSSO as any).orientation;

    if (!isNil(orientation)) {
      return {
        ...maybeSSO,
        offset: (maybeSSO as SegOffsetOriented).offset ?? 0,
        fromAlpha: orientation === Orientation.ALPHA_TO_BETA
      };
    }

    return maybeSSO as SegmentPosition;
  }
}
