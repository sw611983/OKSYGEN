/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { Map } from 'maplibre-gl';

import { MapColor } from '../../helpers/map-color.enum';
import { LayerManager } from '../mapbox.layers';
import { TRACK_SOURCE_NAME } from '../source-layer-managers/track/track-source-manager';

export const TRACK_LAYER_NAME = 'track';

/**
 * Manages a track layer for use in a Mapbox map.
 */
export class MiniMapTrackLayerManager extends LayerManager {
  private map: Map = undefined;

  constructor() {
    super(TRACK_LAYER_NAME);
  }

  public override clear(): void {
    this.map = null;
  }

  attachLayerTo(map: Map, _elRef: ElementRef, _getDragPreview: (objectRef: any) => Element): void {
    if (this.map) {
      throw new Error(`Can't attach to multiple maps!`);
    }

    if (!map) {
      throw new Error(`Can't attach to null maps!`);
    }

    this.map = map;

    if (this.mapHasSource(map, TRACK_SOURCE_NAME)) {
      map.addLayer({
        id: TRACK_LAYER_NAME,
        type: 'line',
        source: TRACK_SOURCE_NAME,
        paint: {
          'line-width': 1,
          'line-color': MapColor.TRACK_LAYER_LINE
        }
      });
    }
  }
}
