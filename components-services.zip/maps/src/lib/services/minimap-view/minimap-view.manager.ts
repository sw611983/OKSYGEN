/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgZone } from '@angular/core';
import { isEqual, isFunction, isNil } from 'lodash';
import { LngLatBounds, Map } from 'maplibre-gl';
import { BehaviorSubject, combineLatest, Observable, of, Subscription } from 'rxjs';

import { shareReplayOne, SUPER_WAS_CALLED, SuperCalled } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { Image } from '@oksygen-sim-train-libraries/components-services/common';

import { getMapGeoJSONSource, notNullGeoJSONCollection } from '../../helpers/mapbox.source';
import {
  isTrackMapManager,
  ITrackMapManager,
  TrackMapManagerConfiguration
} from '../../interfaces/map-managers/track-map-manager.interface';
import { TrackMapManager } from '../map-managers/track-map.manager';
import { BackgroundLayerManager } from '../source-layer-managers/background-layer-manager';
import { TRACK_SOURCE_NAME } from '../source-layer-managers/track/track-source-manager';
import { MiniMapTrackLayerManager } from './track-layer-manager';
import { MinimapTrackSourceManager } from './track-source-manager';
import { MiniMapTrackingLayerManager } from './tracking-layer-manager';
import { MinimapTrackingSourceManager } from './tracking-source-manager';

export const NAME = 'minimap';
export const MINIMAP_VIEW_NAME = 'minimap';

export interface IMiniMapManager extends ITrackMapManager {
  update(onlyCrosshair: boolean, bounds: LngLatBounds, zoom: number): void;
}

export function isMiniMapManager(manager: any): manager is IMiniMapManager {
  return !isNil(manager) && isFunction(manager.update) && isTrackMapManager(manager);
}

export class MinimapViewManager extends TrackMapManager<TrackMapManagerConfiguration, MinimapTrackSourceManager> implements IMiniMapManager {
  private trackingSourceManager: MinimapTrackingSourceManager;

  private trackingLayerManager: MiniMapTrackingLayerManager;

  private trackingSubject = new BehaviorSubject<LngLatBounds | undefined>(undefined);

  private onlyCrosshairSubject = new BehaviorSubject<boolean>(true);

  private zoomSubject = new BehaviorSubject<number>(0);
  // private previousCrosshairEmission: [mapbox.LngLatLike, boolean, number] = null;

  constructor(logging: Logging, registry: Registry, zone: NgZone, configuration: TrackMapManagerConfiguration) {
    // redfine configuration, so it can only be a TrackMapManagerConfiguration
    super(logging, registry, zone, {
      pointType: undefined,
      netDef$: configuration.netDef$,
      world$: configuration.world$,
      mapConfig: configuration.mapConfig
    });

    this.trackingLayerManager = new MiniMapTrackingLayerManager();

    this.layerManagers = [new BackgroundLayerManager(), new MiniMapTrackLayerManager(), this.trackingLayerManager];

    this.worldBoundsSources = [TRACK_SOURCE_NAME];
  }

  public attachImagesTo(map: Map, _images: Image[], _batchSize = 500, _delayBetweenBatches = 5): Observable<number> {
    return of(1);
  }

  // override to only attach the track source manager
  public override attachSourcesTo(map: Map, parentSubscription: Subscription): SuperCalled {
    if (!this.sourceManagersCreated) {
      this.createSources();
    }

    parentSubscription.add(
      this.trackSourceManager.asObservable().subscribe(t => {
        getMapGeoJSONSource(map, this.trackSourceManager.sourceName)?.setData(notNullGeoJSONCollection(t));
        // Shows segment IDs
        // this.getMapGeoJSONSource(map, DEBUG_SOURCE_NAME).setData(t);
        this.geometrySourceUpdated.next(null);
      })
    );

    parentSubscription.add(
      this.trackSourceManager.worldBounds$.subscribe(worldBounds => {
        if (!isNil(worldBounds)) {
          map.fitBounds(worldBounds, {
            animate: false,
            padding: 5
          });
        }
      })
    );

    parentSubscription.add(
      combineLatest([
        this.trackingSourceManager.crosshairLngLat$,
        this.onlyCrosshairSubject.pipe(shareReplayOne()),
        this.zoomSubject.pipe(shareReplayOne())
      ]).subscribe(([crosshairLngLat, onlyCrosshair, zoom]) => {
        this.trackingLayerManager.updateCrossHair(onlyCrosshair, zoom, crosshairLngLat);
        // this.previousCrosshairEmission = [crosshairLngLat, onlyCrosshair, zoom];
      })
    );

    return SUPER_WAS_CALLED;
  }

  update(onlyCrosshair: boolean, bounds: LngLatBounds, zoom: number): void {
    if (this.onlyCrosshairSubject.getValue() !== onlyCrosshair) {
      this.onlyCrosshairSubject.next(onlyCrosshair);
    }

    if (this.zoomSubject.getValue() !== zoom) {
      this.zoomSubject.next(zoom);
    }

    if (!isEqual(this.trackingSubject.getValue(), bounds)) {
      this.trackingSubject.next(bounds);
    }
  }

  protected override getSources(): Array<string> {
    const sources = super.getSources();

    if (!isNil(this.trackingSourceManager)) {
      sources.push(...this.trackingSourceManager.sourceNames);
    }

    return sources;
  }

  protected override createSources(): SuperCalled {
    if (isNil(this.trackingSourceManager)) {
      this.trackingSourceManager = new MinimapTrackingSourceManager({
        tracking$: this.trackingSubject.pipe(shareReplayOne())
      });
    }

    return super.createSources();
  }

  public override createTrackSourceManager(): MinimapTrackSourceManager {
    return new MinimapTrackSourceManager(this.configuration);
  }

  public override destroy(): SuperCalled {
    this.trackingSourceManager?.destroy();
    this.trackingSubject.complete();
    this.onlyCrosshairSubject.complete();
    this.zoomSubject.complete();

    return super.destroy();
  }
}
