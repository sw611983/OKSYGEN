/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { BackgroundLayerSpecification, Map } from 'maplibre-gl';

import { ThemeColorHex } from '@oksygen-common-libraries/material/theme';

import { LayerManager } from '../mapbox.layers';

export const BACKGROUND_LAYER_NAME = 'background';

export class MinimapBackgroundLayerManager extends LayerManager {
  public static readonly LAYER: BackgroundLayerSpecification = {
    id: BACKGROUND_LAYER_NAME,
    type: 'background',
    paint: {
      'background-color': ThemeColorHex.WHITE
    }
  };

  constructor() {
    super(BACKGROUND_LAYER_NAME);
  }

  public override clear(): void {}

  public attachLayerTo(map: Map, _elRef: ElementRef<any>, _getDragPreview: (objectRef: any) => Element): void {
    map.addLayer(MinimapBackgroundLayerManager.LAYER);
  }
}
