/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { isNil } from 'lodash';
import { LngLatLike, Map, Marker } from 'maplibre-gl';

import { MapColor } from '../../helpers/map-color.enum';
import { LayerManager } from '../mapbox.layers';
import { TRACK_SOURCE_NAME } from '../source-layer-managers/track/track-source-manager';
import { TRACKING_SOURCE_NAME } from './tracking-source-manager';

export const TRACKING_LAYER_NAME = 'trackingRectFill';

const LINE_WIDTH = 2;
const LINE_OPACITY = 1;
const MINI_MAP_CROSSHAIR_ZOOM_LEVEL = 14;
/**
 * Manages a track layer for use in a Mapbox map.
 */
export class MiniMapTrackingLayerManager extends LayerManager {
  private map: Map = undefined;

  private crosshairMarker: Marker;

  constructor() {
    super(TRACKING_LAYER_NAME);
  }

  public override clear(): void {}

  attachLayerTo(map: Map, elRef: ElementRef, _getDragPreview: (objectRef: any) => Element): void {
    if (this.map) {
      throw new Error(`Can't attach to multiple maps!`);
    }

    if (!map) {
      throw new Error(`Can't attach to null maps!`);
    }

    this.map = map;

    this.crosshairMarker = new Marker(elRef.nativeElement);

    if (this.mapHasSource(map, TRACK_SOURCE_NAME)) {
      map.addLayer({
        id: TRACKING_LAYER_NAME,
        type: 'line',
        source: TRACKING_SOURCE_NAME,
        layout: {},
        paint: {
          'line-color': MapColor.MINI_MAP_LINE,
          'line-opacity': LINE_OPACITY,
          'line-width': LINE_WIDTH
        }
      });
    }
  }

  public updateCrossHair(onlyCrosshair: boolean, zoom: number, lngLat: LngLatLike): void {
    if (!this.map) {
      return;
    }
    if (!isNil(lngLat) && (onlyCrosshair || zoom >= MINI_MAP_CROSSHAIR_ZOOM_LEVEL)) {
      this.crosshairMarker.setLngLat(lngLat);
      this.crosshairMarker.addTo(this.map);
      this.crosshairMarker.getElement().style.display = 'block';
      this.map.setLayoutProperty('trackingRectFill', 'visibility', 'none');
    } else {
      this.crosshairMarker.getElement().style.display = 'none';
      this.map.setLayoutProperty('trackingRectFill', 'visibility', 'visible');
    }
  }
}
