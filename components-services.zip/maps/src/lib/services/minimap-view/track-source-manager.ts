/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isArray, isNil } from 'lodash';
import { LngLatBounds } from 'maplibre-gl';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { shareReplayOne, SuperCalled } from '@oksygen-common-libraries/common';
import { WorldData } from '@oksygen-sim-train-libraries/components-services/common';

import { emptyGeoJSONCollection } from '../../helpers/mapbox.source';
import { MapBoxBounds } from '../mapbox.bounds';
import { SourceManagerConfiguration } from '../mapbox.layers';
import { AbstractTrackSourceManager } from '../source-layer-managers/track/track-source-manager';

export interface MinimapTrackSourceManagerConfiguration extends SourceManagerConfiguration {
  world$: Observable<WorldData>;
}

/**
 * Manages Mapbox Sources for rendering tracks.
 */
export class MinimapTrackSourceManager extends AbstractTrackSourceManager<MinimapTrackSourceManagerConfiguration> {
  private worldSub = Subscription.EMPTY;

  private worldBoundsSubject = new BehaviorSubject<LngLatBounds | undefined>(undefined);

  constructor(configuration: MinimapTrackSourceManagerConfiguration) {
    super(configuration);

    this.worldSub = this.configuration.world$?.pipe().subscribe(w => {
      if (isNil(w)) {
        this.geoJSONSource.next(emptyGeoJSONCollection());
        return;
      }

      const trackGeoJson = this.createTrackGeoJSON(w.segmentPolylines);

      if (!isNil(trackGeoJson?.features) && isArray(trackGeoJson?.features) && trackGeoJson?.features.length > 0) {
        const mapBoxBounds = new MapBoxBounds(trackGeoJson?.features);

        if (!isNil(mapBoxBounds?.worldBounds)) {
          this.worldBoundsSubject.next(mapBoxBounds.worldBounds);
        }
      }

      this.geoJSONSource.next(trackGeoJson);
    });
  }

  public get worldBounds$(): Observable<LngLatBounds | undefined> {
    return this.worldBoundsSubject.pipe(shareReplayOne());
  }

  override destroy(): SuperCalled {
    this.worldSub.unsubscribe();
    this.worldBoundsSubject.complete();

    return super.destroy();
  }
}
