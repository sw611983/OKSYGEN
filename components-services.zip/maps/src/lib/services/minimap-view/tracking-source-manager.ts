/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { FeatureCollection } from 'geojson';
import { isNil } from 'lodash';
import { LngLatBounds, LngLatLike } from 'maplibre-gl';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { shareReplayOne, SuperCalled } from '@oksygen-common-libraries/common';

import { emptyGeoJSONCollection } from '../../helpers/mapbox.source';
import { SourceManager, SourceManagerConfiguration } from '../mapbox.layers';

export interface MinimapTrackingSourceManagerConfiguration extends SourceManagerConfiguration {
  tracking$: Observable<LngLatBounds>;
}

export const TRACKING_SOURCE_NAME = 'trackingRect';

/**
 * Manages Mapbox Sources for rendering tracks.
 */
export class MinimapTrackingSourceManager extends SourceManager<MinimapTrackingSourceManagerConfiguration> {
  private trackingSub = Subscription.EMPTY;

  private crosshairLngLatSubject = new BehaviorSubject<LngLatLike | undefined>(undefined);

  constructor(configuration: MinimapTrackingSourceManagerConfiguration) {
    super(TRACKING_SOURCE_NAME, configuration);

    this.trackingSub = this.configuration.tracking$?.pipe().subscribe(bounds => {
      if (isNil(bounds)) {
        this.geoJSONSource.next(emptyGeoJSONCollection());
        return;
      }

      const ne = bounds.getNorthEast();
      const sw = bounds.getSouthWest();

      this.crosshairLngLatSubject.next([sw.lng + (ne.lng - sw.lng) / 2, sw.lat + (ne.lat - sw.lat) / 2]);

      this.geoJSONSource.next(this.createTrackingGeoJSON(bounds));
    });
  }

  public get crosshairLngLat$(): Observable<LngLatLike> {
    return this.crosshairLngLatSubject.pipe(shareReplayOne());
  }

  private createTrackingGeoJSON(bounds: LngLatBounds): FeatureCollection {
    const ne = bounds.getNorthEast();
    const sw = bounds.getSouthWest();

    const trackingRectCoordinates: any = [[[], [], [], [], []]];

    trackingRectCoordinates[0][0][0] = ne.lng;
    trackingRectCoordinates[0][0][1] = ne.lat;

    trackingRectCoordinates[0][1][0] = sw.lng;
    trackingRectCoordinates[0][1][1] = ne.lat;

    trackingRectCoordinates[0][2][0] = sw.lng;
    trackingRectCoordinates[0][2][1] = sw.lat;

    trackingRectCoordinates[0][3][0] = ne.lng;
    trackingRectCoordinates[0][3][1] = sw.lat;

    trackingRectCoordinates[0][4][0] = ne.lng;
    trackingRectCoordinates[0][4][1] = ne.lat;

    return {
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          properties: {
            name: 'trackingRect',
            bounds
          },
          geometry: {
            type: 'Polygon',
            coordinates: trackingRectCoordinates
          }
        }
      ]
    };
  }

  override destroy(): SuperCalled {
    this.trackingSub.unsubscribe();

    this.crosshairLngLatSubject.complete();

    return super.destroy();
  }
}
