/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { Map as MapLibre } from 'maplibre-gl';

import { computeIfAbsent } from '@oksygen-common-libraries/common';
import { WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { MapIOManager } from './map-io-manager';

/**
 * Supplies MapIOManagers, which publish map component info.
 */
@Injectable()
export class MapIOService {
  private mapModels: Map<number, MapIOManager> = new Map();

  constructor(private worldDefinitionService: WorldDefinitionService) {}

  destroySystem(systemNumber: number): void {
    this.mapModels.get(systemNumber)?.destroy();
    this.mapModels.delete(systemNumber);
  }

  /**
   * Wires up feedback from the map for propagation to the wider application.
   */
  public bindMapEvents(map: MapLibre, mapId: string, trackName: string, systemNumber: number): void {
    this.worldDefinitionService.getNetworkDefinitionManager(trackName).then(ndh => this.getMapIOManager(systemNumber).bindMapEvents(map, mapId, ndh));
  }

  /**
   * Unbinds feedback from the map.
   */
  public unbindMapEvents(mapId: string, systemNumber: number): void {
    this.getMapIOManager(systemNumber).unbindMapEvents(mapId);
  }

  public getMapIOManager(systemNumber: number): MapIOManager {
    return computeIfAbsent(this.mapModels, systemNumber, x => new MapIOManager());
  }
}
