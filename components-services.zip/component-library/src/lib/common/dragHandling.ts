/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { DRAG_ELEMENT_ID_COMMON, createDragImage, enableDragHandling } from '@oksygen-common-libraries/common';

/*
 * NOTE
 * because of a security feature drag data is unreadable before the drop occurs,
 * so we store it in the mime type
 *
 * **DO NOT USE THIS TECHNIQUE TO TRANSFER SENSITIVE DATA**
 * This is abusing the API, and is not something you usually want to do :(
 */

/**
 *  Enables drag handling for the host element and creates a drag image with the specified icon name
 * Note that it will try to use the existing div with the same icon name if it exists to avoid creating multiple images in the DOM
 * @param host  The host element
 * @param iconName  The name of the icon
 * @param data  The data to be dragged
 */
export function enableDragHandlingAndHandleDragImage(host: ElementRef, iconName: string, data: any): void {
  // Select the div with id "drag-elements", or create it if it doesn't exist
  let dragElementsDiv = document.getElementById('drag-elements');
  if (!dragElementsDiv) {
    dragElementsDiv = document.createElement('div');
    dragElementsDiv.id = 'drag-elements';
    document.body.appendChild(dragElementsDiv);
  }
  // Create a new image element with the id "drag-image-{iconName}" if it doesn't exist
  const img = document.getElementById(DRAG_ELEMENT_ID_COMMON + iconName) || createDragImage(iconName);
  // Append the image to the "drag-elements" div
  dragElementsDiv.appendChild(img);

  // Enable Drag Handling and make the image visible
  enableDragHandling(
    host,
    () => data,
    () => {
      img.style.visibility = 'visible';
      return img;
    }
  );
  // Hide the image when the drag ends
  host.nativeElement.addEventListener('dragend', () => {
    img.style.visibility = 'hidden';
  });
}
