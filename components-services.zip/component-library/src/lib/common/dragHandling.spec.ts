/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ElementRef } from '@angular/core';
import { enableDragHandlingAndHandleDragImage } from './dragHandling';
import { DRAG_ELEMENT_ID_COMMON } from '@oksygen-common-libraries/common';

describe('enableDragHandlingAndHandleDragImage', () => {
  let host: ElementRef;
  let data: any;

  beforeEach(() => {
    // Set up a mock host element
    host = new ElementRef(document.createElement('div'));
    // Set up mock data
    data = { type: 'RuleTemplateItem', data: 'mockData' };
    document.getElementById('drag-elements')?.remove();
  });

  it('should create and append the image to the "drag-elements" div and set up the drag element', () => {
    expect(document.getElementById('drag-elements')).toBeNull();
    expect(document.getElementById(DRAG_ELEMENT_ID_COMMON + 'iconName')).toBeNull();
    enableDragHandlingAndHandleDragImage(host, 'iconName', data);
    expect(document.getElementById('drag-elements')).not.toBeNull();
    expect(document.getElementById('drag-elements').childElementCount).toEqual(1);
    expect(document.getElementById(DRAG_ELEMENT_ID_COMMON + 'iconName')).not.toBeNull();
    enableDragHandlingAndHandleDragImage(host, 'iconName2', data);
    expect(document.getElementById('drag-elements').childElementCount).toEqual(2);
  });
});
