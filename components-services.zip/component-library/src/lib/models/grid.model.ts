/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Type } from '@angular/core';

/**
 * Component Library grid. A grid has multiple columns, and each column has one or more tiles.
 * Each individual tile is (generally) a list, such as of rules or objects.
 */
export interface CLGrid {
  columns: CLColumn[];
}

/**
 * Component library column. A column has one or more tiles, where each tile is generally a list of related data, such as rules or markers.
 */
export interface CLColumn {
  tiles: CLTile<any>[];
}

/**
 * Component library tile. Each tile is generally a list of related data, such as rules or markers.
 * Supply a component to use and optionally some data for it to consume.
 */
export class CLTile<T> {
  constructor(public component: Type<GridTileComponent<T>>, public data?: T) {}
}

/**
 * An interface for your grid tile components to implement.
 * Just has the data property.
 */
export interface GridTileComponent<T> {
  data: T;
}

