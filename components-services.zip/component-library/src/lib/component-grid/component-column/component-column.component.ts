/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

import { CLColumn } from '../../models/grid.model';
import { ComponentTileComponent } from './component-tile/component-tile.component';

// FIXME this is currently fixed grid of 4 columns!!!

/**
 * See ComponentGridComponent JSDoc comment for information on how this should be used.
 * Generally, you should not be using this component directly and instead use the grid.
 * NOTE - that currently we have a fixed grid of 4 columns.
 */
@Component({
  selector: 'oksygen-component-column',
  templateUrl: './component-column.component.html',
  styleUrls: ['./component-column.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    ComponentTileComponent
]
})
export class ComponentColumnComponent {
  public readonly column = input.required<CLColumn>();

  constructor() {}
}
