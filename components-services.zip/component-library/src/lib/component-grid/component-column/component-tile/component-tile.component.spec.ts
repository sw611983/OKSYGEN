/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, input } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { CLTile, GridTileComponent } from '../../../models/grid.model';

import { ComponentTileComponent } from './component-tile.component';

describe('ComponentTileComponent', () => {
  let component: ComponentTileComponent<any>;
  let fixture: ComponentFixture<ComponentTileComponent<any>>;
  let tile: CLTile<any>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [ComponentTileComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    tile = new CLTile(MyGridTileComponent, { test: 'great Data !' });
    fixture = TestBed.createComponent(ComponentTileComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('tile', tile);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should add tile to view on create', () => {
    const tileHost = fixture.debugElement.query(By.directive(MyGridTileComponent));
    // Check that the component has been added in NgOnInit
    expect(tileHost).toBeTruthy();
    // Check that the component has the correct data
    expect(tileHost.componentInstance.test()).toEqual(tile.data.test);
  });
});

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'test',
  template: ''
})
// Define a class that implements the GridTileComponent interface
class MyGridTileComponent implements GridTileComponent<any> {
  public readonly test = input.required<string>();

  data: any;
  // Add additional methods and properties as needed
}
