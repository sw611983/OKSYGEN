/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, effect, input, viewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { forOwn } from 'lodash';

import { OksygenMaterialComponentsModule, ViewHostDirective } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

import { CLTile } from '../../../models/grid.model';

/**
 * See ComponentGridComponent for usage details.
 */
@Component({
  selector: 'oksygen-component-tile',
  templateUrl: './component-tile.component.html',
  styleUrls: ['./component-tile.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule
]
})
export class ComponentTileComponent<TileData> {
  public readonly tile = input.required<CLTile<TileData>>();
  public readonly tileHost = viewChild.required(ViewHostDirective);

  constructor() {
    effect(() => {
      const tile = this.tile();
      const tileHost = this.tileHost();

      if (!tile) {
        return;
      }

      const componentRef = tileHost?.viewContainerRef?.createComponent(tile.component);

      if (componentRef) {
        forOwn(tile.data, (value, key) => componentRef.setInput(key, value));
      }
    });
  }
}
