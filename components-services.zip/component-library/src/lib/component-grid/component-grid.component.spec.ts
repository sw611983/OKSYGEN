/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ComponentGroupHeaderComponent } from '../component-group/component-group-header/component-group-header.component';
import { ComponentGroupComponent } from '../component-group/component-group.component';
import { ComponentGridComponent } from './component-grid.component';

describe('ComponentGridComponent', () => {
  let component: ComponentGridComponent;
  let fixture: ComponentFixture<ComponentGridComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [ComponentGroupHeaderComponent, ComponentGroupComponent, ComponentGridComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentGridComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('grid', { columns: []});
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
