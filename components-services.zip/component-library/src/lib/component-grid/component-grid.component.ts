/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

import { CLGrid } from '../models/grid.model';
import { ComponentColumnComponent } from './component-column/component-column.component';

/**
 * A component grid. Takes [grid] as input (of type CLGrid).
 * This grid has columns, and each column has a tile, where a tile is generally a list of related data such as markers or trains.
 * Only one tile can be viewed at a time.
 *
 * The input grid is a nested data structure containing columns which contain tiles. These tiles include a component type reference.
 * This type reference is the important part - your grid will automatically place this component inside the tile.
 * So your implementation should be a component (extending GridTileComponent) which you pass a reference to via here.
 *
 * NOTE that currently a limitation is that we support exactly and only 4 columns.
 *
 * Developer details for anyone extending this functionality (if you just need to use it, you probably don't need to read on):
 * ComponentGridComponent has ComponentColumnComponent children.
 * ComponentColumnComponent has ComponentTileComponent children.
 * ComponentTileComponent will render the component you supplied (via the grid input), which should extend GridTileComponent.
 * This component (typically) should just contain <oksygen-component-group>YOUR TILE CONTENT HERE</oksygen-component-group>
 * You don't actually need to use the componentGroup, but it's helpful in setting up your content as searchable expansion panel.
 * Generally, YOUR TILE CONTENT HERE should be your searchable list.
 */
@Component({
  selector: 'oksygen-component-grid',
  templateUrl: './component-grid.component.html',
  styleUrls: ['./component-grid.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    ComponentColumnComponent
]
})
export class ComponentGridComponent {
  public readonly grid = input.required<CLGrid>();

  constructor() {}
}
