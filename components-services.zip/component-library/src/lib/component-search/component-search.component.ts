/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule, Sorter } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

/**
 * Just renders a simple title & icon in the mat expansion header of a component group.
 * This is internal to the ComponentGroup system, which is itself internal to the ComponentGridComponent system.
 * For general usage information, please refer to ComponentGridComponent.
 * NOTE implentation not done - only styles complete.
 */
@Component({
  selector: 'oksygen-component-search',
  templateUrl: './component-search.component.html',
  styleUrls: ['./component-search.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule
]
})
export class ComponentSearchComponent {
  public readonly filterGroups = input.required<Array<string>>();
  sorter = new Sorter<any>();
  selectedfilterGroups: Array<string> = [];

  constructor() {}

  clearGroupFilters(): void {}

  filterByGroup(typeGroup: string): void {}

  removeTypeGroupFilter(type: string): void {}

  onSearchKey(search: string): void {}
}
