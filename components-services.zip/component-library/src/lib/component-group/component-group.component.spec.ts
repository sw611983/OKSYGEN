/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ComponentGroupHeaderComponent } from './component-group-header/component-group-header.component';
import { ComponentGroupComponent } from './component-group.component';

describe('ComponentGroupComponent', () => {
  let component: ComponentGroupComponent;
  let fixture: ComponentFixture<ComponentGroupComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [ComponentGroupHeaderComponent, ComponentGroupComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentGroupComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('title', 'title');
    fixture.componentRef.setInput('icon', OksygenIcon.CLOCK);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
