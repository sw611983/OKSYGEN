/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, input, viewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

import { ComponentGroupHeaderComponent } from './component-group-header/component-group-header.component';
import { MatExpansionPanel } from '@angular/material/expansion';

@Component({
  selector: 'oksygen-component-group',
  templateUrl: './component-group.component.html',
  styleUrls: ['./component-group.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    ComponentGroupHeaderComponent
]
})
export class ComponentGroupComponent {
  public readonly title = input.required<string>();
  public readonly icon = input<string | undefined>(undefined);
  public readonly expandable = input<boolean>(false);

  private readonly panel = viewChild.required<MatExpansionPanel>('panel');

  expanded = true;

  constructor() {}

  close(): void {
    if (!this.expandable()) {
      this.panel().open();
    }
  }
}
