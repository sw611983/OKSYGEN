/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

/**
 * Just renders a simple title & icon in the mat expansion header of a component group.
 * This is internal to the ComponentGroup system, which is itself internal to the ComponentGridComponent system.
 * For general usage information, please refer to ComponentGridComponent.
 */
@Component({
  selector: 'oksygen-component-group-header',
  templateUrl: './component-group-header.component.html',
  styleUrls: ['./component-group-header.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule
]
})
export class ComponentGroupHeaderComponent {
  public readonly title = input.required<string>();
  public readonly icon = input.required<string>();

  constructor() {}
}
