/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ComponentGroupHeaderComponent } from './component-group-header.component';

describe('ComponentGroupHeaderComponent', () => {
  let component: ComponentGroupHeaderComponent;
  let fixture: ComponentFixture<ComponentGroupHeaderComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [ComponentGroupHeaderComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentGroupHeaderComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('title', 'title');
    fixture.componentRef.setInput('icon', OksygenIcon.CLOCK);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
