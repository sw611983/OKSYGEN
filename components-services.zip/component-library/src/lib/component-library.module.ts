/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

import { ComponentColumnComponent } from './component-grid/component-column/component-column.component';
import { ComponentTileComponent } from './component-grid/component-column/component-tile/component-tile.component';
import { ComponentGridComponent } from './component-grid/component-grid.component';
import { ComponentGroupHeaderComponent } from './component-group/component-group-header/component-group-header.component';
import { ComponentGroupComponent } from './component-group/component-group.component';
import { ComponentSearchComponent } from './component-search/component-search.component';

// import { SharedModule } from '../../shared.module';

export const components = [
  ComponentGridComponent,
  ComponentColumnComponent,
  ComponentTileComponent,
  ComponentGroupHeaderComponent,
  ComponentGroupComponent,
  ComponentSearchComponent
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule.forChild(),
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    components
  ],
  exports: components
})
export class OksygenSimTrainComponentLibraryModule {}
