/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';

import { ComponentLibraryAssessmentCriteriaComponent } from './components/assessment-criteria/assessment-criteria.component';
import { ComponentLibraryTabComponent } from './components/component-library-tab/component-library-tab.component';
import { ComponentLibraryDriverComponent } from './components/driver/driver.component';
import { ComponentLibraryMultimediaComponent } from './components/multimedia/multimedia.component';
import { ComponentLibraryObjectComponent } from './components/object/object.component';
import { ComponentLibraryRuleComponent } from './components/rule/rule.component';
import { ComponentLibraryTrainComponent } from './components/train/train.component';

export const components = [
  ComponentLibraryDriverComponent,
  ComponentLibraryMultimediaComponent,
  ComponentLibraryObjectComponent,
  ComponentLibraryRuleComponent,
  ComponentLibraryTrainComponent,
  ComponentLibraryTabComponent,
  ComponentLibraryAssessmentCriteriaComponent
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule.forChild(),
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    ...components
  ],
  exports: [...components]
})
export class OksygenSimTrainComponentLibraryComponentsModule {}
