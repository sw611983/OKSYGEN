/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { BehaviorSubject, Subscription } from 'rxjs';

import { filterTruthy, shareReplayOne } from '@oksygen-common-libraries/common';
import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule, UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { MultimediaDataItem, MultimediaDataService } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { OksygenSimTrainCommonModule, TRAINS } from '@oksygen-sim-train-libraries/components-services/common';
import { CLGrid, CLTile, OksygenSimTrainComponentLibraryModule } from '@oksygen-sim-train-libraries/components-services/component-library';
import { OksygenSimTrainRuleEditModule } from '@oksygen-sim-train-libraries/components-services/editors/rules';
import { OksygenSimTrainObjectsModule } from '@oksygen-sim-train-libraries/components-services/objects';
import { ObjectTypeContainer, ObjectTypeDataService, OksygenSimTrainObjectServicesModule } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RobotDriverService } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { OksygenSimTrainRuleModule, RuleTemplate, RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';
import { Consist, ConsistDataService, OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';

import { ComponentLibraryDriverComponent } from '../driver/driver.component';
import { DriverData } from '../driver/driver.model';
import { ComponentLibraryMultimediaComponent } from '../multimedia/multimedia.component';
import { ComponentLibraryObjectComponent } from '../object/object.component';
import { ComponentLibraryRuleComponent } from '../rule/rule.component';
import { ComponentLibraryTrainComponent } from '../train/train.component';

@Component({
  selector: 'oksygen-component-library-tab',
  templateUrl: './component-library-tab.component.html',
  styleUrls: ['./component-library-tab.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    OksygenSimTrainTrainsModule,
    OksygenSimTrainObjectsModule,
    OksygenSimTrainObjectServicesModule,
    OksygenSimTrainRuleEditModule,
    OksygenSimTrainRuleModule,
    OksygenSimTrainComponentLibraryModule
  ]
})
export class ComponentLibraryTabComponent implements OnInit, OnDestroy {
  @Input() uiModels!: UiStateModelManager;
  readonly TRUE = 'true';

  grid: CLGrid;

  private masterSubscription = new Subscription();

  private driversSubject = new BehaviorSubject<Array<DriverData>>([]);
  private consistsSubject = new BehaviorSubject<Array<Consist>>([]);
  private ruleTemplatesSubject = new BehaviorSubject<Array<RuleTemplate>>([]);
  private objectsSubject = new BehaviorSubject<Array<ObjectTypeContainer>>([]);
  private multimediaSubject = new BehaviorSubject<Array<MultimediaDataItem>>([]);

  constructor(
    private consistService: ConsistDataService,
    private objectTypeService: ObjectTypeDataService,
    private multimediaDataService: MultimediaDataService,
    private ruleTemplateService: RuleTemplateService,
    private robotDriverService: RobotDriverService
  ) {}

  ngOnInit(): void {
    this.masterSubscription.add(
      this.robotDriverService
        .data()
        .pipe(filterTruthy())
        .subscribe(robotDrivers =>
          this.driversSubject.next([
            //FIXME: Currently id need to be guid
            { type: DriverType.HUMAN, name: t('Human'), id: '' },
            ...robotDrivers.map(rd => ({ type: DriverType.ROBOT, name: rd.name, id: rd.id }))
          ])
        )
    );

    this.masterSubscription.add(
      this.consistService
        .data()
        .pipe(filterTruthy())
        .subscribe(consists => this.consistsSubject.next(consists.filter(tr => !!tr.trainType?.dllName)))
    );

    this.masterSubscription.add(
      this.objectTypeService
        .placementTypes$()
        .pipe(filterTruthy())
        .subscribe(objects => this.objectsSubject.next(Array.from(objects.values())))
    );

    this.masterSubscription.add(
      this.multimediaDataService
        .data()
        .pipe(filterTruthy())
        .subscribe(multimedia => this.multimediaSubject.next(multimedia))
    );

    this.masterSubscription.add(
      this.ruleTemplateService
        .latestVersionData()
        .pipe(filterTruthy())
        .subscribe(ruleTemplates => this.ruleTemplatesSubject.next(ruleTemplates))
    );

    this.configureGrid();
  }

  ngOnDestroy(): void {
    this.masterSubscription.unsubscribe();
    this.driversSubject.complete();
    this.consistsSubject.complete();
    this.ruleTemplatesSubject.complete();
    this.objectsSubject.complete();
    this.multimediaSubject.complete();
  }

  refresh(): void {
    this.consistService.reloadData();
    this.multimediaDataService.reloadData();
    this.objectTypeService.reloadData();
  }

  configureGrid(): void {
    const simulatedTrains = new CLTile(ComponentLibraryTrainComponent, {
      title: TRAINS,
      icon: OksygenIcon.TRAIN,
      consists$: this.consistsSubject.pipe(shareReplayOne()),
      uiModels: this.uiModels
    });
    const drivers = new CLTile(ComponentLibraryDriverComponent, {
      drivers$: this.driversSubject.pipe(shareReplayOne()),
      uiModels: this.uiModels
    });

    const rules = new CLTile(ComponentLibraryRuleComponent, {
      ruleTemplates$: this.ruleTemplatesSubject.pipe(shareReplayOne()),
      uiModels: this.uiModels
    });
    const objects = new CLTile(ComponentLibraryObjectComponent, {
      objects$: this.objectsSubject.pipe(shareReplayOne()),
      uiModels: this.uiModels
    });
    const multimedia = new CLTile(ComponentLibraryMultimediaComponent, {
      multimedia$: this.multimediaSubject.pipe(shareReplayOne()),
      uiModels: this.uiModels
    });
    this.grid = {
      columns: [
        {
          tiles: [
            simulatedTrains,
            drivers,
            rules,
            objects,
            multimedia
            // TODO faults
          ]
        }
      ]
    };
  }
}
