/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ComponentLibraryRuleComponent } from './rule.component';

describe('ComponentLibraryRuleComponent', () => {
  let component: ComponentLibraryRuleComponent;
  let fixture: ComponentFixture<ComponentLibraryRuleComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [ComponentLibraryRuleComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentLibraryRuleComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('ruleTemplates$', of([]));
    fixture.componentRef.setInput('uiModels', new UiStateModelManager());
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
