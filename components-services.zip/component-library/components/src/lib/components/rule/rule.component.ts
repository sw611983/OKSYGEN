/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule, UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import {
  GridTileComponent,
  OksygenSimTrainComponentLibraryModule
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { OksygenSimTrainRuleEditModule } from '@oksygen-sim-train-libraries/components-services/editors/rules';
import { OksygenSimTrainRuleModule, RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';

type RuleDataType = {
  ruleTemplates$: Observable<Array<RuleTemplate>>;
  uiModels: UiStateModelManager;
}; // FIXME when we decide which data type to supply here

@Component({
  selector: 'oksygen-component-library-rule-component',
  templateUrl: './rule.component.html',
  styleUrls: ['./rule.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    OksygenSimTrainRuleEditModule,
    OksygenSimTrainRuleModule,
    OksygenSimTrainComponentLibraryModule
]
})
export class ComponentLibraryRuleComponent implements GridTileComponent<RuleDataType> {
  public readonly ruleTemplates$ = input.required<Observable<Array<RuleTemplate>>>();
  public readonly uiModels = input.required<UiStateModelManager>();
  public readonly expandable = input<boolean>(true);

  data: RuleDataType; // dummy, to fulfil GridTileComponent

  constructor() {}
}
