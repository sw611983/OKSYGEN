/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule, UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import {
  OksygenSimTrainAssessmentCriteriaModule,
  ReportItemGroup
} from '@oksygen-sim-train-libraries/components-services/assessment-criteria';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { ComponentGroupComponent, GridTileComponent } from '@oksygen-sim-train-libraries/components-services/component-library';

type AssessmentCriteriaComponentData = {
  assessmentCriteriaGroupItems$: Observable<Array<ReportItemGroup>>;
  uiModels: UiStateModelManager;
  expandable?: boolean;
};

@Component({
  selector: 'oksygen-component-library-assessment-criteria-component',
  templateUrl: './assessment-criteria.component.html',
  styleUrls: ['./assessment-criteria.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    OksygenSimTrainAssessmentCriteriaModule,
    ComponentGroupComponent
]
})
export class ComponentLibraryAssessmentCriteriaComponent implements GridTileComponent<AssessmentCriteriaComponentData> {
  public readonly assessmentCriteriaGroupItems$ = input.required<Observable<Array<ReportItemGroup>>>();
  public readonly uiModels = input.required<UiStateModelManager>();
  public readonly expandable = input<boolean>(false);

  data: AssessmentCriteriaComponentData; // dummy, to fulfil GridTileComponent

  constructor() {}
}
