/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainAssessmentCriteriaModule } from '@oksygen-sim-train-libraries/components-services/assessment-criteria';
import {
  ComponentGridComponent,
  ComponentGroupComponent,
  ComponentGroupHeaderComponent
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ComponentLibraryAssessmentCriteriaComponent } from './assessment-criteria.component';

describe('ComponentLibraryAssessmentCriteriaComponent', () => {
  let component: ComponentLibraryAssessmentCriteriaComponent;
  let fixture: ComponentFixture<ComponentLibraryAssessmentCriteriaComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [
        OksygenSimTrainAssessmentCriteriaModule,
        ComponentLibraryAssessmentCriteriaComponent,
        ComponentGroupComponent,
        ComponentGroupHeaderComponent,
        ComponentGridComponent
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentLibraryAssessmentCriteriaComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('assessmentCriteriaGroupItems$', of([]));
    fixture.componentRef.setInput('uiModels', new UiStateModelManager());
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
