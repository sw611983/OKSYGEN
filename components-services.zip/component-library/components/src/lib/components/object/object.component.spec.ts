/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import {
  ComponentGridComponent,
  ComponentGroupComponent,
  ComponentGroupHeaderComponent
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { ObjectTypeListComponent } from '@oksygen-sim-train-libraries/components-services/objects';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { ConsistListItemComponent, DriverListItemComponent } from '@oksygen-sim-train-libraries/components-services/trains';

import { ComponentLibraryObjectComponent } from './object.component';

describe('ComponentLibraryObjectComponent', () => {
  let component: ComponentLibraryObjectComponent;
  let fixture: ComponentFixture<ComponentLibraryObjectComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [ObjectTypeListComponent, ConsistListItemComponent, DriverListItemComponent],
      imports: [ComponentLibraryObjectComponent, ComponentGroupComponent, ComponentGroupHeaderComponent, ComponentGridComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentLibraryObjectComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('objects$', of([]));
    fixture.componentRef.setInput('uiModels', new UiStateModelManager());
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
