/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, effect, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs';

import { Filter, OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule, UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import {
  GridTileComponent,
  OksygenSimTrainComponentLibraryModule
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { ObjectTypeListFilterType, OksygenSimTrainObjectsModule } from '@oksygen-sim-train-libraries/components-services/objects';
import { ObjectTypeContainer, OksygenSimTrainObjectServicesModule } from '@oksygen-sim-train-libraries/components-services/objects/data';

type ObjectComponentData = {
  objects$: Observable<Array<ObjectTypeContainer>>;
  uiModels: UiStateModelManager;
};

@Component({
  selector: 'oksygen-component-library-object-component',
  templateUrl: './object.component.html',
  styleUrls: ['./object.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    OksygenSimTrainObjectsModule,
    OksygenSimTrainObjectServicesModule,
    OksygenSimTrainComponentLibraryModule
]
})
export class ComponentLibraryObjectComponent implements GridTileComponent<ObjectComponentData> {
  public readonly objects$ = input.required<Observable<Array<ObjectTypeContainer>>>();
  public readonly uiModels = input.required<UiStateModelManager>();
  public readonly expandable = input<boolean>(true);

  data: ObjectComponentData; // dummy, to fulfil GridTileComponent
  objectTypes: ObjectTypeContainer[];
  filterObjectTypes: Array<Filter<ObjectTypeListFilterType>>;

  constructor() {
    effect(onCleanup => {
      const subscription = this.objects$().subscribe(objects => {
        this.objectTypes = Array.from(objects.values())
          .filter(ot => ot.placementRules?.placeable ?? true)
          .map(o => o);
        this.filterObjectTypes = objects
          .map(o => o.group.name)
          .reduce((uniqueTypes, type) => {
            if (!uniqueTypes.includes(type)) {
              uniqueTypes.push(type);
            }
            return uniqueTypes;
          }, [])
          .map(uniqueType => new Filter(ObjectTypeListFilterType.OBJECT_TYPE_GROUP, uniqueType));
      });

      onCleanup(() => {
        subscription?.unsubscribe();
      });
    });
  }
}
