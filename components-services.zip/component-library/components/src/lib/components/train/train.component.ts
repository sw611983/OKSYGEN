/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, effect, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs';

import { Filter, OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule, UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import {
  GridTileComponent,
  OksygenSimTrainComponentLibraryModule
} from '@oksygen-sim-train-libraries/components-services/component-library';
import {
  Consist,
  ConsistListItem,
  ConsistTypeListFilterType,
  OksygenSimTrainTrainsModule
} from '@oksygen-sim-train-libraries/components-services/trains';

type TrainDataType = {
  title: string;
  icon: string;
  consists$: Observable<Array<Consist>>;
  uiModels: UiStateModelManager;
};

@Component({
  selector: 'oksygen-component-library-train-component',
  templateUrl: './train.component.html',
  styleUrls: ['./train.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    OksygenSimTrainTrainsModule,
    OksygenSimTrainComponentLibraryModule
]
})
export class ComponentLibraryTrainComponent implements GridTileComponent<TrainDataType> {
  public readonly title = input.required<string>();
  public readonly icon = input.required<string>();
  public readonly consists$ = input.required<Observable<Array<Consist>>>();
  public readonly uiModels = input.required<UiStateModelManager>();
  public readonly expandable = input<boolean>(true);

  data: TrainDataType; // dummy, to fulfil GridTileComponent
  consistList: Array<ConsistListItem>;
  filterConsistType: Array<Filter<ConsistTypeListFilterType>>;

  constructor() {
    effect(onCleanup => {
      const subscription = this.consists$().subscribe(consists => {
        this.consistList = consists.map(consist => ({ consist }));
        this.filterConsistType = consists
          .map(consist => consist.trainType.name)
          .reduce((uniqueTypes, type) => {
            if (!uniqueTypes.includes(type)) {
              uniqueTypes.push(type);
            }
            return uniqueTypes;
          }, [])
          .map(uniqueType => new Filter(ConsistTypeListFilterType.CONSIST_TYPE_GROUP, uniqueType));
      });

      onCleanup(() => {
        subscription?.unsubscribe();
      });
    });
  }
}
