/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import {
  ComponentGridComponent,
  ComponentGroupComponent,
  ComponentGroupHeaderComponent
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { ConsistListComponent, ConsistListItemComponent } from '@oksygen-sim-train-libraries/components-services/trains';

import { ComponentLibraryTrainComponent } from './train.component';

describe('ComponentLibraryTrainComponent', () => {
  let component: ComponentLibraryTrainComponent;
  let fixture: ComponentFixture<ComponentLibraryTrainComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [ConsistListComponent, ConsistListItemComponent],
      imports: [ComponentLibraryTrainComponent, ComponentGroupComponent, ComponentGroupHeaderComponent, ComponentGridComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentLibraryTrainComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('title', 'test');
    fixture.componentRef.setInput('icon', 'test');
    fixture.componentRef.setInput('consists$', of([]));
    fixture.componentRef.setInput('uiModels', new UiStateModelManager());
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
