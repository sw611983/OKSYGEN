/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';

export interface DriverData {
  id?: string;
  type: DriverType;
  name: string;
}
