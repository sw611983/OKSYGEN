/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, effect, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs';

import { Filter, OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule, UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import {
  GridTileComponent,
  OksygenSimTrainComponentLibraryModule
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { OksygenSimTrainRobotDriversModule } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import {
  DriverListItem,
  DriverTypeListFilterType,
  OksygenSimTrainTrainsModule
} from '@oksygen-sim-train-libraries/components-services/trains';

import { DriverData } from './driver.model';

type DriverComponentData = {
  drivers$: Observable<Array<DriverData>>;
  uiModels: UiStateModelManager;
};

@Component({
  selector: 'oksygen-component-library-driver-component',
  templateUrl: './driver.component.html',
  styleUrls: ['./driver.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    OksygenSimTrainTrainsModule,
    OksygenSimTrainRobotDriversModule,
    OksygenSimTrainComponentLibraryModule
]
})
export class ComponentLibraryDriverComponent implements GridTileComponent<DriverComponentData> {
  public readonly drivers$ = input.required<Observable<Array<DriverData>>>();
  public readonly uiModels = input.required<UiStateModelManager>();
  public readonly expandable = input<boolean>(true);

  data: DriverComponentData; // dummy, to fulfil GridTileComponent
  driverList: Array<DriverListItem>;

  filterDriverType: Array<Filter<DriverTypeListFilterType>>;

  constructor() {
    effect(onCleanup => {
      const subscription = this.drivers$().subscribe(drivers => {
        this.driverList = drivers.map(driver => ({ driver: { ...driver } }));
        this.filterDriverType = drivers
        .map(driver => driver.type)
        .reduce((uniqueTypes, type) => {
          if (!uniqueTypes.includes(type)) {
            uniqueTypes.push(type);
          }
          return uniqueTypes;
        }, [])
        .map(uniqueType => new Filter(DriverTypeListFilterType.DRIVER_TYPE_GROUP, uniqueType));
      });

      onCleanup(() => {
        subscription?.unsubscribe();
      });
    });
  }
}
