/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';

import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import {
  ComponentGridComponent,
  ComponentGroupComponent,
  ComponentGroupHeaderComponent
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';

import { ComponentLibraryDriverComponent } from './driver.component';

describe('ComponentLibraryDriverComponent', () => {
  let component: ComponentLibraryDriverComponent;
  let fixture: ComponentFixture<ComponentLibraryDriverComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainTrainsModule, ComponentLibraryDriverComponent, ComponentGroupComponent, ComponentGroupHeaderComponent, ComponentGridComponent]
    }).compileComponents();

    const translateService = TestBed.inject(TranslateService);
    translateService.addLangs(['en_AU']);
    translateService.setDefaultLang('en_AU');
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentLibraryDriverComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('drivers$', of([
      { type: DriverType.HUMAN, name: 'Human' },
      { type: DriverType.ROBOT, name: 'Robot' }
    ]));
    fixture.componentRef.setInput('uiModels', new UiStateModelManager());
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
