/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';

import { Component, input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule, UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { MultimediaDataItem } from '@oksygen-sim-core-libraries/components-services/multimedia';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import {
  GridTileComponent,
  OksygenSimTrainComponentLibraryModule
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { OksygenSimTrainMultimediaModule } from '@oksygen-sim-train-libraries/components-services/multimedia';

type LmsMultimediaDataType = {
  multimedia$: Observable<MultimediaDataItem[]>;
  uiModels: UiStateModelManager;
};

@Component({
  selector: 'oksygen-component-library-multimedia-component',
  templateUrl: './multimedia.component.html',
  styleUrls: ['./multimedia.component.scss'],
  standalone: true,
  imports: [
    RouterModule,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    OksygenSimTrainCommonModule,
    OksygenSimTrainMultimediaModule,
    OksygenSimTrainComponentLibraryModule
]
})
export class ComponentLibraryMultimediaComponent implements GridTileComponent<LmsMultimediaDataType> {
  public readonly multimedia$ = input.required<Observable<MultimediaDataItem[]>>();
  public readonly uiModels = input.required<UiStateModelManager>();
  public readonly expandable = input<boolean>(true);

  data: LmsMultimediaDataType; // dummy, to fulfil GridTileComponent
  constructor() {}
}
