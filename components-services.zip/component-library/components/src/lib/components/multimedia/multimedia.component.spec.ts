/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import {
  ComponentGridComponent,
  ComponentGroupComponent,
  ComponentGroupHeaderComponent
} from '@oksygen-sim-train-libraries/components-services/component-library';
import { MultimediaDataListComponent, MultimediaDataListItemComponent } from '@oksygen-sim-train-libraries/components-services/multimedia';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ComponentLibraryMultimediaComponent } from './multimedia.component';

describe('ComponentLibraryMultimediaComponent', () => {
  let component: ComponentLibraryMultimediaComponent;
  let fixture: ComponentFixture<ComponentLibraryMultimediaComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [MultimediaDataListItemComponent, MultimediaDataListComponent],
      imports: [ComponentLibraryMultimediaComponent, ComponentGroupComponent, ComponentGroupHeaderComponent, ComponentGridComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentLibraryMultimediaComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('multimedia$', of([]));
    fixture.componentRef.setInput('uiModels', new UiStateModelManager());
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
