/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { isNil } from 'lodash';

import { ToolboxContainerTabsConfig } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';

import { ComponentLibraryAssessmentCriteriaComponent } from '../components/assessment-criteria/assessment-criteria.component';
import { ComponentLibraryDriverComponent } from '../components/driver/driver.component';
import { ComponentLibraryMultimediaComponent } from '../components/multimedia/multimedia.component';
import { ComponentLibraryObjectComponent } from '../components/object/object.component';
import { ComponentLibraryRuleComponent } from '../components/rule/rule.component';
import { ComponentLibraryTrainComponent } from '../components/train/train.component';

export function defaultScenarioEditorLibraryTabsConfig(additionalTabs?: ToolboxContainerTabsConfig): ToolboxContainerTabsConfig {
  const libraryTabs: ToolboxContainerTabsConfig = {
    startTabs: {
      simTrainsLibrary: {
        name: t('Sim Train Library'),
        icon: OksygenIcon.TRAIN,
        component: ComponentLibraryTrainComponent
      },
      driversLibrary: {
        name: t('Drivers Library'),
        icon: OksygenIcon.STEERING_WHEEL,
        component: ComponentLibraryDriverComponent
      },
      rulesLibrary: {
        name: t('Rules Library'),
        icon: OksygenIcon.RULE_EDITOR,
        component: ComponentLibraryRuleComponent
      },
      objectsLibrary: {
        name: t('Objects Library'),
        icon: OksygenIcon.OBJECT,
        component: ComponentLibraryObjectComponent
      },
      multimediaLibrary: {
        name: t('Multimedia Library'),
        icon: OksygenIcon.MULTIMEDIA,
        component: ComponentLibraryMultimediaComponent
      },
      assessmentCriteriaLibrary: {
        name: t('Assessment Criteria Library'),
        icon: OksygenIcon.TEST_ALT,
        component: ComponentLibraryAssessmentCriteriaComponent
      }
    }
  };

  if (!isNil(additionalTabs?.startTabs)) {
    libraryTabs.startTabs = { ...libraryTabs.startTabs, ...additionalTabs.startTabs };
  }

  if (!isNil(additionalTabs?.endTabs)) {
    libraryTabs.endTabs = { ...libraryTabs.endTabs, ...additionalTabs.endTabs };
  }

  return libraryTabs;
}
