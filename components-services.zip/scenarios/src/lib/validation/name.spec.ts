/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Scenario } from '../models/scenario-service.model';
import { collateScenarioNames } from './name';

describe('name', () => {
  it('should return a list containing the name of all the scenarios given', () => {
    const scenarios: Scenario[] = [
      { name: 'scenario1' } as unknown as Scenario,
      { name: 'scenario2' } as unknown as Scenario,
      { name: 'scenario3' } as unknown as Scenario
    ];
    const expected = ['scenario1', 'scenario2', 'scenario3'];
    const actual = collateScenarioNames(scenarios);
    expect(actual).toEqual(expected);
  });
});
