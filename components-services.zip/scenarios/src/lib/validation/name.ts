/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Scenario } from '../models/scenario-service.model';

export function collateScenarioNames(scenarios: Scenario[]): string[] {
  const scenarioNames: string[] = [];

  scenarios?.forEach(scenario => scenarioNames.push(scenario?.name));

  return scenarioNames;
}
