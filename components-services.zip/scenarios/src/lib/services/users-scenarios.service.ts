/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, combineLatest, Observable, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

import { filterTruthy, SelfCompletingObservable, shareReplayOne, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Instructor, Trainee, User, UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { LmsService } from '@oksygen-sim-core-libraries/components-services/lms';
import { UserScenarioMapping } from '../models/user-scenario-mapping.model';
import { Scenario } from '../models/scenario-service.model';
import { ScenarioService } from './scenario.service';

/**
 * Once created, this listens on userService and ScenarioService and updates when they update
 */
@Injectable()
export class UsersScenariosService implements OnDestroy {
  private mappingSubject = new BehaviorSubject<UserScenarioMapping>(null);

  private subscriptions = new Subscription();

  public scenarios: Scenario[] = [];

  constructor(private userService: UserService, private scenarioService: ScenarioService, private lmsService: LmsService) {
    this.subscriptions.add(
      combineLatest([
        scenarioService.data().pipe(filter(s => s && s.length > 0)),
        userService.ready$.pipe(filterTruthy()),
        this.lmsService.isReady$().pipe(takeOneTruthy())
      ]).subscribe(([scenarios, u, lms]) => {
        if (!!scenarios && !!u && !!lms) {
          this.scenarios = scenarios;
          this.reloadData(scenarios, [...userService.users]);
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  // TODO should use a cache eviction mechanism (e.g. comparing time of last update to latest)
  // to avoid unnecessary data transfer.
  /**
   * Request the data to be reloaded.
   * the data will be published to the data() Observable when the data is reloaded.
   */
  public reloadData(scenarios: Scenario[], users: User[]): void {
    this.lmsService.getUserScenariosMap(users).subscribe(map => {
      if (map?.size > 0) {
        const userSimUserIdScenarioIdMap = new Map<string, string[]>();
        const scenarioIdUserSimUserIdMap = new Map<string, string[]>();

        scenarios.forEach(scenario => scenarioIdUserSimUserIdMap.set(scenario.id, []));

        users.forEach(user => userSimUserIdScenarioIdMap.set(user.id, []));

        map.forEach((lmsScenarios, user) => {
          lmsScenarios.forEach(lmsScenario => {
            // In the LMS, scenarioId is refering to what we call id in the db, which is a GUID.
            const scenario = scenarios.find(s => s.id === lmsScenario.scenarioId);

            if (scenario) {
              userSimUserIdScenarioIdMap.get(user.id).push(scenario.id);
              scenarioIdUserSimUserIdMap.get(scenario.id).push(user.id);
            }
          });
        });

        this.mappingSubject.next({ userSimUserIdScenarioIdMap, scenarioIdUserSimUserIdMap });
      }
    });
  }

  public isInstructor(user: User): boolean {
    if(this.userService.instructors.find(us => us.id === user.id))
    {
      return true;
    }
    return false;
  }

  get mapping$(): Observable<UserScenarioMapping> {
    return this.mappingSubject.pipe(shareReplayOne());
  }

  getScenario(id: string): SelfCompletingObservable<Scenario> {
    return this.scenarioService.getScenario(id);
  }

  /**
   * @returns the trainee data as an array
   */
  get trainees(): ReadonlyArray<Trainee> {
    return this.userService.trainees;
  }

  /**
   * @returns the instructor data as an array
   */
  get instructors(): ReadonlyArray<Instructor> {
    return this.userService.instructors;
  }
  /**
   * @returns the user data as an array
   */
  get users(): ReadonlyArray<User> {
    return this.userService.users;
  }


}
