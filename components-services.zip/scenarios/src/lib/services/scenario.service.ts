/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { AbstractDataService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Observable } from 'rxjs';
import { Scenario } from '../models/scenario-service.model';

@Injectable()
export abstract class ScenarioService extends AbstractDataService<Scenario[]> {
  constructor(
    logging: Logging,
    registry: Registry,
    dataAccessService: DataAccessService
  ) {
    super(logging, registry, dataAccessService);
  }

  /**
   * Load the specified scenario from the database. TODO: caching mechanism.
   *
   * @param id the id of the scenario to get
   */
  public abstract getScenario(id: string): SelfCompletingObservable<Scenario>;
  /**
   * TODO: Remove this when scenarioId becomes completely redundant
   * Load the specified scenario from the database. TODO: caching mechanism.
   *
   * @param scenarioId the id of the scenario to get
   */
  public abstract getScenarioByScenarioId(scenarioId: number): SelfCompletingObservable<Scenario>;
  /**
   * Return a list of scenarios that are currently in use in a session (if any).
   */
  public abstract getActiveScenarios(): Observable<string[]>;
  public abstract getRawScenario(id: string): SelfCompletingObservable<any>;

}
