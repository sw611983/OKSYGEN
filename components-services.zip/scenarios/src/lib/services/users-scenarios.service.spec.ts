/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TestBed } from '@angular/core/testing';
import { UsersScenariosService } from './users-scenarios.service';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

describe('users scenario service', () => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  let service: UsersScenariosService;

  beforeEach(() => {
    configureSimTrainTestingModule({ providers: [UsersScenariosService] });
    service = TestBed.inject(UsersScenariosService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
