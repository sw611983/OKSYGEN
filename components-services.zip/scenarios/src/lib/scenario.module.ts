/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { CommonModule } from '@angular/common';
import { EnvironmentProviders, ModuleWithProviders, NgModule, Provider, Type } from '@angular/core';
import { isNil } from 'lodash';

import { ScenarioService } from './services/scenario.service';
import { SCENARIO_EDITOR_EXTENSIONS_TOKEN, ScenarioEditorExtensions } from './tokens/scenario.token';

export interface ScenarioModuleConfig {
  /**
   * A concrete implemention for scenario service to be used to load scenarios.
   * Generally you should provide ```ScenarioServiceImpl``` from scenarios/view here.
   */
  scenarioService?: Type<ScenarioService>;
  scenarioExtensions?: Type<ScenarioEditorExtensions>;
}

@NgModule({
  imports: [CommonModule]
})
export class OksygenSimTrainScenarioModule {
  /**
   * forRoot takes a config object containing an implementation of ```ScenarioService``` you would like to use.
   * Can also contain loader & saver methods for processing custom Scenario fields if your project has extended scenarios.
   *
   * @param config contains a class that implements ```ScenarioService``` the application should use
   */
  public static forRoot(config: ScenarioModuleConfig): ModuleWithProviders<OksygenSimTrainScenarioModule> {
    const providers: Provider | EnvironmentProviders = [];

    if (!isNil(config.scenarioService)) {
      providers.push({ provide: ScenarioService, useClass: config.scenarioService });
    }

    if (!isNil(config.scenarioExtensions)) {
      providers.push({ provide: SCENARIO_EDITOR_EXTENSIONS_TOKEN, useClass: config.scenarioExtensions });
    }

    return {
      ngModule: OksygenSimTrainScenarioModule,
      providers
    };
  }
}
