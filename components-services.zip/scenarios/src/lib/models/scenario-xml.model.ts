/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ParameterDefinitionValueType, SimPropertyValues, TitleVersionXml, TrainElementXml, XmlBooleanEnum } from '@oksygen-sim-train-libraries/components-services/common';
import { RuleTemplateReference } from '@oksygen-sim-train-libraries/components-services/rules';
import { TrainTypeEquipment } from './hardware-states-config.model';

export enum OrientationXmlEnum {
  FROM_ALPHA = 'From Alpha',
  FROM_BETA = 'From Beta',
  BOTH = 'Both'
}

export interface AddScenarioIdResponse {
  scenarioId: number;
}

export interface ScenarioTrainXml {
  $: {
    id: string;
    name: string;
    trainDescription: string;
    startSegmentName: string;
    startOffset: string;
    isHeadingAlpha: XmlBooleanEnum;
    isSimulated: XmlBooleanEnum;
    tripNumber: string;
  };
  simPropertyValues?: SimPropertyValues;
  trainElement?: TrainElementXml[];
}

export interface VirtualLocationVehicleXml {
  $: {
    locationType: string;
    description: string;
    hubMode: string;
    xOffset: string;
    yOffset: string;
    zOffset: string;
    headingOffset: string;
    pitchOffset: string;
    rollOffset: string;
    scenarioTrainName: string;
    locationName: string;
    vehicleIndex: string;
  };
}

export interface ScenarioTrainDriverXml {
  id: number;
  type: string;
  initialTrainAssociation: number;
  driverTemplateReference: DriverTemplateReferenceXml;
}

export interface DriverTemplateReferenceXml {
  id: string;
  version: string;
}

export interface EnvironmentXml {
  simPropertyValues: SimPropertyValues;
}

// TODO Remove legacy data definition
export interface ScenarioFeatureXml {
  $: {
    name: string;
    typeName: string;
    xCoord: number;
    yCoord: number;
    zCoord: number;
    heading: number;
    pitch: number;
    roll: number;
  };

  segmentPosition: Array<SegmentPositionXml>;

  featureProperty: Array<FeaturePropertyXml>;
}

// TODO Remove legacy data definition
export interface SegmentPositionXml {
  $: {
    segmentName: string;
    segmentOffset: number;
    orientationName: OrientationXmlEnum;
  };
}

// TODO Remove legacy data definition
export interface FeaturePropertyXml {
  $: {
    name: string;
    isTextValue: number;
    value: number | string;
  };
}

// TODO Confirm new data definition once we add support to C++ Data Access code
export interface ObjectXml {
  id: number;
  name: string;
  typeName: string;
  xCoord: number;
  yCoord: number;
  zCoord: number;
  heading: number;
  pitch: number;
  roll: number;

  segmentAssociations: SegmentAssociationsXml;

  properties: ObjectPropertiesXml;
}

// TODO Confirm new data definition once we add support to C++ Data Access code
export interface SegmentAssociationsXml {
  segmentAssociation: Array<SegmentAssociationXml>;
}

// TODO Confirm new data definition once we add support to C++ Data Access code
export interface SegmentAssociationXml {
  segmentName: string;
  segmentOffset: number;
  orientationName: OrientationXmlEnum;
}

// TODO Confirm new data definition once we add support to C++ Data Access code
export interface ObjectPropertiesXml {
  property: Array<ObjectPropertyXml>;
}

// TODO Confirm new data definition once we add support to C++ Data Access code
export interface ObjectPropertyXml {
  name: string;
  isTextValue: number; // FIXME This may be redundant since the Object Type describes this. If not, should this be a boolean?
  value: number | string;
}

export interface LinkedSegmentAssociationXml extends SegmentAssociationXml {
  /** Note that this should not be written to the database, but is automatically generated on read for convenience. */
  segmentId: number;
}

// TODO Confirm new data definition once we add support to C++ Data Access code
export interface ObjectsXml {
  object?: Array<ObjectXml>;
}

export interface RuleXml {
  $: {
    id: number;
  };

  ruleType?: string;
  displayName: string;
  description?: string;
  active: boolean;
  ruleTemplateReference: RuleTemplateReference;
}

export interface MoodleScormActivityXml {
  $: {
    name: string;
    multimediaId: string;
    ruleId: number;
  };
}

export interface MultimediaXml {
  moodleScormActivity: Array<MoodleScormActivityXml>;
}

export interface WorldXml {
  trackNetwork: TitleVersionXml;
  trackSkin: TrackSkinXml;
  signallingScheme: SignallingSchemeXml;
  objectModifications: ObjectModificationsXml;
  objects: ObjectsXml;
}

export interface TrackSkinXml {
  name: string;
}

export interface SignallingSchemeXml {
  name: string;
  version: string;
}

export interface ObjectModificationsXml {
  object: Array<ObjectModificationXml>;
}

export interface ObjectModificationXml {
  name: string;
  properties: ObjectPropertiesXml;
}

export interface ScenarioBaseInfoHistoryXml {
  $: {
    type: string;
    authorFirstName: string;
    authorLastName: string;
    scenarioName: string;
    scenarioVersion: string;
    timestamp: string;
  };
}

export interface ScenarioBaseInfoXml {
  $: {
    scenarioId?: string;
    version: string;
    type: string;
    scenarioDescription: string; // Note this is scenario name
    scenarioStartTime: string;
    scenarioIsCore: XmlBooleanEnum;
    tracknetworkName: string;
    tracknetworkSkinName: string;
    scenarioIsActive: XmlBooleanEnum;
  };

  history?: {
    historyLog: Array<ScenarioBaseInfoHistoryXml>;
  };
}

export interface ScenarioReportItemParameterXml {
  name: string;
  value: ParameterDefinitionValueType;
}

export interface ScenarioReportItemParametersXml {
  parameter: Array<ScenarioReportItemParameterXml>;
}

export interface ScenarioReportItemEventItemXml {
  name: string;
  parameters: ScenarioReportItemParametersXml;
}

export interface ScenarioReportItemEventsXml {
  event: Array<ScenarioReportItemEventItemXml>;
}

export interface ScenarioReportItemAssessmentParametersXml {
  assessmentParameter: Array<ScenarioReportItemParameterXml>;
}

export interface ScenarioReportItemReferenceXml {
  $: {
    name: string;
    version: string;
  };
  assessmentParameters: ScenarioReportItemAssessmentParametersXml;
  parameters: ScenarioReportItemParametersXml;
  events: ScenarioReportItemEventsXml;
}

export interface ScenarioReportItemXml {
  $: {
    id: number;
  };
  displayName: string;
  description: string;
  compulsory: boolean;
  reportItemReference: ScenarioReportItemReferenceXml;
}

export interface ScenarioReportDataXml {
  reportItem: Array<ScenarioReportItemXml>;
}

export interface ScenarioRuleVariablesXml {
  ruleVariable: Array<ScenarioRuleVariableXml>;
}

export interface ScenarioRuleVariableXml {
  $: {
    name: string;
    type: string;
    value: string | number | XmlBooleanEnum;
  };
}

export interface MeritDemeritXml {
  initialScore: number;
  targetScore: number;
}

export interface AssessmentTypeXml {
  meritDemerit?: MeritDemeritXml;
}

export interface AssessmentParameterXml {
  enabled: boolean;
  assessmentType: AssessmentTypeXml;
}

export interface AssessmentReportDataXml {
  assessmentItem: AssessmentParameterXml[];
}

export interface ScenarioXml {
  // N.B.  When adding any new fields to this class,
  // make sure you update the method createForKnownKeysHandling to create a non-null/non-undefined value for the new fields.
  // This is used to create a list of known XML fields, to not overwrite with from the raw XML from the DB, see handleUnknownXmlData

  id: string;
  baseInfo: ScenarioBaseInfoXml;

  displayDescription?: string;
  subject?: string;

  environment?: EnvironmentXml;

  scenarioTrain?: Array<ScenarioTrainXml>;

  scenarioTrainDriver?: Array<ScenarioTrainDriverXml>;

  virtualLocationVehicle?: Array<VirtualLocationVehicleXml>;

  scenarioFeature?: Array<ScenarioFeatureXml>;

  multimedia?: MultimediaXml;

  rule?: Array<RuleXml>;

  world?: WorldXml;

  assessment?: boolean;

  assessmentReport?: AssessmentReportDataXml;

  trainTypeEquipment?: TrainTypeEquipment;

  reportData?: ScenarioReportDataXml;

  ruleVariables?: ScenarioRuleVariablesXml;
}
/**
 * Creates a dummy Scenario Xml object, with all fields being a valid object, so that the for/in loop works
 */
export function scenarioXmlCreateForKnownKeysHandling(): ScenarioXml {
  const xml: ScenarioXml = {
    id: '',
    baseInfo: {} as any, // don't need to create a full object, just a non-null value
    displayDescription: '',
    subject: '',
    environment: {} as any, // don't need to create a full object, just a non-null value
    scenarioTrain: [],
    scenarioTrainDriver: [],
    virtualLocationVehicle: [],
    scenarioFeature: [],
    multimedia: {} as any, // don't need to create a full object, just a non-null value
    rule: [],
    world: {} as any, // don't need to create a full object, just a non-null value
    assessment: false,
    assessmentReport: {} as any,
    trainTypeEquipment: {} as any,
    reportData: {} as any,
    ruleVariables: {} as any
  };

  return xml;
}
