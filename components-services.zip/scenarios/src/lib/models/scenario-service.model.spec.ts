/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Scenario, scenarioSearchableText } from './scenario-service.model';

describe('scenario service model', () => {
  it('should return a scenario as a searchable text', () => {
    const scenario: Scenario = { name: 'great Scenario' } as unknown as Scenario;
    expect(scenarioSearchableText(scenario)).toEqual(['great Scenario']);
  });
});
