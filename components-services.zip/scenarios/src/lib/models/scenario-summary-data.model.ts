/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import moment from 'moment';

import {
  EditHistory,
  getLastModified,
  HISTORY_TYPE_COPIED,
  HISTORY_TYPE_CREATED,
  NO_NAME,
  NO_TYPE,
  PUBLISHED_STATUS,
  UNKNOWN
} from '@oksygen-common-libraries/common';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { EditorBrowserTableData, EditorBrowserTableStatus } from '@oksygen-sim-train-libraries/components-services/common';

import { Scenario } from './scenario-service.model';

export interface ScenarioSummaryData extends EditorBrowserTableData {
  id: string;
  description: string;
  world: string;
  // FIXME scenarios can have multiple simulated trains
  train: { name: string; type: string };
  version: string;
  scenarioIsActive: boolean;
}

export function scenarioToScenarioSummaryData(
  userService: UserService,
  scenario: Scenario,
  status: EditorBrowserTableStatus = PUBLISHED_STATUS
): ScenarioSummaryData {
  const tableData: ScenarioSummaryData = {
    id: scenario.id,
    name: scenario.name,
    description: scenario.scenarioDescription,
    world: scenario.tracknetworkName,
    train: null,
    created: null,
    modified: null,
    version: scenario.version?.toString(),
    status,
    scenarioIsActive: scenario?.scenarioIsActive ?? false
  };

  const simTrain = scenario.scenarioTrains.scenarioTrain.find(train => train.driverType === DriverType.HUMAN);

  if (simTrain) {
    tableData.train = {
      name: simTrain.name || NO_NAME,
      type: simTrain.trainType || simTrain.trainDescription || NO_TYPE
    };
  } else {
    tableData.train = {
      name: t('Not Found'),
      type: NO_TYPE
    };
  }

  let created = scenario.scenarioHistory.find(history => history.type === HISTORY_TYPE_CREATED);

  if (!created) {
    created = scenario.scenarioHistory.find(history => history.type === HISTORY_TYPE_COPIED);
  }

  // In case there's missing data...
  if (!created) {
    created = {
      type: HISTORY_TYPE_CREATED,
      authorFirstName: UNKNOWN,
      authorLastName: UNKNOWN,
      scenarioName: UNKNOWN,
      scenarioVersion: scenario.version,
      timestamp: UNKNOWN
    };
  }

  const modified: EditHistory = getLastModified(scenario.scenarioHistory);

  const creator = userService.users.find(u => u.firstName === created.authorFirstName && u.lastName === created.authorLastName);
  const modifier = userService.users.find(u => u.firstName === modified.authorFirstName && u.lastName === modified.authorLastName);

  tableData.created = {
    avatar: creator?.avatar,
    name: created.authorFirstName === UNKNOWN && created.authorLastName === UNKNOWN ? UNKNOWN : (created.authorFirstName + ' ' + created.authorLastName).trim(),
    date: !!created.timestamp && created.timestamp !== UNKNOWN ? moment(created.timestamp) : null
  };

  tableData.modified = {
    avatar: modifier?.avatar,
    name: modified.authorFirstName === UNKNOWN && modified.authorLastName === UNKNOWN ?
      UNKNOWN : (modified.authorFirstName + ' ' + modified.authorLastName).trim(),
    date: !!modified.timestamp && modified.timestamp !== UNKNOWN ? moment(modified.timestamp) : null
  };

  return tableData;
}
