/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Environment } from '@oksygen-sim-train-libraries/components-services/world-environment';

export enum ScenarioPreviewCamera {
  AERIAL = 'aerial',
  OBJECT = 'object',
  TRACK = 'track',
  TRAIN = 'train'
}

export enum PreviewVisionState {
  NOT_LOADED = 'not_loaded',
  LOADING = 'loading',
  LOADED = 'loaded',
  UNLOADING = 'unloading'
}

export interface FeatureAndAngle {
  featureId: number;
  angleInDegrees: number;
}

export interface EnvironmentData extends Environment {
  environmentShowInPreview: boolean;
}
