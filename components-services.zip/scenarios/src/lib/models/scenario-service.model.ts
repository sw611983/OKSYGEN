/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { cloneDeep } from 'lodash';

import { EditHistory } from '@oksygen-common-libraries/common';
import { IdName } from '@oksygen-sim-core-libraries/components-services/data-services';
import { ObjectModification } from '@oksygen-sim-core-libraries/data-types/objects';
import { asFreezableObjectType, ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { BaseRule } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioTrainDrivers, ScenarioTrains } from '@oksygen-sim-train-libraries/components-services/trains';
import { Environment } from '@oksygen-sim-train-libraries/components-services/world-environment';
import { TrainTypeEquipment } from './hardware-states-config.model';
import { ScenarioReportData } from '@oksygen-sim-train-libraries/components-services/assessment-criteria/scenario';
import { AssessmentReportDataXml } from './scenario-xml.model';
import { InitialConditionsTrains } from '@oksygen-sim-train-libraries/components-services/common';

export interface VirtualLocation {
  locationType: string;
  locationName: string;
  description: string;
  hubMode: string;
  xOffset: number;
  yOffset: number;
  zOffset: number;
  headingOffset: number;
  pitchOffset: number;
  rollOffset: number;
}

export interface VirtualLocationVehicle extends VirtualLocation {
  scenarioTrainName: string;
  vehicleIndex: number;
}

export interface VirtualLocationVehicles {
  virtualLocation: Array<VirtualLocationVehicle>;
}

export interface ScenarioHistory extends EditHistory {
  scenarioName: string;
  scenarioVersion: number;
}

export interface ScenarioMoodleScormActivity {
  name: string;
  multimediaId: string;
  ruleId: number;
}

export interface ScenarioMultimedia {
  moodleScormActivity?: ScenarioMoodleScormActivity;
  isFavourite?: boolean;
}

export interface ScenarioRule extends BaseRule {
  ruleType?: string;
  active?: boolean;
}

export interface ScenarioWorld {
  trackNetwork?: ScenarioWorldTrackNetwork;
  trackSkin?: ScenarioWorldTrackSkin;
  signallingScheme?: ScenarioWorldSignallingScheme;
  /** Modifications to apply to Track Objects. */
  objectModification?: Array<ObjectModification>;
  /** Objects defined by the Scenario. */
  object?: Array<ObjectContainer>;
}

export interface ScenarioWorldTrackNetwork {
  title: string;
  version: string;
}

export interface ScenarioWorldTrackSkin {
  name: string;
}

export interface ScenarioWorldSignallingScheme {
  name: string;
  version: string;
}

export interface ScenarioRuleVariable{
  name: string;
  type: string;
  value: number | boolean | string;
}

export enum RuleVariableTypes {
  NUMBER = 'number',
  STRING = 'string',
  BOOLEAN = 'boolean'
}


// TODO We will need a lighter version of this for scenario lists and such,
// so we're not always loading a large amount of data that we don't actually care about.
// The summary interface may end up being a sub-interface of this one.
export interface Scenario {
  id: string; // UUID
  /** @deprecated only use this when dealing with live sessions, use the id (UUID) otherwise */
  scenarioId: number;
  name: string;
  type: string;
  scenarioType: IdName;
  version: number;
  scenarioHistory: Array<ScenarioHistory>;
  scenarioDescription: string;
  /** The intended learning outcome of this scenario. */
  subject: string;
  world: ScenarioWorld;
  tracknetworkName: string;
  tracknetworkSkinName: string;
  scenarioStartTime: string;
  scenarioIsCore: boolean;
  environment?: Environment;
  scenarioTrains: ScenarioTrains;
  scenarioTrainDrivers: ScenarioTrainDrivers;
  virtualLocations?: VirtualLocationVehicles;
  multimedia?: Array<ScenarioMultimedia>;
  rule?: Array<ScenarioRule>;
  assessment?: boolean;
  initialScore?: number;
  targetScore?: number;
  trainTypeEquipment?: TrainTypeEquipment;
  initialConditionsTrains?: InitialConditionsTrains;
  scenarioIsActive?: boolean;
  reportData?: Array<ScenarioReportData>;
  assessmentData?: Array<AssessmentReportDataXml>;
  ruleVariables?: Array<ScenarioRuleVariable>;
}

export function scenarioSearchableText(scenario: Scenario): Array<string> {
  // TODO Will probably need to include more stuff
  return [scenario.name.toString()];
}

export interface Scenarios {
  scenario: Array<Scenario>;
}

// FIXME Only here as a workaround for INTOSC-8421
export function asFreezableScenario(scenario: Scenario): Scenario {
  if (!scenario) return scenario;
  const result: Scenario = cloneDeep(scenario);
  result.world.object = result.world.object.map(o => {
    const objectType = asFreezableObjectType(o.objectType);
    return { ...o, objectType, states: objectType.states, selectedIcon: null, selectedState: objectType.states.get(o.selectedState?.id) };
  });
  return result;
}
