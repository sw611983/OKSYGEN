/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export interface UserScenarioMapping {
  userSimUserIdScenarioIdMap: Map<string, string[]>;

  scenarioIdUserSimUserIdMap: Map<string, string[]>;
}
