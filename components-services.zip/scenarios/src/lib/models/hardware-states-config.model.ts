/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export interface TrainTypeEquipment {
  scenarioTrainId: number;
  equipmentTypes: EquipmentType;
}

export interface EquipmentType {
  equipmentType: EquipmentTypeData[];
}

export interface EquipmentTypeData {
  name: string;
  displayName: string;
  equipmentState: EquipmentState;
}

export interface EquipmentState {
  stateName: string;
  displayName: string;
}
