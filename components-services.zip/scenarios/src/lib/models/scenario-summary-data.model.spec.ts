/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { PUBLISHED_STATUS } from '@oksygen-common-libraries/common';
import { Scenario } from './scenario-service.model';
import { scenarioToScenarioSummaryData } from './scenario-summary-data.model';
import moment from 'moment';

describe('scenario summary data model', () => {
  it('should convert a scenario into a scenario summary data', () => {
    const userData = { users: [] } as any;
    const scenario: Scenario = {
      id: '1',
      name: 'great scenario',
      scenarioDescription: 'scenario description',
      tracknetworkName: 'track network name',
      scenarioTrains: { scenarioTrain: [{ driverType: 'Human', name: 'train name', trainType: 'train type', trainDescription: 'train description' }] },
      scenarioHistory: [
        { type: 'Created', timestamp: '2021-01-01', authorFirstName: 'Bob', authorLastName: 'Dylan', scenarioName: 'scenario name', scenarioVersion: 1 }
      ],
      version: 1
    } as unknown as Scenario;
    const scenarioSummaryData = scenarioToScenarioSummaryData(userData, scenario);
    expect(scenarioSummaryData).toEqual({
      id: '1',
      name: 'great scenario',
      description: 'scenario description',
      world: 'track network name',
      train: { name: 'train name', type: 'train type' },
      scenarioIsActive: false,
      created: {
        avatar: undefined,
        name: 'Bob Dylan',
        date: moment('2021-01-01')
      },
      modified: { avatar: undefined, name: 'Bob Dylan', date: moment('2021-01-01') },
      version: '1',
      status: PUBLISHED_STATUS
    });
  });
});
