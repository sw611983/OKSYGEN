/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { IdName, Track } from '@oksygen-sim-core-libraries/components-services/data-services';

import { Scenario } from './scenario-service.model';

export enum ScenarioEditType {
  VIEW,
  EDIT,
  CREATE
}

export interface ScenarioDetailsData {
  scenario?: Scenario;
  tracks?: Track[];
  editType: ScenarioEditType;
}

export interface ScenarioDetailsResultData {
  name: string;
  startTime: string;
  description: string;
  track: Track;
  appearance: IdName;
}
