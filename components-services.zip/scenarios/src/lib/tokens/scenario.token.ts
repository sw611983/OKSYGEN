/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { InjectionToken } from '@angular/core';

import { DragFeedback } from '@oksygen-common-libraries/common';

import { Scenario } from '../models/scenario-service.model';
import { ScenarioXml } from '../models/scenario-xml.model';

export const SCENARIO_EDITOR_EXTENSIONS_TOKEN = new InjectionToken<ScenarioEditorExtensions>('SCENARIO_EDITOR_EXTENSIONS_TOKEN');

/**
 * Mechanism to provide additional details from the project.
 */
export abstract class ScenarioEditorExtensions<S extends Scenario = Scenario, X extends ScenarioXml = ScenarioXml, A = any> {
  /**
   * This will return the top level field names that are loaded/saved by this class
   */
  public scenarioAdditionalFields: Array<string> = [];

  /**
   * Process any additional fields on a scenario when loading it from the database.
   * This method is expected to modify the input scenario data.
   * Useful if project side a scenario has some additional data.
   */
  public loadScenarioAdditionalFields(scenarioXml: X, scenario: S): void {}

  /**
   * Process any additional fields on a scenario in preparation for saving it.
   * Returns an object with just the additional fields so Oksygen can merge with the Oksygen fields.
   */
  public saveScenarioAdditionalFields(scenario: S): A | undefined {
    return undefined;
  }

  public dragChecker(scenario: S, data: any): boolean {
    return false;
  }

  public dragFeedback(scenario: S, data: any): DragFeedback {
    return {
      allowed: false,
      message: ''
    };
  }

  public onDrop(scenario: S, data: any): boolean {
    return false;
  }
}
