/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isEmpty, isNil, isString, set } from 'lodash';

import { asArray, HistoryType } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectModification } from '@oksygen-sim-core-libraries/data-types/objects';
import { InitialConditionsTrains, stringToBoolean, TrainSimPropertyValues, VehicleSimProp, XmlBooleanEnum } from '@oksygen-sim-train-libraries/components-services/common';
import {
  DISPLAY_STATE,
  INITIAL_STATE,
  ObjectContainer,
  ObjectSource,
  ObjectTypeContainer,
  USER_STATE
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { ScenarioTrain, ScenarioTrainDriver } from '@oksygen-sim-train-libraries/components-services/trains';

import { Scenario, ScenarioWorld, VirtualLocationVehicle } from '../models/scenario-service.model';
import {
  LinkedSegmentAssociationXml,
  ObjectModificationsXml,
  ObjectsXml,
  ObjectXml,
  ScenarioTrainDriverXml,
  ScenarioTrainXml,
  ScenarioXml,
  VirtualLocationVehicleXml,
  WorldXml
} from '../models/scenario-xml.model';

export interface LinkedSegmentAssociationsXml {
  segmentAssociation: Array<LinkedSegmentAssociationXml>;
}

export interface LinkedObjectXml extends ObjectXml {
  segmentAssociations: LinkedSegmentAssociationsXml;
}

export interface LinkedObjectsXml extends ObjectsXml {
  object?: Array<LinkedObjectXml>;
}
export interface LinkedWorldXml extends WorldXml {
  objects: LinkedObjectsXml;
}

export interface ScenarioXmlResult extends ScenarioXml {
  scenarioType?: {
    $: {
      id: string;
      name: string;
    };
  };

  world?: LinkedWorldXml;
}

export function fromScenarioXml<S extends Scenario = Scenario, X extends ScenarioXmlResult = ScenarioXmlResult>(
  scenarioXml: X,
  objectTypes: Map<string, ObjectTypeContainer>,
  logging: Logging,
  loadScenarioAdditionalFields?: (scenarioXml: X, scenario: S) => void
): S | undefined {
  if (isNil(scenarioXml) || isEmpty(scenarioXml)) {
    return undefined;
  }

  const scenario: S = {
    id: toString(scenarioXml.id),
    scenarioId: toNumber(scenarioXml.baseInfo.$.scenarioId),
    name: toString(scenarioXml.baseInfo.$.scenarioDescription),
    type: toString(scenarioXml.baseInfo.$.type),
    scenarioType: {
      id: -1,
      name: toString(scenarioXml.baseInfo.$.type)
    },
    version: toNumber(scenarioXml.baseInfo.$.version),
    scenarioHistory: [],
    scenarioDescription: scenarioXml.displayDescription ?? scenarioXml.baseInfo.$.scenarioDescription,
    subject: !isNil(scenarioXml.subject) ? toString(scenarioXml.subject) : '',
    world: fromWorldXml(scenarioXml.world, objectTypes),
    tracknetworkName: toString(scenarioXml.baseInfo.$.tracknetworkName),
    tracknetworkSkinName: toString(scenarioXml.baseInfo.$.tracknetworkSkinName),
    scenarioStartTime: toString(scenarioXml.baseInfo.$.scenarioStartTime),
    scenarioIsCore: stringToBoolean(scenarioXml.baseInfo.$.scenarioIsCore),
    scenarioIsActive: !!scenarioXml.baseInfo.$.scenarioIsActive,
    scenarioTrains: {
      scenarioTrain: []
    },
    virtualLocations: {
      virtualLocation: []
    },
    scenarioTrainDrivers: {
      scenarioTrainDriver: []
    },
    environment: {
      cloudDensityPercentage: 0,
      fogPercentage: 0,
      hazePercentage: 0,
      lightningPercentage: 0,
      rainPercentage: 0,
      snowPercentage: 0,
      sunBrightnessPercentage: 0,
      sunGlarePercentage: 0,
      windDirectionAngle: 0,
      windStrengthKmH: 0
    },
    multimedia: [],
    rule: [],
    reportData: []
  } as S;

  scenario.scenarioDescription = toString(scenario.scenarioDescription);

  asArray(scenarioXml.baseInfo.history?.historyLog).forEach(historyLog => {
    scenario.scenarioHistory.push({
      type: toString(historyLog.$.type) as HistoryType,
      authorFirstName: toString(historyLog.$.authorFirstName),
      authorLastName: toString(historyLog.$.authorLastName),
      scenarioName: toString(historyLog.$.scenarioName),
      scenarioVersion: toNumber(historyLog.$.scenarioVersion),
      timestamp: toString(historyLog.$.timestamp)
    });
  });

  if (!isNil(scenarioXml.scenarioType)) {
    scenario.scenarioType.id = toNumber(scenarioXml.scenarioType.$.id);
  }

  if (!isNil(scenarioXml.scenarioTrain) && !isEmpty(scenarioXml.scenarioTrain)) {
    scenario.scenarioTrains.scenarioTrain.push(...asArray(scenarioXml.scenarioTrain).map(fromScenarioTrainXml));
  }

  if (!isNil(scenarioXml.scenarioTrain) && !isEmpty(scenarioXml.scenarioTrain)) {
    const scenarioTrainsRaw = scenarioXml.scenarioTrain;
    const scenarioTrains = Array.isArray(scenarioTrainsRaw) ? scenarioTrainsRaw : [scenarioTrainsRaw];
    const simpropObj: InitialConditionsTrains = { trains: [] };

    scenarioTrains.forEach(train => {

      const trainObj: TrainSimPropertyValues = {
        trainSimPropertyValues: undefined,
        vehicleProps: [],
        trainId: undefined,
        trainDescription: undefined,
        trainNameInScenario: undefined
      };

      const isSimulated = train.$.isSimulated;
      if (isSimulated) {
        // Train-level sim properties

        trainObj.trainId = train.$.trainDescription;

        trainObj.trainDescription = train.$.trainDescription;
        trainObj.trainNameInScenario = train.$.name;

        if (train.simPropertyValues) {
          // trainObj.trainSimPropertyValues = train.simPropertyValues;
          trainObj.trainSimPropertyValues = normalizeSimPropertyValue(train.simPropertyValues);
        }

        const trainElementArray = Array.isArray(train.trainElement)
          ? train.trainElement
          : train.trainElement ? [train.trainElement] : [];


        // Vehicle-level properties
        if (Array.isArray(trainElementArray)) {
          trainElementArray.forEach(element => {
            const pos = parseInt(element.$.position, 10);
            if (!isNaN(pos)) {
              const vehSimPropValues = normalizeSimPropertyValue(element.simPropertyValues);
              const veh: VehicleSimProp = {
                vehicleIndex: pos,
                vehicleName: element.$?.classCode,
                vehicleSimPropertyValues: vehSimPropValues
              };
              trainObj.vehicleProps.push(veh);
            }
          });
        }
      }

      simpropObj.trains.push(trainObj);
    });
    scenario.initialConditionsTrains = simpropObj;
  }

  if (!isNil(scenarioXml.virtualLocationVehicle) && !isEmpty(scenarioXml.virtualLocationVehicle)) {
    scenario.virtualLocations.virtualLocation.push(...asArray(scenarioXml.virtualLocationVehicle).map(fromVirtualLocationVehicleXml));
  }

  if (!isNil(scenarioXml?.trainTypeEquipment) && !isNil(scenarioXml?.trainTypeEquipment?.equipmentTypes)) {
    scenario.trainTypeEquipment = {
      equipmentTypes: {
        equipmentType: asArray(scenarioXml.trainTypeEquipment.equipmentTypes.equipmentType)
      },
      scenarioTrainId: scenarioXml.trainTypeEquipment.scenarioTrainId
    };
  } else {
    scenario.trainTypeEquipment = {
      equipmentTypes: {
        equipmentType: []
      },
      scenarioTrainId: null
    };
  }

  if (!isNil(scenarioXml.scenarioTrainDriver) && !isEmpty(scenarioXml.scenarioTrainDriver)) {
    scenario.scenarioTrainDrivers.scenarioTrainDriver.push(...asArray(scenarioXml.scenarioTrainDriver).map(fromScenarioTrainDriverXml));

    scenario.scenarioTrainDrivers.scenarioTrainDriver.forEach(std => {
      // retroactively set robot driven scenario trains
      const st = scenario.scenarioTrains.scenarioTrain.find(t => t.id === std.initialTrainAssociation);
      if (!isNil(st)) {
        st.driverType = std.type === DriverType.HUMAN ? DriverType.HUMAN : DriverType.ROBOT;
      }
    });
  }

  // assign object children once we've processed them all
  scenario.world.object?.forEach((object, i) => {
    for (const typeChild of object?.objectType?.children ?? []) {
      const childId = object.properties[typeChild.name];

      if (childId) {
        // we assume that scenario objects CANNOT have track objects as children
        const childFeature = scenario.world.object.find(cf => cf.id === childId);
        if (childFeature) {
          const existingChild = object.children.find(c => c.id === childFeature.id);
          childFeature.parentId = object.id;
          childFeature.promotedChild = typeChild.promoted;
          if (!existingChild) {
            object.children.push(childFeature);
          } else {
            existingChild.parentId = object.id;
            existingChild.promotedChild = typeChild.promoted;
          }
        }
      }
    }
  });

  if (!isNil(scenarioXml.environment?.simPropertyValues?.simPropertyValue) && !isEmpty(scenarioXml.environment.simPropertyValues.simPropertyValue)) {
    asArray(scenarioXml.environment.simPropertyValues.simPropertyValue).forEach(simPropertyValue => {
      if (simPropertyValue.simPropertyGroup === 'Environment') {
        switch (simPropertyValue.simPropertyName) {
          case 'Cloud Density Percentage':
            scenario.environment.cloudDensityPercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Fog Percentage':
            scenario.environment.fogPercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Haze Percentage':
            scenario.environment.hazePercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Lightning Percentage':
            scenario.environment.lightningPercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Rain Percentage':
            scenario.environment.rainPercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Snow Percentage':
            scenario.environment.snowPercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Sun Brightness Percentage':
            scenario.environment.sunBrightnessPercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Sun Glare Percentage':
            scenario.environment.sunGlarePercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Tunnel Smoke Percentage':
            scenario.environment.tunnelSmokePercentage = simPropertyValue.simPropertyValue;
            break;
          case 'Wind Direction Angle':
            scenario.environment.windDirectionAngle = simPropertyValue.simPropertyValue;
            break;
          case 'Wind Gust':
            scenario.environment.windGust = simPropertyValue.simPropertyValue;
            break;
          case 'Wind Strength km/h':
            scenario.environment.windStrengthKmH = simPropertyValue.simPropertyValue;
            break;
          default:
            logging.warn(`Unknown Environment property "${simPropertyValue.simPropertyName}" encountered while loading Scenario ${scenario.id}!`);
            break;
        }
      }
    });
  }

  if (!isNil(scenarioXml.multimedia?.moodleScormActivity) && !isEmpty(scenarioXml.multimedia.moodleScormActivity)) {
    scenario.multimedia = asArray(scenarioXml.multimedia.moodleScormActivity).map(moodleScormActivity => ({
      moodleScormActivity: {
        name: toString(moodleScormActivity.$.name),
        multimediaId: toString(moodleScormActivity.$.multimediaId),
        ruleId: moodleScormActivity.$.ruleId
      }
    }));
  }

  if (!isNil(scenarioXml.rule) && !isEmpty(scenarioXml.rule)) {
    scenario.rule = asArray(scenarioXml.rule).map(ruleXml => ({
      id: toNumber(ruleXml.$.id),
      displayName: toString(ruleXml.displayName),
      description: toString(ruleXml.description),
      ruleType: toString(ruleXml.ruleType),
      active: isNil(ruleXml.active) ? true : ruleXml.active,
      ruleTemplateReference: {
        id: toString(ruleXml.ruleTemplateReference.id),
        version: toString(ruleXml.ruleTemplateReference.version),
        ruleBlocks: {
          ruleBlock: asArray(ruleXml.ruleTemplateReference.ruleBlocks.ruleBlock).map(ruleBlockXml => ({
            blockId: toNumber(ruleBlockXml.blockId),
            properties: {
              property: asArray(ruleBlockXml.properties.property).map(propertyXml => ({
                name: toString(propertyXml.name),
                value: convertPropertyXmlValue(propertyXml.value),
                units: toString(propertyXml.units),
                version: toString(propertyXml.version)
              }))
            }
          }))
        }
      }
    }));
  }

  scenario.assessment = scenarioXml.assessment;

  if (scenarioXml.assessmentReport?.assessmentItem) {
    const meritItem = asArray(scenarioXml.assessmentReport.assessmentItem)
      .find(item => item.assessmentType?.meritDemerit);
    if (meritItem) {
      scenario.initialScore = Number(meritItem.assessmentType.meritDemerit.initialScore) || 0;
      scenario.targetScore = Number(meritItem.assessmentType.meritDemerit.targetScore) || 0;
    }
  }

  if (!isNil(scenarioXml.reportData?.reportItem) && !isEmpty(scenarioXml.reportData.reportItem)) {
    scenario.reportData = asArray(scenarioXml.reportData.reportItem).map(reportDataXml => ({
      id: reportDataXml.$.id,
      displayName: reportDataXml.displayName,
      description: reportDataXml.description,
      assessed: reportDataXml.compulsory,
      reportItemReference: {
        name: reportDataXml.reportItemReference.$.name,
        version: reportDataXml.reportItemReference.$.version,
        assessmentParameters: asArray(reportDataXml.reportItemReference.assessmentParameters.assessmentParameter).map(assessmentParameter => ({
          ...assessmentParameter
        })),
        parameters: asArray(reportDataXml.reportItemReference.parameters.parameter).map(parameter => ({ ...parameter })),
        events: asArray(reportDataXml.reportItemReference.events.event).map(event => ({
          name: event.name,
          parameters: asArray(event.parameters.parameter).map(parameter => ({ ...parameter }))
        }))
      }
    }));
  }

  if (!isNil(scenarioXml.ruleVariables?.ruleVariable) && !isEmpty(scenarioXml.ruleVariables.ruleVariable)) {
    scenario.ruleVariables = asArray(scenarioXml.ruleVariables.ruleVariable).map(ruleVariableXml => ({
      name: ruleVariableXml.$.name,
      type: ruleVariableXml.$.type,
      value:
        ruleVariableXml.$.type === 'boolean'
          ? stringToBoolean(ruleVariableXml.$.value as XmlBooleanEnum)
          : ruleVariableXml.$.type === 'number'
          ? toNumber(ruleVariableXml.$.value)
          : ruleVariableXml.$.value
    }));
  }

  if (!isNil(loadScenarioAdditionalFields)) {
    loadScenarioAdditionalFields(scenarioXml, scenario);
  }

  return scenario;
}

function normalizeSimPropertyValue(value: any): { simPropertyValue: any[] } {
  if (typeof value !== 'object' || value == null) {
    return { simPropertyValue: [] };
  }

  const simPropertyValue = Array.isArray(value.simPropertyValue)
    ? value.simPropertyValue
    : value.simPropertyValue
      ? [value.simPropertyValue]
      : [];

  return {
    ...value,
    simPropertyValue
  };
}


function convertPropertyXmlValue(value?: string | number | boolean): any {
  if (!isNil(value) && isString(value)) {
    switch (value) {
      case 'true':
        return true;
      case 'false':
        return false;
    }
  }

  return value;
}

function fromScenarioTrainXml(scenarioTrainXml: ScenarioTrainXml): ScenarioTrain {
  return {
    id: toNumber(scenarioTrainXml.$.id),
    name: toString(scenarioTrainXml.$.name),
    driverType: stringToBoolean(scenarioTrainXml.$.isSimulated) ? DriverType.HUMAN : null, // need to check scenarioDriver xml to determine if robot or unset
    trainDescription: toString(scenarioTrainXml.$.trainDescription),
    tripNumber: toString(scenarioTrainXml.$.tripNumber),
    isHeadingAlpha: toNumber(scenarioTrainXml.$.isHeadingAlpha),
    startOffset: toNumber(scenarioTrainXml.$.startOffset),
    startSegmentName: scenarioTrainXml.$.startSegmentName
  };
}

function fromVirtualLocationVehicleXml(vLocXml: VirtualLocationVehicleXml): VirtualLocationVehicle {
  return {
    locationType: toString(vLocXml.$.locationType),
    locationName: toString(vLocXml.$.locationName),
    description: toString(vLocXml.$.description),
    hubMode: toString(vLocXml.$.hubMode),
    xOffset: toNumber(vLocXml.$.xOffset),
    yOffset: toNumber(vLocXml.$.yOffset),
    zOffset: toNumber(vLocXml.$.zOffset),
    headingOffset: toNumber(vLocXml.$.headingOffset),
    pitchOffset: toNumber(vLocXml.$.pitchOffset),
    rollOffset: toNumber(vLocXml.$.rollOffset),
    scenarioTrainName: toString(vLocXml.$.scenarioTrainName),
    vehicleIndex: toNumber(vLocXml.$.vehicleIndex)
  };
}

function fromScenarioTrainDriverXml(scenarioTrainDriverXml: ScenarioTrainDriverXml): ScenarioTrainDriver {
  return {
    id: toNumber(scenarioTrainDriverXml.id),
    initialTrainAssociation: toNumber(scenarioTrainDriverXml.initialTrainAssociation),
    type: toString(scenarioTrainDriverXml.type),
    driverTemplateReference: {
      id: toString(scenarioTrainDriverXml?.driverTemplateReference?.id),
      version: toString(scenarioTrainDriverXml?.driverTemplateReference?.version)
    }
  };
}

function fromWorldXml(worldXml: LinkedWorldXml, objectTypes: Map<string, ObjectTypeContainer>): ScenarioWorld {
  const world: ScenarioWorld = {
    trackNetwork: undefined,
    objectModification: [],
    signallingScheme: undefined,
    trackSkin: undefined,
    object: []
  };

  if (!isNil(worldXml)) {
    if (!isNil(worldXml.trackNetwork)) {
      world.trackNetwork = {
        title: toString(worldXml.trackNetwork.title),
        version: toString(worldXml.trackNetwork.version)
      };
    }

    if (!isNil(worldXml.trackSkin)) {
      world.trackSkin = {
        name: toString(worldXml.trackSkin.name)
      };
    }

    if (!isNil(worldXml.signallingScheme)) {
      world.signallingScheme = {
        name: toString(worldXml.signallingScheme.name),
        version: toString(worldXml.signallingScheme.version)
      };
    }

    if (!isNil(worldXml.objectModifications)) {
      world.objectModification = fromWorldObjectModificationXml(worldXml.objectModifications);
    }

    if (!isNil(worldXml.objects)) {
      world.object = fromWorldObjectXml(worldXml.objects, objectTypes);
    }
  }

  return world;
}

function fromWorldObjectModificationXml(objectModificationsXml: ObjectModificationsXml): Array<ObjectModification> {
  const objectModifications: Array<ObjectModification> = [];

  if (!isNil(objectModificationsXml?.object) && !isEmpty(objectModificationsXml?.object)) {
    asArray(objectModificationsXml.object).forEach(objectXml => {
      const objectModification = {
        name: toString(objectXml.name),
        properties: {}
      };

      asArray(objectXml.properties?.property).forEach(propertyXml =>
        set(objectModification.properties, propertyXml.name, propertyXml.isTextValue ? toString(propertyXml.value) : Number(propertyXml.value))
      );

      objectModifications.push(objectModification);
    });
  }

  return objectModifications;
}

export function fromWorldObjectXml(objectsXml: LinkedObjectsXml, objectTypes: Map<string, ObjectTypeContainer>): Array<ObjectContainer> {
  const objects: Array<ObjectContainer> = [];

  if (!isNil(objectsXml?.object) && !isEmpty(objectsXml?.object)) {
    asArray(objectsXml.object).forEach(objectXml => {
      const objectType = objectTypes.get(objectXml.typeName);

      const selectedStateProperty = asArray(objectXml.properties.property).find(p => p.name === INITIAL_STATE);
      const selectedState = Array.from(objectType.states).find(([id, s]) => s.name === selectedStateProperty.value)?.[1] ?? objectType.defaultState;

      const displayStateProperty = asArray(objectXml.properties.property).find(p => p.name === DISPLAY_STATE);
      const displayState = Array.from(objectType.states).find(([id, s]) => s.name === displayStateProperty?.value)?.[1] ?? objectType.displayState;

      const stateAutomated =
        Object.prototype.hasOwnProperty.call(objectXml.properties, USER_STATE) && (objectXml.properties as any)[USER_STATE] === objectType.automatedState.name;

      const object: ObjectContainer = {
        id: objectXml.id,
        name: toString(objectXml.name),
        objectType,
        source: ObjectSource.SCENARIO,
        states: objectType.states,
        selectedState,
        selectedIcon: selectedState?.icons,
        stateAutomated,
        stateVirtual: undefined,
        location: {
          lnglat: undefined,
          geometry: {
            x: objectXml.xCoord,
            y: objectXml.yCoord,
            z: objectXml.zCoord,
            h: objectXml.heading,
            p: objectXml.pitch,
            r: objectXml.roll
          }
        },
        children: [],
        trackAssociations: [],
        displayState
      };

      if (!isNil(objectXml.segmentAssociations?.segmentAssociation) && !isEmpty(objectXml.segmentAssociations?.segmentAssociation)) {
        // XQuery returns segmentId as well
        asArray(objectXml.segmentAssociations.segmentAssociation).forEach(segmentAssociation => {
          let orientation = Orientation.NONE;

          if (segmentAssociation.orientationName === 'From Alpha') {
            orientation = Orientation.ALPHA_TO_BETA;
          } else if (segmentAssociation.orientationName === 'From Beta') {
            orientation = Orientation.BETA_TO_ALPHA;
          }

          object.trackAssociations.push({
            segmentId: segmentAssociation.segmentId,
            offset: segmentAssociation.segmentOffset,
            orientation
          });
        });
      }

      if (!isNil(objectXml.properties?.property) && !isEmpty(objectXml.properties?.property)) {
        object.properties = {};

        asArray(objectXml.properties.property).forEach(propertyXml =>
          set(object.properties, propertyXml.name, propertyXml.isTextValue ? toString(propertyXml.value) : toNumber(propertyXml.value))
        );
      }

      objects.push(object);
    });
  }

  return objects;
}

function toString(value: any): string | undefined {
  if (Number.isNaN(value)) {
    return '';
  }

  return !isNil(value) ? value + '' : undefined;
}

function toNumber(value: any): number | undefined {
  return !isNil(value) ? Number(value) : undefined;
}
