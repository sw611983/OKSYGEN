/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isBoolean, isEmpty, isNil } from 'lodash';
import moment from 'moment';

import { HISTORY_TYPE_CREATED, HISTORY_TYPE_MODIFIED, momentToString } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { User } from '@oksygen-sim-core-libraries/components-services/users';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectProperties } from '@oksygen-sim-core-libraries/data-types/objects';
import { booleanToString, handleUnknownXmlData, SimPropertyValue, TrainElementXml, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { RuleBlockReference, RuleProperty } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioTrain, ScenarioTrainDriver } from '@oksygen-sim-train-libraries/components-services/trains';

import { Scenario, ScenarioWorld, VirtualLocationVehicle } from '../models/scenario-service.model';
import {
  ObjectModificationXml,
  ObjectPropertiesXml,
  ObjectXml,
  OrientationXmlEnum,
  ScenarioTrainDriverXml,
  ScenarioTrainXml,
  ScenarioXml,
  scenarioXmlCreateForKnownKeysHandling,
  SegmentAssociationXml,
  VirtualLocationVehicleXml,
  WorldXml
} from '../models/scenario-xml.model';

export function isValidScenarioId(scenario: Scenario): boolean {
  return !!scenario.scenarioId && scenario.scenarioId > 0;
}

export function toScenarioXml(
  rawScenario: any,
  scenario: Scenario,
  world: WorldData,
  loggedInUser: User,
  logger: Logging,
  scenarioAdditionalFields?: Array<string>,
  saveScenarioAdditionalFields?: (scenario: Scenario) => any | undefined
): ScenarioXml {
  // FIXME Added as a result of INTOSC-8817.
  // Possibly we want to retain this test after the bug is fixed; in that case determine the right course of action here.
  if (!loggedInUser) {
    loggedInUser = { firstName: 'Unknown', lastName: 'User', id: '' };
    logger.log('NO USER SET WHILE SAVING A SCENARIO. This seems incorrect.');
  }

  const data: ScenarioXml = {
    id: scenario.id,
    baseInfo: {
      $: {
        version: scenario.version?.toString(),
        type: scenario.scenarioType.name,
        scenarioDescription: scenario.name,
        scenarioStartTime: scenario.scenarioStartTime,
        scenarioIsCore: booleanToString(scenario.scenarioIsCore),
        tracknetworkName: scenario.tracknetworkName,
        tracknetworkSkinName: scenario.tracknetworkSkinName,
        scenarioIsActive: booleanToString(scenario.scenarioIsActive)
      },
      history: {
        historyLog: []
      }
    },
    // If no description, use scenario name as description
    displayDescription: scenario.scenarioDescription
  };
  if (scenario.subject) {
    data.subject = scenario.subject; // avoid <subject /> entries when it's left blank
  }

  // TODO: Remove this step once scenarioId is redundant
  // only set the scenarioId if we have one.
  if (isValidScenarioId(scenario)) {
    data.baseInfo.$.scenarioId = scenario.scenarioId.toString();
  }

  scenario.scenarioHistory?.forEach(history => {
    data.baseInfo.history.historyLog.push({
      $: {
        type: history.type,
        authorFirstName: history.authorFirstName,
        authorLastName: history.authorLastName,
        scenarioName: history.scenarioName,
        scenarioVersion: history.scenarioVersion?.toString(),
        timestamp: history.timestamp
      }
    });
  });

  if (!scenario.scenarioHistory || scenario.scenarioHistory.length === 0) {
    data.baseInfo.history.historyLog.push({
      $: {
        type: HISTORY_TYPE_CREATED,
        authorFirstName: loggedInUser.firstName,
        authorLastName: loggedInUser.lastName,
        scenarioName: scenario.name,
        scenarioVersion: '1',
        timestamp: momentToString(moment())
      }
    });
  } else {
    // add new entries to the start of the array
    data.baseInfo.history.historyLog.unshift({
      $: {
        type: HISTORY_TYPE_MODIFIED,
        authorFirstName: loggedInUser.firstName,
        authorLastName: loggedInUser.lastName,
        scenarioName: scenario.name,
        scenarioVersion: scenario.version?.toString(),
        timestamp: momentToString(moment())
      }
    });
  }

  if (scenario.scenarioTrains.scenarioTrain && scenario.scenarioTrains.scenarioTrain.length > 0) {
    data.scenarioTrain = scenario.scenarioTrains.scenarioTrain.map(toScenarioTrainXml);

    if (scenario.virtualLocations.virtualLocation && scenario.virtualLocations.virtualLocation.length > 0) {
      data.virtualLocationVehicle = scenario.virtualLocations.virtualLocation.map(toVirtualLocationVehicleXml);
    }
  }

  if (scenario?.initialConditionsTrains?.trains?.length > 0) {
    data.scenarioTrain.forEach(train => {
      const matchingTrain = scenario.initialConditionsTrains.trains.find(
        elemTrain => elemTrain.trainNameInScenario === train.$.name
      );

      if (matchingTrain) {
        // Set top-level train sim properties
        train.simPropertyValues = matchingTrain.trainSimPropertyValues ?? { simPropertyValue: [] };

        // Safely initialize trainElement array
        train.trainElement = [];

        const vehSimProps = matchingTrain.vehicleProps ?? [];

        vehSimProps.forEach(elem => {
          const trainElement: TrainElementXml = {
            $: {
              position: elem.vehicleIndex.toString(),
              classCode: elem.vehicleName
            },
            simPropertyValues: elem.vehicleSimPropertyValues ?? { simPropertyValue: [] }
          };

          train.trainElement.push(trainElement);
        });
      }
    });
  }


  if (scenario?.scenarioTrainDrivers?.scenarioTrainDriver?.length) {
    data.scenarioTrainDriver = scenario.scenarioTrainDrivers.scenarioTrainDriver.map(toScenarioTrainDriverXml);
  }

  const simPropertyValue = new Array<SimPropertyValue>();

  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Cloud Density Percentage', scenario.environment.cloudDensityPercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Fog Percentage', scenario.environment.fogPercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Haze Percentage', scenario.environment.hazePercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Lightning Percentage', scenario.environment.lightningPercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Rain Percentage', scenario.environment.rainPercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Snow Percentage', scenario.environment.snowPercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Sun Brightness Percentage', scenario.environment.sunBrightnessPercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Sun Glare Percentage', scenario.environment.sunGlarePercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Tunnel Smoke Percentage', scenario.environment.tunnelSmokePercentage);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Wind Direction Angle', scenario.environment.windDirectionAngle);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Wind Gust', scenario.environment.windGust);
  addEnvironmentSimPropertyValueXml(simPropertyValue, 'Environment', 'Wind Strength km/h', scenario.environment.windStrengthKmH);

  if (simPropertyValue.length) {
    data.environment = {
      simPropertyValues: {
        simPropertyValue
      }
    };
  }

  if (scenario.multimedia?.length > 0) {
    data.multimedia = {
      moodleScormActivity: []
    };

    scenario.multimedia.forEach(m => {
      if (m.moodleScormActivity) {
        data.multimedia.moodleScormActivity.push({
          $: {
            name: m.moodleScormActivity.name,
            multimediaId: m.moodleScormActivity.multimediaId,
            ruleId: m.moodleScormActivity.ruleId
          }
        });
      }
    });
  }

  if (scenario.rule?.length > 0) {
    data.rule = [];

    scenario.rule.forEach(r => {
      data.rule.push({
        $: {
          id: r.id
        },
        displayName: r.displayName,
        description: r.description,
        active: r.active === undefined ? true : r.active,
        ruleType: r.ruleType,
        ruleTemplateReference: {
          ...r.ruleTemplateReference,
          ruleBlocks: {
            ruleBlock: r.ruleTemplateReference.ruleBlocks?.ruleBlock?.map(rb => {
              const block: RuleBlockReference = {
                blockId: rb.blockId,
                properties: {
                  property: rb.properties?.property?.map(p => {
                    const prop: RuleProperty = {
                      ...p,
                      value: p.value === true || p.value === false ? p.value.toString() : p.value
                    };
                    return prop;
                  })
                }
              };
              return block;
            })
          }
        }
      });
    });
  }

  const worldXml = toWorldXml(scenario.world, world);

  if (worldXml) {
    data.world = worldXml;
  }

  if (isBoolean(scenario.assessment)) {
    data.assessment = scenario.assessment;
    data.assessmentReport = {
      assessmentItem: [
        {
          enabled: scenario.assessment,
          assessmentType: {
            meritDemerit: {
              initialScore: scenario.initialScore || 0,
              targetScore: scenario.targetScore || 0
            }
          }
        }
      ]
    };
  } else if (typeof scenario.assessment === 'number') {
     data.assessment = !!scenario.assessment;
  } else if (typeof scenario.assessment === 'string') {
    if (scenario.assessment === '0' || scenario.assessment === '') {
     data.assessment = false;
    } else {
     data.assessment = true;
    }
  }

  if (!isNil(scenario.reportData) && !isEmpty(scenario.reportData)) {
    data.reportData = {
      reportItem: scenario.reportData.map(assessment => (
        {
          $: {
            id: assessment.id
          },
          displayName: assessment.displayName,
          description: assessment.description,
          compulsory: assessment.assessed,
          reportItemReference: {
            $: {
              name: assessment.reportItemReference.name,
              version: assessment.reportItemReference.version
            },
            assessmentParameters: {
              assessmentParameter: assessment.reportItemReference.assessmentParameters
            },
            parameters: {
              parameter: assessment.reportItemReference.parameters
            },
            events: {
              event: assessment.reportItemReference.events.map(event => ({
                name: event.name,
                parameters: {
                  parameter: event.parameters
                }
              }))
            }
          }
      }))
    };
  }

  if (!isNil(scenario.ruleVariables) && !isEmpty(scenario.ruleVariables)) {
    data.ruleVariables = {
      ruleVariable: scenario.ruleVariables.map(variable => ({
        $: {
          name: variable.name,
          type: variable.type,
          value: typeof variable.value === 'boolean' ? booleanToString(variable.value) : variable.value
        }
      }))
    };
  }

  if (!isNil(saveScenarioAdditionalFields)) {
    const customFields = saveScenarioAdditionalFields(scenario);

    if (!isNil(customFields)) {
      Object.assign(data, customFields);
    }
  }

  if (!isNil(scenario?.trainTypeEquipment?.scenarioTrainId) && scenario?.trainTypeEquipment?.equipmentTypes?.equipmentType?.length > 0) {
    data.trainTypeEquipment = scenario.trainTypeEquipment;
  }

  return handleUnknownXmlData(rawScenario, data, getKnownScenarioKeys(scenarioAdditionalFields));
}

function getKnownScenarioKeys(scenarioAdditionalFields?: Array<string>): Array<string> {
  const knownScenarioKeys: Array<string> = [];

  const scenarioXmlObj = scenarioXmlCreateForKnownKeysHandling();

  for (const key in scenarioXmlObj) {
    if (Object.prototype.hasOwnProperty.call(scenarioXmlObj, key)) {
      knownScenarioKeys.push(key);
    }
  }

  if (!isNil(scenarioAdditionalFields) && !isEmpty(scenarioAdditionalFields)) {
    scenarioAdditionalFields.forEach(additionalField => {
      if (isNil(knownScenarioKeys.find(known => known.toLowerCase() === additionalField.toLowerCase()))) {
        knownScenarioKeys.push(additionalField);
      }
    });
  }

  return knownScenarioKeys;
}

function addEnvironmentSimPropertyValueXml(
  simProperties: Array<SimPropertyValue>,
  simPropertyGroup: string,
  simPropertyName: string,
  simPropertyValue: number | undefined
): void {
  if (simPropertyValue) {
    simProperties.push({
      simPropertyGroup,
      simPropertyName,
      simPropertyValue
    });
  }
}

function toScenarioTrainXml(scenarioTrain: ScenarioTrain): ScenarioTrainXml {
  return {
    $: {
      id: scenarioTrain.id.toString(),
      name: scenarioTrain.name,
      trainDescription: scenarioTrain.trainDescription,
      startSegmentName: scenarioTrain.startSegmentName,
      startOffset: scenarioTrain.startOffset?.toString() || '',
      isHeadingAlpha: (scenarioTrain.isHeadingAlpha?.toString() as any) || '',
      isSimulated: booleanToString(scenarioTrain.driverType === DriverType.HUMAN),
      tripNumber: scenarioTrain.tripNumber
    },
    simPropertyValues: scenarioTrain?.simPropertyValues,
    trainElement: scenarioTrain?.trainElement
  };
}

function toVirtualLocationVehicleXml(vLoc: VirtualLocationVehicle): VirtualLocationVehicleXml {
  return {
    $: {
      locationType: vLoc.locationType,
      description: vLoc.description,
      hubMode: vLoc.hubMode,
      xOffset: vLoc.xOffset.toString(),
      yOffset: vLoc.yOffset.toString(),
      zOffset: vLoc.zOffset.toString(),
      headingOffset: vLoc.headingOffset.toString(),
      pitchOffset: vLoc.pitchOffset.toString(),
      rollOffset: vLoc.rollOffset.toString(),
      scenarioTrainName: vLoc.scenarioTrainName,
      locationName: vLoc.locationName,
      vehicleIndex: vLoc.vehicleIndex.toString()
    }
  };
}

function toScenarioTrainDriverXml(scenarioTrainDriver: ScenarioTrainDriver): ScenarioTrainDriverXml {
  return {
    id: scenarioTrainDriver.id,
    initialTrainAssociation: scenarioTrainDriver.initialTrainAssociation,
    type: scenarioTrainDriver.type,
    driverTemplateReference: scenarioTrainDriver.driverTemplateReference

  };
}

function toWorldXml(rawWorld: ScenarioWorld, worldData: WorldData): WorldXml {
  const world: WorldXml = {
    trackNetwork: undefined,
    objectModifications: undefined,
    signallingScheme: undefined,
    trackSkin: undefined,
    objects: undefined
  };
  if (rawWorld) {
    if (rawWorld.trackNetwork) {
      world.trackNetwork = {
        title: rawWorld.trackNetwork.title,
        version: rawWorld.trackNetwork.version
      };
    }
    if (rawWorld.trackSkin) {
      world.trackSkin = {
        name: rawWorld.trackSkin.name
      };
    }
    if (rawWorld.signallingScheme) {
      world.signallingScheme = {
        name: rawWorld.signallingScheme.name,
        version: rawWorld.signallingScheme.version
      };
    }
    if (rawWorld.objectModification) {
      const objectModXml = toWorldObjectModificationXml(rawWorld);
      world.objectModifications = {
        object: objectModXml
      };
    }
    // FIXME add this back in once we support this data on the BE / XQ
    if (rawWorld.object) {
      const objectXml = toWorldObjectXml(rawWorld, worldData);
      world.objects = {
        object: objectXml
      };
    }
  }
  return world;
}

function toWorldObjectModificationXml(rawWorld: ScenarioWorld): Array<ObjectModificationXml> {
  return rawWorld.objectModification.map(om => ({
    name: om.name,
    properties: mapObjectProperties(om.properties)
  }));
}

export function toWorldObjectXml(rawWorld: ScenarioWorld, worldData: WorldData): Array<ObjectXml> {
  // we do not save children as scenario world object structure is flat - each child will be alongside the parent
  return rawWorld.object.map(o => {
    const obj: ObjectXml = {
      id: o.id,
      name: o.name,
      typeName: o.objectType.name,
      xCoord: o.location.geometry?.x ?? 0,
      yCoord: o.location.geometry?.y ?? 0,
      zCoord: o.location.geometry?.z ?? 0,
      heading: o.location.geometry?.h ?? 0,
      pitch: o.location.geometry?.p ?? 0,
      roll: o.location.geometry?.r ?? 0,
      properties: undefined,
      segmentAssociations: undefined
    };

    if (o.trackAssociations) {
      obj.segmentAssociations = {
        segmentAssociation: o.trackAssociations.map(a => {
          const assoc: SegmentAssociationXml = {
            segmentName: worldData.segmentMap.get(a.segmentId).name,
            segmentOffset: a.offset,
            orientationName: OrientationXmlEnum.BOTH
          };

          switch (a.orientation) {
            case Orientation.ALPHA_TO_BETA:
              assoc.orientationName = OrientationXmlEnum.FROM_ALPHA;
              break;
            case Orientation.BETA_TO_ALPHA:
              assoc.orientationName = OrientationXmlEnum.FROM_BETA;
              break;
          }

          return assoc;
        })
      };
    }

    if (!isEmpty(o.properties)) {
      obj.properties = mapObjectProperties(o.properties);
    }

    return obj;
  });
}

function mapObjectProperties(properties: ObjectProperties): ObjectPropertiesXml {
  return {
    property: Object.keys(properties)
      .filter(p => properties[p] !== null && properties[p] !== undefined)
      .map(p => {
        const value = properties[p];
        const isTextValue = typeof value === 'string';
        const isBool = typeof value === 'boolean';
        return {
          name: p,
          isTextValue: isTextValue ? 1 : 0,
          value: isTextValue ? (value as string) : isBool ? Number(value) : (value as number)
        };
      })
  };
}
