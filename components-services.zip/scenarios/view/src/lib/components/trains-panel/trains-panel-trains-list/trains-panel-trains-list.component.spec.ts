/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { TrainsPanelTrainsListComponent } from './trains-panel-trains-list.component';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { TrainListComponent } from '@oksygen-sim-train-libraries/components-services/trains';

describe('TrainsPanelTrainsListComponent', () => {
  let component: TrainsPanelTrainsListComponent;
  let fixture: ComponentFixture<TrainsPanelTrainsListComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [TrainsPanelTrainsListComponent, TrainListComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainsPanelTrainsListComponent);
    component = fixture.componentInstance;
    component.trains = new Observable(sub => sub.next([]));
    component.uiModels = new UiStateModelManager();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
