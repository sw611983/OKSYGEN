/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { Observable, Subscription } from 'rxjs';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { TrainListConfig, TrainQuickActionConfig, UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';
import { UserConfigService } from '@oksygen-sim-train-libraries/components-services/user-configuration';

@Component({
  selector: 'oksygen-trains-panel-trains-list',
  templateUrl: './trains-panel-trains-list.component.html',
  styleUrls: ['./trains-panel-trains-list.component.scss']
})
export class TrainsPanelTrainsListComponent implements OnInit, OnChanges, OnDestroy {
  @Input() trains!: Observable<UsefulTrain[]>;
  @Input() followTrain$: Observable<UsefulTrain>;
  @Input() pathTrainId$: Observable<number>;
  @Input() uiModels!: UiStateModelManager;
  /** May change during this component's lifetime */
  @Input() enableTrainMovement = false;
  @Input() enableChangeOrientation = false;
  @Input() worldData!: WorldData;

  @Output() readonly trainSelect = new EventEmitter<UsefulTrain>();
  @Output() readonly favourite = new EventEmitter<UsefulTrain>();
  @Output() readonly goToTrain = new EventEmitter<UsefulTrain>();
  @Output() readonly showTrain = new EventEmitter<UsefulTrain>();
  @Output() readonly lockOnTrain = new EventEmitter<UsefulTrain>();
  @Output() readonly changeOrientation = new EventEmitter<UsefulTrain>();
  @Output() readonly deleteTrain = new EventEmitter<UsefulTrain>();
  @Output() readonly pathTrain = new EventEmitter<UsefulTrain>();

  // FIXME probably should be per train
  trainItemSettings: TrainQuickActionConfig;
  allTrains: UsefulTrain[];
  driverlessTrains: UsefulTrain[];
  simulationTrains: UsefulTrain[];
  controlledTrains: UsefulTrain[];

  trainListConfig: TrainListConfig;

  private trainSub: Subscription;

  constructor(private readonly userConfigService: UserConfigService) {
    effect(() => {
      const userConfig = this.userConfigService.config();

      this.trainListConfig = {
        showTrackName: !!userConfig?.positionFormat.find(pf => pf === 'trackName'),
        showUserScale: !!userConfig?.positionFormat.find(pf => pf === 'userScale'),
        showSegOffset: !!userConfig?.positionFormat.find(pf => pf === 'segment')
      };
    });
}

  ngOnInit(): void {
    this.trainSub = this.trains.subscribe(trains => {
      if (!trains) {
        this.allTrains = [];
        this.driverlessTrains = [];
        this.simulationTrains = [];
        this.controlledTrains = [];
      } else {
        // needs to be a new array and object to fire change detection
        this.allTrains = [...trains.map(t => Object.assign({}, t))];
        this.driverlessTrains = trains.filter(train => !train.driverType);
        this.simulationTrains = trains.filter(train => train.driverType === DriverType.HUMAN);
        this.controlledTrains = trains.filter(train => train.driverType === DriverType.ROBOT);
      }
    });

    this.updateTrainItemSettings(this.enableChangeOrientation);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.enableChangeOrientation) {
      this.updateTrainItemSettings(changes.enableChangeOrientation.currentValue);
    }
  }

  updateTrainItemSettings(moveable: boolean): void {
    this.trainItemSettings = {
      favouriteEnabled: !!this.favourite.observers.length,
      findTrainEnabled: !!this.goToTrain.observers.length,
      lockOnEnabled: !!this.lockOnTrain.observers.length,
      deleteEnabled: !!this.deleteTrain.observers.length,
      pathEnabled: !!this.pathTrain.observers.length,
      selectionEnabled: false,
      carotEnabled: true,
      // FIXME the clever use of observers breaks down in cases like this.
      // Per-train settings set from the parent would probably reolve this issue.
      changeOrientationEnabled: moveable
    };
  }

  ngOnDestroy(): void {
    this.trainSub?.unsubscribe();
  }

  selectTrain(train: UsefulTrain): void {
    this.trainSelect.emit(train);
  }

  setFavourite(train: UsefulTrain): void {
    this.favourite.emit(train);
  }

  doGoToTrain(train: UsefulTrain): void {
    this.goToTrain.emit(train);
  }

  doShowTrain(train: UsefulTrain): void {
    this.showTrain.emit(train);
  }

  doLockOnTrain(train: UsefulTrain): void {
    this.lockOnTrain.emit(train);
  }

  doPathTrain(train: UsefulTrain): void {
    this.pathTrain.emit(train);
  }

  doChangeOrientation(train: UsefulTrain): void {
    this.changeOrientation.emit(train);
  }

  doDeleteTrain(train: UsefulTrain): void {
    this.deleteTrain.emit(train);
  }
}
