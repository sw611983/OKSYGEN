/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { BehaviorSubject, combineLatest, Observable, Subscription } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

import { filterTruthy } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { UserScenarioFavourites, UserScenarioFavouritesManager } from '@oksygen-sim-core-libraries/components-services/favourites';
import { FaultItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { UsefulTrain, UsefulVehiclePosition } from '@oksygen-sim-train-libraries/components-services/trains';
import { UserConfig, UserConfigService } from '@oksygen-sim-train-libraries/components-services/user-configuration';

import { SessionContext } from '../../contexts/session-context';
import { findTrain, lockOff, lockOn } from '../../models/train-utilities';
import { TrainCommsManager } from '../../services/train-comms.manager';

export class TrainFollowManager {
  followSelectedTrain = false;
  followToggled = false;
  followedTrain: UsefulTrain;
  followTrain$: BehaviorSubject<UsefulTrain> = new BehaviorSubject(null);

  constructor(private context: SessionContext) {}

  bind(): Subscription {
    return combineLatest([
      // FIXME The naming inconsistencies should get resolved as we rework what "selected" means.
      this.context.trains.getSelectedTrain$(),
      this.context.map.mapTogglesSubject
    ]).subscribe(([train, toggles]) => {
      this.followSelectedTrain = toggles.follow;
      this.followedTrain = this.followSelectedTrain ? train : null;
      this.followToggled = this.followSelectedTrain && !!this.followedTrain;
      this.followTrain$.next(this.followedTrain);
    });
  }

  toggleFollowTrain(train: UsefulTrain): void {
    if (train?.id === this.followedTrain?.id) {
      lockOff(this.context);
    } else {
      lockOn(this.context, train);
    }
  }
}

@Component({
  selector: 'oksygen-trains-panel',
  templateUrl: './trains-panel.component.html',
  styleUrls: ['./trains-panel.component.scss']
})
export class TrainsPanelComponent implements OnInit, OnDestroy {
  @Input() context$: Observable<SessionContext>;
  @Input() selectedTrain$: BehaviorSubject<UsefulTrain> = new BehaviorSubject(null);
  @Input() selectedFault$: Observable<FaultItem>;
  @Input() uiModels!: UiStateModelManager;
  @Input() enableTrainMovement$: Observable<boolean>;
  @Input() enableChangeOrientation$: Observable<boolean>;

  @Output() readonly trainSelect = new EventEmitter<UsefulTrain>();

  simulator: any;
  trains$: Observable<UsefulTrain[]>;
  pathTrainId$: Observable<number>;

  dynamicTrainData$: Observable<UsefulVehiclePosition>;

  worldData: WorldData;

  pathToggled = false;
  selectedFault: FaultItem;
  followManager: TrainFollowManager;

  currentTrains: UsefulTrain[];

  userScenarioFavourites: UserScenarioFavourites;

  breadcrumbChildren: ReadonlyArray<string>;

  enableTrainMovement = false;
  enableChangeOrientation = false;

  userConfig$: Observable<UserConfig>;

  private context: SessionContext;

  private pathTrainId: number;

  private subscription = new Subscription();

  private userScenarioFavouritesManager: UserScenarioFavouritesManager;

  constructor(private readonly logging: Logging, userConfigService: UserConfigService) {
    this.userConfig$ = userConfigService.config$();
  }

  ngOnInit(): void {
    const contextSub = this.context$?.pipe(filterTruthy()).subscribe(m => {
      this.context = m;
      this.initialiseData();
    });
    this.subscription.add(contextSub);

    this.subscription.add(this.enableTrainMovement$.subscribe(b => (this.enableTrainMovement = b)));
    this.subscription.add(this.enableChangeOrientation$.subscribe(b => (this.enableChangeOrientation = b)));
  }

  initialiseData(): void {
    this.subscription.add(this.context.world.world$.subscribe(w => (this.worldData = w)));

    this.trains$ = this.context.trains.data();

    this.pathTrainId$ = this.context.map.getPathTrainId$();

    this.subscription.add(
      this.pathTrainId$.subscribe(pt => {
        this.pathTrainId = pt;
        this.pathToggled = this.selectedTrain$.getValue()?.id === this.pathTrainId;
      })
    );

    this.followManager = new TrainFollowManager(this.context);
    this.subscription.add(this.followManager.bind());

    this.userScenarioFavouritesManager = this.context.userScenarioFavourites;
    this.subscription.add(
      this.userScenarioFavouritesManager.userScenarioFavourites$().subscribe(value => {
        this.userScenarioFavourites = value;
        this.processFavouriteStoreData();
      })
    );

    this.dynamicTrainData$ = this.selectedTrain$.pipe(
      switchMap(selectedTrain => this.trains$.pipe(map(trains => trains.find(tr => tr?.id === selectedTrain?.id)?.vehicles[0].position)))
    );

    this.subscription.add(
      combineLatest([this.trains$, this.selectedTrain$, this.selectedFault$]).subscribe(([trains, selectedTrain, selectedFault]) => {
        this.selectedFault = selectedFault;
        this.selectTrain(selectedTrain, false);
        this.currentTrains = trains;

        // FIXME this approach doesn't seem scalable or readily customisable by projects.
        // There should be an API (probably part of a service) for requesting a train to be selected.
        if (selectedFault) {
          const train = this.currentTrains?.find(tr => tr.id === selectedFault.scenarioTrainId);

          if (train) {
            this.selectTrain(train, false);
          }
        }
      })
    );

    this.processFavouriteStoreData();
  }

  ngOnDestroy(): void {
    this.followManager?.followTrain$?.complete();
    this.subscription.unsubscribe();
  }

  setFavourite(train: UsefulTrain): void {
    if (this.userScenarioFavourites) {
      this.userScenarioFavouritesManager.updateScenarioTrains(train.id);
    } else {
      this.logging.warn(`tried to favourite trainId ${train}, but userScenarioFavourites is not valid`);
    }
  }

  goToTrain(train: UsefulTrain): void {
    findTrain(this.context, train);
  }

  changeOrientation(train: UsefulTrain): void {
    // FIXME need a "move train" API shared between editor and session runner
    (this.context.trains as TrainCommsManager).flipTrain(train.id);
  }

  showTrain(train: UsefulTrain): void {
    this.context.map.spotlightTrain(train.id);
  }

  selectTrain(train: UsefulTrain, emit = true): void {
    if (emit) {
      // FIXME This component writing to this observable is probably not expected by the class that created it.
      this.selectedTrain$.next(train);
    }
    this.pathToggled = this.selectedTrain$.getValue()?.id === this.pathTrainId;
    this.updateBreadcrumbs();
  }

  onTrainSelection(train: UsefulTrain): void {
    this.trainSelect.emit(train);
  }

  showTrainPath(train: UsefulTrain): void {
    this.context.map.toggleHighlightedPath(train);
  }

  private processFavouriteStoreData(): void {
    if (this.userScenarioFavourites) {
      this.context.trains.updateTrainFavourites(this.userScenarioFavourites);
    }
  }

  private updateBreadcrumbs(): void {
    if (this.selectedTrain$.getValue()) {
      this.breadcrumbChildren = [t('Details')];
    } else {
      this.breadcrumbChildren = null;
    }
  }
}
