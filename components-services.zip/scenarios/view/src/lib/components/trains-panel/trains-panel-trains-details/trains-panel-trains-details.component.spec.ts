/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { DecimalPipe } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { UnitsUnitPipe } from '@oksygen-sim-core-libraries/components-services/measurement-units';
import { IconFieldComponent } from '@oksygen-sim-train-libraries/components-services/common';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { TrainCardComponent } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserConfigurationModule } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { OksygenSimTrainWorldDefinitionModule } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { FaultItemComponent } from '../../user-faults/fault-item/fault-item.component';
import { FaultsPanelComponent } from '../../user-faults/faults-panel/faults-panel.component';
import { TrainsPanelTrainsDetailsComponent } from './trains-panel-trains-details.component';

describe('TrainsPanelTrainsDetailsComponent', () => {
  let component: TrainsPanelTrainsDetailsComponent;
  let fixture: ComponentFixture<TrainsPanelTrainsDetailsComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainUserConfigurationModule, OksygenSimTrainWorldDefinitionModule, IconFieldComponent],
        declarations: [
          TrainsPanelTrainsDetailsComponent,
          TrainCardComponent,
          FaultsPanelComponent,
          FaultItemComponent,
          UnitsUnitPipe
        ],
        providers: [DecimalPipe]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainsPanelTrainsDetailsComponent);
    component = fixture.componentInstance;
    component.train = {
      id: 1,
      name: 'A Train',
      description: 'A Train Description',
      driverType: DriverType.HUMAN,
      driverName: DriverType.HUMAN,
      driverId:'',
      trainType: 'A Train Type',
      vehicles: []
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
