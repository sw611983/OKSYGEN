/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Observable, Subscription } from 'rxjs';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import {
  newFormControl,
  newNumericFormControl,
  newOptionalFormControl,
  quietUpdateOptions
} from '@oksygen-common-libraries/material/components';
import { FaultItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { DragData, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { ScenarioTrainItem } from '@oksygen-sim-train-libraries/components-services/maps';
import {
  calculateDistance,
  calculateDistanceFormat,
  calculateSpeed,
  calculateSpeedFormat,
  ConsistDataService,
  TrainCardConfig,
  TrainDistanceFormat,
  TrainSpeedFormat,
  UsefulTrain,
  UsefulVehiclePosition
} from '@oksygen-sim-train-libraries/components-services/trains';
import { INITIAL_CONFIG, UserConfig } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import {
  newUserScaleUi,
  TrackLocationPanelSegmentOffsetInput,
  TrackLocationPanelTrackNameInput,
  TrackLocationPanelUserScaleInput,
  UserScaleUi
} from '@oksygen-sim-train-libraries/components-services/world-definition';

@Component({
  selector: 'oksygen-trains-panel-trains-details',
  templateUrl: './trains-panel-trains-details.component.html',
  styleUrls: ['./trains-panel-trains-details.component.scss']
})
export class TrainsPanelTrainsDetailsComponent implements OnInit, OnChanges, OnDestroy {
  @Input() train!: UsefulTrain;
  @Input() selectedFault: FaultItem;
  @Input() followToggled = false;
  @Input() pathToggled = false;
  @Input() worldData!: WorldData;
  @Input() dynamicTrainData$: Observable<UsefulVehiclePosition>;
  /** May change during this component's lifetime */
  @Input() enableTrainMovement = false;
  @Input() enableChangeOrientation = false;
  @Input() userConfig: UserConfig;

  @Output() readonly favourite         = new EventEmitter<UsefulTrain>();
  @Output() readonly goToTrain         = new EventEmitter<UsefulTrain>();
  @Output() readonly lockOnTrain       = new EventEmitter<UsefulTrain>();
  @Output() readonly changeOrientation = new EventEmitter<UsefulTrain>();
  @Output() readonly showTrain         = new EventEmitter<UsefulTrain>();
  @Output() readonly pathTrain         = new EventEmitter<UsefulTrain>();

  private configSubscription = Subscription.EMPTY;
  private cachedUserConfig = INITIAL_CONFIG;

  dragData: DragData;

  speed: number;
  odometer: number;
  distanceFormat: TrainDistanceFormat = t('km');
  speedFormat: TrainSpeedFormat = t('km/h');

  trackNameControl = newFormControl();
  segmentControl = newFormControl();
  offsetControl = newNumericFormControl();
  orientationControl = newFormControl();
  driverControl = newOptionalFormControl();
  userScaleControls: UserScaleUi[] = [];

  // FIXME deprecate the above controls as we copy their refs here anyway
  trackLocationConfig: {
    trackName: TrackLocationPanelTrackNameInput;
    userScales: TrackLocationPanelUserScaleInput;
    segmentOffset: TrackLocationPanelSegmentOffsetInput;
  };

  private trainSubscription = Subscription.EMPTY;

  public config: TrainCardConfig;

  constructor(
    private readonly consistDataService: ConsistDataService
  ) { }

  ngOnInit(): void {
    this.calculateData(null);
    this.distanceFormat = calculateDistanceFormat(this.cachedUserConfig?.uomFormat);
    this.speedFormat = calculateSpeedFormat(this.cachedUserConfig?.uomFormat);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if(changes.dynamicTrainData$ && changes.dynamicTrainData$.currentValue !== changes.dynamicTrainData$.previousValue) {
      this.trainSubscription.unsubscribe();

      this.trainSubscription = this.dynamicTrainData$.subscribe(position => {
        this.calculateData(position);
        this.updateTrainFields(position);
      });
    }

    if (changes.userConfig) {
      this.cachedUserConfig = changes.userConfig.currentValue;
      this.distanceFormat = calculateDistanceFormat(this.cachedUserConfig?.uomFormat);
      this.speedFormat = calculateSpeedFormat(this.cachedUserConfig?.uomFormat);
      this.updateTrackLocationFields(this.cachedUserConfig);
    }

    if (changes.enableTrainMovement || changes.enableChangeOrientation) {
      const moveable = Object.prototype.hasOwnProperty.call(changes, 'enableTrainMovement') ? changes.enableTrainMovement.currentValue : false;
      const orientatable = Object.prototype.hasOwnProperty.call(changes, 'enableChangeOrientation') ? changes.enableChangeOrientation.currentValue : false;

      this.config = {
        trainName: true,
        icons: {
          favourites: true,
          flip: orientatable,
          findTrain: true,
          follow: true,
          moveTrain: moveable,
          path: true,
          vision: true
        }
      };

      // TODO Scenario Trains should probably have the consist attached.
      this.consistDataService.data()
        .pipe(takeOneTruthy())
        .subscribe(consists => {
          const consist = consists.find(c => c.name === this.train.description);

          const sti: ScenarioTrainItem = {scenarioTrainId: this.train.id, consist, driverType: this.train.driverType};
          this.dragData = {type: 'train', data: sti};
        });
    }
  }

  ngOnDestroy(): void {
    this.configSubscription.unsubscribe();
    this.trainSubscription.unsubscribe();
  }

  calculateData(position: UsefulVehiclePosition): void {
    this.speed = calculateSpeed(position, this.cachedUserConfig?.uomFormat);
    this.odometer = calculateDistance(position, this.cachedUserConfig?.uomFormat);
  }

  setFavourite(train?: UsefulTrain): void {
    this.favourite.emit(this.train);
  }

  setLockOnTrain(train?: UsefulTrain): void {
    this.lockOnTrain.emit(this.train);
  }

  doGoToTrain(train?: UsefulTrain): void {
    this.goToTrain.emit(this.train);
  }

  doShowTrain(train?: UsefulTrain): void {
    this.showTrain.emit(this.train);
  }

  doPathTrain(train?: UsefulTrain): void {
    this.pathTrain.emit(this.train);
  }

  doChangeOrientation(train?: UsefulTrain): void {
    this.changeOrientation.emit(this.train);
  }

  updateTrainFields(pos: UsefulVehiclePosition): void {
    if (pos) {
      this.segmentControl.setValue(pos.segmentId, quietUpdateOptions);
      this.offsetControl.setValue(pos.segmentOffset, quietUpdateOptions);
      this.trackNameControl.setValue(pos?.trackName ?? '', quietUpdateOptions);
      this.orientationControl.setValue(pos.segmentOrientation === Orientation.ALPHA_TO_BETA ? t('Alpha to Beta') : t('Beta to Alpha'), quietUpdateOptions);
      this.userScaleControls = pos.userScales?.map(scale => newUserScaleUi(scale)) ?? [];
      if (this.trackLocationConfig?.userScales?.userScaleControls) {
        this.trackLocationConfig.userScales.userScaleControls = this.userScaleControls;
      }
      this.updateTrackLocationFields(this.cachedUserConfig);
    }
  }

  private updateTrackLocationFields(userConfig: UserConfig): void {
    const showTrackName = this.trackNameControl.value && !!userConfig.positionFormat.find(pf => pf === 'trackName');
    const showUserScale = !!userConfig.positionFormat.find(pf => pf === 'userScale');
    const showSegOffset = !!userConfig.positionFormat.find(pf => pf === 'segment');
    const config = {
      trackName: {
        show: showTrackName,
        trackNameControl: this.trackNameControl
      },
      userScales: {
        show: showUserScale,
        userScaleControls: this.userScaleControls
      },
      segmentOffset: {
        show: showSegOffset,
        segmentControl: this.segmentControl,
        offsetControl: this.offsetControl
      }
    };
    this.trackLocationConfig = config;
  }
}
