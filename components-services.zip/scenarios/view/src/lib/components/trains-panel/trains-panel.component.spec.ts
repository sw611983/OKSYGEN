/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { TrainsPanelComponent } from './trains-panel.component';
import { TrainListComponent } from '@oksygen-sim-train-libraries/components-services/trains';
import { TrainsPanelTrainsListComponent } from './trains-panel-trains-list/trains-panel-trains-list.component';
import { BehaviorSubject } from 'rxjs';
import { SessionContext } from '../../contexts/session-context';
import { FaultItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';

describe('TrainsPanelComponent', () => {
  let component: TrainsPanelComponent;
  let fixture: ComponentFixture<TrainsPanelComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [
          TrainsPanelComponent,
          TrainsPanelTrainsListComponent,
          TrainListComponent
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainsPanelComponent);
    component = fixture.componentInstance;
    component.context$ = new BehaviorSubject<SessionContext>(new SessionContext());
    component.selectedFault$ = new BehaviorSubject<FaultItem>(null);
    component.uiModels = new UiStateModelManager();
    component.enableTrainMovement$ = new BehaviorSubject<boolean>(false);
    component.enableChangeOrientation$ = new BehaviorSubject<boolean>(false);

    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
