/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { ScenarioDetailRuleListComponent } from './scenario-detail-rule-list.component';

describe('ScenarioDetailRuleListComponent', () => {
  let component: ScenarioDetailRuleListComponent;
  let fixture: ComponentFixture<ScenarioDetailRuleListComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      imports: [ScenarioDetailRuleListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioDetailRuleListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
