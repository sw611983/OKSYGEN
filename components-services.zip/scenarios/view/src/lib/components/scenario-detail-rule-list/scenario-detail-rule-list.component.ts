/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component } from '@angular/core';
import { MatFormFieldControl } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';

import { OksygenMaterialComponentsModule, OksygenMatFormFieldComponent } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { ScenarioRule } from '@oksygen-sim-train-libraries/components-services/scenarios';

@Component({
  selector: 'oksygen-scenario-detail-rule-list',
  templateUrl: './scenario-detail-rule-list.component.html',
  styleUrls: ['./scenario-detail-rule-list.component.scss'],
  standalone: true,
  imports: [MatIcon, OksygenMaterialComponentsModule, OksygenMaterialTranslateModule],
  providers: [{ provide: MatFormFieldControl, useExisting: ScenarioDetailRuleListComponent }]
})
export class ScenarioDetailRuleListComponent
  extends OksygenMatFormFieldComponent<ScenarioRule[]>
  implements MatFormFieldControl<ScenarioRule[]> {}
