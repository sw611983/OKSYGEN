/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, Output, OnInit, OnDestroy } from '@angular/core';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { Observable, Subscription, switchMap } from 'rxjs';

import { ActiveSessionState } from '@oksygen-sim-train-libraries/components-services/common';
import { NotificationDialogData } from '@oksygen-sim-train-libraries/components-services/events';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { filterTruthy } from '@oksygen-common-libraries/common';

@Component({
  selector: 'oksygen-instructor-prompt-dialog',
  templateUrl: './instructor-prompt-dialog.component.html',
  styleUrls: ['./instructor-prompt-dialog.component.scss']
})
export class InstructorPromptDialogComponent implements OnInit, OnDestroy {
  @Input() event: NotificationDialogData;
  @Input('systemState') systemState$!: Observable<ActiveSessionState>;

  @Output('dialogClose') readonly closeEmit = new EventEmitter<void>();
  @Output('activate') readonly activateEmit = new EventEmitter<boolean>();
  @Output('trigger') readonly triggerEmit = new EventEmitter<void>();

  disabled = false;

  private subscription = new Subscription();

  constructor(private contextSupplier: SessionContextSupplier) {}

  ngOnInit(): void {
    this.subscription.add(
      this.contextSupplier
        .currentContext$()
        .pipe(
          filterTruthy(),
          switchMap(m => m.data$)
        )
        .subscribe(scenario => (this.disabled = scenario.assessment ?? false))
    );
  }

  progressBarValue(dismissDuration: number, sessionTriggerTime: number): number{
    const progress = 100 - (dismissDuration*100/sessionTriggerTime);
    return progress;
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  close(): void {
    this.closeEmit.emit();
  }

  changeActive(change: MatSlideToggleChange): void {
    this.activateEmit.emit(change.checked);
  }

  onTrigger(): void {
    this.triggerEmit.emit();
    this.close();
  }
}
