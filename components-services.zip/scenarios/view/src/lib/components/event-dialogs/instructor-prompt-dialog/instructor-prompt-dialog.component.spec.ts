/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { InstructorPromptDialogComponent } from './instructor-prompt-dialog.component';

describe('InstructorPromptDialogComponent', () => {
  let component: InstructorPromptDialogComponent;
  let fixture: ComponentFixture<InstructorPromptDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [InstructorPromptDialogComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(InstructorPromptDialogComponent);
    component = fixture.componentInstance;
    component.event = { event$: new Observable(obs => {}) };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
