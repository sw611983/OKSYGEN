/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { SpatialEventDialogComponent } from './spatial-event-dialog.component';
import { SpatialEventPipe, SpatialEventUnitsPipe } from '@oksygen-sim-train-libraries/components-services/common';

describe('SpatialEventDialogComponent', () => {
  let component: SpatialEventDialogComponent;
  let fixture: ComponentFixture<SpatialEventDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [SpatialEventDialogComponent, SpatialEventPipe, SpatialEventUnitsPipe]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(SpatialEventDialogComponent);
    component = fixture.componentInstance;
    component.event = { event$: new Observable(obs => {}) };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
