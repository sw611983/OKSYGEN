/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { filter, switchMap } from 'rxjs/operators';

import { filterTruthy, takeOneTruthy } from '@oksygen-common-libraries/common';
import { SpatialEvent } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { ActiveSessionState } from '@oksygen-sim-train-libraries/components-services/common';
import { NotificationDialogData } from '@oksygen-sim-train-libraries/components-services/events';
import { ObjectContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { UserConfigService } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { getTrackLocationFields, WorldLocationTextData } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { SessionContext } from '../../../contexts/session-context';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';

@Component({
  selector: 'oksygen-spatial-event-dialog',
  templateUrl: './spatial-event-dialog.component.html',
  styleUrls: ['./spatial-event-dialog.component.scss']
})
export class SpatialEventDialogComponent implements OnInit, OnDestroy {
  readonly noTrackNameText = '--';
  readonly trainPositionSeparator = '|';
  readonly userScaleSeparator = '-';

  @Input() event!: NotificationDialogData;
  @Input('systemState') systemState$!: Observable<ActiveSessionState>;

  @Output('dialogClose') readonly closeEmit = new EventEmitter<void>();
  @Output('activate') readonly activateEmit = new EventEmitter<boolean>();
  @Output('trigger') readonly triggerEmit = new EventEmitter<void>();

  feature: ObjectContainer;

  disabled = false;

  locationData: WorldLocationTextData;

  private subscription = new Subscription();

  constructor(private readonly contextSupplier: SessionContextSupplier, private readonly userConfigService: UserConfigService) {}

  ngOnInit(): void {
    this.subscription.add(
      this.contextSupplier
        .currentContext$()
        .pipe(
          filterTruthy(),
          switchMap(m => combineLatest([m.data$, this.userConfigService.config$(), m.world.netDef$, m.world.world$]))
        )
        .subscribe(([scenario, userConfig, netDef, world]) => {
          this.disabled = scenario.assessment ?? false;
          const trackAssoc = this.feature.trackAssociations[0];
          this.locationData = getTrackLocationFields(userConfig, netDef, trackAssoc, world);
        })
    );

    const feature$ = combineLatest([this.event.event$, this.contextSupplier.currentContext$()])?.pipe(
      filter(([event, manager]) => !!event && !!manager),
      switchMap(([event, manager]: [SpatialEvent, SessionContext]) => manager.objects.getObject$(event?.markerId))
    );
    this.subscription.add(
      feature$?.subscribe(feature => {
        this.feature = feature;
      })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  close(): void {
    this.closeEmit.emit();
  }

  changeActive(change: MatSlideToggleChange): void {
    this.activateEmit.emit(change.checked);
  }

  onTrigger(): void {
    this.triggerEmit.emit();
    this.close();
  }

  gotoFeature(mouseEvent: Event): void {
    mouseEvent.stopPropagation();
    if (!this.feature?.location) {
      return;
    }
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy())
      .subscribe(m => {
        m.map.mapGoto(this.feature.location?.lnglat);
      });
  }
}
