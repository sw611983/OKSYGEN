/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { TemporalEventDialogComponent } from './temporal-event-dialog.component';

describe('TemporalEventDialogComponent', () => {
  let component: TemporalEventDialogComponent;
  let fixture: ComponentFixture<TemporalEventDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [TemporalEventDialogComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(TemporalEventDialogComponent);
    component = fixture.componentInstance;
    component.event = { event$: new Observable(obs => {}) };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
