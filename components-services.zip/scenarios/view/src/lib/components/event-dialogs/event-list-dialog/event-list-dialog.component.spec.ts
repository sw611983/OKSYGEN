/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { SESSION_RUNNER_CONTEXT_PROVIDERS, configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { NotificationListDialogComponent } from './event-list-dialog.component';

describe('NotificationListDialogComponent', () => {
  let component: NotificationListDialogComponent;
  let fixture: ComponentFixture<NotificationListDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [NotificationListDialogComponent],
        providers: SESSION_RUNNER_CONTEXT_PROVIDERS
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationListDialogComponent);
    component = fixture.componentInstance;
    component.data = { events$: new Observable(() => {}), onActivate: null, onTrigger: null, onAcknowledge: null, systemState$: new Observable(() => {}) };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
