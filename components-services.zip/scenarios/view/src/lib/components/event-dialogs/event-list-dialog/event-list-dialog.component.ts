/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { animate, query, stagger, style, transition, trigger } from '@angular/animations';
import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Observable, Subscription } from 'rxjs';
import { distinctUntilChanged, first, map } from 'rxjs/operators';

import { EventActiveStatus, EventType, RawEvent, TriggerActiveStatus } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { NotificationDialogData, NotificationListDialogData } from '@oksygen-sim-train-libraries/components-services/events';

import { OksygenScrollbarComponent } from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';

@Component({
  selector: 'oksygen-event-list-dialog',
  templateUrl: './event-list-dialog.component.html',
  styleUrls: ['./event-list-dialog.component.scss'],
  // providers: [ SessionRunnerContextPublisher ],
  animations: [
    trigger('listAnimation', [
      transition('* => *', [
        query(':enter', style({ transform: 'translateX(-100%)', opacity: 0.2 }), { optional: true }),
        query(':enter', stagger('300ms', [
          animate('.5s ease-in', style({ transform: 'translateX(0)', opacity: 1, offset: 0 }))
        ]), { optional: true }),
        query(':leave', style({ transform: 'translateX(0)', opacity: 1 }), { optional: true }),
        query(':leave', [
          stagger(200, [
            animate('.5s ease-in', style({ transform: 'translateX(-100%)', opacity: 0.2, offset: 0 }))
          ])
        ], { optional: true })
      ])
    ])
  ]
})
export class NotificationListDialogComponent implements OnInit, OnDestroy {

  events$: Observable<RawEvent[]>;
  events: NotificationDialogData[] = [];
  displayedEvents: NotificationDialogData[] = [];
  masterSubscription = new Subscription();
  @ViewChild('scrollbar') scrollbar: OksygenScrollbarComponent;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: NotificationListDialogData,
    private dialogRef: MatDialogRef<NotificationListDialogComponent>,
    private logger: Logging,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.events$ = this.data.events$;
    // ugly setTimeout required for entry animation - otherwise initial list of events don't animate in
    setTimeout(() => {
      const eventSub = this.events$?.subscribe(events => {
        events?.forEach( event => this.eventManager(event) );
        this.sortEventList(this.displayedEvents, true);
        this.cdr.detectChanges();
      });
      this.masterSubscription.add(eventSub);
      // ugly setTimeout again - scroll to bottom must wait for the list UI to have been rendered before it can scroll
      setTimeout(() => { this.scrollToBottom(); this.cdr.detectChanges(); }, 20);
    });
    // const systemSub = this.data.systemState$?.subscribe(system => {
    //   this.contextSupplier.setCurrentContext({id: system.systemNumber});
    // });
    // this.masterSubscription.add(systemSub);
  }

  ngOnDestroy(): void {
    this.masterSubscription?.unsubscribe();
  }

  /**
   * This method is the black box responsible for figuring out the "state" of the event.
   * Specifically, this means whether it should be displayed or not (including removing / adding it).
   *
   * @param event the event to process
   */
  private eventManager(event: RawEvent): void {
    // so our algorithm is:
    // maintain 2 lists - 1 of all events, the second a subset of events which should be displayed
    // then, if this event isn't in our list of all events, add it in
    // then work out of the event should be displayed or not
    // add / remove it, depending on if its current state doesn't match where it currently is
    let currentEventIndex = this.arrayHasEvent(event, this.events);
    if (currentEventIndex < 0) {
      this.events.push(this.createEvent(event));
      currentEventIndex = this.events.length - 1;
    }
    const notificationDialogData = this.events[currentEventIndex];
    const eventState = this.eventShouldDisplay(notificationDialogData, event.promptTime);
    if (typeof eventState === 'number') { // number indicates an index from which to splice it
      this.displayedEvents.splice(eventState, 1);
    } else if (eventState === 'add') {
      this.displayedEvents.push(notificationDialogData);
    } // else it's unchanged, in which case do nothing
  }

  /**
   * This creates an event in our list format.
   *
   * @param event the event to "create" in our list format
   */
  private createEvent(event: RawEvent): NotificationDialogData {
    const event$ = this.events$.pipe(
      map(events => events.find(e => e.id === event.id && e.ruleId === event.ruleId)),
      distinctUntilChanged()
    );
    const eventData: NotificationDialogData = {
      event$
      // dismissed: false
    };
    return eventData;
  }

  /**
   * Simple helper method to determine whether the event exists in the specified array.
   *
   * @param event the event
   * @param array the array to check for said event
   */
  arrayHasEvent(event: RawEvent, array: NotificationDialogData[]): number {
    return array.findIndex(ae => {
      const ev = this.getEventFromObservable(ae);
      return ev.id === event.id && ev.ruleId === event.ruleId;
    });
  }

  onClose(data: NotificationDialogData): void {
    // event.dismissed = true;
    const event = this.getEventFromObservable(data);
    this.onAcknowledge(data);
    this.eventManager(event);
  }

  onActivate(changed: boolean, event: NotificationDialogData): void {
    this.data.onActivate(changed, this.getEventFromObservable(event));
  }

  onTrigger(event: NotificationDialogData): void {
    this.data.onTrigger(this.getEventFromObservable(event));
  }

  onAcknowledge(event: NotificationDialogData): void {
    this.data.onAcknowledge(this.getEventFromObservable(event));
  }

  /**
   * Sorts events based on how long until they trigger.
   * Mutates the original array, so the return value is the same array you passed in.
   *
   * @param events the array of events to sort
   * @param asc ascending - ie, events closest to triggering at the top
   */
  sortEventList(events: NotificationDialogData[], asc: boolean): NotificationDialogData[] {
    return events.sort((a, b) => {
      const eventA = this.getEventFromObservable(a);
      const eventB = this.getEventFromObservable(b);
      if (!eventA && eventB) { return 1; }
      if (eventA && !eventB) { return -1; }
      if (!eventA && !eventB) { return 0; }
      if (asc) { return eventA.timeToTrigger - eventB.timeToTrigger; }
      return eventB.timeToTrigger - eventA.timeToTrigger; // desc
    });
  }

  /**
   * Simple helper method to synchronously get an event's data.
   *
   * @param appEvent the event to convert back to a regular RawEvent
   */
  private getEventFromObservable(appEvent: NotificationDialogData): RawEvent {
    let event: RawEvent;
    const sub = appEvent.event$.pipe(first()).subscribe((ev: RawEvent) => {
      event = ev;
    });
    sub?.unsubscribe();
    return event;
  }

  /**
   * The black box method to determine whether an event should be displayed.
   * Returns the index of the event if the event should be removed, otherwise 'add' or 'unchanged'.
   *
   * @param data the event
   * @param threshold time threshold for whether the popup should display.
   */
  private eventShouldDisplay(data: NotificationDialogData,threshold = 60): number|'unchanged'|'add' {
    const event = this.getEventFromObservable(data);
    const eventIndex = this.arrayHasEvent(event, this.displayedEvents);
    // note we can't use whether it's been triggered or not as events can be deactivated
    if (eventIndex >= 0) {
      if (/*data.dismissed ||*/ event.acknowledged ||  event.triggerState === TriggerActiveStatus.TRIGGERED
        || event.timeToTrigger > threshold || event.timeToTrigger <= 0
        || (event.type === EventType.INSTRUCTOR_PROMPT && event.autoDismiss) && (event.dismissDuration > threshold || event.dismissDuration <= 0)
      ) {
        return eventIndex;
      }
    } else {
      if ( !event.acknowledged && (event.triggerState === TriggerActiveStatus.NOT_TRIGGERED)
          && (
              (event.timeToTrigger <= threshold && event.timeToTrigger > 0 && event.prompt)
              || (
                event.type === EventType.INSTRUCTOR_PROMPT && event.activationState === EventActiveStatus.ACTIVE
                && event.dismissDuration <= threshold && event.dismissDuration > 0
              )
              || (event.type === EventType.INSTRUCTOR_PROMPT && !event.autoDismiss && event.timeToTrigger === event.sessionTriggerTime-event.promptTime)
            )
      ) {
        return `add`;
      }
    }
    return `unchanged`;
  }

  /**
   * Scroll the event list to the bottom.
   */
  private scrollToBottom(): void {
    this.scrollbar?.scrollToBottom();
  }

}
