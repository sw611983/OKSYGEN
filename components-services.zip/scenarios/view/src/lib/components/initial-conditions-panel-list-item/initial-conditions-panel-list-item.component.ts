/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, ElementRef, effect, input, output } from '@angular/core';

import { MatAccordionTogglePosition } from '@angular/material/expansion';
import { AutocompleteInputType } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { SimPropertyValues, TrainSimPropertyValues } from '@oksygen-sim-train-libraries/components-services/common';

@Component({
  selector: 'oksygen-initial-conditions-panel-list-item',
  templateUrl: './initial-conditions-panel-list-item.component.html',
  styleUrls: ['./initial-conditions-panel-list-item.component.scss']
})
export class InitialConditionsPanelListItemComponent {
  public readonly allSimPropertiesTrain = input<TrainSimPropertyValues>();
  public readonly deleteEnabled = input<boolean>(true);

  readonly deleteRule = output<TrainSimPropertyValues>();

  formField = AutocompleteInputType.FORM_FIELD;
  togglePositionBefore: MatAccordionTogglePosition = 'before';

  trainIcon = OksygenIcon.TRAIN;
  vehicleIcon = OksygenIcon.RAILCAR;

  constructor(private host: ElementRef) {
    // Must run effect inside constructor to keep injection context
    effect(() => {
      setTimeout(() => {
        const value = this.allSimPropertiesTrain();
        if (value) {
        }
      });
    });
  }

  deleteClicked(updatedSimPropValues: SimPropertyValues, scope: 'train' | 'vehicle', vehicleIndex?: number): void {
    const current = this.allSimPropertiesTrain();
    let updated: TrainSimPropertyValues;

    if (scope === 'train') {
      updated = {
        ...current,
        trainSimPropertyValues: updatedSimPropValues
      };
    } else if (scope === 'vehicle' && typeof vehicleIndex === 'number') {
      let updatedVehicleProps = current.vehicleProps?.map(vehicle =>
        vehicle.vehicleIndex === vehicleIndex
          ? {
              ...vehicle,
              vehicleSimPropertyValues: updatedSimPropValues
            }
          : vehicle
      );

      if (updatedSimPropValues.simPropertyValue.length === 0) {
        updatedVehicleProps = updatedVehicleProps?.filter(v => v.vehicleIndex !== vehicleIndex);
      }

      updated = {
        ...current,
        vehicleProps: updatedVehicleProps
      };
    } else {
      console.warn('Unhandled scope or missing vehicle index');
      updated = current;
    }

    // Emit result safely
    setTimeout(() => this.deleteRule.emit(updated));
  }
}
