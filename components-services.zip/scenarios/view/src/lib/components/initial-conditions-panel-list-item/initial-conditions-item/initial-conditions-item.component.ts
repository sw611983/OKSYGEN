/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, effect, ElementRef, input, output } from '@angular/core';
import { MatAccordionTogglePosition } from '@angular/material/expansion';
import { AutocompleteInputType } from '@oksygen-common-libraries/material/components';
import { SimPropertyValues } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';

@Component({
  selector: 'oksygen-initial-conditions-item',
  templateUrl: './initial-conditions-item.component.html',
  styleUrls: ['./initial-conditions-item.component.scss']
})
export class InitialConditionsItemComponent {
  public readonly simPropertiesValues = input<SimPropertyValues>();
  public readonly icon = input<OksygenIcon | undefined>(undefined);
  public readonly title = input<string>();
  public readonly deleteEnabled = input<boolean>();

  readonly deleteRule = output<SimPropertyValues>();

  formField = AutocompleteInputType.FORM_FIELD;
  togglePositionBefore: MatAccordionTogglePosition = 'before';

  constructor(private host: ElementRef) {
    effect(() => {
      const value = this.simPropertiesValues();
      if (value) {
      }
    });
  }

  deleteClicked(propertyName: string): void {
    const current = this.simPropertiesValues();
    const updated: SimPropertyValues = {
      ...current,
      simPropertyValue: current.simPropertyValue.filter(item => item.name !== propertyName)
    };
    this.deleteRule.emit(updated);
  }
}
