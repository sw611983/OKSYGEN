/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { AfterViewChecked, Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { BehaviorSubject, Subscription } from 'rxjs';

import { filterTruthy } from '@oksygen-common-libraries/common';
import { Sorter } from '@oksygen-common-libraries/material/components';
import { CabHardwareService } from '@oksygen-sim-train-libraries/components-services/cab-hardware';
import { Scenario, scenarioSearchableText, ScenarioService, UsersScenariosService } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { ScenarioItemComponent } from '../scenario-item/scenario-item.component';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

/**
 * A component for selecting Scenarios and setting overrides on them.
 */
@Component({
  selector: 'oksygen-scenario-select',
  templateUrl: './scenario-select.component.html',
  styleUrls: ['./scenario-select.component.scss']
})
export class ScenarioSelectComponent implements OnInit, AfterViewChecked, OnDestroy {
  /** The system the selection is for */
  @Input() systemNumber: number;
  /**
   * The currently selected scenario.
   */
  @Input() selectedScenarioId: string;
  /**
   * The currently selected trainee.
   */
  @Input() selectedTraineeId: string;
  /**
   * Forms containing override settings, indexed by Scenario ID.
   * The forms are expected to contain a startTimeDate FormControl.
   */
  @Input() scenarioForms: Map<string, UntypedFormGroup> = new Map();

  /**
   * Indicates that the selected scenario should change.
   */
  @Output() readonly selectedValue = new EventEmitter<Scenario>();

  traineeScenarios: Scenario[] = [];
  sorter = new Sorter<Scenario>();

  private loadedSubject = new BehaviorSubject<boolean>(false);
  public loaded = this.loadedSubject.asObservable();

  expandedScenarioId: string;

  // FIXME Copy pasted verbatim :(
  // Track the state of the expansion panels as they begin expanded and then collapse,
  // and we want to respond to them being collapsed.
  private prevHeight = 0;
  private expansionPanelsCollapsed = false;
  // Prevent FOUC due to https://github.com/angular/components/issues/13870
  disableAnimation = true;

  // FIXME Copy pasted verbatim :(
  // Flag for driving automatic scrolling to the selected item,
  // which we only want to do when the screen is initially shown.
  private initialScrollPending = true;
  private dataSubscription: Subscription;

  // FIXME Copy pasted almost verbatim :(
  @ViewChildren(ScenarioItemComponent) scenarioItemComponents: QueryList<ScenarioItemComponent>;
  @ViewChild('scrollcontent') scrollContent: ElementRef<HTMLDivElement>;
  @ViewChild('scroll') scroll: ElementRef<HTMLDivElement>;

  constructor(
    public scenarioService: ScenarioService,
    private cabHardwareService: CabHardwareService,
    private usersScenariosService: UsersScenariosService,
    private readonly translateService: TranslateService
  ) {}

  ngOnInit(): void {
    this.dataSubscription = this.usersScenariosService.mapping$.pipe(filterTruthy()).subscribe(userScenarioMapping => {
      if (userScenarioMapping) {
        const validScenarios = this.cabHardwareService.filterScenarios(this.systemNumber, this.usersScenariosService.scenarios);

        if (this.selectedTraineeId != null && this.selectedTraineeId !== undefined) {
          const traineeScenarioIds = userScenarioMapping?.userSimUserIdScenarioIdMap?.get(this.selectedTraineeId);

          if (traineeScenarioIds) {
            this.traineeScenarios = validScenarios.filter(scenario => traineeScenarioIds.includes(scenario.id));
          } else {
            this.traineeScenarios = [];
          }
        } else {
          this.traineeScenarios = validScenarios;
        }

        this.loadedSubject.next(true);
      }
    });

    this.sorter.sortFunction = (c, a, b): number => a.name.localeCompare(b.name, this.translateService.currentLocaleString);
  }

  ngAfterViewChecked(): void {
    this.checkForInitialCollapseOfExpansionPanels();
    this.performInitialScroll();
  }

  ngOnDestroy(): void {
    this.loadedSubject.complete();
    this.dataSubscription?.unsubscribe();
  }

  // FIXME Copy pasted verbatim :(
  private checkForInitialCollapseOfExpansionPanels(): void {
    if (!this.expansionPanelsCollapsed) {
      const height = this.scrollContent.nativeElement.clientHeight;

      if (height < this.prevHeight) {
        this.expansionPanelsCollapsed = true;
        setTimeout(() => (this.disableAnimation = false));
      }

      this.prevHeight = height;
    }
  }

  // FIXME Copy pasted almost verbatim :(
  private performInitialScroll(): void {
    // Make sure we haven't done our initial scroll, and that we are ready to do so.
    if (this.initialScrollPending && this.expansionPanelsCollapsed && this.loadedSubject.value && this.scroll) {
      // Abort if no scenario selected
      this.initialScrollPending = !!this.selectedScenarioId;

      if (!this.initialScrollPending) {
        return;
      }

      // Make sure that all of the child components have been created.
      if (this.scenarioItemComponents.length === this.traineeScenarios.length) {
        for (const sic of this.scenarioItemComponents.toArray()) {
          if (sic.scenario.id === this.selectedScenarioId) {
            this.initialScrollPending = false;
            setTimeout(() => {
              this.scroll.nativeElement.scrollTo({
                top: sic.element.nativeElement.offsetTop - this.scroll.nativeElement.clientHeight / 2,
                behavior: 'smooth'
              });
              setTimeout(() => (this.expandedScenarioId = this.selectedScenarioId));
            });
            return;
          }
        }
      }
    }
  }

  updateSelectedScenario(scenario: Scenario): void {
    this.selectedValue.emit(scenario);
  }

  updateExpandedScenario(scenario: Scenario): void {
    this.expandedScenarioId = scenario ? scenario.id : null;
  }

  compareScenarios(a: Scenario, b: Scenario): number {
    return a.name.localeCompare(b.name, this.translateService.currentLocaleString);
  }

  toSearchableText(scenario: Scenario): string[] {
    return scenarioSearchableText(scenario);
  }
}
