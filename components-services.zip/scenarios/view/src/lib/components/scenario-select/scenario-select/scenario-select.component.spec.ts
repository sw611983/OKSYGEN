/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OksygenSimTrainNoCabHardwareModule } from '@oksygen-sim-train-libraries/components-services/cab-hardware';
import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ScenarioSelectComponent } from './scenario-select.component';
import { UsersScenariosService } from '@oksygen-sim-train-libraries/components-services/scenarios';

describe('ScenarioSelectComponent', () => {
  let component: ScenarioSelectComponent;
  let fixture: ComponentFixture<ScenarioSelectComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainNoCabHardwareModule],
        declarations: [ScenarioSelectComponent],
        providers: [UsersScenariosService]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
