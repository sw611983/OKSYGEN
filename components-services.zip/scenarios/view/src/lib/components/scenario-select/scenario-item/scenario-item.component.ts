/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MatExpansionPanel } from '@angular/material/expansion';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import moment from 'moment';

import { momentToString } from '@oksygen-common-libraries/common';
import { CANCEL_BUTTON, PromptDialogComponent, PromptDialogData } from '@oksygen-common-libraries/material/components';
import { MaterialThemePalette } from '@oksygen-common-libraries/material/theme';
import { TrackService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Scenario, ScenarioService } from '@oksygen-sim-train-libraries/components-services/scenarios';

/**
 * Displays the details about a scenario in an expansion panel.
 * Allows selection of the scenario and the overriding of its default settings.
 */
@Component({
  selector: 'oksygen-scenario-item',
  templateUrl: './scenario-item.component.html',
  styleUrls: ['./scenario-item.component.scss']
})
export class ScenarioItemComponent implements OnInit, OnChanges {
  /**
   * The Scenario to display.
   */
  @Input() scenario!: Scenario;
  @Input() scenarioIcon = 'train';
  /**
   * Containing override settings.
   * Expected to contain a startTimeDate FormControl.
   */
  @Input() form!: UntypedFormGroup;
  @Input() selected!: boolean;
  @Input() expanded!: boolean;

  @Output() readonly clicked = new EventEmitter<Scenario>();
  @Output() readonly expand = new EventEmitter<Scenario>();

  hasOverrides = false;

  @ViewChild(MatExpansionPanel) expansionPanel: MatExpansionPanel;

  constructor(
    public scenarioService: ScenarioService,
    public trackService: TrackService,
    public element: ElementRef,
    public dialog: MatDialog) {}

  ngOnInit(): void {
    this.updateHasOverrides();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.expanded && this.expansionPanel) {
      this.synchroniseExpansion();
    }
  }

  updateSelected(): void {
    this.clicked.emit(this.scenario);
  }

  /**
   * Selects the start time for the scenario.
   *
   * @param time The selected time
   */
  selectTime(time: moment.Moment): void {
    // We seem to have to force change detection to occur in the date picker.
    this.form.controls.startTimeDate.setValue(null);
    setTimeout(() => {
      this.form.controls.startTimeDate.setValue(momentToString(time));
      this.updateHasOverrides();
    });
  }

  updateHasOverrides(): void {
    const selectedStartTime = this.form.value.startTimeDate;
    const defaultStartTime = this.scenario.scenarioStartTime;
    this.hasOverrides = selectedStartTime !== defaultStartTime;
  }

  resetOverrides(): void {
    const promptData = new PromptDialogData();
    promptData.title = t('Are you sure you want to reset these fields?');
    promptData.content = t('This cannot be recovered.');
    promptData.buttons = [{
      color: MaterialThemePalette.PRIMARY,
      text: 'Reset',
      data: true
    }, CANCEL_BUTTON];

    PromptDialogComponent.open(this.dialog, promptData,
      result => {
        if (result) {
          this.selectTime(moment(this.scenario.scenarioStartTime));
        }
      });
  }

  toggleExpansion(): void {
    this.expand.emit(this.expanded ? null : this.scenario);
  }

  /**
   * Helper for customising expansion panel behavour.
   * Suppresses event propagation and ensures the panel state matches what we want.
   * Requests selection if we've clicked the title.
   */
  intercept($event: Event): void {
    $event.stopPropagation();

    if (!this.isExpansionToggle($event.target)) {
      this.synchroniseExpansion();
      if (this.isExpansionTitle($event.target)) {
        this.updateSelected();
      }
    }
  }

  private synchroniseExpansion(): void {
    if (this.expanded) {
      this.expansionPanel.open();
    } else {
      this.expansionPanel.close();
    }
  }

  private isExpansionTitle(target: any): boolean {
    const headerClass = 'mat-expansion-panel-header-title';
    return target.classList?.contains(headerClass);
  }

  private isExpansionToggle(target: any): boolean {
    const expansionToggleClass = 'expansion-toggle';
    return target.classList?.contains(expansionToggleClass);
  }
}
