/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, inject, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormBuilder, Validators } from '@angular/forms';

import { configureSimTrainTestingModule, createTestScenario } from '@oksygen-sim-train-libraries/components-services/testing';

import { ScenarioItemComponent } from './scenario-item.component';

describe('ScenarioItemComponent', () => {
  let component: ScenarioItemComponent;
  let fixture: ComponentFixture<ScenarioItemComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [ScenarioItemComponent]
      }).compileComponents();
    })
  );

  beforeEach(inject([UntypedFormBuilder], (fb: UntypedFormBuilder) => {
    fixture = TestBed.createComponent(ScenarioItemComponent);
    component = fixture.componentInstance;

    component.scenario = createTestScenario();

    component.form = fb.group({
      selectedScenario: [null, Validators.required],
      startTimeDate: [null, Validators.required]
      // Disabling this form as it causes the UI to start hunting for tracks (which we haven't set up in this spec).
      // skin: [null, Validators.required]
    });

    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
