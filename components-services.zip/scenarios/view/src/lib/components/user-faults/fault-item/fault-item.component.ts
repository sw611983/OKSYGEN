/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Input } from '@angular/core';

import { UserScenarioFavouritesManager } from '@oksygen-sim-core-libraries/components-services/favourites';
import { FaultItem, UserFaultControlType, UserFaultManager } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';

@Component({
  selector: 'oksygen-fault-item',
  templateUrl: './fault-item.component.html',
  styleUrls: ['./fault-item.component.scss']
})
export class FaultItemComponent {
  readonly USER = UserFaultControlType.USER;

  @Input() fault: FaultItem;
  @Input() faultManager: UserFaultManager;
  @Input() userScenarioFavouritesManager: UserScenarioFavouritesManager;
  @Input() expanded = false;

  internalExpanded = false;

  constructor() {}

  favouriteClick(event: Event): void {
    event?.stopPropagation();
    this.userScenarioFavouritesManager.updateFaults(this.fault.id, this.fault.ruleId);
  }

  expandedStateChanged(): void {
    this.internalExpanded = !this.internalExpanded;
  }

  requestChange(value: number): void {
    this.faultManager.requestControlChange({
      id: this.fault.id,
      ruleId: this.fault.ruleId,
      controlRequest: value
    });
  }
}
