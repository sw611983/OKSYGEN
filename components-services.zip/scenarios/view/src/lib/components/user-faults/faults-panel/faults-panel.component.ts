/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

import { Sorter, TextFilterPipe } from '@oksygen-common-libraries/material/components';
import { Logging } from '@oksygen-common-libraries/pio';
import { UserScenarioFavouritesManager } from '@oksygen-sim-core-libraries/components-services/favourites';
import { FaultItem, UserFault, UserFaultControlType, UserFaultManager } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { filterTruthy } from '@oksygen-common-libraries/common';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { TranslateService } from '@oksygen-common-libraries/material/translate';

export class FaultFilterType {
  constructor(public searchKey: string, public displayText: string) {}
}

export const allFaultFilterType = new FaultFilterType('', t('All'));
// this component is currently session only due to the expected properties on UserFaultManager
@Component({
  selector: 'oksygen-faults-panel',
  templateUrl: './faults-panel.component.html',
  styleUrls: ['./faults-panel.component.scss']
})
export class FaultsPanelComponent implements OnInit, OnDestroy {
  static readonly FAULT_TYPES = [
    allFaultFilterType,
    new FaultFilterType(UserFaultControlType.USER.toString(), t('User')),
    new FaultFilterType(UserFaultControlType.RULE.toString(), t('Rule'))
  ];

  @Input() scenarioTrainId: number;
  @Input() vehicleIndex: number;
  @Input() selectedFault: FaultItem;

  selectedFaultTypeSubject: BehaviorSubject<FaultFilterType> = new BehaviorSubject(allFaultFilterType);
  searchTextSubject = new BehaviorSubject('');
  searchText$: Observable<string>;
  sorter = new Sorter<FaultItem>();
  filteredFaults: FaultItem[] = [];

  faultTypes = FaultsPanelComponent.FAULT_TYPES;
  faultManager: UserFaultManager; // FIXME this is the session impl - should be compatible with other impls
  userScenarioFavouritesManager: UserScenarioFavouritesManager;

  private currentSearchText = '';

  private textFilterPipe: TextFilterPipe<FaultItem>;
  private faults: FaultItem[] = [];
  private searchTextSub: Subscription;
  private faultSub: Subscription;
  private manSub: Subscription;

  constructor(
    private logger: Logging,
    private contextSupplier: SessionContextSupplier,
    private readonly translateService: TranslateService
  ) {}

  ngOnInit(): void {
    this.textFilterPipe = new TextFilterPipe(this.logger);
    this.sorter.sortFunction = (c, a, b): number => a?.name?.localeCompare(b?.name, this.translateService.currentLocaleString);
    this.searchText$ = this.searchTextSubject.pipe(debounceTime(500));
    this.searchTextSub = this.searchText$.subscribe(search => {
      this.setSearchFilters(search);
    });
    this.selectedFaultTypeSubject.subscribe(() => {
      this.onSearchKey();
    });
    this.setSearchFilters();
    this.manSub = this.contextSupplier.currentContext$().pipe(filterTruthy()).subscribe(m => {
      this.faultManager = m.userFaults as any; // FIXME this makes this component session only!
      this.faultSub?.unsubscribe();

      this.faultSub = this.faultManager?.getFaults$(this.scenarioTrainId, this.vehicleIndex).subscribe(newUserFaults => {
        this.faults = newUserFaults;

        this.setSearchFilters();
      });
      this.userScenarioFavouritesManager = m.userScenarioFavourites;
    });
  }

  ngOnDestroy(): void {
    this.faults.forEach(fault => {
      this.faultManager.cancelIndividualUpdateNotification({ id: fault.id, ruleId: fault.ruleId });
    });
    this.searchTextSubject.complete();
    this.searchTextSub?.unsubscribe();
    this.faultSub?.unsubscribe();
    this.manSub?.unsubscribe();
    this.selectedFaultTypeSubject?.complete();
  }

  getFaultId(index: number, fault: UserFault): number {
    return fault ? fault.id : 0;
  }

  /**
   * this will set the icon filter to search + ' ' + the selected filter type (ie signal).
   * For example, 'fooSearch barType'
   */
  onSearchKey(search?: string): void {
    this.currentSearchText = search !== null || search !== undefined ? search : this.currentSearchText;
    const selectedFaultType = this.selectedFaultTypeSubject.getValue();
    const searchText = (this.currentSearchText ? this.currentSearchText + ' ' : '') + selectedFaultType.searchKey;
    this.searchTextSubject.next(searchText);
  }

  removeFilterType(): void {
    this.selectedFaultTypeSubject.next(allFaultFilterType);
  }

  toSearchableText(fault: UserFault): string[] {
    const searchableFaultText: string[] = [];
    if (fault.name) {
      searchableFaultText.push(fault.name);
    }
    if (fault.controlType) {
      searchableFaultText.push(fault.controlType.toString());
    }
    return searchableFaultText;
  }

  filterByFaultType(faultType: FaultFilterType): void {
    this.selectedFaultTypeSubject.next(faultType ? faultType : allFaultFilterType);
  }

  toggleSort(): void {
    this.sorter.toggleSort();
    this.setSearchFilters();
  }

  private setSearchFilters(search?: string): void {
    if (!this.faults || !this.textFilterPipe) {
      return;
    }
    const searchText = search ? search : this.searchTextSubject.getValue();
    this.filteredFaults = this.textFilterPipe.transform(this.faults, this.toSearchableText.bind(this), searchText, this.sorter, this.sorter.refresh);
  }
}
