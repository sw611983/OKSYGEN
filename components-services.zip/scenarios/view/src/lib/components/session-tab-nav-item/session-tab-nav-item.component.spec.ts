/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { UserScenarioFavouritesService } from '@oksygen-sim-core-libraries/components-services/favourites';
import { RuleService } from '@oksygen-sim-train-libraries/components-services/rules';
import { configureSimTrainTestingModule, TEST_SYSTEM_NUMBER, TEST_USER_ID } from '@oksygen-sim-train-libraries/components-services/testing';

import { SessionTabNavItemComponent } from './session-tab-nav-item.component';
import { of } from 'rxjs';
import { SessionLoggingConfigToken } from '../../tokens/session-logging.token';

describe('SessionTabNavItemComponent', () => {
  let component: SessionTabNavItemComponent;
  let fixture: ComponentFixture<SessionTabNavItemComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule({
      declarations: [SessionTabNavItemComponent],
      providers: [
        {
          provide: SessionLoggingConfigToken,
          useValue: {}
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    const favouritesService = TestBed.inject(UserScenarioFavouritesService);
    favouritesService.create(TEST_SYSTEM_NUMBER, TEST_USER_ID);

    const ruleService = TestBed.inject(RuleService);
    ruleService.createSystem(TEST_SYSTEM_NUMBER, of(true));

    fixture = TestBed.createComponent(SessionTabNavItemComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('data', {
      routerLink: 'session/1',
      id: 1,
      systemNumber: 1,
      traineeName: 'John Doe',
      traineeId: '2',
      scenarioId: 3,
      scenarioName: 'Running',
      autonomous: false,
      alert: null,
      sessionState: { icon: 'play', style: 'color: var(--color-success)', message: '' }
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
