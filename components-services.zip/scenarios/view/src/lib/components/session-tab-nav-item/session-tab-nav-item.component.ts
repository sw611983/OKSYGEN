/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ChangeDetectorRef, Component, effect } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseTabNavItemComponent, TabService } from '@oksygen-common-libraries/material/components';
import { EventsService, EventType, RawEvent } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { RuleService } from '@oksygen-sim-train-libraries/components-services/rules';

import { getActiveRuleEvents, SessionTabNavItem } from '../../models/session-tab-nav-item.model';
import { CSystemSimulatorHelpersService } from '../../services/csystem-simulator-helpers.service';
import { SessionLogging } from '../../logging/session-logging';

@Component({
  selector: 'oksygen-session-tab-nav-item',
  templateUrl: './session-tab-nav-item.component.html',
  styleUrls: ['./session-tab-nav-item.component.scss']
})
export class SessionTabNavItemComponent extends BaseTabNavItemComponent<SessionTabNavItem> {
  eventCount$: Observable<number>;
  events: RawEvent[] = [];
  eventSub: Subscription;

  constructor(
    private readonly cd: ChangeDetectorRef,
    public eventService: EventsService,
    private sessionLogging: SessionLogging,
    router: Router,
    tabService: TabService,
    private ruleService: RuleService,
    private cSystemSimulatorHelpersService: CSystemSimulatorHelpersService
  ) {
    super(router, tabService);

    effect(() => {
      const data = this.data();
      if (!this.eventService.getSystem(data.systemNumber)) {
        this.eventService.createSystem(data.systemNumber, this.cSystemSimulatorHelpersService.isWebServerSessionActive(data.systemNumber));
      }
      // this.eventCount$ = data.trackName$?.pipe(
      //   switchMap( trackName => {
      //     if (!this.eventService.getWorld(trackName)) { this.eventService.createWorld(trackName); }
      //     return this.eventService.activeEvents(trackName);
      //   }),
      //   map(events => Array.isArray(events) ? events.length : 0)
      // );
      this.eventCount$ = getActiveRuleEvents(
        this.eventService.activeEvents(data.systemNumber),
        this.ruleService.systemRules(data.systemNumber).pipe(map(rules => rules.filter(rule => !rule.phantom)))
      ).pipe(
        map(events =>
          Array.isArray(events) ? events.filter(e => !((e?.type === EventType.TEMPORAL || e?.type === EventType.SPATIAL) && !e?.prompt)).length : 0
        )
      );
      setTimeout(() => this.cd.markForCheck());
    });
  }
}
