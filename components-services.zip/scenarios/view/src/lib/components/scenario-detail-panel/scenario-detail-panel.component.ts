/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NGX_MAT_DATE_FORMATS, NgxMatDateFormats, NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Inject,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges
} from '@angular/core';
import { AbstractControl, FormControl, FormsModule, ReactiveFormsModule, UntypedFormControl, ValidationErrors } from '@angular/forms';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { MatError, MatFormField, MatLabel, MatPrefix } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { BehaviorSubject, combineLatest, Observable, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

import { momentToString, NGX_DATE_TIME_FORMAT, shareReplayOne, UNKNOWN } from '@oksygen-common-libraries/common';
import {
  AutocompleteInputType,
  CustomDatePipe,
  errorStateMatcher,
  illegalNameCharacterExists,
  InputError,
  newFormControl,
  OksygenMaterialComponentsModule,
  UpdateOn,
  validateMandatoryString,
  validateUniqueString
} from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { Registry } from '@oksygen-common-libraries/pio';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import {
  Scenario,
  ScenarioService,
  ScenarioSummaryData,
  scenarioToScenarioSummaryData
} from '@oksygen-sim-train-libraries/components-services/scenarios';
import { Skin } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ScenarioDetailRuleListComponent } from '../scenario-detail-rule-list/scenario-detail-rule-list.component';
import { ScenarioDetailTrainListComponent } from '../scenario-detail-train-list/scenario-detail-train-list.component';

export const MY_DATE_FORMATS: NgxMatDateFormats = {
  parse: {
    dateInput: NGX_DATE_TIME_FORMAT
  },
  display: {
    dateInput: NGX_DATE_TIME_FORMAT,
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'dd',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};

@Component({
  selector: 'oksygen-scenario-detail-panel',
  templateUrl: './scenario-detail-panel.component.html',
  styleUrls: ['./scenario-detail-panel.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatIcon,
    MatSlideToggle,
    FormsModule,
    MatFormField,
    MatInput,
    MatLabel,
    MatPrefix,
    MatError,
    ReactiveFormsModule,
    NgxMatDatetimePickerModule,
    ScenarioDetailRuleListComponent,
    ScenarioDetailTrainListComponent,
    OksygenMaterialComponentsModule,
    OksygenMaterialTranslateModule
  ],
  providers: [
    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    { provide: NGX_MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS }
  ]
})
export class ScenarioDetailPanelComponent implements OnInit, OnChanges, OnDestroy {
  readonly UNKNOWN = UNKNOWN;

  @Input() scenario$!: Observable<Scenario>;
  @Input() savedScenarioName$: Observable<string>;
  @Input() summaryData: ScenarioSummaryData = null;
  @Input() showTrains = false;
  @Input() showRules = false;
  @Input() showStatus = false;
  @Input() showAssessment = false;
  @Input() showInPreviewVisible = false;
  @Input() disableStatus = false;
  @Input() edit = false;
  @Input() worldSelectionLocked: false;
  @Input() availableWorlds$: Observable<Array<string>>;
  @Input() availableSkins$: Observable<Array<Skin>>;
  @Input() toolbox = true;
  @Input() showInPreviewDisabled$: Observable<boolean>;
  @Input() showSubHeader = true;
  @Input() showInPreview$: Observable<boolean>;

  // initialise this, so we don't always have to supply it
  @Input() sessionStartTime$: Observable<string> = new BehaviorSubject<string>(null).pipe(shareReplayOne());

  @Input() hideStatusSection = false;

  @Input() triggerFormValidation$?: Observable<void>;

  @Output() readonly targetScoreUpdated = new EventEmitter<number>();
  @Output() readonly initialScoreUpdated = new EventEmitter<number>();
  @Output() readonly nameUpdated = new EventEmitter<string>();
  @Output() readonly descriptionUpdated = new EventEmitter<string>();
  @Output() readonly subjectUpdated = new EventEmitter<string>();
  @Output() readonly worldSelected = new EventEmitter<string>();
  @Output() readonly skinSelected = new EventEmitter<string>();
  @Output() readonly dateTimeSelected = new EventEmitter<string>();
  @Output() readonly showInPreviewChanged = new EventEmitter<boolean>();
  @Output() readonly disableSave = new EventEmitter<boolean>();
  @Output() readonly scenarioAssessmentChanged = new EventEmitter<boolean>();
  @Output() readonly scenarioActivationStatusChanged = new EventEmitter<boolean>();

  scenario: Scenario;
  showSubject: boolean;
  availableWorlds: Array<string> = [];
  availableSkins: Array<string> = [];
  startTime: string;
  showInPreview = false;

  createdAt: string = this.UNKNOWN;
  modifedAt: string = this.UNKNOWN;

  private subscriptions = new Subscription();

  nameControl: UntypedFormControl;
  initialScoreControl: UntypedFormControl;
  targetScoreControl: UntypedFormControl;
  descriptionControl: UntypedFormControl;
  subjectControl: UntypedFormControl;
  worldControl = newFormControl(); // for value monitoring
  worldInputControl: UntypedFormControl; // for value validation
  skinControl = newFormControl(); // for value monitoring
  skinInputControl: UntypedFormControl; // for value validation

  worldControlErrors: InputError[] = [{ type: 'missing', text: t('A world is required.') }];

  skinControlErrors: InputError[] = [{ type: 'missing', text: t('An appearance is required.') }];

  matcher = errorStateMatcher;

  autocompleteInputType = AutocompleteInputType.FORM_FIELD;

  private existingScenarioNames: Array<string> = [];
  private originalScenarioName: string;

  private nameError = false;
  private worldError = false;
  private skinError = false;

  constructor(
    private userService: UserService,
    private scenarioService: ScenarioService,
    private registry: Registry,
    private datePipe: CustomDatePipe,
    @Inject(MAT_DATE_FORMATS) public data: any,
    private cd: ChangeDetectorRef
  ) {
    this.data.display.dateInput = this.datePipe.dateFormat + ' ' + this.datePipe.hoursFormat;
  }

  ngOnInit(): void {
    this.parseFieldConfig();

    this.initialScoreControl = new FormControl<number>(this.scenario?.initialScore || 0);
    this.targetScoreControl = new FormControl<number>(this.scenario?.targetScore || 0);

    this.nameControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;

      this.nameError = false;

      if (this.edit) {
        result = validateUniqueString(control.value, this.existingScenarioNames, this.originalScenarioName);

        if (!result && control.value?.trim() !== control.value) {
          result = { spaces: true };
        } else {
          if (illegalNameCharacterExists(control.value)) {
            return { specialCharacter: true };
          }
        }

        this.nameError = result !== null; // error if the result is not null

        this.tryDisableSave();
      }

      return result;
    });

    this.skinInputControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;

      this.skinError = false;

      if (this.edit && !this.worldError && this.availableSkins?.length > 0) {
        result = validateMandatoryString(control.value);

        this.skinError = result !== null; // error if the result is not null

        this.tryDisableSave();
      }

      return result;
    });

    this.worldInputControl = newFormControl(UpdateOn.CHANGE, (control: AbstractControl): ValidationErrors | null => {
      let result: ValidationErrors = null;

      this.worldError = false;

      if (this.edit) {
        result = validateMandatoryString(control.value);

        this.worldError = result !== null; // error if the result is not null

        this.tryDisableSave();
      }

      return result;
    });

    this.descriptionControl = new FormControl<string | null>('');
    this.subjectControl = new FormControl<string | null>('');

    if (this.edit) {
      this.subscriptions.add(this.targetScoreControl.valueChanges.subscribe(s => this.targetScoreUpdated.emit(s)));
      this.subscriptions.add(this.initialScoreControl.valueChanges.subscribe(s => this.initialScoreUpdated.emit(s)));
      this.subscriptions.add(this.nameControl.valueChanges.subscribe(s => this.nameUpdated.emit(s)));
      this.subscriptions.add(this.worldControl.valueChanges.subscribe(s => this.worldSelected.emit(s)));
      this.subscriptions.add(this.skinControl.valueChanges.subscribe(s => this.skinSelected.emit(s)));
      this.subscriptions.add(this.descriptionControl.valueChanges.subscribe(s => this.descriptionUpdated.emit(s)));
      this.subscriptions.add(this.subjectControl.valueChanges.subscribe(s => this.subjectUpdated.emit(s)));
    }

    this.subscriptions.add(
      this.initialScoreControl.valueChanges.subscribe(value => {
        if (this.scenario) {
          this.scenario.initialScore = value;
          this.initialScoreUpdated.emit(value);
        }
      }
    ));

    this.subscriptions.add(
      this.targetScoreControl.valueChanges.subscribe(value => {
        if (this.scenario) {
          this.scenario.targetScore = value;
          this.targetScoreUpdated.emit(value);
        }
      }
    ));

    this.subscriptions.add(
      this.scenarioService.data().subscribe(scenarios => {
        this.existingScenarioNames = [];
        scenarios?.forEach(s => this.existingScenarioNames.push(s.name));
      })
    );

    this.subscriptions.add(
      combineLatest([this.scenario$, this.sessionStartTime$])
        .pipe(filter(([s, st]) => !!s))
        .subscribe(([s, sessionStartTime]) => {
          this.scenario = s;

          if (this.edit) {
            this.subscriptions.add(this.savedScenarioName$.subscribe(scenarioName => (this.originalScenarioName = scenarioName)));
          }

          if (!this.summaryData && !!s) {
            this.summaryData = scenarioToScenarioSummaryData(this.userService, s);
            this.updateCreatedModified();
          }

          this.worldControl.setValue(s?.tracknetworkName);
          this.nameControl.setValue(s?.name);
          this.updateSkinControl();
          this.descriptionControl.setValue(s?.scenarioDescription);
          this.subjectControl.setValue(s?.subject);

          if (this.initialScoreControl.pristine) {
            this.initialScoreControl.setValue(s?.initialScore ?? 0, { emitEvent: false });
          }
          if (this.targetScoreControl.pristine) {
            this.targetScoreControl.setValue(s?.targetScore ?? 0, { emitEvent: false });
          }

          // We seem to have to set the date to null and then to the new value for the date picker to see the update,
          // otherwise the time fields will not update correctly.
          this.startTime = null;
          setTimeout(() => {
            this.startTime = sessionStartTime ?? s?.scenarioStartTime;
            this.cd.markForCheck();
          });
        })
    );

    this.subscriptions.add(
      this.availableWorlds$?.subscribe(w => {
        this.availableWorlds = w;
      })
    );

    this.subscriptions.add(
      this.availableSkins$?.subscribe(s => {
        // Note that the autocomplete field misbehaves when using formcontrols holding non-string objects.
        // When it is populated programatically, it remains blank.
        // TODO investigate when there aren't quite so many fires to fight.
        this.availableSkins = s.map(sk => sk.name);
        this.updateSkinControl();
      })
    );

    this.subscriptions.add(
      this.triggerFormValidation$?.subscribe(() => {
        if (this.edit) {
          this.worldInputControl.markAsTouched();
          this.skinInputControl.markAsTouched();
        }
      })
    );

    this.subscriptions.add(this.showInPreview$?.subscribe(showInPreview => (this.showInPreview = showInPreview)));
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.summaryData) {
      this.updateCreatedModified();
    }
    setTimeout(() => this.cd.markForCheck());
  }

  private tryDisableSave(): void {
    this.disableSave.emit(this.nameError || this.worldError || this.skinError);
  }

  convertDate(date: any, hourFormat: any): string {
    return this.datePipe.transform(date, hourFormat);
  }

  updateCreatedModified(): void {
    if (this.summaryData?.created?.date) {
      this.createdAt = this.convertDate(this.summaryData?.created?.date, false);
    } else {
      this.createdAt = this.UNKNOWN;
    }
    if (this.summaryData?.modified?.date) {
      this.modifedAt = this.convertDate(this.summaryData?.modified?.date, false);
    } else {
      this.modifedAt = this.UNKNOWN;
    }
  }

  updateSkinControl(): void {
    if (this.scenario && this.availableSkins && this.availableSkins.length > 0) {
      this.skinControl.setValue(this.availableSkins.find(s => s === this.scenario.tracknetworkSkinName));
      if (this.availableSkins.length === 1) {
        // if there is only one available, display it by default
        this.skinControl.setValue(this.availableSkins[0]);
      }
    } else if (this.edit) {
      if (this.availableSkins?.length === 1) {
        // default the skin, if there is only one available
        this.skinControl.setValue(this.availableSkins[0]);
      } else {
        this.skinControl.markAsDirty();
      }
    }
    this.skinInputControl.updateValueAndValidity(); // Trigger validation for appearance field
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  echo(o: any): any {
    return o;
  }

  selectWorld(trackName: string): void {
    this.worldControl.setValue(trackName);
    //Reset the SkinValue
    this.skinControl.setValue(null);
    this.skinInputControl.updateValueAndValidity(); // Trigger validation for appearance field
    //this.worldSelected.emit(trackName);
  }

  selectSkin(skinName: string): void {
    this.skinSelected.emit(skinName);
  }

  selectTime(time: string): void {
    this.dateTimeSelected.emit(time);
  }

  momentToString(time: moment.Moment): string {
    return momentToString(time);
  }

  showInPreviewChange(checked: boolean): void {
    this.showInPreview = checked;
    this.showInPreviewChanged.emit(checked);
  }

  scenarioAssessmentChange(checked: boolean): void {
    this.scenarioAssessmentChanged.emit(checked);
  }

  scenarioActivationStatusChange(checked: boolean): void {
    this.scenarioActivationStatusChanged.emit(checked);
  }

  /**
   * Check the registry for which additional fields to render.
   * At this stage only 'subject' is supported.
   */
  private parseFieldConfig(): void {
    const config = this.registry.getObject(['editor', 'scenario'], { additionalFields: [] });
    if (config?.additionalFields?.length) {
      this.showSubject = !!config.additionalFields.find(f => f === 'subject');
    }
  }
}
