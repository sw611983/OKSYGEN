/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import moment from 'moment';
import { BehaviorSubject } from 'rxjs';

import { PUBLISHED_STATUS } from '@oksygen-common-libraries/common';
import { XmlJsonUtil } from '@oksygen-common-libraries/data-access';
import { DataAccessServiceDataKey } from '@oksygen-common-libraries/data-access/testing';
import { IconFieldComponent } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectTypeDataService } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { Scenario, ScenarioService } from '@oksygen-sim-train-libraries/components-services/scenarios';
import {
  configureSimTrainTestingModule,
  createTestScenario,
  createTestScenarioXml
} from '@oksygen-sim-train-libraries/components-services/testing';

import { ScenarioDetailTrainListComponent } from '../scenario-detail-train-list/scenario-detail-train-list.component';
import { ScenarioDetailPanelComponent } from './scenario-detail-panel.component';

describe('ScenarioDetailPanelComponent', () => {
  const scenario = createTestScenario();
  const scenarioXml = createTestScenarioXml();

  let component: ScenarioDetailPanelComponent;
  let fixture: ComponentFixture<ScenarioDetailPanelComponent>;

  beforeEach(waitForAsync(() => {
    configureSimTrainTestingModule(
      {
        imports: [ScenarioDetailTrainListComponent, ScenarioDetailPanelComponent, IconFieldComponent]
      },
      undefined,
      new Map<DataAccessServiceDataKey, any>([
        [{ query: 'get_scenario_details', parameters: { id: scenario.id, scenario_id: null } }, XmlJsonUtil.convertObjectToXml(scenarioXml, 'scenario')],
        [
          { query: 'get_scenario_details', parameters: { id: null, scenario_id: scenario.scenarioId } },
          XmlJsonUtil.convertObjectToXml(scenarioXml, 'scenario')
        ],
        [{ query: 'get_scenario_list' }, XmlJsonUtil.convertObjectToXml({ scenario: [scenarioXml] }, 'scenarios')]
      ])
    ).compileComponents();
    const objectTypeDataService = TestBed.inject(ObjectTypeDataService);
    objectTypeDataService.reloadData();

    const scenarioService = TestBed.inject(ScenarioService);
    scenarioService.reloadData();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScenarioDetailPanelComponent);
    component = fixture.componentInstance;

    component.scenario$ = new BehaviorSubject<Scenario>(scenario);
    component.sessionStartTime$ = new BehaviorSubject<string>(scenario.scenarioStartTime);
    component.summaryData = {
      id: scenario.id,
      name: scenario.name,
      description: scenario.scenarioDescription,
      world: scenario.tracknetworkName,
      train: {
        name: 'Test',
        type: 'Test'
      },
      created: {
        name: 'Test',
        avatar: null,
        date: moment()
      },
      modified: {
        name: 'Test',
        avatar: null,
        date: moment()
      },
      version: scenario.version?.toString(),
      status: PUBLISHED_STATUS,
      scenarioIsActive: scenario.scenarioIsActive
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
