/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, Renderer2, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { MatIcon } from '@angular/material/icon';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { MatSliderDragEvent } from '@angular/material/slider';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { filterTruthy } from '@oksygen-common-libraries/common';
import { Environment } from '@oksygen-sim-train-libraries/components-services/world-environment';

import { SessionContextSupplier } from '../../contexts/session-context.supplier';

/**
 * Holds all the state for an environmental slider.
 * Not exported as this is just for this component - we instead output Environments to the store.
 */
interface EnvironmentPropertyControl {
  icon: string;
  key?: EnvironmentProperty;
  tooltip: string;
  /**
   * This holds the current server value. Control.value holds the displayed value on the UI itself.
   */
  value: number;
  control: UntypedFormControl;
  dragged: boolean;
}

/**
 * Providing typings for the environment options we can change. IE fog, haze, rain etc.
 */
export type EnvironmentProperty =
  | 'cloudDensityPercentage'
  | 'fogPercentage'
  | 'hazePercentage'
  | 'lightningPercentage'
  | 'rainPercentage'
  | 'snowPercentage'
  // | 'sunBrightnessPercentage'
  | 'sunGlarePercentage'
  | 'windDirectionAngle'
  | 'windGust'
  | 'windStrengthKmH'
  | 'tunnelSmokePercentage';

export interface EnvironmentEditorService {
  getEnvironmentState$: () => Observable<Map<EnvironmentProperty, number>>;
  setEnvironmentState: (prop: EnvironmentProperty, value: number) => void;
  showInPreview$: () => Observable<boolean>;
}

@Component({
  selector: 'oksygen-environment-controls',
  templateUrl: './environment-controls.component.html',
  styleUrls: ['./environment-controls.component.scss']
})
export class EnvironmentControlsComponent implements OnInit, OnDestroy {
  @Input() environmentService: EnvironmentEditorService;
  @Input() showInPreviewEnabled = false;
  @Input() showInPreviewDisabled$: Observable<boolean>;
  @Input() isEditor = false;

  @Output() readonly showInPreviewChanged = new EventEmitter<boolean>();

  @ViewChild('windIcon') windIcon: MatIcon;

  envControls: Map<EnvironmentProperty, EnvironmentPropertyControl>;

  /**
   * This one is seperate because its functionality is a little different. ticks, extra (rotating!) icon, different min / max.
   */
  windAngleControl: EnvironmentPropertyControl;
  lightningControl: EnvironmentPropertyControl;
  subscription = new Subscription();

  showInPreview = false;

  disabled = false;

  /**
   * TODO this does not account for errors or infinite loads.
   */
  loading = true;
  /**
   * this only really exists to hook up the controls to our form in the HTML. Use envControls to access these!
   */
  public environmentForm: UntypedFormGroup;

  constructor(
    private readonly contextSupplier: SessionContextSupplier,
    private readonly renderer: Renderer2,
    private readonly formBuilder: UntypedFormBuilder
  ) {}

  ngOnInit(): void {
    setTimeout(() => {
      this.initialiseForm({
        cloudDensityPercentage: 0,
        fogPercentage: 0,
        hazePercentage: 0,
        lightningPercentage: 0,
        rainPercentage: 0,
        snowPercentage: 0,
        sunBrightnessPercentage: 0,
        sunGlarePercentage: 0,
        tunnelSmokePercentage: 0,
        windDirectionAngle: 0,
        windGust: 0,
        windStrengthKmH: 0
      });
      this.loading = false;
    }, 0);

    this.subscription.add(this.environmentService.getEnvironmentState$()
      .subscribe(e => {
        if (this.loading && e) {
          const env: Environment = {};

          e?.forEach((v, k) => {
            env[k] = 0;
          });

          setTimeout(() => {
            this.initialiseForm(env);
            this.loading = false;
          }, 0);
        }

        // Ensures the update is reflected by the sliders (particularly when the component is first viewed)
        // TODO Is this is the best way to ensure the sliders are up to date?
        setTimeout(() => {
          e?.forEach((v, k) => {
            this.updateSliderServer(k, v);
          });
        }, 0);
      }));

      this.subscription.add(this.environmentService.showInPreview$()?.subscribe(showInPreview => (this.showInPreview = showInPreview)));

      this.subscription.add(
        this.contextSupplier
          .currentContext$()
          .pipe(
            filterTruthy(),
            switchMap(m => combineLatest([m.data$, m.isSimulation$]))
          )
          .subscribe(([s, isSimulation]) => {
            this.disabled = this.isEditor ? false : s?.assessment ?? !isSimulation; // if in the editor, always be enabled

            if (this.disabled) {
              this.environmentForm?.disable();
            } else {
              this.environmentForm?.enable();
            }
          })
      );
    }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  /**
   * Creates the form holding our environment data and the controls themselves.
   * You can supply some initial values.
   *
   * @param initEnv initial values for our environmental settings
   */
  initialiseForm(initEnv?: Environment): void {
    const cloudDensityPercentage = this.formBuilder.control(initEnv?.cloudDensityPercentage || 0);
    const fogPercentage = this.formBuilder.control(initEnv?.fogPercentage || 0);
    const hazePercentage = this.formBuilder.control(initEnv?.hazePercentage || 0);
    const lightningPercentage = this.formBuilder.control(initEnv?.lightningPercentage ? 100 : 0);
    const rainPercentage = this.formBuilder.control(initEnv?.rainPercentage || 0);
    const snowPercentage = this.formBuilder.control(initEnv?.snowPercentage || 0);
    // const sunBrightnessPercentage = this.formBuilder.control(initEnv?.sunBrightnessPercentage || 0);
    const sunGlarePercentage = this.formBuilder.control(initEnv?.sunGlarePercentage || 0);
    const windDirectionAngle = this.formBuilder.control(initEnv?.windDirectionAngle || 0);
    const windStrengthKmH = this.formBuilder.control(initEnv?.windStrengthKmH || 0);
    this.environmentForm = new UntypedFormGroup({
      cloudDensityPercentage,
      fogPercentage,
      hazePercentage,
      lightningPercentage, // we'll actually use this as a toggle rather than a slider. So 0 or 100, rather than 0-100.
      rainPercentage,
      snowPercentage,
      // sunBrightnessPercentage,
      sunGlarePercentage,
      windDirectionAngle,
      windStrengthKmH
    });

    if (this.disabled) {
      this.environmentForm?.disable();
    } else {
      this.environmentForm?.enable();
    }

    this.windAngleControl = this.genEnvControl('wind_direction', t('Wind direction'), windDirectionAngle);
    this.windAngleControl.key = 'windDirectionAngle';
    this.lightningControl = this.genEnvControl('lightning', t('Lightning'), lightningPercentage);
    this.lightningControl.key = 'lightningPercentage';
    this.envControls = new Map();
    // this.envControls.set('sunBrightnessPercentage', this.genEnvControl('brightness', t('Sun brightness'), sunBrightnessPercentage));
    this.envControls.set('sunGlarePercentage', this.genEnvControl('sun_glare', t('Sun glare'), sunGlarePercentage));
    this.envControls.set('hazePercentage', this.genEnvControl('haze', t('Haze'), hazePercentage));
    this.envControls.set('cloudDensityPercentage', this.genEnvControl('clouds', t('Cloud density'), cloudDensityPercentage));
    this.envControls.set('rainPercentage', this.genEnvControl('rain', t('Rain'), rainPercentage));
    this.envControls.set('fogPercentage', this.genEnvControl('fog', t('Fog'), fogPercentage));
    this.envControls.set('snowPercentage', this.genEnvControl('snow', t('Snow'), snowPercentage));
    this.envControls.set('windStrengthKmH', this.genEnvControl('wind_speed', t('Wind'), windStrengthKmH));
    this.updateAllControlsData(initEnv);
  }

  /**
   * Updates all environment settings to the supplied.
   * Note this is an update and not a patch!!!
   */
  updateAllControlsData(environment: Environment): void {
    const keys = Object.keys(environment);
    for (const envKey of keys) {
      const controlMap = this.envControls.get(envKey as EnvironmentProperty);
      if (!controlMap) {
        continue;
      }
      controlMap.control.setValue((environment as any)[envKey]);
      controlMap.value = (environment as any)[envKey];
    }
    this.windAngleControl.value = environment.windDirectionAngle;
    this.windAngleControl.control.setValue(environment.windDirectionAngle);
    this.lightningControl.value = environment.lightningPercentage;
    this.lightningControl.control.setValue(environment.lightningPercentage);
  }

  updateSliderServer(name: EnvironmentProperty, newValue: number): void {
    const envMap = this.envControls.get(name);
    if (envMap) {
      envMap.value = newValue;
      if (!envMap.dragged) {
        // touched if it's currently being dragged
        envMap.control.setValue(newValue);
      }
    }
    else if(name === 'windDirectionAngle') //Case of WindDirection
    {
      this.windAngleControl.value = newValue;
      if (!this.windAngleControl.dragged) {
        // touched if it's currently being dragged
        this.windAngleControl.control.setValue(newValue);
      }
    }
    else if(name === 'lightningPercentage') //Case of slide toggle for lightning
    {
      this.lightningControl.value = newValue;
      if (!this.lightningControl.dragged) {
        // touched if it's currently being dragged
        this.lightningControl.control.setValue(newValue);
      }
    }
  }

  onDragEndWindDirection($event: MatSliderDragEvent): void {
    this.windAngleControl.value = $event.value;
    this.windAngleControl.dragged = true;
    this.environmentService.setEnvironmentState('windDirectionAngle', $event.value);
  }

  onDragWindDirection($event: number): void {
    this.windAngleControl.control.setValue($event);
    this.windAngleControl.dragged = false;
  }

  /**
   * Wind direction is from 0 - 360 degrees, where 0 is due North, 90 is East etc.
   * These labels are 1-2 chars, ie N, SW, NE etc.
   */
  windDirectionLabel(value: number): string {
    if (value < 22.5 || value >= 337.5) return t('N');
    if (value < 67.5 && value >= 22.5) return t('NE');
    if (value < 112.5 && value >= 67.5) return t('E');
    if (value < 157.5 && value >= 112.5) return t('SE');
    if (value < 202.5 && value >= 157.5) return t('S');
    if (value < 247.5 && value >= 202.5) return t('SW');
    if (value < 292.5 && value >= 247.5) return t('W');
    // otherwise (value < 337.5 && value > 292.5)
    return t('NW');
  }

  sliderChanged(env: { key: EnvironmentProperty | string; value: EnvironmentPropertyControl }, change: number): void {
    // when we finish dragging, set the value to what the server thinks it should be.
    // env.value.control.setValue(env.value.value);
    env.value.dragged = false;
  }

  /**
   * We update the server on slider drag. This happens via an effect on the store.
   */
  sliderDrag(change: MatSliderDragEvent, control: { key: EnvironmentProperty | string; value: EnvironmentPropertyControl }): void {
    const environment: any = {};
    environment[control.key] = change.value;
    control.value.dragged = true;
    this.environmentService.setEnvironmentState(control.key as EnvironmentProperty, change.value);
  }

  toggleLightning(change: MatSlideToggleChange): void {
    const key = 'lightningPercentage';
    const value = change.checked ? 100 : 0; // lightning is all or nothing baby, fear the thunder god
    this.environmentService.setEnvironmentState(key as EnvironmentProperty, value);
  }

  toggleLightningInput(control: EnvironmentPropertyControl): void {
    this.lightningControl.value = control.value;
    this.lightningControl.dragged = true;
    this.environmentService.setEnvironmentState(control.key, control.value);
  }

  showInPreviewChange(checked: boolean): void {
    this.showInPreview = checked;

    this.showInPreviewChanged.emit(checked);
  }

  /**
   * Helper method to create an EnvironmentControl.
   * Note that the value property will be set to the control.value.
   */
  private genEnvControl(icon: string, tooltipText: string, control: UntypedFormControl): EnvironmentPropertyControl {
    return { icon, tooltip: tooltipText, value: control.value, control, dragged: false };
  }
}
