/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BehaviorSubject, Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { EnvironmentControlsComponent, EnvironmentProperty } from './environment-controls.component';

describe('EnvironmentControlsComponent', () => {
  let component: EnvironmentControlsComponent;
  let fixture: ComponentFixture<EnvironmentControlsComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [EnvironmentControlsComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(EnvironmentControlsComponent);
    component = fixture.componentInstance;
    component.environmentService = {
      getEnvironmentState$: (): Observable<Map<EnvironmentProperty, number>> => new BehaviorSubject(new Map()),
      setEnvironmentState: (x): void => {},
      showInPreview$: (): Observable<boolean> => null
    };
    fixture.detectChanges();
  });

  // enable this once we fix how environment service loads - currently it just loads when included, which is incorrect
  // it should be driven by the session
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
