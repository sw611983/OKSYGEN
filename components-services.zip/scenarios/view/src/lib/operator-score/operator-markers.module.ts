/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

import { AddOperatorMarkerDialogComponent } from './components/add-operator-marker-dialog/add-operator-marker-dialog.component';
import { OperatorMarkersDetailsPanelComponent } from './components/operator-markers-details-panel/operator-markers-details-panel.component';
import { OperatorMarkersDetailsComponent } from './components/operator-markers-details/operator-markers-details.component';
import { OperatorMarkersListComponent } from './components/operator-markers-list/operator-markers-list.component';
import { OperatorScorePanelComponent } from './components/operator-score-panel/operator-score-panel.component';
import { OperatorMarkerListItemComponent } from './components/operator-marker-list-item/operator-marker-list-item.component';
import { ScorePanelComponent } from './components/score-panel/score-panel.component';


export const operatorMarkersComponents = [
  OperatorScorePanelComponent,
  ScorePanelComponent,
  OperatorMarkersListComponent,
  OperatorMarkerListItemComponent,
  AddOperatorMarkerDialogComponent,
  OperatorMarkersDetailsComponent,
  OperatorMarkersDetailsPanelComponent
];

@NgModule({
  declarations: operatorMarkersComponents,
  imports: [
    RouterModule,
    CommonModule,
    DragDropModule,
    OksygenMaterialComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    // this is ugly to repeat everywhere, but it's the only way for this to be properly initialised
    OksygenMaterialTranslateModule.forChild(),
    OksygenSimTrainCommonModule
  ],
  exports: operatorMarkersComponents
})
export class OksygenSimTrainOperatorMarkersModule {}
