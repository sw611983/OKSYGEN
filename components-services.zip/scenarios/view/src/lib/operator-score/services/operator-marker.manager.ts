/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { filterTruthy, shareReplayOne } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { BaseDataManager } from '@oksygen-sim-core-libraries/components-services/data-services';
import { cloneDeep, omit } from 'lodash';
import { OperatorMarker } from '../models/operator-marker.model';
import { OperatorMarkerDataService } from './operator-marker-data.service';

export class OperatorMarkerManager extends BaseDataManager<OperatorMarker[]> {
  private subcriptions = new Subscription();
  private markerDataService: OperatorMarkerDataService;
  private markerSubject: BehaviorSubject<OperatorMarker[]>;
  private markers: OperatorMarker[] = [];

  private totalScoreSubject = new BehaviorSubject<number>(0);

  constructor(registry: Registry, private logger: Logging, private systemNumber: number, serverStatus$: Observable<boolean>) {
    super();
    this.markerDataService = new OperatorMarkerDataService(registry, logger, this.systemNumber, serverStatus$);
    this.markerSubject = new BehaviorSubject(null);
  }

  connect(): void {
    if (this.markerDataService.isConnected()) {
      this.logger.warn(`[MarkerManager] attempting to connect to already connected data source.`);
      return;
    }
    this.markerDataService.openConnection();

    this.subcriptions.add(
      this.markerDataService
        .data$()
        .pipe(filterTruthy())
        .subscribe(markers => this.onMarkersChange(markers))
    );
  }

  onMarkersChange(endpointMarkers: OperatorMarker[]): void {
    // const markers = cloneDeep(this.markers);
    const markers = cloneDeep(endpointMarkers);

    for (const marker of endpointMarkers) {
      const oldMarker = markers.find(m => m.id === marker.id);

      if (oldMarker) {
        this.partiallyUpdateMarker(marker, oldMarker);
      } else {
        markers.push({ ...marker });
      }
    }

    this.markers = markers;
    this.markerSubject.next(this.markers);
  }

  destroy(): void {
    this.markerDataService.destroy();
    this.subcriptions.unsubscribe();
    this.markerSubject.complete();
    this.markerSubject = null;
  }

  public markerDefinitions$(): Observable<OperatorMarker[]> {
    return this.markerSubject.asObservable();
  }

  /**
   * @deprecated
   */
  data(): Observable<OperatorMarker[]> {
    return this.data$;
  }

  get data$(): Observable<OperatorMarker[]> {
    if (!this.markerDataService.isConnected()) {
      this.connect();
    }
    return this.markerSubject.pipe(shareReplayOne());
  }

  createOperatorMarker(marker: OperatorMarker): void {
    if (!this.markerDataService.isConnected()) {
      this.connect();
    }
    this.markerDataService.createMarker(omit(marker, 'timeStamp'));
  }

  updateMarker(marker: OperatorMarker): void {
    this.markerDataService.updateMarker(marker);
  }

  deleteMarker(markerId: number): void {
    this.markerDataService.deleteMarker(markerId);
  }

  public totalScore$(): Observable<number> {
    return this.markerDataService.totalScore$();
  }

  public categoryList$(): Observable<string[]> {
    return this.markerDataService.categoryList$();
  }

  public requestCategoryList(): void {
    return this.markerDataService.getCategoryList();
  }

  // This function replaces the fields in markerToUpdate with the ones in partialMarker, except id.
  private partiallyUpdateMarker(partialMarker: OperatorMarker, markerToUpdate: OperatorMarker): void {
    for (const [key, value] of Object.entries(partialMarker) as [keyof OperatorMarker, any][]) {
      // We don't want to change the id.
      if (key === 'id') {
        continue;
      }

      if (value != null) {
        (markerToUpdate as any)[key] = value;
      }
    }
  }
}
