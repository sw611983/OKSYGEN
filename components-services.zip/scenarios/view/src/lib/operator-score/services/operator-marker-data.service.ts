/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BehaviorSubject, Observable } from 'rxjs';

import { SuperCalled, asArray } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { OperatorMarkerMessageIds, SocketMessage, SocketService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { CategoryList, OperatorMarker, OperatorMarkerDefinitions, OperatorMarkerMessages } from '../models/operator-marker.model';

/**
 * Sources your markers data for you. It will grab this data from the marker data endpoint in the registry.
 */
export class OperatorMarkerDataService extends SocketService<OperatorMarkerMessageIds, OperatorMarkerMessages> {
  private dataSubject: BehaviorSubject<OperatorMarker[]> = new BehaviorSubject(null);
  private totalScoreSubject: BehaviorSubject<number> = new BehaviorSubject(null);
  private categoryListSubject: BehaviorSubject<string[]> = new BehaviorSubject(null);


  constructor(registry: Registry, logger: Logging, systemNumber: number, serverStatus$: Observable<boolean>) {
    super(registry, logger, registry.getString(['reportData', 'url']), 'OperatorMarkerDataService', serverStatus$);
  }

  public override destroy(): SuperCalled {
    this.closeConnection();
    this.dataSubject.complete();
    this.dataSubject = null;
    return super.destroy();
  }

  public data$(): Observable<OperatorMarker[]> {
    return this.dataSubject.asObservable();
  }

  public totalScore$(): Observable<number> {
    return this.totalScoreSubject.asObservable();
  }

  public categoryList$(): Observable<string[]> {
    return this.categoryListSubject.asObservable();
  }

  public createMarker(marker: OperatorMarker): void {
    const message: SocketMessage<OperatorMarkerMessageIds, any> = {
      messageId: OperatorMarkerMessageIds.MSG_REQUEST_ADD_OPERATOR_MARKER,
      message: marker
    };
    this.socket$.next(message);
  }

  public updateMarker(marker: OperatorMarker): void {
    const message: SocketMessage<OperatorMarkerMessageIds, any> = {
      messageId: OperatorMarkerMessageIds.MSG_REQUEST_UPDATE_OPERATOR_MARKER,
      message: marker
    };
    this.socket$.next(message);
  }

  public deleteMarker(id: number): void {
    const message: SocketMessage<OperatorMarkerMessageIds, any> = {
      messageId: OperatorMarkerMessageIds.MSG_REQUEST_DELETE_OPERATOR_MARKER,
      message: { id }
    };
    this.socket$.next(message);
  }

  public getCategoryList(): void {
    const message: SocketMessage<OperatorMarkerMessageIds, any> = {
      messageId: OperatorMarkerMessageIds.MSG_GET_CATEGORY_LIST,
      message: {}
    };
    this.socket$.next(message);
  }

  protected onOpenSocket(): void {
    const message: SocketMessage<OperatorMarkerMessageIds, any> = {
      messageId: OperatorMarkerMessageIds.MSG_REQUEST_OPERATOR_MARKER_LIST,
      message: {}
    };
    this.socket$.next(message);
  }

  protected onMessage(message: SocketMessage<OperatorMarkerMessageIds, OperatorMarkerMessages | string[] | CategoryList>): void {
    try {
      if (message.messageId === OperatorMarkerMessageIds.OPERATOR_MARKER_LIST_REPONSE) {
        const operatorMarkers = asArray((message?.message as OperatorMarkerDefinitions)?.markers);
        this.dataSubject.next(operatorMarkers);
      }
      else if (message.messageId === OperatorMarkerMessageIds.OPERATOR_MARKER_COMPLETE_LIST_REPONSE) {
        const totalScoreStr = (message.message as any)?.totalScore;
        const totalScore = parseFloat(totalScoreStr ?? '0');
        this.totalScoreSubject.next(totalScore);
      }
      else if (message.messageId === OperatorMarkerMessageIds.OPERATOR_MARKER_CATEGORY_LIST) {
        const categoryList = ((message?.message as CategoryList));
        this.categoryListSubject.next(categoryList.categories);
      }
    } catch (err) {
      this.logger.log('[OperatorMarkerDataService] error on message: ', JSON.stringify(err));
    }
  }

  protected onSocketError(error: any): void {
    if (this.lastConnectionClosedClean) {
      this.logger.warn('An error occured in the marker socket: ', JSON.stringify(error));
    }
  }
}
