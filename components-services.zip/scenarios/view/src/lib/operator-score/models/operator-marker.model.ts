/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export interface OperatorMarker {
  id?: number;
  name?: string;
  description?: string;
  category?: string;
  reportMessage?: string;
  type?: number;
  timestamp?: number;
  time?: number;
  source?: string;
  points?: number;
  triggerOnce?: number;
}


export type OperatorMarkerMessages = OperatorMarkerDefinitions;

export type OperatorMarkerDefinitions = { markers: OperatorMarker[] };

export interface CategoryList {
  categories: string[];
}


