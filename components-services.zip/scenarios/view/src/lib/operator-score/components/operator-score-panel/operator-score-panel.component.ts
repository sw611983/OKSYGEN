/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, input, OnDestroy, OnInit } from '@angular/core';
import { forkJoin, Observable, Subject, Subscription } from 'rxjs';
import { filter, switchMap, take, takeUntil } from 'rxjs/operators';

import { filterTruthy, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DETAILS } from '@oksygen-sim-train-libraries/components-services/common';

import { MatDialog } from '@angular/material/dialog';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { SessionContext } from '../../../contexts/session-context';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { OperatorMarker } from '../../models/operator-marker.model';
import { AddOperatorMarkerDialogComponent } from '../add-operator-marker-dialog/add-operator-marker-dialog.component';

@Component({
  selector: 'oksygen-operator-score-panel',
  templateUrl: './operator-score-panel.component.html',
  styleUrls: ['./operator-score-panel.component.scss']
})
export class OperatorScorePanelComponent implements OnInit, OnDestroy {
  systemNumber = input.required<number>();
  uiModels = input.required<UiStateModelManager>();
  scenario$ = input.required<Observable<Scenario>>();
  private destroy$ = new Subject<void>();

  operatorMarkers$: Observable<OperatorMarker[]>;
  selectedMarker: OperatorMarker = null;
  breadcrumbChildren: ReadonlyArray<string>;
  mainSub = new Subscription();

  currentScore = 0;
  initialScore = 0;
  targetScore = 100;
  assessmentToggle = true;

  constructor(private contextSupplier: SessionContextSupplier, private logger: Logging, public readonly dialog: MatDialog) {
    effect(onCleanup => {
      this.scenario$()
        ?.pipe(
          takeUntil(this.destroy$),
          filter(scenario => !!scenario) // Only proceed when we have a scenario
        )
        .subscribe(scenario => {
          this.initialScore = scenario.initialScore ?? 0;
          this.targetScore = scenario.targetScore ?? 100;
          this.assessmentToggle = scenario.assessment ?? true;
        });
    });
  }

  ngOnInit(): void {
    this.operatorMarkers$ = this.contextSupplier.currentContext$().pipe(
      filterTruthy(),
      switchMap(m => m.operatorMarkers?.data())
    );

    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy(undefined, 200))
      .subscribe(context => {
        context.operatorMarkers.totalScore$().subscribe((score: number) => {
          this.currentScore = score ?? 0;
        });
      });

      this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy(undefined, 200))
      .subscribe(context => {
        context.operatorMarkers.requestCategoryList();
      });
  }

  ngOnDestroy(): void {
    this.mainSub.unsubscribe();
    this.destroy$.next();
    this.destroy$.complete();
  }

  displayMarkerList(): void {
    this.selectedMarker = null;
    this.updateBreadcrumbs();
  }

  selectMarker(marker: OperatorMarker): void {
    this.logger.log('selecting marker: ', marker);
    this.selectedMarker = marker;
    this.updateBreadcrumbs();
  }

  addMarker(): void {
    // TODO: Consolidate with session-top-toolbar.component.ts
    this.contextSupplier
      .currentContext$()
      .pipe(
        // FIXME magic number
        takeOneTruthy<SessionContext>(undefined, 100),
        switchMap(man => man.operatorMarkers.data()),
        take(1)
      )
      .subscribe(currentMarkers => {
        // eslint-disable-next-line max-len
        const dialog = this.dialog.open<AddOperatorMarkerDialogComponent, { systemNumber: number; currentMarkers: OperatorMarker[] }, OperatorMarker>(
          AddOperatorMarkerDialogComponent,
          {
            data: { systemNumber: this.systemNumber(), currentMarkers },
            minWidth: '600px'
          }
        );
        forkJoin([dialog.afterClosed(), this.contextSupplier.currentContext$().pipe(takeOneTruthy<SessionContext>(undefined, 100))])
          .pipe(filter(([marker, manager]) => !!marker))
          .subscribe(([marker, manager]) => manager.operatorMarkers.createOperatorMarker(marker));
      });
  }

  addPointsMarker(): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy<SessionContext>(undefined, 100), take(1))
      .subscribe(manager => {
        const predefinedMarker: OperatorMarker = {
          name: 'Quick Score Increase',
          category: 'Quick Score',
          description: 'This marker is to add 5 points',
          reportMessage: 'Increasing Score',
          type: 1, // Increase Score
          triggerOnce: 1,
          points: 5,
          timestamp: Date.now(),
          time: Date.now(),
          source: 'operator'
        };

        manager.operatorMarkers.createOperatorMarker(predefinedMarker);
      });
  }

  subtractPointsMarker(): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy<SessionContext>(undefined, 100), take(1))
      .subscribe(manager => {
        const predefinedMarker: OperatorMarker = {
          name: 'Quick Score Decrease',
          category: 'Quick Score',
          description: 'This marker is to subtract 5 points',
          reportMessage: 'Decreasing Score',
          type: 2, // Decrease Score
          triggerOnce: 1,
          points: 5,
          timestamp: Date.now(),
          time: Date.now(),
          source: 'operator'
        };

        manager.operatorMarkers.createOperatorMarker(predefinedMarker);
      });
  }

  private updateBreadcrumbs(): void {
    if (this.selectedMarker) {
      this.breadcrumbChildren = [DETAILS];
    } else {
      this.breadcrumbChildren = null;
    }
  }

  deleteMarker(markerId: number): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy(undefined, 200))
      .subscribe((manager: SessionContext) => manager.operatorMarkers.deleteMarker(markerId));

    this.displayMarkerList();
  }
}
