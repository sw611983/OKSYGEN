/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, input, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, UntypedFormGroup } from '@angular/forms';
import { calculateOperatorMarkerTime } from '../../markers-utils';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { AutocompleteInputType } from '@oksygen-common-libraries/material/components';
import { takeOneTruthy } from '@oksygen-common-libraries/common';

@Component({
  selector: 'oksygen-markers-details',
  templateUrl: './operator-markers-details.component.html',
  styleUrls: ['./operator-markers-details.component.scss']
})
export class OperatorMarkersDetailsComponent implements OnChanges {
  elapsedTime = input.required<number>();
  markerFormGroup = input.required<UntypedFormGroup>();

  readonly sliderMinValue = -30;
  minValue = -30;
  displayedMarkerTime = 0;
  autocompleteInputType = AutocompleteInputType.FORM_FIELD;

  availableCategories = ['Maintenance', 'Safety', 'Signal Issue', 'General'];
  categoryControl: any;

  markerTypes = [
    { label: 'Neutral', value: 0, icon: 'prohibit', colorClass: 'neutral-icon' },
    { label: 'Increase', value: 1, icon: 'check_circle_alt', colorClass: 'green-icon' },
    { label: 'Decrease', value: 2, icon: 'cancel_circle_alt', colorClass: 'red-icon' }
  ];
  markerControl: any;
  targetCategoryList: string[];

  markerGroup = new FormGroup({
    markerType: new FormControl(0) // default to Neutral
  });

  constructor(private contextSupplier: SessionContextSupplier) {
    this.contextSupplier
                .currentContext$()
                .pipe(takeOneTruthy(undefined, 200))
                .subscribe(context => {
                  context.operatorMarkers.categoryList$().subscribe((targetList: string[]) => {
                    this.targetCategoryList = targetList ?? [];
                  });
              });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.elapsedTime && changes.elapsedTime.currentValue !== changes.elapsedTime.previousValue) {
      this.updateSliderMinValue();
    }

    if (changes.markerFormGroup && changes.markerFormGroup.currentValue !== changes.markerFormGroup.previousValue) {
      this.categoryControl = this.markerFormGroup()?.get('category');
      this.markerControl = this.markerFormGroup()?.get('markerType');
    }

    if (this.markerFormGroup()?.value?.timeAdjust == null) {
      this.markerFormGroup().patchValue({ timeAdjust: 0 });
    }
    this.updateDisplayedTime(this.markerFormGroup()?.value?.timeAdjust || 0);
  }

  updateDisplayedTime(timeAdjust: number = 0): void {
    const markerTime = calculateOperatorMarkerTime(this.elapsedTime() || 0, timeAdjust || 0);
    this.displayedMarkerTime = Math.floor(markerTime || 0);
  }

  private updateSliderMinValue(): void {
    this.minValue = this.sliderMinValue;

    // don't allow a minValue that would allow a negative time
    if (this.minValue + this.elapsedTime() < 0) {
      this.minValue = 0 - this.elapsedTime();
    }
  }

  calculateMarkerTime(timeAdjust: number): number {
    let markerTime = this.elapsedTime() + timeAdjust;
    if (markerTime < 0) {
      markerTime = 0;
    }
    return markerTime;
  }

  onCategorySelected(selected: string): void {
    if (this.categoryControl?.value !== selected) {
      this.categoryControl?.setValue(selected);
    }
  }

  onMarkerSelected(event: any): void {
    this.markerFormGroup().get('markerType')?.setValue(event.value);
  }

  getLabel(value: number): string {
    return this.markerTypes.find(t => t.value === value)?.label ?? '';
  }

  getIcon(value: number): string {
    return this.markerTypes.find(t => t.value === value)?.icon ?? 'help';
  }

  getIconClass(value: number): string {
    return this.markerTypes.find(t => t.value === value)?.colorClass ?? '';
  }
}
