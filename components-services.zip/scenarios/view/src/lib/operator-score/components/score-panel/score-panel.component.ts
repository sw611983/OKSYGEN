/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, input } from '@angular/core';

@Component({
  selector: 'oksygen-score-panel',
  templateUrl: './score-panel.component.html',
  styleUrls: ['./score-panel.component.scss']
})
export class ScorePanelComponent {
  currentScore = input.required<number>();
  initialScore = input.required<number>();
  targetScore = input.required<number>();
  assessmentToggle = input.required<boolean>();
}
