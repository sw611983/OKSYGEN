/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, input, OnDestroy, OnInit, output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Subscription } from 'rxjs';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import { CANCEL_TEXT, PromptDialogComponent, PromptDialogData } from '@oksygen-common-libraries/material/components';
import { MaterialButtonVariant, MaterialThemePalette } from '@oksygen-common-libraries/material/theme';

import { SessionContext } from '../../../contexts/session-context';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { sourceMappingOperator } from '../../markers-utils';
import { OperatorMarker } from '../../models/operator-marker.model';

@Component({
  selector: 'oksygen-marker-list-item',
  templateUrl: './operator-marker-list-item.component.html',
  styleUrls: ['./operator-marker-list-item.component.scss']
})
export class OperatorMarkerListItemComponent implements OnInit, OnDestroy {
  operatorMarker = input.required<OperatorMarker>();

  public readonly selectedMarker = output<OperatorMarker>();

  elapsedTimeInSecs: number;
  sourceIcon: string;
  displayedSource: string;

  manager: SessionContext;
  private subscription = Subscription.EMPTY;

  constructor(private contextSupplier: SessionContextSupplier, private dialog: MatDialog) {
    effect(() => {
      this.elapsedTimeInSecs = Math.floor(this.operatorMarker()?.timestamp);
      this.updateSourceIconAndText();
    });
  }

  ngOnInit(): void {
    this.subscription = this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy(undefined, 200))
      .subscribe((manager: SessionContext) => (this.manager = manager));
  }

  updateSourceIconAndText(): void {
    const source = this.operatorMarker().source;
    if (source && Object.keys(sourceMappingOperator).includes(source)) {
      this.sourceIcon = sourceMappingOperator[source].icon;
      this.displayedSource = sourceMappingOperator[source].displayedName;
    } else {
      this.sourceIcon = 'null';
      this.displayedSource = '';
    }
  }

  onDeleteClick($event?: Event): void {
    $event.stopPropagation();

    const promptData = new PromptDialogData();
    promptData.title = t('Delete');
    promptData.content = t('Are you sure you want to delete this marker?');
    promptData.buttons = [
      {
        color: MaterialThemePalette.PRIMARY,
        text: CANCEL_TEXT,
        data: false
      },
      {
        color: MaterialThemePalette.PRIMARY,
        style: MaterialButtonVariant.BUTTON,
        text: t('Delete'),
        data: true
      }
    ];

    const dialogRef = this.dialog.open(PromptDialogComponent, {
      data: promptData,
      width: '400px',
      panelClass: 'small-whitespace-dialog'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteMarker();
      }
    });
  }

  selectMarker(feature: OperatorMarker): void {
      this.selectedMarker.emit(feature);
  }

  onEditClick($event?: Event): void {
    $event.stopPropagation();

    const promptData = new PromptDialogData();
    promptData.title = t('Delete');
    promptData.content = t('Are you sure you want to delete this marker?');
    promptData.buttons = [
      {
        color: MaterialThemePalette.PRIMARY,
        text: CANCEL_TEXT,
        data: false
      },
      {
        color: MaterialThemePalette.PRIMARY,
        style: MaterialButtonVariant.BUTTON,
        text: t('Delete'),
        data: true
      }
    ];

    const dialogRef = this.dialog.open(PromptDialogComponent, {
      data: promptData,
      width: '400px',
      panelClass: 'small-whitespace-dialog'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteMarker();
      }
    });
  }

  deleteMarker(): void {
    this.manager?.operatorMarkers?.deleteMarker(this.operatorMarker().id);
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }
}
