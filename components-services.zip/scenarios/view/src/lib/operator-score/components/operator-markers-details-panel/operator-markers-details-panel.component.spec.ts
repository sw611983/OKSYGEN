/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OperatorMarkersDetailsComponent } from '../operator-markers-details/operator-markers-details.component';
import { OperatorMarkersDetailsPanelComponent } from './operator-markers-details-panel.component';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { OksygenSimTrainSessionModule } from '@oksygen-sim-train-libraries/components-services/session';

describe('MarkersDetailsPanelComponent', () => {
  let component: OperatorMarkersDetailsPanelComponent;
  let fixture: ComponentFixture<OperatorMarkersDetailsPanelComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainSessionModule],
        declarations: [OperatorMarkersDetailsPanelComponent, OperatorMarkersDetailsComponent],
        providers: [SessionContextSupplier]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(OperatorMarkersDetailsPanelComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
