/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, effect, input, OnDestroy, OnInit, output } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Subscription } from 'rxjs';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import { CANCEL_TEXT, newFormControl, PromptDialogComponent, PromptDialogData } from '@oksygen-common-libraries/material/components';
import { MaterialButtonVariant, MaterialThemePalette } from '@oksygen-common-libraries/material/theme';

import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { calculateOperatorMarkerTime, sourceMappingOperator } from '../../markers-utils';
import { OperatorMarker } from '../../models/operator-marker.model';

@Component({
  selector: 'oksygen-markers-details-panel',
  templateUrl: './operator-markers-details-panel.component.html',
  styleUrls: ['./operator-markers-details-panel.component.scss']
})
export class OperatorMarkersDetailsPanelComponent implements OnInit, OnDestroy {
  marker = input.required<OperatorMarker>();
  public readonly deleteClick = output<number>();

  markerFormGroup: UntypedFormGroup;
  elapsedTime: number;
  elapsedTimeInSecs: number;
  sourceIcon: string;
  displayedSource: string;

  private subscription = new Subscription();

  constructor(private contextSupplier: SessionContextSupplier, private dialog: MatDialog) {
    this.markerFormGroup = new UntypedFormGroup({
      name: newFormControl(),
      markerType: newFormControl(),
      description: newFormControl(),
      points: newFormControl(),
      timeAdjust: newFormControl(),
      category: newFormControl()
    });

    effect(
      onCleanup => {
        const marker = this.marker(); // 🔁 This triggers the effect reactively!

        this.markerFormGroup.patchValue(
          {
            name: marker.name ?? '',
            description: marker.reportMessage ?? '',
            points: marker.points,
            timeAdjust: marker.time - marker.timestamp,
            markerType: marker.type,
            category: marker.category
          },
          { emitEvent: false }
        );

        this.elapsedTimeInSecs = Math.floor(marker.timestamp);
        this.elapsedTime = marker.timestamp ?? 0;
        this.updateSourceIconAndText(marker);
        onCleanup(() => {
          this.subscription.unsubscribe();
        });
      },
      { allowSignalWrites: true }
    );
  }

  ngOnInit(): void {
    this.subscription = this.markerFormGroup.statusChanges.subscribe(() => {
      const formValue = this.markerFormGroup.value;
      const timeAdjust = formValue.timeAdjust ? formValue.timeAdjust : 0;
      const markerTime = calculateOperatorMarkerTime(this.elapsedTime, timeAdjust);

      const updatedMarker: OperatorMarker = {
        id: this.marker().id,
        name: formValue.name ?? '',
        description: formValue.description ?? '',
        reportMessage: formValue.description ?? '',
        category: formValue.category ?? '',
        points: +formValue.points,
        time: markerTime || 0,
        timestamp: markerTime || 0,
        type: formValue.markerType ?? 0,
        triggerOnce: 1
      };

      this.contextSupplier
        .currentContext$()
        .pipe(takeOneTruthy())
        .subscribe(manager => {
          manager.operatorMarkers.updateMarker(updatedMarker);
        });

      this.elapsedTimeInSecs = Math.floor(updatedMarker.timestamp);
      this.updateSourceIconAndText(updatedMarker);
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  updateSourceIconAndText(marker: OperatorMarker): void {
    const source = marker.source;

    if (source && Object.keys(sourceMappingOperator).includes(source)) {
      this.sourceIcon = sourceMappingOperator[source].icon;
      this.displayedSource = sourceMappingOperator[source].displayedName;
    } else {
      this.sourceIcon = 'null';
      this.displayedSource = '';
    }
  }

  onDeleteClick($event?: Event): void {
    $event.stopPropagation();

    const promptData = new PromptDialogData();
    promptData.title = t('Delete');
    promptData.content = t('Are you sure you want to delete this marker?');
    promptData.buttons = [
      {
        color: MaterialThemePalette.PRIMARY,
        text: CANCEL_TEXT,
        data: false
      },
      {
        color: MaterialThemePalette.PRIMARY,
        style: MaterialButtonVariant.BUTTON,
        text: t('Delete'),
        data: true
      }
    ];

    const dialogRef = this.dialog.open(PromptDialogComponent, {
      data: promptData,
      width: '400px',
      panelClass: 'small-whitespace-dialog'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteClick.emit(this.marker().id);
      }
    });
  }
}
