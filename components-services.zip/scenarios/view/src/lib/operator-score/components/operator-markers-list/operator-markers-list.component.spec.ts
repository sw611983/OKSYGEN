/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { OperatorMarkersListComponent } from './operator-markers-list.component';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';

describe('MarkersListComponent', () => {
  let component: OperatorMarkersListComponent;
  let fixture: ComponentFixture<OperatorMarkersListComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [OperatorMarkersListComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(OperatorMarkersListComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('uiModels', new UiStateModelManager());
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
