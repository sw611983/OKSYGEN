/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, effect, input, OnDestroy, output } from '@angular/core';
import { Observable, Subscription } from 'rxjs';

import { asArray } from '@oksygen-common-libraries/common';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { OperatorMarker } from '../../models/operator-marker.model';

@Component({
  selector: 'oksygen-markers-list',
  templateUrl: './operator-markers-list.component.html',
  styleUrls: ['./operator-markers-list.component.scss']
})
export class OperatorMarkersListComponent implements  OnDestroy {
  operatorMarkers$ = input.required<Observable<OperatorMarker[]>>();
  uiModels = input.required<UiStateModelManager>();

   public readonly addMarker = output<void>();
   public readonly addPointsMarker = output<void>();
   public readonly subtractPointsMarker = output<void>();
   public readonly selectMarker = output<OperatorMarker>();

  operatorMarkers: OperatorMarker[] = [];

  markerTags: { tag: string; icon: string; displayedName: string }[];
  endlessScrollBottomVisible = false;

  private subscription = new Subscription();

  constructor() {
     effect(onCleanup => {
       const subscription = this.operatorMarkers$().subscribe(operatorMarkers => {
         this.operatorMarkers = asArray(operatorMarkers);
         this.operatorMarkers = this.operatorMarkers.map(m => ({ ...m }));
       });
       onCleanup(() => {
         subscription?.unsubscribe();
       });
     });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  selectedMarker(feature: OperatorMarker): void {
    this.selectMarker.emit(feature);
  }
}
