/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs/operators';

import { newFormControl, newOptionalFormControl } from '@oksygen-common-libraries/material/components';
import { CSystemSimulatorHelpersService } from '../../../services/csystem-simulator-helpers.service';
import { calculateOperatorMarkerTime, getDefaultOperatorMarkerName } from '../../markers-utils';
import { OperatorMarker } from '../../models/operator-marker.model';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { takeOneTruthy } from '@oksygen-common-libraries/common';
import { SessionContext } from '../../../contexts/session-context';

@Component({
  templateUrl: './add-operator-marker-dialog.component.html',
  styleUrls: ['./add-operator-marker-dialog.component.scss']
})
export class AddOperatorMarkerDialogComponent implements OnInit {
  markerFormGroup: UntypedFormGroup;
  elapsedTime: number;

  constructor(
    public dialogRef: MatDialogRef<AddOperatorMarkerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { systemNumber: number; currentMarkers: OperatorMarker[] },
    private cSystemSimulatorHelpersService: CSystemSimulatorHelpersService,
    private contextSupplier: SessionContextSupplier
  ) {
    }

  ngOnInit(): void {
    const name = getDefaultOperatorMarkerName(this.data.currentMarkers);

    this.markerFormGroup = new UntypedFormGroup({
      name: newFormControl(),
      description: newOptionalFormControl(),
      category:newFormControl(),
      reportMessage: newOptionalFormControl(),
      markerType: newFormControl(),
      points: newFormControl(),
      timeAdjust: newFormControl()
    });

    this.markerFormGroup.setValue({
      name,
      description: '',
      category: '' ,
      reportMessage: '',
      markerType: 0,
      points: 0,
      timeAdjust: 0
    });

    this.cSystemSimulatorHelpersService
      .sessionStatus$(this.data.systemNumber)
      .pipe(take(1))
      .subscribe(sessionStatus => {
        this.elapsedTime = Math.floor(sessionStatus?.time) || 0;
      });
  }

  onAddClick(): void {
    const formValue = this.markerFormGroup.value;
    const markerTime = calculateOperatorMarkerTime(this.elapsedTime, formValue.timeAdjust);

    const marker: OperatorMarker = {
      name: formValue.name,
      description: formValue.description,
      reportMessage: formValue.description,
      category: formValue.category,
      type: formValue.markerType,
      triggerOnce: 1,
      points: Number(formValue.points),
      timestamp: markerTime,
      time: this.elapsedTime
    };

    this.dialogRef.close(marker);
  }

  onCancelClick(): void {
    this.dialogRef.close();
  }
}
