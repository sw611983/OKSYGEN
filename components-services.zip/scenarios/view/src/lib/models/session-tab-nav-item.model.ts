/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RawEvent, RuleItem } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { IconState } from '@oksygen-sim-train-libraries/components-services/common';
import { combineLatest, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { SESSIONS_DATA } from './session-setup.model';
import { BaseTabGroupChildData, TabGroupChild } from '@oksygen-common-libraries/material/components';

export interface SessionTabNavItem extends BaseTabGroupChildData {
  routerLink: string;
  systemNumber: number;
  traineeId: string;
  traineeName: string;
  scenarioId: number;
  scenarioName: string;
  autonomous: boolean;
  alert: IconState;
  sessionState: IconState;
  isLoading?: boolean;
}

/**
 * Sorts session tab groups. The sim stations tab will be first, followed by
 * each session in ascending order by system number.
 * @param a first session tab
 * @param b second session tab
 */
export function sessionTabSorter(a: TabGroupChild<any>, b: TabGroupChild<any>): number {
  if (a?.data?.id ===SESSIONS_DATA.id) { return -1; }
  if (b?.data?.id ===SESSIONS_DATA.id) { return 1; }
  return a?.data?.systemNumber - b?.data?.systemNumber;
}

/**
 * This function will filter out events whose corresponding rule is in active state
 * @param events$ - all events
 * @param rules$ - all rules
 * @returns events whose rules are active
 */
export function getActiveRuleEvents(events$: Observable<RawEvent[]>, rules$: Observable<RuleItem[]>): Observable<RawEvent[]> {
  return combineLatest([events$, rules$]).pipe(map(([events, rules]) => events.filter(ev => !rules.some(r => r.id === ev.ruleId && !r.activationState))));
}
