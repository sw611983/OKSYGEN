/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { asArray } from '@oksygen-common-libraries/common';
import { PlayPauseStopEnum } from '@oksygen-common-libraries/material/components';
import { convertStateToPlayPauseStopEnum } from '@oksygen-sim-core-libraries/components-services/data-services';
import { State, SystemModuleState } from '@oksygen-sim-core-libraries/components-services/data-services';
import { SessionStoreData } from '../store/session/session-store.model';
import { CSystemSimulatorHelpersService } from '../services/csystem-simulator-helpers.service';


export function moduleStatusToPlayPauseStopEnum(
  systemNumber: number,
  storeData: SessionStoreData,
  cSystemSimHelperService: CSystemSimulatorHelpersService
): PlayPauseStopEnum {
  if (!storeData?.state?.moduleStates) {
    return convertStateToPlayPauseStopEnum(storeData?.state?.state);
  }

  const moduleStates = getModuleStatusExceptIngores(systemNumber, storeData, cSystemSimHelperService);

  for (const module of moduleStates) {
    if (module.state === State.INITIALISING || module.state === State.LOADING || module.state === State.LOADED || module.state === State.IDLE) {
      return PlayPauseStopEnum.LOADING;
    }
  }

  return convertStateToPlayPauseStopEnum(storeData.state.state);
}

export function getModuleStatusExceptIngores(
  systemNumber: number,
  storeData: SessionStoreData,
  cSystemSimHelperService: CSystemSimulatorHelpersService
): SystemModuleState[] {
  const modules: SystemModuleState[] = [];

  if (storeData?.state?.moduleStates) {
    const moduleStatusIgnores = asArray(cSystemSimHelperService.getModuleStatusIgnores(systemNumber));

    for (const module of storeData.state.moduleStates) {
      if (!moduleStatusIgnores.includes(module.name)) {
        modules.push(module);
      }
    }
  }

  return modules;
}
