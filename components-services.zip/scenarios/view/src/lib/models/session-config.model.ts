/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export const sessionConfigSchema: Record<string, any> = {
  $id: 'oksygen-session-config',
  type: 'object',
  properties: {
    session: {
      type: 'object',
      properties: {
        endSaveOption: { type: 'string', enum: ['always', 'prompt', 'never'] },
        showTab: { type: 'string', enum: ['always', 'never', 'session', 'preview'] },
        loadTimeout: { type: 'number' },
        preloadData: { type: 'boolean' },
        objects: {
          type: 'object',
          properties: {
            showProperties: { type: 'boolean' }
          }
        },
        trainPlacement: {
          type: 'object',
          properties: {
            enableDragFromPanel: { type: 'boolean' },
            enableDragFromMap: { type: 'boolean' },
            enableChangeOrientation: { type: 'boolean' }
          }
        },
        cameraEnabled: { type: 'boolean' }
      }
    }
  }
};
