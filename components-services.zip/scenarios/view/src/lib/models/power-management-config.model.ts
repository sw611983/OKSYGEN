/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { HTTP_SCHEMA_KEYWORD } from '@oksygen-sim-core-libraries/components-services/data-services';

export const powerManagementConfigSchema: Record<string, any> = {
  $id: 'oksygen-powermanagement-config',
  type: 'object',
  properties: {
    power: {
      type: 'object',
      properties: {
        management: {
          type: 'object',
          properties: {
            powerOnEnabled: { type: 'boolean'},
            powerOffEnabled: { type: 'boolean'},
            hubs: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  systemNumber: { type: 'number' },
                  hubId: { type: 'number' }
                }
              }
            },
            ignoreHubs: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  systemNumber: { type: 'number' },
                  hubId: { type: 'number' }
                }
              }
            }
          }
        }
      }
    },
    powerManagement: {
      type: 'object',
      properties: {
        resturl: { type: 'string', [HTTP_SCHEMA_KEYWORD]: '' }
      }
    },
    powerManagementOther: {
      type: 'object',
      properties: {
        resturl: { type: 'array', items: { type: 'string', [HTTP_SCHEMA_KEYWORD]: '' }}
      }
    }
  }
};
