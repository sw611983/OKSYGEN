/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { WS_SCHEMA_KEYWORD } from '@oksygen-sim-core-libraries/components-services/data-services';

export interface SystemRegistryObject {
  systemNumber: number;
  supportedSimulators: string[];
  requiredSimulators: string[];
}

export const commsConfigSchema: Record<string, any> = {
  $id: 'oksygen-comms-config',
  type: 'object',
  properties: {
    comms: {
      type: 'object',
      properties: {
        autoHubs: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              hubType: { type: 'string' },
              hubMode: { type: 'string' }
            }
          }
        },
        moduleStatus: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              systemNumber: { type: 'number' },
              ignored: { type: 'array', items: { type: 'string'} }
            }
          }
        },
        supportedSystems: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              systemNumber: { type: 'number'},
              supportedSimulators: { type: 'array', items: { type: 'string' }},
              requiredSimulators: { type: 'array', items: {type: 'string' }}
            }
          }
        },
        url: { type: 'string', [WS_SCHEMA_KEYWORD]: ''  }
      }
    }
  }
};
