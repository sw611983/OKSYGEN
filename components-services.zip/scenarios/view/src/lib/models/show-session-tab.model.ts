/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

/**
 * Allows consuming applications to determine when to automatically show session tabs. Typically,  
 * prep station should only show preview sessions  
 * operator station should only show "regular" sessions  
 * student station should show no sessions
 */
export enum ShowSessionTab {
  ALWAYS = 'always',
  NEVER = 'never',
  SESSION = 'session',
  PREVIEW = 'preview'
}
