/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';

import { MapMovementType, ZoomLevel } from '@oksygen-sim-train-libraries/components-services/maps';
import { SessionContext } from '../contexts/session-context';

  /**
   * Move the camera to the train location at time of calling this.
   * The train might move during the animation time!
   * @remark If you are faster than 40km/h (11.1m/s), we just move you directly to the train position without animation.
   *
   * @param context the context of the session
   * @param train the train to find
   * @param options:
   *   zoomToTrain Should we zoom to the train level or stay at the current zoom level.
   *   animateTrainZooming should we play an animation when moving to the train
   */
export function findTrain(
  context: SessionContext,
  train: UsefulTrain,
  options?: {
    zoomToTrain?: boolean;
    animateTrainZooming?: boolean;
  }
): void {
  const location = train?.vehicles?.[0]?.position?.lnglat?.[0];
  const speed = train?.vehicles?.[0]?.position?.speed;

  // Default values
  const zoomToTrain = options?.zoomToTrain ?? true;
  const animateTrainZooming = options?.animateTrainZooming ?? true;

  // This is an arbitrary value to say that if you are faster than 40km/h (11.1m/s),
  // we just move you directly to the train position without animation.
  const MAX_SPEED_TO_ANIMATE = 11.1;

  // If you did not find the train, we return immediately
  if (!location) return;

  const shouldJump = !animateTrainZooming || (speed !== undefined && speed > MAX_SPEED_TO_ANIMATE);
  let zoomLevel;
  let movementType;
  if (shouldJump) {
    // If you deactivate animation or are going to fast, we don't change the zoom and directly jump you to the train position
    movementType = MapMovementType.JUMP;
    zoomLevel = null;
  } else {
    // The default animation of mapGoto is fly. so If you have a change in zoom level, it will zoomToTrain and fly.
    // If you don't want to zoom to train, we simply pan you to the train.
    zoomLevel = zoomToTrain ? ZoomLevel.STATION : null;
    movementType = !zoomToTrain ? MapMovementType.PAN : undefined;
  }
  context.map.mapGoto(location, zoomLevel, movementType);
}

/**
 * Follows a train on the map
 */
export function lockOn(context: SessionContext, train: UsefulTrain): void {
  context.trains.selectTrain(train);
  context.map.followTrain(true);
}

/**
 * Stops following trains on the map
 */
export function lockOff(context: SessionContext): void {
  context.map.followTrain(false);
}

/**
 * @deprecated Use the helper functions directly.
 */
export class TrainUtilities {
  /**
   * @deprecated Use the helper function directly.
   */
  public static findTrain(context: SessionContext, train: UsefulTrain): void {
    findTrain(context, train);
  }

  /**
   * @deprecated Use the helper function directly.
   */
  public static lockOn(context: SessionContext, train: UsefulTrain): void {
    lockOn(context, train);
  }

  /**
   * @deprecated Use the helper function directly.
   */
  public static lockOff(context: SessionContext): void {
    lockOff(context);
  }
}
