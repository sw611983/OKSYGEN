/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { AppLauncherInfo } from '@oksygen-common-libraries/material/components';
import { IdName, PhysicalHub, Simulator, StartPosition } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Instructor, Trainee } from '@oksygen-sim-core-libraries/components-services/users';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { Scenario, VirtualLocationVehicle } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { ScenarioTrain } from '@oksygen-sim-train-libraries/components-services/trains';
import { EditorData } from '@oksygen-sim-train-libraries/components-services/editors';

export const SCENARIOS_CARD_DATA = new EditorData(
  t('Scenarios'),
  '/editors/scenarios',
  OksygenIcon.SCENARIO,
  'scenarios'
);

export const SESSIONS_DATA: AppLauncherInfo = {
  title: t('Sessions'),
  icon: OksygenIcon.SESSION,
  page: 'simulators-stations',
  id: 'Session'
};

export enum Action {
  APPLY_SELECTIONS,
  START_SESSION
}

export const simConfigSchema: Record<string, any> = {
  $id: 'oksygen-sim-hardware-config',
  type: 'object',
  properties: {
    sim: {
      type: 'object',
      properties: {
        hardwareConfigurable: { type: 'boolean' },
        hardwareStatesConfigurable: { type: 'boolean' }
      }
    }
  }
};

export interface SessionSetupResult<SelectionData> {
  data: SelectionData;
  action: Action;
}

/**
 * Describes savable overrides to apply to a Scenario when launching a session.
 */
export interface ScenarioOverrides {
  startTime?: string;
  // TODO We may want to include train setup and other options here.
}

export interface SessionSetupData extends ScenarioOverrides {
  systemNumber: number;
  simulator: Simulator;
  instructor?: Instructor;
  scenario?: Scenario;
  isScenario?: boolean; //True if launched from scenario editor, indicating a preview session

  scenarioTrain: ScenarioTrain;
  carIndex: number;
  location: VirtualLocationVehicle;
  startPositions: StartPosition[];
}

/**
 * Describes a session configuration for a single simulator.
 */
export interface SingleSimSessionSetupData extends SessionSetupData {
  trainee?: Trainee;
  instructorHub?: PhysicalHub;
  traineeHub: PhysicalHub;
  // Totally ugly bit of code
  // TODO: Extend the interface and change a whole bunch of code
  session: {
    sessionId: number;
    savedAt: string;
    duration?: number;
  };
}

export function isSingleSessionSetupData(data: SessionSetupData): data is SingleSimSessionSetupData {
  const keys = Object.keys(data);
  return keys.includes('traineeHub')
      && keys.includes('scenarioTrain')
      && keys.includes('carIndex')
      && keys.includes('location')
      && keys.includes('startPosition');
}

/**
 * Describes a session configuration for a single simulator.
 */
export interface SingleSimPreviewSetupData extends SessionSetupData {
  hub: PhysicalHub;
}

export function isSingleSimPreviewSetupData(data: SessionSetupData): data is SingleSimPreviewSetupData {
  const keys = Object.keys(data);
  return keys.includes('hub')
      && keys.includes('scenarioTrain')
      && keys.includes('carIndex')
      && keys.includes('location')
      && keys.includes('startPositions');
}

export interface ScenarioTrainInfo {
  st: ScenarioTrain;
  defaultLoc: VirtualLocationVehicle;
  vls: Map<number, VirtualLocationVehicle>;
}

export interface ScenarioTrainVirtualLocation {
  st: ScenarioTrain;
  vl: VirtualLocationVehicle;
}
// TODO Do we really want this? Could we use the station features themselves?
// TODO If we keep this, it may need to move to another model file.
/**
 * Stations are where trains pull up to (for example) pick up and / or unload cargo & passengers.
 */
export interface Station extends IdName {
  location: LngLatCoord;
}

export type SessionMainView = 'plan' | 'synoptic';

/**
 * Returns whether the argument is not falsy and also a SessionMainView (ie plan or synoptic).
 */
export function isSessionMainView(data: any): data is SessionMainView {
  return data && (data === 'plan' || data === 'synoptic');
}

export function isSingleSimSessionSetupData(
  value: SessionSetupData
): value is SingleSimSessionSetupData {
  return value && (value as SingleSimSessionSetupData).traineeHub !== undefined;
}
