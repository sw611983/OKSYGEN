/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { WithToolboxContainerTabsConfig } from '@oksygen-common-libraries/material/components';
import { EditorWithMapsConfig, EditorWithTopToolbarConfig } from '@oksygen-sim-train-libraries/components-services/editors';

/**
 * Session/Scenario Editor Config
 */
export interface SSeConfig<C extends SSeTopToolbarDefaultItemsConfig>
  extends WithToolboxContainerTabsConfig,
    EditorWithMapsConfig,
    EditorWithTopToolbarConfig<C> {}

/**
 * Session/Scenario Editor Top Toolbar Default Items Config
 */
export interface SSeTopToolbarDefaultItemsConfig {
  map: boolean;
  elevation: boolean;
  layers: boolean;
  stations: boolean;
}
