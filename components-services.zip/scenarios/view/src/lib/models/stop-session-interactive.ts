/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';

import {
  CANCEL_BUTTON,
  isCancelButtonResult,
  isYesButtonResult,
  OK_BUTTON,
  PlayPauseStopEnum,
  PromptDialogComponent,
  PromptDialogData,
  YES_NO_CANCEL_BUTTONS
} from '@oksygen-common-libraries/material/components';
import { Registry } from '@oksygen-common-libraries/pio';
import { CSystemSimulatorHelpersService } from '../services/csystem-simulator-helpers.service';
import { SystemStoreState } from '../store/system/system.state';
import { sessionActions } from '../store/session/session.actions';

type EndSessionSaveOption = 'always' | 'prompt' | 'never';

// Don't know if these magic strings here makes sense
export const TIMEOUT_TITLE = t('Session Timeout');
export const TIMEOUT_MESSAGE = t('Allocated time limit has elapsed.');

/**
 * Format the additional info to be displayed in the stop session dialog. Needs the title and message to be translated before calling this function.
 *
 * @param title The title to display. This must be translated before calling this function.
 * @param message The message to display. This must be translated before calling this function.
 * @returns The formatted message.
 */
export function additionalInfoFormatter(title: string, message: string): string {
  return `<span><b>${title}:</b> ${message}<span><br><br>`;
}

/**
 *
 * @param registry
 * @param dialog
 * @param commsService
 * @param systemNumber
 * @param store
 * @param additionalInfo The reason for stopping the session.
 * Usually an html formatted message like "<h1>Session Timeout</h1><span>Allocated time limit has elapsed.<span>""
 */
export function stopSessionInteractive(
  registry: Registry,
  dialog: MatDialog,
  commsService: CSystemSimulatorHelpersService,
  systemNumber: number,
  store: Store<SystemStoreState>,
  additionalInfo?: string
): void {
  store.dispatch(sessionActions.updateSessionState({ systemNumber, state: PlayPauseStopEnum.PAUSE }));

  // TODO read from config
  // FIXME the default should be 'prompt' to match historical behaviour

  const endSessionSaveOption: EndSessionSaveOption = registry.getString(['session', 'endSaveOption'], 'never') as EndSessionSaveOption;

  const promptData = new PromptDialogData();
  promptData.title = t('End Session');
  promptData.content = t('Are you sure you want to end the Session?');
  promptData.buttons = [{ ...OK_BUTTON, text: t('End Session') }, CANCEL_BUTTON];
  let save = false;

  if (commsService.isSessionSimulation(systemNumber)) {
    switch (endSessionSaveOption) {
      case 'always':
        save = true;
        break;
      case 'prompt':
        promptData.content = t('Would you like to Save the Session?');
        promptData.buttons = YES_NO_CANCEL_BUTTONS;
        break;
      case 'never':
        break;
      default:
        throw Error(`Unknown setting ${endSessionSaveOption}`);
    }
  }

  if (additionalInfo) {
    promptData.content = [additionalInfo, promptData.content];
  }

  PromptDialogComponent.open(dialog, { id: 'END_OF_SESSION', data: promptData }, result => {
    if (!isCancelButtonResult(result)) {
      if (commsService.isSessionSimulation(systemNumber) && (save || (endSessionSaveOption === 'prompt' && isYesButtonResult(result)))) {
        commsService.saveSession(systemNumber);
      }
      commsService.unloadScenario(systemNumber);
    }
  });
}

export function stopAllSessionInteractive(
  registry: Registry,
  dialog: MatDialog,
  commsService: CSystemSimulatorHelpersService,
  systemNumbers: number[],
  store: Store<SystemStoreState>,
  additionalInfo?: string
): void {
  systemNumbers.forEach(systemNumber => {
    store.dispatch(sessionActions.updateSessionState({ systemNumber, state: PlayPauseStopEnum.PAUSE }));
  });

  // TODO read from config
  // FIXME the default should be 'prompt' to match historical behaviour
  const endSessionSaveOption: EndSessionSaveOption = registry.getString(['session', 'endSaveOption'], 'never') as EndSessionSaveOption;

  const promptData = new PromptDialogData();
  promptData.title = t('End Sessions');
  promptData.content = t('Are you sure you want to end all the sessions?');
  promptData.buttons = [{ ...OK_BUTTON, text: t('End Sessions') }, CANCEL_BUTTON];
  let save = false;

  switch (endSessionSaveOption) {
    case 'always':
      save = true;
      break;
    case 'prompt':
      promptData.content = t('Would you like to save all the sessions?');
      promptData.buttons = YES_NO_CANCEL_BUTTONS;
      break;
    case 'never':
      break;
    default:
      throw Error(`Unknown setting ${endSessionSaveOption}`);
  }

  if (additionalInfo) {
    promptData.content = [additionalInfo, promptData.content];
  }

  PromptDialogComponent.open(dialog, { id: 'END_OF_SESSION', data: promptData }, result => {
    if (!isCancelButtonResult(result)) {
      if (save || (endSessionSaveOption === 'prompt' && isYesButtonResult(result))) {
        systemNumbers.forEach(systemNumber => {
          if (commsService.isSessionSimulation(systemNumber)) {
            commsService.saveSession(systemNumber);
          }
        });
      }
      systemNumbers.forEach(systemNumber => {
        commsService.unloadScenario(systemNumber);
      });
    }
  });
}
