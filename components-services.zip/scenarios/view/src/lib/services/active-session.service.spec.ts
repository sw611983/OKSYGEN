/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ActiveSessionService } from './active-session.service';
import { OksygenSimTrainSessionModule } from '@oksygen-sim-train-libraries/components-services/session';
import { SessionLoggingConfigToken } from '../tokens/session-logging.token';

describe('ActiveSessionService', () => {
  let service: ActiveSessionService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainSessionModule],
      providers: [
        {
          provide: SessionLoggingConfigToken,
          useValue: {}
        }
      ]
    });
    service = TestBed.inject(ActiveSessionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
