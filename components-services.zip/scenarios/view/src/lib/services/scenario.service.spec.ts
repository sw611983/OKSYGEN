/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ScenarioServiceImpl } from './scenario.service';

describe('ScenarioServiceImpl', () => {
  let service: ScenarioServiceImpl;

  beforeEach(() => {
    configureSimTrainTestingModule({ providers: [ScenarioServiceImpl] });
    service = TestBed.inject(ScenarioServiceImpl);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
