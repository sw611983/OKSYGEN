/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { shareReplayOne } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { SocketMessage } from '@oksygen-sim-core-libraries/components-services/data-services';
import { RadioData, RadioPanelDataService } from '@oksygen-sim-train-libraries/components-services/radio';

/**
 * Extend this Project side and override onMessage to handle messages coming from the end point
 * Implement with functionality required by the screen, like the send functions for various messages
 */
export class RadioManager {
  private radioPanelDataService: RadioPanelDataService;

  private radioSubscription = Subscription.EMPTY;

  protected radioBadgeContentSubject = new BehaviorSubject<string | number | undefined | null>(null);
  private radioBadgeContentObservable = this.radioBadgeContentSubject.pipe(shareReplayOne());
  protected radioBadgeHiddenSubject = new BehaviorSubject<boolean>(true);
  private radioBadgeHiddenObservable = this.radioBadgeHiddenSubject.pipe(shareReplayOne());

  constructor(
    protected readonly registry: Registry,
    protected readonly logger: Logging,
    protected readonly systemNumber: number,
    protected readonly serverStatus$: Observable<boolean>
  ) {}

  public get radioBadgeContent$(): Observable<string | number | undefined | null> {
    return this.radioBadgeContentObservable;
  }

  public get radioBadgeHidden$(): Observable<boolean> {
    return this.radioBadgeHiddenObservable;
  }

  destroy(): void {
    this.radioBadgeContentSubject.complete();
    this.radioBadgeHiddenSubject.complete();
    this.radioSubscription.unsubscribe();
    this.radioPanelDataService?.destroy();
  }

  /** Call this in the Project Implementation Constructor */
  protected createEndpoint(): void {
    this.radioPanelDataService = new RadioPanelDataService(this.registry, this.logger, this.systemNumber, this.serverStatus$);

    this.radioSubscription = this.radioPanelDataService.radioMessagesSubject$().subscribe(message => this.onMessage(message));
  }

  /**
   * Override this to handle the expected Messages
   * @param message
   */
  protected onMessage(message: SocketMessage<any, RadioData>): void {}

  protected sendMessage(message: SocketMessage<any, any>): void {
    this.radioPanelDataService.sendMessage(message);
  }
}
