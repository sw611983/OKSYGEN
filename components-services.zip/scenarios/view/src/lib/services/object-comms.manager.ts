/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { BehaviorSubject, combineLatest, Observable, of, Subscription } from 'rxjs';
import { distinctUntilChanged, map, startWith, switchMap, tap, withLatestFrom } from 'rxjs/operators';

import { filterTruthy, SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UserScenarioFavouritesService } from '@oksygen-sim-core-libraries/components-services/favourites';
import { LngLatCoord } from '@oksygen-sim-core-libraries/data-types/common';
import { ObjectLocation, UpdatedInserted } from '@oksygen-sim-train-libraries/components-services/common';
import {
  DISPLAY_STATE,
  DISPLAY_STATE_OVERRIDE,
  ObjectContainer,
  ObjectDataService,
  ObjectTypeContainer,
  ObjectWorldGeometry,
  ObjManager,
  RawFeature,
  RawFeatureProperties,
  STATE,
  USER_STATE
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { CommsObjectTransformer } from './transformers/comms-object.transformer';
import { isNil } from 'lodash';
import { CSystemSimulatorHelpersService } from './csystem-simulator-helpers.service';
import { WorldManager } from '@oksygen-sim-train-libraries/components-services/world-definition';
import { ObjectCommsQueue } from './queues/object-comms.queue';

export class ObjectCommsManager extends ObjManager {
  private readonly DATA_BATCH_RATE = 300; // should this be configurable?
  private scenarioObjectNames: string[] = [];
  private trackObjectNames: string[] = [];
  private rawFeatures: RawFeature[] = [];
  private objects: ObjectContainer[] = [];
  private objectDataService: ObjectDataService;
  private objectSub: Subscription;
  private featuresInitialisedSubject: BehaviorSubject<boolean>;
  private readonly subscription = new Subscription();
  private sessionFocused = true;
  private queue = new ObjectCommsQueue();

  private transformer: CommsObjectTransformer;

  constructor(
    registry: Registry,
    private readonly logger: Logging,
    objectTypes$: Observable<ObjectTypeContainer[]>,
    private readonly scenario$: Observable<Scenario>,
    private readonly world$: WorldManager,
    private readonly locationProcessorFn: (objLocations: Map<number, ObjectWorldGeometry>) => Observable<Map<number, ObjectLocation>>,
    private readonly systemNumber: number,
    private readonly favouritesService: UserScenarioFavouritesService,
    private readonly cSystemSimulatorHelpersService: CSystemSimulatorHelpersService,
    private sessionIsFocused$?: Observable<boolean>
  ) {
    super(objectTypes$);
    this.transformer = new CommsObjectTransformer(this.logger, this.locationProcessorFn);
    this.objectDataService = new ObjectDataService(
      registry,
      logger,
      this.systemNumber,
      this.cSystemSimulatorHelpersService.isWebServerSessionActive(systemNumber),
      this.DATA_BATCH_RATE
    );
    this.objectSubject = new BehaviorSubject(this.objects);
    this.featuresInitialisedSubject = new BehaviorSubject<boolean>(false);
    this.subscription.add(this.scenario$.pipe(
      filterTruthy(),
      tap(s => this.scenarioObjectNames = s.world.object?.map(o => o.name) ?? []),
      switchMap(x => this.world$.world$),
      filterTruthy(),
      tap(w => {
        this.trackObjectNames = [];
        w.objects.forEach(o => this.trackObjectNames.push(o.name));
      })
    ).subscribe((w => {
      const positions = new Map();
      w.objects.forEach((obj, key) => {
        // I'm not sure this is even supposed to go here PRDOKS-2535
        obj?.boundaries?.forEach(boundary => positions.set(key, boundary));
      });
      this.updateManyObjectPosition(positions);
    })));
    if (!this.objectDataService.isConnected()) {
      this.connect();
    }
    const focusSub = this.sessionIsFocused$.pipe(
      startWith(true),
      distinctUntilChanged(),
      withLatestFrom(this.objectTypes$)
    ).subscribe(([focused, objectTypes]) => {
      this.sessionFocused = focused;
      if (focused) {
        const pendingUpdates = this.queue.getPendingUpdates();
        this.queue.clear();
        this.transform(pendingUpdates, objectTypes).subscribe(upserts => this.onTransformFeatures(upserts, pendingUpdates) );
      }
      this.logger.debug(`[ObjectCommsManager]: session active status ${focused}`);
    });
    this.subscription.add(focusSub);
  }

  connect(): void {
    if (this.objectDataService.isConnected()) {
      this.logger.warn(`[ObjectCommsManager] attempting to connect to already connected data source.`);
      return;
    }
    this.objectDataService.openConnection();

    // This is not pretty, nor ideal, compared to the switchMap/tap combination that was here
    // but for whatever reason, switchMap was seemingly dropping most of the results of transformMany
    // which is even less ideal
    this.objectSub = combineLatest([this.objectTypes$, this.objectDataService.features$().pipe(filterTruthy())])
      .subscribe(([types, rawFeatures]) =>
      this.transform(rawFeatures?.features, types).pipe(
        filterTruthy()
      ).subscribe(upserts => {
          this.onTransformFeatures(upserts, rawFeatures?.features);
        })
    );
  }

  disconnect(): void {
    this.objectDataService.closeConnection();
    this.objectSub?.unsubscribe();
  }

  override destroy(): void {
    this.disconnect();
    this.objectSubject.complete();
    this.featuresInitialisedSubject.complete();
    this.objectUpdated.complete();
    this.objectInserted.complete();
    this.subscription?.unsubscribe();
    super.destroy();
  }

  override get data$(): Observable<Array<ObjectContainer>> {
    return combineLatest([
      this.objectSubject,
      this.favouritesService.getFavouritesManager(this.systemNumber).userScenarioFavourites$()
    ]).pipe(
      map(([objects, favourites]) => {
        if (favourites?.favourite) {
          objects.forEach(object => {
            object.favourite = !!favourites.favourite.find(fav => object.id === fav.featureId);
          });
        }

        return objects;
      })
    );
  }

  /**
   * A stream of inserted features.
   * Beware using this in combineLatest - this will be re-emitted when your other observables emit.
   * @param emitInitialList (default true) whether to emit the initial list of objects when you first subscribe.
   */
  override getInsertedObject$(emitInitialList = true): Observable<ObjectContainer[]> {
    if (emitInitialList) {
      return this.featuresInitialisedSubject.pipe(
        filterTruthy(),
        switchMap(
          () => this.objectInserted.pipe(
            startWith(this.objectSubject.getValue() ?? [])
          )
        ),
      );
    }
    return this.objectInserted.pipe();
  }

  /* overrides to combine with favourites */
  override getObject$(id: string|number, useOriginal: boolean = true): Observable<ObjectContainer> {
    return combineLatest([
      super.getObject$(id, useOriginal),
      this.favouritesService.getFavouritesManager(this.systemNumber).userScenarioFavourites$()
    ]).pipe(
      map(([object, favourites]) => {
        if (object && favourites?.favourite) {
          object.favourite = !!favourites.favourite.find(fav => object.id === fav.featureId);
        }

        return object;
      })
    );
  }

  private transform(rawFeatures: RawFeature[], types?: ObjectTypeContainer[]): SelfCompletingObservable<UpdatedInserted<ObjectContainer>> {
    if (this.sessionFocused) {
      return this.transformer.processRawFeatures(rawFeatures, types, this.rawFeatures, this.objects, this.trackObjectNames, this.scenarioObjectNames);
    } else {
      this.queue.processMessage(rawFeatures);
      return of(null);
    }
  }

  private processUpserts(upserts: UpdatedInserted<ObjectContainer>, notifyListeners: boolean): void {
    if (!upserts) { return; }

    const objectsUpdated  = upserts.updated.length;
    const objectsInserted = upserts.inserted.length;
    // Process the changes
    if (objectsUpdated) {
      upserts.updated.forEach(object => {
        const objectIndex = this.objects.findIndex(f => f.id === object.id);
        if (objectIndex !== -1) {
          // update reference for immutability which gives us access to distinctUntilChanged()
          object.favourite = this.objects[objectIndex].favourite;

          this.objects[objectIndex] = object;
          this.processLocationUpdate(object);
        } else {
          this.logger.warn(`[ObjectCommsManager] both update and insert! ${object.id} ${object.name}`);
        }
      });
    }

    if (objectsInserted) {
      upserts.inserted.forEach(o => {
        this.processLocationUpdate(o);
        this.objects.push(o);
      });
    }
  }

  private notifyListeners(upserts: UpdatedInserted<ObjectContainer>): void {
    const objectsUpdated  = upserts.updated.length;
    const objectsInserted = upserts.inserted.length;
    // Notify listeners, now that our internal state is up to date.
    // Note, we won't do this when non-state properties are the only updates.

    // Note that the order of these updates is fairly important because
    // it's possible for listeners using subjects other than this.objectSubject to be notified of updates
    // to use ObjectManager.getObject(id) to grab objects, which pulls the objects out of this.objectSubject.
    // If this.objectSubject is not updated first, subscribers using this approach will be processing stale data.
    // FIXME ideally this would be less brittle. Perhaps getObject() should get the value directly from this.object?
    if ((objectsUpdated || objectsInserted)) {
      this.objectSubject.next(this.objects);

      if (objectsUpdated) {
        this.objectUpdated.next(upserts.updated);
      }
      if (objectsInserted) {
        this.objectInserted.next(upserts.inserted);
      }
    }
  }

  private updateObjectPosition(id: number|string, location: LngLatCoord[], update = true): void {
    if (!location) { return; }
    const feature = this.objects.find(f => f.id === id);
    if (!feature) {
      this.unprocessedUpdates.set(id, location);
      return;
    }
    if (location.length > 1) {
      feature.boundaries = [location];
    } else {
      feature.location.lnglat = location[0];
    }
    if (update) {
      this.objectSubject.next(this.objectSubject.getValue());
    }
  }

  private updateManyObjectPosition(positions: Map<number|string, LngLatCoord[]>): void {
    positions.forEach((location, key) => {
      this.updateObjectPosition(key, location, false);
    });
    this.objectSubject.next(this.objectSubject.getValue());
  }

  public updateObjectAuto(id: number|string, isAuto: boolean): void {
    const stateObject: {State?: string|number; 'User State'?: string|number} = {};
    const rawFeature = this.rawFeatures.find(rf => rf.id === id);
    const feature = this.objects.find(f => f.id === id);
    if (!rawFeature || !feature) { return; }
    if (isAuto) {
      const stateId = feature.objectType.automatedState?.id ?? -1;
      if (stateId === -1) { return; } // this shouldn't really ever happen
      stateObject['User State'] = stateId;
    } else {
      if (Object.prototype.hasOwnProperty.call(rawFeature.properties, USER_STATE)
          && Object.prototype.hasOwnProperty.call(rawFeature.properties, STATE)) {
        stateObject['User State'] = rawFeature.properties.State;
      } else {
        return; // shouldn't reach here
      }
    }
    this.objectDataService.setFeatureState(id, stateObject);
  }

  public updateObjectDisplayOverrideState(id: number|string, isOverriden: boolean, state: string|number): void {
    const stateObject: RawFeatureProperties = {};
    const rawFeature = this.rawFeatures.find(rf => rf.id === id);
    const feature = this.objects.find(f => f.id === id);
    if (!rawFeature || !feature) {
      return;
    }
    if (!isNil(state)) {
      // Display State Value Changed
      stateObject[DISPLAY_STATE] = state;
    } else {
      // Display Override Updated
      stateObject[DISPLAY_STATE_OVERRIDE] = +isOverriden;
    }
    this.objectDataService.setFeatureState(id, stateObject);
  }

  updateObjectContainerState(id: number|string, state: string|number): void {
    const stateObject: RawFeatureProperties = {};
    const rawFeature = this.rawFeatures.find(rf => rf.id === id);
    if (!rawFeature || !rawFeature.properties) { return; }
    const rawUserState = rawFeature.properties['User State'];
    const hasUserState = rawUserState !== null && rawUserState !== undefined;
    if (hasUserState) {
      stateObject['User State'] = state;
    } else {
      stateObject.State = state;
    }
    this.objectDataService.setFeatureState(id, stateObject);
  }

  updateObjectContainerProperty(id: number|string, propertyKey: string, propertyValue: string|number): void {
    this.objectDataService.setFeatureProperty(id, propertyKey, propertyValue);
  }

  private processLocationUpdate(feature: ObjectContainer): void {
    if (!feature) { return; }
    const update = this.unprocessedUpdates.get(feature.id);
    if (update) {
      if (update.length === 1) {
        feature.location.lnglat = update[0];
      } else {
        feature.boundaries = [update];
      }
      this.unprocessedUpdates.delete(feature.id);
    }
  }

  private onTransformFeatures(upserts: UpdatedInserted<ObjectContainer>, rawFeatures: RawFeature[]): void {
    setTimeout(() => {
      const notifyListeners = this.transformer.isRawFeatureUpdateImportant(rawFeatures);
      this.processUpserts(upserts, notifyListeners);
      this.transformer.updateParentChildReferences(upserts, this.objects, this.rawFeatures);
      if (notifyListeners) {
        this.notifyListeners(upserts);
        if (!this.featuresInitialisedSubject.getValue()) {
          this.featuresInitialisedSubject.next(true);
        }
      }
    }, 1);
  }
}
