/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { cloneDeep } from 'lodash';
import { BehaviorSubject, Observable, of, ReplaySubject, Subject, Subscription } from 'rxjs';
import { catchError, filter, first, timeout } from 'rxjs/operators';

import { asArray, computeIfAbsent, DISMISS, includesAll, SelfCompletingObservable, shareReplayOne } from '@oksygen-common-libraries/common';
import { DataAccessService } from '@oksygen-common-libraries/data-access';
import { PlayPauseStopEnum, TabService } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ErrorService, Severity } from '@oksygen-sim-core-libraries/components-services/common';
import {
  commsStateErrorId,
  CommsStateResponse,
  CommsStateService,
  Health,
  HubData,
  HubMode,
  HubType,
  PhysicalHub,
  ScenarioDefinition,
  ScenarioDefinitionData,
  ScenarioMessageId,
  SessionDefinition,
  SessionDefinitionData,
  SessionMessageId,
  SessionPreventPlay,
  SessionStatus,
  SessionStatusMessageId,
  Simulator,
  SimulatorData,
  SimulatorService,
  State,
  StateMessageId,
  SystemState,
  SystemStateList,
  TraineeData
} from '@oksygen-sim-core-libraries/components-services/data-services';
import { NO_INSTRUCTOR } from '@oksygen-sim-core-libraries/components-services/users';
import { CabHardwareService } from '@oksygen-sim-train-libraries/components-services/cab-hardware';

import { SessionLogEvents, SessionLogging } from '../logging/session-logging';
import { SystemRegistryObject } from '../models/comms-config.model';
import { SessionSetupData, SingleSimPreviewSetupData, SingleSimSessionSetupData } from '../models/session-setup.model';
import { sessionActions } from '../store/session/session.actions';
import { SystemStoreData, SystemStoreState } from '../store/system/system.state';
import { CommsModuleStateService } from './comms-module-state.service';

interface ModuleStatusConfig {
  systemNumber?: number;
  ignore: string[];
}

interface AutoHubDescription {
  hubType: string;
  hubMode: string;
}

export enum StartSessionRejected {
  UNKNOWN,
  NO_SESSION_ID
}

@Injectable()
export class CSystemSimulatorHelpersService {
  private readonly requiredSimulators: Map<number, Array<string>> = new Map();
  private readonly supportedSimulators: Map<number, Array<string>> = new Map();
  private readonly allSupportedSimulators: Array<string> = [];
  private readonly moduleStatusIgnores: Map<number, Array<string>> = new Map();
  private readonly sessionStatuses: Map<number, BehaviorSubject<SessionStatus>> = new Map();
  // This is a subject and not a behavior subject because we only want to know about it when the event happens.
  // The session prevent play message is not a state, it is an event.
  private readonly sessionPreventPlay: Map<number, ReplaySubject<SessionPreventPlay>> = new Map();
  private readonly unloadRequested: Map<number, boolean> = new Map();
  private readonly pendingSessions: Map<number, BehaviorSubject<boolean>> = new Map();
  private readonly activeSystems: Map<number, boolean> = new Map();
  // The webServerLoadedStatus map tracks whether the web server is in a paused or running state for each system.
  // This ensures that other WebSocket connections related to the active session are only established when the server is in a usable state.
  private readonly webServerLoadedStatus: Map<number, BehaviorSubject<boolean>> = new Map();
  // The webServerUpStatus map tracks whether the web server is up (true) or down (false) for each system.
  // This helps ensure CommsStateConnection only establishes when the server is active, avoiding DROPPED or UNKNOWN states.
  private readonly webServerUpStatus: Map<number, BehaviorSubject<boolean>> = new Map();

  // store if the session is simulation or not
  private readonly sessionSimulation: Map<number, BehaviorSubject<boolean>> = new Map();

  private readonly autoHubs: AutoHubDescription[];
  private simulators: Map<number, Simulator>;

  // private readonly requestedSessions: Map<number, BaseSessionData> = new Map<>();

  private started = false;
  private errorLogCount = 0;

  /** after how long to time out a session load request if the BE doesn't respond */
  private sessionLoadTimeout: number;
  private masterSubscription = new Subscription();

  constructor(
    private registry: Registry,
    private logging: Logging,
    private dataAccessService: DataAccessService,
    private systemStore: Store<SystemStoreData>,
    // This dependency ensures that the CommsModuleStateService is created before we wire up the CommsStateService.
    // This may not be the best way to guarantee that CommsModuleStateService sees all the updates from this shared service
    // but this triad of classes will probably be refactored when we rework how we present simulator health to the user.
    private commsModuleStateService: CommsModuleStateService,
    private commsStateService: CommsStateService,
    private simulatorService: SimulatorService,
    private store: Store<SystemStoreState>,
    private errorService: ErrorService,
    private tabService: TabService,
    private snackBar: MatSnackBar,
    public translate: TranslateService,
    private cabHardwareService: CabHardwareService,
    private sessionLogging: SessionLogging
  ) {
    this.commsStateService.setCommsUrl(this.registry.getString(['comms', 'url'])); // does the systemNumber replacement internally
    this.autoHubs = this.registry.getObjectArray<AutoHubDescription>(['comms', 'autoHubs']);
    this.initSessionLoadTimeout();
  }

  start(): void {
    if (this.started) {
      return;
    }
    this.commsModuleStateService.start();
    this.masterSubscription = new Subscription();
    this.masterSubscription.add(this.commsStateService.responses.subscribe(response => this.handleCommsStateResponse(response)));

    this.masterSubscription.add(
      this.simulatorService
        .data()
        .pipe(filter(s => s && s.length > 0))
        .subscribe(sims => {
          this.simulators = new Map();
          if (sims) {
            sims.forEach(s => {
              this.simulators.set(s.id, s);
            });
          }
        })
    );

    const modStatusConfig = this.registry.getObjectArray<ModuleStatusConfig>(['comms', 'moduleStatus'], []);
    const sharedModStatusConfig = modStatusConfig.find(c => !c.systemNumber);
    const supportedSystems = this.registry.getObjectArray<SystemRegistryObject>(['comms', 'supportedSystems']);

    // Store the simulators used by each system
    for (const system of supportedSystems) {
      this.setSystemSimulators(system.systemNumber, system.supportedSimulators, system.requiredSimulators ? system.requiredSimulators : []);

      const msConfig = modStatusConfig.find(c => c.systemNumber === system.systemNumber);

      const ignores: string[] = [];

      if (sharedModStatusConfig?.ignore) {
        ignores.push(...sharedModStatusConfig.ignore);
      }

      if (msConfig?.ignore) {
        ignores.push(...msConfig.ignore);
      }

      this.moduleStatusIgnores.set(system.systemNumber, ignores);
      if (!this.pendingSessions.get(system.systemNumber)) {
        this.pendingSessions.set(system.systemNumber, new BehaviorSubject(false));
      }
      this.activeSystems.set(system.systemNumber, false);
      // every half second should be sufficient, as we also get a message on play/pause
      // this.commsStateService.requestSessionStatus(system.systemNumber, 0.5);
    }

    this.listenToSystemStateListUpdates();
    this.started = true;
  }

  stop(): void {
    this.masterSubscription?.unsubscribe();
    this.masterSubscription = null;

    this.commsModuleStateService.stop();

    for (const systemNumber of this.supportedSimulators.keys()) {
      if (this.activeSystems.has(systemNumber) && this.activeSystems.get(systemNumber)) {
        this.commsStateService.closeCommsStateConnection(systemNumber);
        this.cabHardwareService.destroySystem(systemNumber);
      }
    }

    this.requiredSimulators.clear();
    this.supportedSimulators.clear();

    this.sessionStatuses.forEach(value => value.complete());
    this.sessionStatuses.clear();

    this.sessionPreventPlay.forEach(value => value.complete());
    this.sessionPreventPlay.clear();

    this.activeSystems.clear();

    this.webServerLoadedStatus.forEach(value => value.complete());
    this.webServerLoadedStatus.clear();

    this.webServerUpStatus.forEach(value => value.complete());
    this.webServerUpStatus.clear();
    this.allSupportedSimulators.length = 0; // clear the array

    this.webServerUpStatus.forEach(value => value.complete());
    this.sessionSimulation.clear();
    this.started = false;
  }

  setSystemSimulators(systemNumber: number, supportedSimulatorNames: Array<string>, requiredSimulatorNames: Array<string>): void {
    if (!includesAll(requiredSimulatorNames, supportedSimulatorNames)) {
      throw Error(`Configuration is asking for required sims that are not supported!
        Supported sims: ${supportedSimulatorNames.toString()}
        Required sims: ${requiredSimulatorNames.toString()}`);
    }

    this.requiredSimulators.set(systemNumber, requiredSimulatorNames);
    this.supportedSimulators.set(systemNumber, supportedSimulatorNames);
    this.sessionStatuses.set(systemNumber, new BehaviorSubject<SessionStatus>(null));
    this.sessionPreventPlay.set(systemNumber, new ReplaySubject<SessionPreventPlay>());
    this.unloadRequested.set(systemNumber, false);
    this.webServerLoadedStatus.set(systemNumber, new BehaviorSubject(false));
    this.webServerUpStatus.set(systemNumber, new BehaviorSubject(false));
    this.getSessionSimulation(systemNumber);

    for (const sim of supportedSimulatorNames) {
      if (!this.allSupportedSimulators.includes(sim)) {
        this.allSupportedSimulators.push(sim);
      }
    }
  }

  public getSystemKeys(): Array<number> {
    return Array.from(this.supportedSimulators.keys());
  }

  public getRequiredSimulators(systemName: number): Array<string> {
    return this.requiredSimulators.get(systemName);
  }

  public getSupportedSimulators(systemName: number): Array<string> {
    return this.supportedSimulators.get(systemName);
  }

  public getAllSupportedSimulators(): Array<string> {
    return this.allSupportedSimulators;
  }

  public getModuleStatusIgnores(systemNumber: number): Array<string> {
    return this.moduleStatusIgnores.get(systemNumber);
  }

  /**
   * Returns all systems associated with the given simulators.
   */
  public getAllAssociatedSystems(simulatorNames: string | string[]): Array<number> {
    simulatorNames = asArray(simulatorNames);
    const associatedSystems = new Array<number>();

    for (const systemName of this.getSystemKeys()) {
      if (includesAll(simulatorNames, this.getRequiredSimulators(systemName))) {
        if (includesAll(this.getSupportedSimulators(systemName), simulatorNames)) {
          associatedSystems.push(systemName);
        }
      }
    }

    return associatedSystems;
  }

  /**
   * Finds the available system with the least simulators that contains all of the given simulators.
   *
   * @param requestedSimulatorNames The names of the simulators required.
   *
   * @return The ID of the System.
   */
  public findMinimalSystem(simulatorNames: string | string[]): number {
    // figure out which simulators are required to run this session

    // figure out which systems contain the required simulators
    // these will be candidates for running the session
    const candidateSystems = this.getAllAssociatedSystems(simulatorNames);
    let primeCandidate = null;

    // select the system that has the least simulators out of the candidates
    let simsInPrimeCandidate = Number.MAX_SAFE_INTEGER;

    for (const candidate of candidateSystems) {
      // TODO Skip busy and missing systems
      // const state = this.getSystem(candidate).getSystemStatus().getState();

      // if (!state.equals(State.UNKNOWN) && !State.isInScenarioState(state))
      {
        const simsInCandidate = this.getSupportedSimulators(candidate).length;

        if (simsInCandidate < simsInPrimeCandidate) {
          primeCandidate = candidate;
          simsInPrimeCandidate = simsInCandidate;
        }
      }
    }

    if (primeCandidate == null) {
      // we shouldn't get here, if we do it's a programatic or config problem
      throw new Error('No System can be found with the required simulators.');
    }

    return primeCandidate;
  }

  public sessionStatus$(systemNumber: number): Observable<SessionStatus> {
    return this.sessionStatuses.get(systemNumber).pipe(shareReplayOne());
  }

  public sessionPreventPlay$(systemNumber: number): Observable<SessionPreventPlay> {
    return this.sessionPreventPlay.get(systemNumber).pipe(shareReplayOne());
  }

  public getSessionTimeout(): number {
    return this.sessionLoadTimeout;
  }

  /**
   * We ignore `SYSTEM_STATE_LIST` updates from our `CommsStateService` subscriptions and instead use `CommsModuleStateService` to handle responses.
   * This approach ensures priority handling of communications updates and prevents synchronization issues
   * that previously caused inconsistencies in UI updates due to out-of-sync status updates from 2 sockets.
   */
  private listenToSystemStateListUpdates(): void {
    this.masterSubscription.add(
      this.commsModuleStateService.systemStateListUpdates$().subscribe(systemStateList => {
        this.updateSystemStatus(systemStateList);
      })
    );
  }

  private handleCommsStateResponse(response: CommsStateResponse): void {
    switch (response.messageId) {
      case ScenarioMessageId.SCENARIO_DEFINITION: {
        this.systemStore.dispatch(
          sessionActions.scenarioDefinition({
            systemNumber: response.systemNumber,
            scenarioDefinition: response.message as ScenarioDefinition
          })
        );
        const pendingSession = this.pendingSessions.get(response.systemNumber);
        if (pendingSession) {
          pendingSession.next(false);
        }
        break;
      }
      case SessionMessageId.SESSION_DEFINITION: {
        const sessionDefinition = response.message as SessionDefinition;
        this.systemStore.dispatch(
          sessionActions.sessionDefinition({
            systemNumber: response.systemNumber,
            sessionDefinition
          })
        );

        this.sessionSimulation.get(response.systemNumber)?.next(sessionDefinition.simulation);
        this.unloadRequested.set(response.systemNumber, false);
        break;
      }
      case SessionStatusMessageId.SESSION_STATUS: {
        this.sessionStatuses.get(response.systemNumber)?.next(response.message as SessionStatus);
        break;
      }
      case StateMessageId.SYSTEM_STATUS:
        break;
      case StateMessageId.SYSTEM_STATE_LIST:
        // If you are interested in these updates please use updateSystemStatus() to avoid synchronisation issue
        break;
      case SessionStatusMessageId.SESSION_PREVENT_PLAY: {
        // A bit hacky, it is supposed to be an enum but it is sent as a string.
        (response.message as SessionPreventPlay).reason = parseInt((response.message as SessionPreventPlay)?.reason.toString(), 10);
        this.sessionPreventPlay.get(response.systemNumber).next(response.message as SessionPreventPlay);
        break;
      }
      default:
        this.logging.warn(`[SessionService:: unknown data: ${JSON.stringify(response)}`);
        break;
    }
  }

  private updateSystemStatus(stateList: SystemStateList): void {
    stateList?.systemStates?.forEach(systemState => {
      if (systemState.state !== State.UNKNOWN && this.activeSystems.has(systemState.id) && !this.activeSystems.get(systemState.id)) {
        // Check for and remove any errors that are present in the current system due to the previous shutdown operation.
        const lostId = commsStateErrorId(systemState.id);
        if (this.errorService.getError(lostId)) {
          this.errorService.deleteError(lostId);
        }
        this.commsStateService.initialiseCommsStateConnection(systemState.id, this.isWebServerUp(systemState.id));
        this.activeSystems.set(systemState.id, true);
      } else if (systemState.state === State.UNKNOWN && this.activeSystems.has(systemState.id) && this.activeSystems.get(systemState.id)) {
        this.commsStateService.closeCommsStateConnection(systemState.id);
        this.activeSystems.set(systemState.id, false);
      }
      this.updateWebServerStateIfChanged(systemState, this.webServerUpStatus, [State.UNKNOWN, State.DROPPED], true);
      this.updateWebServerStateIfChanged(systemState, this.webServerLoadedStatus, [State.PAUSED, State.RUNNING]);
      this.updateWebSocketError(systemState);
    });
  }

  /**
   * Determines if the web server's state matches or does not match the specified valid states.
   *
   * @param systemState - The current system state containing module states.
   * @param validStates - An array of states to check against.
   * @param negate - If true, returns true when the state is NOT in the valid states.
   * @returns True if the state matches (or does not match, if negate is true) any of the valid states.
   */
  private getWebServerState(systemState: SystemState, validStates: State[], negate = false): boolean {
    const webServerState = systemState?.moduleStates?.find(m => m.name === 'Web Server')?.state;
    return webServerState ? (negate ? !validStates.includes(webServerState) : validStates.includes(webServerState)) : false;
  }

  /**
   * Updates the web server state in a specified map if the state has changed and matches the given conditions.
   *
   * @param systemState - The current system state containing module states.
   * @param statusMap - The map to store and update states for each system ID.
   * @param validStates - An array of states to check against for triggering an update.
   * @param negate - If true, updates the map if the state does NOT match the valid states.
   */
  private updateWebServerStateIfChanged(
    systemState: SystemState,
    statusMap: Map<number, BehaviorSubject<boolean>>,
    validStates: State[],
    negate = false
  ): void {
    const newWebServerState = this.getWebServerState(systemState, validStates, negate);

    if (statusMap.has(systemState.id)) {
      const currentBehaviorSubject = statusMap.get(systemState.id);
      if (currentBehaviorSubject && currentBehaviorSubject.value !== newWebServerState) {
        currentBehaviorSubject.next(newWebServerState);
      }
    } else {
      // Add a new BehaviorSubject if system ID is not yet in the map
      statusMap.set(systemState.id, new BehaviorSubject<boolean>(newWebServerState));
    }
  }

  /**
   * Returns if the specified system is running a session (paused or running).
   *
   * @param id - The ID of the system to retrieve the status for.
   */
  public isWebServerSessionActive(id: number): Observable<boolean> {
    return this.webServerLoadedStatus.get(id);
  }

  /**
   * Returns if the specified system is reachable.
   *
   * @param id - The ID of the system to retrieve the status for.
   */
  public isWebServerUp(id: number): Observable<boolean> {
    return this.webServerUpStatus.get(id);
  }

  // TODO Perhaps we should wrap up more/all of the CommsStateService API with this class?
  /**
   * Performs all the housekeeping required to unload a Scenario
   *
   * @param systemName The system of interest.
   */
  public unloadScenario(systemName: number): void {
    this.unloadRequested.set(systemName, true);
    this.store.dispatch(sessionActions.updateSessionState({ systemNumber: systemName, state: PlayPauseStopEnum.STOP }));

    // that allows the person to launch a new session in case the time limit was reached previously
    // this is not a simple subject because people can switch between tabs and thus lost the subject value
    // So when they resubscribe, they need to get the value again. But we don't want the previous session timeout to influence the new one.
    this.sessionPreventPlay.get(systemName)?.complete();
    this.sessionPreventPlay.set(systemName, new ReplaySubject<SessionPreventPlay>());

    this.commsStateService.unloadScenario(systemName);
  }

  /**
   * Returns true if a request to unload was made by calling ```unloadScenario``` on this object after the session started.
   *
   * @param systemName The system of interest.
   */
  public isScenarioUnloadRequested(systemName: number): boolean {
    return this.unloadRequested.get(systemName) ?? false;
  }

  public saveSession(systemNumber: number): void {
    if ((this.commsStateService as any).saveSession) {
      (this.commsStateService as any).saveSession(systemNumber);
    }
  }

  public startReplayOrSession(
    systemNumber: number,
    simulatorId: number,
    simulator: Simulator,
    physicalHub: PhysicalHub,
    sessionSetupData: SingleSimSessionSetupData,
    autonomousMode: boolean
  ): Promise<boolean> {
    if (sessionSetupData?.session?.sessionId) {
      return this.startReplay(systemNumber, simulatorId, physicalHub, sessionSetupData, sessionSetupData.session.sessionId);
    } else {
      return this.startSession(systemNumber, simulator, physicalHub, sessionSetupData, autonomousMode);
    }
  }

  public startSession(
    systemNumber: number,
    simulator: Simulator,
    physicalHub: PhysicalHub,
    sessionSetupData: SingleSimSessionSetupData,
    autonomousMode: boolean
  ): Promise<boolean> {
    this.sessionLogging.log(SessionLogEvents.PRESSED_START_SESSION, {
      simulatorName: simulator.name,
      scenarioName: sessionSetupData.scenario.name,
      scenarioWorld: sessionSetupData.scenario.tracknetworkName,
      train: sessionSetupData.scenarioTrain.name,
      sessionId: undefined
    });
    return new Promise<boolean>((resolve, reject) => {
      const simulatorId: number = simulator.id;
      const pendingSession$ = this.setupPendingSession(systemNumber);
      this.handlePendingSession(pendingSession$);

      const instructorId = autonomousMode ? NO_INSTRUCTOR : sessionSetupData.instructor.id;
      const traineeDatas = this.prepareTraineeData(simulatorId, physicalHub, sessionSetupData);
      const hubDatas = this.prepareHubData(simulatorId, physicalHub, sessionSetupData);

      const scenarioDefData = new ScenarioDefinitionData(sessionSetupData.scenario.scenarioId, simulatorId, [new SimulatorData(simulatorId)], hubDatas);

      this.generateSessionId().subscribe((sessionId: number) => {
        if (sessionId == null) {
          this.handleSessionIdError();
          pendingSession$.next(false);
          reject(StartSessionRejected.NO_SESSION_ID);
          return;
        }

        this.sessionLogging.log(SessionLogEvents.SESSION_ID_GENERATED, {
          simulatorName: simulator.name,
          scenarioName: sessionSetupData.scenario.name,
          scenarioWorld: sessionSetupData.scenario.tracknetworkName,
          train: sessionSetupData.scenarioTrain.name,
          sessionId,
          time: new Date()
        });

        const sessionDefData = this.createSessionDefinition(sessionId, instructorId, sessionSetupData, traineeDatas);

        // Some example of what an initial condition in the session request might look like
        // const makeItRain = new NumberValues('Rain Percentage', 42);
        // const rainObjId = new ObjectIdentifier(2);

        // const chrisTrain = new NumberValues('Air Horn Failure', 2);
        // const trainId = new ObjectIdentifier(100);

        // const initialValues = new InitialValues([ rainObjId ], [ makeItRain ], []);
        // const initialValues2 = new InitialValues([ trainId ], [ chrisTrain ], []);
        // sessionDefData.initialValues = [ initialValues, initialValues2 ];

        this.requestScenarioAndSession(systemNumber, scenarioDefData, sessionDefData, sessionSetupData);
        resolve(true);
      });
    });
  }

  private requestScenarioAndSession(
    systemNumber: number,
    scenarioDefData: ScenarioDefinitionData,
    sessionDefData: SessionDefinitionData,
    sessionSetupData: SessionSetupData,
    simulation = true
  ): void {
    this.commsStateService.requestScenario(systemNumber, new ScenarioDefinition(scenarioDefData));
    this.commsStateService.requestSession(systemNumber, new SessionDefinition(sessionDefData, simulation));
    this.store.dispatch(
      sessionActions.updateSessionSetup({
        systemNumber,
        sessionSetup: cloneDeep(sessionSetupData)
      })
    );
  }

  private createSessionDefinition(
    sessionId: number,
    instructorId: string,
    sessionSetupData: SessionSetupData,
    traineeDatas: TraineeData[],
    preview: boolean = false
  ): SessionDefinitionData {
    const sessionDefData = new SessionDefinitionData(
      instructorId,
      sessionId,
      sessionSetupData.startTime,
      [], // Role Locations are typically set by project side plugins
      traineeDatas,
      preview
    );
    sessionDefData.startPositions = sessionSetupData?.startPositions ?? [];
    return sessionDefData;
  }

  private handleSessionIdError(): void {
    const errMsg = 'Could not generate a Session ID! Make sure Base X is running and it allows write operations.';
    this.logging.error(errMsg + '\nRemember that using the Base X GUI to connect to a database will lock that database.');
  }

  private generateSessionId(): SelfCompletingObservable<number | null> {
    return this.dataAccessService
      .callQueryJson<number>({
        query: 'generate_session_id',
        operation: 'generateSessionId',
        debugMsg: `fetched next session id`
      })
      .pipe(catchError(err => of(null)));
  }

  private prepareTraineeData(simulatorId: number, physicalHub: PhysicalHub, sessionSetupData: SingleSimSessionSetupData): TraineeData[] {
    const traineeId = sessionSetupData.trainee.id;
    const traineeData = new TraineeData(simulatorId, physicalHub.hubId, traineeId);
    return [traineeData];
  }
  private prepareHubData(simulatorId: number, physicalHub: PhysicalHub, sessionSetupData: SessionSetupData): HubData[] {
    // TODO need to find ID of this
    const locationType = 1; // sessionSetupData.location.locationType;
    const mode = 1; // sessionSetupData.location.hubMode;

    const hubData = new HubData(
      simulatorId,
      physicalHub.hubId,
      physicalHub.hubId,
      locationType,
      sessionSetupData.scenarioTrain.id,
      sessionSetupData.location.vehicleIndex,
      sessionSetupData.location.xOffset,
      sessionSetupData.location.yOffset,
      sessionSetupData.location.zOffset,
      sessionSetupData.location.headingOffset,
      sessionSetupData.location.pitchOffset,
      sessionSetupData.location.rollOffset,
      mode
    );
    const hubDatas = [hubData];
    hubDatas.push(...this.createSessionAutoHubData(hubDatas, this.autoHubs));

    return hubDatas;
  }

  private setupPendingSession(systemNumber: number): Subject<boolean> {
    const pendingSession$ = this.pendingSessions.get(systemNumber);
    pendingSession$.next(true);
    return pendingSession$;
  }

  private handlePendingSession(pendingSession$: Subject<boolean>): Subscription {
    // wait for pendingSession to emit false - if it doesn't before the timeout then show snackbar warning.
    return pendingSession$
      .pipe(
        filter(x => x === false),
        first(),
        timeout(this.sessionLoadTimeout)
      )
      .subscribe({
        error: this.handleSessionTimeout(pendingSession$)
      });
  }
  private handleSessionTimeout(pendingSession$: Subject<boolean>): (err: any) => void {
    return err => {
      this.snackBar.open(this.translate.instant(t('Unable to start session, simulator did not respond.')), this.translate.instant(DISMISS), {
        duration: 10000
      });
      pendingSession$.next(false);
    };
  }

  // TODO: Does it still require refinement?
  public startPreview(
    systemNumber: number,
    simulatorId: number,
    physicalHub: PhysicalHub,
    sessionSetupData: SingleSimPreviewSetupData,
    dynamicPreview: boolean
  ): Promise<boolean> {
    return new Promise<boolean>((resolve, reject) => {
      const instructorId = sessionSetupData.instructor.id;
      const traineeDatas = new Array<TraineeData>();
      const hubDatas = this.prepareHubData(simulatorId, physicalHub, sessionSetupData);

      const scenarioDefData = new ScenarioDefinitionData(sessionSetupData.scenario.scenarioId, simulatorId, [new SimulatorData(simulatorId)], hubDatas);

      this.generateSessionId().subscribe(sessionId => {
        if (sessionId == null) {
          this.handleSessionIdError();
          reject(StartSessionRejected.NO_SESSION_ID);
          return;
        }

        const sessionDefData = this.createSessionDefinition(sessionId, instructorId, sessionSetupData, traineeDatas, dynamicPreview);

        this.requestScenarioAndSession(systemNumber, scenarioDefData, sessionDefData, sessionSetupData);

        // TODO: Is this specific to preview?
        this.store.dispatch(sessionActions.sessionDefinition({ systemNumber, sessionDefinition: new SessionDefinition(sessionDefData) }));

        resolve(true);
      });
    });
  }

  public startReplay(
    systemNumber: number,
    simulatorId: number,
    physicalHub: PhysicalHub,
    sessionSetupData: SingleSimSessionSetupData,
    sessionId: number
  ): Promise<boolean> {
    return new Promise<boolean>((resolve, reject) => {
      const pendingSession$ = this.setupPendingSession(systemNumber);
      this.handlePendingSession(pendingSession$);

      const instructorId = sessionSetupData.instructor.id;
      const traineeDatas = this.prepareTraineeData(simulatorId, physicalHub, sessionSetupData);
      const hubDatas = this.prepareHubData(simulatorId, physicalHub, sessionSetupData);

      const scenarioDefData = new ScenarioDefinitionData(sessionSetupData.scenario.scenarioId, simulatorId, [new SimulatorData(simulatorId)], hubDatas);

      if (sessionId == null) {
        this.handleSessionIdError();
        pendingSession$.next(false);
        reject(StartSessionRejected.NO_SESSION_ID);
        return;
      }

      const sessionDefData = this.createSessionDefinition(sessionId, instructorId, sessionSetupData, traineeDatas);

      this.requestScenarioAndSession(systemNumber, scenarioDefData, sessionDefData, sessionSetupData, false);
      resolve(true);
    });
  }

  /**
   * Creates HubDatas reflect some template HubDatas but using different hub types.
   *
   * @param templateHubData The HubDatas to base our hubs on.
   * @param autoHubs Descriptions of the hubs to automatically create.
   *
   * @return HubDatas that reflect the given template HubDatas.
   */
  public createSessionAutoHubData(templateHubData: Array<HubData>, autoHubs: AutoHubDescription[]): Array<HubData> {
    const instructorHubConfigs = new Array<HubData>();

    // FIXME This assumes there will never be multiple trainee hubs on one sim.
    const simHubConfigMap = new Map<number, HubData>();

    for (const config of templateHubData) {
      simHubConfigMap.set(config.simulatorId, config);
    }

    for (const sim of Array.from(this.findHubSimulators(templateHubData))) {
      for (const autoHub of autoHubs) {
        instructorHubConfigs.push(...this.createAutoHubDataForSim(sim, simHubConfigMap.get(sim.id), autoHub));
      }
    }

    return instructorHubConfigs;
  }

  /**
   * Returns an observable for whether the system is waiting on the backend to start a session.
   */
  public isSessionPending(systemNumber: number): BehaviorSubject<boolean> {
    return this.pendingSessions.get(systemNumber);
  }

  private findHubSimulators(hubDatas: Array<HubData>): Set<Simulator> {
    const requestedSimulators = new Set<Simulator>();

    for (const hubData of hubDatas) {
      requestedSimulators.add(this.simulators.get(hubData.simulatorId));
    }

    return requestedSimulators;
  }

  /**
   * Creates HubDatas reflect some template HubDatas but using different hub types.
   *
   * @param sim The simulator where the hubs reside.
   * @param templateHubData The HubData to base our hubs on.
   * @param autoHubs Describes the hub to automatically create.
   *
   * @return A HubData that reflects the given template HubData.
   */
  public createAutoHubDataForSim(sim: Simulator, templateHubData: HubData, autoHub: AutoHubDescription): Array<HubData> {
    let instructorHubType: HubType;
    let instructorHubMode: HubMode;

    for (const hub of sim.physicalHub) {
      const type = hub.type;
      // we can do this as names are unique
      if (autoHub.hubType === type.name) {
        instructorHubType = type;
        break;
      }
    }

    if (!instructorHubType) {
      return [];
    }

    for (const mode of instructorHubType.hubTypeMode) {
      // we can do this as names are unique
      if (autoHub.hubMode === mode.name) {
        instructorHubMode = mode;
        break;
      }
    }

    if (!instructorHubMode) {
      return [];
    }

    return this.createAutoHubDataForSimHubTypeMode(sim, templateHubData, instructorHubType, instructorHubMode);
  }

  /**
   * Creates HubDatas reflect some template HubDatas but using different hub types.
   *
   * @param sim The simulator where the hubs reside.
   * @param templateHubData The HubData to base our hubs on.
   * @param autoHubType The type of the hub to automatically create.
   * @param autoHubMode The mode to use for the automatically created hub.
   *
   * @return A HubData that reflects the given template HubData.
   */
  public createAutoHubDataForSimHubTypeMode(sim: Simulator, templateHubData: HubData, autoHubType: HubType, autoHubMode: HubMode): Array<HubData> {
    const result = new Array<HubData>();

    for (const hub of sim.physicalHub) {
      if (hub.type.id === autoHubType.id) {
        result.push(
          new HubData(
            sim.id,
            hub.hubId,
            hub.hubId,
            templateHubData.locationType,
            templateHubData.scenarioTrainId,
            templateHubData.vehicleIndex,
            templateHubData.xOffset,
            templateHubData.yOffset,
            templateHubData.zOffset,
            templateHubData.hOffset,
            templateHubData.pOffset,
            templateHubData.rOffset,
            autoHubMode.id
          )
        );
      }
    }

    return result;
  }

  public isSessionSimulation(systemNumber: number): boolean {
    return this.getSessionSimulation(systemNumber).getValue();
  }

  public isSessionSimulation$(systemNumber: number): Observable<boolean> {
    return this.getSessionSimulation(systemNumber).asObservable();
  }

  private getSessionSimulation(systemNumber: number): BehaviorSubject<boolean> {
    return computeIfAbsent(this.sessionSimulation, systemNumber, () => new BehaviorSubject(true));
  }

  private initSessionLoadTimeout(): void {
    // default value is 10 seconds if not provided or you provide invalid data.
    const loadTimeout = this.registry.getNumber(['session', 'loadTimeout'], 10);
    if (typeof loadTimeout !== 'number') {
      this.sessionLoadTimeout = 10000;
    } else {
      this.sessionLoadTimeout = loadTimeout * 1000; // registry value is in seconds
    }
  }

  private updateWebSocketError(systemState: SystemState): void {
    if (systemState?.health === Health.WEBSOCKET_ERROR) {
      if (!this.errorService.getError('socket')) {
        this.errorService.addError({
          type: 'socket',
          id: 'socket',
          icon: OksygenIcon.SERVER,
          severity: Severity.ERROR,
          asString() {
            return t(`${this.id} connection interrupted.`);
          }
        });
      }
      this.systemStore.dispatch(
        sessionActions.sessionError({
          systemNumber: systemState.id,
          sessionError: t('Connection interrupted.')
        })
      );
    } else {
      // const tab = this.tabService.getTabGroup('warning-tab');
      // this.tabService.removeTabGroup(tab);
      if (this.errorService.getError('socket')) {
        this.errorService.deleteError('socket');
      }
    }
  }
}
