/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { LngLat } from 'maplibre-gl';
import { BehaviorSubject, combineLatest, Observable, of, Subject, Subscription, timer } from 'rxjs';
import { auditTime, distinctUntilChanged, filter, map, switchMap, tap } from 'rxjs/operators';

import { filterTruthy, shareReplayOne, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { DriverType } from '@oksygen-sim-core-libraries/components-services/data-services';
import { EnvironmentProperty, VisionState } from '@oksygen-sim-core-libraries/components-services/vision-endpoint';
import { FeatureCreateMessageData } from '@oksygen-sim-core-libraries/core-vision-messages';
import { Orientation, Point3D, SegOffsetOriented, toOrientation } from '@oksygen-sim-core-libraries/data-types/common';
import { IReachablePathFinder, SegmentPosition } from '@oksygen-sim-train-libraries/components-services/common';
import { INITIAL_STATE, ObjectContainer, SimObject, STATE } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { FeatureAndAngle, PreviewVisionState, Scenario, ScenarioPreviewCamera } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { Consist, ConsistDataService, TrainStateData, TrainVisionManager, UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';
import { Skin, TrackDataService } from '@oksygen-sim-train-libraries/components-services/world-definition';
import { Environment } from '@oksygen-sim-train-libraries/components-services/world-environment';
import { VehiclePositionData } from '@oksygen-sim-train-libraries/train-vision-messages';

import { ScenarioContext } from '../contexts/scenario-context';

const ENVIRONMENTAL_EFFECTS_OFF: Environment = {
  cloudDensityPercentage: 0,
  fogPercentage: 0,
  hazePercentage: 0,
  lightningPercentage: 0,
  rainPercentage: 0,
  snowPercentage: 0,
  sunBrightnessPercentage: 0,
  sunGlarePercentage: 0,
  tunnelSmokePercentage: 0,
  windDirectionAngle: 0,
  windGust: 0,
  windStrengthKmH: 0
};
/**
 * Updates vision with the current Scenario state to help the user visualise it.
 *
 * Intended for use while editing a Scenario.
 *
 * Instances of this class need to be retained while the Scenario editing is in progress.
 * Typically a long lived service would manage object lifetime.
 * It's usually not a good idea for a UI component to manage these objects,
 * as components may be destroyed when you navigate away from them.
 */
export class ScenarioPreviewManager {
  private static readonly TIME_RESET_TIMER = timer(0, 1000 * 60);

  readonly trackCameraHeight = 2.8; // in meters from the ground
  readonly maxAerialCameraHeight = 3000; // in meters from the ground
  readonly refreshRateFps = 25;

  /** Signals that vision needs to be started. */
  private startSubject = new Subject();

  private consists: Consist[];

  /** Retains the last value we sent to the vision for the scenario track. */
  private visionTrack: string;
  /** Retains the last value we sent to the vision for the scenario skin. */
  private visionSkin: Skin;
  /** Retains the last value we sent to the vision for the time of day to display. */
  private previewWorldTimeSeconds: number;
  /** Retains the last value we sent to the vision for the environmental effects to display. */
  private visionEnvironmentSettings = ENVIRONMENTAL_EFFECTS_OFF;
  /** Retains the last values we sent to the vision for the trains. */
  private visionScenarioTrains: TrainStateData[] = [];
  /** Retains the last values we sent to the vision for the scenario objects. */
  private visionScenarioObjects: FeatureCreateMessageData[] = [];

  private settingsUpdated$ = new BehaviorSubject(null);

  private selectedCameraSubject: BehaviorSubject<ScenarioPreviewCamera>;
  // FIXME this is only interesting for the camera, which makes its presense here a bit wonky.
  // The fix is probably to make camera management a function of this preview manager.
  private focusedObjectSubject = new BehaviorSubject<SimObject>(null);

  private aerialCameraPositionSubject = new BehaviorSubject<Point3D>(null);
  private objectCameraPositionSubject = new BehaviorSubject<FeatureAndAngle>(null);
  private trackCameraPositionSubject = new BehaviorSubject<SegmentPosition>(null);

  private visionStateSubject = new BehaviorSubject<PreviewVisionState>(PreviewVisionState.NOT_LOADED);

  private subscription: Subscription;

  private objectCameraAngle: number;

  // FIXME this is only interesting for the camera, which makes its presense here a bit wonky.
  // The fix is probably to make camera management a function of this preview manager.
  private aerialLngLat = new LngLat(0, 0);

  private stateChangeSubscription: Subscription;

  private showEnvironmentalEffects = false;
  private showScenarioTime = false;
  showEnvironmentalEffects$ = new BehaviorSubject<boolean>(false);
  showPreview$ = new BehaviorSubject<boolean>(false);

  constructor(
    // FIXME There is a lot of potential for this ID to be inadequate for identifying the controller,
    // especially considering that we currently use scenario IDs and no contextual information.
    public readonly id: string,
    private readonly logger: Logging,
    private readonly consistDataService: ConsistDataService,
    private readonly trackDataService: TrackDataService,
    private readonly context: ScenarioContext,
    private readonly visionManager: TrainVisionManager,
    defaultCamera = ScenarioPreviewCamera.TRACK
  ) {
    this.selectedCameraSubject = new BehaviorSubject<ScenarioPreviewCamera>(defaultCamera);
    this.consistDataService
      ?.data()
      .pipe(takeOneTruthy())
      .subscribe(c => (this.consists = c));

    // subscribe to the controller and state change permanently,
    // but only update if we are the controller
    this.stateChangeSubscription = combineLatest([this.visionManager.visionController$, this.visionManager.simulationStateChanged$]).subscribe(
      ([controller, data]) => {
        if (controller === this.id) {
          switch (data?.state) {
            // We treat ready as loading, since we expect the vision to be running/paused
            // once all our initialisation requests are processed.
            case VisionState.READY:
            case VisionState.LOADING:
              this.visionStateSubject.next(PreviewVisionState.LOADING);
              break;
            case VisionState.UNLOADING:
              this.visionStateSubject.next(PreviewVisionState.UNLOADING);
              break;
            case VisionState.PAUSED:
            case VisionState.RUNNING:
            case VisionState.SHUTTLING:
            case VisionState.SEEKING:
              this.visionStateSubject.next(PreviewVisionState.LOADED);
              break;
            case VisionState.WAITING:
            case VisionState.ERROR:
            case VisionState.UNKNOWN:
            default:
              this.onVisionControlLost();
              break;
          }
        } else {
          this.onVisionControlLost();
        }
      }
    );
  }

  private onVisionControlLost(): void {
    this.visionStateSubject.next(PreviewVisionState.NOT_LOADED);

    // Reset cached vision state to reflect the vision does not have our settings applied.
    this.visionTrack = null;
    this.visionSkin = null;
    this.visionEnvironmentSettings = ENVIRONMENTAL_EFFECTS_OFF;
    this.visionScenarioTrains = [];
    this.aerialCameraPositionSubject.next(null);
    this.objectCameraPositionSubject.next(null);
    this.trackCameraPositionSubject.next(null);
  }

  destroy(): void {
    this.stopVision();
    this.startSubject.complete();
    this.stateChangeSubscription?.unsubscribe();
    this.selectedCameraSubject.complete();
    this.focusedObjectSubject.complete();
    this.aerialCameraPositionSubject.complete();
    this.objectCameraPositionSubject.complete();
    this.trackCameraPositionSubject.complete();
    this.visionStateSubject.complete();
    this.settingsUpdated$.complete();
    this.showEnvironmentalEffects$.complete();
  }

  /**
   * Emits true when the scenario contains enough information to start the vision.
   */
  get scenarioSuitable$(): Observable<boolean> {
    return this.context.data$.pipe(
      map(s => this.isValidVisionScenario(s)),
      distinctUntilChanged(),
      shareReplayOne()
    );
  }

  /**
   * Emits true when the vision may be started.
   * Does not emit false when the vision has been started.
   */
  get visionStartable$(): Observable<boolean> {
    return combineLatest([this.scenarioSuitable$, this.visionAvailable$]).pipe(
      map(([s, a]) => s && a),
      shareReplayOne()
    );
  }

  /**
   * Emits true when the vision is loaded and under this object's control.
   */
  get visionUnderControl$(): Observable<boolean> {
    return combineLatest([this.visionState$, this.controllingVision$]).pipe(
      map(([state, control]) => control && state === PreviewVisionState.LOADED),
      shareReplayOne()
    );
  }

  disconnectFromComms(): void {
    this.visionManager.disconnectFromComms();
  }

  connectToComms(): void {
    this.visionManager.connectToComms();
  }

  /**
   * Initialise Vision
   */
  startVision(): void {
    this.visionScenarioObjects = [];
    const visionControl = this.visionManager.requestControl(this.id);

    if (visionControl) {
      if (!this.subscription) {
        this.subscription = new Subscription();

        this.subscription.add(
          this.visionManager.visionController$
            .pipe(
              // Don't process updates while we don't have control
              filter(id => id === this.id),
              switchMap(x => this.startSubject),
              switchMap(x => this.settingsUpdated$),
              switchMap(x => this.context.data$),
              // Restrict processing when we get rapidly changing values (such as someone dragging a slider).
              auditTime(1000 / this.refreshRateFps),
              tap(scenario => {
                if (!this.isValidVisionScenario(scenario)) {
                  this.stopVision();
                  return;
                }

                const newVisionTime = new Date(scenario.scenarioStartTime);

                if (!this.showScenarioTime) {
                  // set to midday to have best visibility
                  newVisionTime.setUTCHours(12, 0, 0, 0);
                }

                this.previewWorldTimeSeconds = toSeconds(newVisionTime);

                if (this.visionTrack !== scenario.tracknetworkName || this.visionSkin?.name !== scenario.tracknetworkSkinName) {
                  this.visionTrack = scenario.tracknetworkName;
                  this.visionSkin = this.trackDataService
                    .getTracks()
                    .get(scenario.tracknetworkName)
                    .skin.find((s: Skin) => s.name === scenario.tracknetworkSkinName);

                  this.visionManager.initializeNetwork(this.id, {
                    networkName: this.visionTrack,
                    worldName: this.visionSkin.code,
                    dateTime: this.previewWorldTimeSeconds
                  });

                  this.visionManager.runSimulation(this.id);
                }

                this.updateEnvironment(this.showEnvironmentalEffects ? scenario.environment : ENVIRONMENTAL_EFFECTS_OFF);

                this.updateVisionObjects(scenario);
              }),
              switchMap(x => combineLatest([this.context.trains.data(), this.context.pathFinder$]))
            )
            .pipe(
              // This redundant pipe helps typescript know what types it's working with
              tap(([trains, pathFinder]) => this.updateVisionTrains(trains, pathFinder)),
              // We periodically reset the time to ensure vision.
              switchMap(x => ScenarioPreviewManager.TIME_RESET_TIMER)
            )
            .subscribe(x => this.visionManager.setTimeOfDay(this.id, { timeOfDay: this.previewWorldTimeSeconds }))
        );

        this.subscription.add(
          this.aerialCameraPositionSubject
            .pipe(
              filter(() => this.selectedCameraSubject?.value === ScenarioPreviewCamera.AERIAL),
              filterTruthy(),
              distinctUntilChanged(),
              auditTime(1000 / this.refreshRateFps)
            )
            .subscribe((pos: Point3D) => {
              if (pos.z >= this.maxAerialCameraHeight) pos.z = this.maxAerialCameraHeight;
              this.visionManager.setWorldCamera(this.id, pos);
            })
        );

        this.subscription.add(
          this.objectCameraPositionSubject
            .pipe(
              filter(() => this.selectedCameraSubject?.value === ScenarioPreviewCamera.OBJECT),
              filterTruthy(),
              distinctUntilChanged(),
              auditTime(1000 / this.refreshRateFps)
            )
            .subscribe((pos: FeatureAndAngle) => {
              this.visionManager.setFeatureCamera(this.id, {
                featureId: pos.featureId,
                heading: pos.angleInDegrees,
                pitch: 20.0,
                zoom: 1.0
              });
            })
        );

        this.subscription.add(
          this.trackCameraPositionSubject
            .pipe(
              filter(() => this.selectedCameraSubject?.value === ScenarioPreviewCamera.TRACK),
              filterTruthy(),
              distinctUntilChanged(),
              auditTime(1000 / this.refreshRateFps)
            )
            .subscribe((pos: SegmentPosition) => {
              this.visionManager.setTrackCamera(this.id, {
                segmentId: pos.segmentId,
                segmentOffset: pos.offset,
                fromAlpha: pos.fromAlpha,
                cameraHeight: this.trackCameraHeight
              });
            })
        );
      }

      this.startSubject.next(undefined);
    }
  }

  private isValidVisionScenario(scenario: Scenario): boolean {
    return !!scenario && !!scenario.tracknetworkName && !!scenario.tracknetworkSkinName && !!scenario.scenarioStartTime;
  }

  /**
   * Emits true when this manager is in control of vision or vision is not under control.
   */
  get visionAvailable$(): Observable<boolean> {
    return this.visionManager.visionController$.pipe(switchMap(id => of(!id || id === this.id)));
  }

  /**
   * Emits true when this manager is in control of vision.
   */
  get controllingVision$(): Observable<boolean> {
    return this.visionManager.visionController$.pipe(switchMap(id => of(id === this.id)));
  }

  selectCamera(camera: ScenarioPreviewCamera): void {
    this.selectedCameraSubject.next(camera);

    if (camera === ScenarioPreviewCamera.TRAIN) {
      this.visionManager.setTrainCamera(this.id);
    }
  }

  get selectedCamera$(): Observable<ScenarioPreviewCamera> {
    return this.selectedCameraSubject.pipe(shareReplayOne());
  }

  getSelectedCamera(): ScenarioPreviewCamera {
    return this.selectedCameraSubject.getValue();
  }

  setFocusedObject(object: SimObject): void {
    this.focusedObjectSubject.next(object);
  }

  get focusedObject$(): Observable<SimObject> {
    return this.focusedObjectSubject.pipe(shareReplayOne());
  }

  get visionState$(): Observable<PreviewVisionState> {
    return this.visionStateSubject.pipe(shareReplayOne());
  }

  setAerialCameraPosition(position: Point3D): void {
    this.aerialCameraPositionSubject.next(position);
  }

  setAerialCameraLngLat(aerialLngLat: LngLat): void {
    this.aerialLngLat = aerialLngLat;
  }

  getAerialCameraLngLat(): LngLat {
    return this.aerialLngLat;
  }

  setObjectCameraPosition(position: FeatureAndAngle): void {
    this.objectCameraPositionSubject.next(position);
  }

  getObjectCameraPosition(): FeatureAndAngle {
    return this.objectCameraPositionSubject.getValue();
  }

  setObjectCameraAngle(angle: number): void {
    this.objectCameraAngle = angle;
  }

  getObjectCameraAngle(): number {
    return this.objectCameraAngle;
  }

  setTrackCameraPosition(position: SegmentPosition): void {
    this.trackCameraPositionSubject.next(position);
  }

  getTrackCameraPosition(): SegmentPosition {
    return this.trackCameraPositionSubject.getValue();
  }

  /**
   * Stops vision and releases control.
   */
  public stopVision(): void {
    this.disconnectFromComms();

    switch (this.visionStateSubject.getValue()) {
      case PreviewVisionState.LOADED:
      case PreviewVisionState.LOADING:
        this.visionManager.terminateSimulation(this.id);
    }
    this.subscription?.unsubscribe();
    this.subscription = null;

    this.visionManager.releaseControl(this.id);
  }

  public setShowScenarioTime(value: boolean): void {
    this.showScenarioTime = value;
    this.showPreview$.next(value);
    this.settingsUpdated$.next(null);
  }

  public setShowEnvironmentalEffects(value: boolean): void {
    this.showEnvironmentalEffects = value;
    this.showEnvironmentalEffects$.next(this.showEnvironmentalEffects);
    this.settingsUpdated$.next(null);
  }

  private updateVisionObjects(scenario: Scenario): void {
    scenario.world?.objectModification?.forEach(mod => {
      if (!mod) {
        return;
      }
      const object = this.context.objects.getObjectByName(mod.name);
      if (!object) {
        return;
      }
      this.sendObjectProperties(object);
    });

    const scenarioObjectIds: Array<number> = [];
    scenario.world?.object?.forEach(object => {
      scenarioObjectIds.push(object.id);
      this.updateScenarioObject(object);
    });

    const deletedObjects = this.visionScenarioObjects.filter(o => !scenarioObjectIds.includes(o.featureId));
    deletedObjects.forEach(o => {
      this.visionManager.destroyObject(this.id, o.featureId);
      this.visionScenarioObjects.splice(
        this.visionScenarioObjects.findIndex(o2 => o2.featureId === o.featureId),
        1
      );
    });
  }

  /**
   * Set an object property in scenario preview (vision engine).
   *
   * @param objectId the object
   * @param propertyName the property (generally either INITIAL STATE or USER STATE)
   * @param propertyValue the value to set it to
   */
  private updateScenarioObject(object: ObjectContainer): void {
    const visionObjectIndex = this.visionScenarioObjects.findIndex(o => o.featureId === object.id);
    let visionObject = visionObjectIndex >= 0 ? this.visionScenarioObjects[visionObjectIndex] : null;

    // Check for fundamental changes that will require the object to be completely rebuilt.
    if (
      visionObject &&
      (visionObject.featureName !== object.name ||
        visionObject.featureType !== object.objectType.name ||
        visionObject.featureTransformData.x !== (object.location?.geometry?.x ?? 0) ||
        visionObject.featureTransformData.y !== (object.location?.geometry?.y ?? 0) ||
        visionObject.featureTransformData.z !== (object.location?.geometry?.z ?? 0) ||
        visionObject.featureTransformData.h !== (object.location?.geometry?.h ?? 0) ||
        visionObject.featureTransformData.p !== (object.location?.geometry?.p ?? 0) ||
        visionObject.featureTransformData.r !== (object.location?.geometry?.r ?? 0))
    ) {
      this.visionManager.destroyObject(this.id, object.id);
      this.visionScenarioObjects.splice(visionObjectIndex, 1);
      visionObject = null;
    }

    // Build the object if required.
    if (!visionObject) {
      visionObject = {
        featureId: object.id,
        featureName: object.name,
        featureType: object.objectType.name,
        raycastOffset: 0,
        featureTransformData: {
          x: 0,
          y: 0,
          z: 0,
          h: 0,
          p: 0,
          r: 0,
          ...object.location?.geometry,
          scaleX: 1,
          scaleY: 1,
          scaleZ: 1
        },
        numberProperties: [],
        stringProperties: [],
        timeStamp: 0
      };

      this.visionManager.createObject(this.id, visionObject);

      // if you destroyed and recreated the currently focused object, we need to update the camera because it has probably been updated before the re-creation
      // It does mean that the camera might update twice for one object modification.
      if(this.getObjectCameraPosition()?.featureId === visionObject.featureId) {
        // We need a new camera position because there is a distinct until changed so we recreate an object (reference equality)
        this.setObjectCameraPosition({...this.getObjectCameraPosition()});
      }
      this.visionScenarioObjects.push(visionObject);
    }

    // Update the object's properties.
    this.sendObjectProperties(object);
  }

  private sendObjectProperties(object: ObjectContainer): void {
    // TODO This may get sluggish for scenarios with lots of objects/modifications.
    // We could cache what values we sent and only send updates.
    const properties = Object.keys(object.properties);
    properties?.forEach(key => {
      let propertyName = key;
      const propertyValue = object.properties[key];
      let value = typeof propertyValue === 'boolean' ? +propertyValue : propertyValue; // convert bool to 1 / 0

      // We need to send State IDs to the vision, but we have State names in properties.
      if (propertyName === INITIAL_STATE || propertyName === STATE) {
        propertyName = STATE;
        let stateId: number;
        object.states.forEach(s => {
          if (s.name === propertyValue) {
            stateId = s.id;
          }
        });

        if (stateId !== undefined) {
          value = stateId;
        }
      }

      this.setObjectProperty(object.id, propertyName, value);
    });
  }

  /**
   * Set an object property in scenario preview (vision engine).
   *
   * @param objectId the object
   * @param propertyName the property (generally either INITIAL STATE or USER STATE)
   * @param propertyValue the value to set it to
   */
  private setObjectProperty(objectId: number, propertyName: string, propertyValue: string | number): void {
    this.visionManager.setObjectProperty(this.id, objectId, propertyName, propertyValue);
  }

  private updateEnvironment(current: Environment): void {
    const previous = this.visionEnvironmentSettings;
    this.updateEnvironmentProperty(EnvironmentProperty.CLOUD_DENSITY, previous, current, e => e.cloudDensityPercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.FOG, previous, current, e => e.fogPercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.HAZE, previous, current, e => e.hazePercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.LIGHTNING, previous, current, e => e.lightningPercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.RAIN, previous, current, e => e.rainPercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.SNOW, previous, current, e => e.snowPercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.SUN_BRIGHTNESS_LEVEL, previous, current, e => e.sunBrightnessPercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.SUN_GLARE, previous, current, e => e.sunGlarePercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.TUNNEL_SMOKE, previous, current, e => e.tunnelSmokePercentage);
    this.updateEnvironmentProperty(EnvironmentProperty.WIND_DIRECTION, previous, current, e => e.windDirectionAngle);
    this.updateEnvironmentProperty(EnvironmentProperty.WIND_STRENGTH, previous, current, e => e.windStrengthKmH);
    this.visionEnvironmentSettings = current;
  }

  private updateEnvironmentProperty(
    property: EnvironmentProperty,
    previousState: Environment,
    currentState: Environment,
    getValue: (e: Environment) => number
  ): void {
    const prev = getValue(previousState);
    const value = getValue(currentState);
    if (prev !== value) {
      this.visionManager.setEnvironmentProperty(this.id, { property, value });
    }
  }

  private updateVisionTrains(usefulTrains: UsefulTrain[], pathFinder: IReachablePathFinder): void {
    const scenarioTrainsStateData: TrainStateData[] = [];
    const scenarioVehiclePosData: Map<number, VehiclePositionData[]> = new Map();

    usefulTrains.forEach(usefulTrain => {
      const vehicles: VehiclePositionData[] = [];

      const consist = this.consists.find(c => c.name === usefulTrain?.description);
      const trainTypeId = consist.id;

      const train: TrainStateData = {
        trainId: usefulTrain.id,
        trainType: trainTypeId,
        isAlive: true,
        isSimulated: usefulTrain.driverType === DriverType.HUMAN,
        segmentId: usefulTrain.rearPosition?.segmentId,
        offset: usefulTrain.rearPosition?.offset,
        fromAlpha: usefulTrain.rearPosition?.fromAlpha
      };

      scenarioTrainsStateData.push(train);

      usefulTrain.vehicles.forEach(v => {
        const orientation = toOrientation(v?.orientation) ?? Orientation.ALPHA_TO_BETA;
        // vehicle tail may not be on the same segment so we need to convert using our pathFinder
        const tailOffset =
          v.position.segmentOrientation !== undefined
            ? v.position.segmentOrientation === Orientation.ALPHA_TO_BETA
              ? v.position.segmentOffset - v.position.length
              : v.position.segmentOffset + v.position.length
            : undefined;
        const so: SegOffsetOriented = { segmentId: v.position.segmentId, offset: tailOffset, orientation };
        const tailSegOffset = pathFinder.scanPath(so).toValidSegOffsetOriented(so);
        const vehicle: VehiclePositionData = {
          trainId: usefulTrain.id,
          vehicleId: v.id,
          // FIXME: set leadOffset at 0 for now
          leadOffset: 0,
          leadAnchor: {
            segmentId: v.position.segmentId,
            offset: v.position.segmentOffset,
            fromAlpha: v.position.segmentOrientation === Orientation.ALPHA_TO_BETA
          },
          trailingAnchor: {
            segmentId: tailSegOffset.segmentId,
            offset: tailSegOffset.offset,
            fromAlpha: tailSegOffset.orientation === Orientation.ALPHA_TO_BETA
          },
          // Below properties at 0 because the preview is static
          positionTimeStamp: 0,
          velocity: 0,
          acceleration: 0,
          velocityTimeStamp: 0
        };
        vehicles.push(vehicle);
      });

      if (vehicles.length) {
        scenarioVehiclePosData.set(usefulTrain.id, vehicles);
      }
    });

    // We now have all of the scenario trains ready to update.
    // Now ensure all trains that have been removed are flagged as "not alive" for the vision.
    this.visionScenarioTrains.forEach(t => {
      const isAlive = scenarioTrainsStateData.findIndex(tsd => tsd.trainId === t.trainId) >= 0;

      if (!isAlive) {
        scenarioTrainsStateData.push({ ...t, isAlive });
      }
    });

    this.updateTrains(scenarioTrainsStateData);
    this.visionScenarioTrains = scenarioTrainsStateData;

    // Update vehicles
    if (scenarioVehiclePosData.keys()) {
      this.updateVehicles(scenarioVehiclePosData);
    }
  }

  private updateTrains(trains: TrainStateData[]): void {
    trains.forEach(t => {
      this.visionManager.setVisionTrains(this.id, t);
    });
  }

  private updateVehicles(vehicles: Map<number, VehiclePositionData[]>): void {
    vehicles.forEach(v => this.visionManager.setVisionVehicles(this.id, v));
  }
}

function toSeconds(date: Date): number {
  if (!date) return null;

  return Math.floor(date.getTime() / 1000);
}
