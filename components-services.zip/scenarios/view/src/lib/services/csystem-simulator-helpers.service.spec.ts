/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { CSystemSimulatorHelpersService } from './csystem-simulator-helpers.service';
import { OksygenSimTrainScenarioViewModule } from '../scenario-view.module';
import { SessionLoggingConfigToken } from '../tokens/session-logging.token';

describe('CSystemSimulatorHelpersService', () => {
  let service: CSystemSimulatorHelpersService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      imports: [OksygenSimTrainScenarioViewModule],
      providers: [
        {
          provide: SessionLoggingConfigToken,
          useValue: {}
        }
      ]
    });

    service = TestBed.inject(CSystemSimulatorHelpersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
