/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Logging, Registry } from '@oksygen-common-libraries/pio';

import { RadioManager } from './radio.manager';

/**
 * Extend this Project side and have it create the extends RadioManager
 * Then provide it in the AppModule for the application, e.g.
 * ```
 * {
 *   provide: RadioService,
 *   useClass: ProjectRadioService
 * }
 * ```
 */
@Injectable()
export class RadioService {
  protected radioDataServiceMap = new Map<number, RadioManager>();

  constructor(protected readonly registry: Registry, protected readonly logger: Logging) {}

  create(systemNumber: number, serverStatus$: Observable<boolean>): RadioManager {
    if (!this.radioDataServiceMap.has(systemNumber)) {
      this.radioDataServiceMap.set(systemNumber, this.createRadioManager(systemNumber, serverStatus$));
    }
    return this.getRadioManager(systemNumber);
  }

  destroy(systemNumber: number): void {
    if (this.radioDataServiceMap.has(systemNumber)) {
      this.radioDataServiceMap.get(systemNumber).destroy();
      this.radioDataServiceMap.delete(systemNumber);
    }
  }

  getRadioManager(systemNumber: number): RadioManager {
    if (this.radioDataServiceMap.has(systemNumber)) {
      return this.radioDataServiceMap.get(systemNumber);
    }
    return null;
  }

  protected createRadioManager(systemNumber: number, serverStatus$: Observable<boolean>): RadioManager {
    return new RadioManager(this.registry, this.logger, systemNumber, serverStatus$);
  }
}
