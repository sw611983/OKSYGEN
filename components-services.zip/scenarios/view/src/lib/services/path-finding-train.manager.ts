/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable, Subscription } from 'rxjs';
import { filter, switchMap } from 'rxjs/operators';

import { filterTruthy, SUPER_WAS_CALLED, SuperCalled, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { Orientation } from '@oksygen-sim-core-libraries/data-types/common';
import { SegmentPosition } from '@oksygen-sim-train-libraries/components-services/common';
import { TrainReachablePathFinder } from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectTypeContainer, ObjectTypeName, ObjManager } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { BaseTrainManager, UsefulTrain } from '@oksygen-sim-train-libraries/components-services/trains';

/**
 * Adds path finding functionality to the train manager.
 */
export abstract class PathFindingTrainManager extends BaseTrainManager {

  /**
   * Updates automatically when {@link subscribeForPathUpdateSignals} is used.
   */
  protected pathFinder: TrainReachablePathFinder;
  protected subscriptions = new Subscription();
  private pathSub: Subscription;

  constructor(
    protected scenario$: Observable<Scenario>,
    protected logger: Logging) {
    super();
  }

  destroy(): SuperCalled {
    this.subscriptions.unsubscribe();
    this.pathSub?.unsubscribe();
    return SUPER_WAS_CALLED;
  }

  /**
   * Subscribes to changes that affect paths.
   * These changes will trigger invocation of the given update function.
   *
   * @param objectManager Manager of points objects.
   * @param points The points object type.
   * @param pathFinder$ Observable path finder, which will populate {@link pathFinder} when updated.
   * @param updatePaths Updates all paths. Would usually call {@link updatePath}.
   */
  protected subscribeForPathUpdateSignals(
    objectManager: ObjManager,
    points: ObjectTypeContainer,
    pathFinder$: Observable<TrainReachablePathFinder>,
    updatePaths: () => void
  ): Subscription {
    return pathFinder$.pipe(
      filterTruthy(),
      switchMap(pathFinder => {
        this.pathFinder = pathFinder;
        updatePaths();

        // FIXME delete this once objectManager supports subscribing to upsert with optional get initial emission
        // this code addresses timing issue where we run updatePath() here before objects are loaded, so path doesn't include points
        objectManager.getObjectContainersOfType$(ObjectTypeName.POINT).pipe(
          filter(objs => Array.isArray(objs) && !!objs.length),
          takeOneTruthy()
        ).subscribe(objs => {
          updatePaths();
        });

        return objectManager.getUpdatedObject$();
      }),
      filterTruthy()
    ).subscribe(objects => {
        // We only care about updates to points
        if (objects?.find(f => f?.objectType?.name === points?.name)) {
          updatePaths();
        }

        // TODO We should probably be checking whether the updated points can affect the path, as demonstrated here.
        // ReachablePath.pathChangePoints is not yet populated we can't do this yet :(
        // if (!!features.find(f => !!currentPath.pathChangePoints.get(f.id))) {
        //   this.updatePath(this.pathTrain);
        // }
    });
  }

  /**
   * Updates the path of the given train.
   * Expects {@link #pathFinder} to have been set before being called.
   * Usually this is automatic when {@link subscribeForPathUpdateSignals} is used with an update function that calls this method.
   */
  protected updatePath(train: UsefulTrain): void {
    let front: SegmentPosition;
    let back: SegmentPosition;

    if (train && train.vehicles.length > 0) {
      const frontPos = train.vehicles[0].position;
      const backPos = train.vehicles[train.vehicles.length - 1].position;
      front = {segmentId: frontPos.segmentId, offset: frontPos.segmentOffset, fromAlpha: frontPos.segmentOrientation === Orientation.ALPHA_TO_BETA};
      back  = {segmentId: backPos .segmentId, offset: backPos .segmentOffset, fromAlpha: backPos .segmentOrientation === Orientation.ALPHA_TO_BETA};
    }

    if (front && back) {
      try {
        // FIXME use the actual train length
        const path = this.pathFinder.scanTrainPath(10000, front, back);
        train.path = path;
      } catch (err) {
        let errorOut = JSON.stringify(err);

        if (err instanceof Error) {
          errorOut = `{
 Name: ${err.name},
 Message: ${err.message},
 Stack: ${err.stack}
}`;
        }

        this.logger.warn(`An error occured calculating the path: ${JSON.stringify(errorOut)}`);
      }
    }
  }
}
