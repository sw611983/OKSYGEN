/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { BehaviorSubject, combineLatest, interval, Observable, of } from 'rxjs';
import { filter, map, startWith, switchMap, takeWhile, tap } from 'rxjs/operators';

import { shareReplayOne } from '@oksygen-common-libraries/common';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import {
  LoadingData,
  OBJECTS as OBJECTS_NAME,
  TRAINS as TRAINS_NAME,
  WORLD as WORLD_NAME
} from '@oksygen-sim-train-libraries/components-services/common';
import { MapType, PLAN_VIEW_NAME } from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectContainer, ObjManager } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { SessionContext } from '../contexts/session-context';
import { SessionRunnerContextPublisher } from '../contexts/session-runner-context.publisher';

/** the modules we show on our loading screen */
export enum SessionModules {
  TRAINS = 1,
  OBJECTS = 2,
  WORLD = 3,
  MAP = 4
}

function blankLoadedModulesFactory(): LoadingData[] {
  return [
    { id: SessionModules.TRAINS, name: TRAINS_NAME, loaded: false, icon: OksygenIcon.TRAIN, obs: new BehaviorSubject<boolean>(false) },
    { id: SessionModules.OBJECTS, name: OBJECTS_NAME, loaded: false, icon: OksygenIcon.OBJECT, obs: new BehaviorSubject<boolean>(false) },
    { id: SessionModules.WORLD, name: WORLD_NAME, loaded: false, icon: OksygenIcon.WORLD, obs: new BehaviorSubject<boolean>(false) }
  ];
}

/**
 * Inject this into your session so you have one per session.
 * Used for to get easy access to whatever your dumb component may need in a session.
 * Currently just used to tell if a session is finished loading and to get the world this session is in.
 */
@Injectable()
export class ActiveSessionService {
  private loadedModulesPerSystem: Map<number, LoadingData[]> = new Map();

  constructor(private contextSupplier: SessionRunnerContextPublisher) {}

  destroy(systemNumber: number): void {
    const loadedModules = this.loadedModulesPerSystem.get(systemNumber);
    loadedModules?.forEach(m => {
      if (m.obs && m.obs instanceof BehaviorSubject) {
        m.obs.complete();
      }
    });
    this.loadedModulesPerSystem.delete(systemNumber);
  }

  feature$(id: number): Observable<ObjectContainer> {
    return this.contextSupplier.currentContext$().pipe(switchMap(m => m.objects.getObject$(id)));
  }

  /**
   * Loads a session's data. Or more specifically, prepares the observable that listens to our data initialising.
   * It does not kick off loading itself - so if you only call this, you'll be loading forever.
   * To load the actual data you need to .subscribe to the returned observable.
   * Can safely be subscribed to multiple times as the data loader is a singleton behind the scenes.
   */
  loadSessionData(systemNumber: number): Observable<boolean> {
    // check if we are changing system, and force a loaded update if we are
    let loadedModules = this.loadedModulesPerSystem.get(systemNumber);
    if (!loadedModules) {
      loadedModules = blankLoadedModulesFactory();
      this.loadedModulesPerSystem.set(systemNumber, loadedModules);
    } else {
      return this.isLoadingComplete(systemNumber);
    }

    // const context$ = this.contextSupplier.currentContext$();
    const context = this.contextSupplier?.createContext(systemNumber);
    const features$ = of(context).pipe(
      filter(m => !!m),
      switchMap(m => m.objects.data()),
      map(objs => Array.isArray(objs) && objs.length > 0)
    );
    const feature$: Observable<boolean> = combineLatest([
      features$
      // this.loadSelectedFeatureImages(context)
    ]).pipe(
      startWith([false, null]),
      map(vals => vals[0])
    );
    const trains$ = of(context).pipe(
      switchMap(m => m.trains.data()),
      map(trains => Array.isArray(trains))
    );
    // FIXME append this map$ observable in the session component when we navigate to the session screen.
    const map$ = of(context).pipe(
      switchMap(pipeContext =>
        combineLatest([of(pipeContext), interval(1000)]).pipe(
          map(([c, i]) => c.map.getMapComponent({ type: MapType.PLAN, name: PLAN_VIEW_NAME }) as any),
          takeWhile(m => !m, true)
          // filter(m => !!m),
        )
      ),
      switchMap(component =>
        component
          ? combineLatest([
              component.mapViewReadySubject as Observable<boolean>,
              interval(1000).pipe(
                map(n => component?.loading === false),
                takeWhile(loaded => !loaded, true)
              )
            ]).pipe(map(([viewReady, idleReady], i) => viewReady && idleReady))
          : of(false)
      )
    );
    const worldData$ = of(context).pipe(
      switchMap(m => m.world.world$),
      map(world => !!world)
    );
    const world$ = combineLatest([worldData$, map$]).pipe(map(([worldReady, mapReady]) => worldReady && mapReady));
    this.setLoadedModuleObservable(systemNumber, SessionModules.TRAINS, trains$.pipe(startWith(false)));
    this.setLoadedModuleObservable(systemNumber, SessionModules.OBJECTS, feature$.pipe(startWith(false)));
    this.setLoadedModuleObservable(systemNumber, SessionModules.WORLD, world$.pipe(startWith(false)));
    return this.isLoadingComplete(systemNumber);
  }

  isLoadingComplete(systemNumber: number): Observable<boolean> {
    const loadedModules = this.loadedModulesPerSystem.get(systemNumber);
    return combineLatest(loadedModules.map(mod => mod.obs)).pipe(
      tap(vals => {
        vals.forEach((val, i) => {
          loadedModules[i].loaded = val;
        });
      }),
      map(vals => vals.reduce((prev, val) => val && prev)),
      shareReplayOne()
    );
  }

  /**
   * Get the modules that'll be loaded as part of the session.
   * This will not start loading them - you need to call ```loadSessionData()``` for that.
   */
  getSessionLoadingModules(systemNumber: number): LoadingData[] {
    return this.loadedModulesPerSystem.get(systemNumber);
  }

  private setLoadedModuleObservable(systemNumber: number, id: SessionModules, obs: Observable<boolean>): void {
    const sessionModule = this.loadedModulesPerSystem.get(systemNumber).find(mod => mod.id === id);
    if (sessionModule) {
      if ((sessionModule.obs as BehaviorSubject<boolean>).complete) {
        (sessionModule.obs as BehaviorSubject<boolean>).complete();
      }
      sessionModule.obs = obs;
    }
  }

  // not used currently - we don't want to force the user to wait for images to load before they can access the session.
  // FIXME contains a memory leak
  private loadSelectedFeatureImages(context: SessionContext): Observable<boolean> {
    return new Observable<boolean>(obs => {
      const fcSub = of(context)
        .pipe(switchMap(m => m.objects.data()))
        .subscribe(features => {
          const images = ObjManager.getSelectedFeatureImages(features);
          const imgSub = ObjManager.initFeatureImages(images).subscribe(result => {
            obs.next(true);
            obs.complete();
            fcSub?.unsubscribe();
            imgSub?.unsubscribe();
          });
        });
    });
  }
}
