/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { cloneDeep, isEqual } from 'lodash';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { distinctUntilChanged, filter, map, tap } from 'rxjs/operators';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ObjectData, ObjectModification } from '@oksygen-sim-core-libraries/data-types/objects';
import { UpdatedInserted } from '@oksygen-sim-train-libraries/components-services/common';
import {
  INITIAL_STATE,
  ObjectContainer,
  ObjectTypeContainer,
  ObjManager,
  SimObject
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { NetworkDefinitionManager, WorldManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { BasexObjectTransformer } from './transformers/basex-object.transformer';

// FIXME this is copied verbatim from ObjectBasexManager
// that file however cannot live here because it depends on ScenarioEditor only code.

/**
 * This works like a readonly version of ObjectBasexManager.
 */
export class ObjectSessionSetupManager extends ObjManager {
  transformer: BasexObjectTransformer;
  subscription = new Subscription();
  private scenario: Scenario;

  constructor(
    registry: Registry,
    private logger: Logging,
    objectTypes$: Observable<ObjectTypeContainer[]>,
    private scenario$: Observable<Scenario>,
    private worldManager: WorldManager
  ) {
    super(objectTypes$);
    this.transformer = new BasexObjectTransformer(this.logger);

    const transformedWorldObjects$ = combineLatest([this.worldManager.world$, this.objectTypes$]).pipe(
      filter(([w, ot]) => !!w && !!ot?.length),
      map(([world, objectType]) => {
        const objects: ObjectContainer[] = [];
        world.objects.forEach(o => {
          const object = this.transform(o, objectType);
          if (object) {
            objects.push(object);
          }
        });
        return objects;
      }),
      tap(objects => {
        // TODO: May need to add this to the transformedWorldObjects processing below, once we can add composite objects
        objects.forEach(object => this.assignObjectChildren(object, objects));
      })
    );
    const scenarioUpdates$ = this.scenario$.pipe(distinctUntilChanged(this.scenarioObjectsUnchanged));
    this.subscription.add(
      combineLatest([transformedWorldObjects$, this.worldManager.netDef$, scenarioUpdates$, this.objectTypes$])
        .pipe(filter(([wo, n, s, ft]) => !!wo && !!n && !!s && !!ft))
        .subscribe(([wo, netDef, s, objectTypes]) => {
          this.scenario = s;
          const worldObjectsMap = new Map(wo.map(obj => [obj.name, obj]));
          const existingObjectsMap = new Map((this.objectSubject?.getValue() || []).map(obj => [obj.id, obj]));
          const insertedObjects: ObjectContainer[] = [];

          // these are track objects, which includes points, so should be in objectUpdated
          // so that the path can be re-calculated if required
          s.world?.objectModification?.forEach(mod => {
            const obj = worldObjectsMap.get(mod.name);
            if (obj) {
              this.applyScenarioModifications(obj, mod);
            }
          });

          // these are new objects, so should be in objectInserted
          insertedObjects.push(
            ...s.world.object.map(o => {
              const liveObject = this.copyUsingCommonInstances(o, objectTypes);
              this.updateMissingLLWithGeometry(liveObject, netDef);
              this.setState(liveObject);
              this.loadIcons(liveObject);
              return liveObject;
            })
          );
          // append the children now that each object exists
          insertedObjects.forEach(obj => {
            this.assignObjectChildren(obj, insertedObjects);
          });

          const allObjects = [...worldObjectsMap.values(), ...insertedObjects];
          const upserted: UpdatedInserted<ObjectContainer> = {
            // FIXME Account for update/removed objects
            updated: allObjects,
            inserted: allObjects.filter(obj => !existingObjectsMap?.get(obj.id))
          };

          this.objectSubject.next(allObjects);
          this.objectUpdated.next(upserted.updated);
          this.objectInserted.next(upserted.inserted);
          // this.objectInserted.next(insertedObjects);
        })
    );
  }

  /**
   * Creates a copy of the given object, using the common instances of object types.
   * We do this for scenario objects which have been mangled as part of going through the store.
   * Should not be necessary once INTOSC-8421 is resolved.
   *
   * @param o The object to copy.
   * @param objectTypes The common object type instances.
   */
  private copyUsingCommonInstances(o: ObjectContainer | SimObject, objectTypes: ObjectTypeContainer[]): ObjectContainer {
    const objectType = objectTypes.find(t => t.name === o.objectType.name);
    const states = objectType.states;
    const selectedState = states.get(o.selectedState?.id);

    return {
      ...cloneDeep(o),
      objectType,
      states,
      selectedState,
      selectedIcon: selectedState?.icons,
      children: (o as any as ObjectContainer).children?.map(c => this.copyUsingCommonInstances(c, objectTypes))
    };
  }

  /**
   * Ensures that the Object has its lngLat set if it has the appropriate geometry info.
   */
  private updateMissingLLWithGeometry(object: ObjectContainer, netDef: NetworkDefinitionManager): ObjectContainer {
    if (object.location && !object.location.lnglat && object.location.geometry.x != null && object.location.geometry.y != null) {
      const ll = netDef.xyTolngLatIndividual(object.location.geometry.x, object.location.geometry.y);
      // Note that objects' contents may be frozen.
      object.location = {
        ...object.location,
        lnglat: [ll.longitude, ll.latitude]
      };
      object?.children?.forEach(child => {
        if (!child.location) {
          child.location = {
            lnglat: [ll.longitude, ll.latitude],
            geometry: object.location.geometry
          };
        }
        if (!child.location.lnglat) {
          child.location.lnglat = [ll.longitude, ll.latitude];
        }
        if (!child.location.geometry) {
          child.location.geometry = object.location.geometry;
        }
      });
    }

    return object;
  }

  /**
   * Ensures that the Object has its selectedState and selectedIcon set if it has the appropriate property set.
   */
  private setState(object: ObjectContainer): ObjectContainer {
    if (!object.selectedState) {
      const state = object.properties[INITIAL_STATE];

      if (state) {
        object.selectedState = Array.from(object.objectType.states).find(([id, s]) => s.name === state)[1];
        object.selectedIcon = object.selectedState?.icons;
      }
    }

    return object;
  }

  /**
   * Loads small icons for the initial state.
   * This ensures that icons can be drawn on the map if the Object has its selectedState or selectedIcon set.
   */
  private loadIcons(object: ObjectContainer): ObjectContainer {
    const icon = object.selectedIcon ?? object.selectedState?.icons;
    // This triggers a call to ImageService.addGlobalImage, which in turns notifies the map of the icon.
    icon?.small.asBlob();

    return object;
  }

  override destroy(): void {
    this.subscription?.unsubscribe();
    super.destroy();
  }

  private transform(data: ObjectData, objectTypes?: ObjectTypeContainer[]): ObjectContainer {
    const types = objectTypes ? objectTypes : this.obsToVal(this.objectTypes$);
    if (!data || !types) {
      return null;
    }
    const object = this.transformer.transformObjectDataToObjectContainer(data, types, this.scenario);
    return object;
  }

  // This is done in a similar fashion as it is done for objects coming from comms
  private assignObjectChildren(object: ObjectContainer, objects: ObjectContainer[]): void {
    if (!object?.objectType?.children || object.objectType.children.length === 0) {
      return;
    }

    if (!object.children) {
      object.children = [];
    }

    for (const typeChild of object?.objectType?.children ?? []) {
      const childId = object.properties[typeChild.name];

      if (childId) {
        const childFeature = objects.find(cf => cf.id === childId);

        if (childFeature) {
          const existingChild = object.children.find(c => c.id === childFeature.id);
          childFeature.parentId = object.id;
          childFeature.promotedChild = typeChild.promoted;
          if (!existingChild) {
            object.children.push(childFeature);
          } else {
            existingChild.parentId = object.id;
            existingChild.promotedChild = typeChild.promoted;
          }
        }
      }
    }
  }

  /**
   * Synchonously returns the current value of an observable (if it is set). Undefined otherwise.
   *
   * @param obs the observable
   */
  obsToVal(obs: Observable<any>): any {
    let val;
    const sub = obs.subscribe(v => {
      val = v;
    });
    sub.unsubscribe();
    return val;
  }

  updateObjectAuto(id: string | number, isAuto: boolean): void {
    throw new Error('Method not implemented.');
  }

  override updateObjectDisplayOverrideState(id: number | string, isOverriden: boolean, state: string|number): void {
    throw new Error('Method not implemented.');
  }

  updateObjectContainerState(id: string | number, state: string | number): void {
    // do nothing - can't change objects from here
  }

  updateObjectContainerProperty(id: number|string, propertyKey: string, propertyValue: string|number): void {
    // do nothing - can't change objects from here
  }

  private applyScenarioModifications(obj: ObjectContainer, mod: ObjectModification): void {
    obj.properties = { ...obj.properties, ...mod.properties };
    // FIXME probably a better way of doing this - copy pasted from transform
    const selectedState = this.transformer.getInitialState(obj, obj.objectType, this.scenario);
    obj.selectedState = selectedState;
    obj.selectedIcon = selectedState?.icons;
    obj.stateAutomated = this.transformer.isAutomated(obj, obj.objectType);
    obj.stateVirtual = this.transformer.isVirtual(obj, obj.objectType);
    obj.displayState = this.transformer.getDisplayState(obj, obj.objectType, this.scenario);
  }

  private scenarioObjectsUnchanged(oldS: Scenario, newS: Scenario): boolean {
    const scenarioObjectsEqual = isEqual(oldS?.world, newS?.world);
    return scenarioObjectsEqual;
  }
}
