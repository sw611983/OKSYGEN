/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RawFeature } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { merge } from 'lodash';


/**
 * Responsible for processing incoming object updates and consolidating them
 * while a session is inactive.
 */
export class ObjectCommsQueue {

  private pendingFeatureUpdates = new Map<number, RawFeature>();

  processMessage(message: RawFeature[]): void {
    message?.forEach(obj => {
      const existingUpdate = this.pendingFeatureUpdates.get(obj.id);
      if (existingUpdate) {
        merge(existingUpdate, obj); // this may not handle updates to trackAssociations cleanly.
      } else {
        this.pendingFeatureUpdates.set(obj.id, obj);
      }
    });
  }

  getPendingUpdates(clear = false): RawFeature[] {
    const updates = Array.from(this.pendingFeatureUpdates.values());
    if (clear) {
      this.pendingFeatureUpdates.clear();
    }
    return updates;
  }

  clear(): void {
    this.pendingFeatureUpdates.clear();
  }
}
