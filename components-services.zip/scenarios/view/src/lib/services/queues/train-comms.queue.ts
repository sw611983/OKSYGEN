/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { VehicleTrackPosition } from '@oksygen-sim-train-libraries/components-services/trains';

/**
 * Responsible for processing incoming train (vehicle) position updates and consolidating them
 * while a session is inactive.
 */
export class TrainCommsQueue {

  private pendingVehicleUpdates = new Map<number, VehicleTrackPosition>();

  processMessage(message: VehicleTrackPosition[]): void {
    message?.forEach(v => this.pendingVehicleUpdates.set(v.id, v));
  }

  getPendingUpdates(): VehicleTrackPosition[] {
    const updates = Array.from(this.pendingVehicleUpdates.values());
    return updates;
  }

  clear(): void {
    this.pendingVehicleUpdates.clear();
  }
}
