/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { EnvironmentManager } from './environment.manager';
import { SystemStoreState } from '../store/system/system.state';
import { Observable } from 'rxjs';

@Injectable()
export class EnvironmentService {
  protected environmentDataServiceMap = new Map<number, EnvironmentManager>();

  constructor(private registry: Registry, private logger: Logging, private store: Store<SystemStoreState>) {}

  create(systemNumber: number, serverStatus$: Observable<boolean>): EnvironmentManager {
    if (!this.environmentDataServiceMap.has(systemNumber)) {
      this.environmentDataServiceMap.set(systemNumber, new EnvironmentManager(this.registry, this.logger, this.store, systemNumber, serverStatus$));
    }
    return this.getEnvironmentManager(systemNumber);
  }

  destroy(systemNumber: number): void {
    if (this.environmentDataServiceMap.has(systemNumber)) {
      this.environmentDataServiceMap.get(systemNumber).destroy();

      this.environmentDataServiceMap.delete(systemNumber);
    }
  }

  getEnvironmentManager(systemNumber: number): EnvironmentManager {
    if (this.environmentDataServiceMap.has(systemNumber)) {
      return this.environmentDataServiceMap.get(systemNumber);
    }

    return null;
  }
}
