/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { EnvironmentMessageIds, SocketMessage } from '@oksygen-sim-core-libraries/components-services/data-services';
import { Environment, EnvironmentDataService } from '@oksygen-sim-train-libraries/components-services/world-environment';
import { SystemStoreState } from '../store/system/system.state';
import { environmentDataActions } from '../store/environment/environment.actions';

export class EnvironmentManager {
  private environmentDataService: EnvironmentDataService;

  private environmentSubscription: Subscription;

  constructor(registry: Registry, logger: Logging, private store: Store<SystemStoreState>, private systemNumber: number, serverStatus$: Observable<boolean>) {
    this.environmentDataService = new EnvironmentDataService(registry, logger, this.systemNumber, serverStatus$);

    this.environmentSubscription = this.environmentDataService.environmentMessages$().subscribe(message => this.onMessage(message));
  }

  destroy(): void {
    this.environmentSubscription.unsubscribe();
    this.environmentDataService.destroy();
  }

  private onMessage(message: SocketMessage<EnvironmentMessageIds, Environment>): void {
    if (message?.messageId === EnvironmentMessageIds.SERVER_ENVIRONMENT_UPDATE) {
      this.store.dispatch(environmentDataActions.updateEnvironmentStore({ systemNumber: this.systemNumber, environment: message.message }));
    }
  }

  public async updateEnvironment(env: Environment): Promise<void> {
    const message: SocketMessage<EnvironmentMessageIds, Environment> = {
      messageId: EnvironmentMessageIds.CLIENT_ENVIRONMENT_PATCH,
      message: env
    };

    this.environmentDataService.sendMessage(message);
  }
}
