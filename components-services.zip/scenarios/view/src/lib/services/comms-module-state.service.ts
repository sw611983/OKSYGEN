/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Store } from '@ngrx/store';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

import { computeIfAbsent, shareReplayOne, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ErrorService, Severity } from '@oksygen-sim-core-libraries/components-services/common';
import {
  CommsStateResponse,
  CommsStateService,
  ModuleState,
  ScenarioMessageId,
  SessionMessageId,
  SessionStatusMessageId,
  State,
  StateMessageId,
  SystemState,
  SystemStateList
} from '@oksygen-sim-core-libraries/components-services/data-services';

import { sessionActions } from '../store/session/session.actions';
import { SystemStoreData } from '../store/system/system.state';

/**
 * Supplies Comms Module State information for UIs to display.
 * This is intended to be a stopgap until a full simulator health subsystem has been developed.
 * This should be constructed before CommsStateService is connected to the backend.
 */
@Injectable()
export class CommsModuleStateService {
  /**
   * Holds module information and state.
   * The first key is system number.
   * The second key is module name. We do not key on ID, because if a module is restarted it is assigned a new ID.
   */
  private moduleStates = new Map<number, Map<string, ModuleState>>();

  /**
   * Modules Names keyed on ID.
   * For figuring out where nameless updates should be applied.
   * Note that the name stored here will be the ID when we get updates to modules before we've been told their names.
   */
  private moduleNames = new Map<string, string>();

  nextModuleId = 0;

  private dataUpdated = new BehaviorSubject<number>(0);
  private subscription = new Subscription();
  private systemStateList$: BehaviorSubject<SystemStateList>;

  constructor(
    private logging: Logging,
    private registry: Registry,
    private commsStateService: CommsStateService,
    private errorService: ErrorService,
    private systemStore: Store<SystemStoreData>) {


  }

  start(): void {
    this.systemStateList$ = new BehaviorSubject<SystemStateList>(null);
    this.commsStateService.initialiseCommsStatusConnection(this.registry.getString(['systemModuleStatus', 'url']));
    this.subscription = this.commsStateService.responses.subscribe(response => this.handleCommsStateResponse(response));
  }

  stop(): void {
    this.subscription.unsubscribe();
    this.commsStateService.closeCommsStatusConnection();
    this.systemStateList$.complete();
    this.systemStateList$ = null;
  }

  private handleCommsStateResponse(response: CommsStateResponse): void {
    switch (response.messageId) {
      case StateMessageId.SYSTEM_STATE_LIST:
        this.onSystemStateListUpdate(response.message as SystemStateList);
        break;
      case ScenarioMessageId.SCENARIO_DEFINITION:
      case StateMessageId.SYSTEM_STATUS:
      case SessionMessageId.SESSION_DEFINITION:
      case SessionStatusMessageId.SESSION_STATUS:
      case SessionStatusMessageId.SESSION_PREVENT_PLAY:
        // Not interested in these updates.
        break;
      default:
        this.logging.warn(`[CommsModuleStateService:: unknown data: ${JSON.stringify(response)}`);
        break;
    }
  }

  public requestModuleStates(systemNumber: number): void {
    this.commsStateService.requestSystemState(systemNumber);
  }

  // It would probably be better practice to provide an observable and so forth,
  // but given this is a stopgap it's probably not worth the extra work.
  public getModuleStates(systemId: number): Map<string, ModuleState> {
    return computeIfAbsent(this.moduleStates, systemId, k => new Map());
  }

  public dataUpdated$(): Observable<number> {
    return this.dataUpdated.asObservable().pipe(shareReplayOne());
  }

  private onSystemStateListUpdate(stateList: SystemStateList): void {
    this.systemStateList$.next(stateList);
    stateList.systemStates.forEach(this.onSystemStateUpdate, this);
  }

  private onSystemStateUpdate(systemState: SystemState): void {
    this.systemStore.dispatch(
      sessionActions.sessionState({
        systemNumber: systemState.id,
        sessionMessage: systemState
      })
    );
    const moduleMap = this.getModuleStates(systemState.id);
    moduleMap.clear();
    systemState?.moduleStates?.forEach(moduleState => {
      this.onModuleUpdate(systemState.id, moduleState);
    }, this);
    this.dataUpdated.next(systemState.id);
  }

  private onModuleUpdate(systemId: number, state: ModuleState): void {
    const moduleMap = this.getModuleStates(systemId);

    // Handle cases where we are told the name, where we have seen the name before or where we get updates to modules whose names we don't yet know.
    let key = state.name ?? this.moduleNames.get(state.id);
    let idUsed = false;

    if (!key) {
      key = state.id;
      idUsed = true;
    }

    let module = moduleMap.get(key);

    if (module) {
      // Known module, so update its state.
      // Note that we don't remove dropped modules.
      // Much like the Hotel California, they can check out any time they like but they can never leave...

      // Note that we will get notified of a dropped module even if it has been restarted,
      // because the newly started instance has a different ID.
      // Here we prevent a dropped module from overwriting a live one
      let doUpdate = true;

      if (state.state === State.DROPPED) {
        doUpdate = module.id === state.id;
      }

      if (doUpdate) {
        module.id = state.id;

        // Note that these properties are not sent unless they are changed,
        // so we can't blindly overwrite them.
        module.health = state.health ?? module.health;
        module.state  = state.state  ?? module.state;
        // Handling name changes is a special case related to handling updates to modules whose names we haven't been told yet.
        module.name   = state.name   ?? module.name;

        if (state.name) {
          this.moduleNames.set(state.id, state.name);
        }
      }
    } else {
      // Newly detected module
      module = {
        system: systemId,
        id: state.id,
        // Depending on the order of updates we may not get a name
        name: state.name ?? state.id,
        state: state.state,
        health: state.health
      };

      this.moduleNames.set(state.id, module.name);
    }

    if (state.state === State.UNKNOWN) {
      this.onModuleDropped(systemId, state);
    }
    if (!idUsed) {
      // Clean up any id-based references to this module.
      moduleMap.delete(state.id);
    }

    moduleMap.set(key, module);
  }

  private onModuleDropped(systemId: number, state: ModuleState): void {
    const errorId = `${systemId}_${state.name}`; // can't use state id because only the name is guaranteed
    let e = this.errorService.getError(errorId);
    if (!e) {
      e = {
        id: errorId,
        severity: Severity.WARNING,
        type: 'Module Dropped',
        asString: (): string => t(`System ${systemId} module ${state.name} has dropped.`)
      };
      this.errorService.addError(e);
      this.commsStateService.responses.pipe(
        filter(response => response.messageId === StateMessageId.SYSTEM_STATE_LIST),
        filter(response => {
          const stateList = response.message as SystemStateList;
          const responseState = stateList?.systemStates?.find(s => s.id === systemId);
          const moduleState = responseState?.moduleStates?.find(ms => ms.name === state.name);
          return moduleState?.state !== state.state;
        }),
        takeOneTruthy()
      ).subscribe(() => this.errorService.deleteError(errorId));
    }
  }

  public systemStateListUpdates$(): Observable<SystemStateList> {
    return this.systemStateList$.asObservable().pipe(shareReplayOne());
  }
}
