/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, Injectable, OnDestroy, Optional, SkipSelf } from '@angular/core';
import { isNil } from 'lodash';
import moment from 'moment';
import { BehaviorSubject, Observable, ReplaySubject, Subscription } from 'rxjs';

import { ElectronService } from '@oksygen-common-libraries/common/electron';
import { LoggingDatePipe, Registry } from '@oksygen-common-libraries/pio';
import { PioLoggingElectronConfig } from '@oksygen-common-libraries/pio/logging/electron';
import { SessionLoggingConfigToken } from '../tokens/session-logging.token';

export enum SessionLogEvents {
  GENERATE_SESSION_LOG = 'generate_session_log',
  PRESSED_START_SESSION = 'pressed_start_session',
  SESSION_ID_GENERATED = 'session_id_generated',
  SESSION_TAB_LOADED = 'session_tab_loaded',
  PLAY_BUTTON_ENABLED = 'play_button_enabled',
  MAP_LOADED = 'map_loaded',
  PLAY_BUTTON_PRESSED = 'play_button_pressed'
}

interface LoggingData {
  message: string;
  additional: any[];
}

interface SessionLoggingData {
  date: string;
  sessions: SessionLogs[];
}

interface RecordedEvent {
  event_name: SessionLogEvents;
  time_stamp: string;
}

interface SessionLogs {
  simulator_name?: string;
  session_launched_order?: number;
  launch_date_time?: string;
  scenario_name?: string;
  scenario_world?: string;
  session_id?: number;
  train?: string;
  delay_tab_header_available_second?: string;
  delay_play_button_available_second?: string;
  delay_map_completely_loaded_second?: string;
  delay_play_button_pressed_second?: string;
  recorded_events?: RecordedEvent[];
}

const DEFAULT_LOG_FILENAME = 'electronApp.log';

@Injectable()
export class SessionLogging implements OnDestroy {
  private loadedSubject = new BehaviorSubject<boolean>(false);

  private registrySubscription: Subscription;

  private loggingSubject = new ReplaySubject<LoggingData>(50);
  private loggingSubjectSubscription: Subscription;

  private filename = DEFAULT_LOG_FILENAME;
  private loggingDirectory: string;

  private sessionLoggingData: SessionLoggingData;
  lastLogMessage = '';
  lastLogTime = 0;
  debounceTime = 1000;

  constructor(
    @Optional() @SkipSelf() parentModule: SessionLogging,
    @Inject(SessionLoggingConfigToken) private readonly config: PioLoggingElectronConfig,
    private readonly electronService: ElectronService,
    private registry: Registry,
    loggingDatePipe: LoggingDatePipe
  ) {
    if (parentModule) {
      throw new Error('SessionLogging is already loaded. Import it in the AppModule only');
    }

    if (electronService.isElectron) {
      this.electronService.getAppPath().subscribe(appPath => this.processConfiguration(appPath));
    }
  }

  public ngOnDestroy(): void {
    this.loggingSubjectSubscription?.unsubscribe();
    this.loggingSubject.complete();
  }
  public loaded(): Observable<boolean> {
    return this.loadedSubject.asObservable();
  }

  public log(message: string, ...additional: any[]): void {
    this.loggingSubject.next({ message, additional });
  }

  private processConfiguration(appPath: string): void {
    this.registrySubscription = this.registry?.loaded().subscribe((ready: any) => {
      if (ready) {
        let loggingConfig: PioLoggingElectronConfig | undefined;

        try {
          loggingConfig = this.registry.getObject<PioLoggingElectronConfig>('logging.config', undefined);
        } catch (e) {
          if (!Object.getOwnPropertyNames(e).includes('message') || !(e.message as string).startsWith('Property not found')) {
            console.log('Error caught trying to get registry entry', e);
          }
        }

        const baseDirectory = !isNil(loggingConfig) && !isNil(loggingConfig.baseDirectory) ? loggingConfig.baseDirectory : appPath;
        const directory = !isNil(loggingConfig) && !isNil(loggingConfig.directory) ? loggingConfig.directory : this.config.directory;
        this.filename = this.getFormattedLogFilename();
        this.loggingDirectory = this.electronService.path.join(baseDirectory, directory);
        this.registrySubscription?.unsubscribe();
        this.initialiseLogging();
      }
    });
  }

  private initialiseLogging(): void {
    console.log('Session logging to: ' + this.electronService.path.join(this.loggingDirectory, this.filename));
    this.electronService.ipcRenderer.invoke('setAppLogsPath', this.loggingDirectory);
    this.loggingSubjectSubscription = this.loggingSubject.subscribe(data => this.doLogging(data));
    this.loadedSubject.next(true);
  }

  private doLogging(data: LoggingData): void {
    const filePath = this.electronService.path.join(this.loggingDirectory, this.filename);
    if (this.electronService.fs.existsSync(filePath)) {
      try {
        this.sessionLoggingData = JSON.parse(this.electronService.fs.readFileSync(filePath, 'utf-8'));
      } catch (error) {
        console.error('Error reading file:', error);
      }
    }

    switch (data.message) {
      case SessionLogEvents.GENERATE_SESSION_LOG:
        this.sessionLoggingData = { date: this.formatDateTime(), sessions: [] };
        this.logSessionData();
        break;
      case SessionLogEvents.SESSION_ID_GENERATED:
        if (data.additional.length > 0) {
          const sessionData = data.additional[0];
          const sessionLogs = this.sessionLoggingData.sessions.find(
            s =>
              s.session_id === undefined &&
              s.simulator_name === sessionData?.simulatorName &&
              s.scenario_name === sessionData?.scenarioName &&
              s.scenario_world === sessionData?.scenarioWorld &&
              s.train === sessionData?.train
          );
          if (sessionLogs) {
            sessionLogs.session_id = sessionData.sessionId;
            sessionLogs.recorded_events.push({ event_name: SessionLogEvents.SESSION_ID_GENERATED, time_stamp: this.formatDateTime() });
            this.logSessionData();
          }
        }
        break;
      case SessionLogEvents.PRESSED_START_SESSION:
        if (data.additional.length > 0) {
          const sessionData = data.additional[0];
          const sessionLogs: SessionLogs = {};
          const recorded_events: RecordedEvent[] = [];

          sessionLogs.simulator_name = sessionData.simulatorName;
          sessionLogs.scenario_name = sessionData.scenarioName;
          sessionLogs.scenario_world = sessionData.scenarioWorld;
          sessionLogs.train = sessionData.train;
          sessionLogs.launch_date_time = this.formatDateTime();
          sessionLogs.session_id = sessionData.sessionId;
          sessionLogs.session_launched_order = this.sessionLoggingData.sessions.length + 1;
          recorded_events.push({ event_name: SessionLogEvents.PRESSED_START_SESSION, time_stamp: this.formatDateTime() });
          sessionLogs.recorded_events = [...recorded_events];
          this.sessionLoggingData.sessions.push(sessionLogs);
          this.logSessionData();
        }
        break;
      case SessionLogEvents.SESSION_TAB_LOADED:
        if (data.additional.length > 0) {
          const sessionLogs = this.sessionLoggingData.sessions.find(s => s?.session_id === data.additional[0]?.sessionId);
          if (sessionLogs) {
            const recorded_events: RecordedEvent[] = sessionLogs?.recorded_events ?? [];
            if (!recorded_events.some(e => e.event_name === SessionLogEvents.SESSION_TAB_LOADED)) {
              sessionLogs.delay_tab_header_available_second = this.getDelay(sessionLogs.launch_date_time, this.formatDateTime());
              recorded_events.push({
                event_name: SessionLogEvents.SESSION_TAB_LOADED,
                time_stamp: this.formatDateTime()
              });
            }
            sessionLogs.recorded_events = [...recorded_events];
            this.logSessionData();
          }
        }
        break;
      case SessionLogEvents.PLAY_BUTTON_PRESSED:
        if (data.additional.length > 0) {
          const sessionLogs = this.sessionLoggingData.sessions.find(s => s?.session_id === data.additional[0]?.sessionId);
          if (sessionLogs) {
            const recorded_events: RecordedEvent[] = sessionLogs?.recorded_events ?? [];
            if (!recorded_events.some(e => e.event_name === SessionLogEvents.PLAY_BUTTON_PRESSED)) {
              sessionLogs.delay_play_button_pressed_second = this.getDelay(sessionLogs.launch_date_time, this.formatDateTime());
              recorded_events.push({
                event_name: SessionLogEvents.PLAY_BUTTON_PRESSED,
                time_stamp: this.formatDateTime()
              });
            }
            sessionLogs.recorded_events = [...recorded_events];
            this.logSessionData();
          }
        }
        break;
      case SessionLogEvents.MAP_LOADED:
        if (data.additional.length > 0) {
          const sessionLogs = this.sessionLoggingData.sessions.find(s => s?.session_id === data.additional[0]?.sessionId);
          if (sessionLogs) {
            const recorded_events: RecordedEvent[] = sessionLogs?.recorded_events ?? [];
           if (!recorded_events.some(e => e.event_name === SessionLogEvents.MAP_LOADED)) {
            sessionLogs.delay_map_completely_loaded_second = this.getDelay(sessionLogs.launch_date_time, this.formatDateTime());
            recorded_events.push({
              event_name: SessionLogEvents.MAP_LOADED,
              time_stamp: this.formatDateTime()
            });
          }
            sessionLogs.recorded_events = [...recorded_events];
            this.logSessionData();
          }
        }
        break;
      case SessionLogEvents.PLAY_BUTTON_ENABLED:
        if (data.additional.length > 0) {
          const sessionLogs = this.sessionLoggingData.sessions.find(s => s?.session_id === data.additional[0]?.sessionId);
          if (sessionLogs) {
            const recorded_events: RecordedEvent[] = sessionLogs?.recorded_events ?? [];
            if (!recorded_events.some(e => e.event_name === SessionLogEvents.PLAY_BUTTON_ENABLED)) {
              sessionLogs.delay_play_button_available_second = this.getDelay(sessionLogs.launch_date_time, this.formatDateTime());
              recorded_events.push({
                event_name: SessionLogEvents.PLAY_BUTTON_ENABLED,
                time_stamp: this.formatDateTime()
              });
            }
            sessionLogs.recorded_events = [...recorded_events];
            this.logSessionData();
          }
        }
        break;
      default:
        break;
    }
  }

  private getDelay(start: string, end: string): string {
    const diff = moment.duration(moment(end).diff(moment(start)));
    return `${String(Math.floor(diff.asHours())).padStart(2, '0')}:${String(diff.minutes()).padStart(2, '0')}:${String(diff.seconds()).padStart(2, '0')}`;
  }

  private logSessionData(): void {
    this.electronService.fs.writeFileSync(
      this.electronService.path.join(this.loggingDirectory, this.filename),
      JSON.stringify(this.sessionLoggingData, null, 2)
    );
  }

  private formatDateTime(date = new Date()): string {
    return moment(date).format('YYYY-MM-DD HH:mm:ss');
  }

  private getFormattedLogFilename(): string {
    const now = new Date();

    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');

    return `session_log_${day}_${month}_${year}_${hours}_${minutes}.json`;
  }
}
