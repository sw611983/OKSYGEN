/// @copyright © 2025 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';
import { SessionLogging } from './session-logging';
import { SessionLoggingConfigToken } from '../tokens/session-logging.token';

describe('SessionLogging', () => {
  let service: SessionLogging;

  beforeEach(() => {
    configureSimTrainTestingModule({
      providers: [
        SessionLogging,
        {
          provide: SessionLoggingConfigToken,
          useValue: {}
        }
      ]
    });
    service = TestBed.inject(SessionLogging);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
