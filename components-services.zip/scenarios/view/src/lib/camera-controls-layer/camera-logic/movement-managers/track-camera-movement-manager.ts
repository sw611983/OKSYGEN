/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import Point from '@mapbox/point-geometry';
import { LngLat, Map } from 'maplibre-gl';

import { SegOffset } from '@oksygen-sim-core-libraries/data-types/common';

import { TrackCameraControlComponent } from '../../camera-controls/track-camera-control/track-camera-control.component';
import { PreciseCoordConverter, RAD_TO_DEG_FACTOR } from '../../models/camera-controls-layer.model';
import { UserCameraMovementManager } from './user-camera-movement-manager';

export class TrackCameraMovementManager extends UserCameraMovementManager {
  private dragBoundsSegments: number[] = [];

  private cameraComponent: TrackCameraControlComponent;
  private cameraAngleInDegreesFromEast = 0;
  private segOffset: SegOffset = { segmentId: null, offset: null };
  private fromAlpha = true;

  constructor(layer: HTMLElement, camera: { element: HTMLElement; component: TrackCameraControlComponent }) {
    super(layer, camera);
    this.cameraComponent = camera.component;

    const sub = this.cameraComponent.flipped$.subscribe((flipped: boolean) => {
      this.fromAlpha = !flipped;
      this.sendCameraPosition();
    });
    this.listeners.add(sub);
  }

  private rotateListener = (): void => {
    this.cameraComponent.angleInDegrees$.next(this.cameraAngleInDegreesFromEast - this.map.getBearing());
  };

  override setMap(map: Map): void {
    super.setMap(map);
    this.dragBoundsSegments = this.getMapBounds();
    this.coordConverter = new PreciseCoordConverter(map);
  }

  protected override addMapListeners(map: Map): void {
    super.addMapListeners(map);

    map.on('rotate', this.rotateListener);
  }

  protected override removeMapListeners(map: Map): void {
    super.removeMapListeners(map);
    if (map) {
      map.off('rotate', this.rotateListener);
    }
  }

  protected override onMouseDown(mousePos: Point): void {
    const bounds = this.map.getBounds();
    this.dragBoundsSegments = this.networkDefinitionManager.segmentsInBoundingBox({
      minX: bounds.getWest(),
      maxX: bounds.getEast(),
      minY: bounds.getSouth(),
      maxY: bounds.getNorth()
    });
    super.onMouseDown(mousePos);
  }

  postTreatCameraLngLat(lngLat: LngLat): void {
    // 1 - Position
    this.segOffset = this.networkDefinitionManager.lngLatToSegmentOffset([lngLat.lng, lngLat.lat], this.dragBoundsSegments);
    [lngLat.lng, lngLat.lat] = this.networkDefinitionManager.segOffsetToLngLat(this.segOffset);
    // 2 - Rotation
    const worldPoint = this.networkDefinitionManager.segmentOffsetToOrientedWorldPoint(this.segOffset.segmentId, this.segOffset.offset);
    this.cameraAngleInDegreesFromEast = -worldPoint.headingInRadians * RAD_TO_DEG_FACTOR;
    this.cameraComponent.angleInDegrees$.next(this.cameraAngleInDegreesFromEast - this.map.getBearing());
  }

  sendCameraPosition(): void {
    this.scenarioPreviewManager?.setTrackCameraPosition({ ...this.segOffset, fromAlpha: this.fromAlpha });
  }

  loadCameraState(): void {
    const trackCameraPosition = this.scenarioPreviewManager.getTrackCameraPosition();

    if (trackCameraPosition) {
      this.fromAlpha = trackCameraPosition.fromAlpha;
      this.segOffset.offset = trackCameraPosition.offset;
      this.segOffset.segmentId = trackCameraPosition.segmentId;

      const [lng, lat] = this.networkDefinitionManager.segOffsetToLngLat(this.segOffset);
      this.moveCamera(lng, lat);

      this.showCamera();
    }
  }
}
