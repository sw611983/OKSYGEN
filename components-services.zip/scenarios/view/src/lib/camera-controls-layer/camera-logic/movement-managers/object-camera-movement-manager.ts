/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Map } from 'maplibre-gl';
import { Observable } from 'rxjs';

import { SimObject } from '@oksygen-sim-train-libraries/components-services/objects/data';

import { ObjectCameraControlComponent } from '../../camera-controls/object-camera-control/object-camera-control.component';
import { PreciseCoordConverter } from '../../models/camera-controls-layer.model';
import { CameraMovementManager } from './camera-movement-manager';

export class ObjectCameraMovementManager extends CameraMovementManager {
  private object: SimObject = null;
  private cameraAngleInDegreesFromEast = 0;

  private cameraComponent: ObjectCameraControlComponent;

  constructor(camera: { element: HTMLElement; component: ObjectCameraControlComponent }, userSetCameraAngleInDegrees$: Observable<number>) {
    super(camera);
    this.cameraComponent = camera.component;
    const sub = userSetCameraAngleInDegrees$.subscribe((angle: number) => {
      this.cameraAngleInDegreesFromEast = angle + (this.map?.getBearing() ?? 0);
      this.sendCameraPosition();
    });
    this.listeners.add(sub);
  }

  override setMap(map: Map): void {
    super.setMap(map);

    this.coordConverter = new PreciseCoordConverter(map);
  }

  protected override addMapListeners(map: Map): void {
    super.addMapListeners(map);

    map.on('rotate', this.rotateListener);
  }

  protected override removeMapListeners(map: Map): void {
    super.removeMapListeners(map);
    if(map) {
      map.off('rotate', this.rotateListener);
    }

  }

  public setCameraObject(object: SimObject): void {
    this.object = object;
    if (!object?.location?.lnglat || object?.location?.lnglat?.length < 2) return;
    const lngLat = object.location.lnglat;
    super.moveCamera(lngLat[0], lngLat[1]);
    if (this.cameraVisible) this.sendCameraPosition();
  }

  override moveCamera(): void {} // this camera has to be moved using setCameraObject

  postTreatCameraLngLat(): void {}

  sendCameraPosition(): void {
    if (!this.object) return;
    // Changes for issue : PRDOKS-3249 
    this.scenarioPreviewManager.setObjectCameraPosition({
      featureId: this.object.id,
      angleInDegrees: -this.cameraAngleInDegreesFromEast
    });
  }

  loadCameraState(): void {}

  private rotateListener = (): void => {
    this.cameraComponent.angleInDegrees$.next(this.cameraAngleInDegreesFromEast - this.map.getBearing());
  };
}
