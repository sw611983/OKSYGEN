/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import Point from '@mapbox/point-geometry';

import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { FixedSizeComponent, UserMovingCamera } from '../../models/camera.model';
import { DragAndDropManager } from '../../models/drag-drop-manager';
import { CameraMovementManager } from './camera-movement-manager';

export abstract class UserCameraMovementManager extends CameraMovementManager {
  private dragAndDropManager: DragAndDropManager;
  private initialMousePos: Point = null;
  private initialCameraPos: Point = null;

  protected networkDefinitionManager: NetworkDefinitionManager;

  constructor(protected layer: HTMLElement, camera: { element: HTMLElement; component: UserMovingCamera & FixedSizeComponent }) {
    super(camera);
    this.dragAndDropManager = new DragAndDropManager(layer, camera.component.getMoveHandle());
    this.dragAndDropManager.onMouseDown = this.onMouseDown.bind(this);
    this.dragAndDropManager.onMouseMove = this.onMouseMove.bind(this);
  }

  public setNetworkDefinitionManager(networkDefinitionManager: NetworkDefinitionManager): void {
    this.networkDefinitionManager = networkDefinitionManager;
  }

  protected getMapBounds(): number[] {
    if (!this.map || !this.networkDefinitionManager) {
      return [];
    }
    const bounds = this.map.getBounds();
    return this.networkDefinitionManager.segmentsInBoundingBox({
      minX: bounds.getWest(),
      maxX: bounds.getEast(),
      minY: bounds.getSouth(),
      maxY: bounds.getNorth()
    });
  }

  protected onMouseDown(mousePos: Point): void {
    this.initialMousePos = mousePos;
    this.initialCameraPos = this.getCameraXY();
  }

  protected onMouseMove(mousePos: Point): void {
    // Compute delta from initial position (when drag & drop was initiated) to avoid accumulating errors:
    const delta = mousePos.sub(this.initialMousePos);
    const newPos = this.initialCameraPos.add(delta);
    const lngLat = this.coordConverter.lngLat(newPos);
    this.moveCamera(lngLat.lng, lngLat.lat);
  }
}
