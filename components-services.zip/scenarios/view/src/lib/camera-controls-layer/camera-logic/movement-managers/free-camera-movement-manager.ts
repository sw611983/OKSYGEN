/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import Point from '@mapbox/point-geometry';
import { LngLat, Map } from 'maplibre-gl';

import { BREADTH_TO_ELEVATION_FACTOR, PreciseCoordConverter } from '../../models/camera-controls-layer.model';
import { FixedSizeComponent, UserMovingCamera } from '../../models/camera.model';
import { UserCameraMovementManager } from './user-camera-movement-manager';

export class FreeCameraMovementManager extends UserCameraMovementManager {
  private dragBoundsSegments: number[] = [];
  private approximateGroundElevation: number;

  constructor(layer: HTMLElement, camera: { element: HTMLElement; component: UserMovingCamera & FixedSizeComponent }) {
    super(layer, camera);
  }

  private zoomListener = (): void => {
    if (this.cameraVisible) this.sendCameraPosition();
  };

  override setMap(map: Map): void {
    super.setMap(map);
    this.dragBoundsSegments = this.getMapBounds();
    this.coordConverter = new PreciseCoordConverter(map);
  }

  protected override addMapListeners(map: Map): void {
    super.addMapListeners(map);

    map.on('zoom', this.zoomListener);
  }

  protected override removeMapListeners(map: Map): void {
    super.removeMapListeners(map);
    if (map) {
      map.off('zoom', this.zoomListener);
    }
  }

  protected override onMouseDown(mousePos: Point): void {
    const bounds = this.map.getBounds();
    this.dragBoundsSegments = this.networkDefinitionManager.segmentsInBoundingBox({
      minX: bounds.getWest(),
      maxX: bounds.getEast(),
      minY: bounds.getSouth(),
      maxY: bounds.getNorth()
    });
    super.onMouseDown(mousePos);
  }

  postTreatCameraLngLat(lngLat: LngLat): void {
    const segOffset = this.networkDefinitionManager.lngLatToSegmentOffset([lngLat.lng, lngLat.lat], this.dragBoundsSegments);
    this.approximateGroundElevation = this.networkDefinitionManager.segmentOffsetToOrientedWorldPoint(segOffset.segmentId, segOffset.offset).z;
  }

  sendCameraPosition(): void {
    const xy = this.networkDefinitionManager.lngLatToXYIndividual(this.lngLat.lng, this.lngLat.lat);
    const bounds = this.map.getBounds();
    const latBreadth = Math.abs(bounds.getNorthWest().distanceTo(bounds.getSouthWest()));
    const z = this.approximateGroundElevation + latBreadth * BREADTH_TO_ELEVATION_FACTOR;
    this.scenarioPreviewManager.setAerialCameraPosition({ ...xy, z });
    this.scenarioPreviewManager.setAerialCameraLngLat(this.lngLat);
  }

  loadCameraState(): void {
    this.lngLat = this.scenarioPreviewManager.getAerialCameraLngLat();

    this.moveCamera(this.lngLat.lng, this.lngLat.lat);
  }
}
