/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import Point from '@mapbox/point-geometry';
import { LngLat, Map } from 'maplibre-gl';
import { Subscription } from 'rxjs';

import { ScenarioPreviewManager } from '../../../services/scenario-preview.manager';
import { CenterManager, CoordConverter } from '../../models/camera-controls-layer.model';
import { FixedSizeComponent } from '../../models/camera.model';

export abstract class CameraMovementManager {
  protected centerManager: CenterManager;
  protected lngLat = new LngLat(0, 0);
  protected cameraVisible = false;
  protected upToDate = true;

  protected scenarioPreviewManager: ScenarioPreviewManager;
  protected map: Map;
  protected coordConverter: CoordConverter;
  protected listeners = new Subscription();

  constructor(camera: { element: HTMLElement; component: FixedSizeComponent }) {
    this.centerManager = new CenterManager(camera.element, camera.component);
  }

  private moveListener = (): void => {
    this.upToDate = false;
    if (this.cameraVisible) this.updateHTMLElementPosition();
  };

  destroy(): void {
    this.removeMapListeners(this.map);
    this.listeners.unsubscribe();
  }

  public setScenarioPreviewManager(scenarioPreviewManager: ScenarioPreviewManager): void {
    this.scenarioPreviewManager = scenarioPreviewManager;
  }

  public setMap(map: Map): void {
    if (this.map !== map) {
      if (this.map) {
        this.removeMapListeners(this.map);
      }

      this.map = map;

      if (this.map) {
        this.addMapListeners(this.map);
      }
    }
  }

  protected addMapListeners(map: Map): void {
    map.on('move', this.moveListener);
  }

  protected removeMapListeners(map: Map): void {
    if (map) {
      map.off('move', this.moveListener);
    }
  }

  public moveCamera(lng: number, lat: number): void {
    this.upToDate = false;
    this.lngLat.lng = lng;
    this.lngLat.lat = lat;
    this.postTreatCameraLngLat(this.lngLat);
    if (this.cameraVisible) {
      this.updateHTMLElementPosition();
      this.sendCameraPosition();
    }
  }

  public getCameraLngLat(): LngLat {
    return this.lngLat;
  }

  public getCameraXY(): Point {
    if (!this.upToDate) this.updateHTMLElementPosition();
    return this.centerManager.center;
  }

  public showCamera(): void {
    if (!this.upToDate) this.updateHTMLElementPosition();
    this.cameraVisible = true;
    this.sendCameraPosition();
  }

  public hideCamera(): void {
    this.cameraVisible = false;
  }

  /**
   * Updates the state of the camera based on what is persisted in the {@link SceanrioPreviewManager}
   */
  public abstract loadCameraState(): void;

  /**
   * This method can modify lngLat coordinates of camera in specific movement managers
   * (e.g. if camera has to stick to tracks, in which case the callback would project the position onto
   * the tracks).
   */
  protected abstract postTreatCameraLngLat(lngLat: LngLat): void;

  /**
   * This method must send the camera position to the ScenarioPreviewService.
   */
  protected abstract sendCameraPosition(): void;

  private updateHTMLElementPosition(): void {
    this.centerManager.center = this.coordConverter.xy(this.lngLat);
    this.upToDate = true;
  }
}
