/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { SimObject } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { ScenarioPreviewCamera } from '@oksygen-sim-train-libraries/components-services/scenarios';

import { ObjectCameraControlComponent } from '../camera-controls/object-camera-control/object-camera-control.component';
import { CameraLogic } from './camera-logic';
import { CameraRotationManager } from './camera-rotation-manager';
import { ObjectCameraMovementManager } from './movement-managers/object-camera-movement-manager';

export class ObjectCameraLogic extends CameraLogic<ObjectCameraMovementManager> {
  rotationManager: CameraRotationManager;

  constructor(layer: HTMLElement, camera: { element: HTMLElement; component: ObjectCameraControlComponent }) {
    super(ScenarioPreviewCamera.OBJECT);

    this.rotationManager = new CameraRotationManager(layer, camera);
    this.movementManager = new ObjectCameraMovementManager(camera, this.rotationManager.angleInDegrees$.asObservable());
  }

  override destroy(): void {
    super.destroy();
    this.rotationManager.angleInDegrees$?.complete();
  }

  setCameraObject(feature: SimObject): void {
    this.movementManager.setCameraObject(feature);
  }
}
