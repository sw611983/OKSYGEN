/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';
import { AerialCameraControlComponent } from '../camera-controls/aerial-camera-control/aerial-camera-control.component';
import { CameraLogic } from './camera-logic';
import { FreeCameraMovementManager } from './movement-managers/free-camera-movement-manager';
import { ScenarioPreviewCamera } from '@oksygen-sim-train-libraries/components-services/scenarios';

export class AerialCameraLogic extends CameraLogic<FreeCameraMovementManager> {
  constructor(layer: HTMLElement, camera: { element: HTMLElement; component: AerialCameraControlComponent }) {
    super(ScenarioPreviewCamera.AERIAL);

    this.movementManager = new FreeCameraMovementManager(layer, camera);
  }

  setNetworkDefinitionManager(networkDefinitionManager: NetworkDefinitionManager): void {
    this.movementManager.setNetworkDefinitionManager(networkDefinitionManager);
  }
}
