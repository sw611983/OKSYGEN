/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import Point from '@mapbox/point-geometry';
import { BehaviorSubject } from 'rxjs';

import { RAD_TO_DEG_FACTOR } from '../models/camera-controls-layer.model';
import { UserRotatingCamera } from '../models/camera.model';
import { DragAndDropManager } from '../models/drag-drop-manager';

export class CameraRotationManager {
  private dragAndDropManager: DragAndDropManager;
  private rotationCenter: Point;
  private initialMouseAngleInDegrees: number;
  private initialCameraAngleInDegrees: number;

  public angleInDegrees$ = new BehaviorSubject<number>(0);

  constructor(layer: HTMLElement, private camera: { element: HTMLElement; component: UserRotatingCamera }) {
    this.dragAndDropManager = new DragAndDropManager(layer, camera.component.getRotateHandle());
    this.dragAndDropManager.onMouseDown = this.onMouseDown.bind(this);
    this.dragAndDropManager.onMouseMove = this.onMouseMove.bind(this);
  }

  private onMouseDown(mousePos: Point): void {
    const el = this.camera.element;
    this.rotationCenter = new Point(el.offsetLeft + el.offsetWidth / 2, el.offsetTop + el.offsetHeight / 2);
    this.initialMouseAngleInDegrees = this.computeMouseAngleInDegrees(mousePos);
    this.initialCameraAngleInDegrees = this.camera.component.angleInDegrees$.value;
  }

  private onMouseMove(mousePos: Point): void {
    const deltaAngle = this.computeMouseAngleInDegrees(mousePos) - this.initialMouseAngleInDegrees;
    // CSS angles turn clockwise, so we have to subtract deltaAngle rather than adding it:
    const newAngle = this.initialCameraAngleInDegrees - deltaAngle;
    this.camera.component.angleInDegrees$.next(newAngle);
    this.angleInDegrees$.next(newAngle);
  }

  private computeMouseAngleInDegrees(mousePos: Point): number {
    const dx = mousePos.x - this.rotationCenter.x;
    const dy = this.rotationCenter.y - mousePos.y; // Y axis goes downward
    return Math.atan2(dy, dx) * RAD_TO_DEG_FACTOR;
  }
}
