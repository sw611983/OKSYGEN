/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { LngLat, Map } from 'maplibre-gl';

import { ScenarioPreviewManager } from '../../services/scenario-preview.manager';
import { CameraMovementManager } from './movement-managers/camera-movement-manager';

export abstract class CameraLogic<T extends CameraMovementManager> {
  public visible = false;

  protected movementManager: T;

  constructor(public readonly name: string) {}

  destroy(): void {
    this.movementManager.destroy();
  }

  setScenarioPreviewManager(scenarioPreviewManager: ScenarioPreviewManager): void {
    // we're changing scenario, therefore it's not necessarily the one in control of vision
    // so hide the camera initially, the subsequent subscriptions will make it visible if necessary
    this.hideCamera();

    this.movementManager.setScenarioPreviewManager(scenarioPreviewManager);
  }

  setMap(map: Map): void {
    this.movementManager.setMap(map);
  }

  showCamera(): void {
    this.visible = true;
    this.movementManager.showCamera();
  }

  hideCamera(): void {
    this.visible = false;
    this.movementManager.hideCamera();
  }

  loadCameraState(): void {
    this.movementManager.loadCameraState();
  }

  getCameraLngLat(): LngLat {
    return this.movementManager.getCameraLngLat();
  }

  moveCamera(lng: number, lat: number): void {
    this.movementManager.moveCamera(lng, lat);
  }
}
