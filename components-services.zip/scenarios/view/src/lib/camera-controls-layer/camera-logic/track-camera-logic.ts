/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';
import { TrackCameraControlComponent } from '../camera-controls/track-camera-control/track-camera-control.component';
import { CameraLogic } from './camera-logic';
import { TrackCameraMovementManager } from './movement-managers/track-camera-movement-manager';
import { ScenarioPreviewCamera } from '@oksygen-sim-train-libraries/components-services/scenarios';

export class TrackCameraLogic extends CameraLogic<TrackCameraMovementManager> {
  constructor(layer: HTMLElement, camera: { element: HTMLElement; component: TrackCameraControlComponent }) {
    super(ScenarioPreviewCamera.TRACK);

    this.movementManager = new TrackCameraMovementManager(layer, camera);
  }

  setNetworkDefinitionManager(networkDefinitionManager: NetworkDefinitionManager): void {
    this.movementManager.setNetworkDefinitionManager(networkDefinitionManager);
  }
}
