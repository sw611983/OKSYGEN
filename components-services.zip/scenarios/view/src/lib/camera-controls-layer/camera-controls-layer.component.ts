/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { AfterViewInit, Component, ElementRef, Input, OnChanges, OnDestroy, SimpleChanges, ViewChild } from '@angular/core';
import { LngLat, Map as MapLibre } from 'maplibre-gl';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { distinctUntilChanged, filter, take } from 'rxjs/operators';

import { SimObject } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { PreviewVisionState, ScenarioPreviewCamera } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { NetworkDefinitionManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { ScenarioPreviewManager } from '../services/scenario-preview.manager';
import { AerialCameraControlComponent } from './camera-controls/aerial-camera-control/aerial-camera-control.component';
import { ObjectCameraControlComponent } from './camera-controls/object-camera-control/object-camera-control.component';
import { TrackCameraControlComponent } from './camera-controls/track-camera-control/track-camera-control.component';
import { AerialCameraLogic } from './camera-logic/aerial-camera-logic';
import { CameraLogic } from './camera-logic/camera-logic';
import { ObjectCameraLogic } from './camera-logic/object-camera-logic';
import { TrackCameraLogic } from './camera-logic/track-camera-logic';

/**
 * Manages a camera widget which may be displayed over a Mapbox map.
 */
@Component({
  selector: 'oksygen-camera-controls-layer',
  templateUrl: './camera-controls-layer.component.html',
  styleUrls: ['./camera-controls-layer.component.scss']
})
export class CameraControlsLayerComponent implements AfterViewInit, OnChanges, OnDestroy {
  @Input() scenarioPreviewManager: ScenarioPreviewManager;
  @Input() mainMapViewMapReady$: Observable<boolean>;

  public visionLoaded = false;

  public currentCamera: CameraLogic<any>;

  // AERIAL CAMERA
  @ViewChild(AerialCameraControlComponent) private aerialCameraComponent: AerialCameraControlComponent;
  @ViewChild(AerialCameraControlComponent, { read: ElementRef }) private aerialCameraElementRef: ElementRef<HTMLElement>;
  private aerialCamera: AerialCameraLogic;

  // OBJECT CAMERA
  @ViewChild(ObjectCameraControlComponent) private objectCameraComponent: ObjectCameraControlComponent;
  @ViewChild(ObjectCameraControlComponent, { read: ElementRef }) private objectCameraElementRef: ElementRef<HTMLElement>;
  private objectCamera: ObjectCameraLogic;

  // TRACK CAMERA
  @ViewChild(TrackCameraControlComponent) private trackCameraComponent: TrackCameraControlComponent;
  @ViewChild(TrackCameraControlComponent, { read: ElementRef }) private trackCameraElementRef: ElementRef<HTMLElement>;
  private trackCamera: TrackCameraLogic;

  private map: MapLibre;

  private subscription: Subscription;

  private masterSubscription = new Subscription();

  private viewInit = false;
  private netDefSet = false;
  private previewManagerSet = false;
  private mapSet = false;

  private visionPreviouslyLoadedMap = new Map<string | number, boolean>();

  private initialised = false;

  constructor(private el: ElementRef) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.scenarioPreviewManager && changes.scenarioPreviewManager.currentValue !== changes.scenarioPreviewManager.previousValue) {
      this.previewManagerSet = !!this.scenarioPreviewManager;

      this.initialise();
    }
  }

  ngAfterViewInit(): void {
    const sub = combineLatest([this.aerialCameraComponent.initialized$, this.objectCameraComponent.initialized$, this.trackCameraComponent.initialized$])
      .pipe(
        filter(array => array.every(b => !!b)),
        take(1)
      ) // wait for everything to be initialized
      .subscribe(() => {
        this.aerialCamera = new AerialCameraLogic(this.el.nativeElement, {
          element: this.aerialCameraElementRef.nativeElement,
          component: this.aerialCameraComponent
        });
        this.objectCamera = new ObjectCameraLogic(this.el.nativeElement, {
          element: this.objectCameraElementRef.nativeElement,
          component: this.objectCameraComponent
        });
        this.trackCamera = new TrackCameraLogic(this.el.nativeElement, {
          element: this.trackCameraElementRef.nativeElement,
          component: this.trackCameraComponent
        });

        this.viewInit = true;
        this.initialise();
      });
    this.masterSubscription.add(sub);
  }

  ngOnDestroy(): void {
    this.map = null;
    this.visionPreviouslyLoadedMap.clear();
    this.subscription?.unsubscribe();
    this.masterSubscription.unsubscribe();

    this.aerialCamera.destroy();
    this.trackCamera.destroy();
    this.objectCamera.destroy();
  }

  public setMap(map: MapLibre): void {
    if (this.map !== map) {
      this.map = map;

      this.aerialCamera.setMap(map);
      this.objectCamera.setMap(map);
      this.trackCamera.setMap(map);

      this.mapSet = !!map;
      this.initialise();
    }
  }

  setNetworkDefinitionManager(mgr: NetworkDefinitionManager): void {
    this.hideAllCameras();

    this.aerialCamera.setNetworkDefinitionManager(mgr);
    this.trackCamera.setNetworkDefinitionManager(mgr);

    this.netDefSet = !!mgr;
    this.initialise();
  }

  passEventToMap(event: MouseEvent): void {
    if (!this.map) return;
    const ctr: any = event.constructor;
    const clone = new ctr(event.type, event);
    this.map.getCanvasContainer().dispatchEvent(clone);
  }

  private initialise(): void {
    if (!(this.viewInit && this.netDefSet && this.previewManagerSet && this.mapSet)) {
      return;
    }

    this.subscription?.unsubscribe();
    this.subscription = new Subscription();

    this.hideAllCameras();
    this.aerialCamera.setScenarioPreviewManager(this.scenarioPreviewManager);
    this.objectCamera.setScenarioPreviewManager(this.scenarioPreviewManager);
    this.trackCamera.setScenarioPreviewManager(this.scenarioPreviewManager);

    this.subscription
      .add(
        combineLatest([
          this.mainMapViewMapReady$,
          this.scenarioPreviewManager.controllingVision$.pipe(distinctUntilChanged()),
          this.scenarioPreviewManager.selectedCamera$
        ]).subscribe(([mapLoaded, controllingVision, cameraName]) => {
          // don't do anything until after the map is loaded
          // the map being loaded is a good indication that we have everything setup correctly
          if (mapLoaded) {
            // if this is the first load (i.e. shortly after component creation)
            // and we already have control of vision, then setup the camera as it was
            if (!this.initialised) {
              // FIXME this state juggling would probably not be necessary if camera management was part of the preview manager.
              this.aerialCamera.loadCameraState();
              this.objectCamera.loadCameraState();
              this.trackCamera.loadCameraState();

              const prevSelectedCamera = this.scenarioPreviewManager.getSelectedCamera();

              if (prevSelectedCamera) {
                switch (prevSelectedCamera) {
                  case ScenarioPreviewCamera.AERIAL:
                    this.currentCamera = this.aerialCamera;
                    break;
                  case ScenarioPreviewCamera.OBJECT:
                    this.currentCamera = this.objectCamera;
                    break;
                  case ScenarioPreviewCamera.TRACK:
                    this.currentCamera = this.trackCamera;
                    break;
                  case ScenarioPreviewCamera.TRAIN:
                    this.currentCamera = null;
                    break;
                }

                if (controllingVision && this.visionLoaded) this.currentCamera?.showCamera();
              }

              this.visionPreviouslyLoadedMap.set(this.scenarioPreviewManager.id, true);
              this.initialised = true;
              return;
            }

            let lngLat: LngLat = null;

            // Hide the current camera and use its location as a hint to the new camera.
            if (this.currentCamera) {
              lngLat = this.currentCamera.getCameraLngLat();
              if (this.visionLoaded) {
                this.currentCamera.hideCamera();
              }
            }

            // Make sure the new camera is always visible, no matter the current camera's position.
            if (!this.map) {
              return;
            }
            const mapBounds = this.map.getBounds();
            if (lngLat == null || (mapBounds && !mapBounds.contains(lngLat))) {
              lngLat = mapBounds.getCenter();
            }

            switch (cameraName) {
              case ScenarioPreviewCamera.AERIAL:
                this.currentCamera = this.aerialCamera;
                break;
              case ScenarioPreviewCamera.OBJECT:
                this.currentCamera = this.objectCamera;
                break;
              case ScenarioPreviewCamera.TRACK:
                this.currentCamera = this.trackCamera;
                break;
              case ScenarioPreviewCamera.TRAIN:
                this.currentCamera = null;
                break;
            }

            if (lngLat) this.currentCamera?.moveCamera(lngLat.lng, lngLat.lat);

            if (this.visionLoaded) this.currentCamera?.showCamera();
          }
        })
      );
      this.subscription.add(
        this.scenarioPreviewManager.focusedObject$.subscribe((feature: SimObject) => {
          this.objectCamera.setCameraObject(feature);
        })
      );
      this.subscription.add(
        combineLatest([this.mainMapViewMapReady$, this.scenarioPreviewManager.visionState$]).subscribe(([mapLoaded, state]) => {
          if (mapLoaded) {
            const visionPreviouslyLoaded = !!this.visionPreviouslyLoadedMap.get(this.scenarioPreviewManager.id);
            this.visionLoaded = state === PreviewVisionState.LOADED;

            if (!this.visionLoaded) {
              this.visionPreviouslyLoadedMap.set(this.scenarioPreviewManager.id, false);
              // Vision just got unloaded
              this.currentCamera?.hideCamera();
            } else {
              if (!visionPreviouslyLoaded) {
                this.visionPreviouslyLoadedMap.set(this.scenarioPreviewManager.id, true);
                // Vision just completed loading
                const initialLngLat = this.map.getCenter();
                this.currentCamera?.moveCamera(initialLngLat.lng, initialLngLat.lat);
              }

              this.currentCamera?.showCamera();
            }
          }
        })
      );
  }

  private hideAllCameras(): void {
    this.aerialCamera.hideCamera();
    this.objectCamera.hideCamera();
    this.trackCamera.hideCamera();
  }
}
