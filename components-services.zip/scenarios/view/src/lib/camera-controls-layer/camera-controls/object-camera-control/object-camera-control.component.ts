/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FixedSizeComponent, MovingCamera, UserRotatingCamera } from '../../models/camera.model';

@Component({
  selector: 'oksygen-object-camera-control',
  templateUrl: './object-camera-control.component.html',
  styleUrls: ['./object-camera-control.component.scss']
})
export class ObjectCameraControlComponent implements FixedSizeComponent, MovingCamera, UserRotatingCamera, AfterViewInit, OnDestroy {
  public readonly width = 258;
  public readonly height = 60;

  public angleInDegrees$ = new BehaviorSubject<number>(0); // reference: X axis with arrow to the right

  public initialized$ = new BehaviorSubject<boolean>(false);

  @ViewChild('rotateHandle') private rotateHandle: ElementRef;

  ngAfterViewInit(): void {
    this.initialized$.next(true);
  }

  ngOnDestroy(): void {
    this.angleInDegrees$.complete();
    this.initialized$.complete();
  }

  public getRotateHandle(): HTMLElement {
    return this.rotateHandle.nativeElement;
  }
}
