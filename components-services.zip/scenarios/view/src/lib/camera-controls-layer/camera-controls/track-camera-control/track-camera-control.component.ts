/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { FixedSizeComponent, RotatingCamera, UserMovingCamera } from '../../models/camera.model';

@Component({
  selector: 'oksygen-track-camera-control',
  templateUrl: './track-camera-control.component.html',
  styleUrls: ['./track-camera-control.component.scss']
})
export class TrackCameraControlComponent implements FixedSizeComponent, UserMovingCamera, RotatingCamera, AfterViewInit, OnDestroy {
  public readonly width = 128;
  public readonly height = 60;

  public angleInDegrees$ = new BehaviorSubject<number>(0); // reference: X axis with arrow to the right
  public flipped$ = new BehaviorSubject<boolean>(false);
  public computedAngleInDegrees = 0; // angle to be used in template to reflect flipped state

  public initialized$ = new BehaviorSubject<boolean>(false);
  private subscription: Subscription = new Subscription();

  @ViewChild('moveHandle') private moveHandle: ElementRef;

  ngAfterViewInit(): void {
    this.initialized$.next(true);
    const s1 = this.angleInDegrees$.subscribe(this.updateComputedAngle.bind(this));
    const s2 = this.flipped$.subscribe(this.updateComputedAngle.bind(this));
    this.subscription.add(s1);
    this.subscription.add(s2);
  }

  ngOnDestroy(): void {
    this.angleInDegrees$.complete();
    this.flipped$.complete();
    this.initialized$.complete();
    this.subscription.unsubscribe();
  }

  public getMoveHandle(): HTMLElement {
    return this.moveHandle.nativeElement;
  }

  public flip(): void {
    // Do not simply add 180° to angleInDegrees$ because the movement manager reassigns the angle every
    // time the camera is dragged and we need to know the fromAlpha state
    this.flipped$.next(!this.flipped$.value);
  }

  private updateComputedAngle(): void {
    this.computedAngleInDegrees = this.angleInDegrees$.value + (this.flipped$.value ? 180 : 0);
  }
}
