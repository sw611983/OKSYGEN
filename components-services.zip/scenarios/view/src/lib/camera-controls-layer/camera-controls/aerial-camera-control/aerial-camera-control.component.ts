/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FixedSizeComponent, UserMovingCamera } from '../../models/camera.model';

@Component({
  selector: 'oksygen-aerial-camera-control',
  templateUrl: './aerial-camera-control.component.html',
  styleUrls: ['./aerial-camera-control.component.scss']
})
export class AerialCameraControlComponent implements FixedSizeComponent, UserMovingCamera, AfterViewInit, OnDestroy {
  public readonly width = 60;
  public readonly height = 60;

  public initialized$ = new BehaviorSubject<boolean>(false);

  @ViewChild('moveHandle') private moveHandle: ElementRef;

  ngAfterViewInit(): void {
    this.initialized$.next(true);
  }

  ngOnDestroy(): void {
    this.initialized$.complete();
  }

  public getMoveHandle(): HTMLElement {
    return this.moveHandle.nativeElement;
  }
}
