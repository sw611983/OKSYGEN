/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BehaviorSubject } from 'rxjs';

export interface FixedSizeComponent {
  readonly width: number; // in pixels
  readonly height: number; // in pixels
}

export interface RotatingCamera {
  angleInDegrees$: BehaviorSubject<number>;
}

export interface UserRotatingCamera extends RotatingCamera {
  getRotateHandle(): HTMLElement;
}

export type MovingCamera = object;

export interface UserMovingCamera extends MovingCamera {
  getMoveHandle(): HTMLElement;
}
