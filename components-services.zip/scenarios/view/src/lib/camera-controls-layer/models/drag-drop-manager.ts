/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import Point from '@mapbox/point-geometry';

import { noop } from './camera-controls-layer.model';

// FIXME Rename. The term drag and drop usally refers to dragging from one component to another,
// rather than dragging an object within a component.
/**
 * Manages logic of dragging an object by a handle over a layer.
 * This class deals with client coordinates transformation into the frame of the layer
 * and passes the transformed coordinates to its callbacks, (0, 0) corresponding to
 * the top-left corner of the layer.
 */
export class DragAndDropManager {
  /**
   * client coords of the top-left corner of the layer
   */
  private layerClientOrigin: Point;

  /**
   * Called when mouse button is pressed, thus initiating the drag operation.
   *
   * @param mousePos mouse position when button is pressed, in the frame of the layer.
   */
  public onMouseDown: (mousePos: Point) => void = noop;

  /**
   * Called every time mouse moves with button pressed, during the drag operation.
   *
   * @param mousePos mouse position, in the frame of the layer.
   */
  public onMouseMove: (mousePos: Point) => void = noop;

  /**
   * Called when mouse button is released, thus completing the drag operation.
   */
  public onMouseUp: () => void = noop;

  constructor(private layer: HTMLElement, handle: HTMLElement) {
    handle.onmousedown = this.baseMouseDown.bind(this);
  }

  private baseMouseDown(e: MouseEvent): void {
    e.preventDefault();
    const rect = this.layer.getBoundingClientRect();
    this.layerClientOrigin = new Point(rect.x, rect.y);
    // This assumes the layer won't move during the drag & drop operation.
    this.layer.style.pointerEvents = 'auto';
    this.onMouseDown(this.transformEventCoords(e));
    this.layer.onmouseup = this.baseMouseUp.bind(this);
    this.layer.onmousemove = this.baseMouseMove.bind(this);
  }

  private baseMouseMove(e: MouseEvent): void {
    e.preventDefault();
    this.onMouseMove(this.transformEventCoords(e));
  }

  private baseMouseUp(): void {
    this.layer.onmouseup = null;
    this.layer.onmousemove = null;
    this.layer.style.pointerEvents = 'none';
    this.onMouseUp();
  }

  private transformEventCoords(e: MouseEvent): Point {
    return this.transformCoords(new Point(e.clientX, e.clientY));
  }
  private transformCoords(clientCoords: Point): Point {
    return clientCoords.sub(this.layerClientOrigin);
  }
}
