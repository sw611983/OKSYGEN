/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import Point from '@mapbox/point-geometry';
import { LngLat, Map } from 'maplibre-gl';

import { FixedSizeComponent } from './camera.model';

export const RAD_TO_DEG_FACTOR = 180 / Math.PI;
export const DEG_TO_RAD_FACTOR = Math.PI / 180;
export const FOV_IN_DEGREES = 60;
export const BREADTH_TO_ELEVATION_FACTOR = 1 / (2 * Math.tan((FOV_IN_DEGREES * DEG_TO_RAD_FACTOR) / 2));

export function noop(): void {}

export interface CoordConverter {
  lngLat(xy: Point): LngLat;
  xy(lngLat: LngLat): Point;
}

export class PreciseCoordConverter implements CoordConverter {
  constructor(private map: Map) {}

  lngLat(xy: Point): LngLat {
    return this.map.unproject(xy);
  }
  xy(lngLat: LngLat): Point {
    return this.map.project(lngLat);
  }
}

/*
 * This class gets and sets the center position of a fixed size HTML element.
 */
export class CenterManager {
  private halfWidth: number;
  private halfHeight: number;

  constructor(private el: HTMLElement, component: FixedSizeComponent) {
    this.halfWidth = component.width / 2;
    this.halfHeight = component.height / 2;
  }

  public get center(): Point {
    return new Point(this.el.offsetLeft + this.halfWidth, this.el.offsetTop + this.halfHeight);
  }

  public set center(c: Point) {
    this.el.style.left = c.x - this.halfWidth + 'px';
    this.el.style.top = c.y - this.halfHeight + 'px';
  }
}
