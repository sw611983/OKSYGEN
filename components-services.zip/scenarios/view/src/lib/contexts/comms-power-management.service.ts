/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';
import { SelfCompletingObservable, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Registry } from '@oksygen-common-libraries/pio';
import { CommsStateService, PhysicalHub, SimulatorService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { PowerManagement, PowerManagementRegistry } from '@oksygen-sim-train-libraries/components-services/common';
import { map, Observable, of } from 'rxjs';
import { CSystemSimulatorHelpersService } from '../services/csystem-simulator-helpers.service';
import { SystemRegistryObject } from '../models/comms-config.model';

@Injectable()
export class CommsPowerManagementService implements PowerManagement {

  constructor(
    private readonly registry: Registry,
    private readonly commsStateService: CommsStateService,
    private readonly csystem: CSystemSimulatorHelpersService,
    private readonly simulators: SimulatorService
  ) {}

  getBootedHubs(systemNumber: number, baseUrl?: string): SelfCompletingObservable<{ hubIds: number[] }> {
    // comms doesn't support checking this so assume we booted all hubs associated to sims in our config
    // note the above systemNumber will be ignored
    return this.simulators.data().pipe(
      takeOneTruthy(),
      map(simulators => {
        const supportedSystems = this.registry.getObjectArray<SystemRegistryObject>(['comms', 'supportedSystems'], []);
        const hubIdSet = new Set<number>();
        supportedSystems?.forEach(system => {
          if (!system.supportedSimulators?.length) { return; }
          system.supportedSimulators.forEach(sim => {
            const dbSim = simulators.find(s => s.name === sim);
            if (!dbSim) { return; }
            dbSim.physicalHub.forEach( hub => hubIdSet.add(hub.hubId) );
          });
        });
        const hubIds = Array.from(hubIdSet.values());
        return { hubIds } ;
      })
    );
  }

  getOtherBootedHubs(systemNumber: number): SelfCompletingObservable<{ hubIds: number[] }> {
    // comms doesn't support checking this so have to return an empty array
    return of({hubIds: []});
  }

  isHubOperational(systemNumber: number, hubId: number, baseUrl?: string): SelfCompletingObservable<boolean> {
    return this.csystem.isWebServerUp(systemNumber);
  }

  powerOnOff(command: 'boot' | 'shutdown', systemNumber: number, hub: PhysicalHub, onlyBooted?: boolean, url?: string, useIgnored?: boolean): Observable<any> {
    if (command === 'boot') { throw new Error('Comms already running and cannot boot. Only shutdown commands accepted.'); }
    this.commsStateService.requestShutdown(systemNumber);
    return of(true);
  }

  powerOnOffHub(command: 'boot' | 'shutdown', systemNumber: number, hubId: number, url?: string): Observable<any> {
    if (command === 'boot') { throw new Error('Comms already running and cannot boot. Only shutdown commands accepted.'); }
    this.commsStateService.requestShutdown(systemNumber);
    return of(true);
  }

  shutdownConfigHubs(): void {
    const powerManagementReg = this.getShutdownConfig();
    if (powerManagementReg) {
      for (const powerManagementHub of powerManagementReg.hubs) {
        this.powerOnOffHub('shutdown', powerManagementHub.systemNumber, powerManagementHub.hubId).subscribe();
      }
    }
  }

  getShutdownConfig(): PowerManagementRegistry {
    return this.registry.getObject<PowerManagementRegistry>(['power', 'management'], null);
  }

  shutdownAll(onlyBooted?: boolean, baseUrl?: string, useIgnored?: boolean): void {
    const supportedSystems = this.registry.getObjectArray<{systemNumber: number}>(['comms', 'supportedSystems']);
    supportedSystems?.forEach(system => {
      this.powerOnOff('shutdown', system.systemNumber, null).subscribe();
    });

  }
}
