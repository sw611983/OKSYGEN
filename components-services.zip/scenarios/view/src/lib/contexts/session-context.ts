/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { isEqual, isNil } from 'lodash';
import { BehaviorSubject, combineLatest, Observable, of } from 'rxjs';
import { distinctUntilChanged, map, switchMap, tap } from 'rxjs/operators';

import { filterTruthy } from '@oksygen-common-libraries/common';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { BaseDataManager } from '@oksygen-sim-core-libraries/components-services/data-services';
import { UserScenarioFavouritesManager } from '@oksygen-sim-core-libraries/components-services/favourites';
import { EventsManager, RulesManager, UserFault } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { HubStateService } from '@oksygen-sim-train-libraries/components-services/hubs';
import {
  DefaultObjectsSourceManagerConfiguration,
  emptyGeoJSONCollection,
  ITrainObjectTrackAtlasManager,
  MapIOManager
} from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectContainer, ObjManager } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { BaseRule, RuleBlock, RuleTemplate } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario, ScenarioRule } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { BaseTrainManager, ITrainReachablePathFinder } from '@oksygen-sim-train-libraries/components-services/trains';
import { WorldManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { MarkerManager } from '../markers/services/marker.manager';
import { OperatorMarkerManager } from '../operator-score/services/operator-marker.manager';
import { EnvironmentManager } from '../services/environment.manager';
import { RadioManager } from '../services/radio.manager';
import { ScenarioContext } from './scenario-context';

export class SessionObjectsSourceManagerConfiguration extends DefaultObjectsSourceManagerConfiguration<Scenario> {
  override getTriggerObjects(data: Scenario): Array<string> {
    const obj: Array<string> = [];

    data?.rule?.forEach(r => {
      r?.ruleTemplateReference?.ruleBlocks?.ruleBlock?.forEach(rb => {
        rb?.properties?.property?.forEach(p => {
          if (p.name === 'feature_name' && p.value) {
            obj.push(p.value as string);
          }
        });
      });
    });

    return obj;
  }


  override subscribe(): void {
    this.subscription = combineLatest([
      this.netDef$,
      this.highlightedPath$,
      this.layer$,
      // If the description changed, we don't want to reload the map for example
      this.data$.pipe(
        distinctUntilChanged(
          (prev, curr) => isEqual(prev?.world, curr?.world) && isEqual(prev?.tracknetworkName, curr?.tracknetworkName) && isEqual(prev?.rule, curr?.rule))
      ) ?? of(null)
    ]).subscribe(
      ([netDef, path, layers, data]) => {
        const oldPath = this.path;
        this.netDef = netDef;
        this.path = path;
        this.layers = layers;
        this.data = data;

        if (netDef?.worldData?.name === data?.tracknetworkName) {
          this.triggerObjects = this.getTriggerObjects(data);
          // this.featureGeoJSON = this.asFeatureGeoJSON();
        }
        if (path !== oldPath) {
          this.featureGeoJSON.features.forEach(f => {
            const obj = this.objectsMap.get(f.properties.id);
            f.properties.onPath = this.objectOnPath(obj, this.path);
          });
        }

        this.dataHasChangedSubject.next(!netDef || netDef?.worldData?.name !== data?.tracknetworkName);
        this.triggerUpdateSubject.next(true);
      },
      err => this.logger.error('An error occured in SessionContext', JSON.stringify(err))
    );

    // we need to reset our objects when netDef changes track
    const netDef$ = this.netDef$.pipe(
      filterTruthy(),
      distinctUntilChanged((a, b) => a?.worldData?.name === b?.worldData?.name),
      tap(netDef => {
        this.objectsMap.clear();
        this.featureGeoJSON = emptyGeoJSONCollection();
      })
    );

    const objSub = netDef$.pipe(
      filterTruthy(),
      switchMap(netDef => this.objects$)
    ).subscribe(objects => {
      objects?.inserted?.forEach(insObj => {
        this.objectsMap.set(insObj.id, insObj);
      });
      objects?.updated?.forEach(upObj => {
        this.objectsMap.set(upObj.id, upObj);
      });
      objects?.deleted?.forEach(delObj => {
        this.objectsMap.delete(delObj.id);
      });
      this.featureGeoJSON = this.asFeatureGeoJSON(objects);
      this.dataHasChangedSubject.next(!objects || (!objects?.inserted && !objects?.updated));
    });
    this.subscription.add(objSub);
  }
}

/**
 * The Context used by a session.
 */
export class SessionContext implements ScenarioContext {
  public objects: ObjManager;
  public trains: BaseTrainManager;
  public markers?: MarkerManager;
  public operatorMarkers?: OperatorMarkerManager;
  public map: ITrainObjectTrackAtlasManager;
  public mapIo: MapIOManager;
  public events?: EventsManager;
  public rules?: RulesManager;
  public ruleBlocks$?: Observable<RuleBlock[]>;
  public ruleTemplates$?: Observable<RuleTemplate[]>;
  public userFaults?: BaseDataManager<UserFault[]>; // currently no base user fault data manager
  public userScenarioFavourites?: UserScenarioFavouritesManager;
  public world: WorldManager;
  public pathFinder$: Observable<ITrainReachablePathFinder>;
  public hubs?: HubStateService; // consider changing this to a manager
  public environment?: EnvironmentManager;
  public radio?: RadioManager;
  public isSimulation$: Observable<boolean>;

  public uiState = new UiStateModelManager();

  public getLinkedRules$?: (selectedObj$: Observable<ObjectContainer>) => Observable<Array<BaseRule>>;
  public objectModifications$: () => Observable<string[]>;

  constructor(public readonly data$: Observable<Scenario> = of(null)) {
    this.getLinkedRules$ = (selectedObj$: Observable<ObjectContainer>): Observable<Array<BaseRule>> =>
      combineLatest([selectedObj$, this.data$]).pipe(
        map(([selectedObj, scenario]) => {
          const scenarioRules: ScenarioRule[] = [];

          if (!isNil(selectedObj) && !isNil(scenario)) {
            scenario?.rule?.forEach(r => {
              r?.ruleTemplateReference?.ruleBlocks?.ruleBlock?.forEach(rb => {
                rb?.properties?.property?.forEach(p => {
                  if (p.name === 'feature_name' && p?.value === selectedObj.name) {
                    scenarioRules.push(r);
                  }
                });
              });
            });
          }

          return scenarioRules;
        })
      );

    this.objectModifications$ = (): Observable<string[]> => this.data$.pipe(map(scenario => scenario.world.objectModification.map(om => om.name)));
  }

  destroy(): void {
    this.map?.destroy();
    this.objects?.destroy();
    this.trains?.destroy();
    this.mapIo?.destroy();
    this.events?.destroy();
    this.hubs?.destroy();
    this.markers?.destroy();
    this.operatorMarkers?.destroy();

    this.completeSubject(this.data$);
    this.completeSubject(this.world?.world$);
    this.completeSubject(this.pathFinder$);
  }

  private completeSubject<T>(observable: Observable<T>): void {
    if ((observable as BehaviorSubject<T>)?.complete) {
      (observable as BehaviorSubject<T>).complete();
    }
  }
}
