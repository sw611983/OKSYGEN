/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable, NgZone } from '@angular/core';
import { Store } from '@ngrx/store';
import { BehaviorSubject, Observable, OperatorFunction, pipe } from 'rxjs';
import { distinctUntilChanged, filter, first, map, switchMap } from 'rxjs/operators';

import { filterTruthy, shareReplayOne, takeOneTruthy } from '@oksygen-common-libraries/common';
import { ContextManager, ObjectLocation, WorldData } from '@oksygen-sim-train-libraries/components-services/common';
import { ObjectWorldGeometry } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleTemplate, RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';
import { Scenario, ScenarioService } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { NetworkDefinitionManager, WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { getSelectedSystemData } from '../store/system/system.selectors';
import { SystemStoreData, SystemStoreState } from '../store/system/system.state';
import { SessionContext } from './session-context';

/**
 * FIXME - refactor
 * Basically, a lot of code assumed world would only load once, so on scenario creation when you can initially change world a lot of issues
 * would arise due to memory not being wiped on world change. Furthermore, because updates happen via observables AND 1 at a time, changing
 * world would emit like 4-6 different times (objects, train, world, scenario, netDef at a minimum) which meant things listening to all of
 * these things would get inconsistent data in the meantime. As in, if world$ emits first then all the other observables will still be looking
 * at the old objects trains etc but the new world so any listener processing would fail and likely error trying to find old world objects on the new world.
 */

/**
 * Cutdown Session Runner to provide basic managers for a running session
 */
@Injectable()
export abstract class BaseScenarioSessionContextManager<ContextId> extends ContextManager<ContextId, SessionContext> {

  protected populateObjectLngLat(
    zone: NgZone,
    store: Store<SystemStoreState>,
    worldDefService: WorldDefinitionService,
    scenarioService: ScenarioService,
    systemNumber: number
  ): (objLocations: Map<number, ObjectWorldGeometry>) => Observable<Map<number, ObjectLocation>> {
    return objLocs =>
      this.getScenarioFromSystemNumber(zone, store, scenarioService, systemNumber).pipe(
        switchMap(scenario => worldDefService.populateObjectLngLat(objLocs).pipe(first()))
      );
  }

  protected scenarioIdFromStore(): OperatorFunction<SystemStoreData, number> {
    return pipe(
      map((storeData: SystemStoreData) => storeData?.session?.scenarioDefinition?.data?.scenarioId),
      // Ignore irrelevant System state updates
      distinctUntilChanged()
    );
  }

  protected getScenarioFromSystemNumber(
    zone: NgZone,
    store: Store<SystemStoreState>,
    scenarioService: ScenarioService,
    systemNumber: number
  ): Observable<Scenario> {
    return store.select(getSelectedSystemData(zone, systemNumber)).pipe(
      this.scenarioIdFromStore(),
      filterTruthy(),
      switchMap(scenarioId =>
        scenarioService.data().pipe(
          filterTruthy(),
          map(scenarios => scenarios.find(s => s.scenarioId === scenarioId)),
          first()
        )
      ),
      first()
    );
  }

  protected getFullScenarioFromSystemNumber(
    zone: NgZone,
    store: Store<SystemStoreState>,
    scenarioService: ScenarioService,
    systemNumber: number
  ): Observable<Scenario> {
    const scenarioSubject = new BehaviorSubject<Scenario>(null);

    store
      .select(getSelectedSystemData(zone, systemNumber))
      .pipe(
        this.scenarioIdFromStore(),
        filterTruthy(),
        switchMap(scenarioId => scenarioService.getScenarioByScenarioId(scenarioId).pipe(first())),
        first()
      )
      .subscribe(s => scenarioSubject.next(s));

    return scenarioSubject.pipe(shareReplayOne());
  }

  protected getWorldFromScenarioId(worldDefService: WorldDefinitionService, scenarioService: ScenarioService, scenarioId: number): Observable<WorldData> {
    return scenarioService.data().pipe(
      map(scenarios => (scenarios ? scenarios.find(s => s.scenarioId === scenarioId) : null)),
      takeOneTruthy(), // TODO Figure out how to handle situations where no scenarios match
      map(scenario => scenario.tracknetworkName),
      filterTruthy(),
      switchMap(track => worldDefService.loadWorld(track)),
      first()
    );
  }

  protected getWorldFromSystemNumber(
    zone: NgZone,
    store: Store<SystemStoreState>,
    worldDefService: WorldDefinitionService,
    scenarioService: ScenarioService,
    systemNumber: number
  ): Observable<WorldData> {
    const world$ = new BehaviorSubject<WorldData>(null);

    store
      .select(getSelectedSystemData(zone, systemNumber))
      .pipe(
        this.scenarioIdFromStore(),
        filterTruthy(),
        switchMap(scenarioId => this.getWorldFromScenarioId(worldDefService, scenarioService, scenarioId)),
        first()
      )
      .subscribe(w => world$.next(w));

    return world$.pipe(shareReplayOne());
  }

  protected getWorldProcessorFromScenario(worldDefService: WorldDefinitionService, scenario$: Observable<Scenario>): Observable<NetworkDefinitionManager> {
    const ndef$ = scenario$.pipe(
      filter(s => !!s?.tracknetworkName),
      distinctUntilChanged((prev, curr) => prev.tracknetworkName === curr.tracknetworkName),
      switchMap(s => worldDefService.getNetworkDefinitionManager(s.tracknetworkName))
    );
    return ndef$;
  }

  protected getWorldProcessorFromSystemNumber(
    zone: NgZone,
    store: Store<SystemStoreState>,
    worldDefService: WorldDefinitionService,
    scenarioService: ScenarioService,
    systemNumber: number
  ): Observable<NetworkDefinitionManager> {
    return store.select(getSelectedSystemData(zone, systemNumber)).pipe(
      this.scenarioIdFromStore(),
      filterTruthy(),
      switchMap(scenarioId => {
        const netDef$ = scenarioService.data().pipe(
          map(scenarios => scenarios?.find(s => s.scenarioId === scenarioId)),
          filterTruthy(),
          switchMap(scenario => worldDefService.getNetworkDefinitionManager(scenario.tracknetworkName))
        );
        return netDef$;
      }),
      distinctUntilChanged()
    );
  }

  protected getRuleTemplate(ruleTemplateService: RuleTemplateService, ruleTemplateId: string): Observable<RuleTemplate> {
    return ruleTemplateService.getRuleTemplateById(ruleTemplateId);
  }
}
