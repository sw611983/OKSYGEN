/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { TestBed } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { PowerManagementService } from './power-management.service';
import { SessionLoggingConfigToken } from '../tokens/session-logging.token';
//import { OksygenSimTrainScenarioViewModule } from '../scenario-view.module';

describe('PowerManagementService', () => {
  let service: PowerManagementService;

  beforeEach(() => {
    configureSimTrainTestingModule({
      // imports: [OksygenSimTrainScenarioViewModule],
      providers: [
        PowerManagementService,
        {
          provide: SessionLoggingConfigToken,
          useValue: {}
        }
      ]
    });

    service = TestBed.inject(PowerManagementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
