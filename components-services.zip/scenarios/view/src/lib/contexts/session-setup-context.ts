/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

// Imported to make links in docco work
// eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars
import { Context } from '@oksygen-sim-train-libraries/components-services/common';
import { ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';
import { ScenarioContext } from './scenario-context';

/**
 * A {@link Context} which is a collection of references to the data you need when setting up a session.
 */
// eslint-disable-next-line @typescript-eslint/no-empty-object-type
export interface SessionSetupContext extends ScenarioContext {
}

/**
 * Used for dependency injection.
 * Typically provided by using an existing {@link ContextSupplier} that supplies a Context compatible with {@link ScenarioContext}.
 */
export abstract class SessionSetupContextSupplier extends ContextSupplier<ScenarioContext> {}
