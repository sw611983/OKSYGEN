/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable, NgZone } from '@angular/core';
import { Store } from '@ngrx/store';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { EventsService } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { HubStateService } from '@oksygen-sim-train-libraries/components-services/hubs';
import { ObjectTypeContainer } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockService, RuleService, RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioService } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { UserFaultsService } from '@oksygen-sim-train-libraries/components-services/user-faults';

import { MarkerManager } from '../markers/services/marker.manager';
import { SystemStoreState } from '../store/system/system.state';
import { BaseScenarioSessionContextManager } from './base-scenario-session-context.manager';
import { SessionContext } from './session-context';
import { CSystemSimulatorHelpersService } from '../services/csystem-simulator-helpers.service';

/**
 * Cutdown Session Runner to provide basic managers for a running session
 */
@Injectable()
export class SimpleSessionRunnerContextManager extends BaseScenarioSessionContextManager<number> {
  private points: ObjectTypeContainer;

  constructor(
    private readonly registry: Registry,
    private readonly logger: Logging,
    private readonly scenarioService: ScenarioService,
    private readonly store: Store<SystemStoreState>,
    private readonly eventService: EventsService,
    private readonly faultService: UserFaultsService,
    private readonly ruleBlockService: RuleBlockService,
    private readonly ruleService: RuleService,
    private readonly ruleTemplateService: RuleTemplateService,
    private readonly zone: NgZone,
    private readonly cSystemSimulatorHelpersService: CSystemSimulatorHelpersService
  ) {
    super();
  }

  protected createContext(id: number): SessionContext {
    const scenario$ = this.getFullScenarioFromSystemNumber(this.zone, this.store, this.scenarioService, id);
    const context = new SessionContext(scenario$);

    const ruleBlocks$ = this.ruleBlockService.data();
    const ruleTemplates$ = this.ruleTemplateService.data();

    const eventMan = this.eventService.createSystem(id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    const userFaultsMan = this.faultService.create(id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    const ruleMan = this.ruleService.createSystem(id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    context.hubs = new HubStateService(this.registry, this.logger, id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    const markerMan = new MarkerManager(this.registry, this.logger, id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));

    context.rules = ruleMan;
    context.ruleBlocks$ = ruleBlocks$;
    context.ruleTemplates$ = ruleTemplates$;
    context.markers = markerMan;
    context.events = eventMan;
    context.userFaults = userFaultsMan;

    return context;
  }

  override destroyContext(id: number): void {
    super.destroyContext(id);

    // add any other service required destroy calls here for sessions
    if (typeof id === 'number') {
      this.eventService.destroySystem(id);
      this.faultService.destroySystem(id);
      this.ruleService.destroySystem(id);
    }
  }
}
