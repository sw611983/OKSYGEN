/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Observable } from 'rxjs';

// Included for docco linking to work
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Context, ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';
import { HubStateService } from '@oksygen-sim-train-libraries/components-services/hubs';
import { TrainObjectDataMapContext, TrainObjectDataMapContextSupplier } from '@oksygen-sim-train-libraries/components-services/maps';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';

/**
 * A {@link Context}  which supplies data for a scenario.
 */
export interface ScenarioContext extends TrainObjectDataMapContext<Scenario> {
  hubs?: HubStateService;
  isSimulation$?: Observable<boolean>;
}


/**
 * Used for dependency injection.
 * Typically provided by using an existing {@link ContextSupplier} that supplies a Context compatible with {@link ScenarioContext}.
 */
export abstract class ScenarioContextContextSupplier<C extends ScenarioContext = ScenarioContext>  extends TrainObjectDataMapContextSupplier<C> {}
