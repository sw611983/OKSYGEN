/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { ScenarioContextContextSupplier } from './scenario-context';
import { SessionContext } from './session-context';

/**
 * A stopgap to allow components to continue to use PartialContext
 * instead of more appropriate interfaces.
 */
 export abstract class SessionContextSupplier extends ScenarioContextContextSupplier<SessionContext> {}
