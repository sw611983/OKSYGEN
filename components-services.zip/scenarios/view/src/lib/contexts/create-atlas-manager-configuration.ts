/// @copyright © 2024 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { map, merge, Observable } from 'rxjs';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { IReachablePathFinder, UpdatedInserted } from '@oksygen-sim-train-libraries/components-services/common';
import { HubStateService } from '@oksygen-sim-train-libraries/components-services/hubs';
import {
  ObjectMapRenderer,
  readMapConfig,
  TrainObjectTrackAtlasManagerConfiguration
} from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectContainer, ObjectTypeContainer, ObjectTypeDataService, ObjManager } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { Scenario } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { BaseTrainManager, ConsistDataService } from '@oksygen-sim-train-libraries/components-services/trains';
import { WorldManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { SessionObjectsSourceManagerConfiguration } from './session-context';

export function createAtlasManagerConfiguration(
  pointType: ObjectTypeContainer,
  objectTypeDataService: ObjectTypeDataService,
  consistDataService: ConsistDataService,
  objManager: ObjManager,
  hubStatesService: HubStateService,
  trainManager: BaseTrainManager,
  worldManager: WorldManager,
  pathFinder$: Observable<IReachablePathFinder>,
  data$: Observable<Scenario>,
  logger: Logging,
  registry: Registry,
  overrideObjectRenderer: ObjectMapRenderer
): TrainObjectTrackAtlasManagerConfiguration {
  const mapConfig = readMapConfig(registry);

  const objectsSourceManagerConfiguration = new SessionObjectsSourceManagerConfiguration(
    mapConfig,
    logger,
    worldManager.netDef$,
    merge(
      objManager.getInsertedObject$(true).pipe(map(i => {
        const upsert: UpdatedInserted<ObjectContainer> = {inserted: i, updated: []};
        return upsert;
      })),
      objManager.getUpdatedObject$().pipe(map(o => {
        const upsert: UpdatedInserted<ObjectContainer> = {inserted: [], updated: o};
        return upsert;
      })),
      objManager.getDeletedObject$().pipe(map(o => {
        const upsert: UpdatedInserted<ObjectContainer> = {inserted: [], updated: [], deleted: o};
        return upsert;
      })),

    ),
    data$,
    overrideObjectRenderer
  );

  return {
    objectTypes$: objectTypeDataService.placementTypesMap$({domain: 'editor', key: 'scenario'}),
    getObject$: objManager.getObject$.bind(objManager),
    getObject: objManager.getObject.bind(objManager),
    allHubState$: hubStatesService?.getAllHubState$(),
    allHubUsers$: hubStatesService?.getAllHubUsers$(),
    trains$: trainManager.data(),
    selectedTrain$: trainManager.getSelectedTrain$(),
    pointType,
    ...worldManager,
    objects$: objManager.data(),
    objectsSourceManagerConfiguration,
    consist$: consistDataService.data(),
    pathFinder$,
    mapConfig
  };
}
