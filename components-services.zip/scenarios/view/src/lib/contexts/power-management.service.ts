/// @copyright © 2022 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { Observable, of, Subscription, zip } from 'rxjs';
import { catchError, map, switchMap, take, timeout } from 'rxjs/operators';

import { SelfCompletingObservable } from '@oksygen-common-libraries/common';
import { Registry } from '@oksygen-common-libraries/pio';
import { PhysicalHub, Simulator, SimulatorService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { PowerManagement, PowerManagementRegistry } from '@oksygen-sim-train-libraries/components-services/common';

import { CSystemSimulatorHelpersService } from '../services/csystem-simulator-helpers.service';

@Injectable()
export class PowerManagementService implements PowerManagement, OnDestroy {

  private masterSubscription = new Subscription();

  constructor(
    private registry: Registry,
    private systemSimsHelperService: CSystemSimulatorHelpersService,
    private simulatorService: SimulatorService,
    private httpClient: HttpClient
  ) {}

  /**
   * Get all the hubs that have been booted by this power management module (NOT this app - the backend power management module).
   * Currently systemNumber is ignored on the backend.
   *
   * @param systemNumber the system this hub is on
   * @param baseUrl (optional) uses registry url if not supplied. Should use powermanagement registry format!
   */
  getBootedHubs(systemNumber: number, baseUrl?: string): SelfCompletingObservable<{ hubIds: number[] }> {
    const url = this.registry
      .getString(
        ['powerManagement', 'resturl'],
        baseUrl,
        new Map<string, string>([
          ['systemNumber', `${systemNumber}`],
          ['hubId', 'delete'],
          ['command', 'boot_hubs']
        ])
      )
      .replace('/hub/delete', '');

    return this.httpClient.get<{ hubIds: number[] }>(url);
  }

  /**
   * Get all the hubs that have been booted by other power management modules (ie if we're operator station, student station and vice versa).
   * Currently systemNumber is ignored on the backend.
   */
  getOtherBootedHubs(systemNumber: number): SelfCompletingObservable<{ hubIds: number[] }> {
    const others = this.registry.getStringArray(['powerManagementOther', 'resturl']);
    if (others?.length) {
      const results: SelfCompletingObservable<{ hubIds: number[] }>[] = [];
      for (const url of others) {
        results.push(this.getBootedHubs(systemNumber, url));
      }
      return zip(results).pipe(
        map(otherHubIds => {
          const condensed = otherHubIds.map(hubs => hubs.hubIds);
          const all: { hubIds: number[] } = { hubIds: [] };
          condensed.forEach(c => all.hubIds.push(...c));
          return all;
        })
      );
    }
    return of({ hubIds: [] });
  }

  /**
   * Check if the hub is on. Returns true if so, false if not.
   *
   * @param systemNumber the system this hub is on
   * @param hubId the hub to check
   * @param baseUrl (optional) uses registry url if not supplied. Should use powermanagement registry format!
   */
  isHubOperational(systemNumber: number, hubId: number, baseUrl?: string): SelfCompletingObservable<boolean> {
    // expected url format is "http://localhost:8999/power_management_api/{systemNumber}/hub/{hubId}/{command}"
    const url = this.registry.getString(
      ['powerManagement', 'resturl'],
      baseUrl,
      new Map<string, string>([
        ['systemNumber', `${systemNumber}`],
        ['hubId', `${hubId}`],
        ['command', 'ping']
      ])
    );
    // we get a 202 if the hub is alive and 404 if it's not - map any success to true and any fail (including timeout) to false
    return this.httpClient.put(url, '', { responseType: 'text' }).pipe(
      timeout(3000),
      catchError((err, caught) => of(false)),
      map(val => (val === false ? false : true))
    );
  }

  /**
   * Switch on or off a hub. By default, you can't switch off a hub that is under control by a different power management module.
   *
   * @param command whether to switch on or off
   * @param systemNumber the system number of this hub
   * @param hub the hub to switch on or off
   * @param onlyBooted (default true) whether this boot should take place if the hub is under control of another system
   * @param url (optional) uses registry url if not supplied. Should use powermanagement registry format!
   * @param useIgnored (default true) whether to check if the hub has been ignored. True = ignore config is used, meaning ignored hubs will not be switched off.
   */
  public powerOnOff(command: 'boot' | 'shutdown', systemNumber: number, hub: PhysicalHub, onlyBooted = true, url?: string, useIgnored = true): Observable<any> {
    if (onlyBooted && command === 'shutdown') {
      return this.getBootedHubs(systemNumber, url).pipe(
        switchMap(hubs => {
          const exists = hubs?.hubIds?.find(h => h === hub.hubId);
          const ignored = useIgnored ? this.isHubIgnored(hub.hubId) : false;
          // only can shut down a hub if we booted it AND we don't intentionally ignore it
          if (exists && !ignored) {
            return this.powerOnOffHub(command, systemNumber, hub.hubId, url);
          } else {
            return of();
          }
        })
      );
    }
    return this.powerOnOffHub(command, systemNumber, hub.hubId, url);
  }

  /**
   * Power on or off a hub. This is made public but you should prefer powerOnOff() as it has protections against
   * switching off other systems hubs.
   */
  public powerOnOffHub(command: 'boot' | 'shutdown', systemNumber: number, hubId: number, url?: string): SelfCompletingObservable<any> {
    url = url
      ? url
      : this.registry.getString(
          ['powerManagement', 'resturl'],
          null,
          new Map<string, string>([
            ['systemNumber', `${systemNumber}`],
            ['hubId', `${hubId}`],
            ['command', command]
          ])
        );
    return this.httpClient.put(url, '');
  }

  /**
   * Shutdown all hubs specified in the power.management registry. Will not check if they were booted.
   * You can get the list of these hubs via ```getShutdownConfig()```.
   */
  public shutdownConfigHubs(): void {
    const powerManagementReg = this.getShutdownConfig();
    if (powerManagementReg) {
      for (const powerManagementHub of powerManagementReg.hubs) {
        this.masterSubscription.add(this.powerOnOffHub('shutdown', powerManagementHub.systemNumber, powerManagementHub.hubId).subscribe());
      }
    }
  }

  /**
   * Get all hubs configured to be shutdown by ```shutdownConfigHubs()```.
   */
  public getShutdownConfig(): PowerManagementRegistry {
    return this.registry.getObject<PowerManagementRegistry>(['power', 'management'], null);
  }

  /**
   * Shutdown all hubs that were booted by this power management module. You can forcefully override onlyBooted with false
   * to force shutdown EVERYTHING. By default we do not shutdown any hubs in the power.management config's ignoreHubs array - you can override this with
   * useIgnored = false.
   *
   * @param onlyBooted (default true) only shutdown the hubs that were booted by this power management module (the BE)
   * @param baseUrl (optional) uses registry url if not supplied. Should use powermanagement registry format!
   * @param useIgnored (default true) whether to check if the hub has been ignored. True = ignore config is used, meaning ignored hubs will not be switched off.
   */
  public shutdownAll(onlyBooted = true, baseUrl?: string, useIgnored = true): void {
    const simHubs: { sim: Simulator; hub: PhysicalHub; systemNumber: number }[] = [];
    this.systemSimsHelperService.start();
    const supportedSimNames = this.systemSimsHelperService.getAllSupportedSimulators();
    this.simulatorService
      .data()
      .pipe(take(1))
      .subscribe((sims: Simulator[]) => {
        if (sims) {
          sims.forEach(sim => {
            // Only include supported sims
            if (supportedSimNames.includes(sim.name)) {
              sim.physicalHub.forEach(hub => {
                const systemNumber = this.systemSimsHelperService.findMinimalSystem(sim.name);
                simHubs.push({ sim, hub, systemNumber });
              });
            }
          });
        }
        // Then shutdown all simulators.
        if (onlyBooted) {
          // if we can only switch off locally controlled hubs, get that list first to check
          // const systemNumbers = uniqWith(simHubs, (a, b) => a.systemNumber === b.systemNumber).map(hub => hub.systemNumber);
          // TODO - use systemNumber. Not in use because the BE is NOT systemNumber based - any hub can be switched off with arbitrary systemNumber reference.
          // eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars
          // for (const systemNumber of systemNumbers) {
          this.masterSubscription.add(this.getBootedHubs(1, baseUrl).subscribe(hubs => {
            if (!hubs?.hubIds) {
              return;
            }
            for (const hubId of hubs.hubIds) {
              const ignored = useIgnored ? this.isHubIgnored(hubId) : false;
              if (Number.isInteger(hubId) && !ignored) {
                this.powerOnOffHub('shutdown', 1, hubId, baseUrl).pipe(take(1)).subscribe();
              }
            }
          }));
          // }
        } else {
          // no protections - just kill everything (that isn't ignored)!
          for (const simHub of simHubs) {
            const ignored = useIgnored ? this.isHubIgnored(simHub.hub.hubId) : false;
            if (!ignored) {
              this.powerOnOffHub('shutdown', 1, simHub.hub.hubId, baseUrl).pipe(take(1)).subscribe();
            }
          }
        }
      });
  }

  /**
   * Check if this hub should be ignored. An ignored hub will not shutdown.
   *
   * @param hubId the hub to check
   */
  private isHubIgnored(hubId: number): boolean {
    const powerManagementReg = this.registry.getObject<PowerManagementRegistry>(['power', 'management'], null);
    if (!powerManagementReg?.ignoreHubs?.length) {
      return false;
    } // if no registry then nothing is ignored
    return !!powerManagementReg.ignoreHubs.find(hub => hub.hubId === hubId);
  }

  ngOnDestroy(): void {
    this.masterSubscription.unsubscribe();
  }
}
