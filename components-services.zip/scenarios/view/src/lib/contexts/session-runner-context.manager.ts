/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Inject, Injectable, Injector, NgZone, computed, inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { BehaviorSubject, Observable } from 'rxjs';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { UserService } from '@oksygen-sim-core-libraries/components-services/users';
import { UserScenarioFavouritesService } from '@oksygen-sim-core-libraries/components-services/favourites';
import { EventsService } from '@oksygen-sim-core-libraries/components-services/rule-endpoint';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { HubStateService } from '@oksygen-sim-train-libraries/components-services/hubs';
import {
  MapIoManagerFactory,
  OBJECT_MAP_RENDERER_TOKEN,
  ObjectMapRenderer,
  TrainReachablePathFinder,
  TrainObjectsTrackAtlasManager
} from '@oksygen-sim-train-libraries/components-services/maps';
import { ObjectTypeDataService, PointTypeDataService } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { RuleBlockService, RuleService, RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';
import { ScenarioService } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { ConsistDataService, TrainTypeService } from '@oksygen-sim-train-libraries/components-services/trains';
import { UserConfigService } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { UserFaultsService } from '@oksygen-sim-train-libraries/components-services/user-faults';
import { WorldDefinitionService, WorldManager } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { MarkerManager } from '../markers/services/marker.manager';
import { EnvironmentService } from '../services/environment.service';
import { ObjectCommsManager } from '../services/object-comms.manager';
import { TrainCommsManager } from '../services/train-comms.manager';
import { SystemStoreState } from '../store/system/system.state';
import { BaseScenarioSessionContextManager } from './base-scenario-session-context.manager';
import { createAtlasManagerConfiguration } from './create-atlas-manager-configuration';
import { SessionContext } from './session-context';
import { CSystemSimulatorHelpersService } from '../services/csystem-simulator-helpers.service';
import { ACTIVE_SESSION_TOKEN } from '../tokens/active-session.token';
import { toObservable } from '@angular/core/rxjs-interop';
import { RobotDriverService } from '@oksygen-sim-train-libraries/components-services/robot-drivers';
import { RadioService } from '../services/radio.service';
import { OperatorMarkerManager } from '../operator-score/public-api-operator'

@Injectable()
export class SessionRunnerContextManager extends BaseScenarioSessionContextManager<number> {

  activeSession = inject(ACTIVE_SESSION_TOKEN, {optional: true});

  constructor(
    protected readonly registry: Registry,
    protected readonly logger: Logging,
    protected readonly scenarioService: ScenarioService,
    protected readonly pointTypeDataService: PointTypeDataService,
    protected readonly objectTypeService: ObjectTypeDataService,
    protected readonly worldDefService: WorldDefinitionService,
    protected readonly zone: NgZone,
    protected readonly store: Store<SystemStoreState>,
    protected readonly trainTypeService: TrainTypeService,
    protected readonly consistDataService: ConsistDataService,
    protected readonly eventService: EventsService,
    protected readonly authService: AuthService,
    protected readonly favouritesService: UserScenarioFavouritesService,
    protected readonly faultService: UserFaultsService,
    protected readonly ruleBlockService: RuleBlockService,
    protected readonly ruleService: RuleService,
    protected readonly ruleTemplateService: RuleTemplateService,
    protected readonly userService: UserService,
    protected readonly environmentService: EnvironmentService,
    protected readonly radioService: RadioService,
    protected readonly userConfigService: UserConfigService,
    protected readonly cSystemSimulatorHelpersService: CSystemSimulatorHelpersService,
    private injector: Injector,
    protected readonly robotDriverService: RobotDriverService,
    @Inject(OBJECT_MAP_RENDERER_TOKEN) protected overrideObjectMapRenderer: ObjectMapRenderer
  ) {
    super();
  }

  protected createContext(id: number): SessionContext {
    const scenario$ = this.getFullScenarioFromSystemNumber(this.zone, this.store, this.scenarioService, id);
    const context = new SessionContext(scenario$);

    const objectTypes$ = this.objectTypeService.types$();
    const mapIoMan = MapIoManagerFactory();
    const ruleBlocks$ = this.ruleBlockService.data();
    const ruleTemplates$ = this.ruleTemplateService.data();

    const objectProcessor = this.populateObjectLngLat(this.zone, this.store, this.worldDefService, this.scenarioService, id);

    const world = new WorldManager(
      this.getWorldFromSystemNumber(this.zone, this.store, this.worldDefService, this.scenarioService, id),
      this.getWorldProcessorFromSystemNumber(this.zone, this.store, this.worldDefService, this.scenarioService, id)
    );

    const sessionIsFocused$: Observable<boolean> = toObservable(computed(() => this.activeSession() === id), {injector: this.injector});

    const objMan = new ObjectCommsManager(
      this.registry,
      this.logger,
      objectTypes$,
      scenario$,
      world,
      objectProcessor,
      id,
      this.favouritesService,
      this.cSystemSimulatorHelpersService,
      sessionIsFocused$
    );
    const visibleSegs = mapIoMan.getVisibleSegments$();

    const pathFinder$ = new BehaviorSubject<TrainReachablePathFinder>(null);
    const pathFinder = new TrainReachablePathFinder(this.pointTypeDataService.pointType(), objMan.getObject.bind(objMan));
    world.world$.subscribe(w => {
      pathFinder.setWorldData(w);
      pathFinder$.next(w ? pathFinder : null);
    });
    const trainMan = new TrainCommsManager(
      id,
      this.registry,
      scenario$,
      this.trainTypeService,
      this.consistDataService,
      this.logger,
      this.zone,
      visibleSegs,
      world,
      objMan,
      this.pointTypeDataService.pointType(),
      pathFinder$,
      this.cSystemSimulatorHelpersService,
      this.robotDriverService,
      sessionIsFocused$
    );
    const eventMan = this.eventService.createSystem(id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    const favouriteMan = this.favouritesService.create(id, this.authService.getLoggedInUser().id);
    const userFaultsMan = this.faultService.create(id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    const ruleMan = this.ruleService.createSystem(id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    this.ruleService.connectSystem(id);
    const envMan = this.environmentService.create(id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    const radioMan = this.radioService.create(id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    context.hubs = new HubStateService(this.registry, this.logger, id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
    const markerMan = new MarkerManager(this.registry, this.logger, id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));
	const operatorMarkerMan = new OperatorMarkerManager(this.registry, this.logger, id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));

    context.mapIo = mapIoMan;
    context.world = world;
    context.objects = objMan;
    context.rules = ruleMan;
    context.ruleBlocks$ = ruleBlocks$;
    context.ruleTemplates$ = ruleTemplates$;
    context.trains = trainMan;
    context.markers = markerMan;
	context.operatorMarkers = operatorMarkerMan;
    context.world.world$ = world.world$;
    context.events = eventMan;
    context.userFaults = userFaultsMan;
    context.userScenarioFavourites = favouriteMan;
    context.environment = envMan;
    context.radio = radioMan;
    context.pathFinder$ = pathFinder$;

    // Note that the order is important here; we make sure the context is set up as fully as possible so the map manager can use it.
    context.map = new TrainObjectsTrackAtlasManager(
      createAtlasManagerConfiguration(
        this.pointTypeDataService.pointType(),
        this.objectTypeService,
        this.consistDataService,
        context.objects,
        context.hubs,
        context.trains,
        context.world,
        context.pathFinder$,
        context.data$,
        this.logger,
        this.registry,
        this.overrideObjectMapRenderer
      ),
      this.logger,
      this.registry,
      this.zone
    );

    return context;
  }

  override destroyContext(id: number): void {
    super.destroyContext(id);

    // add any other service required destroy calls here for sessions
    // FIXME this check is pretty brittle
    if (typeof id === 'number') {
      this.eventService.destroySystem(id);
      this.favouritesService.destroy(id);
      this.faultService.destroySystem(id);
      this.ruleService.destroySystem(id);
      this.environmentService.destroy(id);
      this.radioService.destroy(id);
    }
  }
}
