/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Injectable } from '@angular/core';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { ContextManager } from '@oksygen-sim-train-libraries/components-services/common';
import { MapIoManagerFactory } from '@oksygen-sim-train-libraries/components-services/maps';
import { RuleBlockService, RuleTemplateService } from '@oksygen-sim-train-libraries/components-services/rules';

import { MarkerManager } from '../markers/services/marker.manager';
import { SessionContext } from './session-context';
import { CSystemSimulatorHelpersService } from '../services/csystem-simulator-helpers.service';

/**
 * A ContextManager for the Intercom screen.
 */
@Injectable()
export class IntercomDataService extends ContextManager<number, SessionContext> {
  constructor(
    private readonly registry: Registry,
    private readonly logger: Logging,
    private readonly ruleBlockService: RuleBlockService,
    private readonly ruleTemplateService: RuleTemplateService,
    private readonly cSystemSimulatorHelpersService: CSystemSimulatorHelpersService
  ) {
    super();
  }

  protected createContext(id: number): SessionContext {
    const context = new SessionContext();

    const mapIoMan = MapIoManagerFactory();
    const ruleBlocks$ = this.ruleBlockService.data();
    const ruleTemplates$ = this.ruleTemplateService.data();

    const markerMan = new MarkerManager(this.registry, this.logger, id, this.cSystemSimulatorHelpersService.isWebServerSessionActive(id));

    context.mapIo = mapIoMan;
    context.ruleBlocks$ = ruleBlocks$;
    context.ruleTemplates$ = ruleTemplates$;
    context.markers = markerMan;

    return context;
  }
}
