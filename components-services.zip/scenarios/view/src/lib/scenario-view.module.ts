/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { registrySchemaProvider } from '@oksygen-common-libraries/pio/registry';
import { OksygenSimCoreDataServicesModule, socketSchema } from '@oksygen-sim-core-libraries/components-services/data-services';
import { OksygenSimCoreUnitsModule } from '@oksygen-sim-core-libraries/components-services/measurement-units';
import { OksygenSimTrainNoCabHardwareModule } from '@oksygen-sim-train-libraries/components-services/cab-hardware';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainObjectsModule } from '@oksygen-sim-train-libraries/components-services/objects';
import { OksygenSimTrainObjectServicesModule } from '@oksygen-sim-train-libraries/components-services/objects/data';
import { OksygenSimTrainRuleModule } from '@oksygen-sim-train-libraries/components-services/rules';
import { OksygenSimTrainScenarioModule } from '@oksygen-sim-train-libraries/components-services/scenarios';
import { OksygenSimTrainTrainsModule } from '@oksygen-sim-train-libraries/components-services/trains';
import { OksygenSimTrainUserFaultsModule } from '@oksygen-sim-train-libraries/components-services/user-faults';
import { OksygenSimTrainWorldDefinitionModule } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { CameraControlsLayerComponent } from './camera-controls-layer/camera-controls-layer.component';
import {
  AerialCameraControlComponent
} from './camera-controls-layer/camera-controls/aerial-camera-control/aerial-camera-control.component';
import {
  ObjectCameraControlComponent
} from './camera-controls-layer/camera-controls/object-camera-control/object-camera-control.component';
import { TrackCameraControlComponent } from './camera-controls-layer/camera-controls/track-camera-control/track-camera-control.component';
import { EnvironmentControlsComponent } from './components/environment-controls/environment-controls.component';
import { NotificationListDialogComponent } from './components/event-dialogs/event-list-dialog/event-list-dialog.component';
import { InstructorPromptDialogComponent } from './components/event-dialogs/instructor-prompt-dialog/instructor-prompt-dialog.component';
import { SpatialEventDialogComponent } from './components/event-dialogs/spatial-event-dialog/spatial-event-dialog.component';
import { TemporalEventDialogComponent } from './components/event-dialogs/temporal-event-dialog/temporal-event-dialog.component';
import { ScenarioDetailPanelComponent } from './components/scenario-detail-panel/scenario-detail-panel.component';
import { ScenarioDetailRuleListComponent } from './components/scenario-detail-rule-list/scenario-detail-rule-list.component';
import { ScenarioDetailTrainListComponent } from './components/scenario-detail-train-list/scenario-detail-train-list.component';
import { ScenarioItemComponent } from './components/scenario-select/scenario-item/scenario-item.component';
import { ScenarioSelectComponent } from './components/scenario-select/scenario-select/scenario-select.component';
import { SessionTabNavItemComponent } from './components/session-tab-nav-item/session-tab-nav-item.component';
import {
  TrainsPanelTrainsDetailsComponent
} from './components/trains-panel/trains-panel-trains-details/trains-panel-trains-details.component';
import { TrainsPanelTrainsListComponent } from './components/trains-panel/trains-panel-trains-list/trains-panel-trains-list.component';
import { TrainsPanelComponent } from './components/trains-panel/trains-panel.component';
import { FaultItemComponent } from './components/user-faults/fault-item/fault-item.component';
import { FaultsPanelComponent } from './components/user-faults/faults-panel/faults-panel.component';
import { InitialConditionsPanelListItemComponent } from './components/initial-conditions-panel-list-item/initial-conditions-panel-list-item.component';
import { InitialConditionsItemComponent } from './components/initial-conditions-panel-list-item/initial-conditions-item/initial-conditions-item.component';
import { IntercomDataService } from './contexts/intercom-context.manager';
import { SessionRunnerContextManager } from './contexts/session-runner-context.manager';
import { SessionSetupContextManager } from './contexts/session-setup-context.manager';
import { SimpleSessionRunnerContextManager } from './contexts/simple-session-runner-context.manager';
import { SessionLogging } from './logging/session-logging';
import { commsConfigSchema } from './models/comms-config.model';
import { powerManagementConfigSchema } from './models/power-management-config.model';
import { sessionConfigSchema } from './models/session-config.model';
import { simConfigSchema } from './models/session-setup.model';
import { CommsModuleStateService } from './services/comms-module-state.service';
import { CSystemSimulatorHelpersService } from './services/csystem-simulator-helpers.service';
import { EnvironmentService } from './services/environment.service';
import { RadioService } from './services/radio.service';
import { SessionEventDialogService } from './services/session-dialog.manager';

const components = [
  ScenarioItemComponent,
  ScenarioSelectComponent,
  TrainsPanelTrainsListComponent,
  NotificationListDialogComponent,
  InstructorPromptDialogComponent,
  SpatialEventDialogComponent,
  TemporalEventDialogComponent,
  SessionTabNavItemComponent,
  EnvironmentControlsComponent,
  TrainsPanelTrainsDetailsComponent,
  TrainsPanelComponent,
  FaultItemComponent,
  FaultsPanelComponent,
  InitialConditionsPanelListItemComponent,
  InitialConditionsItemComponent,
  CameraControlsLayerComponent,
  TrackCameraControlComponent,
  AerialCameraControlComponent,
  ObjectCameraControlComponent
];

const importExportComponents = [
  ScenarioDetailPanelComponent,
  ScenarioDetailTrainListComponent,
  ScenarioDetailRuleListComponent
];

const importExportModules = [
  OksygenMaterialComponentsModule,
  OksygenSimCoreUnitsModule,
  OksygenSimTrainCommonModule,
  OksygenSimTrainUserFaultsModule,
  OksygenSimTrainRuleModule,
  OksygenSimTrainScenarioModule,
  OksygenSimTrainTrainsModule,
  OksygenSimTrainObjectsModule,
  OksygenSimTrainObjectServicesModule,
  OksygenSimTrainWorldDefinitionModule,
  OksygenSimTrainNoCabHardwareModule
];

/**
 * This module contains components that are shared between the Scenario Editor and Sessions which would have polluted the /scenarios endpoint.
 */
@NgModule({
  declarations: components,
  imports: [CommonModule, ...importExportModules, ...importExportComponents, OksygenSimCoreDataServicesModule.forChild()],
  exports: [...components, ...importExportModules, ...importExportComponents, OksygenSimCoreDataServicesModule],
  providers: [
    SessionLogging,
    CommsModuleStateService,
    CSystemSimulatorHelpersService,
    SessionEventDialogService,
    IntercomDataService,
    EnvironmentService,
    RadioService,
    SimpleSessionRunnerContextManager,
    SessionSetupContextManager,
    SessionRunnerContextManager,
    registrySchemaProvider(simConfigSchema),
    registrySchemaProvider(socketSchema('hubData')),
    registrySchemaProvider(socketSchema('markerData')),
    registrySchemaProvider(socketSchema('environmentData')),
    registrySchemaProvider(socketSchema('systemModuleStatus')),
    registrySchemaProvider(powerManagementConfigSchema),
    registrySchemaProvider(sessionConfigSchema),
    registrySchemaProvider(commsConfigSchema)
  ]
})
export class OksygenSimTrainScenarioViewModule {}
