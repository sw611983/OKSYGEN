/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs/operators';

import { generateUuid } from '@oksygen-common-libraries/common';
import { newFormControl, newOptionalFormControl } from '@oksygen-common-libraries/material/components';
import { InternalMarker, Marker } from '../../models/markers.model';
import { CSystemSimulatorHelpersService } from '../../../services/csystem-simulator-helpers.service';
import { calculateMarkerTime, getDefaultMarkerName } from '../../markers-utils';

@Component({
  templateUrl: './add-marker-dialog.component.html',
  styleUrls: ['./add-marker-dialog.component.scss']
})
export class AddMarkerDialogComponent implements OnInit {
  markerFormGroup: UntypedFormGroup;
  elapsedTime: number;

  constructor(
    public dialogRef: MatDialogRef<AddMarkerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { systemNumber: number; currentMarkers: Marker[] },
    private cSystemSimulatorHelpersService: CSystemSimulatorHelpersService
  ) {}

  ngOnInit(): void {
    const name = getDefaultMarkerName(this.data.currentMarkers);

    this.markerFormGroup = new UntypedFormGroup({
      name: newFormControl(),
      description: newOptionalFormControl(),
      tag: newOptionalFormControl(),
      timeAdjust: newOptionalFormControl()
    });

    this.markerFormGroup.setValue({
      name,
      description: '',
      tag: 'bad',
      timeAdjust: 0
    });

    this.cSystemSimulatorHelpersService
      .sessionStatus$(this.data.systemNumber)
      .pipe(take(1))
      .subscribe(sessionStatus => {
        this.elapsedTime = Math.floor(sessionStatus?.time) || 0;
      });
  }

  onAddClick(): void {
    const formValue = this.markerFormGroup.value;
    const markerTime = calculateMarkerTime(this.elapsedTime, formValue.timeAdjust);

    const marker: InternalMarker = {
      id: generateUuid(),
      name: formValue.name,
      time: markerTime,
      source: 'operator',
      tag: formValue.tag,
      description: formValue.description,
      originalTime: this.elapsedTime
    };

    this.dialogRef.close(marker);
  }

  onCancelClick(): void {
    this.dialogRef.close();
  }
}
