/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Subscription } from 'rxjs';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import { PromptDialogComponent, PromptDialogData, CANCEL_TEXT } from '@oksygen-common-libraries/material/components';
import { MaterialButtonVariant, MaterialThemePalette } from '@oksygen-common-libraries/material/theme';

import { SessionContext } from '../../../contexts/session-context';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { sourceMapping, tagMapping } from '../../markers-utils';
import { InternalMarker } from '../../models/markers.model';

@Component({
  selector: 'oksygen-marker-list-item',
  templateUrl: './marker-list-item.component.html',
  styleUrls: ['./marker-list-item.component.scss']
})
export class MarkerListItemComponent implements OnInit, OnDestroy {
  @Input() marker!: InternalMarker;

  private subscriptions = new Subscription();
  elapsedTimeInSecs: number;
  sourceIcon: string;
  displayedSource: string;
  tagIcon: string;
  displayedTag: string;

  constructor(
    private contextSupplier: SessionContextSupplier,
    private dialog: MatDialog) {}

  ngOnInit(): void {
    this.elapsedTimeInSecs = Math.floor(this.marker.time);
    this.updateTagIconAndText();
    this.updateSourceIconAndText();
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  updateTagIconAndText(): void {
    const tag = this.marker.tag;
    if (tag && Object.keys(tagMapping).includes(tag)) {
      this.tagIcon = tagMapping[tag].icon;
      this.displayedTag = tagMapping[tag].displayedName;
    } else {
      this.tagIcon = 'null';
      this.displayedTag = '';
    }
  }

  updateSourceIconAndText(): void {
    const source = this.marker.source;
    if (source && Object.keys(sourceMapping).includes(source)) {
      this.sourceIcon = sourceMapping[source].icon;
      this.displayedSource = sourceMapping[source].displayedName;
    } else {
      this.sourceIcon = 'null';
      this.displayedSource = '';
    }
  }

  onDeleteClick($event?: Event): void {
    $event.stopPropagation();

    const promptData = new PromptDialogData();
    promptData.title = t('Delete');
    promptData.content = t('Are you sure you want to delete this marker?');
    promptData.buttons = [
      {
        color: MaterialThemePalette.PRIMARY,
        text: CANCEL_TEXT,
        data: false
      },
      {
        color: MaterialThemePalette.PRIMARY,
        style: MaterialButtonVariant.BUTTON,
        text: t('Delete'),
        data: true
      }
    ];

    const dialogRef = this.dialog.open(PromptDialogComponent, {
      data: promptData,
      width: '400px',
      panelClass: 'small-whitespace-dialog'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteMarker();
      }
    });
  }

  deleteMarker(): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy(undefined, 200))
      .subscribe((manager: SessionContext) => manager.markers.deleteMarker(this.marker.id));
  }
}
