/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { Observable, Subscription } from 'rxjs';

import { allFilterTypesMatch, filterMatches, Filter, SelectedFilterArray, Sorter, SorterPipe } from '@oksygen-common-libraries/material/components';

import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { asArray } from '@oksygen-common-libraries/common';
import { InternalMarker } from '../../models/markers.model';
import { tagMapping } from '../../markers-utils';

interface MarkerListState {
  filters: MarkerPanelFilter;
}

enum FilterType {
  // These names are used to select the icon on chips of that type
  TAG = 'marker',
  NAME = 'search'
}

interface MarkerPanelFilter {
  search: string;
  selectedFilters: SelectedFilterArray<FilterType>;
}

const SELECTOR = 'oksygen-markers-list';

@Component({
  selector: SELECTOR,
  templateUrl: './markers-list.component.html',
  styleUrls: ['./markers-list.component.scss']
})
export class MarkersListComponent implements OnInit, OnChanges, OnDestroy {
  readonly EMPTY_FILTERS = new SelectedFilterArray<FilterType>();

  @Input('markers$') markers$!: Observable<InternalMarker[]>;
  @Input() uiModels!: UiStateModelManager;

  @Output() readonly addMarker: EventEmitter<void> = new EventEmitter();
  @Output('selectMarker') readonly selectMarker$: EventEmitter<InternalMarker> = new EventEmitter();

  markers: InternalMarker[] = [];
  state: MarkerListState;

  markerTags: { tag: string; icon: string; displayedName: string }[];
  sorter = new Sorter<InternalMarker>();
  filteredMarkers: InternalMarker[];
  endlessScrollBottomVisible = false;

  private sorterPipe = new SorterPipe();
  private subscription = new Subscription();

  constructor() {
    this.sorter.sortFunction = (c, a, b): number => (a?.time || 0) - (b?.time || 0);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.markers$ && changes.markers$.currentValue !== changes.markers$.previousValue) {
      this.subscription.unsubscribe();
      this.subscription = new Subscription();

      this.subscription = this.markers$.subscribe(markers => {
          this.markers = asArray(markers);
          this.applyFilters();
        });
    }
  }

  ngOnInit(): void {
    this.state = this.uiModels.getStateModel(SELECTOR, () => ({
      filters: {
        tagFilters: [],
        search: '',
        selectedFilters: new SelectedFilterArray<FilterType>()
      }
    }));

    this.markerTags = Object.entries(tagMapping).map(([key, value]) => ({ tag: key, ...value }));

    this.applyFilters();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  selectMarker(feature: InternalMarker): void {
    this.selectMarker$.emit(feature);
  }

  filterByTag(tag: string, displayText: string): void {
    if (tag) {
      this.clearAllTagFilters();
      this.addFilter(new Filter(FilterType.TAG, tag, displayText));
    }
  }

  clearTagFilters(): void {
    this.clearAllTagFilters();
    this.applyFilters();
  }

  onCurrentValueUpdate(text: string): void {
    this.state.filters.search = text;
    this.applyFilters();
  }

  applyFilters(): void {
    if (!this.markers) {
      return;
    }

    const filter = this.state?.filters;
    const searchText = filter?.search || null;

    let filteredMarkers = this.markers.filter(marker => {
      const names = [marker.name, marker.description];

      if (!allFilterTypesMatch([
            {t: FilterType.TAG, v: marker.tag, strict: true},
            {t: FilterType.NAME, v: names}
          ], filter?.selectedFilters ?? this.EMPTY_FILTERS)
      ) {
        return false;
      }

      if (!filterMatches(names, searchText)) {
        return false;
      }

      return true;
    });

    filteredMarkers = this.sorterPipe.transform(filteredMarkers, this.sorter, this.sorter.refresh);

    // Deep copy (1 level deep), that way cdkVirtualFor tracking understands there's a change.
    this.filteredMarkers = filteredMarkers.map(m => ({ ...m }));
  }

  textToFilter = (text: string): Filter<string> => new Filter(FilterType.NAME, text);

  private addFilter(filter: Filter<FilterType>): void {
    if (filter) {
      this.state.filters.selectedFilters.push(filter);
      this.applyFilters();
    }
  }

  private clearAllTagFilters(): void {
    this.state.filters.selectedFilters = this.state.filters.selectedFilters.filter(v => v.type !== FilterType.TAG);
  }
}
