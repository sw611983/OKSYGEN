/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { MarkersListComponent } from './markers-list.component';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';

describe('MarkersListComponent', () => {
  let component: MarkersListComponent;
  let fixture: ComponentFixture<MarkersListComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        declarations: [MarkersListComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkersListComponent);
    component = fixture.componentInstance;
    component.markers$ = new BehaviorSubject(null);
    component.uiModels = new UiStateModelManager();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
