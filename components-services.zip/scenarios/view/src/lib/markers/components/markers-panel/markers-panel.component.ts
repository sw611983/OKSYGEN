/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { forkJoin, Observable, Subscription } from 'rxjs';
import { filter, switchMap, take } from 'rxjs/operators';

import { filterTruthy, takeOneTruthy } from '@oksygen-common-libraries/common';
import { Logging } from '@oksygen-common-libraries/pio';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { DETAILS } from '@oksygen-sim-train-libraries/components-services/common';

import { SessionContext } from '../../../contexts/session-context';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { InternalMarker, Marker } from '../../models/markers.model';
import { MatDialog } from '@angular/material/dialog';
import { AddMarkerDialogComponent } from '../add-marker-dialog/add-marker-dialog.component';

@Component({
  selector: 'oksygen-markers-panel',
  templateUrl: './markers-panel.component.html',
  styleUrls: ['./markers-panel.component.scss']
})
export class MarkersPanelComponent implements OnInit, OnDestroy {
  @Input() uiModels!: UiStateModelManager;
  @Input() systemNumber!: number;

  markers$: Observable<InternalMarker[]>;
  selectedMarker: InternalMarker = null;
  breadcrumbChildren: ReadonlyArray<string>;
  mainSub = new Subscription();

  constructor(private contextSupplier: SessionContextSupplier, private logger: Logging, public readonly dialog: MatDialog) {}

  ngOnInit(): void {
    this.markers$ = this.contextSupplier.currentContext$().pipe(
      filterTruthy(),
      switchMap(m => m.markers?.data())
    );
  }

  ngOnDestroy(): void {
    this.mainSub.unsubscribe();
  }

  displayMarkerList(): void {
    this.selectedMarker = null;
    this.updateBreadcrumbs();
  }

  selectMarker(marker: InternalMarker): void {
    this.logger.log('selecting marker: ', marker);
    this.selectedMarker = marker;
    this.updateBreadcrumbs();
  }

  addMarker(): void {
        // TODO: Consolidate with session-top-toolbar.component.ts
    this.contextSupplier.currentContext$().pipe(
      // FIXME magic number
      takeOneTruthy<SessionContext>(undefined, 100),
      switchMap(man => man.markers.data()),
      take(1)
    ).subscribe(currentMarkers => {
      const dialog = this.dialog.open<AddMarkerDialogComponent, { systemNumber: number; currentMarkers: Marker[] }, InternalMarker>(AddMarkerDialogComponent, {
        data: { systemNumber: this.systemNumber, currentMarkers },
        minWidth: '600px'
      });
      forkJoin([
        dialog.afterClosed(),
        this.contextSupplier.currentContext$().pipe(takeOneTruthy<SessionContext>(undefined, 100))
      ]).pipe(
        filter( ([marker, manager]) => !!marker)
      ).subscribe( ([marker, manager]) => manager.markers.createMarker(marker));
    });
  }

  private updateBreadcrumbs(): void {
    if (this.selectedMarker) {
      this.breadcrumbChildren = [DETAILS];
    } else {
      this.breadcrumbChildren = null;
    }
  }

  deleteMarker(markerId: string): void {
    this.contextSupplier
      .currentContext$()
      .pipe(takeOneTruthy(undefined, 200))
      .subscribe((manager: SessionContext) => manager.markers.deleteMarker(markerId));

    this.displayMarkerList();
  }
}
