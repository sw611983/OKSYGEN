/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BehaviorSubject, Observable } from 'rxjs';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { ContextSupplier } from '@oksygen-sim-train-libraries/components-services/common';
import { MarkersListComponent } from '../markers-list/markers-list.component';
import { MarkersPanelComponent } from './markers-panel.component';
import { UiStateModelManager } from '@oksygen-sim-core-libraries/components-services/common';
import { SessionContext } from '../../../contexts/session-context';
import { Marker } from '../../models/markers.model';
import { OksygenSimTrainSessionModule } from '@oksygen-sim-train-libraries/components-services/session';

describe('MarkersPanelComponent', () => {
  let component: MarkersPanelComponent;
  let fixture: ComponentFixture<MarkersPanelComponent>;
  const manager = new BehaviorSubject<SessionContext>({ markers: { data: (): Observable<Marker[]> => new BehaviorSubject<Marker[]>(null) } as any } as any);

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainSessionModule],
        providers: [
          {
            provide: ContextSupplier,
            useValue: {
              currentContext$: (): Observable<SessionContext> => manager
            }
          }
        ],
        declarations: [MarkersPanelComponent, MarkersListComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkersPanelComponent);
    component = fixture.componentInstance;
    component.uiModels = new UiStateModelManager();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
