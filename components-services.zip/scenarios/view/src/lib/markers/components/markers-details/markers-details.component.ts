/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { calculateMarkerTime } from '../../markers-utils';


@Component({
  selector: 'oksygen-markers-details',
  templateUrl: './markers-details.component.html',
  styleUrls: ['./markers-details.component.scss']
})
export class MarkersDetailsComponent implements OnChanges {
  @Input() markerFormGroup: UntypedFormGroup;
  @Input() elapsedTime = 0;

  readonly sliderMinValue = -30;

  minValue = -30;

  displayedMarkerTime = 0;

  constructor() {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.elapsedTime && changes.elapsedTime.currentValue !== changes.elapsedTime.previousValue) {
      this.updateSliderMinValue();
    }

    if (changes.markerFormGroup && changes.markerFormGroup.currentValue !== changes.markerFormGroup.previousValue) {
      this.updateDisplayedTime(this.markerFormGroup.value.timeAdjust);
    }
  }

  updateDisplayedTime(timeAdjust: number): void {
    const markerTime = calculateMarkerTime(this.elapsedTime, timeAdjust);
    this.displayedMarkerTime = Math.floor(markerTime);
  }

  private updateSliderMinValue(): void {
    this.minValue = this.sliderMinValue;

    // don't allow a minValue that would allow a negative time
    if (this.minValue + this.elapsedTime < 0) {
      this.minValue = 0 - this.elapsedTime;
    }
  }

  calculateMarkerTime(timeAdjust: number): number {
    let markerTime = this.elapsedTime + timeAdjust;
    if (markerTime < 0) {
      markerTime = 0;
    }
    return markerTime;
  }
}
