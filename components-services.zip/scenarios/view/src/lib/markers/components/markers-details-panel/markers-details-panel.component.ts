/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { Subscription } from 'rxjs';

import { takeOneTruthy } from '@oksygen-common-libraries/common';
import {
  CANCEL_TEXT,
  newFormControl,
  newOptionalFormControl,
  PromptDialogComponent,
  PromptDialogData
} from '@oksygen-common-libraries/material/components';
import { MaterialButtonVariant, MaterialThemePalette } from '@oksygen-common-libraries/material/theme';

import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { calculateMarkerTime, sourceMapping, tagMapping } from '../../markers-utils';
import { InternalMarker, Marker } from '../../models/markers.model';

@Component({
  selector: 'oksygen-markers-details-panel',
  templateUrl: './markers-details-panel.component.html',
  styleUrls: ['./markers-details-panel.component.scss']
})
export class MarkersDetailsPanelComponent implements OnChanges, OnDestroy {
  @Input() marker!: InternalMarker;

  @Output() readonly delete = new EventEmitter<string>();

  markerFormGroup: UntypedFormGroup;
  elapsedTime: number;
  elapsedTimeInSecs: number;
  sourceIcon: string;
  displayedSource: string;
  tagIcon: string;
  displayedTag: string;

  private subscription = new Subscription();

  constructor(private contextSupplier: SessionContextSupplier,
    private dialog: MatDialog) {
    this.markerFormGroup = new UntypedFormGroup({
      name: newFormControl(),
      description: newOptionalFormControl(),
      tag: newOptionalFormControl(),
      timeAdjust: newOptionalFormControl()
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!!changes.marker && changes.marker.currentValue !== changes.marker.previousValue) {
      this.markerFormGroup.setValue({
        name: this.marker.name,
        description: this.marker.description,
        tag: this.marker.tag,
        timeAdjust: this.marker.time - this.marker.originalTime
      });

      this.elapsedTime = this.marker.originalTime ?? 0;

      this.elapsedTimeInSecs = Math.floor(this.marker.time);
      this.updateTagIconAndText(this.marker);
      this.updateSourceIconAndText(this.marker);

      this.subscription.unsubscribe();
      this.subscription = new Subscription();

      this.subscription = this.markerFormGroup.statusChanges.subscribe(() => {
        const formValue = this.markerFormGroup.value;
        const markerTime = calculateMarkerTime(this.elapsedTime, formValue.timeAdjust);

        const marker: Marker = {
          id: this.marker.id,
          name: formValue.name,
          time: markerTime,
          source: 'operator',
          tag: formValue.tag,
          description: formValue.description
        };

        this.contextSupplier
          .currentContext$()
          .pipe(takeOneTruthy())
          .subscribe(manager => {
            manager.markers.updateMarker(marker);
          });

        this.elapsedTimeInSecs = Math.floor(marker.time);
        this.updateTagIconAndText(marker);
        this.updateSourceIconAndText(marker);
      });
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  updateTagIconAndText(marker: Marker): void {
    const tag = marker.tag;

    if (tag && Object.keys(tagMapping).includes(tag)) {
      this.tagIcon = tagMapping[tag].icon;
      this.displayedTag = tagMapping[tag].displayedName;
    } else {
      this.tagIcon = 'null';
      this.displayedTag = '';
    }
  }

  updateSourceIconAndText(marker: Marker): void {
    const source = marker.source;

    if (source && Object.keys(sourceMapping).includes(source)) {
      this.sourceIcon = sourceMapping[source].icon;
      this.displayedSource = sourceMapping[source].displayedName;
    } else {
      this.sourceIcon = 'null';
      this.displayedSource = '';
    }
  }

  onDeleteClick($event?: Event): void {
    $event.stopPropagation();

    const promptData = new PromptDialogData();
    promptData.title = t('Delete');
    promptData.content = t('Are you sure you want to delete this marker?');
    promptData.buttons = [
      {
        color: MaterialThemePalette.PRIMARY,
        text: CANCEL_TEXT,
        data: false
      },
      {
        color: MaterialThemePalette.PRIMARY,
        style: MaterialButtonVariant.BUTTON,
        text: t('Delete'),
        data: true
      }
    ];

    const dialogRef = this.dialog.open(PromptDialogComponent, {
      data: promptData,
      width: '400px',
      panelClass: 'small-whitespace-dialog'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete.emit(this.marker.id);
      }
    });
  }
}
