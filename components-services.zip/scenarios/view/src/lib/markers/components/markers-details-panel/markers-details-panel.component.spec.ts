/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { configureSimTrainTestingModule } from '@oksygen-sim-train-libraries/components-services/testing';

import { MarkersDetailsComponent } from '../markers-details/markers-details.component';
import { MarkersDetailsPanelComponent } from './markers-details-panel.component';
import { SessionContextSupplier } from '../../../contexts/session-context.supplier';
import { OksygenSimTrainSessionModule } from '@oksygen-sim-train-libraries/components-services/session';

describe('MarkersDetailsPanelComponent', () => {
  let component: MarkersDetailsPanelComponent;
  let fixture: ComponentFixture<MarkersDetailsPanelComponent>;

  beforeEach(
    waitForAsync(() => {
      configureSimTrainTestingModule({
        imports: [OksygenSimTrainSessionModule],
        declarations: [MarkersDetailsPanelComponent, MarkersDetailsComponent],
        providers: [SessionContextSupplier]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkersDetailsPanelComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
