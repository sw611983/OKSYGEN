/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

export interface Marker {
  id: string;
  name?: string;
  time?: number;
  source?: string;
  tag?: string;
  description?: string;
}

export interface InternalMarker extends Marker {
  originalTime: number;
}

export type MarkerMessages = MarkerError | MarkerDefinitions | DeletedMarkers | DeleteMarker;

export interface MarkerError {
  code: number;
  description: string;
}

export type MarkerDefinitions = { markers: Marker[] };

export interface DeletedMarkers {
  markers: string[];
}

export interface DeleteMarker {
  id: string;
}
