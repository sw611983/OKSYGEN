/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { OksygenMaterialComponentsModule } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule } from '@oksygen-common-libraries/material/translate';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { OksygenSimTrainCommonModule } from '@oksygen-sim-train-libraries/components-services/common';

import { AddMarkerDialogComponent } from './components/add-marker-dialog/add-marker-dialog.component';
import { MarkersDetailsPanelComponent } from './components/markers-details-panel/markers-details-panel.component';
import { MarkersDetailsComponent } from './components/markers-details/markers-details.component';
import { MarkersListComponent } from './components/markers-list/markers-list.component';
import { MarkersPanelComponent } from './components/markers-panel/markers-panel.component';
import { MarkerListItemComponent } from './components/marker-list-item/marker-list-item.component';

export const markersComponents = [
  MarkersPanelComponent,
  MarkersListComponent,
  MarkerListItemComponent,
  AddMarkerDialogComponent,
  MarkersDetailsComponent,
  MarkersDetailsPanelComponent
];

@NgModule({
  declarations: markersComponents,
  imports: [
    RouterModule,
    CommonModule,
    DragDropModule,
    OksygenMaterialComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    // this is ugly to repeat everywhere, but it's the only way for this to be properly initialised
    OksygenMaterialTranslateModule.forChild(),
    OksygenSimTrainCommonModule
  ],
  exports: markersComponents
})
export class OksygenSimTrainMarkersModule {}
