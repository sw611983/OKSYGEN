/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BehaviorSubject, Observable } from 'rxjs';

import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { MarkerMessageIds, SocketMessage, SocketService } from '@oksygen-sim-core-libraries/components-services/data-services';
import { DeletedMarkers, Marker, MarkerDefinitions, MarkerMessages } from '../models/markers.model';
import { SuperCalled, asArray } from '@oksygen-common-libraries/common';

/**
 * Sources your markers data for you. It will grab this data from the marker data endpoint in the registry.
 */
export class MarkerDataService extends SocketService<MarkerMessageIds, MarkerMessages> {
  private markerDefinitionsSubject: BehaviorSubject<Marker[]> = new BehaviorSubject(null);
  private deletedMarkersSubject: BehaviorSubject<string[]> = new BehaviorSubject(null);

  constructor(registry: Registry, logger: Logging, systemNumber: number, serverStatus$: Observable<boolean>) {
    super(
      registry,
      logger,
      registry.getString(['markerData', 'url'], undefined, new Map<string, string>([['systemNumber', `${systemNumber}`]])),
      'MarkerDataService',
      serverStatus$
    );
  }

  public override destroy(): SuperCalled {
    this.closeConnection();
    this.markerDefinitionsSubject.complete();
    this.markerDefinitionsSubject = null;
    this.deletedMarkersSubject.complete();
    this.deletedMarkersSubject = null;
    return super.destroy();
  }

  /**
   * This observable will initially emit null (as it's a BehaviorSubject).
   * TODO handle if socket never connects, ie never get second emit of features after the null.
   */
  public markerDefinitions$(): Observable<Marker[]> {
    return this.markerDefinitionsSubject.asObservable();
  }

  public deletedMarkerSubject$(): Observable<string[]> {
    return this.deletedMarkersSubject.asObservable();
  }

  public createMarker(marker: Marker): void {
    const message: SocketMessage<MarkerMessageIds, any> = {
      messageId: MarkerMessageIds.CREATE_MARKER,
      message: marker
    };
    this.socket$.next(message);
  }

  public updateMarker(marker: Marker): void {
    const message: SocketMessage<MarkerMessageIds, any> = {
      messageId: MarkerMessageIds.UPDATE_MARKER,
      message: marker
    };
    this.socket$.next(message);
  }

  public deleteMarker(id: string): void {
    const message: SocketMessage<MarkerMessageIds, any> = {
      messageId: MarkerMessageIds.DELETE_MARKER,
      message: { id }
    };
    this.socket$.next(message);
  }

  protected onOpenSocket(): void {
    const message: SocketMessage<MarkerMessageIds, any> = {
      messageId: MarkerMessageIds.REQUEST_ALL_MARKERS,
      message: {}
    };
    this.socket$.next(message);
  }

  protected onMessage(message: SocketMessage<MarkerMessageIds, MarkerMessages | string[]>): void {
    try {
      if (!message?.message) {
        this.logger.log('[MarkerDataService] Malformed message!');
        return;
      }

      if (message.messageId === MarkerMessageIds.MARKER_DEFINITIONS) {
        const markers = asArray((message.message as MarkerDefinitions).markers);
        this.markerDefinitionsSubject.next(markers);
      } else if (message.messageId === MarkerMessageIds.DELETED_MARKERS) {
        const markerIds = asArray((message.message as DeletedMarkers).markers);
        this.deletedMarkersSubject.next(markerIds);
      } else if (message.messageId === MarkerMessageIds.MARKER_ERROR) {
        this.logger.log('[MarkerDataService] received marker error message: ', JSON.stringify(message.message));
      }
    } catch (err) {
      this.logger.log('[MarkerDataService] error on message: ', JSON.stringify(err));
    }
  }

  protected onSocketError(error: any): void {
    if (this.lastConnectionClosedClean) {
      this.logger.warn('An error occured in the marker socket: ', JSON.stringify(error));
    }
  }
}
