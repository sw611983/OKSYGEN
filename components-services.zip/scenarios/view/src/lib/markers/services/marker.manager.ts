/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { filterTruthy, shareReplayOne } from '@oksygen-common-libraries/common';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { BaseDataManager } from '@oksygen-sim-core-libraries/components-services/data-services';
import { cloneDeep, omit } from 'lodash';
import { InternalMarker, Marker } from '../models/markers.model';
import { MarkerDataService } from './marker-data.service';

export class MarkerManager extends BaseDataManager<Marker[]> {
  private subcriptions = new Subscription();
  private markers: InternalMarker[] = [];
  private markerDataService: MarkerDataService;
  private markerSubject: BehaviorSubject<InternalMarker[]>;

  constructor(registry: Registry, private logger: Logging, private systemNumber: number, serverStatus$: Observable<boolean>) {
    super();
    this.markerDataService = new MarkerDataService(registry, logger, this.systemNumber, serverStatus$);
    this.markerSubject = new BehaviorSubject(null);
  }

  connect(): void {
    if (this.markerDataService.isConnected()) {
      this.logger.warn(`[MarkerManager] attempting to connect to already connected data source.`);
      return;
    }
    this.markerDataService.openConnection();

    this.subcriptions.add(
      this.markerDataService
        .markerDefinitions$()
        .pipe(filterTruthy())
        .subscribe(markers => this.onMarkersChange(markers))
    );
    this.subcriptions.add(
      this.markerDataService
        .deletedMarkerSubject$()
        .pipe(filterTruthy())
        .subscribe(markers => this.onMarkersDeleted(markers))
    );
  }

  destroy(): void {
    this.markerDataService.destroy();
    this.subcriptions.unsubscribe();
    this.markerSubject.complete();
    this.markerSubject = null;
    this.markers = [];
  }

  /**
   * @deprecated
   */
  data(): Observable<InternalMarker[]> {
    return this.data$;
  }

  get data$(): Observable<InternalMarker[]> {
    if (!this.markerDataService.isConnected()) {
      this.connect();
    }

    return this.markerSubject.pipe(shareReplayOne());
  }

  onMarkersChange(endpointMarkers: Marker[]): void {
    const markers = cloneDeep(this.markers);

    for (const marker of endpointMarkers) {
      const oldMarker = markers.find(m => m.id === marker.id);

      if (oldMarker) {
        this.partiallyUpdateMarker(marker, oldMarker);
      } else {
        markers.push({ ...marker, originalTime: marker.time });
      }
    }

    this.markers = markers;
    this.markerSubject.next(this.markers);
  }

  onMarkersDeleted(markerIds: string[]): void {
    const newMarkers: InternalMarker[] = [];

    for (const marker of this.markers) {
      if (!markerIds.includes(marker.id)) {
        newMarkers.push(marker);
      }
    }

    this.markers = newMarkers;
    this.markerSubject.next(this.markers);
  }

  createMarker(marker: InternalMarker): void {
    this.markers.push(marker);

    if (!this.markerDataService.isConnected()) {
      this.connect();
    }

    this.markerDataService.createMarker(omit(marker, 'originalTime')); // remove the originalTime value prior to sending it to the endpoint
  }

  updateMarker(marker: Marker): void {
    this.markerDataService.updateMarker(marker);
  }

  deleteMarker(markerId: string): void {
    this.markerDataService.deleteMarker(markerId);
  }

  // This function replaces the fields in markerToUpdate with the ones in partialMarker, except id.
  private partiallyUpdateMarker(partialMarker: Marker, markerToUpdate: Marker): void {
    for (const [key, value] of Object.entries(partialMarker) as [keyof Marker, any][]) {
      // We don't want to change the id.
      if (key === 'id') {
        continue;
      }

      if (value != null) {
        (markerToUpdate as any)[key] = value;
      }
    }
  }
}
