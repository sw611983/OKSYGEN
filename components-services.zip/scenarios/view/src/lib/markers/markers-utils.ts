/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { OksygenIcon } from '@oksygen-common-libraries/material/icons';

import { Marker } from './models/markers.model';

export const tagMapping: { [tag: string]: { icon: string; displayedName: string } } = {
  good: {
    icon: OksygenIcon.MARKER_GOOD,
    displayedName: t('Good')
  },
  bad: {
    icon: OksygenIcon.MARKER_BAD,
    displayedName: t('Bad')
  },
  trainEvent: {
    icon: OksygenIcon.MARKER_TRAIN,
    displayedName: t('Train Event')
  },
  worldEvent: {
    icon: OksygenIcon.MARKER_WORLD,
    displayedName: t('World Event')
  }
};

export const sourceMapping: { [source: string]: { icon: string; displayedName: string } } = {
  operator: {
    icon: OksygenIcon.HEADPHONES,
    displayedName: t('Operator')
  },
  communication: {
    icon: OksygenIcon.COMMUNICATION,
    displayedName: t('Communications')
  },
  rule: {
    icon: OksygenIcon.RULE_EDITOR,
    displayedName: t('Rule')
  }
};

export function getDefaultMarkerName(currentMarkers: Marker[]): string {
  const currentMarkerNames = currentMarkers ? currentMarkers.map(m => m.name) : [];
  const defaultName: string = t('New Replay Marker');
  let name = defaultName;

  // Incrementing name as needed
  // This could be a while loop, but 1000 names should be more than enough.
  for (let i = 1; i < 1000; i++) {
    if (!currentMarkerNames.includes(name)) {
      break;
    }
    name = `${defaultName} (${i})`;
  }
  return name;
}

export function calculateMarkerTime(elapsedTime: number, timeAdjust: number): number {
  let markerTime = elapsedTime + timeAdjust;

  if (markerTime < 0) {
    markerTime = 0;
  }

  return markerTime;
}
