/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { RuleEditorState } from '@oksygen-sim-train-libraries/components-services/editors/rules';
import { ScenarioEditorState } from '@oksygen-sim-train-libraries/components-services/editors/scenarios';
import { SignalEditorState } from '@oksygen-sim-train-libraries/components-services/editors/signals';
import { SignEditorState } from '@oksygen-sim-train-libraries/components-services/editors/signs';
import { TrainEditorState } from '@oksygen-sim-train-libraries/components-services/editors/trains';
import { UserFaultEditorState } from '@oksygen-sim-train-libraries/components-services/editors/user-faults';
import { SystemStoreState } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

/**
 * Deprecated
 */
export interface AppState {
  systems: SystemStoreState;
  scenarioEditor: ScenarioEditorState;
  signEditor: SignEditorState;
  signalEditor: SignalEditorState;
  ruleEditor: RuleEditorState;
  userFaultEditor: UserFaultEditorState;
  trainEditor: TrainEditorState;
}
