/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { MoodlePermission } from '@oksygen-sim-core-libraries/components-services/moodle';
import { Permission } from '@oksygen-sim-core-libraries/components-services/permissions';

export class OksygenPermission extends Permission {
  static readonly OPERATOR_STATION = new Permission('OPERATOR_STATION');
  static readonly EDITING_STATION = new Permission('EDITING_STATION');
  static readonly ADDITIONAL_STATION = new Permission('ADDITIONAL_STATION');
  static readonly BRIEFING_STATION = new Permission('BRIEFING_STATION');
  static readonly ADDITIONAL_LOGS_REPORTS = new Permission('ADDITIONAL_LOGS_REPORTS');
  static readonly ADDITIONAL_PERMISSIONS = new Permission('ADDITIONAL_PERMISSIONS');
}

export class OksygenMoodlePermission extends MoodlePermission {
  static readonly OPERATOR_STATION = new MoodlePermission('local/oksygen:operator_station', OksygenPermission.OPERATOR_STATION);
  static readonly EDITING_STATION = new MoodlePermission('local/oksygen:editing_station', OksygenPermission.EDITING_STATION);
  static readonly ADDITIONAL_STATION = new MoodlePermission('local/oksygen:additional_station', OksygenPermission.ADDITIONAL_STATION);
  static readonly ADDITIONAL_LOGS_REPORTS = new MoodlePermission('local/oksygen:additional_logs_reports', OksygenPermission.ADDITIONAL_LOGS_REPORTS);
  static readonly ADDITIONAL_PERMISSIONS = new MoodlePermission('local/oksygen:additional_permissions', OksygenPermission.ADDITIONAL_PERMISSIONS);
  static readonly BRIEFING_STATION = new MoodlePermission('local/oksygen:briefing_station', OksygenPermission.BRIEFING_STATION);
}
