/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Route, Router, RouterStateSnapshot, UrlSegment, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';

import { OksygenPermission } from '../../moodle/models/permissions.model';
import { AppRoutePaths } from '../models/app-route-paths.model';

/**
 * Used by the routing module to determine if a route can be followed or not
 */
@Injectable({
  providedIn: 'root'
})
export class AuthenticationGuard  {
  constructor(private authService: AuthService, public router: Router) {}

  public canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (!this.authService.isLoggedIn()) {
      this.router.navigate([AppRoutePaths.ROOT]);
      return false;
    }

    return this.validatePath(route.routeConfig.path);
  }

  public canLoad(route: Route, segments: UrlSegment[]): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    return this.validatePath(route.path);
  }

  private validatePath(path: string): boolean {
    let result = this.authService.isLoggedIn();

    if (path.startsWith(AppRoutePaths.SESSION) || path.startsWith(AppRoutePaths.SIMULATORS_STATIONS)) {
      result = this.authService.loggedInUserHasPermission(OksygenPermission.SESSIONS);
    } else if (path.startsWith(AppRoutePaths.REPORTS)) {
      result = this.authService.loggedInUserHasAnyPermission(OksygenPermission.LOGS_REPORTS);
    } else if (path.startsWith(AppRoutePaths.ADMINISTRATION)) {
      result = this.authService.loggedInUserHasAnyPermission(OksygenPermission.PROFILE, OksygenPermission.PERMISSIONS);
    }

    return result;
  }
}
