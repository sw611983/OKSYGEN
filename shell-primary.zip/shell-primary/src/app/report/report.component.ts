/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
/// For more info see: https://material.angular.io/components/dialog/overview

import { coerceNumberProperty } from '@angular/cdk/coercion';
import { Component, input } from '@angular/core';

import { Logging } from '@oksygen-common-libraries/pio';
import { ViewReportComponent } from '@oksygen-sim-train-libraries/components-services/reports';

@Component({
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements ViewReportComponent {
  public readonly sessionId = input.required<number, number | string>({ transform: value => coerceNumberProperty(value, null) });

  public readonly traineeId = input.required<number, number | string>({ transform: value => coerceNumberProperty(value, null) });

  constructor(private readonly logging: Logging) {}

  printReport(): void {
    this.logging.debug('Would print report for session id', this.sessionId());
  }
}
