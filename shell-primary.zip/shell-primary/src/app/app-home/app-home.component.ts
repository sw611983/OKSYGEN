/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component } from '@angular/core';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';

import { AppLauncherInfo, AppLauncherInfoCollection } from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { ADMINISTRATION_ROUTE } from '@oksygen-sim-core-libraries/components-services/administration';
import { ENROLMENT } from '@oksygen-sim-train-libraries/components-services/administration';
import { AuthService } from '@oksygen-sim-train-libraries/components-services/authentication';
import { EditorData } from '@oksygen-sim-train-libraries/components-services/editors';
import { LINES_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/lines';
import { MULTIMEDIA_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/multimedia';
import { ROBOT_DRIVERS_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/robot-drivers';
import { RULES_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/rules';
import { SCENARIOS_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/scenarios';
import { SIGNALS_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/signals';
import { SIGNS_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/signs';
import { TRAINS_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/trains';
import { FAULTS_CARD_DATA } from '@oksygen-sim-train-libraries/components-services/editors/user-faults';
import { getLayoutCardData } from '@oksygen-sim-train-libraries/components-services/layouts';
import { LOGS_AND_REPORTS_DATA } from '@oksygen-sim-train-libraries/components-services/reports';
import { SESSIONS_DATA } from '@oksygen-sim-train-libraries/components-services/scenarios/view';

import { OksygenPermission } from '../moodle/models/permissions.model';

export function getAppLauncherInfo(authService: AuthService): AppLauncherInfoCollection[] {
  const allInfo: AppLauncherInfoCollection[] = [];
  const simulation: AppLauncherInfoCollection = { title: "Simulation", appInfos: [] };
  const editors: AppLauncherInfoCollection = { title: "Editors", appInfos: [] };
  const layouts: AppLauncherInfoCollection = {title: t('Layout Configurator'), appInfos: []};
  const administration: AppLauncherInfoCollection = { title: "Administration", appInfos: [] };

  addIfAllowed(authService, OksygenPermission.SESSIONS, simulation, SESSIONS_DATA);

  addIfAllowed(authService, OksygenPermission.LOGS_REPORTS, simulation, LOGS_AND_REPORTS_DATA);

  addIfAllowed(authService, OksygenPermission.LOGS_REPORTS, simulation,
    { title: t('Replay Session'), icon: OksygenIcon.REPLAY, page: '/replays-list' });

  // Not sure what the permission should be
  addIfAllowed(authService, OksygenPermission.SESSIONS, layouts, getLayoutCardData(1));
  addIfAllowed(authService, OksygenPermission.SESSIONS, layouts, getLayoutCardData(2));

  addEditorIfAllowed(authService, OksygenPermission.EDIT_FAULTS,    editors, FAULTS_CARD_DATA);
  addEditorIfAllowed(authService, OksygenPermission.EDIT_OBJECTS,   editors, LINES_CARD_DATA); // FIXME Probably not the correct permission
  addEditorIfAllowed(authService, OksygenPermission.EDIT_RULES,     editors, RULES_CARD_DATA);
  addEditorIfAllowed(authService, OksygenPermission.EDIT_SCENARIOS, editors, SCENARIOS_CARD_DATA);
  addEditorIfAllowed(authService, OksygenPermission.EDIT_OBJECTS,   editors, SIGNALS_CARD_DATA); // FIXME Probably not the correct permission
  addEditorIfAllowed(authService, OksygenPermission.EDIT_SIGNS,     editors, SIGNS_CARD_DATA);
  addEditorIfAllowed(authService, OksygenPermission.EDIT_TRAINS,    editors, ROBOT_DRIVERS_CARD_DATA);  // FIXME create it's own permissions
  addEditorIfAllowed(authService, OksygenPermission.EDIT_TRAINS,    editors, TRAINS_CARD_DATA);
  addEditorIfAllowed(authService, OksygenPermission.LMS, editors, MULTIMEDIA_CARD_DATA); // FIXME create it's own permissions

  simulation.appInfos.push({ title: t('Communication Panel'), icon: OksygenIcon.BLANK, page: '/comms-panel' });
  simulation.appInfos.push({ title: t('Wrong'), icon: OksygenIcon.BLANK, page: '/meh' });

  addIfAllowed(authService, OksygenPermission.PERMISSIONS, administration, { title: t('Enrolment'), icon: OksygenIcon.ENROL, page: `/${ADMINISTRATION_ROUTE}/${ENROLMENT}` });
  administration

  if (simulation.appInfos.length > 0) {
    allInfo.push(simulation);
  }

  if (editors.appInfos.length > 0) {
    allInfo.push(editors);
  }

  if(layouts.appInfos.length > 0) {
    allInfo.push(layouts);
  }

  if(administration.appInfos.length > 0) {
    allInfo.push(administration);
  }
  return allInfo;
}

function addEditorIfAllowed(authService: AuthService, permission: OksygenPermission, collection: AppLauncherInfoCollection, data: EditorData): void {
  addIfAllowed(authService, permission, collection, data.toAppLauncherInfo());
}

function addIfAllowed(authService: AuthService, permission: OksygenPermission, collection: AppLauncherInfoCollection, info: AppLauncherInfo): void {
  if (authService.loggedInUserHasPermission(permission)) {
    collection.appInfos.push(info);
  }
}


@Component({
  templateUrl: './app-home.component.html',
  styleUrls: ['./app-home.component.scss'],
})
export class AppHomeComponent {
  cards = getAppLauncherInfo(this.authService);

  constructor(private authService: AuthService) {
  }
}
