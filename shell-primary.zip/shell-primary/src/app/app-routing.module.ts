/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ADMINISTRATION_ROUTE } from '@oksygen-sim-core-libraries/components-services/administration';
import { commsPanelRoute } from '@oksygen-sim-train-libraries/components-services/communication';
import { editorsRoute } from '@oksygen-sim-train-libraries/components-services/editors';
import { layoutRoute } from '@oksygen-sim-train-libraries/components-services/layouts';
import { replayBrowserRoute, replayRoute } from '@oksygen-sim-train-libraries/components-services/replay';
import { reportBrowserRoute, reportRoute } from '@oksygen-sim-train-libraries/components-services/reports';
import { sessionRoute } from '@oksygen-sim-train-libraries/components-services/session';
import { simulatorStationsRoute } from '@oksygen-sim-train-libraries/components-services/simulators';

import { AppHomeComponent } from './app-home/app-home.component';
import { AppComponent } from './app.component';
import { AuthenticationGuard } from './authentication/services/authentication.guard';

const routes: Routes = [
  { path: 'home', component: AppHomeComponent, canActivate: [AuthenticationGuard] },
  commsPanelRoute({ auth: [AuthenticationGuard] }),
  simulatorStationsRoute({ auth: [AuthenticationGuard] }),
  sessionRoute({ auth: [AuthenticationGuard] }),
  reportRoute({ auth: [AuthenticationGuard] }),
  reportBrowserRoute({ auth: [AuthenticationGuard] }),
  replayRoute({ auth: [AuthenticationGuard] }),
  replayBrowserRoute({ auth: [AuthenticationGuard] }),
  layoutRoute({ auth: [AuthenticationGuard] }),
  editorsRoute({
    loadChildren: () => import('./editors/editors-routing.module').then(m => m.EditorRoutingModule),
    auth: [AuthenticationGuard]
  }),
  {
    path: ADMINISTRATION_ROUTE,
    loadChildren: () => import('./administration-routing.module').then(m => m.AdministrationRoutingModule)
  },
 { path: '**', component: AppComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
