/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.
import { Injectable } from '@angular/core';
import { ScenarioEditorExtensions } from '@oksygen-sim-train-libraries/components-services/scenarios';

@Injectable()
export class DefaultScenarioEditorExtension extends ScenarioEditorExtensions {

}
