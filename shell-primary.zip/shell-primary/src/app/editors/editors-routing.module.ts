/// @copyright © 2021 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { defaultScenarioEditorLibraryTabsConfig } from '@oksygen-sim-train-libraries/components-services/component-library/components';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { linesEditorRoute } from '@oksygen-sim-train-libraries/components-services/editors/lines';
import { multimediaBrowserRoute } from '@oksygen-sim-train-libraries/components-services/editors/multimedia';
import { robotDriverBrowserRoute } from '@oksygen-sim-train-libraries/components-services/editors/robot-drivers';
import { ruleBrowserRoute, ruleEditorRoute } from '@oksygen-sim-train-libraries/components-services/editors/rules';
import {
  defaultScenarioEditorConfig,
  scenarioBrowserRoute,
  scenarioEditorRoute
} from '@oksygen-sim-train-libraries/components-services/editors/scenarios';
import { signalBrowserRoute } from '@oksygen-sim-train-libraries/components-services/editors/signals';
import { signBrowserRoute, signEditorRoute } from '@oksygen-sim-train-libraries/components-services/editors/signs';
import { trainEditorRoute, trainsBrowserRoute } from '@oksygen-sim-train-libraries/components-services/editors/trains';
import { userFaultBrowserRoute, userFaultEditorRoute } from '@oksygen-sim-train-libraries/components-services/editors/user-faults';

const scenarioEditorConfig = defaultScenarioEditorConfig(defaultScenarioEditorLibraryTabsConfig());

const routes: Routes = [
  linesEditorRoute(),
  multimediaBrowserRoute(),
  ruleBrowserRoute(),
  ruleEditorRoute(),
  scenarioBrowserRoute(),
  scenarioEditorRoute({ data: scenarioEditorConfig }),
  robotDriverBrowserRoute(),
  signalBrowserRoute(),
  signBrowserRoute(),
  signEditorRoute(),
  trainsBrowserRoute(),
  trainEditorRoute(),
  userFaultBrowserRoute(),
  userFaultEditorRoute()
];

@NgModule({
  imports: [OksygenSimTrainEditorsModule, RouterModule.forChild(routes)],
  exports: [OksygenSimTrainEditorsModule, RouterModule]
})
export class EditorRoutingModule {}
