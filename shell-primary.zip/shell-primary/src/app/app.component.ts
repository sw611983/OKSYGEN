/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { Component, Inject, OnDestroy, Optional } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { Title } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { marker as t } from '@biesbjerg/ngx-translate-extract-marker';
import { TranslateService } from '@oksygen-common-libraries/material/translate';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { APP_EVENT_NOTIFICATION_TOKEN, AppEventNotification } from '@oksygen-common-libraries/common';
import {
  createSideNavItems,
  SideNavClick,
  SideNavDivider,
  SideNavItem,
  SideNavService,
  SideNavText
} from '@oksygen-common-libraries/material/components';
import { OksygenIcon } from '@oksygen-common-libraries/material/icons';
import { initialiseI18N } from '@oksygen-common-libraries/material/translate';
import { Logging, Registry } from '@oksygen-common-libraries/pio';
import { SideNavLoggedInUserComponent } from '@oksygen-sim-core-libraries/components-services/users';
import { APPS_HOME_SIDENAV_ROUTERLINK } from '@oksygen-sim-train-libraries/components-services';
import { AuthService, defaultLogout } from '@oksygen-sim-train-libraries/components-services/authentication';
import { GlobalImageStoreKey, ImageService, InactivityComponent } from '@oksygen-sim-train-libraries/components-services/common';
import { RuleEditorContextManager, RuleEditorContextPublisher } from '@oksygen-sim-train-libraries/components-services/editors/rules';
import {
  ScenarioEditorContextManager,
  ScenarioEditorContextPublisher,
  ScenarioRouteReuseStrategy
} from '@oksygen-sim-train-libraries/components-services/editors/scenarios';
import {
  UserFaultEditorContextManager,
  UserFaultEditorContextPublisher
} from '@oksygen-sim-train-libraries/components-services/editors/user-faults';
import {
  ObjectTypeDataService,
  PointTypeDataService,
  startLoadingObjectTypeIcons,
  startLoadingPointTypeIcons
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { ReplayRouteReuseStrategy } from '@oksygen-sim-train-libraries/components-services/replay';
import { CustomRouteReuseStrategy, RouteReuseType } from '@oksygen-sim-train-libraries/components-services/routing';
import { RuleBlockService, startLoadingRuleBlockIcons } from '@oksygen-sim-train-libraries/components-services/rules';
import {
  IntercomContextPublisher,
  IntercomDataService,
  SessionRunnerContextManager,
  SessionRunnerContextPublisher,
  SessionSetupContextManager,
  SessionSetupContextPublisher,
  SimpleSessionRunnerContextManager,
  SimpleSessionRunnerContextPublisher
} from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { SessionRouteReuseStrategy } from '@oksygen-sim-train-libraries/components-services/session';
import { StartupModule } from '@oksygen-sim-train-libraries/components-services/startup';
import { SettingsComponent } from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { loadTracks, TrackDataService, WorldDefinitionService } from '@oksygen-sim-train-libraries/components-services/world-definition';

import { getAppLauncherInfo } from './app-home/app-home.component';
import { OBJECT_MAP_RENDERER_TOKEN, ObjectMapRenderer } from '@oksygen-sim-train-libraries/components-services/maps';
import { ErrorService } from '@oksygen-sim-core-libraries/components-services/common';
import { TrainEditorContextManager, TrainEditorContextPublisher } from '@oksygen-sim-train-libraries/components-services/editors/trains';

@Component({
  selector: 'oksygen-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent extends InactivityComponent implements OnDestroy {

  isLoggedIn$: Observable<boolean>;

  startupComplete = false;

  loggedInSub: Subscription;

  softwareLoading: Observable<number | boolean>[] = [];

  modules: StartupModule[] = [
    {
      name: t('software'),
      icon: OksygenIcon.WORKSTATION,
      toLoad: this.softwareLoading,
      loadSequential: true
    },
    {
      name: t('hardware'),
      icon: OksygenIcon.SERVER,
      toLoad: []
    }
  ];

  private inactivityTimerEnabled = false;

  constructor(
    registry: Registry,
    logging: Logging,
    private translate: TranslateService,
    private titleService: Title,
    private sideNavService: SideNavService,
    dialog: MatDialog,
    private authService: AuthService,
    pointTypeService: PointTypeDataService,
    objectTypeService: ObjectTypeDataService,
    imageService: ImageService,
    ruleBlockService: RuleBlockService,
    private routeReuseStrategy: RouteReuseStrategy,
    private worldDefService: WorldDefinitionService,
    private trackDataService: TrackDataService,
    private errorService: ErrorService,
    @Inject(APP_EVENT_NOTIFICATION_TOKEN) private appEventNotifier: BehaviorSubject<AppEventNotification>,
    @Optional() private ruleEditorContextManager: RuleEditorContextManager,
    @Optional() private ruleEditorContextPublisher: RuleEditorContextPublisher,
    @Optional() private scenarioEditorContextManager: ScenarioEditorContextManager,
    @Optional() private scenarioEditorContextPublisher: ScenarioEditorContextPublisher,
    @Optional() private userFaultEditorContextManager: UserFaultEditorContextManager,
    @Optional() private userFaultEditorContextPublisher: UserFaultEditorContextPublisher,
    @Optional() private intercomContextManager: IntercomDataService,
    @Optional() private intercomContextPublisher: IntercomContextPublisher,
    @Optional() private sessionRunnerContextManager: SessionRunnerContextManager,
    @Optional() private sessionRunnerContextPublisher: SessionRunnerContextPublisher,
    @Optional() private sessionSetupContextManager: SessionSetupContextManager,
    @Optional() private sessionSetupContextPublisher: SessionSetupContextPublisher,
    @Optional() private simpleSessionRunnerContextManager: SimpleSessionRunnerContextManager,
    @Optional() private simpleSessionRunnerContextPublisher: SimpleSessionRunnerContextPublisher,
    @Optional() private trainEditorContextManager: TrainEditorContextManager,
    @Optional() private trainEditorContextPublisher: TrainEditorContextPublisher,
    @Inject(OBJECT_MAP_RENDERER_TOKEN) protected overrideObjectMapRenderer: ObjectMapRenderer
  ) {
    super(registry, logging, dialog);
    this.isLoggedIn$ = authService.isLoggedIn$();
    this.loggedInSub = this.isLoggedIn$.subscribe(loggedIn => {
      if (loggedIn) {
        this.stopInactivityTimer();
        this.completeLogin();
        this.initialiseRouteReuseHandlers();
      } else if (this.inactivityTimerEnabled) {
        this.startInactivityTimer();
      }
    });
    
    this.loggedInSub.add(this.translate.onLangChange.subscribe(() => {
      this.updateTitle();
    }));
    
    initialiseI18N(this.registry, this.translate);
    this.errorService.validateRegistry();
    
    this.softwareLoading.push(startLoadingPointTypeIcons(pointTypeService, imageService));
    const toLoad = this.registry.getObject('app', {initialLoad: {featureTypes: true, tracks: true}});
    if (this.overrideObjectMapRenderer?.images) {
      this.overrideObjectMapRenderer?.images.forEach(i => {
        objectTypeService.loadImage(GlobalImageStoreKey.SMALL, i);
      });
    }
    if (!toLoad?.initialLoad || toLoad.initialLoad?.featureTypes) {
      this.softwareLoading.push(startLoadingObjectTypeIcons(objectTypeService, imageService));
    }
    if (!toLoad?.initialLoad || toLoad.initialLoad?.tracks) {
      const trackNames = Array.isArray(toLoad.initialLoad?.tracks) ? toLoad.initialLoad?.tracks : undefined;
      const tracks$ = loadTracks(this.worldDefService, this.trackDataService, trackNames);
      const trackModules: StartupModule = {
        name: t('tracks'),
        icon: 'track',
        toLoad: [tracks$]
      };
      this.modules.push(trackModules);
    }
    this.softwareLoading.push(startLoadingRuleBlockIcons(ruleBlockService, imageService));
  }

  override ngOnDestroy(): void {
    super.ngOnDestroy();
    this.loggedInSub.unsubscribe();
  }

  public completeStartup(): void {
    this.startupComplete = true;
  }

  private initialiseRouteReuseHandlers(): void {
    (this.routeReuseStrategy as CustomRouteReuseStrategy)?.initialiseHandler(RouteReuseType.SESSION, new SessionRouteReuseStrategy());
    (this.routeReuseStrategy as CustomRouteReuseStrategy)?.initialiseHandler(RouteReuseType.SCENARIO, new ScenarioRouteReuseStrategy());
    (this.routeReuseStrategy as CustomRouteReuseStrategy)?.initialiseHandler(RouteReuseType.REPLAY, new ReplayRouteReuseStrategy());
  }

  private destroyContexts(): void {
    this.ruleEditorContextManager?.contexts.forEach((value, key) => {
      this.ruleEditorContextPublisher?.destroyCurrentContext(key);
    });

    this.scenarioEditorContextManager?.contexts.forEach((value, key) => {
      this.scenarioEditorContextPublisher?.destroyCurrentContext(key);
    });

    this.userFaultEditorContextManager?.contexts.forEach((value, key) => {
      this.userFaultEditorContextPublisher?.destroyCurrentContext(key);
    });

    this.intercomContextManager?.contexts.forEach((value, key) => {
      this.intercomContextPublisher?.destroyCurrentContext(key);
    });

    this.sessionRunnerContextManager?.contexts.forEach((value, key) => {
      this.sessionRunnerContextPublisher?.destroyCurrentContext(key);
    });

    this.sessionSetupContextManager?.contexts.forEach((value, key) => {
      this.sessionSetupContextPublisher?.destroyCurrentContext(key);
    });

    this.simpleSessionRunnerContextManager?.contexts.forEach((value, key) => {
      this.simpleSessionRunnerContextPublisher?.destroyCurrentContext(key);
    });

    this.trainEditorContextManager?.contexts.forEach((value, key) => {
      this.trainEditorContextPublisher?.destroyCurrentContext(key);
    });
  }

  private clearRouteReuseHandlers(): void {
    (this.routeReuseStrategy as CustomRouteReuseStrategy)?.clearHandlers();
  }

  public completeLogin(): void {
    const loggedInUser = this.authService.getLoggedInUser();
    this.logging.log(
      'User logged in: ' +
        JSON.stringify({
          ...loggedInUser,
          // Password redacted
          password: loggedInUser.password?.replace(/./g, '*'),
          // No need to log binary data
          avatar: !!loggedInUser.avatar ? '**binary data omitted**' : loggedInUser.avatar,
          avatarHandler: !!loggedInUser.avatarHandler ? '**binary data omitted**' : loggedInUser.avatarHandler
        })
    );

    // we've already logged in, but this is being called again
    if (this.sideNavService.sideNavScrollableItems.length > 0) {
      return;
    }

    const navItems: SideNavItem<any>[] = [
      APPS_HOME_SIDENAV_ROUTERLINK,
      ...createSideNavItems(getAppLauncherInfo(this.authService)),
      new SideNavDivider('margin: 10px 0px;'),
      new SideNavText(t('Help'), 'help'),
      new SideNavClick(t('Settings'), () => SettingsComponent.openSettings(this.dialog), 'settings'),
      new SideNavClick(t('Logout'), () => {
        defaultLogout(this.dialog, this.authService, this.onLogout.bind(this));
        this.onLogout();
      }, 'log_out')
    ];

    this.appEventNotifier.next({type: 'LOGIN'});

    this.sideNavService.addSideNavItems(new SideNavItem(SideNavLoggedInUserComponent, loggedInUser));
    this.sideNavService.addSideNavScrollableItems(...navItems);
  }

  onLogout(): void {
    this.destroyContexts();
    this.clearRouteReuseHandlers();
    this.appEventNotifier.next({type: 'LOGOUT'});
  }

  private updateTitle(): void {
    this.titleService.setTitle(this.translate.instant(t('Primary Shell App')));
  }

  inactivityTimerChanged(change: MatSlideToggleChange): void {
    this.inactivityTimerEnabled = change.checked;

    if (this.inactivityTimerEnabled) {
      this.startInactivityTimer();
    } else {
      this.stopInactivityTimer();
    }
  }

  protected shutdown(): void {
    this.logging.log('System would shutdown due to inactivity');
  }
}
