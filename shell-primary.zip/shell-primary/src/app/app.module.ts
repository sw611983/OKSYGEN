/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgxMatDatetimePickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { APP_INITIALIZER, NgModule, provideExperimentalZonelessChangeDetection } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteReuseStrategy, RouterModule } from '@angular/router';
import { EffectsModule } from '@ngrx/effects';
import { Action, ActionReducer, ActionReducerMap, StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AngularSplitModule } from 'angular-split';
import { cloneDeep } from 'lodash';
import { MomentModule } from 'ngx-moment';
import { combineLatest } from 'rxjs';

import { OksygenCommonModule } from '@oksygen-common-libraries/common';
import { electronDisplayError, ElectronScreenConfig, ElectronService } from '@oksygen-common-libraries/common/electron';
import { OksygenDataAccessBasexModule } from '@oksygen-common-libraries/data-access/basex';
import { OksygenMaterialComponentsModule, VerticalToolboxMode } from '@oksygen-common-libraries/material/components';
import { OksygenMaterialTranslateModule, TranslateLoaderType } from '@oksygen-common-libraries/material/translate';
import { OksygenWasmNetworkDefinitionModule } from '@oksygen-common-libraries/network-definition';
import {
  Logging,
  OksygenPioBackupModule,
  PioRegistryDataIniConverter,
  PioRegistryDataPropertiesConverter,
  PioRegistryDataYamlConverter,
  Registry
} from '@oksygen-common-libraries/pio';
import { OksygenPioLoggingElectronModule } from '@oksygen-common-libraries/pio/logging/electron';
import { OksygenPioRegistryElectronModule } from '@oksygen-common-libraries/pio/registry/electron';
import { OksygenWasmSynopticViewModule } from '@oksygen-common-libraries/synoptic-view';
import { OksygenSimCoreCommonModule } from '@oksygen-sim-core-libraries/components-services/common';
import { InternalLmsServiceConfig, InternalLmsServiceConfigToken } from '@oksygen-sim-core-libraries/components-services/lms';
import { OksygenSimCoreDataAccessMoodleConfigurableModule } from '@oksygen-sim-core-libraries/components-services/moodle';
import { createDefaultInternalLmsConfig, OksygenSimTrainComponentsServicesModule } from '@oksygen-sim-train-libraries/components-services';
import { OksygenSimTrainAssessmentCriteriaModule } from '@oksygen-sim-train-libraries/components-services/assessment-criteria';
import { OksygenSimTrainAuthenticationModule } from '@oksygen-sim-train-libraries/components-services/authentication';
import { OksygenSimTrainNoCabHardwareModule } from '@oksygen-sim-train-libraries/components-services/cab-hardware';
import {
  OksygenSimTrainPowerManagementModule,
  UndoableActionEntityMetaReducer
} from '@oksygen-sim-train-libraries/components-services/common';
import { OksygenSimTrainEditorsModule } from '@oksygen-sim-train-libraries/components-services/editors';
import { OksygenSimTrainMultimediaEditModule } from '@oksygen-sim-train-libraries/components-services/editors/multimedia';
import { OksygenSimTrainRobotDriverEditModule } from '@oksygen-sim-train-libraries/components-services/editors/robot-drivers';
import {
  OksygenSimTrainRuleEditModule,
  ruleEditorActions,
  RuleEditorData,
  ruleEditorDataAdapter,
  ruleEditorReducer
} from '@oksygen-sim-train-libraries/components-services/editors/rules';
import {
  OksygenSimTrainScenarioEditModule,
  scenarioEditorActions,
  ScenarioEditorData,
  scenarioEditorDataAdapter,
  scenarioEditorReducer
} from '@oksygen-sim-train-libraries/components-services/editors/scenarios';
import { OksygenSimTrainSignalEditModule, signalEditorReducer } from '@oksygen-sim-train-libraries/components-services/editors/signals';
import { OksygenSimTrainSignEditModule, signEditorReducer } from '@oksygen-sim-train-libraries/components-services/editors/signs';
import {
  OksygenSimTrainTrainEditModule,
  trainEditorActions,
  trainEditorDataAdapter,
  trainEditorReducer,
  TrainEditorStoreData
} from '@oksygen-sim-train-libraries/components-services/editors/trains';
import {
  OksygenSimTrainUserFaultEditModule,
  userFaultEditorActions,
  userFaultEditorDataAdapter,
  userFaultEditorReducer,
  UserFaultEditorStoreData
} from '@oksygen-sim-train-libraries/components-services/editors/user-faults';
import { OksygenSimTrainHomeModule } from '@oksygen-sim-train-libraries/components-services/home';
import {
  LAYOUT_TOKEN,
  LayoutEditorItem,
  OksygenSimTrainLayoutModule,
  VIEWS_TOKEN
} from '@oksygen-sim-train-libraries/components-services/layouts';
import { OksygenSimTrainMultimediaModule } from '@oksygen-sim-train-libraries/components-services/multimedia';
import { OksygenSimTrainObjectsModule } from '@oksygen-sim-train-libraries/components-services/objects';
import {
  OksygenSimTrainObjectServicesModule,
  OksygenSimTrainPointServicesModule
} from '@oksygen-sim-train-libraries/components-services/objects/data';
import { OksygenSimTrainReplayModule } from '@oksygen-sim-train-libraries/components-services/replay';
import { OksygenSimTrainReportsModule, ReportBrowserTableColumn } from '@oksygen-sim-train-libraries/components-services/reports';
import { CustomRouteReuseStrategy } from '@oksygen-sim-train-libraries/components-services/routing';
import { OksygenSimTrainRuleModule } from '@oksygen-sim-train-libraries/components-services/rules';
import {
  OksygenSimTrainScenarioModule,
  SCENARIO_EDITOR_EXTENSIONS_TOKEN,
  ScenarioService
} from '@oksygen-sim-train-libraries/components-services/scenarios';
import {
  EnvironmentEffects,
  OksygenSimTrainScenarioViewModule,
  PowerManagementService,
  ScenarioServiceImpl,
  systemDataReducer
} from '@oksygen-sim-train-libraries/components-services/scenarios/view';
import { OksygenSimTrainSessionModule, SessionEffects } from '@oksygen-sim-train-libraries/components-services/session';
import { OksygenSimTrainSessionDataModule } from '@oksygen-sim-train-libraries/components-services/session/data';
import { OksygenSimTrainStartupModule } from '@oksygen-sim-train-libraries/components-services/startup';
import {
  INITIAL_USER_CONFIG_TOKEN,
  OksygenSimTrainUserConfigurationModule,
  UserConfig
} from '@oksygen-sim-train-libraries/components-services/user-configuration';
import { defaultVersionRegistryConfig, OksygenSimTrainVersionModule } from '@oksygen-sim-train-libraries/components-services/versioning';

import { environment } from '../environments/environment';
import { AppHomeComponent } from './app-home/app-home.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DefaultScenarioEditorExtension } from './editors/default-scenario-editor-extension';
import { ReportComponent } from './report/report.component';
import { AppState } from './store/state/app.state';
import { OksygenSimTrainAdministrationEnrolmentBrowserModule } from '@oksygen-sim-train-libraries/components-services/administration';

// Combine meta reduces for each editor into one mega meta reducer (try saying that three times)
// which will delegate to the appropriate editor based on the action type.
export const metaReducer = (reducer: ActionReducer<any, Action>) => {
  function createScenarioStoreDataWith(id: string | number, state: AppState, scenario: ScenarioEditorData): AppState {
    const scenarioEntity = cloneDeep(state.scenarioEditor.entities[id]);
    scenarioEntity.editorItem = scenario.editorItem;
    scenarioEntity.canRedo = scenario.canRedo;
    scenarioEntity.canUndo = scenario.canUndo;
    const scenarioEditor = scenarioEditorDataAdapter.setOne(scenarioEntity, state.scenarioEditor);

    const newAppState = {
      ...state,
      scenarioEditor
    };
    return newAppState;
  }

  function createRuleStoreDataWith(id: string | number, state: AppState, ruleTemplate: RuleEditorData): AppState {
    const ruleEntity = cloneDeep(state.ruleEditor.entities[id]);
    ruleEntity.editorItem = ruleTemplate.editorItem;
    ruleEntity.canRedo = ruleTemplate.canRedo;
    ruleEntity.canUndo = ruleTemplate.canUndo;
    const ruleEditor = ruleEditorDataAdapter.setOne(ruleEntity, state.ruleEditor);

    const newAppState = {
      ...state,
      ruleEditor
    };
    return newAppState;
  }

  function createUserFaultStoreDataWith(id: string | number, state: AppState, userFault: UserFaultEditorStoreData): AppState {
    const userFaultEntity = cloneDeep(state.userFaultEditor.entities[id]);
    userFaultEntity.editorItem = userFault.editorItem;
    userFaultEntity.canUndo = userFault.canUndo;
    userFaultEntity.canRedo = userFault.canRedo;
    const userFaultEditor = userFaultEditorDataAdapter.setOne(userFaultEntity, state.userFaultEditor);

    const newAppState = {
      ...state,
      userFaultEditor: userFaultEditor
    };
    return newAppState;
  }

  function createTrainStoreDataWith(id: string | number, state: AppState, train: TrainEditorStoreData): AppState {
    const trainEntity = cloneDeep(state.trainEditor.entities[id]);
    trainEntity.editorItem = train.editorItem;
    trainEntity.canUndo = train.canUndo;
    trainEntity.canRedo = train.canRedo;
    const trainEditor = trainEditorDataAdapter.setOne(trainEntity, state.trainEditor);

    const newAppState = {
      ...state,
      trainEditor: trainEditor
    };
    return newAppState;
  }

  const seMetaReducer = new UndoableActionEntityMetaReducer<AppState, ScenarioEditorData>(
    scenarioEditorActions.undoScenarioEdit.type,
    scenarioEditorActions.redoScenarioEdit.type,
    scenarioEditorActions.scenarioClosed.type,
    (id, s) => {
      for (const scenarioEditorStoreData of Object.values(s.scenarioEditor.entities)) {
        if (scenarioEditorStoreData.id === id) {
          return scenarioEditorStoreData;
        }
      }

      return null;
    },
    createScenarioStoreDataWith
  );

  const str = ruleEditorActions.undoRuleEdit.type;
  const reMetaReducer = new UndoableActionEntityMetaReducer<AppState, RuleEditorData>(
    ruleEditorActions.undoRuleEdit.type,
    ruleEditorActions.redoRuleEdit.type,
    ruleEditorActions.ruleTemplateClosed.type,
    (id, s) => {
      for (const ruleEditorStoreData of Object.values(s.ruleEditor.entities)) {
        if (ruleEditorStoreData.id === id) {
          return ruleEditorStoreData;
        }
      }

      return null;
    },
    createRuleStoreDataWith
  );

  const ufeMetaReducer = new UndoableActionEntityMetaReducer<AppState, UserFaultEditorStoreData>(
    userFaultEditorActions.userFaultUndo.type,
    userFaultEditorActions.userFaultRedo.type,
    userFaultEditorActions.userFaultClosed.type,
    (id, s) => {
      for (const userFaultEditorStoreData of Object.values(s.userFaultEditor.entities)) {
        if (userFaultEditorStoreData.id === id) {
          return userFaultEditorStoreData;
        }
      }

      return null;
    },
    createUserFaultStoreDataWith
  );

  const teMetaReducer = new UndoableActionEntityMetaReducer<AppState, TrainEditorStoreData>(
    trainEditorActions.trainUndo.type,
    trainEditorActions.trainRedo.type,
    trainEditorActions.trainClosed.type,
    (id, s) => {
      for (const trainEditorStoreData of Object.values(s.trainEditor.entities)) {
        if (trainEditorStoreData.id === id) {
          return trainEditorStoreData;
        }
      }

      return null;
    },
    createTrainStoreDataWith
  );

  return (state: any, action: any) => {
    const stTypes = Object.values(scenarioEditorActions).map(action => action.type);
    if (stTypes.includes(action.type)) {
      return seMetaReducer.reduce(reducer)(state, action);
    }
    const rtActions = Object.values(ruleEditorActions);
    const rtTypes = rtActions.map(action => action.type);
    if (rtTypes.includes(action.type)) {
      return reMetaReducer.reduce(reducer)(state, action);
    }
    const ufActions = Object.values(userFaultEditorActions);
    const ufTypes = ufActions.map(action => action.type);
    if (ufTypes.includes(action.type)) {
      return ufeMetaReducer.reduce(reducer)(state, action);
    }
    const trainActions = Object.values(trainEditorActions);
    const trainTypes = trainActions.map(action => action.type);
    if (trainTypes.includes(action.type)) {
      return teMetaReducer.reduce(reducer)(state, action);
    }

    return reducer(state, action);
  };
};

const reducers: ActionReducerMap<AppState> = {
  systems: systemDataReducer,
  ruleEditor: ruleEditorReducer,
  scenarioEditor: scenarioEditorReducer,
  signEditor: signEditorReducer,
  signalEditor: signalEditorReducer,
  userFaultEditor: userFaultEditorReducer,
  trainEditor: trainEditorReducer
};

const USER_CONFIG: UserConfig = {
  toolboxMode: VerticalToolboxMode.OVER,
  notificationDetailLevel: 'simple',
  positionFormat: ['segment', 'userScale', 'trackName'],
  uomFormat: 'metric',
  additionalProperties: [
    // { id: 'string', label: 'Some String', type: 'string', value: '' },
    // { id: 'number', label: 'Some number', type: 'number', value: 0 },
    // { id: 'mlist', label: 'Multi list', type: 'list', multi: true, value: [1], values: [{ value: 1 }, { value: 2 }, { value: 3 }] },
    // { id: 'slist', label: 'Single choice list', type: 'list', multi: false, value: 1, values: [{ value: 1 }, { value: 2 }, { value: 3 }] }
  ]
};

function internalLmsServiceConfigFactory(scenarioService: ScenarioService): InternalLmsServiceConfig {
  return createDefaultInternalLmsConfig(scenarioService);
}

@NgModule({
  declarations: [AppComponent, AppHomeComponent, ReportComponent],
  bootstrap: [AppComponent],
  imports: [
    CommonModule,
    OksygenCommonModule,
    OksygenMaterialComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    OksygenSimCoreCommonModule,
    OksygenWasmNetworkDefinitionModule,
    OksygenWasmSynopticViewModule,
    NgxMatDatetimePickerModule,
    NgxMatMomentModule,
    RouterModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ScrollingModule,
    // store
    StoreModule.forRoot(reducers, {
      metaReducers: [metaReducer],
      runtimeChecks: {
        strictStateImmutability: true,
        strictActionImmutability: true
      }
    }),
    EffectsModule.forRoot([SessionEffects, EnvironmentEffects]),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: environment.production }),
    // Logging and Registry
    OksygenPioLoggingElectronModule.forRoot({ directory: '../logs', logFileName: 'primary_shell.log' }),
    OksygenPioRegistryElectronModule.forRoot({
      configFiles: [...environment.registryConfigFiles],
      converters: [new PioRegistryDataYamlConverter(), new PioRegistryDataIniConverter(), new PioRegistryDataPropertiesConverter()]
    }),
    OksygenPioBackupModule,
    // translations
    OksygenMaterialTranslateModule.forRoot({ loaderType: TranslateLoaderType.ELECTRON }),
    OksygenSimCoreDataAccessMoodleConfigurableModule.forRoot(),
    //OksygenSimCoreDataAccessLdapModule,
    OksygenSimTrainNoCabHardwareModule,
    OksygenDataAccessBasexModule.forRoot(),
    // Date/Time API
    MomentModule.forRoot({
      relativeTimeThresholdOptions: {
        m: 59
      }
    }),
    AngularSplitModule,
    OksygenSimTrainObjectsModule,
    OksygenSimTrainPointServicesModule,
    OksygenSimTrainObjectServicesModule,
    OksygenSimTrainSessionModule,
    OksygenSimTrainReplayModule,
    OksygenSimTrainReportsModule.forRoot(
      {
        displayColumns: [
          ReportBrowserTableColumn.SAVED_AT,
          ReportBrowserTableColumn.SIMULATOR,
          ReportBrowserTableColumn.INSTRUCTOR,
          ReportBrowserTableColumn.TRAINEE,
          ReportBrowserTableColumn.SCENARIO
        ],
        filterColumns: [
          ReportBrowserTableColumn.SAVED_AT,
          ReportBrowserTableColumn.SIMULATOR,
          ReportBrowserTableColumn.INSTRUCTOR,
          ReportBrowserTableColumn.TRAINEE,
          ReportBrowserTableColumn.SCENARIO
        ],
        supportUUID: false,
        dateFormat: 'YYYY-MM-DD hh:mm:ss'
      },
      {
        reportComponent: ReportComponent
      }
    ),
    OksygenSimTrainUserConfigurationModule,
    OksygenSimTrainEditorsModule,
    OksygenSimTrainRuleModule,
    OksygenSimTrainRuleEditModule,
    OksygenSimTrainUserFaultEditModule,
    OksygenSimTrainMultimediaModule,
    OksygenSimTrainMultimediaEditModule,
    OksygenSimTrainSignEditModule,
    OksygenSimTrainSignalEditModule,
    OksygenSimTrainRobotDriverEditModule,
    OksygenSimTrainSessionDataModule,
    OksygenSimTrainScenarioEditModule,
    OksygenSimTrainScenarioModule.forRoot({
      scenarioService: ScenarioServiceImpl
    }),
    OksygenSimTrainScenarioViewModule,
    OksygenSimTrainAuthenticationModule,
    OksygenSimTrainPowerManagementModule.forRoot(PowerManagementService),
    OksygenSimTrainStartupModule,
    OksygenSimTrainHomeModule,
    OksygenSimTrainComponentsServicesModule,
    OksygenSimTrainVersionModule.forRoot(defaultVersionRegistryConfig('Core Dev')),
    OksygenSimTrainLayoutModule,
    OksygenSimTrainAssessmentCriteriaModule.forRoot(),
    OksygenSimTrainTrainEditModule,
    OksygenSimTrainAdministrationEnrolmentBrowserModule
  ],
  providers: [
    provideExperimentalZonelessChangeDetection(),
    {
      provide: RouteReuseStrategy,
      useClass: CustomRouteReuseStrategy
    },
    {
      provide: InternalLmsServiceConfigToken,
      useFactory: internalLmsServiceConfigFactory,
      deps: [ScenarioService]
    },
    {
      // providing --base-href ./ as cmd param fails deprecation on builds
      // providing baseHref under build.options in angular.json fails builds too
      provide: APP_BASE_HREF,
      useValue: './'
    },
    { provide: INITIAL_USER_CONFIG_TOKEN, useValue: USER_CONFIG },
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      multi: true,
      deps: [Registry, Logging, ElectronService]
    },
    {
      provide: LAYOUT_TOKEN,
      useValue: [
        { displayName: '1', value: 'one', icon: 'layout_01', type: 'Layout One View' },
        { displayName: '4', value: 'four', icon: 'layout_04', type: 'Layout Four Views' },
        { displayName: '4 Alt', value: 'four_alt', type: 'Layout Four Views Alt' },
        { displayName: '5', value: 'five', icon: 'layout_05', type: 'Layout Five Views' }
      ]
    },
    {
      provide: VIEWS_TOKEN,
      useValue: new Map<string, LayoutEditorItem[]>([
        ['Cameras Streams', [{ displayName: 'Trainee CCTV', icon: 'cctv', name: 'Stream:Camera' }]],
        ['Vision Streams', [{ displayName: 'Forward Vision', icon: 'vision_forward', name: 'Stream:Vision' }]],
        [
          'Misc. Streams',
          [
            { displayName: 'VTI', icon: 'vti', name: 'Stream:VTI' },
            { displayName: 'HMI', icon: '', name: 'Stream:HMI' },
            { displayName: 'Trainee', icon: 'trainee', name: 'Stream:Trainee' },
            { displayName: 'Trainee', icon: 'trainee', name: 'Stream:Trainee' },
            { displayName: 'Trainee', icon: 'trainee', name: 'Stream:Trainee' }
          ]
        ]
      ])
    },
    provideHttpClient(withInterceptorsFromDi()),
    {
      provide: SCENARIO_EDITOR_EXTENSIONS_TOKEN,
      useClass: DefaultScenarioEditorExtension
    }
  ]
})
export class AppModule {}

export function initApp(registry: Registry, logging: Logging, electronService: ElectronService): () => Promise<void> {
  return async (): Promise<void> => {
    logging.info('[AppModule] initApp');

    // this is a hack, for development purposes only, and should not be copied into project code
    // this will force the electron browser to load to the root level again (on every even call)
    await electronService.ipcRenderer.invoke('forceRestart');

    return new Promise(resolve => {
      const subscription = combineLatest([registry.loaded(), logging.loaded()]).subscribe(([regLoaded, logLoaded]) => {
        if (regLoaded && logLoaded) {
          logging.info('[AppModule] Finished loading registry');
          registryInitialised(registry, logging, electronService);
          try {
            subscription.unsubscribe();
          } catch (e) {}

          setTimeout(() => resolve(), 5000);
        }
      });
    });
  };
}

export function registryInitialised(registry: Registry, logging: Logging, electronService: ElectronService): void {
  try {
    // if needed, install and use cordova-plugin-device to see if is electron
    logging.info('[AppModule] registryInitialised');
    const screenConfig = registry.getObject<ElectronScreenConfig>('app.screen');
    logging.info(`[AppModule] Pos X/Y is: ${screenConfig.position?.x} / ${screenConfig.position?.y}`);
    logging.info(`[AppModule] Window W/H is: ${screenConfig.size?.width} / ${screenConfig.size?.height}`);
    logging.info(`[AppModule] resizable: ${screenConfig.resizable}, screen initial state: ${screenConfig.screenState}`);

    electronService.configureWindow(screenConfig);
    electronService.windowFlashFrame(true);

    // make sure the menu bar is not visible for prod
    if (environment.production) {
      electronService.setWindowMenuBarVisibility(false);
    }
  } catch (error) {
    logging.fatal('[AppModule] Error initialising window', error);
    electronDisplayError(error);
  }
}

interface Screen {
  size: {
    width: number;
    height: number;
  };
  position: {
    x: number;
    y: number;
  };
  fullscreen: boolean;
  resizable: boolean;
}
