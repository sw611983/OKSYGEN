/// <reference lib="webworker" />
import { WorldWorker } from '@oksygen-sim-train-libraries/components-services/worker';
// FIXME TS can't find the below JS file anymore, needs investigating why this changed
// @ts-ignore
import NetworkDefinition from '@oksygen-common-libraries/network-definition/lib/assets/wasm/network_definition.js';

const worldWorker = new WorldWorker();
worldWorker.initialiseWasm(NetworkDefinition);
