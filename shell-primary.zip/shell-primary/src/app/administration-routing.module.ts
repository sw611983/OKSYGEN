/// @copyright © 2023 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { administrationEnrolmentRoute } from '@oksygen-sim-train-libraries/components-services/administration';

@NgModule({
  imports: [RouterModule.forChild([administrationEnrolmentRoute()])],
  exports: [RouterModule]
})
export class AdministrationRoutingModule {}
