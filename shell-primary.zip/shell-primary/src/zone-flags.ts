/// @copyright © 2020 Oktal Sydac
/// This is unpublished proprietary source code. The copyright notice above
/// does not evidence any actual or intended publication of such source code.

// this file is for configuring how ZoneJS works. ZoneJS is the library that determines
// when to fire change detection (CD).
// IE, on button click, observable emission, web socket message, etc
// We're concerned with switching off various parts of ZoneJS so we can run code without it.
// Note that we're just switching off default behaviour - you can still manually fire CD.
// By default, ZoneJS wraps just about everything (timeouts, socket messages, animation firing).
// Many of these checks are redundant, and even worse, you can't use runOutsideAngular()
// to escape them because change detection has already been triggered by the time
// it gets to your application logic! An example of this is mapbox talking to it's worker thread
// to calculate changes then rendering them via requestAnimationFrame(). Both of these
// will trigger change detection, neither of these should.
// ZoneJS docs aren't very useful, I found the following to help more:
// https://angular.io/guide/zone
// https://github.com/angular/angular/blob/HEAD/packages/zone.js/STANDARD-APIS.md
// https://stackoverflow.com/questions/58537060/angular-getting-out-of-zone-js-for-specific-callbacks
// It's also worth noting that a lot of examples online (including the above!) are for
// old versions and don't work out of the box anymore.

// we don't want requestAnimationFrame() or mousemove calling change detection automatically
if (window) {
  (window as any).__Zone_disable_requestAnimationFrame = true;
  (window as any).__zone_symbol__UNPATCHED_EVENTS = [ 'mousemove', 'message' ];
}
// Stop worker AND web socket messages from automatically firing change detection
// currently working on how to separate these, see commented code below.
// this is scary - we sometimes DO want message to fire change detection automatically
if (global) {
  (global as any).__zone_symbol__UNPATCHED_EVENTS = [ 'mousemove', 'message' ];
}

// this is apparently the proper way to do it, but isn't working
// const props = (global as any).__Zone_ignore_on_properties || (
//   (global as any).__Zone_ignore_on_properties = []
// );
// props.push(
//   { target: WebSocket.prototype, ignoreProperties: ['close', 'error', 'open', 'message'] },
//   { target: Worker.prototype, ignoreProperties: ['close', 'error', 'open', 'message'] }
// );

// this is apparently the proper way to do it, but isn't working
// (WebSocket.prototype as any).__zone_symbol__UNPATCHED_EVENTS = [ 'message' ];
// (Worker.prototype as any).__zone_symbol__UNPATCHED_EVENTS = [ 'message' ];
